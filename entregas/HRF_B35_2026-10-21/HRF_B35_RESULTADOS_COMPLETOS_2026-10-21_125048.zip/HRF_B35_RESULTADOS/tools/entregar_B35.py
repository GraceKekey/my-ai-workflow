"""Empacotamento e visualização após a avaliação congelada; não altera decisões."""
import json, pathlib, hashlib, zipfile, datetime, csv
from zoneinfo import ZoneInfo
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
P=pathlib.Path(__file__).resolve().parents[1]
r=json.loads((P/'resultados/avaliacao_B35.json').read_text())
stamp=datetime.datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%d_%H%M%S')
(P/'figuras').mkdir(exist_ok=True)
(P/'tabelas').mkdir(exist_ok=True)
def table(name,rows):
 with (P/'tabelas'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
rows=[]
for name,g in r['por_grafo'].items():
 rows.append(dict(grafo=name,a1=g['a1']['decisao'],fracao_exata=g['a1']['frac_exata'],fracao_graduada=g['a1']['frac_graduada'],lema=g['a1']['lema'],T2=g['a2']['decisao_T2'],delta_med=g['a2']['delta_med'],T3=g['a2']['decisao_T3'],dS_rel_med=g['a2']['dS_rel_med'],a3=g['a3']['decisao'],rho_med=g['a3']['rho_med']))
table('alfa_por_grafo.csv',rows)
b=r['beta']
table('beta_por_kappa.csv',[dict(kappa=k,b1=v['decisao'],tau=v['tau'],b2=b['b2'][k]['decisao'],D=b['b2'][k]['D'],razao_M2=b['b2'][k]['razao_M2_AC']) for k,v in b['b1'].items()])
fig,axs=plt.subplots(1,3,figsize=(14,4.3),layout='constrained')
ks=sorted(float(k) for k in b['b1'] if float(k)>0)
tau=[b['b1'][str(k)]['tau'] for k in ks]
axs[0].loglog(ks,tau,'o-',label='K4 medido')
axs[0].loglog(ks,[tau[0]*(k/ks[0])**-2 for k in ks],'--',label='referência κ⁻²')
axs[0].set(xlabel='κ',ylabel='Tempo de seleção τ',title='Sombreado transitório');axs[0].legend()
D=[b['b2'][str(k)]['D'] for k in ks]
axs[1].loglog(ks,D,'o-',label='K4 × K3 medido')
axs[1].loglog(ks,[D[0]*(k/ks[0])**4 for k in ks],'--',label='referência κ⁴')
axs[1].set(xlabel='κ',ylabel='Diferença D no vácuo',title='Distinção por relações virtuais');axs[1].legend()
for nm in ['K40','R3_1024','R6_512','TRI24']:
 fs=r['por_grafo'][nm]['a3']['fontes'];f=fs[0]
 axs[2].plot(f['cascas'],f['t_med'],'o-',label=nm)
axs[2].set(xlabel='Distância no grafo',ylabel='Tempo médio de chegada',title='Primeira fonte; demais no JSON');axs[2].legend()
for a in axs:a.grid(alpha=.25)
fig.savefig(P/'figuras/B35_resumo.png',dpi=180);fig.savefig(P/'figuras/B35_resumo.pdf');plt.close(fig)
expected=['B35a_'+n+'.json' for n in ['K24','K40','R3_512','R3_1024','R6_256','R6_512','TRI16','TRI24']]+['B35b1_K4.json','B35b1_K5.json','B35b2.json','B35_config.json']
assert all((P/'resultados'/f).is_file() for f in expected)
cfg=json.loads((P/'resultados/B35_config.json').read_text());assert cfg['modo']=='completo'
for n in cfg['cfg']['grafos']:
 g=json.loads((P/'resultados'/('B35a_'+n+'.json')).read_text());assert len(g['a1'])==200 and len(g['a2'])==40 and len(g['a3'])==4
assert len(json.loads((P/'resultados/B35b1_K4.json').read_text())['casos'])==12
assert len(json.loads((P/'resultados/B35b1_K5.json').read_text())['casos'])==2
vacs=json.loads((P/'resultados/B35b2.json').read_text());assert len(vacs['K4'])==6 and len(vacs['K5'])==3
(P/'auditoria/cobertura.json').write_text(json.dumps(dict(modo='completo',grafos=8,triplos_a1=1600,triplos_a2=320,fontes_a3=32,casos_b1_K4=12,casos_b1_K5=2,pares_vacuo_K4=6,pares_vacuo_K5=3,verificacao='PASSOU'),indent=2))
lines=['# HRF B35 — Relatório da execução completa',f'\nData: {stamp} (America/Sao_Paulo). Autoria HRF: Mario José do Canto Filho, MD. Execução: Codex.','\n## Objetivo','[M] Testar seleção, independência, ordem de chegada e distinção entre vértice sombreado e ausente nos modelos α e β do protocolo.','\n## Hipóteses','[M] α: seleção exata associada à degenerescência; independência somente no completo; estado escuro distinguível do ausente. [H] A ordem pode seguir a distância de grafo sem geometria reconstruída. [M] β: sombreado transitório para κ>0, τ∝κ⁻² e diferença virtual D∝κ⁴.','\n## Parâmetros','[M] Parâmetros integralmente preservados do protocolo: α μ²=C=1; oito grafos K24/K40, R3_512/R3_1024, R6_256/R6_512, TRI16/TRI24; 200 triplos, 40 transplantes e quatro fontes por grafo. β U=1, D=C=0,5, t=0,1; κ=0; 0,0125; 0,025; 0,05; 0,1; 0,2. K5 usa os subconjuntos pré-registrados.','\n## Protocolo','[D] Execução autorizada pelo pedido “Oi pode rodar”. Hashes conferidos antes e depois, 79 ramos sintéticos testados, execução `python -I src/rodar_B35.py completo resultados`, seguida do avaliador congelado. BLAS/OMP/MKL limitados a uma thread. Nenhum arquivo congelado foi alterado.','[M] O protocolo declara exploração e fumaça prévias em quase todos os casos; esta execução é confirmação formal, não previsão cega.','\n## Medidas','[M] Frações exata/graduada, controles no campo inteiro, transplante, entropia do vácuo, tempos de chegada, conservação, simetrias, tempo τ, diferença D e razões de parceiros. Dados completos em resultados/ e resumos CSV em tabelas/.','\n## Resultados','\n| Decisão | Resultado |','|---|---|']
lines += [f'| {k} | **{v}** |' for k,v in r['globais'].items()]
lines += ['\n| Grafo | a1 | T2 | T3 | a3 | δ mediana | ΔS/S mediana |','|---|---|---|---|---|---|---|']
for x in rows:lines.append(f"| {x['grafo']} | {x['a1']} | {x['T2']} | {x['T3']} | {x['a3']} | {x['delta_med']:.7g} | {x['dS_rel_med']:.7g} |")
lines += ['\n[M] Escala b1: '+str(b['escala_b1'])+'. Escala b2: '+str(b['escala_b2'])+'. Lei dos parceiros: '+b['lei_parceiros']+'.','\n| κ | b1 | τ | b2 | D |','|---|---|---|---|---|']
for k,v in b['b1'].items():lines.append(f"| {k} | {v['decisao']} | {v['tau']} | {b['b2'][k]['decisao']} | {b['b2'][k]['D']:.9g} |")
lines += ['\n## Controles','[M] Hashes: auditoria/hashes_antes.txt e hashes_depois.txt. Teste sintético: auditoria/teste_avaliador.txt. Cobertura completa: auditoria/cobertura.json. Ambiente e versões: auditoria/ambiente.json e resultados/B35_config.json. Logs: resultados_log.txt e resultados/log_execucao.txt.','\nResumo numérico dos controles:', '```json', (P/'auditoria/controles_resumo.json').read_text(), '```', '\nNotas de tamanho:', '```json',json.dumps(r['notas_tamanho'],ensure_ascii=False,indent=2),'```','\nControle K5:', '```json',json.dumps(b['controle_K5'],ensure_ascii=False,indent=2),'```','\nLema por grafo: '+str({k:v['a1']['lema'] for k,v in r['por_grafo'].items()})+'.','\n## Interpretação','[D] G1 confirma seleção exata somente nos grafos degenerados; os regulares aleatórios dão seleção graduada. G2 restringe a independência ao completo. G2b distingue o vértice escuro do ausente em todos os grafos. G3 favorece ordem por distância de grafo: R3, R6 e TRI são ordenadas, K não tem ordem. G4 apoia o sombreado dinâmico nos parâmetros desta bancada. O protocolo não define um único veredito global para α e β juntos.', '[M] O controle menor R6_256 é PARCIAL em a3, enquanto R6_512 é ORDENADA; isso é reportado, conforme a regra não estrita de tamanho para a3. Todos os controles estritos de tamanho passaram. Execução completa: 504,3 segundos, conforme log.', '[M] As decisões acima são as saídas literais do avaliador congelado. A seleção da carga no vértice não equivale a desligar todas as relações incidentes; o lema distingue vértice sem carga de vértice inteiramente sombreado. A distinção dinâmica de β refere-se a observáveis nas relações remanescentes e aos parâmetros escolhidos.','[H] Identificar o campo com uma boundary holográfica continua sendo hipótese. [?] A bancada não reconstrói geometria, não fornece um dicionário holográfico e não resolve Q11. α é livre/gaussiano em grafos fixos; β contém relações dinâmicas apenas em K3–K5. Precisão dupla e tamanhos finitos limitam as conclusões.','\n## Arquivos e auditoria','ZIP autocontido com pré-registro, código intacto, grafos, fumaça original, entradas originais, resultados, logs, tabelas, figuras, ambiente e manifestos. tools/entregar_B35.py somente organiza e desenha dados após a avaliação; não modifica critérios ou decisões.']
report=P/f'HRF_B35_RELATORIO_{stamp}.md';report.write_text('\n'.join(lines)+'\n')
(P/'LEIA_PRIMEIRO_RESULTADOS.md').write_text(f'# Resultados B35\n\nRelatório: {report.name}\n\n'+json.dumps(r['globais'],ensure_ascii=False,indent=2)+'\n\nAs pastas fumaca/ e entradas/ são antecedentes, não os resultados desta rodada. A rodada completa está em resultados/.\n')
files=[p for p in sorted(P.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256_RESULTADOS.txt']
(P/'MANIFEST_SHA256_RESULTADOS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(P).as_posix()+'\n' for p in files))
archive=pathlib.Path('/workspace')/f'HRF_B35_RESULTADOS_COMPLETOS_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(P.rglob('*')):
  if p.is_file() and '__pycache__' not in p.parts:z.write(p,pathlib.Path('HRF_B35_RESULTADOS')/p.relative_to(P))
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
receipt=dict(archive=str(archive),report=str(report),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)
pathlib.Path('/workspace/HRF_B35_ENTREGA_LOCAL.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps(receipt))
