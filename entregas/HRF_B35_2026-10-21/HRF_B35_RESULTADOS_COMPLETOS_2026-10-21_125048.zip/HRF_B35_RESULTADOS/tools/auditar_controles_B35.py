"""Resume controles existentes nos checkpoints, sem nova simulação."""
import json,pathlib
P=pathlib.Path(__file__).resolve().parents[1]
gs=[json.loads(p.read_text())for p in (P/'resultados').glob('B35a_*.json')]
vs=[r['verif'] for g in gs for r in g['a1'] if 'verif'in r]
as3=[g['a3'][0]for g in gs]
bs=sum([json.loads((P/'resultados'/n).read_text())['casos'] for n in ['B35b1_K4.json','B35b1_K5.json']],[])
s=dict(n_estados_verificados=len(vs),erro_modo_max=max(v['erro_modo']for v in vs),dispersao_freq_max=max(v['dispersao_freq']for v in vs),erro_energia_estado_max=max(abs(v['soma_energia']-1)for v in vs),erro_energia_ola_max=max(abs(a[k]-1)for a in as3 for k in ['soma_energia_0','soma_energia_T']),erro_reducao_vertices_max=max(a['dif_vertices_T']for a in as3),erro_identidade_congelada_max=max(a['dif_K_congelado_vs_removido']for g in gs for a in g['a2']if 'dif_K_congelado_vs_removido'in a),erro_norma_beta_max=max(c['erro_norma']for c in bs),erro_simetria_beta_max=max(c['simetria_BD']for c in bs),gap_beta_min=min(c['gap']for c in bs))
(P/'auditoria/controles_resumo.json').write_text(json.dumps(s,indent=2));print(json.dumps(s))
