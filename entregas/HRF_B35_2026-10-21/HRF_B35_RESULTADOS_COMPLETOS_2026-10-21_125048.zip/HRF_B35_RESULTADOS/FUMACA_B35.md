# FUMAÇA — B35 (a base ativa os GMFt? seleção, independência, ordem e sombreado nos grafos da QG)

**Data:** 21 de outubro de 2026 (America/Sao_Paulo) · Claude (`-clau`)
**Ambiente:** Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, 2 núcleos, 8 GB.
**Para quê:** conferir o código, dimensionar tolerâncias e estimar memória e tempo.
**Como:** antes do código definitivo houve uma exploração (scripts fora do pré-registro) nos tamanhos da rodada e em
tamanhos próximos. Depois veio a fumaça com o código congelado (`python -I src/rodar_B35.py fumaca fumaca`): os tamanhos
de controle, menos triplos, 2 fontes e κ ∈ {0; 0,025; 0,1}.
**Aviso:** os números abaixo antecipam o desfecho provável (protocolo §3).

## 1. Peças conferidas

| Teste | Resultado |
|---|---|
| Frações de carga no campo inteiro × v² (estado estacionário) | diferença 0 (K24, TRI16); dispersão de frequência 0 |
| Soma das energias (vértices + relações) de um quantum | 1 a 6×10⁻¹⁶ (t = 0 e T) |
| Redução da a3 ao espaço dos vértices × campo inteiro (t = T) | ≤ 2,8×10⁻¹⁵ |
| Menor autovalor de K (μ² = 1) | 1,000 (a banda plana fica em ω = μ) |
| Identidade congelada (relações de B desligadas × G−B) | diferença 0 em todos os triplos |
| Hamiltoniano β simétrico; setores de K_3, K_4 e K_5 | assimetria 0; M = 0: 20, 924 e 184 756 estados; M = +1: 15, 792 e 167 960 |
| β: sentidos m = +1 × m = −1 | τ idênticos em todos os κ; simetria B↔D ≤ 3×10⁻¹²; norma ≤ 10⁻¹⁴ |
| Teste sintético do avaliador | 79 ramos, todos ok |

## 2. Exploração antes do congelamento (decide parâmetros e tolerâncias)

**β, salto t.** Com t = 0,25, o estado fundamental de K_5 em κ = 0 tem E₀ = −1,38: é o bloco "todas as relações
ligadas", um condensado de cordas. O de K_4 continua no vazio (E₀ = 0). Com t = 0,1, o bloco todo ligado de K_5 vai para
E = 7,44 e o vazio vestido volta a ser o fundamental. **Fixado t = 0,1.**

**β com t = 0,1 (exploração, K_4):**

| κ | E₀ | ⟨n_ligadas⟩ nas relações de B (vácuo) | τ de seleção |
|---|---|---|---|
| 0 | 0 | 0 | não cruza até 30 000 |
| 0,0125 | −9,4×10⁻⁴ | 4,7×10⁻⁴ | 7 053,5 |
| 0,025 | −3,7×10⁻³ | 1,9×10⁻³ | 1 766,5 |
| 0,05 | −1,5×10⁻² | 7,4×10⁻³ | 441,0 |
| 0,1 | −5,9×10⁻² | 2,9×10⁻² | 111,0 |
| 0,2 | −2,3×10⁻¹ | 1,1×10⁻¹ | 24,9 |

Inclinação de ln τ entre 0,0125 e 0,05: −2,0. K_5: τ = 111,25 (κ = 0,1) e 25,0 (κ = 0,2), praticamente iguais a K_4.

**β, vácuo com B presente × B removido (exploração).** D = 0 em κ = 0. Para κ > 0, D vale 2,2×10⁻⁹, 3,5×10⁻⁸, 5,6×10⁻⁷,
8,4×10⁻⁶ e 1,1×10⁻⁴ para κ = 0,0125 a 0,2; a inclinação entre 0,0125 e 0,05 é 3,99. A razão ⟨M_AC²⟩ é 2,0005 a 2,008 em
K_4/K_3 e 1,5004 a 1,506 em K_5/K_4. ⟨P_AC⟩ quase não muda (1,5618×10⁻⁴ nos dois em κ = 0,0125): o que muda é a
**flutuação** do campo na relação, não a chance de ela estar ligada.

**α, tamanhos da rodada (exploração com os mesmos geradores):**
- a1: K40 com fração exata 1,00; TRI24 com 1,00 (69 de dimensão máxima); R3_1024 com graduada 1,00 (contraste mediano
  4×10⁴); R6_512 com graduada 1,00.
- a2/T2: K40 com δ = 0 (≤ 8×10⁻¹⁶).
- a3: R3_1024 com médias de 0,69; 2,64; 4,14; 5,53; 7,33; 9,57; 11,48 nas cascas 1–7 (ρ ordinal 0,80 a 0,81); TRI24 com
  10 cascas, 1,12 a 15,88 (ρ 0,967); R6_512 com 3 cascas e ρ ordinal 0,47 a 0,53 (com postos médios deve subir).

## 3. Fumaça (código congelado, tamanhos de controle)

| Grafo | a1 | f_exata / f_grad | dim. máx. | carga de B (máx.) | energia nas relações de B (mediana) | ΔS₂ circ. da estrela de B / de A |
|---|---|---|---|---|---|---|
| K24 | EXATA | 1,00 / 0 | 23 | 10⁻³¹ | 0,024 | 0,194 / 0,691 |
| R3_512 | GRADUADA | 0 / 1,00 | 1 | 2,3×10⁻⁶ | 0,0019 | 0,0059 / 0,0086 |
| R6_256 | GRADUADA | 0 / 0,99 | 1 | 2,2×10⁻⁵ | 0,0030 | 0,012 / 0,022 |
| TRI16 | EXATA | 1,00 / 0 | 45 | 7×10⁻³¹ | 0,039 | 0,145 / 0,168 |

Lema da vizinhança CONFIRMADO nos quatro. Em K24, com B exatamente sem carga, as relações de B levam 2,4% da energia e o
ΔS₂ da estrela de B é 0,19 nats: B está **atravessado**. Circular × linear: até 0,009 nats (K24).

| Grafo | T2 (δ mediano; faixa) | T3 (\|ΔS\|/S mediano; \|ΔS\|) | a3 |
|---|---|---|---|
| K24 | INDEPENDENTE (3×10⁻¹⁶) | DISTINGUIVEL (0,049; 0,24 nats) | SEM_ORDEM (1 casca; t = 0,72 em todos) |
| R3_512 | DEPENDENTE (0,53; 0,10–0,70) | DISTINGUIVEL (0,31; 0,15) | ORDENADA (7 cascas crescentes; ρ 0,78 e 0,82) |
| R6_256 | DEPENDENTE (0,44; 0,22–3,5) | DISTINGUIVEL (0,15; 0,23) | PARCIAL (3 e 2 cascas; ρ 0,76 e 0,65) |
| TRI16 | DEPENDENTE (0,83; 0,68–0,83) | DISTINGUIVEL (0,21; 0,26) | ORDENADA (6 cascas; 1,12 → 8,92; ρ 0,97) |

**β na fumaça:**
- K_4: κ = 0 PERSISTENTE; κ = 0,025 τ = 1 766,5; κ = 0,1 τ = 111,0 (os dois sentidos iguais);
- b2: κ = 0 IDENTICO (D = 0); κ = 0,025 D = 3,5×10⁻⁸, razão 2,0005; κ = 0,1 D = 8,4×10⁻⁶, razão 2,008;
- K_5/K_4 em κ = 0,025: razão 1,5004;
- K_5 dinâmico em κ = 0,2: τ = 25,0.
- As escalas ficam INSUFICIENTE e G4 fica INCONCLUSIVO na fumaça, como esperado (faltam κ).

**Globais da fumaça:** G1 EXATA_SO_COM_DEGENERESCENCIA · G2 INDEPENDENCIA_SO_NO_COMPLETO · G2b
ESCURO_DISTINGUIVEL_DO_AUSENTE · G3 ORDEM_POR_DISTANCIA_DE_GRAFO · G4 INCONCLUSIVO.

## 4. Memória e tempo

Fumaça: 87 s, pico de 0,55 GB. A K_5 dinâmica é o caso mais lento: 54 s em κ = 0,2 e cerca de 230 s em κ = 0,1
(exploração). Rodada estimada: 12–20 min e ≤ 2 GB.
