"""B35 — grafos da Quantum Graphity congelados (retratos): completo K_N, regular aleatório (d = 3 e 6) e quase-rede
triangular em toro. Os vértices representam GMFt (sem grau de liberdade próprio); as arestas são as relações ligadas.
Os grafos aleatórios usados na rodada estão congelados em dados/grafos_B35.json (gerados por gerar_grafos_B35.py)."""
import json, os
from collections import deque
import numpy as np


def completo(N):
    return [(i, j) for i in range(N) for j in range(i + 1, N)]


def tri_toro(L):
    """rede triangular L × L com contorno periódico; vizinhos (±1,0), (0,±1), (1,−1), (−1,1); grau 6."""
    idx = lambda i, j: (i % L) * L + (j % L)
    E = set()
    for i in range(L):
        for j in range(L):
            for di, dj in ((1, 0), (0, 1), (1, -1)):
                a, b = idx(i, j), idx(i + di, j + dj)
                E.add((min(a, b), max(a, b)))
    return sorted(E)


def regular_aleatorio(N, d, seed):
    """modelo de configuração com rejeição (grafo simples e conexo). Só é usado para GERAR os grafos congelados."""
    rng = np.random.default_rng(seed)
    for tent in range(100000):
        stubs = np.repeat(np.arange(N), d)
        rng.shuffle(stubs)
        a, b = stubs[0::2], stubs[1::2]
        if np.any(a == b):
            continue
        e = set(zip(np.minimum(a, b).tolist(), np.maximum(a, b).tolist()))
        if len(e) < len(a):
            continue
        E = sorted(e)
        if conexo(N, E):
            return [(int(x), int(y)) for x, y in E], tent
    raise RuntimeError('sem grafo simples conexo')


def vizinhos(N, E):
    viz = [[] for _ in range(N)]
    for a, b in E:
        viz[a].append(b); viz[b].append(a)
    return viz


def distancias(N, E, s, viz=None):
    viz = viz if viz is not None else vizinhos(N, E)
    d = -np.ones(N, int); d[s] = 0
    q = deque([s])
    while q:
        u = q.popleft()
        for w in viz[u]:
            if d[w] < 0:
                d[w] = d[u] + 1; q.append(w)
    return d


def conexo(N, E):
    return bool(np.all(distancias(N, E, 0) >= 0))


def incidencia(N, E):
    """R (N × E) sem sinal: R[a, e] = 1 se a é ponta da relação e."""
    R = np.zeros((N, len(E)))
    for k, (a, b) in enumerate(E):
        R[a, k] = 1.0; R[b, k] = 1.0
    return R


def sem_vertice(N, E, B):
    """grafo com o vértice B e todas as suas relações retirados; devolve (N−1, E', mapa antigo→novo)."""
    keep = [x for x in range(N) if x != B]
    pos = {x: i for i, x in enumerate(keep)}
    E2 = [(pos[a], pos[b]) for a, b in E if a != B and b != B]
    return N - 1, E2, pos


def triplos(N, E, n, seed):
    """n triplos (A, B, C) com B vizinho comum de A e de C (B 'entre' A e C no grafo)."""
    viz = vizinhos(N, E)
    rng = np.random.default_rng(seed)
    out = []
    tent = 0
    while len(out) < n and tent < 100 * n:
        tent += 1
        B = int(rng.integers(N))
        if len(viz[B]) < 2:
            continue
        A, C = rng.choice(np.array(viz[B]), 2, replace=False)
        out.append((int(A), B, int(C)))
    return out


def carregar(caminho_dados, nome):
    with open(caminho_dados) as f:
        g = json.load(f)[nome]
    return g['N'], [tuple(e) for e in g['E']], g


GRAFOS = {
    # nome: (tipo, parâmetros)
    'K24': ('completo', dict(N=24)), 'K40': ('completo', dict(N=40)),
    'R3_512': ('regular', dict(N=512, d=3, seed=3501)), 'R3_1024': ('regular', dict(N=1024, d=3, seed=3502)),
    'R6_256': ('regular', dict(N=256, d=6, seed=3503)), 'R6_512': ('regular', dict(N=512, d=6, seed=3504)),
    'TRI16': ('tri', dict(L=16)), 'TRI24': ('tri', dict(L=24)),
}
