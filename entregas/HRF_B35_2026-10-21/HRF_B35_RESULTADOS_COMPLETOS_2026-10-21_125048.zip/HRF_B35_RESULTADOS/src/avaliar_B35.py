"""B35 — avaliador congelado. Uso: python -I src/avaliar_B35.py <pasta_resultados>
Lê os checkpoints e aplica as regras do protocolo (§7). Grava <pasta>/avaliacao_B35.json."""
import sys, os, json
import numpy as np

PARES = [('K', 'K40', 'K24'), ('R3', 'R3_1024', 'R3_512'), ('R6', 'R6_512', 'R6_256'), ('TRI', 'TRI24', 'TRI16')]
LIT = 0.5
CONTRASTE = 100.0
KAPS_ESCALA = [0.0125, 0.025, 0.05]
RUINS = ('INCONCLUSIVO', 'INSUFICIENTE', None)


def ler(p, nome):
    f = os.path.join(p, nome)
    if not os.path.exists(f):
        return None
    with open(f) as h:
        return json.load(h)


def _ranks(x):
    o = np.argsort(x, kind='stable')
    r = np.empty(len(x)); r[o] = np.arange(len(x), dtype=float)
    xs = x[o]; i = 0
    while i < len(xs):
        j = i
        while j + 1 < len(xs) and xs[j + 1] == xs[i]:
            j += 1
        if j > i:
            r[o[i:j + 1]] = 0.5 * (i + j)
        i = j + 1
    return r


def spearman(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float)
    rx, ry = _ranks(x), _ranks(y)
    if np.std(rx) == 0 or np.std(ry) == 0:
        return float('nan')
    return float(np.corrcoef(rx, ry)[0, 1])


def inclinacao(x, y):
    return float(np.polyfit(np.log(x), np.log(y), 1)[0])


# ---------------- a1 ----------------
def avaliar_a1(g, n_min=50):
    a1 = g['a1']
    n = len(a1)
    motivos = []
    ver = [r['verif'] for r in a1 if 'verif' in r]
    for v in ver:
        if not (v['erro_modo'] <= 1e-8 and v['dispersao_freq'] <= 1e-8 and abs(v['soma_energia'] - 1) <= 1e-8):
            motivos.append('verificação do estado no campo inteiro falhou'); break
    plenos = [v for v in ver if v['carga_B'] <= 1e-12 and v['rel_estrela_B'] <= 1e-12]
    lema = 'CONFIRMADO' if not plenos else 'VIOLADO'
    fe = float(np.mean([r['exato_Nmin'] >= LIT for r in a1])) if n else 0.0
    fg = float(np.mean([(r['exato_Nmin'] < LIT) and r['grad_contraste'] >= CONTRASTE and r['grad_Nmin'] >= LIT
                        for r in a1])) if n else 0.0
    if motivos:
        dec = 'INCONCLUSIVO'
    elif n < n_min:
        dec = 'INSUFICIENTE'
    elif fe >= 0.9:
        dec = 'EXATA'
    elif fe + fg >= 0.9:
        dec = 'GRADUADA'
    elif fe + fg >= 0.1:
        dec = 'RARA'
    else:
        dec = 'SEM_SELECAO'
    resumo = dict(n_triplos=n, frac_exata=fe, frac_graduada=fg, dim_max=g['dim_max'], n_autoespacos=g['n_autoespacos'],
                  lema=lema, n_verif=len(ver))
    if ver:
        resumo.update(carga_B_max=max(v['carga_B'] for v in ver), rel_estrela_B_med=float(np.median([v['rel_estrela_B'] for v in ver])),
                      dS2circ_B_med=float(np.median([v['dS2circ_B'] for v in ver])),
                      dS2circ_A_med=float(np.median([v['dS2circ_A'] for v in ver])),
                      dif_circ_lin_max=float(max(abs(v['dS2circ_' + k] - v['dS2lin_' + k]) for v in ver for k in 'ABC')))
    return dict(decisao=dec, motivos=motivos, **resumo)


# ---------------- a2 ----------------
def avaliar_a2(g, n_min=15):
    val = [r for r in g['a2'] if r.get('tipo') not in (None, 'nenhum')]
    motivos = []
    if any(r['dif_K_congelado_vs_removido'] > 1e-12 for r in val):
        motivos.append('identidade congelado-desligado = removido falhou')
    d = [0.5 * (abs(r['media_A_semB'] - r['share_A']) / r['share_A'] + abs(r['media_C_semB'] - r['share_C']) / r['share_C'])
         for r in val]
    rel = [abs(r['S_presente'] - r['S_removido']) / r['S_presente'] for r in val]
    if len(val) < n_min:
        t2 = 'INSUFICIENTE'; t3 = 'INSUFICIENTE'
    else:
        md = float(np.median(d))
        t2 = 'INDEPENDENTE' if md <= 0.01 else ('FRACA' if md <= 0.2 else 'DEPENDENTE')
        mr = float(np.median(rel))
        t3 = 'DISTINGUIVEL' if mr >= 1e-3 else ('INDISTINGUIVEL' if mr <= 1e-10 else 'INTERMEDIARIO')
        if motivos:
            t3 = 'INCONCLUSIVO'
    return dict(decisao_T2=t2, decisao_T3=t3, motivos=motivos, n=len(val),
                delta_med=float(np.median(d)) if d else None, delta_min=float(min(d)) if d else None,
                delta_max=float(max(d)) if d else None,
                dS_rel_med=float(np.median(rel)) if rel else None,
                dS_abs_med=float(np.median([abs(r['S_presente'] - r['S_removido']) for r in val])) if val else None)


# ---------------- a3 ----------------
def corte(g, reg):
    if g['tipo'] == 'completo':
        return 1
    if g['tipo'] == 'tri':
        return g['L'] // 2 - 2
    N = g['N']; ball = reg['bola']
    ks = [k for k in range(1, len(ball)) if ball[k] <= N / 2]
    return max(ks) if ks else 1


def fonte_a3(g, reg):
    d = np.array(reg['d']); t = np.array([np.nan if x is None else x for x in reg['t_chegada']], float)
    dc = corte(g, reg)
    m = (d >= 1) & (d <= dc)
    nan_frac = float(np.mean(np.isnan(t[m]))) if m.any() else 1.0
    mm = m & ~np.isnan(t)
    sh = [k for k in sorted(set(d[mm].tolist())) if np.sum(mm & (d == k)) >= 3]
    tm = [float(np.mean(t[mm & (d == k)])) for k in sh]
    mono = all(tm[i + 1] > tm[i] for i in range(len(tm) - 1)) if len(tm) >= 2 else False
    rho = spearman(t[mm], d[mm]) if len(sh) >= 2 else float('nan')
    spread = float(np.std(t[mm]) / reg['T']) if mm.any() else float('nan')
    return dict(s=reg['s'], d_corte=dc, n_an=int(mm.sum()), nan_frac=nan_frac, cascas=sh, t_med=tm, mono=bool(mono),
                rho=rho, spread=spread)


def avaliar_a3(g):
    fs = [fonte_a3(g, r) for r in g['a3']]
    r0 = g['a3'][0]
    motivos = []
    if 'soma_energia_0' in r0:
        if not (abs(r0['soma_energia_0'] - 1) <= 1e-8 and abs(r0['soma_energia_T'] - 1) <= 1e-8 and r0['dif_vertices_T'] <= 1e-8):
            motivos.append('conferência da redução ao espaço dos vértices falhou')
    rhos = [f['rho'] for f in fs if not np.isnan(f['rho'])]
    rho_med = float(np.median(rhos)) if rhos else float('nan')
    if motivos:
        dec = 'INCONCLUSIVO'
    elif any(f['n_an'] < 10 or f['nan_frac'] > 0.1 for f in fs):
        dec = 'INSUFICIENTE'
    elif all(len(f['cascas']) == 1 and f['spread'] <= 0.02 for f in fs):
        dec = 'SEM_ORDEM'
    elif all(len(f['cascas']) >= 3 and f['mono'] for f in fs) and rho_med >= 0.6:
        dec = 'ORDENADA'
    elif all(len(f['cascas']) >= 2 and f['mono'] for f in fs):
        dec = 'PARCIAL'
    elif (not np.isnan(rho_med)) and rho_med < 0.3 and not all(f['mono'] for f in fs):
        dec = 'SEM_ORDEM'
    else:
        dec = 'INTERMEDIARIO'
    return dict(decisao=dec, motivos=motivos, rho_med=rho_med, fontes=fs)


# ---------------- pares de tamanho ----------------
def com_controle(res_g, res_c, chave, estrito=True):
    """decisão no tamanho maior; com estrito=True o menor tem de dar a mesma classe (senão INCONCLUSIVO); com
    estrito=False (a3: o número de cascas antes da saturação cresce com N por construção) o menor é só reportado.
    Sem o maior (fumaça), usa o menor e marca 'sem_controle_de_tamanho'."""
    if res_g is None and res_c is None:
        return dict(decisao=None, nota='ausente')
    if res_g is None:
        return dict(decisao=res_c[chave], nota='sem_controle_de_tamanho (só o tamanho menor)')
    if res_c is None:
        return dict(decisao=res_g[chave], nota='sem_controle_de_tamanho (só o tamanho maior)')
    if res_g[chave] == res_c[chave]:
        return dict(decisao=res_g[chave], nota='controle de tamanho ok')
    if not estrito:
        return dict(decisao=res_g[chave], nota='tamanho menor (reportado): %s' % res_c[chave])
    if res_g[chave] in RUINS:
        return dict(decisao=res_g[chave], nota='decisão ruim no tamanho maior')
    return dict(decisao='INCONCLUSIVO', nota='controle de tamanho: %s × %s' % (res_g[chave], res_c[chave]))


def global_a1(d):
    v = [d[k] for k in ('K', 'R3', 'R6', 'TRI')]
    if any(x in RUINS for x in v):
        return 'INCONCLUSIVO'
    if d['K'] == 'EXATA' and d['TRI'] == 'EXATA' and d['R3'] in ('GRADUADA', 'RARA') and d['R6'] in ('GRADUADA', 'RARA'):
        return 'EXATA_SO_COM_DEGENERESCENCIA'
    if all(x == 'EXATA' for x in v):
        return 'EXATA_GERAL'
    if all(x == 'SEM_SELECAO' for x in v):
        return 'SEM_SELECAO_GERAL'
    return 'MISTO'


def global_a2(d2, d3):
    v = [d2[k] for k in ('K', 'R3', 'R6', 'TRI')]
    if any(x in RUINS for x in v):
        g2 = 'INCONCLUSIVO'
    elif d2['K'] == 'INDEPENDENTE' and all(d2[k] in ('FRACA', 'DEPENDENTE') for k in ('R3', 'R6', 'TRI')):
        g2 = 'INDEPENDENCIA_SO_NO_COMPLETO'
    elif all(x == 'INDEPENDENTE' for x in v):
        g2 = 'INDEPENDENCIA_GERAL'
    elif not any(x == 'INDEPENDENTE' for x in v):
        g2 = 'DEPENDENCIA_GERAL'
    else:
        g2 = 'MISTO'
    w = [d3[k] for k in ('K', 'R3', 'R6', 'TRI')]
    if any(x in RUINS for x in w):
        g3 = 'INCONCLUSIVO'
    elif all(x == 'DISTINGUIVEL' for x in w):
        g3 = 'ESCURO_DISTINGUIVEL_DO_AUSENTE'
    elif all(x == 'INDISTINGUIVEL' for x in w):
        g3 = 'ESCURO_IGUAL_AO_AUSENTE'
    else:
        g3 = 'MISTO'
    return g2, g3


def global_a3(d):
    v = [d[k] for k in ('K', 'R3', 'R6', 'TRI')]
    if any(x in RUINS for x in v):
        return 'INCONCLUSIVO'
    if d['TRI'] != 'ORDENADA':
        return 'SEM_ORDEM_NA_REDE'
    if d['K'] == 'SEM_ORDEM' and (d['R3'] == 'ORDENADA' or d['R6'] == 'ORDENADA'):
        return 'ORDEM_POR_DISTANCIA_DE_GRAFO'
    if d['K'] == 'SEM_ORDEM':
        return 'ORDEM_SO_COM_GEOMETRIA'
    return 'MISTO'


# ---------------- β ----------------
def avaliar_b1(casos):
    por_k = {}
    for c in casos:
        por_k.setdefault(c['kap'], {})[c['sinal']] = c
    out = {}
    for k, cs in sorted(por_k.items()):
        mot = []
        tps = [cs[s]['tau'] for s in cs]
        if len(cs) == 2:
            a, b = tps
            if (a is None) != (b is None) or (a is not None and abs(a - b) > 0.5):
                mot.append('sentidos do saca-rolha discordam')
        for c in cs.values():
            if c['simetria_BD'] > 1e-9 or c['erro_norma'] > 1e-9:
                mot.append('simetria B↔D ou norma'); break
            if c['gap'] < 0.5 or c['E0'] > 1e-12 or c['nON_vac'] > 2 * c['n'] * (c['n'] - 1) / 2 * c['kap'] ** 2 + 1e-12:
                mot.append('vácuo não é o vazio vestido'); break
        tau = cs[1]['tau'] if 1 in cs else tps[0]
        if mot:
            dec = 'INCONCLUSIVO'
        elif tau is None:
            dec = 'PERSISTENTE'
        elif tau > 5.0:
            dec = 'TRANSITORIA'
        else:
            dec = 'SEM_SELECAO'
        out[k] = dict(decisao=dec, tau=tau, motivos=mot, rB_vac=cs[1]['rB_vac'] if 1 in cs else None)
    return out


def escala(d, chave_val, cls_ok, lo, hi, nomes):
    ks = [k for k in KAPS_ESCALA if k in d]
    if len(ks) < 3 or any(d[k]['decisao'] != cls_ok for k in ks):
        return dict(decisao='INSUFICIENTE', inclinacao=None)
    s = inclinacao(ks, [d[k][chave_val] for k in ks])
    return dict(decisao=nomes[0] if lo <= s <= hi else nomes[1], inclinacao=s)


def avaliar_b2(lista):
    out = {}
    for r in lista:
        mot = []
        if r['gap_presente'] < 0.5:
            mot.append('gap do vácuo')
        D = r['D']; rM = r['razao_M2_AC']
        if mot:
            dec = 'INCONCLUSIVO'
        elif D <= 1e-13:
            dec = 'IDENTICO'
        elif D >= 1e-12 and rM is not None and abs(rM - 1) >= 0.05:
            dec = 'DISTINGUIVEL'
        else:
            dec = 'INTERMEDIARIO'
        out[r['kap']] = dict(decisao=dec, D=D, razao_M2_AC=rM, motivos=mot)
    return out


def lei_parceiros(b2, b2_5):
    """[H] a flutuação do campo na relação A–C cresce com o número de relações parceiras: razão (n−2)/(n−3) quando B é
    removido de K_n (2 em K_4/K_3; 1,5 em K_5/K_4), no menor κ."""
    k = 0.0125
    if k in b2 and k in b2_5 and b2[k]['razao_M2_AC'] and b2_5[k]['razao_M2_AC']:
        ok = abs(b2[k]['razao_M2_AC'] - 2) <= 0.02 and abs(b2_5[k]['razao_M2_AC'] - 1.5) <= 0.02
        return 'CONTAGEM_DE_PARCEIROS' if ok else 'OUTRA'
    return 'INSUFICIENTE'


def controle_K5(b1, casos5):
    out = {}
    for c in casos5:
        t4 = b1.get(c['kap'], {}).get('tau')
        ok = (t4 is not None and c['tau'] is not None and abs(c['tau'] - t4) / t4 <= 0.2) or (t4 is None and c['tau'] is None)
        out[c['kap']] = dict(tau_K5=c['tau'], tau_K4=t4, leitura='CONSISTENTE' if ok else 'DIFERENTE')
    return out


def global_b(b1, esc1, b2):
    kpos = [k for k in b1 if k > 0]
    req = [0.0] + KAPS_ESCALA
    if any(k not in b1 or k not in b2 for k in req) or any(b1[k]['decisao'] == 'INCONCLUSIVO' for k in b1) or \
            any(b2[k]['decisao'] == 'INCONCLUSIVO' for k in b2) or esc1['decisao'] == 'INSUFICIENTE':
        return 'INCONCLUSIVO'
    if kpos and (all(b1[k]['decisao'] == 'PERSISTENTE' for k in kpos) or all(b2[k]['decisao'] == 'IDENTICO' for k in kpos if k in b2)):
        return 'REFUTADO'
    if b1[0.0]['decisao'] == 'PERSISTENTE' and b2[0.0]['decisao'] == 'IDENTICO' and \
            all(b1[k]['decisao'] == 'TRANSITORIA' and b2[k]['decisao'] == 'DISTINGUIVEL' for k in KAPS_ESCALA) and \
            esc1['decisao'] == 'ESCALA_K2':
        return 'APOIADO'
    return 'PARCIAL'


def avaliar(pasta):
    ga = {}
    for _, gnome, cnome in PARES:
        for nm in (gnome, cnome):
            x = ler(pasta, 'B35a_%s.json' % nm)
            if x is not None:
                ga[nm] = dict(a1=avaliar_a1(x), a2=avaliar_a2(x), a3=avaliar_a3(x))
    dec = dict(a1={}, a2_T2={}, a2_T3={}, a3={})
    notas = {}
    for chave, gnome, cnome in PARES:
        G, Cc = ga.get(gnome), ga.get(cnome)
        r = com_controle(G and G['a1'], Cc and Cc['a1'], 'decisao'); dec['a1'][chave] = r['decisao']; notas['a1_' + chave] = r['nota']
        r = com_controle(G and G['a2'], Cc and Cc['a2'], 'decisao_T2'); dec['a2_T2'][chave] = r['decisao']; notas['a2T2_' + chave] = r['nota']
        r = com_controle(G and G['a2'], Cc and Cc['a2'], 'decisao_T3'); dec['a2_T3'][chave] = r['decisao']; notas['a2T3_' + chave] = r['nota']
        r = com_controle(G and G['a3'], Cc and Cc['a3'], 'decisao', estrito=False); dec['a3'][chave] = r['decisao']; notas['a3_' + chave] = r['nota']
    g1 = global_a1(dec['a1']); g2, g2b = global_a2(dec['a2_T2'], dec['a2_T3']); g3 = global_a3(dec['a3'])
    bb1 = ler(pasta, 'B35b1_K4.json'); bb5 = ler(pasta, 'B35b1_K5.json'); bb2 = ler(pasta, 'B35b2.json')
    b1 = avaliar_b1(bb1['casos']) if bb1 else {}
    esc1 = escala(b1, 'tau', 'TRANSITORIA', -2.3, -1.7, ('ESCALA_K2', 'OUTRA_ESCALA')) if b1 else dict(decisao='INSUFICIENTE', inclinacao=None)
    b2 = avaliar_b2(bb2['K4']) if bb2 else {}
    esc2 = escala(b2, 'D', 'DISTINGUIVEL', 3.6, 4.4, ('VIRTUAL_K4', 'OUTRA_ESCALA')) if b2 else dict(decisao='INSUFICIENTE', inclinacao=None)
    b2_5 = avaliar_b2(bb2['K5']) if bb2 else {}
    parc = lei_parceiros(b2, b2_5)
    k5 = controle_K5(b1, bb5['casos']) if bb5 else {}
    g4 = global_b(b1, esc1, b2) if b1 and b2 else 'INCONCLUSIVO'
    return dict(por_grafo=ga, decisoes=dec, notas_tamanho=notas,
                globais=dict(G1_selecao=g1, G2_independencia=g2, G2b_escuro_vs_ausente=g2b, G3_ordem=g3, G4_sombreado_dinamico=g4),
                beta=dict(b1={str(k): v for k, v in b1.items()}, escala_b1=esc1, b2={str(k): v for k, v in b2.items()},
                          escala_b2=esc2, b2_K5={str(k): v for k, v in b2_5.items()}, lei_parceiros=parc, controle_K5=
                          {str(k): v for k, v in k5.items()}))


def _json(o):
    if isinstance(o, dict):
        return {str(k): _json(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_json(v) for v in o]
    if isinstance(o, (np.floating,)):
        return float(o)
    if isinstance(o, (np.integer,)):
        return int(o)
    if isinstance(o, float) and np.isnan(o):
        return None
    return o


if __name__ == '__main__':
    p = sys.argv[1]
    r = avaliar(p)
    with open(os.path.join(p, 'avaliacao_B35.json'), 'w') as f:
        json.dump(_json(r), f, indent=1, ensure_ascii=False)
    print(json.dumps(_json(dict(decisoes=r['decisoes'], globais=r['globais'], notas=r['notas_tamanho'])), indent=1, ensure_ascii=False))
    print(json.dumps(_json(r['beta']), indent=1, ensure_ascii=False))
