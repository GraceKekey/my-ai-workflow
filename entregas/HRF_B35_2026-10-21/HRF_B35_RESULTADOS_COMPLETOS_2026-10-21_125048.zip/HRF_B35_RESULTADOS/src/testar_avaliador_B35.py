"""B35 — teste sintético do avaliador congelado: cada ramo de decisão é atingido por dados fabricados.
Uso: python -I src/testar_avaliador_B35.py   (sai com código 1 se algum ramo não bater)."""
import sys, os
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import numpy as np
import avaliar_B35 as AV

FALHAS = []
N_OK = [0]


def confere(nome, obtido, esperado):
    ok = obtido == esperado
    print('%-62s %-34s %s' % (nome, obtido, 'ok' if ok else 'FALHOU (esperado %s)' % esperado))
    N_OK[0] += ok
    if not ok:
        FALHAS.append(nome)


# ---------------- a1 ----------------
def g_a1(n=100, fe=1.0, fg=0.0, verif_ok=True, pleno=False):
    a1 = []
    for i in range(n):
        ex = (i < round(fe * n))
        gr = (not ex) and (i < round((fe + fg) * n))
        r = dict(exato_Nmin=12.0 if ex else 0.0, grad_contraste=1e3 if gr else 5.0, grad_Nmin=1.0 if gr else 0.2)
        if i < 5:
            r['verif'] = dict(erro_modo=0.0 if verif_ok else 1e-3, dispersao_freq=0.0, soma_energia=1.0, carga_A=0.5,
                              carga_B=0.0, carga_C=0.5, rel_estrela_B=0.0 if pleno else 0.02, rel_AB=0.01,
                              dS2circ_A=0.6, dS2circ_B=0.2, dS2circ_C=0.6, dS2lin_A=0.6, dS2lin_B=0.2, dS2lin_C=0.6)
        a1.append(r)
    return dict(a1=a1, dim_max=5, n_autoespacos=3)


confere('a1 exata', AV.avaliar_a1(g_a1(fe=0.95))['decisao'], 'EXATA')
confere('a1 graduada', AV.avaliar_a1(g_a1(fe=0.3, fg=0.65))['decisao'], 'GRADUADA')
confere('a1 rara', AV.avaliar_a1(g_a1(fe=0.0, fg=0.4))['decisao'], 'RARA')
confere('a1 sem seleção', AV.avaliar_a1(g_a1(fe=0.0, fg=0.05))['decisao'], 'SEM_SELECAO')
confere('a1 insuficiente', AV.avaliar_a1(g_a1(n=30))['decisao'], 'INSUFICIENTE')
confere('a1 inconclusivo (verificação)', AV.avaliar_a1(g_a1(verif_ok=False))['decisao'], 'INCONCLUSIVO')
confere('a1 lema confirmado', AV.avaliar_a1(g_a1())['lema'], 'CONFIRMADO')
confere('a1 lema violado', AV.avaliar_a1(g_a1(pleno=True))['lema'], 'VIOLADO')


# ---------------- a2 ----------------
def g_a2(n=40, delta=0.0, rel=0.1, ident=0.0):
    out = []
    for i in range(n):
        out.append(dict(tipo='exato', share_A=0.5, share_C=0.5, media_A_semB=0.5 * (1 + delta), media_C_semB=0.5 * (1 + delta),
                        S_presente=1.0, S_removido=1.0 - rel, dif_K_congelado_vs_removido=ident))
    return dict(a2=out)


confere('a2 T2 independente', AV.avaliar_a2(g_a2(delta=0.0))['decisao_T2'], 'INDEPENDENTE')
confere('a2 T2 fraca', AV.avaliar_a2(g_a2(delta=0.1))['decisao_T2'], 'FRACA')
confere('a2 T2 dependente', AV.avaliar_a2(g_a2(delta=0.5))['decisao_T2'], 'DEPENDENTE')
confere('a2 T2 insuficiente', AV.avaliar_a2(g_a2(n=10))['decisao_T2'], 'INSUFICIENTE')
confere('a2 T3 distinguível', AV.avaliar_a2(g_a2(rel=0.05))['decisao_T3'], 'DISTINGUIVEL')
confere('a2 T3 indistinguível', AV.avaliar_a2(g_a2(rel=0.0))['decisao_T3'], 'INDISTINGUIVEL')
confere('a2 T3 intermediário', AV.avaliar_a2(g_a2(rel=1e-6))['decisao_T3'], 'INTERMEDIARIO')
confere('a2 T3 inconclusivo (identidade)', AV.avaliar_a2(g_a2(rel=0.05, ident=1e-6))['decisao_T3'], 'INCONCLUSIVO')


# ---------------- a3 ----------------
def g_a3(tipo='regular', nsh=5, mono=True, ruido=0.0, nfontes=2, nan=0.0, soma=1.0, n_por=20, plano=False, seed=0):
    rng = np.random.default_rng(seed)
    N = 1 + nsh * n_por + 400
    regs = []
    for j in range(nfontes):
        d = [0] + [k for k in range(1, nsh + 1) for _ in range(n_por)] + [nsh + 1] * 400
        t = []
        for x in d:
            if x == 0:
                t.append(0.0)
            elif plano:
                t.append(0.7)
            else:
                base = 1.5 * x if mono else (1.5 * x if x % 2 else 1.5 * x - 4.0)
                t.append(float(base + ruido * rng.standard_normal()))
        t = [None if (i > 0 and i <= nan * len(t)) else v for i, v in enumerate(t)]
        bola = [int(np.sum(np.array(d) <= k)) for k in range(nsh + 2)]
        r = dict(s=0, T=20.0, d=d, t_chegada=t, bola=bola)
        if j == 0:
            r.update(soma_energia_0=soma, soma_energia_T=1.0, dif_vertices_T=0.0)
        regs.append(r)
    g = dict(tipo=tipo, N=N, a3=regs)
    if tipo == 'tri':
        g['L'] = 2 * (nsh + 2)
    return g


confere('a3 ordenada', AV.avaliar_a3(g_a3())['decisao'], 'ORDENADA')
confere('a3 parcial (2 cascas)', AV.avaliar_a3(g_a3(nsh=2))['decisao'], 'PARCIAL')
confere('a3 parcial (ρ baixo, monótona)', AV.avaliar_a3(g_a3(nsh=4, ruido=5.0, n_por=300, seed=3))['decisao'], 'PARCIAL')
confere('a3 sem ordem (uma casca, plana)', AV.avaliar_a3(dict(g_a3(tipo='completo', nsh=1, plano=True)))['decisao'], 'SEM_ORDEM')
confere('a3 sem ordem (ρ < 0,3 não monótona)', AV.avaliar_a3(g_a3(nsh=4, ruido=40.0, seed=5, mono=False))['decisao'], 'SEM_ORDEM')
confere('a3 intermediário', AV.avaliar_a3(g_a3(nsh=4, mono=False))['decisao'], 'INTERMEDIARIO')
confere('a3 insuficiente (NaN)', AV.avaliar_a3(g_a3(nan=0.5))['decisao'], 'INSUFICIENTE')
confere('a3 inconclusivo (energia)', AV.avaliar_a3(g_a3(soma=0.9))['decisao'], 'INCONCLUSIVO')
confere('a3 rede (corte L/2−2)', AV.avaliar_a3(g_a3(tipo='tri', nsh=6))['decisao'], 'ORDENADA')

# ---------------- controle de tamanho ----------------
confere('tamanho igual', AV.com_controle(dict(d='EXATA'), dict(d='EXATA'), 'd')['decisao'], 'EXATA')
confere('tamanho diferente (estrito)', AV.com_controle(dict(d='EXATA'), dict(d='GRADUADA'), 'd')['decisao'], 'INCONCLUSIVO')
confere('tamanho diferente (não estrito)', AV.com_controle(dict(d='ORDENADA'), dict(d='PARCIAL'), 'd', estrito=False)['decisao'], 'ORDENADA')
confere('só o menor', AV.com_controle(None, dict(d='PARCIAL'), 'd')['decisao'], 'PARCIAL')
confere('maior ruim', AV.com_controle(dict(d='INSUFICIENTE'), dict(d='EXATA'), 'd')['decisao'], 'INSUFICIENTE')
confere('ausente', AV.com_controle(None, None, 'd')['decisao'], None)

# ---------------- globais α ----------------
G = lambda K, R3, R6, TRI: dict(K=K, R3=R3, R6=R6, TRI=TRI)
confere('G1 exata só com degenerescência', AV.global_a1(G('EXATA', 'GRADUADA', 'RARA', 'EXATA')), 'EXATA_SO_COM_DEGENERESCENCIA')
confere('G1 exata geral', AV.global_a1(G('EXATA', 'EXATA', 'EXATA', 'EXATA')), 'EXATA_GERAL')
confere('G1 sem seleção', AV.global_a1(G('SEM_SELECAO', 'SEM_SELECAO', 'SEM_SELECAO', 'SEM_SELECAO')), 'SEM_SELECAO_GERAL')
confere('G1 misto', AV.global_a1(G('GRADUADA', 'GRADUADA', 'GRADUADA', 'EXATA')), 'MISTO')
confere('G1 inconclusivo', AV.global_a1(G('EXATA', 'INSUFICIENTE', 'GRADUADA', 'EXATA')), 'INCONCLUSIVO')
confere('G1 inconclusivo (ausente)', AV.global_a1(G('EXATA', None, 'GRADUADA', 'EXATA')), 'INCONCLUSIVO')
D3 = G('DISTINGUIVEL', 'DISTINGUIVEL', 'DISTINGUIVEL', 'DISTINGUIVEL')
confere('G2 só no completo', AV.global_a2(G('INDEPENDENTE', 'DEPENDENTE', 'FRACA', 'DEPENDENTE'), D3)[0], 'INDEPENDENCIA_SO_NO_COMPLETO')
confere('G2 geral', AV.global_a2(G('INDEPENDENTE', 'INDEPENDENTE', 'INDEPENDENTE', 'INDEPENDENTE'), D3)[0], 'INDEPENDENCIA_GERAL')
confere('G2 dependência geral', AV.global_a2(G('FRACA', 'DEPENDENTE', 'FRACA', 'DEPENDENTE'), D3)[0], 'DEPENDENCIA_GERAL')
confere('G2 misto', AV.global_a2(G('INDEPENDENTE', 'INDEPENDENTE', 'FRACA', 'DEPENDENTE'), D3)[0], 'MISTO')
confere('G2 inconclusivo', AV.global_a2(G('INDEPENDENTE', 'INSUFICIENTE', 'FRACA', 'DEPENDENTE'), D3)[0], 'INCONCLUSIVO')
confere('G2b distinguível', AV.global_a2(G('INDEPENDENTE', 'DEPENDENTE', 'FRACA', 'DEPENDENTE'), D3)[1], 'ESCURO_DISTINGUIVEL_DO_AUSENTE')
confere('G2b igual', AV.global_a2(D3, G('INDISTINGUIVEL', 'INDISTINGUIVEL', 'INDISTINGUIVEL', 'INDISTINGUIVEL'))[1], 'ESCURO_IGUAL_AO_AUSENTE')
confere('G2b misto', AV.global_a2(D3, G('INDISTINGUIVEL', 'DISTINGUIVEL', 'INTERMEDIARIO', 'DISTINGUIVEL'))[1], 'MISTO')
confere('G2b inconclusivo', AV.global_a2(D3, G('INCONCLUSIVO', 'DISTINGUIVEL', 'DISTINGUIVEL', 'DISTINGUIVEL'))[1], 'INCONCLUSIVO')
confere('G3 distância de grafo', AV.global_a3(G('SEM_ORDEM', 'ORDENADA', 'PARCIAL', 'ORDENADA')), 'ORDEM_POR_DISTANCIA_DE_GRAFO')
confere('G3 só com geometria', AV.global_a3(G('SEM_ORDEM', 'PARCIAL', 'SEM_ORDEM', 'ORDENADA')), 'ORDEM_SO_COM_GEOMETRIA')
confere('G3 sem ordem na rede', AV.global_a3(G('SEM_ORDEM', 'ORDENADA', 'ORDENADA', 'PARCIAL')), 'SEM_ORDEM_NA_REDE')
confere('G3 misto', AV.global_a3(G('PARCIAL', 'ORDENADA', 'ORDENADA', 'ORDENADA')), 'MISTO')
confere('G3 inconclusivo', AV.global_a3(G('SEM_ORDEM', 'INSUFICIENTE', 'ORDENADA', 'ORDENADA')), 'INCONCLUSIVO')


# ---------------- β ----------------
def caso_b1(kap, tau, sinal=1, gap=1.0, E0=-0.001, nON=None, sim=0.0, n=4):
    return dict(kap=kap, sinal=sinal, tau=tau, gap=gap, E0=E0 if kap > 0 else 0.0,
                nON_vac=(nON if nON is not None else 6 * kap ** 2), simetria_BD=sim, erro_norma=0.0, rB_vac=0.0, n=n)


def b1_de(taus, **kw):
    cs = []
    for k, t in taus.items():
        cs += [caso_b1(k, t, 1), caso_b1(k, t, -1)]
    return AV.avaliar_b1(cs)


TAUS_OK = {0.0: None, 0.0125: 7000.0, 0.025: 1750.0, 0.05: 440.0, 0.1: 110.0, 0.2: 25.0}
b1ok = b1_de(TAUS_OK)
confere('b1 persistente', b1ok[0.0]['decisao'], 'PERSISTENTE')
confere('b1 transitória', b1ok[0.025]['decisao'], 'TRANSITORIA')
confere('b1 sem seleção', b1_de({0.2: 3.0})[0.2]['decisao'], 'SEM_SELECAO')
confere('b1 inconclusivo (sentidos)', AV.avaliar_b1([caso_b1(0.05, 440.0, 1), caso_b1(0.05, 300.0, -1)])[0.05]['decisao'], 'INCONCLUSIVO')
confere('b1 inconclusivo (vácuo)', AV.avaliar_b1([caso_b1(0.05, 440.0, 1, gap=0.1), caso_b1(0.05, 440.0, -1, gap=0.1)])[0.05]['decisao'], 'INCONCLUSIVO')
confere('b1 inconclusivo (simetria B↔D)', AV.avaliar_b1([caso_b1(0.05, 440.0, 1, sim=1e-3), caso_b1(0.05, 440.0, -1)])[0.05]['decisao'], 'INCONCLUSIVO')
esc_ok = AV.escala(b1ok, 'tau', 'TRANSITORIA', -2.3, -1.7, ('ESCALA_K2', 'OUTRA_ESCALA'))
confere('b1 escala κ⁻²', esc_ok['decisao'], 'ESCALA_K2')
b1_out = b1_de({0.0125: 1000.0, 0.025: 500.0, 0.05: 250.0})
confere('b1 outra escala', AV.escala(b1_out, 'tau', 'TRANSITORIA', -2.3, -1.7, ('ESCALA_K2', 'OUTRA_ESCALA'))['decisao'], 'OUTRA_ESCALA')
confere('b1 escala insuficiente', AV.escala(b1_de({0.025: 1750.0, 0.05: 440.0}), 'tau', 'TRANSITORIA', -2.3, -1.7, ('ESCALA_K2', 'OUTRA_ESCALA'))['decisao'], 'INSUFICIENTE')


def b2_de(Ds, rM=2.0, gap=1.0):
    return AV.avaliar_b2([dict(kap=k, D=D, razao_M2_AC=(None if D == 0 else rM), gap_presente=gap) for k, D in Ds.items()])


DS_OK = {0.0: 0.0, 0.0125: 2e-9, 0.025: 3.2e-8, 0.05: 5.1e-7, 0.1: 8e-6, 0.2: 1e-4}
b2ok = b2_de(DS_OK)
confere('b2 idêntico', b2ok[0.0]['decisao'], 'IDENTICO')
confere('b2 distinguível', b2ok[0.025]['decisao'], 'DISTINGUIVEL')
confere('b2 intermediário', b2_de({0.025: 5e-13})[0.025]['decisao'], 'INTERMEDIARIO')
confere('b2 intermediário (razão ≈ 1)', b2_de({0.025: 1e-8}, rM=1.01)[0.025]['decisao'], 'INTERMEDIARIO')
confere('b2 inconclusivo (gap)', b2_de({0.025: 1e-8}, gap=0.1)[0.025]['decisao'], 'INCONCLUSIVO')
confere('b2 escala κ⁴', AV.escala(b2ok, 'D', 'DISTINGUIVEL', 3.6, 4.4, ('VIRTUAL_K4', 'OUTRA_ESCALA'))['decisao'], 'VIRTUAL_K4')
confere('b2 outra escala', AV.escala(b2_de({0.0125: 1e-8, 0.025: 4e-8, 0.05: 1.6e-7}), 'D', 'DISTINGUIVEL', 3.6, 4.4, ('VIRTUAL_K4', 'OUTRA_ESCALA'))['decisao'], 'OUTRA_ESCALA')
confere('parceiros ok', AV.lei_parceiros(b2_de({0.0125: 2e-9}, rM=2.001), b2_de({0.0125: 2e-9}, rM=1.5004)), 'CONTAGEM_DE_PARCEIROS')
confere('parceiros outra', AV.lei_parceiros(b2_de({0.0125: 2e-9}, rM=2.3), b2_de({0.0125: 2e-9}, rM=1.5)), 'OUTRA')
confere('parceiros insuficiente', AV.lei_parceiros(b2_de({0.025: 2e-9}), {}), 'INSUFICIENTE')
k5 = AV.controle_K5(b1ok, [dict(kap=0.1, tau=111.25), dict(kap=0.2, tau=60.0)])
confere('K5 consistente', k5[0.1]['leitura'], 'CONSISTENTE')
confere('K5 diferente', k5[0.2]['leitura'], 'DIFERENTE')
confere('G4 apoiado', AV.global_b(b1ok, esc_ok, b2ok), 'APOIADO')
confere('G4 parcial (escala)', AV.global_b(b1ok, dict(decisao='OUTRA_ESCALA'), b2ok), 'PARCIAL')
b2mix = dict(b2ok); b2mix[0.025] = dict(decisao='INTERMEDIARIO')
confere('G4 parcial (b2 intermediário)', AV.global_b(b1ok, esc_ok, b2mix), 'PARCIAL')
b1_pers = b1_de({k: None for k in TAUS_OK})
confere('G4 refutado (sem transbordamento)', AV.global_b(b1_pers, dict(decisao='OUTRA_ESCALA'), b2ok), 'REFUTADO')
b2_ident = b2_de({k: 0.0 for k in DS_OK})
confere('G4 refutado (sem distinção virtual)', AV.global_b(b1ok, esc_ok, b2_ident), 'REFUTADO')
confere('G4 inconclusivo (escala insuficiente)', AV.global_b(b1ok, dict(decisao='INSUFICIENTE'), b2ok), 'INCONCLUSIVO')
confere('G4 inconclusivo (κ ausente)', AV.global_b(b1_de({0.0: None, 0.025: 1750.0}), esc_ok, b2ok), 'INCONCLUSIVO')

print()
if FALHAS:
    print('FALHAS:', FALHAS)
    sys.exit(1)
print('%d ramos testados com sucesso' % N_OK[0])
