"""B35b — modelo exato à Konopka–Markopoulou–Smolin (QG original, 2006) em K_n, n = 3, 4, 5.

Cada relação e tem 4 estados: |off⟩, |m = −1⟩, |m = 0⟩, |m = +1⟩ (ligada). Vértices (GMFt) sem grau próprio.
    H = U Σ_e P_e + D Σ_e M_e² + C Σ_a Q_a² − t Σ_{e~f} (M_e⁺ M_f⁻ + h.c.) − κ Σ_e (|0⟩⟨off| + h.c.)_e
P = projetor "ligada"; M = m; Q_a = Σ_{e∋a} M_e (carga do GMFt a = ponta de corda); M± = escada de spin 1 dentro dos
estados ligados (⟨0|M⁺|−1⟩ = ⟨+1|M⁺|0⟩ = √2); e~f = relações que compartilham um vértice; κ = flutuação da relação
(liga/desliga sozinha, com m = 0). Conservados: M_total = Σ_e M_e (o sentido do saca-rolha) e a simetria S_n.
Índices locais: 0 = off, 1 = −1, 2 = 0, 3 = +1."""
import itertools
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as sla

M_LOC = np.array([0, -1, 0, 1])
ON_LOC = np.array([0, 1, 1, 1])
PAR = dict(U=1.0, D=0.5, C=0.5, t=0.1)


def relacoes(n):
    return [(i, j) for i in range(n) for j in range(i + 1, n)]


class Setor:
    def __init__(self, n, Mtot):
        self.n = n; self.rel = relacoes(n); self.nE = len(self.rel); self.Mtot = Mtot
        est = np.array(list(itertools.product(range(4), repeat=self.nE)), dtype=np.int8)
        est = est[M_LOC[est].sum(1) == Mtot]
        self.est = est
        self.pot = 4 ** np.arange(self.nE, dtype=np.int64)[::-1]
        self.cod = est.astype(np.int64) @ self.pot
        self.ordem = np.argsort(self.cod); self.cod_s = self.cod[self.ordem]
        self.m = M_LOC[est]; self.on = ON_LOC[est]
        Q = np.zeros((len(est), n))
        for k, (a, b) in enumerate(self.rel):
            Q[:, a] += self.m[:, k]; Q[:, b] += self.m[:, k]
        self.Q = Q
        self.dim = len(est)

    def indice(self, est_novos):
        c = est_novos.astype(np.int64) @ self.pot
        k = np.searchsorted(self.cod_s, c)
        kk = np.minimum(k, len(self.cod_s) - 1)
        ok = (k < len(self.cod_s)) & (self.cod_s[kk] == c)
        return np.where(ok, self.ordem[kk], -1)

    def hamiltoniano(self, kap, U=PAR['U'], D=PAR['D'], C=PAR['C'], t=PAR['t']):
        est = self.est; dim = self.dim
        diag = U * self.on.sum(1) + D * (self.m ** 2).sum(1) + C * (self.Q ** 2).sum(1)
        rows = [np.arange(dim)]; cols = [np.arange(dim)]; vals = [diag.astype(float)]
        if kap != 0.0:
            for k in range(self.nE):
                sel = np.flatnonzero(est[:, k] == 0)
                novo = est[sel].copy(); novo[:, k] = 2
                j = self.indice(novo); ok = j >= 0
                rows += [sel[ok], j[ok]]; cols += [j[ok], sel[ok]]; vals += [-kap * np.ones(ok.sum())] * 2
        up = {1: 2, 2: 3}; dn = {3: 2, 2: 1}
        for e in range(self.nE):
            for f in range(self.nE):
                if e == f or not (set(self.rel[e]) & set(self.rel[f])):
                    continue
                for se, se2 in up.items():
                    for sf, sf2 in dn.items():
                        sel = np.flatnonzero((est[:, e] == se) & (est[:, f] == sf))
                        if len(sel) == 0:
                            continue
                        novo = est[sel].copy(); novo[:, e] = se2; novo[:, f] = sf2
                        j = self.indice(novo); ok = j >= 0
                        rows.append(j[ok]); cols.append(sel[ok]); vals.append(-2.0 * t * np.ones(ok.sum()))
        H = sp.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(dim, dim))
        return H


def vacuo(n, kap, **par):
    """estado fundamental no setor M_total = 0 (denso se dim < 3000; senão eigsh partindo do vazio)."""
    S0 = Setor(n, 0)
    H = S0.hamiltoniano(kap, **par)
    if S0.dim < 3000:
        w, V = np.linalg.eigh(H.toarray())
        return S0, H, float(w[0]), V[:, 0], float(w[1] - w[0])
    v0 = (S0.on.sum(1) == 0).astype(float) + 1e-3
    w, V = sla.eigsh(H, k=3, which='SA', v0=v0, tol=1e-12)
    o = np.argsort(w)
    return S0, H, float(w[o[0]]), V[:, o[0]], float(w[o[1]] - w[o[0]])


def excitar(S0, g, rel_idx, sinal):
    """O^±_e |Ω⟩: cria um quantum m = ±1 na relação e (off→±1; 0→±1; ∓1→0), normalizado. Devolve (setor, ψ)."""
    S1 = Setor(S0.n, sinal)
    mapa = {0: 3, 2: 3, 1: 2} if sinal > 0 else {0: 1, 2: 1, 3: 2}
    psi = np.zeros(S1.dim, complex)
    for vo, vn in mapa.items():
        sel = np.flatnonzero(S0.est[:, rel_idx] == vo)
        novo = S0.est[sel].copy(); novo[:, rel_idx] = vn
        j = S1.indice(novo)
        assert np.all(j >= 0)
        np.add.at(psi, j, g[sel])
    psi /= np.linalg.norm(psi)
    return S1, psi


def observaveis_vacuo(S0, g, rels):
    p = g ** 2
    out = {}
    for nome, k in rels.items():
        out['P_' + nome] = float(p @ S0.on[:, k]); out['M2_' + nome] = float(p @ S0.m[:, k] ** 2)
    ks = list(rels.values())
    out['PP_' + '_'.join(list(rels.keys())[:2])] = float(p @ (S0.on[:, ks[0]] * S0.on[:, ks[1]]))
    return out


def tau_selecao(n, kap, sinal, Tmax, limiar=0.1, A=0, B=1, Cv=2, Dv=3, dt_fino=0.05, t_fino=100.0, dt=0.5,
                passo_K5=0.25, **par):
    """tempo até B acender: primeiro t com max(r_B, q_B) ≥ limiar, com r_B = Σ_{e∋B} ⟨P_e⟩ − vácuo e
    q_B = ⟨Q_B²⟩ − vácuo. Quantum inicial na relação A–C. Também mede a simetria B↔D (n ≥ 4)."""
    S0, H0, E0, g, gap = vacuo(n, kap, **par)
    iAC = S0.rel.index((min(A, Cv), max(A, Cv)))
    S1, psi = excitar(S0, g, iAC, sinal)
    H1 = S1.hamiltoniano(kap, **par)
    sB = [k for k, e in enumerate(S0.rel) if B in e]
    rB0 = float(g ** 2 @ S0.on[:, sB].sum(1)); qB0 = float(g ** 2 @ S0.Q[:, B] ** 2)
    obB = S1.on[:, sB].sum(1).astype(float); oqB = (S1.Q[:, B] ** 2).astype(float)
    tem_D = n >= 4
    if tem_D:
        sD = [k for k, e in enumerate(S1.rel) if Dv in e]
        obD = S1.on[:, sD].sum(1).astype(float)
    nON0 = float(g ** 2 @ S0.on.sum(1))
    reg = dict(n=n, kap=kap, sinal=sinal, E0=E0, gap=gap, nON_vac=nON0, rB_vac=rB0, qB_vac=qB0, dim=S1.dim)
    amostra_t, amostra_rB, amostra_qB, amostra_rA = [], [], [], []
    sA = [k for k, e in enumerate(S1.rel) if A in e and Cv not in e]
    obA = S1.on[:, sA].sum(1).astype(float) if sA else None
    tau = None; simBD = 0.0; norma = 1.0
    if S1.dim < 3000:
        w, V = np.linalg.eigh(H1.toarray())
        c = V.T.conj() @ psi
        ts = np.concatenate([np.arange(0.0, t_fino, dt_fino), np.arange(t_fino, Tmax + 1e-9, dt)])
        for i0 in range(0, len(ts), 2000):
            tt = ts[i0:i0 + 2000]
            amp = V @ (c[:, None] * np.exp(-1j * np.outer(w, tt)))
            p = np.abs(amp) ** 2
            norma = max(norma, float(np.max(np.abs(p.sum(0) - 1))) + 1.0)
            rB = obB @ p - rB0; qB = oqB @ p - qB0
            if tem_D:
                simBD = max(simBD, float(np.max(np.abs(obD @ p - obB @ p))))
            pick = slice(None, None, max(1, len(tt) // 20))
            amostra_t += tt[pick].tolist(); amostra_rB += rB[pick].tolist(); amostra_qB += qB[pick].tolist()
            if obA is not None:
                amostra_rA += (obA @ p)[pick].tolist()
            k = np.flatnonzero(np.maximum(rB, qB) >= limiar)
            if len(k):
                tau = float(tt[k[0]]); break
    else:
        A_ = (-1j * passo_K5) * H1
        tt = 0.0; cont = 0
        while tt < Tmax - 1e-9:
            psi = sla.expm_multiply(A_, psi); tt += passo_K5; cont += 1
            p = np.abs(psi) ** 2
            rB = float(obB @ p - rB0); qB = float(oqB @ p - qB0)
            if tem_D:
                simBD = max(simBD, abs(float(obD @ p) - float(obB @ p)))
            if cont % 20 == 0:
                amostra_t.append(tt); amostra_rB.append(rB); amostra_qB.append(qB)
            if max(rB, qB) >= limiar:
                tau = tt; break
        norma = 1.0 + abs(float(np.linalg.norm(psi)) - 1.0)
    reg.update(tau=tau, Tmax=Tmax, simetria_BD=simBD, erro_norma=norma - 1.0,
               amostra_t=amostra_t, amostra_rB=amostra_rB, amostra_qB=amostra_qB, amostra_rA=amostra_rA)
    return reg


def vacuo_presente_removido(n, kap, **par):
    """B = vértice 1. Compara o vácuo de K_n (B presente, relações de B desligadas pela energética) com o de K_(n−1)
    (B removido), nas relações entre A = 0, C = 2 e D = 3 (nenhuma toca B)."""
    S4, H4, E4, g4, gap4 = vacuo(n, kap, **par)
    S3, H3, E3, g3, gap3 = vacuo(n - 1, kap, **par)
    # K_(n−1) com vértices 0..n−2  ↔  K_n sem o vértice 1: mapa 0→0, j→j+1 (j ≥ 1)
    mp = lambda j: 0 if j == 0 else j + 1
    nomes = {'AC': (0, 2), 'AD': (0, 3), 'CD': (2, 3)}
    rel4 = {k: S4.rel.index(v) for k, v in nomes.items()}
    inv = {mp(j): j for j in range(n - 1)}
    rel3 = {k: S3.rel.index((min(inv[a], inv[b]), max(inv[a], inv[b]))) for k, (a, b) in nomes.items()}
    o4 = observaveis_vacuo(S4, g4, rel4); o3 = observaveis_vacuo(S3, g3, rel3)
    D = max(abs(o4[k] - o3[k]) for k in o4)
    rM = o4['M2_AC'] / o3['M2_AC'] if o3['M2_AC'] > 0 else None
    return dict(n=n, kap=kap, E0_presente=E4, E0_removido=E3, gap_presente=gap4, obs_presente=o4, obs_removido=o3,
                D=float(D), razao_M2_AC=rM, nON_presente=float(g4 ** 2 @ S4.on.sum(1)))
