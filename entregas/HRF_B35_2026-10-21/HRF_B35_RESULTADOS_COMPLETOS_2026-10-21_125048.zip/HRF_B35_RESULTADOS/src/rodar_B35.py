"""B35 — executor. Uso: python -I src/rodar_B35.py <fumaca|completo> <pasta_saida>
Checkpoint atômico por caso (relançar retoma). Lê os grafos congelados em dados/grafos_B35.json."""
import sys, os, json, time, platform
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import numpy as np
import scipy
from b35_grafos import carregar, triplos, distancias, vizinhos
import b35a_campo as A
import b35b_exato as Bx

DADOS = os.path.join(os.path.dirname(AQUI), 'dados', 'grafos_B35.json')

MODOS = {
    'fumaca': dict(grafos=['K24', 'R3_512', 'R6_256', 'TRI16'], n_trip=100, n_verif=10, n_a2=20, n_fontes=2,
                   kaps=[0.0, 0.025, 0.1], kaps_K5_vac=[0.025], kaps_K5_din=[0.2], Tmax=30000.0),
    'completo': dict(grafos=['K24', 'K40', 'R3_512', 'R3_1024', 'R6_256', 'R6_512', 'TRI16', 'TRI24'], n_trip=200,
                     n_verif=20, n_a2=40, n_fontes=4, kaps=[0.0, 0.0125, 0.025, 0.05, 0.1, 0.2],
                     kaps_K5_vac=[0.0125, 0.025, 0.05], kaps_K5_din=[0.1, 0.2], Tmax=30000.0),
}
SEMENTE_TRIPLOS = 11
T_OLA = {'K24': 10.0, 'K40': 10.0, 'R3_512': 20.0, 'R3_1024': 20.0, 'R6_256': 12.0, 'R6_512': 12.0,
         'TRI16': 16.0, 'TRI24': 25.0}
NT_OLA = 2001
FRAC_CHEGADA = 0.5


def salvar(pasta, nome, obj):
    tmp = os.path.join(pasta, nome + '.tmp')
    with open(tmp, 'w') as f:
        json.dump(obj, f)
    os.replace(tmp, os.path.join(pasta, nome))


def feito(pasta, nome):
    return os.path.exists(os.path.join(pasta, nome))


def log(pasta, msg):
    linha = time.strftime('%H:%M:%S ') + msg
    print(linha, flush=True)
    with open(os.path.join(pasta, 'log_execucao.txt'), 'a') as f:
        f.write(linha + '\n')


# ---------------- α ----------------
def caso_alfa(nome, cfg, pasta):
    N, E, info = carregar(DADOS, nome)
    t0 = time.time()
    campo = A.Campo(N, E)
    grupos = A.autoespacos(campo.Q)
    dims = [VW.shape[1] for _, VW in grupos]
    trs = triplos(N, E, cfg['n_trip'], SEMENTE_TRIPLOS)
    a1 = []
    estados = []
    for i, (a, b, c) in enumerate(trs):
        ex, gr = A.selecao_triplo(grupos, N, a, b, c)
        r = dict(A=a, B=b, C=c, exato_Nmin=ex['Nmin'], exato_dim=ex['dim'], grad_contraste=gr['contraste'],
                 grad_Nmin=gr['Nmin'], grad_vB2N=gr['vB2N'])
        if ex['v'] is not None:
            v, q, tipo = ex['v'], ex['q'], 'exato'
        elif gr['v'] is not None:
            v, q, tipo = gr['v'], gr['q'], 'graduado'
        else:
            v, q, tipo = None, None, 'nenhum'
        r['tipo'] = tipo
        if i < cfg['n_verif'] and v is not None:
            r['verif'] = A.verificar_estado(campo, v, q, a, b, c)
        a1.append(r); estados.append((v, q, tipo))
    # a2: B escuro × B removido
    a2 = []
    for i, (a, b, c) in enumerate(trs[:cfg['n_a2']]):
        v, q, tipo = estados[i]
        if v is None:
            a2.append(dict(A=a, B=b, C=c, tipo=tipo)); continue
        sA0 = float(v[a] ** 2 / np.sum(v ** 2)); sC0 = float(v[c] ** 2 / np.sum(v ** 2))
        tA, tC, iA, iC = A.transplante(N, E, b, v, a, c)
        vac = A.vacuo_longe_de_B(campo, a, b, c)
        a2.append(dict(A=a, B=b, C=c, tipo=tipo, share_A=sA0, share_C=sC0, media_A_semB=tA, media_C_semB=tC,
                       t0_A_semB=iA, t0_C_semB=iC, **vac))
    # a3: ordem de chegada
    T = T_OLA[nome]
    viz = vizinhos(N, E)
    fontes = [int(k * N // cfg['n_fontes']) for k in range(cfg['n_fontes'])]
    a3 = []
    for j, s in enumerate(fontes):
        ts, eps = A.ola(N, E, s, T, NT_OLA)
        tch = A.chegada(ts, eps, FRAC_CHEGADA)
        d = distancias(N, E, s, viz)
        ball = [int(np.sum(d <= k)) for k in range(int(d.max()) + 1)]
        reg = dict(s=s, T=T, d=d.tolist(), t_chegada=[None if np.isnan(x) else float(x) for x in tch], bola=ball,
                   pico_s=float(eps[:, s].max()))
        if j == 0:
            vo = A.verificar_ola(campo, s, T)
            reg['soma_energia_0'] = vo['soma_0']; reg['soma_energia_T'] = vo['soma_T']
            reg['dif_vertices_T'] = float(np.max(np.abs(vo['ev_T'] - eps[-1])))
        a3.append(reg)
    out = dict(nome=nome, tipo=info['tipo'], N=N, E=len(E), graus=info['graus'], n_autoespacos=len(grupos),
               dim_max=int(max(dims)), kmin=campo.kmin, a1=a1, a2=a2, a3=a3, tempo=time.time() - t0)
    if 'L' in info:
        out['L'] = info['L']
    return out


# ---------------- β ----------------
def caso_b1(n, kaps, Tmax, sinais=(1, -1)):
    out = []
    for kap in kaps:
        for sg in sinais:
            out.append(Bx.tau_selecao(n, kap, sg, Tmax))
    return out


def main(modo, pasta):
    cfg = MODOS[modo]
    os.makedirs(pasta, exist_ok=True)
    salvar(pasta, 'B35_config.json', dict(modo=modo, cfg=cfg, python=platform.python_version(), numpy=np.__version__,
                                          scipy=scipy.__version__, maquina=platform.platform(), cpus=os.cpu_count(),
                                          par_alfa=dict(mu2=A.MU2, C=A.CV), par_beta=Bx.PAR, T_ola=T_OLA,
                                          nt_ola=NT_OLA, frac_chegada=FRAC_CHEGADA, semente_triplos=SEMENTE_TRIPLOS))
    t00 = time.time()
    # β primeiro (rápido)
    if not feito(pasta, 'B35b2.json'):
        t0 = time.time()
        r = dict(K4=[Bx.vacuo_presente_removido(4, k) for k in cfg['kaps']],
                 K5=[Bx.vacuo_presente_removido(5, k) for k in cfg['kaps_K5_vac']])
        salvar(pasta, 'B35b2.json', r); log(pasta, 'b2 ok (%.1f s)' % (time.time() - t0))
    if not feito(pasta, 'B35b1_K4.json'):
        t0 = time.time()
        salvar(pasta, 'B35b1_K4.json', dict(casos=caso_b1(4, cfg['kaps'], cfg['Tmax'])))
        log(pasta, 'b1 K4 ok (%.1f s)' % (time.time() - t0))
    if not feito(pasta, 'B35b1_K5.json'):
        t0 = time.time()
        salvar(pasta, 'B35b1_K5.json', dict(casos=caso_b1(5, cfg['kaps_K5_din'], 400.0, sinais=(1,))))
        log(pasta, 'b1 K5 ok (%.1f s)' % (time.time() - t0))
    for nome in cfg['grafos']:
        arq = 'B35a_%s.json' % nome
        if feito(pasta, arq):
            continue
        t0 = time.time()
        salvar(pasta, arq, caso_alfa(nome, cfg, pasta))
        log(pasta, '%s ok (%.1f s)' % (nome, time.time() - t0))
    log(pasta, 'fim (%.1f s)' % (time.time() - t00))


if __name__ == '__main__':
    main(sys.argv[1], sys.argv[2])
