"""Gera e congela os grafos da B35 em dados/grafos_B35.json. Uso: python -I src/gerar_grafos_B35.py dados
(Feito uma vez, antes do pré-registro; o arquivo gerado entra nos hashes. A rodada só LÊ o arquivo.)"""
import sys, os, json
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import numpy as np
from b35_grafos import GRAFOS, completo, tri_toro, regular_aleatorio, conexo, vizinhos


def main(pasta):
    os.makedirs(pasta, exist_ok=True)
    out = {}
    for nome, (tipo, p) in GRAFOS.items():
        if tipo == 'completo':
            N = p['N']; E = completo(N); info = {}
        elif tipo == 'tri':
            N = p['L'] ** 2; E = tri_toro(p['L']); info = dict(L=p['L'])
        else:
            N = p['N']; E, tent = regular_aleatorio(N, p['d'], p['seed']); info = dict(d=p['d'], seed=p['seed'], tentativas=tent)
        graus = sorted(set(len(v) for v in vizinhos(N, E)))
        out[nome] = dict(tipo=tipo, N=N, E=[list(e) for e in E], graus=graus, conexo=conexo(N, E), **info)
        print(nome, tipo, 'N', N, 'E', len(E), 'graus', graus, 'conexo', out[nome]['conexo'])
    with open(os.path.join(pasta, 'grafos_B35.json'), 'w') as f:
        json.dump(out, f)


if __name__ == '__main__':
    main(sys.argv[1] if len(sys.argv) > 1 else 'dados')
