"""B35a — campo livre (gaussiano) nas relações de um grafo congelado da Quantum Graphity.

Base [D, 21/10]: o campo da QG original (Konopka–Markopoulou–Smolin 2006) vive nas relações; o vértice (GMFt) não tem
grau de liberdade próprio. Limite livre do termo de vértice C Σ_a (Σ_{e∋a} M_e)² e do termo D Σ M_e²:
    H = Σ_p [ ½ Σ_e (π_e^p)² + ½ x^pᵀ K x^p ],   K = μ² I + C Rᵀ R,
R = incidência (N × E) sem sinal, p = 1, 2 (duas polarizações; injeção em saca-rolha = circular).
Carga (receptor) do GMFt a: X_a = Σ_{e∋a} x_e; energia do vértice a: (C/2) X_a².
Modos: banda de carga u_j = Rᵀ v_j / √q_j (Q v_j = q_j v_j, Q = R Rᵀ = Grau + Adj), ω_j² = μ² + C q_j;
banda plana (núcleo de R, ω = μ): laços que não carregam nenhum vértice.
Uma partícula (Rényi-2 linear e circular) adaptada de b33a_quantico.py (B33), com U = 1."""
import numpy as np
from b35_grafos import incidencia, sem_vertice

MU2 = 1.0
CV = 1.0


# ---------------- estrutura de modos ----------------
def autoespacos(Q, tol=1e-8):
    q, V = np.linalg.eigh(Q)
    grupos = []
    i = 0
    while i < len(q):
        j = i + 1
        while j < len(q) and abs(q[j] - q[i]) <= tol * max(1.0, abs(q[i])):
            j += 1
        grupos.append((float(q[i:j].mean()), V[:, i:j]))
        i = j
    return grupos


class Campo:
    """campo livre nas relações; guarda K = U diag(ω²) Uᵀ e as covariâncias do vácuo (por polarização)."""

    def __init__(self, N, E, mu2=MU2, C=CV, vacuo=True):
        self.N, self.E, self.mu2, self.C = N, E, mu2, C
        self.R = incidencia(N, E)
        self.Q = self.R @ self.R.T
        if vacuo:
            K = mu2 * np.eye(len(E)) + C * (self.R.T @ self.R)
            w2, self.U = np.linalg.eigh(K)
            del K
            self.om = np.sqrt(w2)
            self.X = (self.U * (0.5 / self.om)) @ self.U.T
            self.P = (self.U * (0.5 * self.om)) @ self.U.T
            self.kmin = float(w2[0])

    # ---- uma partícula ----
    def coef_de_u(self, u):
        f = self.U.T @ u
        return f / np.linalg.norm(f)

    def vetores_c(self, f, t=0.0):
        ft = np.conj(f * np.exp(-1j * self.om * t))
        a = ft * 0.5 / np.sqrt(self.om); b = ft * 0.5 * np.sqrt(self.om)
        M = np.stack([a.real, a.imag, b.real, b.imag], axis=1)
        Rr = self.U @ M
        cth = Rr[:, 0] + 1j * Rr[:, 1]
        cn = 1j * (Rr[:, 2] + 1j * Rr[:, 3])
        return cth, cn

    def energias(self, f, t=0.0):
        """frações da energia do quantum: (por vértice [termo C/2 X_a²], por relação [½π² + ½μ²x²]); somam 1."""
        cth, cn = self.vetores_c(f, t)
        wbar = float(np.sum(np.abs(f) ** 2 * self.om))
        ev = 2 * self.C * np.abs(self.R @ cth) ** 2 / wbar
        er = 2 * (np.abs(cn) ** 2 + self.mu2 * np.abs(cth) ** 2) / wbar
        return ev, er

    def renyi2(self, idx, f, t=0.0):
        """ΔS₂ (linear, circular) da álgebra das relações idx para o estado a†(f)|0⟩ (fórmula da B33, U = 1)."""
        idx = list(idx)
        cth, cn = self.vetores_c(f, t)
        Xa = self.X[np.ix_(idx, idx)]; Pa = self.P[np.ix_(idx, idx)]
        Xi = np.linalg.inv(Xa); Pi = np.linalg.inv(Pa)
        ct, cn_ = cth[idx], cn[idx]
        mt = Xi @ ct; mn = Pi @ cn_
        v = 1.0 - float(np.real(np.vdot(ct, mt) + np.vdot(cn_, mn)))
        a_t, b_t, a_n, b_n = mt.real, mt.imag, mn.real, mn.imag
        aSa = 0.5 * (a_t @ Xa @ a_t + a_n @ Pa @ a_n)
        bSb = 0.5 * (b_t @ Xa @ b_t + b_n @ Pa @ b_n)
        aSb = 0.5 * (a_t @ Xa @ b_t + a_n @ Pa @ b_n)
        T1 = aSa + bSb; c0 = 2 * v - 1
        T2l = T1 ** 2 + 2 * (aSa ** 2 + bSb ** 2 + 2 * aSb ** 2); T2c = 2 * T1 ** 2
        return float(-np.log(4 * T2l + 4 * c0 * T1 + c0 ** 2)), float(-np.log(4 * T2c + 4 * c0 * T1 + c0 ** 2))

    def entropia_vacuo(self, idx):
        idx = list(idx)
        return entropia_gauss(self.X[np.ix_(idx, idx)], self.P[np.ix_(idx, idx)])


def entropia_gauss(Xa, Pa):
    w, Qm = np.linalg.eigh(Xa)
    w = np.clip(w, 1e-300, None)
    Xh = (Qm * np.sqrt(w)) @ Qm.T
    Mm = Xh @ Pa @ Xh; Mm = 0.5 * (Mm + Mm.T)
    nu = np.sqrt(np.clip(np.linalg.eigvalsh(Mm), 0.25, None))
    nu = np.maximum(nu, 0.5 + 1e-15)
    a, b = nu + 0.5, nu - 0.5
    return float(np.sum(a * np.log(a) - np.where(b > 0, b * np.log(b), 0.0)))


def estrela(E, a):
    return [k for k, (x, y) in enumerate(E) if a in (x, y)]


# ---------------- B35a1: seleção estacionária ----------------
def melhor_min(a, c, n=721):
    """max sobre v unitário em span{a, c} de min((v·a)², (v·c)²); devolve (valor, v)."""
    na = np.linalg.norm(a); nc = np.linalg.norm(c)
    if na < 1e-14 or nc < 1e-14:
        return 0.0, None
    e1 = a / na
    c2 = c - (c @ e1) * e1
    if np.linalg.norm(c2) < 1e-14:
        return float(min(abs(a @ e1), abs(c @ e1)) ** 2), e1
    e2 = c2 / np.linalg.norm(c2)
    th = np.linspace(0.0, np.pi, n)
    best, bv = -1.0, None
    for _ in range(4):
        V = np.outer(np.cos(th), e1) + np.outer(np.sin(th), e2)
        fv = np.minimum((V @ a) ** 2, (V @ c) ** 2)
        k = int(np.argmax(fv))
        if fv[k] > best:
            best, bv = float(fv[k]), V[k].copy()
        dth = th[1] - th[0]
        th = np.linspace(th[k] - dth, th[k] + dth, 41)
    return best, bv


def selecao_triplo(grupos, N, A, B, C, lit=0.5):
    """estado estacionário (um autoespaço de Q) que acende A e C com B escuro.
    exato: autoespaço de dimensão ≥ 2, restrição v_B = 0, maximiza min(v_A², v_C²); conta se N·min ≥ lit.
    graduado: um vetor da base de autovetores com N·min(v_A², v_C²) ≥ lit e maior contraste min/v_B²."""
    ex = dict(Nmin=0.0, v=None, q=None, dim=0)
    for q, VW in grupos:
        w = VW.shape[1]
        if w < 2:
            continue
        b = VW[B, :]
        if np.linalg.norm(b) > 1e-14:
            _, _, Vt = np.linalg.svd(b[None, :])
            Wp = VW @ Vt[1:].T
        else:
            Wp = VW
        a = Wp @ Wp[A, :]; c = Wp @ Wp[C, :]
        m, v = melhor_min(a, c)
        if v is None:
            continue
        v = Wp @ (Wp.T @ v); v /= np.linalg.norm(v)
        m = min(v[A] ** 2, v[C] ** 2)
        if abs(v[B]) ** 2 <= 1e-24 and m * N >= lit and m * N > ex['Nmin']:
            ex = dict(Nmin=float(m * N), v=v, q=q, dim=w)
    gr = dict(contraste=0.0, Nmin=0.0, v=None, q=None, vB2N=None)
    for q, VW in grupos:
        for k in range(VW.shape[1]):
            v = VW[:, k]
            m = min(v[A] ** 2, v[C] ** 2)
            if m * N >= lit:
                ct = m / max(v[B] ** 2, 1e-300)
                if ct > gr['contraste']:
                    gr = dict(contraste=float(ct), Nmin=float(m * N), v=v.copy(), q=q, vB2N=float(v[B] ** 2 * N))
    return ex, gr


def verificar_estado(campo, v, q, A, B, C):
    """constrói o quantum circular no perfil de carga v (estacionário) e mede, no campo inteiro: frações de carga
    (comparadas com v²), energia nas relações da estrela de B, ΔS₂ (linear e circular) das estrelas de A, B, C."""
    E = campo.E
    u = campo.R.T @ v
    u /= np.linalg.norm(u)
    f = campo.coef_de_u(u)
    ev, er = campo.energias(f)
    share = ev / ev.sum()
    erro_modo = float(np.max(np.abs(share - v ** 2 / np.sum(v ** 2))))
    om_esp = np.sqrt(campo.mu2 + campo.C * q)
    disp = float(np.sqrt(np.sum(np.abs(f) ** 2 * (campo.om - om_esp) ** 2)))     # estacionário: 0
    sB = estrela(E, B)
    out = dict(erro_modo=erro_modo, dispersao_freq=disp, soma_energia=float(ev.sum() + er.sum()),
               carga_A=float(share[A]), carga_B=float(share[B]), carga_C=float(share[C]),
               rel_estrela_B=float(er[sB].sum()), rel_AB=float(er[[k for k in sB if A in E[k]]].sum()),
               fracao_vertices=float(ev.sum()))
    for nome, x in (('A', A), ('B', B), ('C', C)):
        l, c = campo.renyi2(estrela(E, x), f)
        out['dS2lin_' + nome] = l; out['dS2circ_' + nome] = c
    return out


# ---------------- B35a2: B escuro × B removido ----------------
def transplante(N, E, B, v, A, C, mu2=MU2, Cv=CV, T=200.0, nt=4001):
    """perfil de carga v restrito a V∖{B}, no grafo sem B; média temporal da fração de carga em A e em C."""
    N2, E2, pos = sem_vertice(N, E, B)
    R2 = incidencia(N2, E2); Q2 = R2 @ R2.T
    q2, V2 = np.linalg.eigh(Q2)
    om2 = np.sqrt(mu2 + Cv * q2)
    keep = [x for x in range(N) if x != B]
    v2 = v[keep]
    u = R2.T @ v2; u /= np.linalg.norm(u)
    f = (V2.T @ (R2 @ u)) / np.sqrt(q2)            # coeficientes nos modos de carga (u está na banda de carga)
    ts = np.linspace(0.0, T, nt)
    coef = 0.5 * np.sqrt(q2) * f / np.sqrt(om2)
    sA = np.zeros(nt); sC = np.zeros(nt)
    for i0 in range(0, nt, 500):
        Rc = (np.exp(1j * np.outer(ts[i0:i0 + 500], om2)) * coef[None, :]) @ V2.T
        e = np.abs(Rc) ** 2
        tot = e.sum(1)
        sA[i0:i0 + 500] = e[:, pos[A]] / tot; sC[i0:i0 + 500] = e[:, pos[C]] / tot
    return float(sA.mean()), float(sC.mean()), float(sA[0]), float(sC[0])


def regiao_AC_sem_B(E, A, B, C):
    return [k for k, (x, y) in enumerate(E) if (x in (A, C) or y in (A, C)) and B not in (x, y)]


def vacuo_longe_de_B(campo, A, B, C):
    """entropia de vácuo da região das relações de A e C que não tocam B, com B presente e com B removido."""
    N, E = campo.N, campo.E
    reg = regiao_AC_sem_B(E, A, B, C)
    S1 = campo.entropia_vacuo(reg)
    N2, E2, pos = sem_vertice(N, E, B)
    c2 = Campo(N2, E2, campo.mu2, campo.C)
    reg2 = regiao_AC_sem_B(E2, pos[A], -1, pos[C])
    S2 = c2.entropia_vacuo(reg2)
    # identidade analítica: "B com todas as relações congeladas desligadas" = grafo sem B (o vértice não tem grau
    # próprio). Conferência: a matriz K do grafo com as relações de B retiradas e B mantido isolado é a de G−B.
    E_off = [e for e in E if B not in e]
    R_off = incidencia(N, E_off)
    K_off = campo.mu2 * np.eye(len(E_off)) + campo.C * (R_off.T @ R_off)
    R2 = incidencia(N2, E2)
    K2 = campo.mu2 * np.eye(len(E2)) + campo.C * (R2.T @ R2)
    ident = float(np.max(np.abs(K_off - K2))) if K_off.shape == K2.shape else float('inf')
    return dict(S_presente=S1, S_removido=S2, n_reg=len(reg), dif_K_congelado_vs_removido=ident)


# ---------------- B35a3: ordem de chegada ----------------
def ola(N, E, s, T, nt, mu2=MU2, Cv=CV):
    """um quantum injetado na configuração que carrega s (u0 = Rᵀ e_s/√d_s; só banda de carga). Fração da energia do
    quantum no termo de vértice de cada GMFt, em função do tempo (cálculo no espaço dos vértices)."""
    R = incidencia(N, E); Q = R @ R.T
    q, V = np.linalg.eigh(Q)
    om = np.sqrt(mu2 + Cv * q)
    ds = Q[s, s]
    f = V[s, :] * np.sqrt(q) / np.sqrt(ds)
    wbar = float(np.sum(f ** 2 * om))
    ts = np.linspace(0.0, T, nt)
    coef = 0.5 * np.sqrt(q) * f / np.sqrt(om)
    eps = np.empty((nt, N))
    for i0 in range(0, nt, 400):
        Rc = (np.exp(1j * np.outer(ts[i0:i0 + 400], om)) * coef[None, :]) @ V.T
        eps[i0:i0 + 400] = 2 * Cv * np.abs(Rc) ** 2 / wbar
    return ts, eps


def chegada(ts, eps, frac=0.5):
    mx = eps.max(axis=0)
    t = np.full(eps.shape[1], np.nan)
    for a in range(eps.shape[1]):
        k = np.flatnonzero(eps[:, a] >= frac * mx[a])
        if len(k) and mx[a] > 0:
            t[a] = ts[k[0]]
    return t


def spearman(x, y):
    x = np.asarray(x, float); y = np.asarray(y, float)
    rx = _ranks(x); ry = _ranks(y)
    if np.std(rx) == 0 or np.std(ry) == 0:
        return float('nan')
    return float(np.corrcoef(rx, ry)[0, 1])


def _ranks(x):
    """postos médios (empates recebem a média dos postos)."""
    o = np.argsort(x, kind='stable')
    r = np.empty(len(x)); r[o] = np.arange(len(x), dtype=float)
    xs = x[o]
    i = 0
    while i < len(xs):
        j = i
        while j + 1 < len(xs) and xs[j + 1] == xs[i]:
            j += 1
        if j > i:
            r[o[i:j + 1]] = 0.5 * (i + j)
        i = j + 1
    return r


def verificar_ola(campo, s, T):
    """conferência da redução ao espaço dos vértices: soma das frações (vértices + relações) = 1 em t = 0 e T, e
    energia dos vértices igual à do campo inteiro em t = T."""
    u0 = campo.R.T[:, s] / np.sqrt(campo.Q[s, s])
    f = campo.coef_de_u(u0)
    out = {}
    for nome, t in (('0', 0.0), ('T', T)):
        ev, er = campo.energias(f, t)
        out['soma_' + nome] = float(ev.sum() + er.sum())
        out['ev_' + nome] = ev
    return out
