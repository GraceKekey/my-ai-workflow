# LEIAME — B35 (pré-registro)

**Mario José do Canto Filho, MD · Claude (`-clau`) · 21/10/2026**

## O que é
Pré-registro da B35, primeira bancada da vertente Ola nos grafos da *Quantum Graphity*. A base é o campo da QG original,
que vive nas relações; o GMFt é o vértice, sem grau de liberdade próprio. A bancada pergunta se a base acende GMFt de
forma seletiva e independente, se a ordem de chegada exige geometria e se um GMFt sombreado se distingue de um ausente.
O protocolo está em `HRF_B35_PROTOCOLO_2026-10-21_1149-clau.md` e a fumaça em `FUMACA_B35.md`. **Rodar só depois do
"pode rodar".**

## Como rodar
```
python -I src/testar_avaliador_B35.py          # deve terminar com "79 ramos testados com sucesso"
python -I src/rodar_B35.py completo resultados  # checkpoint atômico por caso; se cair, relançar retoma
python -I src/avaliar_B35.py resultados          # grava resultados/avaliacao_B35.json
```
Os grafos estão congelados em `dados/grafos_B35.json`. A rodada **não** os regenera; `src/gerar_grafos_B35.py` fica só
para proveniência.

## Quanto custa
12–20 min e ≤ 2 GB. Cabe na nuvem (2 CPUs, 8 GB). A ordem é β primeiro (b2, b1 K_4, b1 K_5), depois os grafos α.

## Arquivos
- `src/b35_grafos.py` — grafos (completo, regular aleatório, triangular em toro), incidência, distâncias, triplos.
- `src/gerar_grafos_B35.py` — gerou `dados/grafos_B35.json` (sementes 3501–3504).
- `src/b35a_campo.py` — campo livre nas relações: modos, uma partícula (Rényi-2 linear e circular, adaptado da B33),
  seleção estacionária, transplante, vácuo longe de B, ola e chegada.
- `src/b35b_exato.py` — modelo exato à KMS em K_3, K_4, K_5: setores de M total, vácuo, quantum em A–C, tempo de
  seleção, vácuo com B presente × removido.
- `src/rodar_B35.py` — executor (modos `fumaca` e `completo`).
- `src/avaliar_B35.py` — avaliador congelado (protocolo §7).
- `src/testar_avaliador_B35.py` — teste sintético (79 ramos).
- `fumaca/` — saída do modo `fumaca`, avaliação e log.
- `HRF_B35_hashes_antes_da_execucao_2026-10-21_1149-clau.txt` — SHA-256 de tudo acima.
