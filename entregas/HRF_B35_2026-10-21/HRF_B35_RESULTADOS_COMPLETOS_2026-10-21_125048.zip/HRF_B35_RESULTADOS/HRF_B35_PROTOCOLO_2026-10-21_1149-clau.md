# HRF B35 — A base ativa os GMFt? Seleção, independência, ordem e sombreado nos grafos da *Quantum Graphity*
## Protocolo pré-registrado

**Data:** 21 de outubro de 2026 (America/Sao_Paulo) — Claude (`-clau`) · fluxo ímpar
**Autoria:** Mario José do Canto Filho, MD · desenho, código e fumaça: Claude
**Decisões de Mario que fixam esta bancada (21/10):**
- 07h25: dois blocos, α (modal) e β (relacional); **GMFt = vértice do grafo**; grafos K_N, regular aleatório e quase-rede;
  Q11 fora da B35, numa B37 com o critério (ii);
- 07h25: **o GMFt é diferente do antigo GMF**;
- 07h36 e 09h31: a base é um meio que está em tudo ao mesmo tempo e só se torna visível pelas relações; é como um
  campo da teoria quântica de campos, com dinâmica própria e todos os graus de liberdade; **é a boundary da teoria
  holográfica**;
- 11h08: escolha **(A)** — a base é o campo da QG original, que vive nas relações, sem espaço de fundo.

**Nada roda sem "pode rodar".**
**Vertente:** HRF-OLA, OLA-0-RR3 do lado do controle modal (nota R/R′ §9). Nota de interface OLA × B33 §5 (esboço
original da B35); nota de arquitetura da base de 21/10.

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 0. Arquitetura usada [D, 21/10]

| Termo | Nesta bancada |
|---|---|
| **base** | o campo da QG original (Konopka–Markopoulou–Smolin 2006) nas N(N−1)/2 relações possíveis; todas existem sempre; relação desligada = vácuo; sem espaço de fundo |
| **GMFt** | o vértice; **sem grau de liberdade próprio**; não é célula da base nem o GMF histórico |
| **relação** | a aresta: o lugar onde a base vive e se torna visível |
| **ativação do GMFt (carga)** | a carga do campo no vértice, Q_a = Σ_{e∋a} M_e (o termo de vértice de KMS; a ponta de corda) |
| **atravessado** | as relações de B levam campo, mas a carga de B é nula |
| **sombreado (sentido da QG)** | todas as relações de B desligadas |
| **ausente** | o vértice B e todas as suas relações retirados |

Não há termo que leve algo de um GMFt a outro; toda a dinâmica é do campo nas relações. A identificação deste campo com
a boundary holográfica é hipótese [H]; a QG não tem boundary nem dicionário holográfico.

**Dois resultados analíticos que a bancada confere [F]:**
1. **Lema da vizinhança.** No campo livre num grafo fixo e não bipartido, se A está carregado num estado estacionário
   (um só autoespaço) e B é vizinho de A,
   então ou B está carregado ou a relação A–B está excitada. Prova: a amplitude do modo na relação A–B é
   (v_A + v_B)/√q; anulá-la com v_B = 0 exige v_A = 0. **Num grafo fixo, um B vizinho de A e de C não fica inteiramente
   escuro.** Sombrear por inteiro exige relações desligadas (é a correção 1 de Mario).
2. **Identidade congelada.** Num retrato congelado, um B com todas as relações desligadas é idêntico a um B ausente,
   porque o vértice não tem grau próprio. Sombreado ≠ ausente só pode vir de outro canal ou das relações **virtuais**
   (bloco β).

## 1. Objetivo

| Bloco | Pergunta (nota de interface §5) |
|---|---|
| **B35a1** (T1) | Num estado estacionário da base, sem nada no hamiltoniano que escolha B, a base acende A e C e deixa B (vizinho comum dos dois) escuro? Exatamente ou só graduadamente? |
| **B35a2** (T2 + T3) | O estado que acendia A e C com B escuro continua igual quando B é removido? B escuro se distingue de B ausente olhando só relações que não tocam B? |
| **B35a3** (T5) | Depois de uma injeção local, a chegada aos GMFt segue a distância? Só com geometria, ou basta distância de grafo? |
| **B35b1** (T1′) | Com relações dinâmicas, um quantum na relação A–C deixa B sombreado (relações desligadas)? Por quanto tempo? |
| **B35b2** (T3c) | B sombreado pela energética se distingue de B removido, olhando só relações que não tocam B? |

## 2. Modelos

**α — campo livre nas relações (B35a).** Limite livre dos termos D Σ M_e² e C Σ_a (Σ_{e∋a} M_e)² da QG original:
H = Σ_p [½ Σ_e (π_e^p)² + ½ x^pᵀ K x^p], K = μ² I + C Rᵀ R, com R a incidência (N × E) sem sinal e p = 1, 2 as duas
polarizações. Carga do GMFt a: X_a = Σ_{e∋a} x_e; energia do vértice: (C/2) X_a². Modos:
- **banda de carga:** u_j = Rᵀ v_j/√q_j, com Q v_j = q_j v_j, Q = R Rᵀ = grau + adjacência, ω_j² = μ² + C q_j;
- **banda plana:** núcleo de R, ω = μ. São laços que não carregam nenhum vértice.

Num estado estacionário de um autoespaço de Q, a fração de carga do GMFt a é exatamente v(a)² [F].

**β — modelo exato à KMS (B35b).** Em K_n (n = 3, 4, 5), cada relação tem os estados |off⟩, |m = −1⟩, |0⟩, |+1⟩:
H = U Σ_e P_e + D Σ_e M_e² + C Σ_a Q_a² − t Σ_{e~f} (M_e⁺ M_f⁻ + h.c.) − κ Σ_e (|0⟩⟨off| + h.c.)_e.
- P_e é o projetor "relação ligada";
- M± é a escada de spin 1 dentro dos estados ligados;
- e~f quer dizer que as relações compartilham um vértice;
- κ é a flutuação da relação: ela liga e desliga sozinha, com m = 0.

São conservados o M total (o sentido do saca-rolha) e a simetria S_n. O vácuo é o estado fundamental com M = 0; para
U > 0 e κ pequeno ele é o vazio vestido.

**Onda injetada (regra do projeto):** em saca-rolha.
- α: um quantum circular nas duas polarizações, a†_circ = (a†_1 + i a†_2)/√2, com o linear como referência. As energias
  são iguais por construção; o ΔS₂ é reportado nos dois.
- β: o quantum é m = +1, e m = −1 é o controle do outro sentido.

## 3. Hipóteses (pré-registradas) e o que já se sabe

**Aviso de cegueira.** A exploração antes do congelamento (e a fumaça) já rodou quase todos os casos, em tamanhos
iguais ou próximos aos da rodada, e o bloco β nos parâmetros exatos da rodada. Os números estão no `FUMACA_B35.md`. A
rodada é a confirmação formal, com código, regras e controles congelados.

- **H-a1 [F/M]:**
  - **EXATA** em K_N, porque a degenerescência é N − 1;
  - **EXATA** na rede triangular em toro (degenerescências de até 45 e 69);
  - **GRADUADA** nos regulares aleatórios: sem degenerescência, o contraste fica entre 10² e 10⁴;
  - global **EXATA_SO_COM_DEGENERESCENCIA**;
  - lema da vizinhança **CONFIRMADO** em todos.
- **H-a2 [F/M]:**
  - T2: **INDEPENDENTE** em K_N. Ali δ = 0 analiticamente, porque o perfil restrito a V∖{B} continua sendo autovetor de
    K_(N−1). **DEPENDENTE** em R3, R6 e TRI. Global **INDEPENDENCIA_SO_NO_COMPLETO**;
  - T3: **DISTINGUIVEL** em todos. Global **ESCURO_DISTINGUIVEL_DO_AUSENTE**.
- **H-a3 [H].** Este bloco **decide entre duas leituras**:
  - leitura de Mario (correção 2): a ordem temporal é propriedade da fase com geometria → **ORDEM_SO_COM_GEOMETRIA**;
  - ressalva de Claude (21/10, primeira resposta deste chat): basta distância de grafo →
    **ORDEM_POR_DISTANCIA_DE_GRAFO**.
  
  Previsão (exploração): K **SEM_ORDEM**; R3 **ORDENADA**; R6 [?] (poucas cascas antes de saturar); TRI **ORDENADA**.
  Global **ORDEM_POR_DISTANCIA_DE_GRAFO**.
- **H-b1 [H]:**
  - κ = 0: **PERSISTENTE**. Com as relações congeladas, o quantum não sai de A–C;
  - κ = 0,0125 a 0,2: **TRANSITORIA**, com τ ≈ 7 054; 1 767; 441; 111; 25;
  - **ESCALA_K2:** inclinação ≈ −2,0, porque o vazamento é um processo de 3.ª ordem com acoplamento J_ef ≈ 2κ²t/U²;
  - K_5 **CONSISTENTE** com K_4 (τ = 111,25 e 25,0).
- **H-b2 [H/F]:**
  - κ = 0: **IDENTICO** (a identidade congelada);
  - κ > 0: **DISTINGUIVEL**, com **VIRTUAL_K4** (inclinação ≈ 4,0, porque o processo virtual de menor ordem é de 4.ª
    ordem em κ);
  - **CONTAGEM_DE_PARCEIROS:** a flutuação do campo em A–C é 2,00 vezes maior com B presente em K_4/K_3 e 1,50 vezes em
    K_5/K_4. É a razão (n − 2)/(n − 3) entre os números de relações parceiras;
  - global **APOIADO**.

## 4. Parâmetros (rodada `completo`)

| Item | Valor |
|---|---|
| α | μ² = 1, C = 1; duas polarizações |
| grafos (decisão / controle) | K40 / K24; R3_1024 (semente 3502) / R3_512 (3501); R6_512 (3504) / R6_256 (3503); TRI24 / TRI16 (toro L × L, grau 6). Arestas congeladas em `dados/grafos_B35.json` |
| a1 | 200 triplos (semente 11), com B vizinho comum de A e C; "aceso" se N·min(v_A², v_C²) ≥ 0,5; exato se v_B² ≤ 10⁻²⁴ num autoespaço de dimensão ≥ 2; graduado se contraste min(v_A², v_C²)/v_B² ≥ 100; verificação no campo inteiro nos 20 primeiros |
| a2 | os 40 primeiros triplos; transplante em G−B com T = 200 (4 001 instantes); região R_AC = relações de A ou de C que não tocam B; entropia de von Neumann do vácuo |
| a3 | fontes s = 0, N/4, N/2, 3N/4; u₀ = Rᵀe_s/√d_s; T = 10 (K), 20 (R3), 12 (R6), 16 (TRI16), 25 (TRI24); 2 001 instantes; chegada = primeiro instante com 50% do próprio máximo; corte: K d = 1; R maior d com bola ≤ N/2; TRI L/2 − 2 |
| β | U = 1, D = 0,5, C = 0,5, t = 0,1; κ ∈ {0; 0,0125; 0,025; 0,05; 0,1; 0,2} |
| b1 | K_4 (A = 0, B = 1, C = 2, D = 3); quantum m = ±1 em A–C sobre o vácuo; passo 0,05 até t = 100 e depois 0,5 até 30 000; limiar 0,1 em max(r_B, q_B), descontado o vácuo. K_5: κ = 0,1 e 0,2, m = +1, passo 0,25 até 400 |
| b2 | K_4 × K_3 em todos os κ; K_5 × K_4 em κ ∈ {0,0125; 0,025; 0,05}; observáveis ⟨P_e⟩ e ⟨M_e²⟩ em AC, AD e CD, e ⟨P_AC P_AD⟩ |

## 5. Protocolo

1. `python -I src/testar_avaliador_B35.py` (79 ramos).
2. `python -I src/rodar_B35.py completo resultados` (checkpoint atômico por caso; relançar retoma).
3. `python -I src/avaliar_B35.py resultados` → `resultados/avaliacao_B35.json`.
4. Relatório: Objetivo → Hipóteses → Parâmetros → Protocolo → Medidas → Resultados → Controles → Interpretação; pós-hoc
   separado.

## 6. Medidas

- **a1:** para cada triplo, o melhor estado exato e o melhor graduado. Para os 20 primeiros, construção do quantum no
  campo inteiro: frações de carga contra v², dispersão de frequência (tem de dar 0), soma das energias, carga de B,
  energia nas relações de B, ΔS₂ linear e circular das estrelas de A, B e C.
- **a2:** δ = média, em A e C, de |fração média em G−B − fração em G| / fração em G; entropia do vácuo de R_AC com B
  presente e removido; conferência da identidade congelada (a matriz K do grafo com as relações de B desligadas e a de
  G−B, diferença máxima).
- **a3:** fração da energia do quantum no termo de vértice de cada GMFt contra o tempo; tempos de chegada; distâncias;
  bolas; soma das energias em t = 0 e T e comparação da redução ao espaço dos vértices com o campo inteiro (só na 1.ª
  fonte).
- **b1:** τ de seleção; r_B(t) e q_B(t) amostrados; simetria B↔D; norma; vácuo (E₀, gap, ⟨n_ligadas⟩).
- **b2:** observáveis do vácuo nas relações que não tocam B; D = maior diferença; razão de ⟨M_AC²⟩.

## 7. Regras de decisão (congeladas; `src/avaliar_B35.py`; testadas em 79 ramos)

**a1 (por grafo).**
- **INCONCLUSIVO** se alguma verificação falhar: erro de modo > 10⁻⁸, dispersão de frequência > 10⁻⁸ ou |soma − 1| > 10⁻⁸;
- **INSUFICIENTE** com menos de 50 triplos;
- **EXATA** se a fração exata f_e ≥ 0,9;
- **GRADUADA** se f_e + f_g ≥ 0,9 (f_g = graduados não exatos);
- **RARA** se f_e + f_g ≥ 0,1;
- **SEM_SELECAO** nos outros casos;
- **lema**, reportado: CONFIRMADO se nenhum triplo verificado tem B com carga ≤ 10⁻¹² e energia nas relações ≤ 10⁻¹².

**a2 (por grafo; triplos válidos ≥ 15, senão INSUFICIENTE).**
- **T2** pela mediana de δ: **INDEPENDENTE** se ≤ 0,01; **FRACA** se ≤ 0,2; **DEPENDENTE** acima disso;
- **T3** pela mediana de |ΔS|/S: **DISTINGUIVEL** se ≥ 10⁻³; **INDISTINGUIVEL** se ≤ 10⁻¹⁰; **INTERMEDIARIO** entre os dois;
  **INCONCLUSIVO** se a identidade congelada falhar (diferença > 10⁻¹²).

**a3 (por grafo).** Cascas: as distâncias 1 ≤ d ≤ corte com pelo menos 3 vértices chegados; ρ de Spearman com postos
médios; espalhamento = desvio-padrão de t / T.
1. **INCONCLUSIVO** se a conferência de energia falhar (> 10⁻⁸);
2. **INSUFICIENTE** se alguma fonte tiver menos de 10 vértices analisados ou mais de 10% sem chegada;
3. **SEM_ORDEM** se todas as fontes tiverem uma só casca e espalhamento ≤ 0,02;
4. **ORDENADA** se todas as fontes tiverem ≥ 3 cascas com médias estritamente crescentes e a mediana de ρ for ≥ 0,6;
5. **PARCIAL** se todas tiverem ≥ 2 cascas crescentes;
6. **SEM_ORDEM** se ρ < 0,3 e as médias não forem todas crescentes;
7. **INTERMEDIARIO** nos outros casos.

**Controle de tamanho.** A decisão é a do tamanho maior.
- Em a1 e a2, o menor tem de dar a mesma classe; se não der, o grafo fica **INCONCLUSIVO**.
- Em a3, o menor é só reportado: o número de cascas antes de saturar cresce com N por construção.

**Globais α.**
- **G1:**
  - INCONCLUSIVO se algum grafo for INCONCLUSIVO, INSUFICIENTE ou faltar;
  - **EXATA_SO_COM_DEGENERESCENCIA** se K e TRI forem EXATA e R3 e R6 forem GRADUADA ou RARA;
  - **EXATA_GERAL** se todos forem EXATA;
  - **SEM_SELECAO_GERAL** se todos forem SEM_SELECAO;
  - **MISTO** nos outros casos.
- **G2:**
  - INCONCLUSIVO, como em G1;
  - **INDEPENDENCIA_SO_NO_COMPLETO** se K for INDEPENDENTE e R3, R6 e TRI forem FRACA ou DEPENDENTE;
  - **INDEPENDENCIA_GERAL** se todos forem INDEPENDENTE;
  - **DEPENDENCIA_GERAL** se nenhum for INDEPENDENTE;
  - **MISTO** nos outros casos.
- **G2b:** **ESCURO_DISTINGUIVEL_DO_AUSENTE** se todos forem DISTINGUIVEL; **ESCURO_IGUAL_AO_AUSENTE** se todos forem
  INDISTINGUIVEL; MISTO ou INCONCLUSIVO nos outros casos.
- **G3:**
  - INCONCLUSIVO se algum grafo for INCONCLUSIVO, INSUFICIENTE ou faltar;
  - **SEM_ORDEM_NA_REDE** se TRI não for ORDENADA;
  - **ORDEM_POR_DISTANCIA_DE_GRAFO** se K for SEM_ORDEM e R3 ou R6 for ORDENADA;
  - **ORDEM_SO_COM_GEOMETRIA** se K for SEM_ORDEM e nenhum R for ORDENADA;
  - **MISTO** nos outros casos.

**b1 (por κ).**
- **INCONCLUSIVO** se:
  - os dois sentidos do saca-rolha discordarem (|τ₊ − τ₋| > 0,5, ou um persiste e o outro não);
  - a simetria B↔D ou a norma errarem por mais de 10⁻⁹;
  - o vácuo não for o vazio vestido: gap < 0,5, E₀ > 10⁻¹² ou ⟨n_ligadas⟩ > 2·n_rel·κ².
- **PERSISTENTE** se não houver cruzamento até T_max;
- **TRANSITORIA** se τ > 5;
- **SEM_SELECAO** se τ ≤ 5.
- **Escala:** inclinação de ln τ contra ln κ em κ ∈ {0,0125; 0,025; 0,05}. **ESCALA_K2** se estiver em [−2,3; −1,7];
  **OUTRA_ESCALA** fora disso; **INSUFICIENTE** se algum dos três κ não for TRANSITORIA.
- **Controle K_5** (reportado): **CONSISTENTE** se |τ₅ − τ₄|/τ₄ ≤ 0,2.

**b2 (por κ).**
- **INCONCLUSIVO** se o gap for < 0,5;
- **IDENTICO** se D ≤ 10⁻¹³;
- **DISTINGUIVEL** se D ≥ 10⁻¹² e |razão − 1| ≥ 0,05;
- **INTERMEDIARIO** nos outros casos.
- **Escala** de ln D em κ ∈ {0,0125; 0,025; 0,05}: **VIRTUAL_K4** se estiver em [3,6; 4,4]; **OUTRA_ESCALA** fora disso;
  **INSUFICIENTE** se algum dos três κ não for DISTINGUIVEL.
- **Lei dos parceiros** (reportada): **CONTAGEM_DE_PARCEIROS** se, em κ = 0,0125, |razão(K_4/K_3) − 2| ≤ 0,02 e
  |razão(K_5/K_4) − 1,5| ≤ 0,02.

**G4 (sombreado dinâmico).**
- **INCONCLUSIVO** se faltar κ = 0 ou algum κ da escala, se algum caso for INCONCLUSIVO ou se a escala de b1 for
  INSUFICIENTE;
- **REFUTADO** se b1 for PERSISTENTE em todos os κ > 0, ou se b2 for IDENTICO em todos os κ > 0;
- **APOIADO** se valerem todas as condições:
  - b1(0) = PERSISTENTE e b2(0) = IDENTICO;
  - b1 = TRANSITORIA e b2 = DISTINGUIVEL nos três κ da escala;
  - escala de b1 = ESCALA_K2;
- **PARCIAL** nos outros casos.

A escala de b2, a lei dos parceiros e o controle K_5 são reportados ao lado.

## 8. Controles, memória e tempo (estimados antes de congelar)

| Controle | Previsão | Limite |
|---|---|---|
| a1: frações de carga no campo inteiro × v² | ≤ 10⁻¹⁵ (fumaça: 0) | 10⁻⁸ |
| a1: dispersão de frequência do estado estacionário | 0 | 10⁻⁸ |
| a3: soma das energias em 0 e T; redução aos vértices | 10⁻¹⁵ (fumaça: ≤ 3×10⁻¹⁵) | 10⁻⁸ |
| a2: identidade congelada | 0 | 10⁻¹² |
| b1: sentidos ±1 | iguais (fumaça: idênticos) | 0,5 |
| b1: simetria B↔D, norma | ≤ 3×10⁻¹² | 10⁻⁹ |
| a1, a2: classes no tamanho menor | iguais às do maior (exploração) | iguais |

**Memória e tempo.**
- Os maiores objetos de α são as matrizes de covariância das relações: TRI24 tem 1 728 relações (X e P de 24 MB cada).
- Em a2, a diagonalização é refeita para cada um dos 40 triplos, sem inverter nada maior que a região (≤ 76 relações).
- β: K_5 tem setores de 184 756 e 167 960 estados, com cerca de 4×10⁶ elementos não nulos. A evolução é em passos de
  expm_multiply, sem guardar a trajetória inteira.
- **Fumaça medida:** 87 s e 0,55 GB de pico.
- **Rodada estimada:** 12–20 min e ≤ 2 GB. Cabe aqui na nuvem (2 CPUs, 8 GB).

## 9. O que foi tentado e mudado antes de congelar

1. **Salto t = 0,25 → 0,1 (β).** Com t = 0,25, o estado fundamental de K_5 deixa de ser o vazio e vira um condensado de
   cordas, com todas as relações ligadas (E₀ = −1,38 em κ = 0). É a fase de "condensado de cordas" de KMS. Com t = 0,1,
   o bloco todo ligado de K_5 fica em E = 7,44 e o vazio vestido é o fundamental em K_3, K_4 e K_5. [M] A fase da base
   depende da conectividade: mais relações parceiras favorecem o condensado.
2. **Spearman com postos médios** (empates em d), em vez de postos ordinais (exploração).
3. **Controle de tamanho de a3 não estrito.** Em R6_256, uma fonte só tem 2 cascas antes de saturar; a classe pode mudar
   com N por construção.
4. **T5 com cascas antes da saturação.** Em R6, as últimas cascas cobrem quase todo o grafo e a média não cresce mais.
5. **Primeira versão do avaliador:** um caso sintético de "PARCIAL com ρ baixo" caía em SEM_ORDEM porque o ruído
   quebrava a monotonia das médias. Corrigido no teste (mais vértices por casca), não na regra.

## 10. Leitura prevista de cada resultado [H]

- **G1 EXATA_SO_COM_DEGENERESCENCIA:** a base acende A e C com B escuro sem que nada no hamiltoniano escolha B. A
  escuridão exata exige degenerescência: em K_N ela vem da ausência de geometria, na rede da simetria. No grafo aleatório
  a escuridão é só graduada.
- **Lema CONFIRMADO:** num grafo fixo, um B entre A e C nunca fica inteiramente escuro. Ou está carregado, ou está
  atravessado. Sombrear de verdade exige desligar relações, e essa é a razão estrutural da correção 1.
- **G2 INDEPENDENCIA_SO_NO_COMPLETO:** em K_N a ativação de A e C não depende de B. Nos grafos esparsos, o GMFt escuro
  faz parte do tecido relacional dos vizinhos: tirá-lo desfaz o estado.

  > **Analogia médica:** é a diferença entre o sangue e um tecido. Retirar uma célula do sangue não muda nada para as
  > outras, porque o hormônio chega a todas igualmente. Num tecido, retirar uma célula quiescente muda o microambiente
  > das vizinhas, que estavam ligadas a ela por junções, mesmo que ela não estivesse ativa.

- **G2b ESCURO_DISTINGUIVEL_DO_AUSENTE:** no campo livre, um B escuro ainda tem relações que carregam emaranhamento do
  vácuo. As relações vizinhas "sabem" que ele está lá.
- **G3 ORDEM_POR_DISTANCIA_DE_GRAFO:** a ordem temporal não exige geometria, só distância de grafo. Em K_N, onde ninguém
  está perto ou longe, não há ordem nenhuma. Se sair ORDEM_SO_COM_GEOMETRIA, prevalece a leitura de Mario.
- **G4 APOIADO:** na QG original, B sombreado (relações desligadas pela energética) é transitório quando as relações
  podem flutuar, com τ ∝ κ⁻². B sombreado só se distingue de B ausente pelas relações **virtuais**, e a diferença cresce
  como κ⁴. Com κ = 0 os dois são idênticos, o que deixa a Q11 mais aguda: a identidade de um GMFt totalmente sombreado
  não tem portador num grafo congelado.

  > **Analogia médica:** é o músculo em repouso comparado ao músculo desnervado. Em repouso ele não contrai (sombreado),
  > mas a placa motora mantém descargas espontâneas em miniatura (os potenciais de placa em miniatura), que o
  > eletromiograma registra. O músculo desnervado não tem nada disso. As relações virtuais são os "potenciais em
  > miniatura" da base.

## 11. Limites

- α é o limite livre (gaussiano) do campo de KMS, sem o vínculo de Gauss duro nem as cordas como objetos.
- Os grafos são retratos congelados; só a β tem relações dinâmicas, e só em K_3 a K_5.
- Os parâmetros são escolhidos, não derivados.
- "Ativação" é a carga no vértice (o termo C); outras leituras, como as relações excitadas ou o ΔS₂ da estrela, são
  reportadas, não decididas.
- A bancada não toca a reconstrução de informação (OLA-0-RR1/RR2, Q14, Q20), nem R/R′, nem a Q11 (B37).
- Não é uma fronteira holográfica de verdade e nenhuma geometria é reconstruída. Precisão dupla.

## 12. Arquivos do pré-registro

`HRF_B35_PROTOCOLO_2026-10-21_1149-clau.md` (este), `LEIAME_B35.md`, `FUMACA_B35.md`, `dados/grafos_B35.json`,
`src/b35_grafos.py`, `src/gerar_grafos_B35.py`, `src/b35a_campo.py`, `src/b35b_exato.py`, `src/rodar_B35.py`,
`src/avaliar_B35.py`, `src/testar_avaliador_B35.py`, `fumaca/` (saída, avaliação e log),
`HRF_B35_hashes_antes_da_execucao_2026-10-21_1149-clau.txt`.

## Referências

- T. Konopka, F. Markopoulou, L. Smolin, *Quantum Graphity*, hep-th/0611197 (2006) — campo nas relações de K_N; fases;
  condensado de cordas.
- T. Konopka, F. Markopoulou, S. Severini, Phys. Rev. D 77, 104029 (2008).
- A. Hamma, F. Markopoulou, S. Lloyd, F. Caravelli, S. Severini, K. Markström, Phys. Rev. D 81, 104032 (2010).
- R. Bauerschmidt, J. Huang, H.-T. Yau, Commun. Math. Phys. 369, 523 (2019); Á. Backhausz, B. Szegedy, Ann. Probab. 47,
  1677 (2019) — autovetores deslocalizados de grafos regulares aleatórios.
- B. Reznik, Found. Phys. 33, 167 (2003) — correlações do vácuo lidas por detectores.
- Internas: nota de interface OLA × B33 (21/10, 06h59); nota R/R′ (20/10); nota provisória dos vértices sombreados
  (20/10); documento inaugural da Hipótese Ola (20/10); B33 (relatório 21/10, 00h02; funções de uma partícula adaptadas
  de `b33a_quantico.py`); análise adversarial de mecanismos conhecidos (21/10; controles C2–C4).
