# Resultados B35

Relatório: HRF_B35_RELATORIO_2026-10-21_125048.md

{
  "G1_selecao": "EXATA_SO_COM_DEGENERESCENCIA",
  "G2_independencia": "INDEPENDENCIA_SO_NO_COMPLETO",
  "G2b_escuro_vs_ausente": "ESCURO_DISTINGUIVEL_DO_AUSENTE",
  "G3_ordem": "ORDEM_POR_DISTANCIA_DE_GRAFO",
  "G4_sombreado_dinamico": "APOIADO"
}

As pastas fumaca/ e entradas/ são antecedentes, não os resultados desta rodada. A rodada completa está em resultados/.
