# B39 — leia-me (pré-registro)

**Autoria:** Mario José do Canto Filho, MD · desenho, código e fumaça: Claude (`-clau`)

A onda de lâmpadas com a rede sempre ligada. A rede (base) tem energia permanente; uma mensagem fraca chama uma casa
por vez e só fecha o relé dela; a lâmpada acende com a energia da rede. Três mensagens (difusão = telecomando,
endereçada, genérica), dois relés (o que trava → frente; o que solta → ola), três bases (livre, linha com espaço, SYK).
O protocolo completo está no arquivo `HRF_B39_PROTOCOLO_*.md`.

## Antes de rodar

1. Python ≥ 3.10 com numpy, scipy e matplotlib.
2. Descompacte o pacote numa pasta nova e entre nela.
3. Confira os hashes: `sha256sum -c` sobre as linhas do arquivo `HRF_B39_hashes_antes_da_execucao_*.txt` (ou compare
   à mão).

## Rodar (só depois do "pode rodar")

```
python -I src/testar_avaliador_B39.py fumaca      # TODOS OS 143 RAMOS CONFEREM
python -I src/conferir_pecas_B39.py fumaca        # TODAS AS 14 PEÇAS CONFEREM
python -I src/rodar_B39.py --modo completo --parte todas
python -I src/avaliar_B39.py resultados
```

Em paralelo (3 núcleos, ≥ 4 GB): três terminais, um com `--parte L` (depois `--parte C`), um com `--parte S20` e um
com `--parte S24`. Cada semente grava um checkpoint em `resultados/`; relançar retoma de onde parou.

Tempo: ≈ 45 min em paralelo, ≈ 1,5 h em sequência. Memória: < 2 GB por processo.

## Devolver

Compacte a pasta `resultados/` inteira (checkpoints, `config_B39.json`, `avaliacao_B39.json`, logs) e anexe na
conversa.
