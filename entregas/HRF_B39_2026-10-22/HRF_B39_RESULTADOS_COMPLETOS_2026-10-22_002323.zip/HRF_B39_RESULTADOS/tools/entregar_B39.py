"""Auditoria, tabelas e figuras após avaliação; não altera fontes congeladas."""
import pathlib,json,hashlib,zipfile,datetime,csv,platform,re
from zoneinfo import ZoneInfo
import numpy as np,scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=pathlib.Path(__file__).resolve().parents[1]
cfg=json.loads((P/'resultados/config_B39.json').read_text());assert cfg['modo']=='completo'
r=json.loads((P/'resultados/avaliacao_B39.json').read_text())
recs=[json.loads(p.read_text())for p in sorted((P/'resultados').glob('*.json'))if not p.name.startswith(('config','avaliacao'))]
expected={f'L_M{M}_s{39500+100*i+k}.json'for i,M in enumerate([400,800,1600])for k in range(4)}|{'C_H10.json'}|{f'S20_N20_s{k}.json'for k in range(3931,3935)}|{'S24_N24_s3941.json'}
actual={p.name for p in (P/'resultados').glob('*.json')if not p.name.startswith(('config','avaliacao'))};assert actual==expected,(expected-actual,actual-expected)
assert len(recs)==18
for x in recs:assert len(x['rodadas'])==(30 if x['parte']=='L'else 8)
coverage=dict(checkpoints_esperados=18,checkpoints_obtidos=18,rodadas_obtidas=sum(len(x['rodadas'])for x in recs),sementes_e_tamanhos='EXATOS',L=12,C=1,S20=4,S24=1)
(P/'auditoria_execucao/cobertura.json').write_text(json.dumps(coverage,indent=2))
ss=[x for x in recs if x['parte']=='S']
controls=dict(gap_S_min=min(x['gap']for x in ss),erro_norma_S_max=max(abs(q['norma']-1)for x in ss for q in x['rodadas']),sementes_S_validas={n:r['S'][n]['validas']for n in ['S20','S24']},condicionamento_motor_max=max(v for x in recs if x['parte']!='S'for v in x['cond'].values()),memoria_pico_processo_GB={n:max(x['mem_gb']for x in recs if x.get('rotulo',x['parte'])==n)for n in ['L','C','S20','S24']})
(P/'auditoria_execucao/controles_resumo.json').write_text(json.dumps(controls,indent=2))
(P/'auditoria_execucao/versoes.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,plataforma=platform.platform()),indent=2))
for d in ['tabelas','figuras']:(P/d).mkdir(exist_ok=True)
def tabela(name,rows):
 with(P/'tabelas'/name).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
tabela('previsto_x_obtido.csv',[dict(teste=k,**v)for k,v in r['previsto_x_obtido'].items()])
tabela('execucao_por_caso.csv',[dict(parte=x.get('rotulo',x['parte']),tamanho=x.get('M',x.get('N',x.get('Mc'))),semente=x.get('semente'),rodadas=len(x['rodadas']),tempo_s=x['tempo_s'],pico_mem_GB=x['mem_gb'])for x in recs])
rows=[]
for M in [400,800,1600]:
 for k,v in r['L'][f'M{M}']['T1'].items():
  if not k.endswith('picos_med'):rows.append(dict(M=M,condicao=k,classe=v[0],fracao=v[1],margem_mediana=v[2]))
tabela('L_margens_por_tamanho.csv',rows)
# Figura descritiva da primeira semente de decisão; demais disponíveis nos dados.
x=next(x for x in recs if x['parte']=='L'and x['M']==1600 and x['semente']==39700)
fig,axs=plt.subplots(3,2,figsize=(11,8),sharex=True,sharey=True,layout='constrained')
for i,tipo in enumerate(['difusao','alvo','generica']):
 q=next(q for q in x['rodadas']if q['teste']=='T1'and q['tipo']==tipo and q['ordem']=='leste_oeste'and q['sentido']==1)
 for j,modo in enumerate(['trava','solta']):
  c=q['curva_brilho_'+modo];ts=np.array(c['ts'])/q['tau'];b=np.array(c['v']).T
  im=axs[i,j].imshow(b,origin='lower',aspect='auto',extent=[ts[0],ts[-1],-.5,b.shape[0]-.5],vmin=0,vmax=1,cmap='Oranges',interpolation='nearest')
  for k in range(10):axs[i,j].plot([k,k+1.25],[k,k],color='.35',lw=.5)
  axs[i,j].set_title(f"{tipo} / {modo}: margem {q['margem_'+modo]:.3g}; acerto {q['acerto_'+modo]:.2f}",fontsize=10)
for a in axs[:,0]:a.set_ylabel('Casa (0 = leste)')
for a in axs[-1,:]:a.set_xlabel('Tempo / τ')
fig.colorbar(im,ax=axs,label='Brilho normalizado',shrink=.7)
fig.suptitle('B39: M=1600, semente 39700, leste→oeste, sentido +1\nExemplo descritivo; decisão usa todas as sementes e ordens')
fig.savefig(P/'figuras/B39_lampadas.png',dpi=160);fig.savefig(P/'figuras/B39_lampadas.pdf');plt.close(fig)
fig,axs=plt.subplots(1,2,figsize=(12,4.5),layout='constrained')
for tipo in ['difusao','alvo','generica']:
 k=tipo+('_ambos_solta'if tipo=='generica'else'_1_solta')
 axs[0].plot([400,800,1600],[r['L'][f'M{m}']['T1'][k][2]for m in [400,800,1600]],'o-',label=tipo)
axs[0].axhline(1,ls=':',color='gray',label='existência');axs[0].axhline(4,ls='--',color='gray',label='folga 4');axs[0].set(yscale='log',xlabel='Tamanho M',ylabel='Margem mediana da ola',title='L: mensagem e tamanho');axs[0].legend()
L=r['L']['M1600']
for tipo in ['difusao','alvo']:
 vals=L['T4_valores'][tipo]['intervalo_rel'];tt=sorted(float(k)for k in vals)
 axs[1].plot(tt,[vals[str(t)]for t in tt],'o-',label='L '+tipo)
vals=r['C']['T4_valores'];tt=sorted(float(k)for k in vals)
axs[1].plot(tt,[vals[str(t)]for t in tt],'s--',label='C: duração do pulso')
axs[1].axhline(1,color='gray',ls=':');axs[1].set(xlabel='τ (L) / duração (C)',ylabel='Intervalo / referência de cada modelo',title='Tempos: referências diferentes em L e C');axs[1].legend()
for a in axs:a.grid(alpha=.25)
fig.savefig(P/'figuras/B39_margens_tempos.png',dpi=160);fig.savefig(P/'figuras/B39_margens_tempos.pdf');plt.close(fig)
stamp=datetime.datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%d_%H%M%S')
preds=r['previsto_x_obtido'];matches=sum(v['confere']for v in preds.values())
summary=dict(L=L['global'],C=r['C']['global'],S20=r['S']['S20']['global'],S24=r['S']['S24']['global'],LxC=r['LxC'],OLA=r['OLA'],controle_M=r['L']['controle_M'],controle_N24=r['S']['controle_N24'],previsoes_conferem=matches,previsoes_total=len(preds))
(P/'auditoria_execucao/decisoes_resumo.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
lines=['# HRF B39 — Relatório da execução completa',f'\n{stamp}, America/Sao_Paulo. Autoria HRF: Mario José do Canto Filho, MD. Execução: Codex.','\n## Objetivo','[M] Testar frente e ola em uma rede permanentemente energizada, comparando base livre onipresente (L), linha com espaço (C) e detecção SYK (S).','\n## Hipóteses','[M/H] Previsões pré-registradas: ONDA_PROGRAMADA em L, ONDA_COM_CAMINHO em C, ONDA_ESQUECIDA em S e separação entre programação e propagação. A ola de difusão e a frente genérica foram declaradas frágeis. A tabela previsto × obtido abaixo preserva todas as divergências.','[M] Os parâmetros e limiares foram escolhidos após explorações em outras sementes. Esta execução confirma nas sementes congeladas, não é previsão inteiramente cega.','\n## Parâmetros','[M] L: M=400/800/1600, quatro sementes por tamanho, 30 rodadas por semente. C: dez casas em linha de 800 sítios, oito rodadas. S20: quatro sementes; S24: uma; oito rodadas por semente. Parâmetros completos no protocolo e resultados/config_B39.json. Decisão L em M1600; controle M800; decisão SYK N20 e controle N24.','\n## Protocolo','[D] Autorização recebida: “Pode rodar tudo”. Testes iniciais concluídos: 143 ramos e 14 peças, incluindo 256 comparações margem/acerto. Hashes conferidos antes e depois. Execução congelada por partes, L seguido de C, em paralelo com S20 e S24; Python isolado e BLAS/OMP/MKL com uma thread por processo. Nenhuma fonte, semente, parâmetro ou tolerância foi modificada.','[M] Checkpoints atômicos por caso. Avaliação final com src/avaliar_B39.py original. Scripts tools/ somente supervisionam, conferem cobertura, organizam e desenham dados.','\n## Medidas','[M] Margens para relé que trava e que solta, fração de rodadas com margem>1, tempos de fechamento, intervalos relativos, brilho, força da mensagem, remoção/corte, eco, controle da rede e matrizes de ganho/vencedores em SYK. Figuras são descritivas e não mudam decisões.','\n## Resultados','```json',json.dumps(summary,ensure_ascii=False,indent=2),'```','\n| Teste | Previsto | Obtido | Confere |','|---|---|---|---|']
lines += [f"| {k} | {v['previsto']} | {v['obtido']} | {'sim'if v['confere']else'NÃO'} |"for k,v in preds.items()]
lines+=['\n[M] L em M1600 — medidas e decisões completas:', '```json',json.dumps(L,ensure_ascii=False,indent=2),'```','\n[M] Linha C:', '```json',json.dumps(r['C'],ensure_ascii=False,indent=2),'```','\n[M] SYK:', '```json',json.dumps(r['S'],ensure_ascii=False,indent=2),'```','\n## Controles','```json',json.dumps(coverage,indent=2),json.dumps(controls,indent=2),'```','\n[M] Tempo e máquina:', '```json',(P/'auditoria_execucao/execucao_resumo.json').read_text(),'```','\n[M] Hashes originais, saídas dos testes, logs por parte e versões constam em auditoria_inicial/ e auditoria_execucao/. Fumaça original preservada em fumaca/; resultados desta rodada em resultados/.','\n## Interpretação','[D] Resultado principal: ONDA_SEM_CAMINHO_SO_NA_BASE_LIVRE. L foi ONDA_PROGRAMADA, C ONDA_COM_CAMINHO, L×C SEPARACAO e SYK ONDA_ESQUECIDA em N20 e N24. Todos os 34 itens previsto × obtido conferiram; controles M e N24 CONSISTENTES.', '[M] Em M1600, frente de difusão: margem mediana 10,4301 e 100% das rodadas com margem>1. Ola de difusão: margem 1,85786 e 83,33% das rodadas com margem>1, portanto ONDA_FRAGIL, não sucesso em todas as rodadas. Endereçada: frente/ola com margens 1891,41/83,1022 e 100% acima de 1. Genérica: frente ONDA_FRAGIL (79,17%); ola SEM_ONDA. O sentido oposto deu SEM_ONDA na ola de difusão e alvo.', '[M] Sem perdas, o eco aumentou por fatores medianos 7,45 (difusão) e 10,94 (alvo). Remover uma casa deu razão de picos 0,999925; cortar a base livre deu 0,760508, com atraso relativo 0,025. Na linha, cortar deu razão 6,17×10⁻⁵, classificada BLOQUEADA. As cinco sementes SYK foram válidas; o maior erro de norma foi 2,08×10⁻¹⁴. Execução paralela: 2020,13 s (33min40s). Memória máxima por processo em L: 3,34 GB, acima da estimativa original, dentro da capacidade disponível.', '[D] As classes reportadas são as saídas literais do avaliador congelado. Divergências em itens auxiliares ou globais permanecem na tabela e no JSON, sem ajuste posterior.','[M] A onda programada em L é condicionada à sequência de mensagens e aos receptores/relés definidos. A regra de tudo ou nada é verificação de construção: o limiar foi posto à mão. O brilho vem de uma rede ideal que não sofre carga das lâmpadas. A classificação de velocidade usa intervalos e tolerâncias do protocolo; não deriva um princípio fundamental de incerteza.','[?] C e L têm topologias e perdas diferentes. SYK mede apenas detecção, sem rede nem relé; portanto, não é a mesma arquitetura completa das lâmpadas. N≤24, sementes finitas, precisão dupla; receptores são sítios extras. Nenhuma geometria é reconstruída. [H] A interpretação HRF permanece condicionada a esses modelos.','\n## Arquivos','Pacote autocontido com entrada original, protocolo, fontes, fumaça, resultados, avaliação, logs, testes, máquina/versões, figuras e tabelas. Manifesto original preservado; MANIFEST_SHA256_RESULTADOS.txt cobre os arquivos entregues.']
report=P/f'HRF_B39_RELATORIO_{stamp}.md';report.write_text('\n'.join(lines)+'\n')
(P/'LEIA_PRIMEIRO_RESULTADOS.md').write_text(f'# B39 — Resultados completos\n\nRelatório: {report.name}\n\n'+json.dumps(summary,ensure_ascii=False,indent=2)+'\n\nResultados desta rodada em resultados/. Fumaça e entrada original são antecedentes.\n')
files=[p for p in sorted(P.rglob('*'))if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256_RESULTADOS.txt']
(P/'MANIFEST_SHA256_RESULTADOS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(P).as_posix()+'\n'for p in files))
archive=pathlib.Path('/workspace')/f'HRF_B39_RESULTADOS_COMPLETOS_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts:z.write(p,pathlib.Path('HRF_B39_RESULTADOS')/p.relative_to(P))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
receipt=dict(archive=str(archive),report=str(report),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)
pathlib.Path('/workspace/HRF_B39_ENTREGA_LOCAL.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
