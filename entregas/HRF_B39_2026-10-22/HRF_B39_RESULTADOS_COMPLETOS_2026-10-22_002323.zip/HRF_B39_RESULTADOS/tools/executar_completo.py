import os,sys,pathlib,json,time,datetime,subprocess
P=pathlib.Path(__file__).resolve().parents[1]
py='/workspace/my-ai-workflow/.venv/bin/python3'
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TZ='America/Sao_Paulo')
t0=time.time();jobs={};statuses={};handles=[]
def start(part):
 f=(P/'auditoria_execucao'/('execucao_'+part+'.txt')).open('w');handles.append(f)
 jobs[part]=subprocess.Popen([py,'-I','src/rodar_B39.py','--modo','completo','--parte',part],cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT)
 print('iniciada',part,flush=True)
start('L')
while not(P/'resultados/config_B39.json').exists():
 if jobs['L'].poll()is not None:raise RuntimeError('L terminou antes da configuração')
 time.sleep(.1)
start('S20');start('S24')
while len(statuses)<4:
 for part,p in list(jobs.items()):
  if part not in statuses and p.poll()is not None:
   statuses[part]=p.returncode;print('terminou',part,'exit',p.returncode,flush=True)
   if part=='L':start('C')
 time.sleep(1)
for f in handles:f.close()
r=dict(inicio_utc=datetime.datetime.fromtimestamp(t0,datetime.timezone.utc).isoformat(),fim_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tempo_parede_s=time.time()-t0,exit_codes=statuses,threads_por_processo=1,partes_paralelas_max=3,cpu_quota=pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),memoria_limite=pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip())
(P/'auditoria_execucao/execucao_resumo.json').write_text(json.dumps(r,indent=2));assert all(v==0 for v in statuses.values()),statuses
