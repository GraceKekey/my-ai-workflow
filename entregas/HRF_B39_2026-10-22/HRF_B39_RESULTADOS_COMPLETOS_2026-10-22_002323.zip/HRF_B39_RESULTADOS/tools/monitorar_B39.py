import pathlib,datetime
P=pathlib.Path(__file__).resolve().parents[1]
print(datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'))
for part in ['L','C','S20','S24']:
 f=P/'auditoria_execucao'/('execucao_'+part+'.txt');ls=f.read_text().splitlines()if f.exists()else[]
 print(part,ls[-1]if ls else 'aguardando')
print('Checkpoints:',{p:len(list((P/'resultados').glob(p)))for p in ['L_M*_s*.json','C_H*.json','S20_N*_s*.json','S24_N*_s*.json']})
