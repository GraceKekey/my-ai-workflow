# HRF B39 — A onda de lâmpadas com a rede sempre ligada: o telecomando numa base onipresente
## Frente (relé que trava) e ola (relé que solta); difusão, endereçada e genérica; base livre, linha com espaço e SYK — protocolo pré-registrado

**Data:** 21 de outubro de 2026 (America/Sao_Paulo) — Claude (`-clau`) · fluxo ímpar
**Autoria:** Mario José do Canto Filho, MD · desenho, código e fumaça: Claude
**Decisões de Mario que fixam esta bancada (21/10):**
- 19h07 — o pedido: "imaginemos que vem uma mensagem pela rede para automaticamente começar a acender a lâmpada de cada
  casa do leste para o oeste da cidade em sequências de um segundo, cada uma depois da outra. Isso vai criar uma onda de
  acendimento de lâmpadas. Vamos testar isso."
- Logo depois, três escolhas:
  - endereço "os dois, em blocos": frequência + forma da fiação como bloco principal, só a frequência como controle;
  - bases: livre + linha + SYK;
  - lâmpada "emite + controle reversível" (substituída às 19h58, abaixo).
- 19h58 — a objeção que refez a bancada: "Uma rede elétrica numa cidade está sempre ligada. Ela tem energia permanente,
  toda ela constantemente." Na primeira versão (nunca congelada), a mensagem trazia a energia da luz; agora a energia
  vem da rede, e a mensagem só comanda o relé (§9).
- ≈ 20h00 — testar os dois relés, o que **trava** e o que **solta**; a SYK fica **só com a detecção**.
- 20h03 — o Ripple Control (telecomando por sinais sobrepostos à rede): a concessionária sobrepõe uma frequência de
  controle à tensão normal; o sinal percorre a rede de distribuição e alcança muitos consumidores; um receptor ou relé
  sintonizado identifica o comando destinado a ele; o relé liga ou desliga a carga. A **difusão** (§0) é essa imagem e
  passa a ser a condição central.

**Nada roda sem "pode rodar".**
**Vertente:** HRF-OLA. Antecedentes: relatório da B37 (21/10, 18h39); nota sobre variáveis ocultas e base onipresente
(21/10, 17h29); esboço da B37 (21/10, 14h24).

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 0. Arquitetura usada [D, 21/10]

| Termo | Nesta bancada |
|---|---|
| **base** | L: osciladores ligados todos com todos (GOE), sem espaço e sem junções (decisão 2), **com perdas γ_b em todo sítio, repostas pela fonte**. C (controle com espaço): uma linha com molas entre vizinhos. S: férmions de Majorana com a interação SYK. |
| **rede** | Uma oscilação permanente na frequência Ω_r = 1,0, abaixo da banda da base (1,41–2,45) e das casas (1,62–2,34), com a mesma força em todos os sítios. Está ligada desde sempre: a bancada usa o estado estacionário exato, sem transiente. |
| **mensagem (telecomando)** | Fraca (F0 = 0,02), na frequência da casa chamada, com envelope sin² de duração τ e saca-rolha de sentido s. Leva só informação. |
| **casa** | Receptor + relé + lâmpada. Dez casas, de leste (0) a oeste (9). |
| **receptor** | Oscilador sintonizado em Ω_k (a bobina do relé), ligado à base pela fiação da casa, com amortecimento próprio γ_R = 0,02. Sente a rede e a mensagem. |
| **relé** | Lê a banda da casa: demodula o receptor na própria frequência e alisa com a inércia T_R = 20. **Trava:** fecha quando a leitura passa do limiar θ e não abre mais. **Solta:** fecha em θ e abre quando a leitura cai abaixo de θ/2 (histerese de relé real). |
| **lâmpada** | Ligada à rede pelo relé. A luz vem da rede: brilho normalizado, 1 = o brilho pleno que a rede dá a qualquer casa. |
| **frente** | Onda em que as casas acendem em sequência e ficam acesas (relé que trava). |
| **ola** | Pulso de luz que corre pela cidade: cada lâmpada acende na sua vez e apaga depois (relé que solta). |
| **margem** | Pelo menos um limiar comum (relés idênticos) faz a onda perfeita ⇔ margem > 1. A margem mede a largura dessa faixa de limiares (§6). |
| **folga** | A mediana da margem. Com folga ≥ 4, o limiar pode errar por um fator 2 para cada lado. |

**As três mensagens (L):**
- **difusão** — o telecomando. O mesmo sinal percorre a fiação de **todas** as casas (perfil Σ_k c_k); o endereço é só
  a frequência.
- **endereçada (alvo)** — o sinal percorre só a fiação da casa chamada (perfil c_k); o endereço é a frequência mais a
  forma da fiação.
- **genérica** — o sinal entra na base por um caminho aleatório, fora da fiação de qualquer casa; o endereço é só a
  frequência.

## 1. Objetivo

Numa cidade cuja rede está sempre ligada, com a mensagem fraca que só comanda os relés, medir:
- **T1, a onda:** a mensagem programada (uma casa por intervalo τ, em três ordens) produz a **frente** (relé que trava)
  e a **ola** (relé que solta)? Com qual mensagem: difusão, endereçada ou genérica? Nos dois sentidos do saca-rolha?
- **T3, tudo ou nada:** a lâmpada acende inteira ou não acende, qualquer que seja a força da mensagem?
- **T4, velocidade:** o intervalo entre as casas segue o programa (τ = 75, 150, 300, 600)? Há um limite de rapidez?
- **T5, dependência:** tirar uma casa muda as outras?
- **T6, corte:** cortar a base em duas metades impede a onda?
- **T7, eco:** o que muda se a base não tiver perdas (rede sem fonte que reponha)?
- **A rede:** sozinha, ela dispara algum relé? Ligada, ela muda os disparos?

E comparar com a **linha (C)**, em que a mensagem entra por uma ponta e caminha, e com a **SYK (S)**, em que só se mede
quem a base excita.

## 2. Modelos

### 2.1 L — base livre onipresente, com a rede sempre ligada [M]

- **Base:** K_base = W0² I + (2 W0 λ/√M) W, com W simétrica gaussiana (GOE), W0 = 2 e λ = 0,25 (banda ω ∈ [1,41; 2,45]).
  Perdas γ_b = 0,01 em todo sítio.
- **Receptores:** dez osciladores com Ω_k = 1,62 + 0,08 k, ligados a todos os sítios por K_ik = 2 W0 g c_ik/√M, com
  g = 0,05 e c_ik = ±1 (a fiação da casa k); amortecimento γ_R = 0,02.
- **Rede:** força Re[f e^{iΩ_r t}] com f_i = A/√M em todo sítio da base, A = 10, Ω_r = 1,0. Estado estacionário exato:
  X̂ = (K − Ω_r² + iΩ_r D)⁻¹ f e x_rede(t) = Re[X̂ e^{iΩ_r t}].
- **Mensagem:** no intervalo j (de jτ a (j+1)τ), chama a casa ordem[j] com
  F(t) = F0 sin²(π u) Re[e^{iΩ_k t} (P1 − i s P2)], u = t/τ − j:
  - P1 = o caminho da mensagem (normalizado): Σ_k c_k (difusão), c_k (alvo) ou um vetor aleatório u1 (genérica);
  - P2 = a resposta da base a esse caminho, W P1, ortogonalizada e normalizada (genérica: um segundo vetor aleatório u2).
- **Integração:** exata por autovalores da equação de primeira ordem, dt = 0,1. A mensagem parte do repouso. Como tudo
  é linear, a resposta é a soma da rede (analítica) com a mensagem (integrada).
- **Leitura do relé:** z = √(Ω/2) x + i p/√(2Ω), w = z e^{iΩt} e w̄_i = a w̄_{i−1} + (1 − a) w_i, com a = e^{−Δ/T_R} e
  amostra Δ = 0,5. A leitura é R = |w̄|². O valor inicial w̄(0) é o estacionário exato do filtro sob a rede.
- **Lâmpada:** ȧ = (γ_L/2)(r − a) e b = a², com γ_L = 0,2 e r ∈ {0, 1} o estado do relé.
- **Intervenções:**
  - T5: a casa 4 desligada da base;
  - T6: a base cortada em duas metades, com o acoplamento interno × √2 para manter a banda;
  - T7: a base sem perdas (γ_b = 0), com a rede no seu estado estacionário sem perdas.

### 2.2 C — linha com espaço (controle) [M]

- **Linha:** Mc = 800 sítios, K = (W0c² + 2κ) I − κ (T + Tᵀ), com W0c = 1,6 e κ = 0,4 (banda ω ∈ [1,6; 2,04]).
- **Pontas:** absorventes, com 60 sítios de amortecimento 0,15 × rampa². O interior não tem perdas: a mensagem passa
  uma vez e sai pelas pontas.
- **Receptores:** dez receptores iguais (Ω_c = 1,85, γ_R = 0,02), cada um ligado a um sítio (g = 0,05), a partir do
  sítio 90 e espaçados de d = 65 sítios.
- **Rede:** igual em todos os sítios da linha (A = 10, Ω_r = 1,0).
- **Mensagem:** dois sítios vizinhos de uma ponta, com saca-rolha s e duração 300 (T4: 150 e 600). Ela caminha com
  v_g = 0,2156 sítio por unidade de tempo; d/v_g = 301,5.
- **Relé e lâmpada:** como no L.
- **Intervenções:** T5 desliga a casa 4; T6 corta a mola entre as casas 4 e 5.

### 2.3 S — base SYK, só a detecção [M]

Sem mudanças em relação à primeira versão (§9):
- N Majoranas com interação de 4 corpos; as casas são quatro pares (χ_2i, χ_2i+1), com energia Ω_i (n_i − ½),
  Ω = 0,3 / 0,5 / 0,7 / 0,9 de leste a oeste (o custo cresce para oeste).
- A mensagem age só sobre a base, no setor de paridade do fundamental, com τ_S = 80, F = 0,05 e dt = 0,1:
  - genérica: dois bilineares aleatórios;
  - endereçada: o bilinear da base que multiplica o bilinear da casa em H, mais a parte de i[H_base, ·] ortogonal a ele.
- Mede-se Δn_i(t), a ocupação de cada casa acima do fundamental. Não há rede nem relé.

## 3. Hipóteses (pré-registradas) e o que já se sabe

### 3.1 O que as explorações mostraram (sementes fora da rodada; §9)

Base livre, margens por rodada (mediana [mín.; máx.]). M = 1 600: sementes 801, 803, 804 e 805, 12 rodadas por linha.
M = 800: sementes 801 e 802, 6 rodadas por linha.

| Mensagem | M | Frente (trava) | Ola (solta) | Pico (mediana) |
|---|---|---|---|---|
| difusão, s = +1 | 1 600 | 10,8 [5,3; 17,7] | 2,7 [1,4; 4,4] | 6,8 × 10⁻⁴ |
| difusão, s = +1 | 800 | 7,6 [4,7; 8,4] | 1,6 [0,86; 2,8] | 8,8 × 10⁻⁴ |
| difusão, s = −1 | 1 600 | 1,4 [0,76; 3,1] | 0,15 [0,06; 0,33] | 7,2 × 10⁻⁵ |
| alvo, s = +1 | 1 600 | 2 230 [1 080; 3 460] | 69 [33; 110] | 6,6 × 10⁻³ |
| alvo, s = +1 | 800 | 850 [560; 1 230] | 55 [34; 67] | 6,8 × 10⁻³ |
| alvo, s = −1 | 1 600 | 9,6 [2,0; 14] | 0,57 [0,10; 0,83] | 3,8 × 10⁻⁴ |
| genérica, s = ±1 | 1 600 | ≈ 2 [0,41; 3,7] (79 % > 1) | ≈ 0,1 [0,04; 0,76] | ≈ 6 × 10⁻⁵ |

Uma quinta semente em M = 1 600 (777001, a da medição de tempo, avaliada com as regras da §7) deu:
- difusão: frente 17–19, ola 3,3–6,2;
- alvo: frente ≈ 3 000, ola 81–87;
- genérica: frente 2,3–3,9, ola ≤ 0,26;
- rede/limiar 0,006.

Todas as classes dessa semente coincidem com as previsões, exceto a ola da difusão: folga 4,3, que seria ONDA.

Outros achados:
- **A rede não atrapalha o telecomando.** Depois da demodulação, a leitura da rede sozinha fica abaixo de 5 × 10⁻⁷ em
  M = 1 600. O limiar do meio da faixa da difusão é ≈ 10⁻⁴. A rede guarda na base centenas de vezes a energia da
  mensagem.
- **Velocidade.** A frente segue o programa: intervalo/τ = 1,00 ± 0,02 em τ = 150, 300 e 600.
  - Em τ = 75, a difusão perde a frente (margem 0,62–1,18); a separação de 0,08 entre as frequências das casas pede
    tempo ≳ 2π/0,08 ≈ 80.
  - A endereçada mantém a frente (≥ 275).
  - A ola pede τ ≥ 150 (alvo) e τ ≥ 300 (difusão); em τ = 150, a ola da difusão fica em 0,32–0,66.
- **Eco.** Sem perdas, a mensagem fica tocando na base e os receptores a bebem tarde:
  - a razão eco = máx pos/mín pico sobe de 0,28 para 1,7 (difusão) e de 0,0075 para 0,077 (alvo);
  - a ola da difusão some (margem 0,11–0,33);
  - a do alvo cai de ≈ 70 para ≈ 6,5.
  - É o atraso de 3 a 6 intervalos da primeira versão (§9).
- **Quiralidade.** No sentido oposto, os picos caem 9 vezes (difusão) e 17 vezes (alvo), e a ola some nas duas.
- **Linha.** A ordem segue a distância à fonte (Spearman 1), o intervalo é d/v_g (0,99–1,01), tirar a casa 4 não
  bloqueia e o corte bloqueia (picos além do corte ≈ 10⁻⁴ dos de referência).

### 3.2 Previsões

Decisão em M = 1 600 (L); controle de tamanho em M = 800.

| Item | Previsto | Por quê |
|---|---|---|
| L.T1 difusão, trava | ONDA | a frequência basta para a frente; folga ≈ 11 |
| L.T1 difusão, solta | ONDA_FRAGIL | a ola existe (todas as margens > 1), com folga ≈ 2–3 |
| L.T1 alvo, trava | ONDA | folga > 10³ |
| L.T1 alvo, solta | ONDA | folga 30–110 |
| L.T1 genérica, trava | ONDA_FRAGIL | ≈ 80 % das margens > 1, folga ≈ 2 |
| L.T1 genérica, solta | SEM_ONDA | margens ≤ 0,8 |
| L.quiral difusão | QUIRAL | ola no sentido casado; nenhuma no oposto |
| L.quiral alvo | QUIRAL | idem |
| L.códigos | HIERARQUIA_FORMA_FREQUENCIA_FORA | folga da ola: alvo ≫ difusão ≫ genérica (razões ≈ 25) |
| L.T3 | TUDO_OU_NADA | relé com limiar e luz da rede (verificação de construção) |
| L.T4 difusão | VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA | segue τ; τ = 75 derruba a margem |
| L.T4 alvo | VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA | idem (margem(75)/margem(300) ≈ 0,15) |
| L.T5 | SEM_DEPENDENCIA | picos das outras casas iguais (≤ 0,1 %) |
| L.T6 | ATRAVESSA | picos 0,7–0,8 dos de referência, sem atraso |
| L.T7 | PERDAS_APAGAM_O_ECO | eco 6–14 vezes maior sem perdas |
| L.rede dispara | REDE_NAO_DISPARA | rede/limiar ≈ 0,01 em M = 1 600 |
| L.rede interfere | REDE_NAO_INTERFERE | Δt ≤ 0,005 τ |
| L.global | ONDA_PROGRAMADA | — |
| L.controle M | CONSISTENTE | as quatro ondas de difusão e alvo (s = +1) existem também em M = 800 |
| C.T1 | ONDA_PROPAGADA | ordem pela distância, intervalo d/v_g |
| C.T1 solta | ONDA_PROPAGADA | margens 4–15 |
| C.T4 | VELOCIDADE_FIXA | o intervalo não segue a duração |
| C.T5 | SEM_BLOQUEIO | — |
| C.T6 | BLOQUEADA | — |
| C.rede dispara | REDE_NAO_DISPARA | rede/limiar ≈ 0,004 |
| C.global | ONDA_COM_CAMINHO | — |
| L×C | SEPARACAO | onda programada sem caminho × onda com caminho |
| S.T1 genérica | SEM_ONDA | como na primeira versão |
| S.T1 alvo | SEM_ONDA | idem |
| S.T2 | SEGUE_O_CUSTO | vencem as casas baratas |
| S.T2b | ORDEM_FINAL_POR_CUSTO | — |
| S.global | ONDA_ESQUECIDA | — |
| S.controle N = 24 | CONSISTENTE | — |
| OLA | ONDA_SEM_CAMINHO_SO_NA_BASE_LIVRE | — |

**Itens no limite (risco declarado):**
- **Ola da difusão:** a folga fica entre 1,4 e 6,2 por rodada (mediana ≈ 3,1 nas cinco sementes exploradas), perto
  do corte 4. ONDA em vez de ONDA_FRAGIL é possível.
- **Frente da genérica:** a fração com margem > 1 fica entre 0,33 e 1 por semente (≈ 0,8 no conjunto), acima do
  corte 0,5. SEM_ONDA é possível.
- **Controle de tamanho:** depende de a ola da difusão existir em M = 800, onde a fração > 1 foi 0,67–0,83.

Sementes da rodada:
- L: 39500–39503 (M = 400), 39600–39603 (M = 800) e 39700–39703 (M = 1 600);
- S: 3931–3934 (N = 20) e 3941 (N = 24).

Nenhuma foi usada nas explorações registradas.

## 4. Parâmetros (rodada `completo`)

| Parte | Tamanhos | Sementes | Bateria por semente |
|---|---|---|---|
| L | M = 400, 800, 1 600 | 4 por M | 30 rodadas: T1 (3 mensagens × 3 ordens × 2 sentidos); T4 (τ = 75, 150, 600 × difusão e alvo); T5, T6, T7 (difusão e alvo). T3 e as leituras sem rede saem das próprias rodadas T1. |
| C | H = 10, Mc = 800 | — | T1 (2 pontas × 2 sentidos), T4 (duração 150 e 600), T5, T6 |
| S20 | N = 20 | 4 | 8 rodadas: (genérica, alvo) × (2 ordens) × (2 sentidos) |
| S24 | N = 24 | 1 | idem |

- **Ordens (L):** leste→oeste, oeste→leste e salteada [0, 5, 2, 7, 4, 9, 1, 6, 3, 8].
- **Tempos (L):** τ = 300; rodada de (10 + 2) τ.
- **Janelas (L):** para a casa da vez j:
  - fechamento em [jτ; (j+1)τ + τ/4];
  - prazo de soltura em (j+1)τ + τ/2.
- **Janelas (C):** chegada prevista t* = dur/2 + |pos − fonte|/v_g; fechamento em t* ± Δ/2; soltura até t* + Δ,
  com Δ = d/v_g.
- **T3:** forças 0,25; 0,5; 1 e 2 × F0, com relé que trava calibrado em metade do menor pico nominal da rodada.

## 5. Protocolo

1. `python -I src/testar_avaliador_B39.py fumaca` deve terminar com "TODOS OS 143 RAMOS CONFEREM".
2. `python -I src/conferir_pecas_B39.py fumaca` deve terminar com "TODAS AS 14 PEÇAS CONFEREM".
3. `python -I src/rodar_B39.py --modo completo --parte todas` grava em `resultados/`, ou cada parte separadamente:
   `L`, `C`, `S20` e `S24` podem rodar em paralelo.
   - Cada (parte, tamanho, semente) gera um checkpoint JSON atômico.
   - Se a execução cair, relançar retoma do ponto em que parou.
   - `config_B39.json` registra os parâmetros e os SHA-256 dos módulos.
4. `python -I src/avaliar_B39.py resultados` grava `resultados/avaliacao_B39.json` e imprime previsto × obtido.
5. Nenhum parâmetro, limiar ou semente muda depois do "pode rodar". Qualquer leitura extra vai para uma seção pós-hoc
   separada do relatório.

## 6. Medidas

- **Leitura R_k(t)** de cada relé (§2.1), com a rede ligada.
- **Por casa h**, dentro da sua janela:
  - pre_h = máx R_h antes do início da janela;
  - pico_h = máx R_h até o fim da janela de fechamento;
  - pos_h = máx R_h depois do prazo de soltura.
- **Margens** (só as casas chamadas; a casa removida fica fora):
  - margem_trava = mín pico / máx pre;
  - margem_solta = mín pico / máx(máx pre, máx pos / HIST), com HIST = ½.
  - margem_trava > 1 ⇔ existe θ comum em que todo relé fecha dentro da sua janela e nenhum antes.
  - margem_solta > 1 ⇔ existe θ comum em que, além disso, todo relé está aberto depois do prazo.
- **Limiar do meio** θ = √(mín pico × denominador), só descritivo. Nele:
  - acerto (fração de casas certas);
  - instantes de fechamento;
  - intervalo relativo = mediana das diferenças entre fechamentos consecutivos / τ;
  - lâmpadas acesas ao mesmo tempo (b > ½);
  - cintilação (trechos ligados a mais);
  - luz de cada lâmpada.
  - Conferido: margem > 1 ⇔ acerto = 1 em todas as rodadas da fumaça.
- **Rede:**
  - leitura máxima só da rede, sobre o limiar do meio;
  - instantes de fechamento com e sem rede, no mesmo limiar;
  - energia da rede na base / maior energia da mensagem na base.
- **T3:** casas que disparam e brilho máximo de cada lâmpada, em cada força.
- **T5 e T6:** razão dos picos casa a casa e |Δ fechamento|/τ, contra a rodada de referência (leste→oeste, s = +1, do
  mesmo tipo e semente).
- **T7:** eco = máx pos / mín pico; razão eco(sem perdas)/eco(com perdas) por semente.
- **C:** Spearman entre os instantes de fechamento e a distância à fonte; intervalo relativo a d/v_g; pico de cada casa.
- **S:** como na primeira versão — matriz de ganhos G (aumento de ⟨n⟩ na janela de cada intervalo), vencedores, acerto,
  contraste e ordem final de Δn.

## 7. Regras de decisão (congeladas; `src/avaliar_B39.py`; testadas em 143 ramos)

**Gerais.**
- Medianas sobre as amostras válidas.
- Se faltar mais de 1/3 das amostras esperadas, a classe é INSUFICIENTE.
- Toda regra global trata o estado INSUFICIENTE.
- Validade S: lacuna do fundamental ≥ 10⁻⁸ e |norma − 1| ≤ 10⁻⁸ em todas as rodadas.

**Modelo L (em M = 1 600).**

| Teste | Classes |
|---|---|
| T1 (por mensagem e relé; s = +1, e a genérica com os dois sentidos juntos) | f = fração das rodadas com margem > 1, m = mediana da margem: **ONDA** f ≥ 0,9 e m ≥ 4 · **ONDA_FRAGIL** f ≥ 0,5 · **SEM_ONDA** senão |
| Quiralidade (difusão e alvo) | classes da ola em s = +1 e s = −1: **AQUIRAL** iguais · **QUIRAL** casado ≠ SEM_ONDA e oposto = SEM_ONDA · **PARCIAL** senão |
| Códigos | medianas da margem da ola (s = +1): **HIERARQUIA_FORMA_FREQUENCIA_FORA** se alvo/difusão ≥ 3 e difusão/genérica ≥ 3 · **OUTRA_ORDEM** senão |
| T3 (difusão e alvo, leste→oeste, s = +1) | numa rodada vale o tudo ou nada se: todas disparam com força 2; nem todas com 0,25; a contagem não cai quando a força sobe; toda lâmpada fica ≥ 0,99 (disparou) ou ≤ 0,01 (não disparou). **TUDO_OU_NADA** se vale em ≥ 90 % das rodadas · **GRADUAL** senão |
| T4 (difusão; alvo) | livre se em τ = 150, 300 e 600 a fração com margem_trava > 1 é ≥ 0,9 e \|intervalo − 1\| ≤ 0,1. **VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA** se livre e margem(75)/margem(300) ≤ 0,5 · **VELOCIDADE_LIVRE_SEM_LIMITE** · **VELOCIDADE_PRESA** |
| T5 | razão dos picos r, atraso d: **SEM_DEPENDENCIA** \|r − 1\| ≤ 0,1 e d ≤ 0,05 · **DEPENDENTE** r < 0,5 ou r > 2 · **PARCIAL** |
| T6 | **BLOQUEADA** r < 0,1 · **ATRAVESSA** r ≥ 0,5 e d ≤ 0,1 · **PARCIAL** |
| T7 | razão dos ecos por tipo: **PERDAS_APAGAM_O_ECO** as duas medianas ≥ 3 · **SEM_EFEITO** as duas < 1,5 · **PARCIAL** |
| Rede dispara (difusão e alvo, s = +1) | **REDE_NAO_DISPARA** se em toda rodada a leitura da rede sozinha < 0,1 × limiar do meio · **REDE_DISPARA** |
| Rede interfere (idem) | **REDE_NAO_INTERFERE** se em toda rodada a mediana de \|Δt\|/τ ≤ 0,02 e ≥ 95 % das casas disparam igual com e sem rede · **REDE_INTERFERE** |
| **Global L** | **ONDA_PROGRAMADA:** frente da difusão e do alvo = ONDA, T4 (difusão) livre, T5 SEM_DEPENDENCIA e T6 ATRAVESSA · **NAO_PROGRAMADA:** as duas frentes SEM_ONDA · **PARCIAL** |
| Controle de tamanho | para difusão e alvo (trava e solta, s = +1), a onda **existe** (ONDA ou ONDA_FRAGIL) ou **não existe** (SEM_ONDA). **CONSISTENTE** se a existência é a mesma em M = 800 e M = 1 600 · **INCONSISTENTE** · **INSUFICIENTE** |

Nas regras da rede, todas as rodadas T1 ficam relatadas como descrição.

**Linha C.**

| Teste | Classes |
|---|---|
| T1 | **ONDA_PROPAGADA** se em todas as rodadas: Spearman ≥ 0,99, \|intervalo − 1\| ≤ 0,05 e margem_trava > 1 · **SEM_PROPAGACAO** |
| T1 solta | **ONDA_PROPAGADA** se todas as margens da ola > 1 · **SEM_SOLTURA** |
| T4 | **VELOCIDADE_FIXA** \|intervalo − 1\| ≤ 0,1 nas três durações · **VELOCIDADE_SEGUE_A_MENSAGEM** se intervalo(600)/intervalo(150) ≥ 2 · **INDEFINIDA** |
| T5 | razão dos picos além da casa 4: **SEM_BLOQUEIO** ≥ 0,9 · **BLOQUEIO_PARCIAL** |
| T6 | como no L (picos além do corte) |
| Rede dispara | como no L, na rodada de referência |
| **Global C** | **ONDA_COM_CAMINHO:** T1 ONDA_PROPAGADA, T4 VELOCIDADE_FIXA e T6 BLOQUEADA · **PARCIAL** |

**SYK (em N = 20; N = 24 como controle).** Como na primeira versão:
- T1 (por mensagem): **ONDA_LIMPA** acerto ≥ 0,9 e contraste ≥ 3 · **ONDA_BORRADA** acerto ≥ 0,5 · **SEM_ONDA**;
- T2: fração de vencedores nas casas baratas (A, B): **SEGUE_O_CUSTO** ≥ 0,75 · **NAO_SEGUE_O_CUSTO** ≤ 0,5 ·
  **INTERMEDIARIO**;
- T2b: Spearman da ordem final de Δn com o custo ≥ 0,8 → **ORDEM_FINAL_POR_CUSTO**;
- global: **ONDA_ESQUECIDA** (as duas SEM_ONDA e SEGUE_O_CUSTO) · **ONDA_LEMBRADA** (alguma ONDA_LIMPA) · **MISTA**;
- controle N = 24: mesma classe global.

**Comparações.**
- **L×C:**
  - **SEPARACAO:** L ONDA_PROGRAMADA, C ONDA_COM_CAMINHO e L-T4 (difusão) livre;
  - **IGUAIS:** as duas programadas ou as duas não;
  - **MISTA:** senão.
- **OLA:**
  - **ONDA_SEM_CAMINHO_SO_NA_BASE_LIVRE:** L programada, L×C SEPARACAO e S esquecida;
  - **ONDA_SEM_CAMINHO_NAS_DUAS:** L programada e S lembrada;
  - **SEM_ONDA_PROGRAMADA:** L não programada;
  - **MISTA:** senão.

## 8. Controles, conferências e tempo (medidos antes de congelar)

- **Conferência das peças** (`src/conferir_pecas_B39.py`, 14 itens):
  - motor × RK4: erro relativo 3 × 10⁻⁷;
  - rede estacionária × RK4: 3 × 10⁻⁹;
  - superposição rede + mensagem × RK4: 8 × 10⁻⁸;
  - valor inicial do filtro × aquecimento de 400 T_R: 4 × 10⁻¹⁵;
  - linearidade sem rede (exata);
  - relé que trava, relé que solta, lâmpada;
  - margem > 1 ⇔ acerto = 1 em todas as rodadas da fumaça.
- **Controles dentro da rodada:**
  - rede sozinha (sem mensagem);
  - mensagem sem rede;
  - base sem perdas;
  - força da mensagem;
  - os dois sentidos do saca-rolha;
  - três ordens;
  - linha com espaço;
  - tamanho (M = 400 e 800; N = 24).
- **Custos** (1 núcleo por processo):

  | Parte | Por semente | Total | Memória |
  |---|---|---|---|
  | L | M = 400 ≈ 25 s; M = 800 ≈ 1 min; M = 1 600 ≈ 4,5 min (medido: 260 s) | ≈ 25 min | < 2 GB (1,9 medido) |
  | C | — | ≈ 30 s | < 0,5 GB |
  | S20 | ≈ 5 min (8 rodadas de ≈ 35 s; N = 20 medido na fumaça) | ≈ 20 min | < 0,2 GB |
  | S24 | 8 rodadas de ≈ 5–6 min (medido na primeira versão) | ≈ 45 min | < 1 GB |

  Em sequência, ≈ 1,5 h. Com L, S20 e S24 em paralelo (3 núcleos, ≥ 4 GB), ≈ 45 min.

## 9. O que foi tentado e mudado antes de congelar

1. **Primeira versão: a mensagem trazia a energia (abandonada às 19h58, nunca congelada).** A base começava no repouso,
   e a luz da lâmpada era a energia da própria mensagem.
   - Com a mensagem endereçada, a onda saía limpa.
   - Com a genérica, a luz saía quase nula, e metade dela era emitida de 3 a 6 intervalos depois da hora certa.
   - Mario: a rede de uma cidade está sempre ligada. A energia passou a vir da rede, e a mensagem só comanda o relé.
   - O atraso tinha duas causas, as duas ligadas à base sem perdas: a mensagem ficava tocando na base (eco), e a
     lâmpada precisava juntar energia. Com o relé, a segunda deixa de existir; a primeira vira o T7.
2. **Controle "lâmpada reversível" retirado.** Ele media a energia que a mensagem deixava na lâmpada. Agora a lâmpada
   não recebe energia da mensagem.
3. **Mensagem de difusão acrescentada** (20h00; Ripple Control às 20h03). A genérica antiga entrava fora da fiação;
   a difusão percorre a fiação de todas as casas.
4. **Frequência da rede.** Dentro da banda, a rede excitaria modos ressonantes da base, sem estado estacionário limpo.
   Foi para Ω_r = 1,0, abaixo da banda, como os 50/60 Hz abaixo das frequências de telecomando.
5. **O relé lê a banda da casa.**
   - Lendo a energia total do receptor, a rede (A = 10) dava leitura comparável à da difusão; com A = 30, a cobria.
   - Passou a demodular na frequência da casa, com inércia T_R = 20, como os receptores de telecomando reais.
   - O filtro parte do valor estacionário exato sob a rede. Sem isso, o "liga" artificial da rede em t = 0 entrava na
     leitura.
6. **Perdas na base.** Sem perdas, a mensagem fica tocando na base; o relé que solta não solta (ola da difusão
   0,14–0,33).
   - Uma rede real perde energia o tempo todo, e é por isso que a fonte fica ligada: as perdas repostas são a "rede
     sempre ligada".
   - Fixado γ_b = 0,01. A base sem perdas ficou como controle (T7).
   - Na linha, o interior fica sem perdas. Com γ_b = 0,01, a mensagem morreria antes de atravessar a cidade
     (e^{−30}); lá o eco não existe, porque a mensagem sai pelas pontas.
7. **Classificar por margem, não por acerto num limiar escolhido.**
   - Com um limiar fixo, o resultado dependia de onde ele fosse posto, e as mensagens têm níveis 10 a 100 vezes
     diferentes.
   - A margem pergunta se existe um limiar comum que faça a onda perfeita, e quanto ele pode errar.
   - O limiar do meio fica só como descrição.
8. **Folga.** Primeiro 3, depois 5, por fim 4:
   - a ola da difusão tem folga ≈ 2–3 e a frente da genérica ≈ 2: as duas devem ficar frágeis;
   - a frente da difusão tem folga 5–8 em M = 800 e ≈ 11 em M = 1 600;
   - com 5, a classe de M = 800 ficaria no limite (5,6 na fumaça).
   - Como a folga da difusão cresce com M, o controle de tamanho passou a comparar só a existência da onda
     (ONDA ou ONDA_FRAGIL contra SEM_ONDA), e não o nível da folga.
9. **Acerto da ola** igualado à definição da margem: todo trecho ligado dentro de [início; prazo]. Na linha, com s = −1,
   o sinal fraco perto da leitura da rede faz o relé cintilar dentro da janela; a cintilação fica relatada.
10. **Regras da rede restritas à difusão e ao alvo com s = +1.**
    - Nas mensagens fracas (genérica e sentido oposto), o limiar do meio fica perto da leitura da rede em M pequeno:
      0,26–0,35 do limiar em M = 400–800.
    - A pergunta da bancada é se a rede atrapalha o telecomando que funciona.
    - O valor de todas as rodadas fica relatado.
11. **T3.** "No máximo 20 % disparam com 1/4 da força" foi trocado por "nem todas disparam, e a contagem não cai quando
    a força sobe": os picos da difusão variam até ≈ 8 vezes entre as casas.
12. **Fumaça em M = 400 e 800** (antes 200 e 400): M = 200 é pequeno demais para a difusão.

Explorações (fora do pré-registro; scripts guardados na sessão):
- L: sementes 777, 801 e 802 (M = 400), 801 e 802 (M = 800), 801, 803, 804, 805 e 777001 (M = 1 600);
- C: a linha de referência;
- primeira versão: as sementes registradas no seu esboço.

## 10. Leitura prevista de cada resultado [H]

- **Frente da difusão = ONDA (previsto).** O telecomando de verdade funciona numa base onipresente:
  - o mesmo sinal fraco, por toda a fiação, endereçado só pela frequência, acende as casas na ordem e na hora do
    programa;
  - a energia vem da rede; a mensagem é só informação.
  - Para a Ola: um GMFt pode ser acionado por um sinal geral da base, sem caminho e sem fila.
- **Ola frágil com a difusão, robusta com o alvo (previsto).**
  - Acender é fácil; apagar na hora certa exige mais: o endereço completo (frequência + forma) ou mais tempo.
  - Com só a frequência, as casas vizinhas na frequência "ouvem" um pouco a vez das outras.
- **QUIRAL (previsto).** A base reconhece o sentido do saca-rolha. No sentido oposto, a mensagem endereçada vale pouco
  mais que a genérica.
- **PERDAS_APAGAM_O_ECO (previsto).** A rede que perde e é reposta esquece a mensagem. A rede sem perdas guarda eco, e
  as casas o bebem tarde. É a explicação do atraso da primeira versão.
- **SEPARACAO L×C (previsto).** Na base livre, a onda é programa: a velocidade é livre, com limite de incerteza, e o
  corte não a bloqueia. Na linha, a onda tem caminho: a velocidade é fixa, e o corte bloqueia. Duas ondas iguais aos
  olhos podem ter naturezas diferentes.
- **ONDA_ESQUECIDA na SYK (previsto).** A base caótica não guarda o código; vence quem custa menos. O telecomando com
  endereço por frequência pede uma base que não embaralhe (como a livre).
- **Se a frente da difusão falhar:** a frequência sozinha não basta numa base onipresente, e o endereço precisaria da
  forma da fiação, ou de um telegrama de pulsos (bancada seguinte).

## 11. Limites

- Toy models. A base livre é linear; o relé (limiar) é a única não linearidade, posta à mão.
- **Rede ideal:**
  - as lâmpadas não carregam a rede, e a tensão não cai quando muitas acendem;
  - o brilho é normalizado;
  - o T3 é uma verificação de construção.
  - A queda de tensão e a fonte finita ficam para depois.
- **Endereço:** uma frequência por casa. O telecomando real usa, em geral, um padrão de pulsos (telegrama) numa única
  frequência de controle. Esse é o teste seguinte natural.
- **Perdas:** uniformes no L; ausentes no interior da linha (§9, item 6).
- **SYK:** só detecção, sem rede nem relé; é pequena (N ≤ 24).
- O receptor é um sítio extra ligado à base, não uma organização da base.
- Precisão dupla. Nenhuma geometria é reconstruída.

## 12. Arquivos do pré-registro

- `src/b39_linear.py` — motor linear (integração exata por autovalores; rede estacionária; energia da mensagem).
- `src/b39_rele.py` — leitura do relé, relés que travam e que soltam, lâmpada, margens e medidas.
- `src/b39_cidade.py` — a cidade: base livre (L) e linha (C), mensagens, intervenções, janelas.
- `src/b39_syk.py` — modelo S (SYK), sem mudanças.
- `src/rodar_B39.py` — executor (modos `fumaca` e `completo`; partes L, C, S20, S24).
- `src/avaliar_B39.py` — avaliador congelado (§7).
- `src/testar_avaliador_B39.py` — teste sintético e de ponta a ponta (143 ramos).
- `src/conferir_pecas_B39.py` — conferência das peças (14 itens).
- `src/figura_fumaca_B39.py` — figura da fumaça (`fumaca/figura_fumaca_B39.png`).
- `fumaca/` — checkpoints, avaliação, logs e saídas dos testes.
- `FUMACA_B39.md`, `LEIAME_B39.md` e o arquivo de hashes SHA-256.

## Referências

- IEC 62054-11:2004, *Electricity metering (a.c.) — Tariff and load control — Part 11: Particular requirements for
  electronic ripple control receivers* (telecomando por sinais sobrepostos à rede).
- E. Fermi, *Nuclear Physics* (1950) (regra de ouro); E. P. Wigner, Ann. Math. 62, 548 (1955) (semicírculo).
- S. Sachdev, J. Ye, Phys. Rev. Lett. 70, 3339 (1993); A. Kitaev, palestras no KITP (2015); J. Maldacena, D. Stanford,
  Phys. Rev. D 94, 106002 (2016).
- J. M. Deutsch, Phys. Rev. A 43, 2046 (1991); M. Srednicki, Phys. Rev. E 50, 888 (1994) (ETH).
