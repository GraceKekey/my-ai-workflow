"""B39 — avaliador (rede sempre ligada). Uso: python avaliar_B39.py PASTA_RESULTADOS
Aplica as regras congeladas (protocolo §7) e grava PASTA/avaliacao_B39.json. As funções classe_* recebem números simples
(testadas em testar_avaliador_B39.py); avaliar_* lê os checkpoints."""
import glob, json, os, sys
import numpy as np

# ---------------------------------------------------------------- limiares congelados
FRAC_ONDA, FRAC_FRAGIL = 0.9, 0.5   # fração das rodadas com margem > 1
FOLGA = 4.0                        # mediana da margem para ONDA (o limiar comum pode errar por um fator 2 para cada lado)
HIER = 3.0                         # hierarquia dos códigos: razão entre medianas da margem de soltura
INTERVALO_TOL = 0.1                # T4: |intervalo relativo − 1|
LIMITE_INC = 0.5                   # T4: margem_trava(τ = 75)/margem_trava(τ = 300) ≤ 0,5
DEP_TOL, DT_TOL = 0.1, 0.05        # T5: |razão de picos − 1| e |Δt de fechamento|/τ
ATRAV, BLOQ, DT_CORTE = 0.5, 0.1, 0.1   # T6
ECO_FATOR, ECO_NADA = 3.0, 1.5     # T7: eco(sem perdas)/eco(com perdas)
TON_SIM, TON_ESCURO = 0.99, 0.01   # T3: brilho de lâmpada acesa / apagada
T3_RODADAS = 0.9                   # T3: fração de rodadas em que vale o tudo-ou-nada
REDE_FRAC = 0.1                    # rede sozinha: leitura máxima < 0,1 do limiar do meio da janela
DT_REDE, CONC_REDE = 0.02, 0.95    # rede × sem rede: |Δt|/τ e concordância de disparo
C_SPEAR, C_INTERV = 0.99, 0.05     # C-T1
C_SEGUE = 2.0                      # C-T4
C_SEM_BLOQ = 0.9                   # C-T5
CUSTO_SIM, CUSTO_NAO = 0.75, 0.5   # S-T2
ORDEM_FINAL = 0.8                  # S-T2b
ACERTO_LIMPA, ACERTO_BORRADA, CONTRASTE_MIN = 0.9, 0.5, 3.0   # S-T1
MIN_VALIDAS = 2.0 / 3.0
GAP_MIN, NORMA_TOL = 1e-8, 1e-8
CASA_REMOVIDA = 4
TIPOS = ('difusao', 'alvo', 'generica')


def med(x):
    v = [u for u in x if u is not None and np.isfinite(u)]
    return float(np.median(v)) if v else None


def fin(x):
    return [u for u in x if u is not None and np.isfinite(u)]


# ---------------------------------------------------------------- classes (L)
def classe_onda(margens, n_esperado):
    """margens de um relé (trava ou solta) num conjunto de rodadas. Devolve (classe, fração com margem > 1, mediana)."""
    m = fin(margens)
    if n_esperado == 0 or len(m) < MIN_VALIDAS * n_esperado:
        return 'INSUFICIENTE', None, None
    fr = float(np.mean([x > 1.0 for x in m])); md = float(np.median(m))
    if fr >= FRAC_ONDA and md >= FOLGA:
        return 'ONDA', fr, md
    if fr >= FRAC_FRAGIL:
        return 'ONDA_FRAGIL', fr, md
    return 'SEM_ONDA', fr, md


def classe_quiral(casado, oposto):
    """classes da onda que solta nos sentidos casado (s = +1) e oposto (s = −1)."""
    if 'INSUFICIENTE' in (casado, oposto):
        return 'INSUFICIENTE'
    if casado == oposto:
        return 'AQUIRAL'
    if casado != 'SEM_ONDA' and oposto == 'SEM_ONDA':
        return 'QUIRAL'
    return 'PARCIAL'


def classe_codigos(m_alvo, m_dif, m_gen):
    """medianas da margem de soltura (s = +1) dos três códigos."""
    if None in (m_alvo, m_dif, m_gen) or m_dif <= 0 or m_gen <= 0:
        return 'INSUFICIENTE'
    if m_alvo / m_dif >= HIER and m_dif / m_gen >= HIER:
        return 'HIERARQUIA_FORMA_FREQUENCIA_FORA'
    return 'OUTRA_ORDEM'


def classe_tudo_ou_nada(rodadas):
    """rodadas: lista de dicts T3 {F_rel, disparadas[iF][h], brilho_max[iF][h]} já restritos às casas que contam."""
    if not rodadas:
        return 'INSUFICIENTE', None
    oks = []
    for q in rodadas:
        F = q['F_rel']
        if 2.0 not in F or 0.25 not in F:
            return 'INSUFICIENTE', None
        o_ = np.argsort(F); cont = [sum(q['disparadas'][i]) for i in o_]
        todas_fortes = all(d == 1 for d in q['disparadas'][F.index(2.0)])
        nem_todas_fracas = not all(d == 1 for d in q['disparadas'][F.index(0.25)])
        monotona = all(b >= a for a, b in zip(cont, cont[1:]))
        nitido = all((b >= TON_SIM) if d else (b <= TON_ESCURO)
                     for iF in range(len(F)) for d, b in zip(q['disparadas'][iF], q['brilho_max'][iF]))
        oks.append(todas_fortes and nem_todas_fracas and monotona and nitido)
    fr = float(np.mean(oks))
    return ('TUDO_OU_NADA' if fr >= T3_RODADAS else 'GRADUAL'), fr


def classe_velocidade(fr_por_tau, intervalos_por_tau, marg75, marg300):
    """dicts τ → fração com margem_trava > 1 e mediana do intervalo relativo; τ ≥ 150 decidem a liberdade."""
    taus = [t for t in fr_por_tau if t >= 150]
    if not taus or any(fr_por_tau[t] is None for t in taus):
        return 'INSUFICIENTE'
    livre = all(fr_por_tau[t] >= FRAC_ONDA and intervalos_por_tau.get(t) is not None and abs(intervalos_por_tau[t] - 1) <= INTERVALO_TOL
                for t in taus)
    if not livre:
        return 'VELOCIDADE_PRESA'
    if marg75 is None or marg300 is None or marg300 <= 0:
        return 'INSUFICIENTE'
    return 'VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA' if marg75 / marg300 <= LIMITE_INC else 'VELOCIDADE_LIVRE_SEM_LIMITE'


def classe_dependencia(razoes, dts):
    r, d = med(razoes), med(dts)
    if r is None or d is None:
        return 'INSUFICIENTE', r, d
    if abs(r - 1) <= DEP_TOL and d <= DT_TOL:
        return 'SEM_DEPENDENCIA', r, d
    if r < 0.5 or r > 2:
        return 'DEPENDENTE', r, d
    return 'PARCIAL', r, d


def classe_corte(razoes, dts):
    r = med(razoes)
    if r is None:
        return 'INSUFICIENTE', r, None
    d = med(dts)
    if r < BLOQ:
        return 'BLOQUEADA', r, d
    if r >= ATRAV and d is not None and d <= DT_CORTE:
        return 'ATRAVESSA', r, d
    return 'PARCIAL', r, d


def classe_eco(razoes_por_tipo):
    """dict tipo → lista de razões eco(sem perdas)/eco(com perdas)."""
    meds = {k: med(v) for k, v in razoes_por_tipo.items()}
    if not meds or any(v is None for v in meds.values()):
        return 'INSUFICIENTE', meds
    if all(v >= ECO_FATOR for v in meds.values()):
        return 'PERDAS_APAGAM_O_ECO', meds
    if all(v < ECO_NADA for v in meds.values()):
        return 'SEM_EFEITO', meds
    return 'PARCIAL', meds


def classe_rede_dispara(fracs):
    """fracs: leitura máxima só da rede / limiar do meio da janela, por rodada."""
    f = fin(fracs)
    if not f:
        return 'INSUFICIENTE', None
    return ('REDE_NAO_DISPARA' if max(f) < REDE_FRAC else 'REDE_DISPARA'), float(max(f))


def classe_rede_interfere(dts, concord):
    """dts: |Δt de fechamento|/τ por rodada (mediana sobre as casas); concord: fração de casas com o mesmo disparo."""
    d, c = fin(dts), fin(concord)
    if not d or not c:
        return 'INSUFICIENTE', None, None
    ok = max(d) <= DT_REDE and min(c) >= CONC_REDE
    return ('REDE_NAO_INTERFERE' if ok else 'REDE_INTERFERE'), float(max(d)), float(min(c))


def classe_global_L(c_dif, c_alvo, t4, t5, t6):
    """c_dif, c_alvo: classes da onda que trava (s = +1); t4: velocidade da difusão; t5, t6: classes conjuntas."""
    if 'INSUFICIENTE' in (c_dif, c_alvo, t4, t5, t6):
        return 'INSUFICIENTE'
    if c_dif == 'ONDA' and c_alvo == 'ONDA' and t4.startswith('VELOCIDADE_LIVRE') and t5 == 'SEM_DEPENDENCIA' and t6 == 'ATRAVESSA':
        return 'ONDA_PROGRAMADA'
    if c_dif == 'SEM_ONDA' and c_alvo == 'SEM_ONDA':
        return 'NAO_PROGRAMADA'
    return 'PARCIAL'


# ---------------------------------------------------------------- classes (C, LxC, S, OLA)
def classe_C_T1(spears, sinais, intervalos, margens):
    if not spears or any(x is None for x in spears + intervalos + margens):
        return 'INSUFICIENTE'
    ok = (all(s * sg >= C_SPEAR for s, sg in zip(spears, sinais)) and all(abs(i - 1) <= C_INTERV for i in intervalos)
          and all(m > 1.0 for m in margens))
    return 'ONDA_PROPAGADA' if ok else 'SEM_PROPAGACAO'


def classe_C_solta(margens):
    if not margens or any(m is None for m in margens):
        return 'INSUFICIENTE'
    return 'ONDA_PROPAGADA' if all(m > 1.0 for m in margens) else 'SEM_SOLTURA'


def classe_C_T4(intervalos_por_dur):
    if not intervalos_por_dur or any(v is None for v in intervalos_por_dur.values()):
        return 'INSUFICIENTE'
    if all(abs(v - 1) <= INTERVALO_TOL for v in intervalos_por_dur.values()):
        return 'VELOCIDADE_FIXA'
    ds = sorted(intervalos_por_dur)
    if intervalos_por_dur[ds[-1]] / intervalos_por_dur[ds[0]] >= C_SEGUE:
        return 'VELOCIDADE_SEGUE_A_MENSAGEM'
    return 'INDEFINIDA'


def classe_C_T5(razoes):
    r = med(razoes)
    if r is None:
        return 'INSUFICIENTE', r
    return ('SEM_BLOQUEIO' if r >= C_SEM_BLOQ else 'BLOQUEIO_PARCIAL'), r


def classe_global_C(t1, t4, t6):
    if 'INSUFICIENTE' in (t1, t4, t6):
        return 'INSUFICIENTE'
    if t1 == 'ONDA_PROPAGADA' and t4 == 'VELOCIDADE_FIXA' and t6 == 'BLOQUEADA':
        return 'ONDA_COM_CAMINHO'
    return 'PARCIAL'


def classe_LxC(gL, gC, t4L):
    if 'INSUFICIENTE' in (gL, gC, t4L):
        return 'INSUFICIENTE'
    if gL == 'ONDA_PROGRAMADA' and gC == 'ONDA_COM_CAMINHO' and t4L.startswith('VELOCIDADE_LIVRE'):
        return 'SEPARACAO'
    if (gL == 'ONDA_PROGRAMADA') == (gC == 'ONDA_PROGRAMADA'):
        return 'IGUAIS'
    return 'MISTA'


def classe_onda_S(acertos, contrastes, n_esperado):
    a = fin(acertos)
    if n_esperado == 0 or len(a) < MIN_VALIDAS * n_esperado:
        return 'INSUFICIENTE', None, None
    ma, mc = med(a), med(contrastes)
    if ma >= ACERTO_LIMPA and mc is not None and mc >= CONTRASTE_MIN:
        return 'ONDA_LIMPA', ma, mc
    if ma >= ACERTO_BORRADA:
        return 'ONDA_BORRADA', ma, mc
    return 'SEM_ONDA', ma, mc


def classe_custo(frac):
    if frac is None:
        return 'INSUFICIENTE'
    if frac >= CUSTO_SIM:
        return 'SEGUE_O_CUSTO'
    if frac <= CUSTO_NAO:
        return 'NAO_SEGUE_O_CUSTO'
    return 'INTERMEDIARIO'


def classe_global_S(gen, alvo, custo):
    if 'INSUFICIENTE' in (gen, alvo, custo):
        return 'INSUFICIENTE'
    if alvo == 'ONDA_LIMPA' or gen == 'ONDA_LIMPA':
        return 'ONDA_LEMBRADA'
    if gen == 'SEM_ONDA' and alvo == 'SEM_ONDA' and custo == 'SEGUE_O_CUSTO':
        return 'ONDA_ESQUECIDA'
    return 'MISTA'


def classe_controle(refs, ctrls):
    refs, ctrls = list(refs), list(ctrls)
    if not refs or any(c in (None, 'INSUFICIENTE') for c in refs + ctrls):
        return 'INSUFICIENTE'
    return 'CONSISTENTE' if refs == ctrls else 'INCONSISTENTE'


def existe(c):
    """controle de tamanho: a folga da difusão cresce com M (§9), então compara-se só se a onda existe."""
    return {'ONDA': 'EXISTE', 'ONDA_FRAGIL': 'EXISTE', 'SEM_ONDA': 'NAO_EXISTE'}.get(c, c)


def classe_OLA(gL, lxc, gS):
    if 'INSUFICIENTE' in (gL, lxc, gS):
        return 'INSUFICIENTE'
    if gL == 'NAO_PROGRAMADA':
        return 'SEM_ONDA_PROGRAMADA'
    if gL == 'ONDA_PROGRAMADA' and lxc == 'SEPARACAO' and gS == 'ONDA_ESQUECIDA':
        return 'ONDA_SEM_CAMINHO_SO_NA_BASE_LIVRE'
    if gL == 'ONDA_PROGRAMADA' and gS == 'ONDA_LEMBRADA':
        return 'ONDA_SEM_CAMINHO_NAS_DUAS'
    return 'MISTA'


# ---------------------------------------------------------------- leitura dos checkpoints
def carregar(pasta):
    recs = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(pasta, '*.json'))) if not os.path.basename(f).startswith(('config', 'avaliacao'))]
    return recs, json.load(open(os.path.join(pasta, 'config_B39.json')))


def rods(recs, **filtro):
    out = []
    for r in recs:
        for q in r.get('rodadas', []):
            if all(q.get(k) == v for k, v in filtro.items()):
                out.append((r, q))
    return out


def por_casa(q, chave):
    return dict(zip(q['casas'], q[chave]))


def avaliar_L_M(recs, M, nS):
    rs = [r for r in recs if r['parte'] == 'L' and r['M'] == M]
    o = {'n_sementes': len(rs), 'T1': {}}
    for tipo in TIPOS:
        for s in ((1, -1) if tipo != 'generica' else ('ambos',)):
            filtro = {'teste': 'T1', 'tipo': tipo}
            if s != 'ambos':
                filtro['sentido'] = s
            q = [x for _, x in rods(rs, **filtro)]
            n_esp = 3 * nS * (2 if s == 'ambos' else 1)
            for modo in ('trava', 'solta'):
                o['T1']['%s_%s_%s' % (tipo, s, modo)] = list(classe_onda([x['margem_' + modo] for x in q], n_esp))
            o['T1']['%s_%s_picos_med' % (tipo, s)] = med([float(np.median(x['pico'])) for x in q])
    T = o['T1']
    o['quiral'] = {tipo: classe_quiral(T['%s_1_solta' % tipo][0], T['%s_-1_solta' % tipo][0]) for tipo in ('difusao', 'alvo')}
    o['quiral_razao_picos'] = {tipo: (T['%s_1_picos_med' % tipo] / T['%s_-1_picos_med' % tipo]
                                      if T['%s_1_picos_med' % tipo] and T['%s_-1_picos_med' % tipo] else None) for tipo in ('difusao', 'alvo')}
    o['codigos'] = classe_codigos(T['alvo_1_solta'][2], T['difusao_1_solta'][2], T['generica_ambos_solta'][2])
    # T3: tudo ou nada (difusão e alvo)
    t3 = []
    for _, x in rods(rs, teste='T1', ordem='leste_oeste', sentido=1):
        if x['tipo'] in ('difusao', 'alvo') and 'T3_forca' in x:
            f = x['T3_forca']; cs = x['casas']
            t3.append({'F_rel': f['F_rel'], 'disparadas': [[d[h] for h in cs] for d in f['disparadas']],
                       'brilho_max': [[b[h] for h in cs] for b in f['brilho_max']]})
    o['T3'] = list(classe_tudo_ou_nada(t3)) if len(t3) >= MIN_VALIDAS * 2 * nS else ['INSUFICIENTE', None]
    # T4: velocidade (por tipo)
    o['T4'] = {}; o['T4_valores'] = {}
    for tipo in ('difusao', 'alvo'):
        fr, it, mg = {}, {}, {}
        for tau in (75.0, 150.0, 300.0, 600.0):
            if tau == 300.0:
                q = [x for _, x in rods(rs, teste='T1', tipo=tipo, ordem='leste_oeste', sentido=1)]
            else:
                q = [x for _, x in rods(rs, teste='T4', tipo=tipo, tau=tau)]
            ok = len(q) >= MIN_VALIDAS * nS
            fr[tau] = float(np.mean([x['margem_trava'] > 1 for x in q])) if ok else None
            it[tau] = med([x.get('intervalo_rel') for x in q]) if q else None
            mg[tau] = med([x['margem_trava'] for x in q]) if q else None
        o['T4_valores'][tipo] = {'fracao_margem_maior_1': fr, 'intervalo_rel': it, 'margem_trava': mg}
        o['T4'][tipo] = classe_velocidade(fr, it, mg.get(75.0), mg.get(300.0))
    # T5, T6, T7 (difusão e alvo juntos)
    raz5, dt5, raz6, dt6, eco = [], [], [], [], {'difusao': [], 'alvo': []}
    for r in rs:
        for tipo in ('difusao', 'alvo'):
            ref = [q for q in r['rodadas'] if q['teste'] == 'T1' and q['tipo'] == tipo and q['ordem'] == 'leste_oeste' and q['sentido'] == 1]
            if not ref:
                continue
            ref = ref[0]; pk_r = por_casa(ref, 'pico'); tf_r = ref['t_fecha']
            for nome, raz, dts in (('T5', raz5, dt5), ('T6', raz6, dt6)):
                alt = [q for q in r['rodadas'] if q['teste'] == nome and q['tipo'] == tipo]
                if not alt:
                    continue
                alt = alt[0]; pk_a = por_casa(alt, 'pico'); tf_a = alt['t_fecha']
                for h in alt['casas']:
                    if h == CASA_REMOVIDA:
                        continue
                    if pk_r.get(h, 0) > 0:
                        raz.append(pk_a[h] / pk_r[h])
                    if tf_r[h] is not None and tf_a[h] is not None:
                        dts.append(abs(tf_a[h] - tf_r[h]) / ref['tau'])
            sp = [q for q in r['rodadas'] if q['teste'] == 'T7' and q['tipo'] == tipo]
            if sp:
                e_cp = max(ref['pos']) / min(ref['pico']); e_sp = max(sp[0]['pos']) / min(sp[0]['pico'])
                if e_cp > 0:
                    eco[tipo].append(e_sp / e_cp)
    o['T5'] = list(classe_dependencia(raz5, dt5))
    o['T6'] = list(classe_corte(raz6, dt6))
    o['T7'] = list(classe_eco(eco)) if all(len(v) >= MIN_VALIDAS * nS for v in eco.values()) else ['INSUFICIENTE', None]
    o['T7_margem_solta_sem_perdas'] = {tipo: med([x['margem_solta'] for _, x in rods(rs, teste='T7', tipo=tipo)]) for tipo in ('difusao', 'alvo')}
    # a rede: sozinha não dispara; ligada não muda os disparos. Decide sobre o telecomando que funciona
    # (difusão e alvo, s = +1); todas as rodadas T1 ficam registradas como descrição.
    q1 = [x for _, x in rods(rs, teste='T1')]
    qd = [x for x in q1 if x['tipo'] in ('difusao', 'alvo') and x['sentido'] == 1]
    o['rede_dispara'] = list(classe_rede_dispara([x['so_rede_max'] / x['theta_trava'] for x in qd if x['theta_trava'] > 0]))
    o['rede_dispara_todas_T1'] = classe_rede_dispara([x['so_rede_max'] / x['theta_trava'] for x in q1 if x['theta_trava'] > 0])[1]
    o['rede_interfere'] = list(classe_rede_interfere(*diferencas_rede(qd)))
    o['rede_interfere_todas_T1'] = list(classe_rede_interfere(*diferencas_rede(q1)))[1:]
    o['rede_sobre_mensagem_mediana'] = med([x.get('rede_sobre_mensagem') for x in q1])
    o['global'] = classe_global_L(T['difusao_1_trava'][0], T['alvo_1_trava'][0], o['T4']['difusao'], o['T5'][0], o['T6'][0])
    return o


def diferencas_rede(q1):
    dts, conc = [], []
    for x in q1:
        d, c = [], []
        for h in x['casas']:
            a, b = x['t_fecha'][h], x['t_fecha_sem_rede'][h]
            c.append((a is None) == (b is None))
            if a is not None and b is not None:
                d.append(abs(a - b) / x['tau'])
        dts.append(med(d) if d else 0.0); conc.append(float(np.mean(c)))
    return dts, conc


def avaliar_C(recs):
    rs = [r for r in recs if r['parte'] == 'C']
    vazio = {'T1': 'INSUFICIENTE', 'T1_solta': 'INSUFICIENTE', 'T4': 'INSUFICIENTE', 'T5': ['INSUFICIENTE', None],
             'T6': ['INSUFICIENTE', None, None], 'rede_dispara': ['INSUFICIENTE', None], 'global': 'INSUFICIENTE'}
    if not rs:
        return vazio
    r = rs[0]; pos = r['pos']; It = r['intervalo_teorico']; fonte = r['fonte']
    from scipy.stats import rankdata

    def sp(tf, lado):
        if any(x is None for x in tf):
            return None
        dist = [abs(p - fonte[lado]) for p in pos]
        return float(np.corrcoef(rankdata(tf), rankdata(dist))[0, 1])

    def interv(tf):
        if any(x is None for x in tf):
            return None
        o_ = np.argsort(pos)
        return float(np.median(np.abs(np.diff(np.array(tf)[o_]))) / It)
    q1 = [q for q in r['rodadas'] if q['teste'] == 'T1']
    if not q1:
        return vazio
    o = {'T1_valores': [{'lado': q['lado'], 'sentido': q['sentido'], 'spearman': sp(q['t_fecha'], q['lado']), 'intervalo_rel': interv(q['t_fecha']),
                         'margem_trava': q['margem_trava'], 'margem_solta': q['margem_solta']} for q in q1]}
    V = o['T1_valores']
    o['T1'] = classe_C_T1([v['spearman'] for v in V], [1] * len(V), [v['intervalo_rel'] for v in V], [v['margem_trava'] for v in V])
    o['T1_solta'] = classe_C_solta([v['margem_solta'] for v in V])
    itd = {}
    for q in r['rodadas']:
        if q['lado'] == 'leste' and q['sentido'] == 1 and q['teste'] in ('T1', 'T4'):
            itd[q['dur']] = interv(q['t_fecha'])
    o['T4_valores'] = itd
    o['T4'] = classe_C_T4(itd)
    ref = [q for q in q1 if q['lado'] == 'leste' and q['sentido'] == 1][0]
    for nome in ('T5', 'T6'):
        alt = [q for q in r['rodadas'] if q['teste'] == nome]
        raz, dts = [], []
        if alt:
            for k in range(CASA_REMOVIDA + 1, len(ref['pico_casa'])):
                if ref['pico_casa'][k] > 0:
                    raz.append(alt[0]['pico_casa'][k] / ref['pico_casa'][k])
                if ref['t_fecha'][k] is not None and alt[0]['t_fecha'][k] is not None:
                    dts.append(abs(alt[0]['t_fecha'][k] - ref['t_fecha'][k]) / It)
        o[nome] = list(classe_C_T5(raz)) if nome == 'T5' else list(classe_corte(raz, dts))
    o['rede_dispara'] = list(classe_rede_dispara([max(r['rede']['leitura_so_rede_max']) / ref['theta_trava']] if ref['theta_trava'] > 0 else []))
    o['global'] = classe_global_C(o['T1'], o['T4'], o['T6'][0])
    return o


def avaliar_S(recs, rot, n_sem):
    rs = [r for r in recs if r['parte'] == 'S' and r.get('rotulo') == rot]
    val = [r for r in rs if r['gap'] >= GAP_MIN and all(abs(q['norma'] - 1) <= NORMA_TOL for q in r['rodadas'])]
    o = {'n_sementes': len(rs), 'validas': len(val)}
    ordens = {'leste_oeste': [0, 1, 2, 3], 'oeste_leste': [3, 2, 1, 0]}
    for alvo in (False, True):
        q = [x for _, x in rods(val, alvo=alvo)]
        cons = []
        for x in q:
            G = np.array(x['G']); ordem = ordens[x['ordem']]
            c = []
            for j, h in enumerate(ordem):
                resto = np.delete(G[:, j], h)
                c.append(max(G[h, j], 0.0) / max(np.max(resto), 1e-300))
            cons.append(float(np.median(c)))
        o['T1_' + ('alvo' if alvo else 'generico')] = list(classe_onda_S([x['acerto'] for x in q], cons, 4 * n_sem))
    todas = [x for _, x in rods(val)]
    venc = [v for x in todas for v in x['vencedores']]
    frac = float(np.mean([v in (0, 1) for v in venc])) if venc and len(todas) >= MIN_VALIDAS * 8 * n_sem else None
    o['T2'] = [classe_custo(frac), frac]
    from scipy.stats import rankdata
    sps = []
    for x in todas:
        d = np.array(x['dn_final'])
        sps.append(float(np.corrcoef(rankdata(d), rankdata([-w for w in (0.3, 0.5, 0.7, 0.9)]))[0, 1]) if np.std(d) > 0 else 0.0)
    ms = med(sps)
    o['T2b'] = ['ORDEM_FINAL_POR_CUSTO' if (ms is not None and ms >= ORDEM_FINAL) else ('INSUFICIENTE' if ms is None else 'ORDEM_FINAL_OUTRA'), ms]
    o['global'] = classe_global_S(o['T1_generico'][0], o['T1_alvo'][0], o['T2'][0])
    return o


PREVISOES = {
    'L.T1_difusao_trava': 'ONDA', 'L.T1_difusao_solta': 'ONDA_FRAGIL',
    'L.T1_alvo_trava': 'ONDA', 'L.T1_alvo_solta': 'ONDA',
    'L.T1_generica_trava': 'ONDA_FRAGIL', 'L.T1_generica_solta': 'SEM_ONDA',
    'L.quiral_difusao': 'QUIRAL', 'L.quiral_alvo': 'QUIRAL', 'L.codigos': 'HIERARQUIA_FORMA_FREQUENCIA_FORA',
    'L.T3': 'TUDO_OU_NADA', 'L.T4_difusao': 'VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA', 'L.T4_alvo': 'VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA',
    'L.T5': 'SEM_DEPENDENCIA', 'L.T6': 'ATRAVESSA', 'L.T7': 'PERDAS_APAGAM_O_ECO',
    'L.rede_dispara': 'REDE_NAO_DISPARA', 'L.rede_interfere': 'REDE_NAO_INTERFERE',
    'L.global': 'ONDA_PROGRAMADA', 'L.controle_M': 'CONSISTENTE',
    'C.T1': 'ONDA_PROPAGADA', 'C.T1_solta': 'ONDA_PROPAGADA', 'C.T4': 'VELOCIDADE_FIXA', 'C.T5': 'SEM_BLOQUEIO', 'C.T6': 'BLOQUEADA',
    'C.rede_dispara': 'REDE_NAO_DISPARA', 'C.global': 'ONDA_COM_CAMINHO',
    'LxC': 'SEPARACAO',
    'S.T1_generico': 'SEM_ONDA', 'S.T1_alvo': 'SEM_ONDA', 'S.T2': 'SEGUE_O_CUSTO', 'S.T2b': 'ORDEM_FINAL_POR_CUSTO',
    'S.global': 'ONDA_ESQUECIDA', 'S.controle_N24': 'CONSISTENTE',
    'OLA': 'ONDA_SEM_CAMINHO_SO_NA_BASE_LIVRE',
}
CONTROLE_M_ITENS = ('difusao_1_trava', 'difusao_1_solta', 'alvo_1_trava', 'alvo_1_solta')


def avaliar_recs(recs, cfg):
    C_ = cfg['config']
    res = {'modo': cfg['modo'], 'L': {}}
    for M in C_['L']['M']:
        res['L']['M%d' % M] = avaliar_L_M(recs, M, C_['L']['n_sementes'])
    Ld = res['L']['M%d' % C_['L']['M_decisao']]; Lc = res['L']['M%d' % C_['L']['M_controle']]
    res['L']['controle_M'] = classe_controle([existe(Ld['T1'][k][0]) for k in CONTROLE_M_ITENS], [existe(Lc['T1'][k][0]) for k in CONTROLE_M_ITENS])
    res['C'] = avaliar_C(recs)
    res['S'] = {rot: avaliar_S(recs, rot, len(C_[rot]['sementes'])) for rot in ('S20', 'S24')}
    res['S']['controle_N24'] = classe_controle([res['S']['S20']['global']], [res['S']['S24']['global']])
    res['LxC'] = classe_LxC(Ld['global'], res['C']['global'], Ld['T4']['difusao'])
    res['OLA'] = classe_OLA(Ld['global'], res['LxC'], res['S']['S20']['global'])
    T = Ld['T1']
    obt = {'L.T1_difusao_trava': T['difusao_1_trava'][0], 'L.T1_difusao_solta': T['difusao_1_solta'][0],
           'L.T1_alvo_trava': T['alvo_1_trava'][0], 'L.T1_alvo_solta': T['alvo_1_solta'][0],
           'L.T1_generica_trava': T['generica_ambos_trava'][0], 'L.T1_generica_solta': T['generica_ambos_solta'][0],
           'L.quiral_difusao': Ld['quiral']['difusao'], 'L.quiral_alvo': Ld['quiral']['alvo'], 'L.codigos': Ld['codigos'],
           'L.T3': Ld['T3'][0], 'L.T4_difusao': Ld['T4']['difusao'], 'L.T4_alvo': Ld['T4']['alvo'],
           'L.T5': Ld['T5'][0], 'L.T6': Ld['T6'][0], 'L.T7': Ld['T7'][0],
           'L.rede_dispara': Ld['rede_dispara'][0], 'L.rede_interfere': Ld['rede_interfere'][0],
           'L.global': Ld['global'], 'L.controle_M': res['L']['controle_M'],
           'C.T1': res['C']['T1'], 'C.T1_solta': res['C']['T1_solta'], 'C.T4': res['C']['T4'], 'C.T5': res['C']['T5'][0],
           'C.T6': res['C']['T6'][0], 'C.rede_dispara': res['C']['rede_dispara'][0], 'C.global': res['C']['global'],
           'LxC': res['LxC'],
           'S.T1_generico': res['S']['S20']['T1_generico'][0], 'S.T1_alvo': res['S']['S20']['T1_alvo'][0], 'S.T2': res['S']['S20']['T2'][0],
           'S.T2b': res['S']['S20']['T2b'][0], 'S.global': res['S']['S20']['global'], 'S.controle_N24': res['S']['controle_N24'],
           'OLA': res['OLA']}
    res['previsto_x_obtido'] = {k: {'previsto': PREVISOES[k], 'obtido': obt[k], 'confere': obt[k] == PREVISOES[k]} for k in PREVISOES}
    return res


def main():
    pasta = sys.argv[1]
    recs, cfg = carregar(pasta)
    res = avaliar_recs(recs, cfg)
    json.dump(res, open(os.path.join(pasta, 'avaliacao_B39.json'), 'w'), indent=1, default=lambda o: o.tolist() if hasattr(o, 'tolist') else str(o))
    print('B39 — avaliação (%s)\n' % res['modo'])
    for k, v in res['previsto_x_obtido'].items():
        print('  %-22s previsto %-42s obtido %-42s %s' % (k, v['previsto'], v['obtido'], 'confere' if v['confere'] else 'NÃO confere'))


if __name__ == '__main__':
    main()
