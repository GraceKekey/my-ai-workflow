"""B39 — figura da fumaça: brilho das dez lâmpadas ao longo do tempo (base livre, M = 800, primeira semente,
ordem leste → oeste, s = +1), para as três mensagens e os dois relés, no limiar do meio da janela.
Uso: python figura_fumaca_B39.py PASTA_FUMACA SAIDA.png"""
import glob, json, os, sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

pasta, saida = sys.argv[1], sys.argv[2]
arq = sorted(glob.glob(os.path.join(pasta, 'L_M800_*.json')))[0]
rec = json.load(open(arq))
plt.rcParams.update({'font.size': 9, 'axes.formatter.use_locale': False})
fmt = lambda v, _=None: ('%g' % v).replace('.', ',')
NOMES = {'difusao': 'difusão (telecomando)', 'alvo': 'endereçada (forma da fiação)', 'generica': 'genérica (fora da fiação)'}
RELE = {'trava': 'relé que trava → frente', 'solta': 'relé que solta → ola'}
fig, ax = plt.subplots(3, 2, figsize=(10, 7.2), sharex=True, sharey=True, constrained_layout=True)
for i, tipo in enumerate(('difusao', 'alvo', 'generica')):
    q = [x for x in rec['rodadas'] if x['teste'] == 'T1' and x['tipo'] == tipo and x['ordem'] == 'leste_oeste' and x['sentido'] == 1][0]
    tau = q['tau']
    for j, modo in enumerate(('trava', 'solta')):
        c = q['curva_brilho_' + modo]; ts = np.array(c['ts']) / tau; b = np.array(c['v']).T
        im = ax[i, j].imshow(b, aspect='auto', origin='lower', cmap='Oranges', vmin=0, vmax=1, interpolation='nearest',
                             extent=[ts[0], ts[-1], -0.5, b.shape[0] - 0.5])
        for k in range(b.shape[0]):               # a vez de cada casa (janela de fechamento)
            ax[i, j].plot([k, k + 1.25], [k, k], color='0.35', lw=0.6, alpha=0.6)
        m = q['margem_' + modo]
        ax[i, j].set_title('%s — %s\nmargem %s · acerto %s' % (NOMES[tipo], RELE[modo], (('%.2f' % m) if m < 10 else ('%.0f' % m)).replace('.', ','),
                                                              fmt(q['acerto_' + modo])), fontsize=8.5, loc='left')
        ax[i, j].set_yticks(range(10)); ax[i, j].set_yticklabels(['%d' % k for k in range(10)], fontsize=7)
        ax[i, j].xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(fmt))
for a in ax[:, 0]:
    a.set_ylabel('casa (0 = leste)')
for a in ax[-1, :]:
    a.set_xlabel('tempo / τ (τ = 300)')
cb = fig.colorbar(im, ax=ax, shrink=0.6, label='brilho da lâmpada (1 = pleno, vindo da rede)')
cb.ax.yaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(fmt))
fig.suptitle('B39, fumaça (M = 800, semente %d): a mensagem chama uma casa por intervalo; a luz vem da rede\n'
             'traço cinza = a vez de cada casa' % rec['semente'], fontsize=10, x=0.02, ha='left')
fig.savefig(saida, dpi=150)
print('gravado', saida)
