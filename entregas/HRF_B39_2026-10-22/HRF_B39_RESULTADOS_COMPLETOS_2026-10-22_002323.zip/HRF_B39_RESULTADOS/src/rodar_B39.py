"""B39 — executor (rede sempre ligada; mensagem só comanda o relé). Uso:
    python rodar_B39.py --modo fumaca|completo --parte L|C|S20|S24|todas [--saida PASTA]
Cada (parte, tamanho, semente) grava um checkpoint JSON atômico; checkpoints existentes são pulados (retomada).
config_B39.json registra parâmetros e SHA-256 dos módulos."""
import argparse, hashlib, json, os, sys, time, platform, resource
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import b39_cidade as C
import b39_rele as RL
import b39_syk as S
from b39_linear import SistemaLinear, energia_rede

CONFIG = {
    'completo': {
        'L': {'M': [400, 800, 1600], 'n_sementes': 4, 'base_semente': 39500, 'M_decisao': 1600, 'M_controle': 800},
        'C': {'H': 10, 'Mc': 800},
        'S20': {'N': 20, 'sementes': [3931, 3932, 3933, 3934]},
        'S24': {'N': 24, 'sementes': [3941]},
    },
    'fumaca': {
        'L': {'M': [400, 800], 'n_sementes': 2, 'base_semente': 39000, 'M_decisao': 800, 'M_controle': 400},
        'C': {'H': 7, 'Mc': 600},
        'S20': {'N': 16, 'sementes': [3990]},
        'S24': {'N': 20, 'sementes': [3991]},
    },
}
TAU_S, F_S, DT_S = 80.0, 0.05, 0.1
ORDENS_S = {'leste_oeste': [0, 1, 2, 3], 'oeste_leste': [3, 2, 1, 0]}
DUR_C = [150.0, 300.0, 600.0]
F_REL = [0.25, 0.5, 1.0, 2.0]       # T3: força da mensagem (múltiplos de F0), relé calibrado em metade do sinal nominal
PASSO_CURVA = 2.5


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def grava(caminho, obj):
    tmp = caminho + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(obj, f, default=lambda o: o.tolist() if hasattr(o, 'tolist') else float(o))
    os.replace(tmp, caminho)


def mem_gb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6


def curva(ts, X, passo=PASSO_CURVA):
    k = max(1, int(round(passo / (ts[1] - ts[0]))))
    return {'ts': ts[::k].tolist(), 'v': np.asarray(X)[::k].tolist()}


def avalia_forca(ts, X, P, Om, Xr, ordem, ini, fim, pos):
    """T3: relé (trava) calibrado em metade do menor pico nominal; a força da mensagem varia, a rede fica igual."""
    R1 = RL.leitura(ts, X, P, Om, Xr, C.A_REDE, C.OM_R)
    m1 = RL.margens(ts, R1, ini, fim, pos, ordem)
    th = 0.5 * min(m1['pico'])
    out = {'theta': th, 'F_rel': F_REL, 'disparadas': [], 'brilho_max': [], 'luz': []}
    for F in F_REL:
        R = RL.leitura(ts, X, P, Om, Xr, C.A_REDE, C.OM_R, F_rel=F)
        r = RL.rele(ts, R, th, 'trava'); b = RL.lampada(ts, r)
        out['disparadas'].append([int(r[:, h].max() > 0) for h in range(r.shape[1])])
        out['brilho_max'].append(b.max(0).tolist())
        out['luz'].append((b.sum(0) * (ts[1] - ts[0])).tolist())
    return out


# ---------------------------------------------------------------- L
def rodar_L(cfg, saida, log):
    for iM, M in enumerate(cfg['M']):
        for k in range(cfg['n_sementes']):
            sd = cfg['base_semente'] + 100 * iM + k
            cam = os.path.join(saida, 'L_M%d_s%d.json' % (M, sd))
            if os.path.exists(cam):
                log('pulado %s' % cam); continue
            t0 = time.time()
            cid = C.CidadeL(M, sd)
            sis = {'e': SistemaLinear(cid.K(), cid.D(True)), 'sp': SistemaLinear(cid.K(), cid.D(False)),
                   'sem': SistemaLinear(cid.K(sem=C.CASA_REMOVIDA), cid.D(True)),
                   'corte': SistemaLinear(cid.K(corte=True), cid.D(True))}
            Xr_full = {k_: v.rede(cid.f_rede(), C.OM_R) for k_, v in sis.items()}
            Xr = {k_: v[M:] for k_, v in Xr_full.items()}
            E_r, P_r = energia_rede(sis['e'], Xr_full['e'], M, C.OM_R)
            ts0 = np.arange(0.0, 13 * C.TAU + 1e-9, C.AMOSTRA)
            so_rede = {k_: RL.leitura(ts0, np.zeros((len(ts0), C.H)), np.zeros((len(ts0), C.H)), C.OM_L, v, C.A_REDE, C.OM_R).max(0).tolist()
                       for k_, v in Xr.items()}
            rec = {'parte': 'L', 'M': M, 'semente': sd, 'cond': {k_: v.cond for k_, v in sis.items()},
                   'rede': {'energia_base': E_r * C.A_REDE ** 2, 'potencia_reposta': P_r * C.A_REDE ** 2,
                            'Xr_receptores_abs': {k_: (np.abs(v) * C.A_REDE).tolist() for k_, v in Xr.items()},
                            'leitura_so_rede_max': so_rede},
                   'rodadas': []}

            def R_(nome, sk, ordem_n, tau, tipo, s, extra=False):
                ordem_full = C.ORDENS[ordem_n]
                ts, X, P = cid.rodar(sis[sk], ordem_full, tau, tipo, s)
                Emsg = sis[sk].energia_max
                ordem = [h for h in ordem_full if not (sk == 'sem' and h == C.CASA_REMOVIDA)]
                ini, fim, pos = C.janelas_L(ordem_full, tau)
                R = RL.leitura(ts, X, P, C.OM_L, Xr[sk], C.A_REDE, C.OM_R)
                m = RL.medidas(ts, R, ordem, ini, fim, pos, tau)
                R0 = RL.leitura(ts, X, P, C.OM_L)                  # mesma mensagem, rede desligada
                r0 = RL.rele(ts, R0, m['theta_trava'], 'trava')
                m['t_fecha_sem_rede'] = [float(ts[np.argmax(r0[:, h] > 0)]) if r0[:, h].max() > 0 else None for h in range(C.H)]
                m0 = RL.margens(ts, R0, ini, fim, pos, ordem)
                m['margem_trava_sem_rede'] = m0['margem_trava']; m['margem_solta_sem_rede'] = m0['margem_solta']
                m['so_rede_max'] = float(max(so_rede[sk][h] for h in ordem))
                m['energia_msg_base_max'] = Emsg
                m['rede_sobre_mensagem'] = rec['rede']['energia_base'] / Emsg if Emsg > 0 else None
                m.update({'teste': nome, 'sistema': sk, 'ordem': ordem_n, 'casas': ordem, 'tau': tau, 'tipo': tipo, 'sentido': s})
                if extra:
                    m['T3_forca'] = avalia_forca(ts, X, P, C.OM_L, Xr[sk], ordem, ini, fim, pos)
                    m['curva_R'] = curva(ts, R)
                    for modo in ('trava', 'solta'):
                        m['curva_brilho_' + modo] = curva(ts, RL.lampada(ts, RL.rele(ts, R, m['theta_' + modo], modo)))
                rec['rodadas'].append(m)

            for tipo in C.TIPOS:
                for on in C.ORDENS:
                    for s in (1, -1):
                        R_('T1', 'e', on, C.TAU, tipo, s, extra=(on == 'leste_oeste' and s == 1))
            for tipo in ('difusao', 'alvo'):
                for tau in C.TAUS:
                    if tau != C.TAU:
                        R_('T4', 'e', 'leste_oeste', tau, tipo, 1)
                R_('T5', 'sem', 'leste_oeste', C.TAU, tipo, 1)
                R_('T6', 'corte', 'leste_oeste', C.TAU, tipo, 1)
                R_('T7', 'sp', 'leste_oeste', C.TAU, tipo, 1)
            rec['tempo_s'] = time.time() - t0; rec['mem_gb'] = mem_gb()
            grava(cam, rec)
            log('L M=%d semente=%d: %.0f s, %.2f GB' % (M, sd, rec['tempo_s'], rec['mem_gb']))


# ---------------------------------------------------------------- C
def rodar_C(cfg, saida, log):
    cam = os.path.join(saida, 'C_H%d.json' % cfg['H'])
    if os.path.exists(cam):
        log('pulado %s' % cam); return
    t0 = time.time()
    cid = C.CidadeC(Hc=cfg['H'], Mc=cfg['Mc'])
    sis = {'e': SistemaLinear(cid.K(), cid.D()), 'sem': SistemaLinear(cid.K(sem=C.CASA_REMOVIDA), cid.D()),
           'corte': SistemaLinear(cid.K(corte=True), cid.D())}
    Xr_full = {k: v.rede(cid.f_rede(), C.OM_R) for k, v in sis.items()}
    Xr = {k: v[cid.Mc:] for k, v in Xr_full.items()}
    E_r, P_r = energia_rede(sis['e'], Xr_full['e'], cid.Mc, C.OM_R)
    Om = np.full(cid.H, C.OM_C); vg = C.vg_linha()
    ts0 = np.arange(0.0, 4000.0, C.AMOSTRA)
    so_rede = RL.leitura(ts0, np.zeros((len(ts0), cid.H)), np.zeros((len(ts0), cid.H)), Om, Xr['e'], C.A_REDE, C.OM_R).max(0).tolist()
    rec = {'parte': 'C', 'H': cfg['H'], 'Mc': cfg['Mc'], 'pos': cid.pos.tolist(), 'fonte': cid.fonte, 'vg': vg,
           'intervalo_teorico': C.D_C / vg, 'cond': {k: v.cond for k, v in sis.items()},
           'rede': {'energia_base': E_r * C.A_REDE ** 2, 'potencia_reposta': P_r * C.A_REDE ** 2, 'leitura_so_rede_max': so_rede},
           'rodadas': []}

    def R_(nome, sk, lado, dur, s):
        ts, X, P = cid.rodar(sis[sk], lado, dur, s)
        Emsg = sis[sk].energia_max
        ordem = [h for h in cid.ordem(lado) if not (sk == 'sem' and h == C.CASA_REMOVIDA)]
        ini, fim, pos = cid.janelas(lado, dur)
        R = RL.leitura(ts, X, P, Om, Xr[sk], C.A_REDE, C.OM_R)
        m = RL.medidas(ts, R, ordem, ini, fim, pos, C.D_C / vg)
        m['pico_casa'] = [float(R[:, h].max()) for h in range(cid.H)]
        m['energia_msg_base_max'] = Emsg
        m['rede_sobre_mensagem'] = rec['rede']['energia_base'] / Emsg if Emsg > 0 else None
        m.update({'teste': nome, 'sistema': sk, 'lado': lado, 'dur': dur, 'sentido': s, 'casas': ordem})
        if nome == 'T1' and lado == 'leste' and s == 1:
            m['curva_R'] = curva(ts, R)
            for modo in ('trava', 'solta'):
                m['curva_brilho_' + modo] = curva(ts, RL.lampada(ts, RL.rele(ts, R, m['theta_' + modo], modo)))
        rec['rodadas'].append(m)

    for lado in ('leste', 'oeste'):
        for s in (1, -1):
            R_('T1', 'e', lado, 300.0, s)
    for dur in DUR_C:
        if dur != 300.0:
            R_('T4', 'e', 'leste', dur, 1)
    R_('T5', 'sem', 'leste', 300.0, 1)
    R_('T6', 'corte', 'leste', 300.0, 1)
    rec['tempo_s'] = time.time() - t0; rec['mem_gb'] = mem_gb()
    grava(cam, rec)
    log('C H=%d: %.0f s, %.2f GB' % (cfg['H'], rec['tempo_s'], rec['mem_gb']))


# ---------------------------------------------------------------- S (só detecção: quem a base excita)
def ganhos_S(ts, ns, ordem, tau):
    """G[k, j]: aumento da ocupação média da casa k na janela do slot j, W_j = [jτ + τ/4, (j+1)τ + τ/4],
    em relação à janela anterior."""
    at = lambda t: int(np.argmin(np.abs(ts - t)))
    Hn = ns.shape[1]; G = np.zeros((Hn, len(ordem)))
    for j in range(len(ordem)):
        a, b = at(j * tau + tau / 4), at((j + 1) * tau + tau / 4)
        m = ns[a:b].mean(0)
        mp = ns[at((j - 1) * tau + tau / 4):a].mean(0) if j > 0 else np.zeros(Hn)
        G[:, j] = m - mp
    return G


def rodar_S(rot, cfg, saida, log):
    N = cfg['N']
    for sd in cfg['sementes']:
        cam = os.path.join(saida, '%s_N%d_s%d.json' % (rot, N, sd))
        if os.path.exists(cam):
            log('pulado %s' % cam); continue
        t0 = time.time()
        m = S.SYK(N, sd); Hm = m.H(S.OM); gs = S.fundamental(m, Hm)
        rec = {'parte': 'S', 'rotulo': rot, 'N': N, 'semente': sd, 'gap': gs['gap'], 'E0': gs['E0'], 'rodadas': []}
        for alvo in (False, True):
            for on, ordem in ORDENS_S.items():
                for s in (1, -1):
                    ts, ns, nrm = S.onda(m, gs, Hm, ordem, TAU_S, alvo, s, F_S, S.OM, dt=DT_S)
                    G = ganhos_S(ts, ns, ordem, TAU_S)
                    venc = [int(np.argmax(G[:, j])) for j in range(len(ordem))]
                    rec['rodadas'].append({'alvo': alvo, 'ordem': on, 'sentido': s, 'norma': nrm, 'G': G.tolist(),
                                           'vencedores': venc, 'acerto': float(np.mean([v == h for v, h in zip(venc, ordem)])),
                                           'dn_final': ns[-int(TAU_S / 2):].mean(0).tolist(), 'curva_n': curva(ts, ns, 2.0)})
                    log('%s N=%d semente=%d %s %s s=%+d: acerto %.2f (%.0f s)' % (rot, N, sd, 'alvo' if alvo else 'generico', on, s,
                                                                             rec['rodadas'][-1]['acerto'], time.time() - t0))
        rec['tempo_s'] = time.time() - t0; rec['mem_gb'] = mem_gb()
        grava(cam, rec)
        log('%s N=%d semente=%d: %.0f s, %.2f GB' % (rot, N, sd, rec['tempo_s'], rec['mem_gb']))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--modo', choices=['fumaca', 'completo'], required=True)
    ap.add_argument('--parte', choices=['L', 'C', 'S20', 'S24', 'todas'], default='todas')
    ap.add_argument('--saida', default=None)
    a = ap.parse_args()
    saida = a.saida or os.path.join(os.path.dirname(AQUI), 'resultados' if a.modo == 'completo' else 'fumaca')
    os.makedirs(saida, exist_ok=True)
    cfg = CONFIG[a.modo]
    logf = open(os.path.join(saida, 'log_%s.txt' % a.parte), 'a')

    def log(msg):
        linha = time.strftime('%Y-%m-%d %H:%M:%S ') + msg
        print(linha, flush=True); logf.write(linha + '\n'); logf.flush()

    cam = os.path.join(saida, 'config_B39.json')
    if not os.path.exists(cam):
        grava(cam, {'modo': a.modo, 'config': cfg, 'python': sys.version, 'numpy': np.__version__, 'plataforma': platform.platform(),
                    'sha256': {f: sha(os.path.join(AQUI, f)) for f in ('b39_linear.py', 'b39_rele.py', 'b39_cidade.py', 'b39_syk.py', 'rodar_B39.py')},
                    'rede': {'Om_r': C.OM_R, 'A': C.A_REDE, 'gamma_b_L': C.GAM_B},
                    'rele': {'T_R': RL.T_R, 'HIST': RL.HIST, 'gamma_lampada': RL.GAM_LAMP, 'amostra': C.AMOSTRA, 'F_rel_T3': F_REL},
                    'L': {'W0': C.W0, 'LAM': C.LAM, 'H': C.H, 'OM': C.OM_L.tolist(), 'g': C.G_L, 'gamma_receptor': C.GAM_R, 'F0': C.F0,
                          'dt': C.DT, 'taus': C.TAUS, 'tau': C.TAU, 'ordens': C.ORDENS, 'casa_removida': C.CASA_REMOVIDA, 'tipos': C.TIPOS},
                    'C': {'Mc': C.MC, 'W0c': C.W0C, 'kappa': C.KAP, 'Om': C.OM_C, 'd': C.D_C, 'x0': C.X0_C, 'abs': C.ABS_C, 'g': C.G_C,
                          'amort': C.AMORT_C, 'vg': C.vg_linha(), 'dur': DUR_C},
                    'S': {'OM': S.OM, 'tau': TAU_S, 'F': F_S, 'dt': DT_S, 'ordens': ORDENS_S}})
    partes = ['L', 'C', 'S20', 'S24'] if a.parte == 'todas' else [a.parte]
    for p in partes:
        log('início %s (%s)' % (p, a.modo))
        if p == 'L':
            rodar_L(cfg['L'], saida, log)
        elif p == 'C':
            rodar_C(cfg['C'], saida, log)
        else:
            rodar_S(p, cfg[p], saida, log)
        log('fim %s' % p)


if __name__ == '__main__':
    main()
