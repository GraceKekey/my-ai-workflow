"""B39 — motor linear (base livre onipresente L e linha com espaço C).

Sistema: ẍ = −K x − D ẋ + F(t), com K simétrica (N×N) e D diagonal (perdas da base, amortecimento dos receptores e
pontas absorventes da linha). Primeira ordem: z = (x, ẋ), ż = A z + (0, F), A = [[0, I], [−K, −D]].
Integração exata por autovalores de A: z = V y, y_j(t + dt) = e^{λ_j dt} y_j + (forçamento integrado).

Duas partes, somadas no fim (o sistema é linear):
- a REDE: forçamento permanente Re[f e^{iΩ_r t}] em todos os sítios da base, ligado desde sempre — estado
  estacionário exato X̂ = (K − Ω_r² + iΩ_r D)⁻¹ f, x_rede(t) = Re[X̂ e^{iΩ_r t}];
- a MENSAGEM: soma de pulsos F(t) = Re[e^{iΩt} env(t) (P1 − i s P2)] (saca-rolha, sentido s = ±1), partindo do
  repouso, com o envelope tomado no ponto médio do passo e a portadora integrada exatamente.
O motor devolve, amostrados, posição e momento dos receptores (só a parte da mensagem)."""
import numpy as np


class SistemaLinear:
    def __init__(self, K, D):
        N = K.shape[0]
        A = np.zeros((2 * N, 2 * N))
        A[:N, N:] = np.eye(N)
        A[N:, :N] = -K
        A[N:, N:] = -np.diag(D)
        lam, V = np.linalg.eig(A)
        self.N, self.lam, self.V = N, lam, V
        self.Vinv = np.linalg.inv(V)
        self.cond = float(np.linalg.cond(V))
        self.K, self.D = K, D

    def proj(self, P):
        """componentes, na base de autovetores, de um forçamento (0, P)."""
        return self.Vinv[:, self.N:] @ P

    def rede(self, f, Om):
        """amplitude complexa estacionária de todos os graus de liberdade sob a rede Re[f e^{iΩt}]."""
        N = self.N
        return np.linalg.solve(self.K - Om ** 2 * np.eye(N) + 1j * Om * np.diag(self.D), f.astype(complex))

    def energia(self, y, nbase):
        """energia da parte da mensagem guardada nos nbase primeiros graus de liberdade (a base)."""
        z = np.real(self.V @ y); x = z[:nbase]; v = z[self.N:self.N + nbase]
        return float(0.5 * v @ v + 0.5 * x @ (self.K[:nbase, :nbase] @ x))

    def rodar(self, pulsos, T, dt, idx, amostra=0.5, nbase=0, passo_energia=50.0):
        """pulsos: lista de dicts {t0, dur, Om, q, qc, F0}; envelope F0 sin² em [t0, t0 + dur].
        Devolve tempos amostrados ts, posições X (nt × len(idx)) e momentos P (nt × len(idx)) da parte da mensagem.
        Se nbase > 0, guarda em self.energia_max a maior energia da mensagem na base (amostrada a cada passo_energia)."""
        lam = self.lam
        nsteps = int(round(T / dt)); pa = max(1, int(round(amostra / dt)))
        pe = max(1, int(round(passo_energia / dt))); self.energia_max = 0.0
        eld = np.exp(lam * dt)
        Vx = self.V[idx, :]; Vp = self.V[[self.N + i for i in idx], :]
        y = np.zeros(2 * self.N, dtype=complex)
        fat = {}
        for P in pulsos:
            Om = P['Om']
            if Om not in fat:
                d1 = 1j * Om - lam; d2 = -1j * Om - lam
                f1 = np.where(np.abs(d1) > 1e-12, (np.exp(1j * Om * dt) - eld) / np.where(np.abs(d1) > 1e-12, d1, 1.0), dt * eld)
                f2 = np.where(np.abs(d2) > 1e-12, (np.exp(-1j * Om * dt) - eld) / np.where(np.abs(d2) > 1e-12, d2, 1.0), dt * eld)
                fat[Om] = (f1, f2)
        ts, X, Pp = [0.0], [np.zeros(len(idx))], [np.zeros(len(idx))]
        for it in range(nsteps):
            t = it * dt; tm = t + 0.5 * dt
            y = eld * y
            for P in pulsos:
                u = (tm - P['t0']) / P['dur']
                if 0.0 < u < 1.0:
                    env = P['F0'] * np.sin(np.pi * u) ** 2
                    f1, f2 = fat[P['Om']]
                    y = y + 0.5 * env * (P['q'] * np.exp(1j * P['Om'] * t) * f1 + P['qc'] * np.exp(-1j * P['Om'] * t) * f2)
            if (it + 1) % pa == 0:
                ts.append(t + dt); X.append(np.real(Vx @ y)); Pp.append(np.real(Vp @ y))
            if nbase and (it + 1) % pe == 0:
                self.energia_max = max(self.energia_max, self.energia(y, nbase))
        return np.array(ts), np.array(X), np.array(Pp)


def energia_rede(sis, Xr, nbase, Om):
    """energia média da rede guardada na base (por unidade de A²) e potência que a fonte repõe (perdas, por A²)."""
    xb = Xr[:nbase]
    E = 0.25 * Om ** 2 * float(np.sum(np.abs(xb) ** 2)) + 0.25 * float(np.real(np.conj(xb) @ (sis.K[:nbase, :nbase] @ xb)))
    Pw = 0.5 * Om ** 2 * float(np.sum(sis.D * np.abs(Xr) ** 2))
    return E, Pw


def pulso(sis, t0, dur, Om, P1, P2, s, F0):
    c = P1 - 1j * s * P2
    return {'t0': t0, 'dur': dur, 'Om': Om, 'q': sis.proj(c), 'qc': sis.proj(np.conj(c)), 'F0': F0}
