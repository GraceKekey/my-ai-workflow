"""B39 — conferência das peças. Uso: python conferir_pecas_B39.py PASTA_FUMACA
1. motor × RK4 (mensagem saindo do repouso, base livre pequena);
2. rede: estado estacionário analítico × RK4 partindo dele (a rede fica igual, sem transiente);
3. superposição: RK4 com rede e mensagem juntas × rede analítica + motor;
4. filtro do relé: valor inicial analítico × aquecimento longo partindo de zero;
5. relé que trava, relé que solta (histerese) e lâmpada, num sinal sintético;
6. margem × acerto no limiar do meio da janela, em todas as rodadas da fumaça (margem > 1 ⇔ onda perfeita);
7. linearidade da leitura sem rede (força 2 → leitura 4 vezes maior)."""
import glob, json, os, sys
import numpy as np
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import b39_cidade as C
import b39_rele as RL
from b39_linear import SistemaLinear, pulso

N_OK = 0


def confere(nome, valor, limite, menor=True):
    global N_OK
    ok = (valor <= limite) if menor else (valor >= limite)
    print('  %s  %-62s %.3e (%s %.1e)' % ('ok ' if ok else 'ERRO', nome, valor, '≤' if menor else '≥', limite))
    if not ok:
        raise AssertionError(nome)
    N_OK += 1


def rk4(K, D, forca, x0, v0, T, dt, idx, amostra):
    x, v = x0.copy(), v0.copy()
    acc = lambda t, x, v: -K @ x - D * v + forca(t)
    pa = int(round(amostra / dt)); X, P = [x[idx].copy()], [v[idx].copy()]
    for it in range(int(round(T / dt))):
        t = it * dt
        k1x = v; k1v = acc(t, x, v)
        k2x = v + 0.5 * dt * k1v; k2v = acc(t + 0.5 * dt, x + 0.5 * dt * k1x, k2x)
        k3x = v + 0.5 * dt * k2v; k3v = acc(t + 0.5 * dt, x + 0.5 * dt * k2x, k3x)
        k4x = v + dt * k3v; k4v = acc(t + dt, x + dt * k3x, k4x)
        x = x + dt / 6 * (k1x + 2 * k2x + 2 * k3x + k4x); v = v + dt / 6 * (k1v + 2 * k2v + 2 * k3v + k4v)
        if (it + 1) % pa == 0:
            X.append(x[idx].copy()); P.append(v[idx].copy())
    return np.array(X), np.array(P)


def pecas_fisicas():
    print('— motor, rede, superposição e filtro (base livre, M = 80)')
    cid = C.CidadeL(80, 7); M = cid.M
    K, D = cid.K(), cid.D(True); sis = SistemaLinear(K, D)
    ordem, tau, T = [0, 3], 150.0, 400.0
    P = cid.perfis('difusao')
    pul = [pulso(sis, j * tau, tau, C.OM_L[k], P[k][0], P[k][1], 1, C.F0) for j, k in enumerate(ordem)]
    ts, Xm, Pm = sis.rodar(pul, T, C.DT, cid.idx, C.AMOSTRA)

    def F_msg(t):
        out = np.zeros(cid.N)
        for j, k in enumerate(ordem):
            u = (t - j * tau) / tau
            if 0 < u < 1:
                c = P[k][0] - 1j * P[k][1]
                out += C.F0 * np.sin(np.pi * u) ** 2 * np.real(c * np.exp(1j * C.OM_L[k] * t))
        return out
    Xr, Pr = rk4(K, D, F_msg, np.zeros(cid.N), np.zeros(cid.N), T, 0.01, cid.idx, C.AMOSTRA)
    confere('motor × RK4 (posição dos receptores, erro relativo)', np.abs(Xm - Xr).max() / np.abs(Xr).max(), 1e-3)
    confere('motor × RK4 (momento dos receptores, erro relativo)', np.abs(Pm - Pr).max() / np.abs(Pr).max(), 1e-3)
    f = cid.f_rede(); Xg = sis.rede(f, C.OM_R); A = C.A_REDE
    F_rede = lambda t: A * np.real(f * np.exp(1j * C.OM_R * t))
    x0 = A * np.real(Xg); v0 = A * np.real(1j * C.OM_R * Xg)
    Xa, Pa = rk4(K, D, F_rede, x0, v0, 200.0, 0.01, cid.idx, C.AMOSTRA)
    tt = np.arange(len(Xa)) * C.AMOSTRA
    xa = A * np.real(Xg[cid.idx][None, :] * np.exp(1j * C.OM_R * tt[:, None]))
    confere('rede estacionária × RK4 (erro relativo nos receptores)', np.abs(Xa - xa).max() / np.abs(xa).max(), 1e-6)
    Xt, Pt = rk4(K, D, lambda t: F_rede(t) + F_msg(t), x0, v0, T, 0.01, cid.idx, C.AMOSTRA)
    xg = A * np.real(Xg[cid.idx][None, :] * np.exp(1j * C.OM_R * ts[:, None]))
    confere('superposição: rede + mensagem × RK4 (erro relativo)', np.abs(xg + Xm - Xt).max() / np.abs(Xt).max(), 1e-3)
    R = RL.leitura(ts, Xm, Pm, C.OM_L, Xg[M:], A, C.OM_R)
    tw = np.arange(-400 * RL.T_R, 0.0 + 1e-9, C.AMOSTRA)
    zero = np.zeros((len(tw), C.H))
    Rw = RL.leitura(tw, zero, zero, C.OM_L, None, 0.0)
    xw = A * np.real(Xg[M:][None, :] * np.exp(1j * C.OM_R * tw[:, None])); pw = A * np.real(1j * C.OM_R * Xg[M:][None, :] * np.exp(1j * C.OM_R * tw[:, None]))
    z = np.sqrt(C.OM_L / 2) * xw + 1j * pw / np.sqrt(2 * C.OM_L); w = z * np.exp(1j * C.OM_L[None, :] * tw[:, None])
    a = np.exp(-C.AMOSTRA / RL.T_R); wb = np.zeros(C.H, complex)
    for i in range(1, len(tw)):
        wb = a * wb + (1 - a) * w[i]
    confere('filtro: valor inicial analítico × aquecimento de 400 T_R', np.abs(np.abs(wb) ** 2 - R[0]).max() / np.abs(wb).max() ** 2, 1e-6)
    R1 = RL.leitura(ts, Xm, Pm, C.OM_L); R2 = RL.leitura(ts, Xm, Pm, C.OM_L, F_rel=2.0)
    confere('linearidade sem rede (força 2 → leitura × 4)', np.abs(R2 - 4 * R1).max() / R2.max(), 1e-12)


def pecas_rele():
    print('— relé e lâmpada (sinal sintético)')
    ts = np.arange(0.0, 400.0, 0.5)
    R = np.zeros((len(ts), 1)); R[:, 0] = np.where((ts > 100) & (ts < 200), 1.0, 0.0) * np.sin(np.pi * (ts - 100) / 100) ** 2
    rt = RL.rele(ts, R, 0.5, 'trava'); rs = RL.rele(ts, R, 0.5, 'solta')
    tf = ts[np.argmax(rt[:, 0] > 0)]
    confere('trava fecha quando R cruza θ = 0,5 (erro do instante; amostra 0,5)', abs(tf - 125.0), 0.75)
    confere('trava não abre depois', 1.0 - rt[ts > tf, 0].min(), 0.0)
    iv = RL.disparos(ts, rs)[0]
    confere('solta: um só trecho ligado', abs(len(iv) - 1), 0)
    confere('solta abre em HIST·θ = 0,25 (erro do instante; amostra 0,5)', abs(iv[0][1] - (100 + 100 * (1 - np.arcsin(np.sqrt(0.25)) / np.pi))), 0.75)
    b = RL.lampada(ts, rt)
    confere('lâmpada ligada há muito tempo: brilho pleno', 1.0 - b[-1, 0], 1e-6)
    confere('lâmpada antes do relé: apagada', b[ts < tf, 0].max(), 0.0)


def pecas_fumaca(pasta):
    print('— margem × acerto no limiar do meio, nas rodadas da fumaça')
    n = 0
    for f in sorted(glob.glob(os.path.join(pasta, '*.json'))):
        r = json.load(open(f))
        if r.get('parte') not in ('L', 'C'):
            continue
        for q in r['rodadas']:
            for modo in ('trava', 'solta'):
                m, a = q['margem_' + modo], q['acerto_' + modo]
                if abs(m - 1) < 1e-9:
                    continue
                if (m > 1) != (a == 1.0):
                    raise AssertionError('%s %s %s: margem %.4g, acerto %.2f' % (os.path.basename(f), q['teste'], modo, m, a))
                n += 1
    confere('rodadas em que margem > 1 ⇔ acerto = 1 (faltam)', 0, 0)
    confere('número de comparações feitas', n, 50, menor=False)


if __name__ == '__main__':
    pecas_fisicas()
    pecas_rele()
    pecas_fumaca(sys.argv[1])
    print('\nTODAS AS %d PEÇAS CONFEREM' % N_OK)
