"""B39 — modelo S: onda programada numa base SYK (Majoranas, q = 4, todos com todos), lâmpadas reversíveis.

N Majoranas, representação de Jordan–Wigner em N/2 qubits. Casa i (i = 0..3, de leste a oeste) = par (χ_2i, χ_2i+1) =
férmion k = i, com energia Ω_i (n_i − ½); a base são os demais N − 8 Majoranas.
H = Σ_{a<b<c<d} J_abcd χ_aχ_bχ_cχ_d + Σ_i Ω_i (n_i − ½), J_abcd gaussianos de variância 3! J²/N³.
Mensagem: H(t) = H + F Σ_slots env(t) [cos(Ω_h t) O1_h + s sin(Ω_h t) O2_h], só sobre a base.
- genérica: O1, O2 = bilineares aleatórios da base (iguais para todas as casas, como na B37);
- endereço completo ("forma da fiação"): O1_h = i Σ_{a<b ∈ base} J_{2h,2h+1,a,b} χ_aχ_b, o bilinear da base que multiplica
  o bilinear da própria casa em H; O2_h = parte de i[H_base, O1_h] ortogonal a O1_h. Normalização Tr O²/dim = 1.
Lâmpadas reversíveis: mede-se a ocupação n_i(t)."""
import itertools
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as sla

J0 = 1.0
NG = 4
OM = [0.3, 0.5, 0.7, 0.9]           # leste → oeste; o custo cresce de leste para oeste
_PC = np.array([bin(i).count('1') & 1 for i in range(1 << 16)], dtype=np.int8)


def paridade(x):
    x = np.asarray(x, dtype=np.int64)
    return _PC[x & 0xFFFF] ^ _PC[(x >> 16) & 0xFFFF]


def majorana(k_maj):
    k = k_maj // 2; low = (1 << k) - 1
    if k_maj % 2 == 0:
        return (1 << k, low, 1 / np.sqrt(2))
    return (1 << k, low | (1 << k), 1j / np.sqrt(2))


def produto(a, b):
    f1, z1, c1 = a; f2, z2, c2 = b
    return (f1 ^ f2, z1 ^ z2, c1 * c2 * (-1) ** (bin(f2 & z1).count('1') & 1))


def operador(termos, dim):
    b = np.arange(dim, dtype=np.int64)
    acc = {}
    for f, z, c in termos:
        s = (1 - 2 * paridade(b & z)).astype(float)
        acc[f] = acc.get(f, 0) + c * s
    rows, cols, vals = [], [], []
    for f, v in acc.items():
        rows.append(b ^ f); cols.append(b); vals.append(v)
    return sp.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(dim, dim))


def normaliza(Op, dim):
    Op = 0.5 * (Op + Op.getH())
    nrm = np.sqrt(abs((Op.multiply(Op.conj())).sum()) / dim)
    return (Op / nrm).tocsr()


def hs(A, B, dim):
    """produto de Hilbert–Schmidt Re Tr(A† B)/dim."""
    return float(np.real(A.conj().multiply(B).sum()) / dim)


class SYK:
    def __init__(self, N, seed):
        self.N = N; self.n = N // 2; self.dim = 1 << self.n
        rng = np.random.default_rng(seed)
        sig = np.sqrt(6.0) * J0 / N ** 1.5
        Mj = [majorana(a) for a in range(N)]
        termos_base, termos_casa = [], []
        self.Jpar = {}                      # J_{2h,2h+1,a,b} para a, b na base
        for q in itertools.combinations(range(N), 4):
            Jq = rng.standard_normal() * sig
            t = produto(produto(produto(Mj[q[0]], Mj[q[1]]), Mj[q[2]]), Mj[q[3]])
            if q[0] >= 2 * NG:
                termos_base.append((t[0], t[1], Jq * t[2]))
            else:
                termos_casa.append((t[0], t[1], Jq * t[2]))
                if q[1] == q[0] + 1 and q[0] % 2 == 0 and q[2] >= 2 * NG:
                    self.Jpar[(q[0] // 2, q[2], q[3])] = Jq
        self.Hb = operador(termos_base, self.dim)
        self.Hc = operador(termos_casa, self.dim)
        self.b = np.arange(self.dim, dtype=np.int64)
        self.par = paridade(self.b)
        self.nbits = [((self.b >> i) & 1).astype(float) for i in range(NG)]
        base = list(range(2 * NG, N))
        self.gen = []
        for _ in range(2):
            termos = []
            for (a, c) in itertools.combinations(base, 2):
                f, z, cc = produto(Mj[a], Mj[c])
                termos.append((f, z, 1j * rng.standard_normal() * cc))
            self.gen.append(normaliza(operador(termos, self.dim), self.dim))
        self.alvo = []
        for h in range(NG):
            termos = []
            for (a, c) in itertools.combinations(base, 2):
                f, z, cc = produto(Mj[a], Mj[c])
                termos.append((f, z, 1j * self.Jpar[(h, a, c)] * cc))
            O1 = normaliza(operador(termos, self.dim), self.dim)
            C = (1j * (self.Hb @ O1 - O1 @ self.Hb)).tocsr()
            C = 0.5 * (C + C.getH())
            C = (C - hs(C, O1, self.dim) * O1).tocsr()
            self.alvo.append((O1, normaliza(C, self.dim)))
        self.idx = {p: np.nonzero(self.par == p)[0] for p in (0, 1)}

    def H(self, Om):
        diag = sum(Om[i] * (self.nbits[i] - 0.5) for i in range(NG))
        return (self.Hb + self.Hc + sp.diags(diag)).tocsr()

    def setor(self, A, p):
        ix = self.idx[p]
        return A[ix][:, ix].tocsr()

    def nb(self, p):
        ix = self.idx[p]
        return [v[ix] for v in self.nbits]


def fundamental(model, H):
    res = {}
    for p in (0, 1):
        w, V = sla.eigsh(model.setor(H, p), k=2, which='SA', tol=1e-12)
        o = np.argsort(w); res[p] = (w[o], V[:, o])
    p0 = 0 if res[0][0][0] <= res[1][0][0] else 1
    todos = np.sort(np.concatenate([res[0][0], res[1][0]]))
    return {'p': p0, 'E0': float(res[p0][0][0]), 'psi': res[p0][1][:, 0].astype(complex), 'gap': float(todos[1] - todos[0])}


def ocup(nb, psi):
    p = np.abs(psi) ** 2
    return np.array([p @ v for v in nb])


def onda(model, gs, Hfull, ordem, tau, alvo, s, F, Om, dt=0.1, amostra=1.0):
    """mensagem programada: no slot j (de duração tau) chama a casa ordem[j], com envelope sin² e portadora Ω da casa."""
    p = gs['p']; Hs = model.setor(Hfull, p); nb = model.nb(p)
    ops = []
    for h in ordem:
        O1, O2 = model.alvo[h] if alvo else model.gen
        ops.append((model.setor(O1, p), model.setor(O2, p), Om[h]))
    T = (len(ordem) + 1) * tau
    n0 = ocup(nb, gs['psi']); psi = gs['psi'].copy()
    ts, ns = [0.0], [np.zeros(len(nb))]
    nsteps = int(round(T / dt)); passo = max(1, int(round(amostra / dt)))
    for it in range(nsteps):
        tm = (it + 0.5) * dt
        j = int(tm // tau)
        Ht = Hs
        if j < len(ordem):
            u = tm / tau - j
            env = F * np.sin(np.pi * u) ** 2
            O1, O2, W = ops[j]
            Ht = Hs + env * (np.cos(W * tm) * O1 + s * np.sin(W * tm) * O2)
        psi = sla.expm_multiply(-1j * dt * Ht, psi)
        if (it + 1) % passo == 0:
            ts.append((it + 1) * dt); ns.append(ocup(nb, psi) - n0)
    return np.array(ts), np.array(ns), float(np.linalg.norm(psi))
