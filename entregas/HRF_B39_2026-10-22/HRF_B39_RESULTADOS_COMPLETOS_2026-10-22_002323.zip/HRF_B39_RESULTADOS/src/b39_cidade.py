"""B39 — a cidade com a rede sempre ligada: base livre onipresente (L) e linha com espaço (C).

L: K_base = W0² I + (2 W0 λ/√M) W (GOE); 10 casas de leste (0) a oeste (9). Cada casa tem um RECEPTOR sintonizado
em Ω_k = 1,62 + 0,08 k, ligado a TODOS os sítios da base com K_ik = 2 W0 g c_ik/√M (c_ik = ±1: a "fiação" da casa).
A REDE: forçamento permanente de amplitude A na frequência Ω_r = 1,0 (abaixo da banda da base e das casas), igual em
todos os sítios da base; a base tem perdas γ_b em todo sítio, repostas pela fonte (estado estacionário desde sempre).
Mensagens (fracas, F0, na frequência da casa chamada, saca-rolha de sentido s):
  difusao  — telecomando: o mesmo sinal pela fiação de TODAS as casas (perfil Σ_k c_k), endereço só pela frequência;
  alvo     — endereçada: pela fiação da casa chamada (perfil c_k);
  generica — por um caminho aleatório da base, fora da fiação.
C: linha de Mc sítios com molas entre vizinhos, K = (W0c² + 2κ) I − κ (T + Tᵀ), pontas absorventes, interior sem
perdas; rede igual em todos os sítios; 10 receptores iguais (Ω_c) pendurados cada um num sítio, espaçados de d sítios;
a mensagem entra por uma ponta e caminha."""
import numpy as np
from b39_linear import SistemaLinear, pulso

# ---------------------------------------------------------------- parâmetros congelados
W0, LAM = 2.0, 0.25
H = 10
OM_L = 1.62 + 0.08 * np.arange(H)
G_L = 0.05
GAM_R = 0.02           # amortecimento do receptor (bobina do relé)
F0 = 0.02              # força da mensagem
DT = 0.1
AMOSTRA = 0.5
TAUS = [75.0, 150.0, 300.0, 600.0]
TAU = 300.0
ORDENS = {'leste_oeste': list(range(H)), 'oeste_leste': list(range(H))[::-1], 'salteada': [0, 5, 2, 7, 4, 9, 1, 6, 3, 8]}
CASA_REMOVIDA = 4
TIPOS = ('difusao', 'alvo', 'generica')

OM_R = 1.0             # frequência da rede
A_REDE = 10.0          # amplitude da rede (por sítio: A/√M)
GAM_B = 0.01           # perdas da base L (repostas pela fonte)

MC, W0C, KAP, OM_C, D_C, X0_C, ABS_C, G_C, AMORT_C = 800, 1.6, 0.4, 1.85, 65, 90, 60, 0.05, 0.15


def vg_linha():
    k = np.arccos(1 - (OM_C ** 2 - W0C ** 2) / (2 * KAP))
    return float(KAP * np.sin(k) / OM_C)


def janelas_L(ordem, tau):
    ini, fim, pos = {}, {}, {}
    for j, h in enumerate(ordem):
        ini[h] = j * tau; fim[h] = (j + 1) * tau + tau / 4; pos[h] = (j + 1) * tau + tau / 2
    return ini, fim, pos


# ---------------------------------------------------------------- base livre L
class CidadeL:
    def __init__(self, M, seed):
        rng = np.random.default_rng(seed)
        Wm = rng.standard_normal((M, M)); self.W = (Wm + Wm.T) / np.sqrt(2.0)
        self.M = M; self.N = M + H
        self.c = rng.choice([-1.0, 1.0], (H, M))
        self.u1 = rng.standard_normal(M); self.u2 = rng.standard_normal(M)
        self.idx = list(range(M, M + H))

    def K(self, sem=None, corte=False):
        M, N = self.M, self.N
        Wb = self.W.copy()
        if corte:                                   # corta a base em duas metades; cada metade mantém a largura da banda
            h = M // 2
            Wb[:h, h:] = 0.0; Wb[h:, :h] = 0.0; Wb *= np.sqrt(2.0)
        K = np.zeros((N, N)); K[:M, :M] = W0 ** 2 * np.eye(M) + (2 * W0 * LAM / np.sqrt(M)) * Wb
        for k in range(H):
            K[M + k, M + k] = OM_L[k] ** 2
            if sem is not None and k == sem:
                continue
            K[:M, M + k] = 2 * W0 * G_L * self.c[k] / np.sqrt(M); K[M + k, :M] = K[:M, M + k]
        return K

    def D(self, perdas=True):
        D = np.zeros(self.N); D[:self.M] = GAM_B if perdas else 0.0; D[self.M:] = GAM_R
        return D

    def f_rede(self):
        f = np.zeros(self.N); f[:self.M] = 1.0 / np.sqrt(self.M)
        return f

    def perfis(self, tipo):
        """(P1, P2) por casa. P1 = caminho da mensagem; P2 = resposta da base a esse caminho, ortogonalizada
        (genérica: um segundo caminho aleatório)."""
        M, N = self.M, self.N
        out = []
        for k in range(H):
            if tipo == 'alvo':
                a = self.c[k].copy()
            elif tipo == 'difusao':
                a = self.c.sum(0)
            elif tipo == 'generica':
                a = self.u1.copy()
            else:
                raise ValueError(tipo)
            a = a / np.linalg.norm(a)
            b = self.W @ a if tipo != 'generica' else self.u2.copy()
            b = b - a * (a @ b); b /= np.linalg.norm(b)
            A = np.zeros(N); B = np.zeros(N); A[:M] = a; B[:M] = b
            out.append((A, B))
        return out

    def rodar(self, sis, ordem, tau, tipo, s):
        P = self.perfis(tipo)
        pul = [pulso(sis, j * tau, tau, OM_L[k], P[k][0], P[k][1], s, F0) for j, k in enumerate(ordem)]
        return sis.rodar(pul, (len(ordem) + 2) * tau, DT, self.idx, AMOSTRA, nbase=self.M)


# ---------------------------------------------------------------- linha C
class CidadeC:
    def __init__(self, Hc=H, Mc=MC):
        self.H = Hc; self.Mc = Mc; self.N = Mc + Hc
        self.pos = X0_C + D_C * np.arange(Hc)
        self.idx = list(range(Mc, Mc + Hc))
        self.fonte = {'leste': ABS_C + 5, 'oeste': Mc - ABS_C - 6}

    def K(self, sem=None, corte=False):
        Mc, N = self.Mc, self.N
        K = np.zeros((N, N)); K[:Mc, :Mc] = (W0C ** 2 + 2 * KAP) * np.eye(Mc)
        icorte = int(self.pos[CASA_REMOVIDA] + D_C // 2) if corte else None
        for i in range(Mc - 1):
            if i == icorte:
                continue
            K[i, i + 1] = K[i + 1, i] = -KAP
        for k in range(self.H):
            K[Mc + k, Mc + k] = OM_C ** 2
            if sem is not None and k == sem:
                continue
            K[self.pos[k], Mc + k] = K[Mc + k, self.pos[k]] = G_C
        return K

    def D(self):
        D = np.zeros(self.N); r = np.arange(ABS_C)
        D[:ABS_C] = AMORT_C * ((ABS_C - r) / ABS_C) ** 2
        D[self.Mc - ABS_C:self.Mc] = AMORT_C * ((r + 1) / ABS_C) ** 2
        D[self.Mc:] = GAM_R
        return D

    def f_rede(self):
        f = np.zeros(self.N); f[:self.Mc] = 1.0 / np.sqrt(self.Mc)
        return f

    def ordem(self, lado):
        return list(range(self.H)) if lado == 'leste' else list(range(self.H))[::-1]

    def janelas(self, lado, dur):
        """chegada prevista t*_k = dur/2 + |pos_k − fonte|/v_g; janela t* ± Δ/2 (Δ = d/v_g); soltura até t* + Δ."""
        vg = vg_linha(); Dl = D_C / vg
        ini, fim, pos = {}, {}, {}
        for k in range(self.H):
            t = dur / 2 + abs(self.pos[k] - self.fonte[lado]) / vg
            ini[k] = t - Dl / 2; fim[k] = t + Dl / 2; pos[k] = t + Dl
        return ini, fim, pos

    def rodar(self, sis, lado, dur, s):
        a = np.zeros(self.N); b = np.zeros(self.N)
        if lado == 'leste':
            a[ABS_C + 5] = 1.0; b[ABS_C + 6] = 1.0
        else:
            a[self.Mc - ABS_C - 6] = 1.0; b[self.Mc - ABS_C - 7] = 1.0
        pul = [pulso(sis, 0.0, dur, OM_C, a, b, s, F0)]
        T = (self.H + 3) * D_C / vg_linha() + dur
        return sis.rodar(pul, T, DT, self.idx, AMOSTRA, nbase=self.Mc)


def spearman(x, y):
    from scipy.stats import rankdata
    rx, ry = rankdata(x), rankdata(y)
    if np.std(rx) == 0 or np.std(ry) == 0:
        return 0.0
    return float(np.corrcoef(rx, ry)[0, 1])
