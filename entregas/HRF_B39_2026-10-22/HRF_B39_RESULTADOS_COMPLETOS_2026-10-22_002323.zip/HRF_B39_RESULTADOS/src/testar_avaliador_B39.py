"""B39 — teste do avaliador: todos os ramos de todas as classes e testes de ponta a ponta sobre a fumaça, com
perturbações que forçam INSUFICIENTE e mudanças de classe. Uso: python testar_avaliador_B39.py PASTA_FUMACA"""
import copy, os, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import avaliar_B39 as A

N_OK = 0


def confere(nome, obtido, esperado):
    global N_OK
    ob = obtido[0] if isinstance(obtido, (tuple, list)) else obtido
    if ob != esperado:
        raise AssertionError('%s: obtido %r, esperado %r' % (nome, obtido, esperado))
    N_OK += 1
    print('  ok  %-60s %s' % (nome, esperado))


def com(d, k, v):
    e = dict(d); e[k] = v
    return e


def t3(disp, brilho, F=(0.25, 0.5, 1.0, 2.0)):
    return {'F_rel': list(F), 'disparadas': disp, 'brilho_max': brilho}


def ramos():
    print('— classes da base livre')
    confere('onda (folga alta)', A.classe_onda([20.0] * 6, 6), 'ONDA')
    confere('frágil (todas > 1, folga baixa)', A.classe_onda([2.0] * 6, 6), 'ONDA_FRAGIL')
    confere('frágil (fração 4/6, folga alta)', A.classe_onda([20.0] * 4 + [0.5] * 2, 6), 'ONDA_FRAGIL')
    confere('sem onda (fração 2/6)', A.classe_onda([20.0] * 2 + [0.5] * 4, 6), 'SEM_ONDA')
    confere('margem exatamente 1 não conta', A.classe_onda([1.0] * 6, 6), 'SEM_ONDA')
    confere('onda: poucas rodadas', A.classe_onda([20.0, None, float('nan')], 6), 'INSUFICIENTE')
    confere('onda: nenhuma rodada esperada', A.classe_onda([], 0), 'INSUFICIENTE')
    confere('quiral (onda × sem onda)', A.classe_quiral('ONDA', 'SEM_ONDA'), 'QUIRAL')
    confere('quiral (frágil × sem onda)', A.classe_quiral('ONDA_FRAGIL', 'SEM_ONDA'), 'QUIRAL')
    confere('aquiral (iguais)', A.classe_quiral('ONDA', 'ONDA'), 'AQUIRAL')
    confere('aquiral (os dois sem onda)', A.classe_quiral('SEM_ONDA', 'SEM_ONDA'), 'AQUIRAL')
    confere('quiralidade parcial', A.classe_quiral('ONDA', 'ONDA_FRAGIL'), 'PARCIAL')
    confere('quiralidade parcial (invertida)', A.classe_quiral('SEM_ONDA', 'ONDA'), 'PARCIAL')
    confere('quiralidade insuficiente', A.classe_quiral('ONDA', 'INSUFICIENTE'), 'INSUFICIENTE')
    confere('códigos em hierarquia', A.classe_codigos(60.0, 2.5, 0.15), 'HIERARQUIA_FORMA_FREQUENCIA_FORA')
    confere('códigos: alvo ≈ difusão', A.classe_codigos(5.0, 2.5, 0.15), 'OUTRA_ORDEM')
    confere('códigos: difusão ≈ genérica', A.classe_codigos(60.0, 0.3, 0.15), 'OUTRA_ORDEM')
    confere('códigos insuficiente', A.classe_codigos(None, 2.5, 0.15), 'INSUFICIENTE')
    confere('códigos insuficiente (genérica zero)', A.classe_codigos(60.0, 2.5, 0.0), 'INSUFICIENTE')
    um, zero = [1] * 3, [0] * 3
    bom = t3([[0, 0, 0], [0, 1, 1], um, um], [[0.0] * 3, [0.0, 1.0, 1.0], [1.0] * 3, [1.0] * 3])
    confere('tudo ou nada', A.classe_tudo_ou_nada([bom] * 4), 'TUDO_OU_NADA')
    conf = t3([[0, 0, 0], [0, 1, 1], um, um], [[0.0] * 3, [0.0, 0.5, 1.0], [1.0] * 3, [1.0] * 3])
    confere('gradual (lâmpada a meia luz)', A.classe_tudo_ou_nada([conf] * 4), 'GRADUAL')
    fraco = t3([um, um, um, um], [[1.0] * 3] * 4)
    confere('gradual (a mensagem fraca acende tudo)', A.classe_tudo_ou_nada([fraco] * 4), 'GRADUAL')
    forte = t3([zero, [0, 1, 1], um, [1, 1, 0]], [[0.0] * 3, [0.0, 1.0, 1.0], [1.0] * 3, [1.0, 1.0, 0.0]])
    confere('gradual (a forte não acende tudo)', A.classe_tudo_ou_nada([forte] * 4), 'GRADUAL')
    nmon = t3([[0, 1, 0], [0, 0, 0], um, um], [[0.0, 1.0, 0.0], [0.0] * 3, [1.0] * 3, [1.0] * 3])
    confere('gradual (contagem não monótona)', A.classe_tudo_ou_nada([nmon] * 4), 'GRADUAL')
    confere('tudo ou nada com uma rodada ruim em dez', A.classe_tudo_ou_nada([bom] * 9 + [conf]), 'TUDO_OU_NADA')
    confere('tudo ou nada insuficiente (vazio)', A.classe_tudo_ou_nada([]), 'INSUFICIENTE')
    confere('tudo ou nada insuficiente (sem F = 2)', A.classe_tudo_ou_nada([t3([zero, um], [[0.0] * 3, [1.0] * 3], F=(0.25, 1.0))]), 'INSUFICIENTE')
    fr = {75.0: 0.0, 150.0: 1.0, 300.0: 1.0, 600.0: 1.0}; it = {75.0: None, 150.0: 1.0, 300.0: 1.0, 600.0: 1.0}
    confere('velocidade livre com limite', A.classe_velocidade(fr, it, 0.8, 10.0), 'VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA')
    confere('velocidade livre sem limite', A.classe_velocidade(fr, it, 8.0, 10.0), 'VELOCIDADE_LIVRE_SEM_LIMITE')
    confere('velocidade presa (margem em τ = 150)', A.classe_velocidade(com(fr, 150.0, 0.5), it, 0.8, 10.0), 'VELOCIDADE_PRESA')
    confere('velocidade presa (intervalo)', A.classe_velocidade(fr, com(it, 600.0, 1.5), 0.8, 10.0), 'VELOCIDADE_PRESA')
    confere('velocidade presa (intervalo ausente)', A.classe_velocidade(fr, com(it, 150.0, None), 0.8, 10.0), 'VELOCIDADE_PRESA')
    confere('velocidade insuficiente (fração ausente)', A.classe_velocidade(com(fr, 300.0, None), it, 0.8, 10.0), 'INSUFICIENTE')
    confere('velocidade insuficiente (margem 75 ausente)', A.classe_velocidade(fr, it, None, 10.0), 'INSUFICIENTE')
    confere('velocidade insuficiente (sem τ ≥ 150)', A.classe_velocidade({75.0: 1.0}, {75.0: 1.0}, 0.8, 10.0), 'INSUFICIENTE')
    confere('sem dependência', A.classe_dependencia([1.02, 0.99], [0.0, 0.01]), 'SEM_DEPENDENCIA')
    confere('dependente (apaga)', A.classe_dependencia([0.2, 0.3], [0.0, 0.0]), 'DEPENDENTE')
    confere('dependente (dispara)', A.classe_dependencia([3.0, 2.5], [0.0, 0.0]), 'DEPENDENTE')
    confere('dependência parcial', A.classe_dependencia([1.3, 1.3], [0.0, 0.0]), 'PARCIAL')
    confere('dependência parcial (atraso)', A.classe_dependencia([1.0, 1.0], [0.2, 0.2]), 'PARCIAL')
    confere('dependência insuficiente', A.classe_dependencia([], []), 'INSUFICIENTE')
    confere('corte bloqueia', A.classe_corte([0.0, 0.01], [0.0]), 'BLOQUEADA')
    confere('corte bloqueia (sem disparos)', A.classe_corte([0.0, 0.01], []), 'BLOQUEADA')
    confere('corte atravessa', A.classe_corte([0.8, 1.1], [0.02, 0.0]), 'ATRAVESSA')
    confere('corte parcial (pico)', A.classe_corte([0.3, 0.3], [0.0]), 'PARCIAL')
    confere('corte parcial (atraso)', A.classe_corte([0.9, 0.9], [0.5]), 'PARCIAL')
    confere('corte insuficiente', A.classe_corte([], []), 'INSUFICIENTE')
    confere('eco apagado pelas perdas', A.classe_eco({'difusao': [8.0, 7.0], 'alvo': [10.0, 12.0]}), 'PERDAS_APAGAM_O_ECO')
    confere('eco sem efeito', A.classe_eco({'difusao': [1.1, 0.9], 'alvo': [1.2, 1.0]}), 'SEM_EFEITO')
    confere('eco parcial', A.classe_eco({'difusao': [8.0, 7.0], 'alvo': [1.2, 1.0]}), 'PARCIAL')
    confere('eco insuficiente', A.classe_eco({'difusao': [], 'alvo': [10.0]}), 'INSUFICIENTE')
    confere('eco insuficiente (vazio)', A.classe_eco({}), 'INSUFICIENTE')
    confere('rede não dispara', A.classe_rede_dispara([0.01, 0.05]), 'REDE_NAO_DISPARA')
    confere('rede dispara', A.classe_rede_dispara([0.01, 0.2]), 'REDE_DISPARA')
    confere('rede dispara: insuficiente', A.classe_rede_dispara([]), 'INSUFICIENTE')
    confere('rede não interfere', A.classe_rede_interfere([0.0, 0.01], [1.0, 1.0]), 'REDE_NAO_INTERFERE')
    confere('rede interfere (atraso)', A.classe_rede_interfere([0.0, 0.05], [1.0, 1.0]), 'REDE_INTERFERE')
    confere('rede interfere (disparo diferente)', A.classe_rede_interfere([0.0, 0.0], [1.0, 0.9]), 'REDE_INTERFERE')
    confere('rede interfere: insuficiente', A.classe_rede_interfere([], []), 'INSUFICIENTE')
    v = 'VELOCIDADE_LIVRE_COM_LIMITE_DE_INCERTEZA'
    confere('global L programada', A.classe_global_L('ONDA', 'ONDA', v, 'SEM_DEPENDENCIA', 'ATRAVESSA'), 'ONDA_PROGRAMADA')
    confere('global L parcial (difusão frágil)', A.classe_global_L('ONDA_FRAGIL', 'ONDA', v, 'SEM_DEPENDENCIA', 'ATRAVESSA'), 'PARCIAL')
    confere('global L parcial (velocidade presa)', A.classe_global_L('ONDA', 'ONDA', 'VELOCIDADE_PRESA', 'SEM_DEPENDENCIA', 'ATRAVESSA'), 'PARCIAL')
    confere('global L parcial (corte bloqueia)', A.classe_global_L('ONDA', 'ONDA', v, 'SEM_DEPENDENCIA', 'BLOQUEADA'), 'PARCIAL')
    confere('global L não programada', A.classe_global_L('SEM_ONDA', 'SEM_ONDA', v, 'SEM_DEPENDENCIA', 'ATRAVESSA'), 'NAO_PROGRAMADA')
    confere('global L insuficiente', A.classe_global_L('ONDA', 'ONDA', v, 'INSUFICIENTE', 'ATRAVESSA'), 'INSUFICIENTE')
    print('— classes da linha, L×C, SYK, controles, OLA')
    confere('C-T1 propagada', A.classe_C_T1([1.0, 1.0], [1, 1], [1.0, 0.99], [700.0, 20.0]), 'ONDA_PROPAGADA')
    confere('C-T1 ordem errada', A.classe_C_T1([1.0, -1.0], [1, 1], [1.0, 1.0], [700.0, 20.0]), 'SEM_PROPAGACAO')
    confere('C-T1 intervalo errado', A.classe_C_T1([1.0, 1.0], [1, 1], [1.0, 1.3], [700.0, 20.0]), 'SEM_PROPAGACAO')
    confere('C-T1 margem ≤ 1', A.classe_C_T1([1.0, 1.0], [1, 1], [1.0, 1.0], [700.0, 0.8]), 'SEM_PROPAGACAO')
    confere('C-T1 insuficiente', A.classe_C_T1([1.0, None], [1, 1], [1.0, 1.0], [700.0, 20.0]), 'INSUFICIENTE')
    confere('C-T1 insuficiente (vazio)', A.classe_C_T1([], [], [], []), 'INSUFICIENTE')
    confere('C soltura propagada', A.classe_C_solta([10.0, 4.0]), 'ONDA_PROPAGADA')
    confere('C sem soltura', A.classe_C_solta([10.0, 0.5]), 'SEM_SOLTURA')
    confere('C soltura insuficiente', A.classe_C_solta([10.0, None]), 'INSUFICIENTE')
    confere('C-T4 velocidade fixa', A.classe_C_T4({150.0: 1.0, 300.0: 1.0, 600.0: 0.98}), 'VELOCIDADE_FIXA')
    confere('C-T4 segue a mensagem', A.classe_C_T4({150.0: 0.5, 300.0: 1.0, 600.0: 2.0}), 'VELOCIDADE_SEGUE_A_MENSAGEM')
    confere('C-T4 indefinida', A.classe_C_T4({150.0: 1.0, 300.0: 1.0, 600.0: 1.4}), 'INDEFINIDA')
    confere('C-T4 insuficiente', A.classe_C_T4({150.0: None, 300.0: 1.0}), 'INSUFICIENTE')
    confere('C-T5 sem bloqueio', A.classe_C_T5([1.1, 1.12]), 'SEM_BLOQUEIO')
    confere('C-T5 bloqueio parcial', A.classe_C_T5([0.5, 0.6]), 'BLOQUEIO_PARCIAL')
    confere('C-T5 insuficiente', A.classe_C_T5([]), 'INSUFICIENTE')
    confere('global C com caminho', A.classe_global_C('ONDA_PROPAGADA', 'VELOCIDADE_FIXA', 'BLOQUEADA'), 'ONDA_COM_CAMINHO')
    confere('global C parcial', A.classe_global_C('ONDA_PROPAGADA', 'VELOCIDADE_FIXA', 'ATRAVESSA'), 'PARCIAL')
    confere('global C insuficiente', A.classe_global_C('INSUFICIENTE', 'VELOCIDADE_FIXA', 'BLOQUEADA'), 'INSUFICIENTE')
    confere('L×C separação', A.classe_LxC('ONDA_PROGRAMADA', 'ONDA_COM_CAMINHO', v), 'SEPARACAO')
    confere('L×C iguais', A.classe_LxC('PARCIAL', 'ONDA_COM_CAMINHO', 'VELOCIDADE_PRESA'), 'IGUAIS')
    confere('L×C mista', A.classe_LxC('ONDA_PROGRAMADA', 'PARCIAL', 'VELOCIDADE_LIVRE_SEM_LIMITE'), 'MISTA')
    confere('L×C mista (velocidade presa)', A.classe_LxC('ONDA_PROGRAMADA', 'ONDA_COM_CAMINHO', 'VELOCIDADE_PRESA'), 'MISTA')
    confere('L×C insuficiente', A.classe_LxC('INSUFICIENTE', 'ONDA_COM_CAMINHO', 'VELOCIDADE_PRESA'), 'INSUFICIENTE')
    confere('S-T1 limpa', A.classe_onda_S([1.0] * 8, [20.0] * 8, 8), 'ONDA_LIMPA')
    confere('S-T1 borrada', A.classe_onda_S([0.75] * 8, [20.0] * 8, 8), 'ONDA_BORRADA')
    confere('S-T1 borrada (contraste)', A.classe_onda_S([1.0] * 8, [1.0] * 8, 8), 'ONDA_BORRADA')
    confere('S-T1 sem onda', A.classe_onda_S([0.25] * 8, [0.5] * 8, 8), 'SEM_ONDA')
    confere('S-T1 insuficiente', A.classe_onda_S([1.0, None], [20.0, 20.0], 8), 'INSUFICIENTE')
    confere('custo segue', A.classe_custo(0.85), 'SEGUE_O_CUSTO')
    confere('custo não segue', A.classe_custo(0.4), 'NAO_SEGUE_O_CUSTO')
    confere('custo intermediário', A.classe_custo(0.6), 'INTERMEDIARIO')
    confere('custo insuficiente', A.classe_custo(None), 'INSUFICIENTE')
    confere('S lembrada (alvo)', A.classe_global_S('SEM_ONDA', 'ONDA_LIMPA', 'SEGUE_O_CUSTO'), 'ONDA_LEMBRADA')
    confere('S lembrada (genérica)', A.classe_global_S('ONDA_LIMPA', 'SEM_ONDA', 'NAO_SEGUE_O_CUSTO'), 'ONDA_LEMBRADA')
    confere('S esquecida', A.classe_global_S('SEM_ONDA', 'SEM_ONDA', 'SEGUE_O_CUSTO'), 'ONDA_ESQUECIDA')
    confere('S mista', A.classe_global_S('SEM_ONDA', 'ONDA_BORRADA', 'SEGUE_O_CUSTO'), 'MISTA')
    confere('S insuficiente', A.classe_global_S('SEM_ONDA', 'SEM_ONDA', 'INSUFICIENTE'), 'INSUFICIENTE')
    confere('controle consistente', A.classe_controle(['ONDA', 'ONDA_FRAGIL'], ['ONDA', 'ONDA_FRAGIL']), 'CONSISTENTE')
    confere('controle inconsistente', A.classe_controle(['ONDA', 'ONDA_FRAGIL'], ['ONDA', 'SEM_ONDA']), 'INCONSISTENTE')
    confere('controle insuficiente', A.classe_controle(['ONDA'], ['INSUFICIENTE']), 'INSUFICIENTE')
    confere('controle insuficiente (vazio)', A.classe_controle([], []), 'INSUFICIENTE')
    confere('existe: frágil conta como onda', A.existe('ONDA_FRAGIL'), 'EXISTE')
    confere('existe: onda', A.existe('ONDA'), 'EXISTE')
    confere('existe: sem onda', A.existe('SEM_ONDA'), 'NAO_EXISTE')
    confere('existe: insuficiente passa adiante', A.existe('INSUFICIENTE'), 'INSUFICIENTE')
    confere('controle de tamanho: frágil × onda é consistente', A.classe_controle([A.existe('ONDA')], [A.existe('ONDA_FRAGIL')]), 'CONSISTENTE')
    confere('OLA só na base livre', A.classe_OLA('ONDA_PROGRAMADA', 'SEPARACAO', 'ONDA_ESQUECIDA'), 'ONDA_SEM_CAMINHO_SO_NA_BASE_LIVRE')
    confere('OLA nas duas', A.classe_OLA('ONDA_PROGRAMADA', 'SEPARACAO', 'ONDA_LEMBRADA'), 'ONDA_SEM_CAMINHO_NAS_DUAS')
    confere('OLA sem onda programada', A.classe_OLA('NAO_PROGRAMADA', 'IGUAIS', 'ONDA_ESQUECIDA'), 'SEM_ONDA_PROGRAMADA')
    confere('OLA mista', A.classe_OLA('PARCIAL', 'IGUAIS', 'ONDA_ESQUECIDA'), 'MISTA')
    confere('OLA insuficiente', A.classe_OLA('ONDA_PROGRAMADA', 'INSUFICIENTE', 'ONDA_ESQUECIDA'), 'INSUFICIENTE')


def ponta_a_ponta(pasta):
    print('— ponta a ponta (fumaça e perturbações)')
    recs, cfg = A.carregar(pasta)
    res = A.avaliar_recs(recs, cfg)
    assert all(k in res['previsto_x_obtido'] for k in A.PREVISOES)
    confere('fumaça: todas as previsões avaliadas', 'OK', 'OK')
    Md = cfg['config']['L']['M_decisao']; tag = 'M%d' % Md
    r = [x for x in recs if not (x['parte'] == 'L' and x['M'] == Md)]
    o = A.avaliar_recs(r, cfg)
    confere('sem L na decisão → difusão (trava)', o['L'][tag]['T1']['difusao_1_trava'], 'INSUFICIENTE')
    confere('sem L na decisão → L global', o['L'][tag]['global'], 'INSUFICIENTE')
    confere('sem L na decisão → controle M', o['L']['controle_M'], 'INSUFICIENTE')
    confere('sem L na decisão → OLA', o['OLA'], 'INSUFICIENTE')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'L':
            for q in x['rodadas']:
                if q['teste'] == 'T1' and q['tipo'] in ('difusao', 'alvo') and q['sentido'] == 1:
                    q['margem_trava'] = 0.5; q['margem_solta'] = 0.1
    o = A.avaliar_recs(r, cfg)
    confere('telecomando apagado → difusão (trava)', o['L'][tag]['T1']['difusao_1_trava'], 'SEM_ONDA')
    confere('telecomando apagado → alvo (solta)', o['L'][tag]['T1']['alvo_1_solta'], 'SEM_ONDA')
    confere('telecomando apagado → quiralidade', o['L'][tag]['quiral']['alvo'], 'AQUIRAL')
    confere('telecomando apagado → códigos', o['L'][tag]['codigos'], 'OUTRA_ORDEM')
    confere('telecomando apagado → L global', o['L'][tag]['global'], 'NAO_PROGRAMADA')
    confere('telecomando apagado → OLA', o['OLA'], 'SEM_ONDA_PROGRAMADA')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'L':
            for q in x['rodadas']:
                if q['teste'] == 'T1' and q['tipo'] in ('difusao', 'alvo') and q['sentido'] == 1:
                    q['so_rede_max'] = q['theta_trava']
    confere('rede forte → rede dispara', A.avaliar_recs(r, cfg)['L'][tag]['rede_dispara'], 'REDE_DISPARA')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'L':
            for q in x['rodadas']:
                if q['teste'] == 'T1' and q['tipo'] == 'alvo' and q['sentido'] == 1:
                    q['t_fecha_sem_rede'] = [None if t is None else t + 0.2 * q['tau'] for t in q['t_fecha']]
    confere('rede atrasa → rede interfere', A.avaliar_recs(r, cfg)['L'][tag]['rede_interfere'], 'REDE_INTERFERE')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'L':
            for q in x['rodadas']:
                if 'T3_forca' in q:
                    q['T3_forca']['brilho_max'] = [[0.5 * b for b in bb] for bb in q['T3_forca']['brilho_max']]
    confere('lâmpadas a meia luz → T3', A.avaliar_recs(r, cfg)['L'][tag]['T3'], 'GRADUAL')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'L':
            for q in x['rodadas']:
                if q['teste'] == 'T7':
                    ref = [p for p in x['rodadas'] if p['teste'] == 'T1' and p['tipo'] == q['tipo'] and p['ordem'] == 'leste_oeste' and p['sentido'] == 1][0]
                    q['pos'] = list(ref['pos']); q['pico'] = list(ref['pico'])
    confere('sem perdas igual a com perdas → T7', A.avaliar_recs(r, cfg)['L'][tag]['T7'], 'SEM_EFEITO')
    r = [x for x in recs if x['parte'] != 'C']
    o = A.avaliar_recs(r, cfg)
    confere('sem linha → C global', o['C']['global'], 'INSUFICIENTE')
    confere('sem linha → rede na linha', o['C']['rede_dispara'], 'INSUFICIENTE')
    confere('sem linha → L×C', o['LxC'], 'INSUFICIENTE')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'C':
            ref = [q for q in x['rodadas'] if q['teste'] == 'T1' and q['lado'] == 'leste' and q['sentido'] == 1][0]
            for q in x['rodadas']:
                if q['teste'] == 'T6':
                    q['pico_casa'] = list(ref['pico_casa']); q['t_fecha'] = list(ref['t_fecha'])
    o = A.avaliar_recs(r, cfg)
    confere('linha sem bloqueio no corte → C-T6', o['C']['T6'], 'ATRAVESSA')
    confere('linha sem bloqueio no corte → C global', o['C']['global'], 'PARCIAL')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'S' and x['rotulo'] == 'S20':
            x['gap'] = 0.0
    o = A.avaliar_recs(r, cfg)
    confere('S20 degenerado → S-T1', o['S']['S20']['T1_generico'], 'INSUFICIENTE')
    confere('S20 degenerado → S global', o['S']['S20']['global'], 'INSUFICIENTE')
    confere('S20 degenerado → OLA', o['OLA'], 'INSUFICIENTE')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'S' and x['rotulo'] == 'S20':
            x['rodadas'][0]['norma'] = 1.01
    confere('S20 norma fora → S global', A.avaliar_recs(r, cfg)['S']['S20']['global'], 'INSUFICIENTE')
    r = copy.deepcopy(recs)
    for x in r:
        if x['parte'] == 'S' and x['rotulo'] == 'S20':
            for q in x['rodadas']:
                ordem = [0, 1, 2, 3] if q['ordem'] == 'leste_oeste' else [3, 2, 1, 0]
                G = [[0.0] * 4 for _ in range(4)]
                for j, h in enumerate(ordem):
                    G[h][j] = 1.0
                q['G'] = G; q['vencedores'] = ordem; q['acerto'] = 1.0
    o = A.avaliar_recs(r, cfg)
    confere('S20 onda perfeita → S-T1 alvo', o['S']['S20']['T1_alvo'], 'ONDA_LIMPA')
    confere('S20 onda perfeita → S global', o['S']['S20']['global'], 'ONDA_LEMBRADA')


if __name__ == '__main__':
    ramos()
    ponta_a_ponta(sys.argv[1])
    print('\nTODOS OS %d RAMOS CONFEREM' % N_OK)
