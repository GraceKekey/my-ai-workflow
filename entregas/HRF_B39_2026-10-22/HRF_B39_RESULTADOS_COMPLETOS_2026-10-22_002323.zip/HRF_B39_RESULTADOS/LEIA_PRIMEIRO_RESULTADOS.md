# B39 — Resultados completos

Relatório: HRF_B39_RELATORIO_2026-10-22_002323.md

{
  "L": "ONDA_PROGRAMADA",
  "C": "ONDA_COM_CAMINHO",
  "S20": "ONDA_ESQUECIDA",
  "S24": "ONDA_ESQUECIDA",
  "LxC": "SEPARACAO",
  "OLA": "ONDA_SEM_CAMINHO_SO_NA_BASE_LIVRE",
  "controle_M": "CONSISTENTE",
  "controle_N24": "CONSISTENTE",
  "previsoes_conferem": 34,
  "previsoes_total": 34
}

Resultados desta rodada em resultados/. Fumaça e entrada original são antecedentes.
