# B39 — fumaça declarada

**Data:** 21 de outubro de 2026, 20h30–20h36 (America/Sao_Paulo) — Claude (`-clau`)
**Autoria:** Mario José do Canto Filho, MD · execução: Claude

A fumaça é um teste do código e do avaliador em tamanhos menores, com sementes próprias. Não é resultado.

## Configuração

| Parte | Tamanhos | Sementes |
|---|---|---|
| L | M = 400 e 800 (decisão em 800, controle em 400) | 39000, 39001 (M = 400); 39100, 39101 (M = 800) |
| C | H = 7 casas, Mc = 600 | — |
| S20 | N = 16 | 3990 |
| S24 | N = 20 | 3991 |

O resto dos parâmetros é o da rodada completa (protocolo §4).

## Previsto × obtido

33 de 34 conferem. A saída completa está em `fumaca/saida_avaliar.txt`.

**Não confere: L.controle_M.**
- A fumaça compara M = 800 com M = 400.
- Em M = 400, a ola da difusão ainda não existe: só 1/3 das margens passam de 1 (SEM_ONDA). Em M = 800, ela existe
  (ONDA_FRAGIL). A frente da difusão também tem pouca folga em M = 400 (3,6).
- A folga da difusão cresce com M: ≈ 3,6 em M = 400, 5,6–7,6 em M = 800, ≈ 11 em M = 1 600 (explorações). Em M
  finito, o perfil Σ c_k não pesa todas as casas igualmente, e a casa mais fraca baixa a margem.
- A rodada completa compara M = 800 com M = 1 600.

## Números da fumaça (M = 800, decisão)

| Mensagem e relé | Classe | Fração com margem > 1 | Folga (mediana) |
|---|---|---|---|
| difusão, trava | ONDA | 1,00 | 5,6 |
| difusão, solta | ONDA_FRAGIL | 0,83 | 1,4 |
| alvo, trava | ONDA | 1,00 | 1 000 |
| alvo, solta | ONDA | 1,00 | 55 |
| genérica, trava | ONDA_FRAGIL | 0,67 | 1,3 |
| genérica, solta | SEM_ONDA | 0,00 | 0,14 |
| difusão, s = −1, solta | SEM_ONDA | 0,00 | 0,32 |
| alvo, s = −1, solta | SEM_ONDA | 0,00 | 0,28 |

Outros testes:
- **Quiralidade:** os picos caem 5,4 vezes (difusão) e 18 vezes (alvo) no sentido oposto.
- **T3:** tudo ou nada em todas as rodadas.
- **T4:**
  - margem da frente em τ = 75 / 150 / 300 / 600: difusão 0,68 / 2,6 / 5,9 / 8,0; alvo 161 / 332 / 1 001 / 1 907;
  - intervalo/τ entre 1,00 e 1,02.
- **T5:** picos das outras casas iguais (razão 1,0000), sem atraso.
- **T6:** picos 0,77 dos de referência, atraso 0,016 τ.
- **T7 (eco):**
  - o eco cresce 8,7 vezes (difusão) e 13,8 vezes (alvo) sem perdas;
  - a ola da difusão cai para 0,14, e a do alvo para 3,7.
- **Rede:**
  - leitura da rede sozinha até 0,038 do limiar do meio (difusão e alvo, s = +1);
  - mediana de |Δt| = 0,0025 τ;
  - disparos iguais em 100 % das casas;
  - energia da rede na base ≈ 330 vezes a da mensagem (mediana).
  - Com todas as rodadas T1, a leitura da rede chega a 0,33 do limiar e 90 % das casas disparam igual: são as
    mensagens fracas (§9, item 10 do protocolo).
- **Linha (H = 7):**
  - Spearman 1 nas quatro rodadas;
  - intervalo/(d/v_g) 0,99–1,01;
  - frente: margens 25–2 300; ola: margens 4,6–15;
  - tirar a casa 4 não bloqueia (razão 1,10);
  - o corte bloqueia (7 × 10⁻⁵);
  - rede/limiar 0,0036.
- **SYK:** sem onda nas duas mensagens (acerto 0,25); vencem as casas baratas (0,81 em N = 16; 0,84 em N = 20); ordem
  final pelo custo (Spearman 1).

## Figura

`fumaca/figura_fumaca_B39.png`: brilho das dez lâmpadas ao longo do tempo (M = 800, semente 39100, leste → oeste,
s = +1), para as três mensagens e os dois relés, no limiar do meio de cada rodada.

## Testes do código

- `testar_avaliador_B39.py fumaca`: TODOS OS 143 RAMOS CONFEREM.
- `conferir_pecas_B39.py fumaca`: TODAS AS 14 PEÇAS CONFEREM:
  - motor × RK4: erro 3,4 × 10⁻⁷;
  - rede × RK4: 3,4 × 10⁻⁹;
  - superposição: 7,8 × 10⁻⁸;
  - filtro: 3,6 × 10⁻¹⁵;
  - margem > 1 ⇔ acerto = 1 em 256 comparações.

## Tempos (1 núcleo por processo, 2 processos em paralelo)

| Parte | Tempo | Memória |
|---|---|---|
| L, M = 400 | 23–24 s por semente | 0,3 GB |
| L, M = 800 | 55–60 s por semente | 0,9 GB |
| C, H = 7 | 13 s | 0,3 GB |
| S, N = 16 | 37 s (8 rodadas) | 0,06 GB |
| S, N = 20 | 300 s (8 rodadas) | 0,09 GB |
