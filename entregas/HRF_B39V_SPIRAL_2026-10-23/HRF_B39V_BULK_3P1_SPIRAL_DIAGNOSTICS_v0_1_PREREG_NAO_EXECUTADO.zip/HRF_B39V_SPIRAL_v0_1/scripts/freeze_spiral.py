from pathlib import Path
import hashlib,json
r=Path(__file__).resolve().parents[1];target=r/'hashes_antes_da_execucao.txt'
if target.exists():raise SystemExit('freeze exists; preserve it and record an explicit technical amendment before replacement')
exclude={'__pycache__','.git','.venv','examples','reports','results','figures'}
files=sorted(p for p in r.rglob('*') if p.is_file() and not any(k in exclude for k in p.relative_to(r).parts) and p.name not in ('MANIFEST_SHA256.txt','hashes_antes_da_execucao.txt','RELATORIO_VERIFICACAO_TECNICA.md'))
target.write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(r).as_posix()+'\n' for p in files));print(json.dumps({'frozen_files':len(files),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'scientific_final_simulations_executed':False}))
