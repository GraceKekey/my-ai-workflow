param([string]$Preset='config/spiral_smoke.json',[string]$Output='results/spiral_smoke')
$ErrorActionPreference='Stop'
Set-Location (Join-Path $PSScriptRoot '..')
$env:OPENBLAS_NUM_THREADS='1';$env:OMP_NUM_THREADS='1';$env:MKL_NUM_THREADS='1'
python -X utf8 -I scripts/spiral.py run --config $Preset --output $Output --execute
if ($LASTEXITCODE -ne 0) {throw 'Execução bloqueada ou falhou'}
python -X utf8 -I scripts/spiral.py plot3d --input $Output --output "$Output/figures"
if ($LASTEXITCODE -ne 0) {throw 'Visualização falhou'}
python -X utf8 -I scripts/spiral.py spiral_report --input $Output --output "$Output/reports"
