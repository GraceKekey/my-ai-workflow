#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
preset="${1:-config/spiral_smoke.json}"
output="${2:-results/spiral_smoke}"
python3 -I scripts/spiral.py run --config "$preset" --output "$output" --execute
python3 -I scripts/spiral.py plot3d --input "$output" --output "$output/figures"
python3 -I scripts/spiral.py spiral_report --input "$output" --output "$output/reports"
