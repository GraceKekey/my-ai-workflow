from pathlib import Path
import sys,unittest
r=Path(__file__).resolve().parents[1];sys.path.insert(0,str(r));suite=unittest.defaultTestLoader.discover(str(r/'tests'),pattern='test_spiral*.py');result=unittest.TextTestRunner(verbosity=2).run(suite);raise SystemExit(not result.wasSuccessful())
