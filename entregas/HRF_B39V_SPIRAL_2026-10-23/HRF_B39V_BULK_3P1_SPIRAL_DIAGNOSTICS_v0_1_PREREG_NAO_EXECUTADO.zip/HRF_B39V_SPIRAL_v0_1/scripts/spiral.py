from pathlib import Path
import sys,importlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
if len(sys.argv)<2:raise SystemExit('commands: run | plot3d | spiral_report | export_data')
command=sys.argv.pop(1)
if command not in ('run','plot3d','spiral_report','export_data'):raise SystemExit('unknown command')
raise SystemExit(importlib.import_module('hrf_integral.'+command).main())
