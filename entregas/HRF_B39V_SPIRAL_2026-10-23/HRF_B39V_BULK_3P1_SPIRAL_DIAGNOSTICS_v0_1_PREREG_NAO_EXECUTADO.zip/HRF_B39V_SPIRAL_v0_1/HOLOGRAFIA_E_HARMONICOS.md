# Holografia separada dos diagnósticos de espiral

[F/M] Dependência angular pode ser decomposta por c_m=(1/2π)∫Psi exp(−im theta)dtheta tanto num campo bulk conhecido quanto em dados complexos de fronteira apropriados. Essa operação de Fourier não define um dual gravitacional.

[M] boundary_angular.ads_cylindrical_mode implementa o modo normalizável livre em AdS4 dado: phi=z^(3/2)J_nu(qz)J_m(k r) exp[i(m theta−omega t)], omega²=q²+k², nu²=9/4+m_bulk²L² com L=1. O coeficiente normalizável de fronteira é (q/2)^nu/Gamma(nu+1)·J_m(k r) exp[i(m theta−omega t)]. Normalização O=(2Delta−3)A precisa ser aplicada se esse for o operador escolhido. É uma referência matemática em geometria fornecida; seus testes são algébricos, sem simulação quântica nova.

[?] Futuro mapa exigiria estado/álgebra de fronteira, operadores, kernel HKLL no patch e regime corretos, observável angular e erro de holdout independentes. A comparação entre m em dois conjuntos de dados não fornece esse mapa. O núcleo integral RT/HKLL fica preservado como referência, sem novas execuções físicas aqui.

[D] A derivação mantém **BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY**. Uma imagem em espiral, caso apareça, não valida holografia, DIO, GMFt ou emergência gravitacional.
