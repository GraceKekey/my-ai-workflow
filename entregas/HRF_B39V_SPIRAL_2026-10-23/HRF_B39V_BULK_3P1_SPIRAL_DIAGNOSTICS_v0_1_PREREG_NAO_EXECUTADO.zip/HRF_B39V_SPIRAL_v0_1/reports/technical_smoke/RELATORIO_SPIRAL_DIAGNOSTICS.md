# Relatório SPIRAL diagnostics

[D] PRÉ-REGISTRADO — GRANDES SIMULAÇÕES NÃO EXECUTADAS; APENAS SMOKE TÉCNICO.

## Objetivo

[D] Observar campo 3D e discriminar propagação radial, rotação angular, torção de fase e transporte em z. Não inserir fator exp(i k_z z) nem um deslocamento azimutal forçado na fonte.

## Parâmetros

[D] Cada caso guarda run.json/case.json, a configuração completa, os passos efetivos, a malha, o catálogo dos 468 históricos e os extras. Os receptores fora do domínio técnico permanecem catalogados e explicitamente inativos. Limiar histórico preservado por caso; não foi recalibrado.

## Medidas e método

[M] Campo completo phi e momento por frame; energia Euleriana e corrente local por projeção de gradientes FEM P1; carga orbital operacional em z; centros de energia; máximos locais com preservação de degenerescências. A energia dos frames descreve a perturbação, não a rede estacionária adicionada ao readout.

[M] Fase de lock-in: média Hann finita de 2 phi exp(+i omega t), compatível com cos(m theta+kz z-omega t). A fase exige janela e amplitude suficientes; bordas da janela são descartadas. A média circular de um vórtice m≠0 pode ser indefinida; reporta-se a fase do coeficiente harmônico, não uma média linear de ângulos. Potência é normalizada pela potência total do anel, sem esconder conteúdo fora do conjunto de m.

[M] Torção de fase é ajustada em trechos z conectados, nos dois hemisférios e globalmente. Requer pureza do modo primário ≥limiar congelado e controle de aliasing. Crista de |phi| com lobos empatados não recebe uma linha artificial escolhida por desempate.

## Resultados e gates

```json
[
  {
    "case_id": "sminus",
    "classification": "TECHNICAL_SMOKE_ONLY",
    "data_scope": "technical smoke, not a scientific experiment",
    "frames": 5,
    "phase": {
      "status": "INSUFFICIENT_TEMPORAL_WINDOW",
      "required_frames": 85,
      "available_frames": 5
    },
    "usable_phase_rings": 0,
    "gates": {
      "information": "FAIL_NO_RESOLVED_INFORMATION",
      "zscan": "PASS_ZSCAN_DIAGNOSTICS",
      "helicity": "FAIL_NO_RESOLVED_INFORMATION",
      "structure": "INCONCLUSIVE_SPIRAL_STRUCTURE"
    },
    "phase_twist_candidates": 0,
    "ridge_classifications": {
      "INDEFINITE_AMBIGUOUS_OR_MISSING_RIDGE": 5
    },
    "max_abs_net_z_flux_fraction": 2.6822827982599665e-16,
    "max_abs_energy_up_down_asymmetry": 2.830585979819798e-16,
    "HRF_holography": "BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY",
    "interpretation": "m≠0 alone indicates angular structure, not upward energy transport; scalar operational OAM is not fundamental helicity",
    "limits": [
      "phase from finite-window narrow-band lock-in, edge frames discarded",
      "real dipole lobes may be degenerate: no invented single ridge",
      "convergence/boundary controls required before physical interpretation"
    ]
  },
  {
    "case_id": "splus",
    "classification": "TECHNICAL_SMOKE_ONLY",
    "data_scope": "technical smoke, not a scientific experiment",
    "frames": 5,
    "phase": {
      "status": "INSUFFICIENT_TEMPORAL_WINDOW",
      "required_frames": 85,
      "available_frames": 5
    },
    "usable_phase_rings": 0,
    "gates": {
      "information": "FAIL_NO_RESOLVED_INFORMATION",
      "zscan": "PASS_ZSCAN_DIAGNOSTICS",
      "helicity": "FAIL_NO_RESOLVED_INFORMATION",
      "structure": "INCONCLUSIVE_SPIRAL_STRUCTURE"
    },
    "phase_twist_candidates": 0,
    "ridge_classifications": {
      "INDEFINITE_AMBIGUOUS_OR_MISSING_RIDGE": 5
    },
    "max_abs_net_z_flux_fraction": 3.4880626245755655e-16,
    "max_abs_energy_up_down_asymmetry": 4.1304549531662145e-16,
    "HRF_holography": "BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY",
    "interpretation": "m≠0 alone indicates angular structure, not upward energy transport; scalar operational OAM is not fundamental helicity",
    "limits": [
      "phase from finite-window narrow-band lock-in, edge frames discarded",
      "real dipole lobes may be degenerate: no invented single ridge",
      "convergence/boundary controls required before physical interpretation"
    ]
  }
]
```

## Interpretação

[H] Um ajuste m≠0 e kz≠0 pode representar uma hélice de fase. Isso não implica trajetória helicoidal de energia. [M] Geometria de crista, fluxo, centro de energia e assimetria superior/inferior são saídas distintas. [F] Uma fonte par em z sobre fundo par admite radiação simétrica para cima e para baixo, sem preferência ascendente. Rotação de fonte não insere direção privilegiada em z.

[?] Estruturas candidatas exigem controles de grade, fronteira, janela de fase, massa/frequência e comparação pareada s±. Gates de visualização/diagnóstico não certificam a estrutura física. A interface HRF continua BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY.
