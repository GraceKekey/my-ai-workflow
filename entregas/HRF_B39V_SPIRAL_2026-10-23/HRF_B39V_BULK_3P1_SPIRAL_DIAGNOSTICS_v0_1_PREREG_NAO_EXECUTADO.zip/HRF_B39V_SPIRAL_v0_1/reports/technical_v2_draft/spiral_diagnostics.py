"""Post-process volume frames; no new PDE evolution here."""
from pathlib import Path
import csv,json
import numpy as np
from .io import atomic_json,atomic_npz,digest
from .spiral_storage import FrameStore
from .phase_analysis import demodulate,azimuthal
from .helicity_metrics import chirality,twist_profiles,axial_transport
from .ridge_tracking import local_peaks,classify_line
from .zscan import arrival_time,slice_centers,radial_time

def sanitize(obj):
    if isinstance(obj,dict):return {k:sanitize(v) for k,v in obj.items()}
    if isinstance(obj,(list,tuple)):return [sanitize(x) for x in obj]
    if isinstance(obj,np.ndarray):return sanitize(obj.tolist())
    if isinstance(obj,np.generic):return sanitize(obj.item())
    if isinstance(obj,float) and not np.isfinite(obj):return None
    return obj

def analyze_case(folder):
    folder=Path(folder);run=json.loads((folder/'case.json').read_text());c=run['config'];d=c['diagnostics'];out=folder/'analysis';out.mkdir(exist_ok=True)
    store=FrameStore(folder/'frames',run['run_id']);frames=store.catalog['frames'];times=np.array([f['t'] for f in frames]);grid=np.load(folder/'grid.npz',allow_pickle=False);x,y,z=(grid[k] for k in ('x','y','z'));shape=(len(x),len(y),len(z));nodevol=grid['node_volume'];requested_z=grid['probe_z'];nr=len(grid['probe_r']);theta=grid['probe_theta']
    rings=[];energy=[];centers=[];coe=[];fluxes=[];Lz=[];ridges=[];ridge_xy=[];radial=[];radial_edges=np.linspace(0,min(abs(x[0]),x[-1],abs(y[0]),y[-1]),25)
    widths=np.r_[np.diff(z)[0]/2,(z[2:]-z[:-2])/2,np.diff(z)[-1]/2]
    for frame in frames:
        with store.read(frame,cuts=True) as data:rings.append(data['ring'])
        with store.read(frame) as data:
            en,center,center3=slice_centers(data['energy_density'],nodevol,x,y,z);energy.append(en);centers.append(center);coe.append(center3);fluxes.append(np.sum(data['flux'][...,2]*nodevol,axis=(0,1))/widths);Lz.append(float(data['orbital_Lz_operational']));radial.append(radial_time(data['energy_density'],nodevol,x,y,radial_edges))
            p=[];all_peaks=[]
            for iz in range(len(z)):
                peaks=local_peaks(data['phi'][:,:,iz],x,y,d['ridge_tie_relative']);all_peaks.append(peaks);p.append(peaks['primary'] if peaks['primary'] is not None else [np.nan,np.nan])
            ridge_xy.append(p);classification=classify_line(z,p,np.diff(x).max(),np.diff(y).max(),d);ridges.append(dict(t=frame['t'],classification=classification,slices=all_peaks))
    rings=np.asarray(rings);phase,valid_time,phase_meta=demodulate(rings,times,c['source']['omega'],d['demod_window_cycles']);az=azimuthal(phase,theta,d['m_values'],d['amplitude_relative_floor'],d['amplitude_absolute_floor'],d['circular_resultant_min'])
    probe_valid=grid['probe_inside'].reshape(len(requested_z),nr,len(theta)).all(axis=-1)
    coeff=az['coefficients'];coeff[:,~probe_valid]=0
    # Mask lock-in edge frames and weak/non-existent rings, without inventing phase at zeros.
    ring_nonzero=np.max(az['amplitude'],axis=-1)>az['amplitude_floor'];usable=valid_time[:,None,None]&probe_valid[None,:,:]&ring_nonzero
    az['phase'][~valid_time]=np.nan;az['winding'][~usable]=np.nan
    primary_index=d['m_values'].index(c['rotation']);twist_coeff=coeff.copy();primary_valid=az['power_fraction'][...,primary_index]>=d['purity_min'];twist_coeff[...,primary_index]=np.where(primary_valid,twist_coeff[...,primary_index],0)
    twist=twist_profiles(requested_z,twist_coeff,d['m_values'],c['rotation'],valid_time,d);ch=chirality(np.abs(coeff)**2,np.array(d['m_values']))
    energy=np.asarray(energy);fluxes=np.asarray(fluxes);centers=np.asarray(centers);coe=np.asarray(coe);transport=axial_transport(z,energy,fluxes)
    arrivals=[arrival_time(times,energy[:,i],d['arrival_fraction'],d['amplitude_absolute_floor']) for i in range(len(z))];zero=int(np.argmin(abs(z)));t0=arrivals[zero];delays=[None if v is None or t0 is None else v-t0 for v in arrivals]
    phase_resolution=bool(usable.sum()>0 and len(times)>=16);z_resolved=sum(v is not None for v in arrivals)>=3
    source_ok=run['resources']['source_resolution_adequate'];information_ok=source_ok and run.get('full_field_frame_nyquist_resolved',False) and phase_resolution and z_resolved and c['classification']!='TECHNICAL_SMOKE_ONLY'
    summary=dict(case_id=c['case_id'],classification=c['classification'],data_scope='technical smoke, not a scientific experiment' if c['classification']=='TECHNICAL_SMOKE_ONLY' else 'exploratory prescribed-metric scalar',frames=len(frames),phase=phase_meta,usable_phase_rings=int(usable.sum()),gates={'information':'RESOLVED_OBSERVATIONS_ONLY' if information_ok else 'FAIL_NO_RESOLVED_INFORMATION','zscan':'PASS_ZSCAN_DIAGNOSTICS' if z_resolved and len(times)>=3 else 'FAIL_NO_RESOLVED_INFORMATION','helicity':'PASS_HELICITY_DIAGNOSTIC' if phase_resolution else 'FAIL_NO_RESOLVED_INFORMATION','structure':'INCONCLUSIVE_SPIRAL_STRUCTURE'},phase_twist_candidates=sum(t['status']=='PHASE_TWIST_CANDIDATE' for t in twist),ridge_classifications={label:sum(r['classification']['label']==label for r in ridges) for label in sorted({r['classification']['label'] for r in ridges})},max_abs_net_z_flux_fraction=float(np.nanmax(abs(transport['net_z_flux_fraction']))) if np.isfinite(transport['net_z_flux_fraction']).any() else None,max_abs_energy_up_down_asymmetry=float(np.nanmax(abs(transport['energy_upper_lower_asymmetry']))) if np.isfinite(transport['energy_upper_lower_asymmetry']).any() else None,HRF_holography='BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY',interpretation='m≠0 alone indicates angular structure, not upward energy transport; scalar operational OAM is not fundamental helicity',limits=['phase from finite-window narrow-band lock-in, edge frames discarded','real dipole lobes may be degenerate: no invented single ridge','convergence/boundary controls required before physical interpretation'])
    ridge_array=np.asarray(ridge_xy);primary_theta=np.arctan2(ridge_array[...,1],ridge_array[...,0]);primary_radius=np.linalg.norm(ridge_array,axis=-1)
    atomic_npz(out/'diagnostics.npz',times=times,z=z,probe_z=requested_z,probe_r=grid['probe_r'],theta=theta,ring_amplitude=az['amplitude'],ring_phase=az['phase'],mode_real=coeff.real,mode_imag=coeff.imag,mode_power_fraction=az['power_fraction'],winding=az['winding'],circular_mean_phase=az['circular_mean_phase'],circular_resultant=az['circular_resultant'],phase_valid_time=valid_time,usable_phase_ring=usable,chirality_operational=ch,energy_by_z=energy,center_by_z=centers,center_energy_3D=coe,flux_z=fluxes,orbital_Lz=Lz,ridge_xy=ridge_xy,maxima_angle_z=primary_theta,maxima_radius_z=primary_radius,radial_time=np.asarray(radial),radial_edges=radial_edges,**transport)
    atomic_json(out/'summary.json',sanitize(summary));atomic_json(out/'twist.json',sanitize(twist));atomic_json(out/'ridges.json',sanitize(ridges))
    with (out/'zscan.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['z','threshold_arrival','delay_vs_z0','arrival_fraction','notice'])
        for zz,tt,lag in zip(z,arrivals,delays):writer.writerow([zz,tt,lag,d['arrival_fraction'],'threshold arrival, not causal front'])
    with (out/'time_z.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['t','z','energy_slab','center_x','center_y','flux_z','global_center_z','orbital_Lz_operational'])
        for it,t in enumerate(times):
            for iz,zz in enumerate(z):writer.writerow([t,zz,energy[it,iz],*centers[it,iz],fluxes[it,iz],coe[it,2],Lz[it]])
    atomic_json(out/'zscan.json',sanitize(dict(z=z,arrival=arrivals,delay=delays,center_energy=coe,energy_up_down_asymmetry=transport['energy_upper_lower_asymmetry'])))
    with (out/'twist.csv').open('w',newline='') as f:
        keys=sorted({k for q in twist for k in q}) if twist else ['status','kz','phase_span'];writer=csv.DictWriter(f,fieldnames=keys);writer.writeheader();writer.writerows(sanitize(twist))
    # Slice phase/amplitude files are computed one slab at a time; all full field frames remain available.
    for iz,zz in enumerate(requested_z):
        slices=[]
        for frame in frames:
            with store.read(frame,verify=False,cuts=True) as data:slices.append(data['xy'][iz])
        slab=np.asarray(slices);zphase,v,_=demodulate(slab,times,c['source']['omega'],d['demod_window_cycles']);amp=abs(zphase);mask=(amp>max(d['amplitude_absolute_floor'],np.max(amp,initial=0)*d['amplitude_relative_floor']))&v[:,None,None]
        atomic_npz(out/f'phase_xy_{iz:02d}.npz',amplitude=amp.astype('f4'),phase=np.where(mask,np.angle(zphase),np.nan).astype('f4'),phase_valid=mask,requested_z=zz,actual_z=grid['slice_actual_z'][iz])
    atomic_json(out/'maxima_angle_z.json',sanitize(dict(times=times,z=z,primary_angle=primary_theta,primary_radius=primary_radius,notice='undefined when equally strong lobes prevent a unique crest')))
    with (out/'maxima_angle_z.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['t','z','theta_candidate','radius_candidate','amplitude','ambiguous','is_primary_unique'])
        for frame_ridge in ridges:
            for zz,peak in zip(z,frame_ridge['slices']):
                for xpeak,ypeak,amp in peak['points']:writer.writerow([frame_ridge['t'],zz,np.arctan2(ypeak,xpeak),np.hypot(xpeak,ypeak),amp,int(peak['ambiguous']),int(not peak['ambiguous'])])
    atomic_json(out/'diagnostics_manifest.json',{'inputs_sha256':digest(folder/'frames/frames.json'),'config_sha256':__import__('hashlib').sha256(json.dumps(c,sort_keys=True).encode()).hexdigest(),'diagnostic_sha256':digest(out/'diagnostics.npz')})
    return sanitize(summary)
