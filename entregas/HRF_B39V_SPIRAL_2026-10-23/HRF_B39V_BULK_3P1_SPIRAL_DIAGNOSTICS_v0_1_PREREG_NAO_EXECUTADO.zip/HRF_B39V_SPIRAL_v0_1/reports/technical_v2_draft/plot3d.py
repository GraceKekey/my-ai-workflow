"""Scientific figures A-F, volumetric surfaces/cloud, common scales and GIF/MP4."""
from pathlib import Path
import argparse,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from .spiral_storage import FrameStore
from .spiral_diagnostics import analyze_case,sanitize
from .visualization_3d import isosurface,point_cloud,overlays
from .export_animation import export_frames
from .io import atomic_json
from .helicity_metrics import paired_angular_statistics

def case_folders(path):
    path=Path(path)
    if (path/'case.json').exists():return [path]
    return sorted(p.parent for p in path.glob('*/case.json') if json.loads(p.read_text()).get('status')=='COMPLETED')

def render_case(folder,out,vmax):
    folder=Path(folder);out=Path(out);out.mkdir(parents=True,exist_ok=True);run=json.loads((folder/'case.json').read_text());c=run['config'];vis=c['visualization'];grid=np.load(folder/'grid.npz',allow_pickle=False);axes=[grid[k] for k in ('x','y','z')];bounds=[[a[0],a[-1]] for a in axes];store=FrameStore(folder/'frames',run['run_id']);frames=store.catalog['frames'];technical=c['classification']=='TECHNICAL_SMOKE_ONLY';tag='SMOKE TÉCNICO — SEM INFERÊNCIA FÍSICA' if technical else 'EXPLORATÓRIO — SEM CERTIFICAÇÃO HISTÓRICA'
    analysis=folder/'analysis'
    if not (analysis/'summary.json').exists():analyze_case(folder)
    diag=np.load(analysis/'diagnostics.npz',allow_pickle=False);summary=json.loads((analysis/'summary.json').read_text())
    peak_index=0;peak=-1.
    for i,fr in enumerate(frames):
        with store.read(fr) as data:value=float(np.max(np.abs(data['phi']),initial=0))
        if value>peak:peak=value;peak_index=i
    selected=frames[peak_index];D=store.read(selected);phi=D['phi'];fig=plt.figure(figsize=(15,5));surface_meta=[]
    for i,(field,level,color,label) in enumerate(((phi,vis['iso_fraction']*vmax,'crimson','phi positivo'),(phi,-vis['iso_fraction']*vmax,'royalblue','phi negativo'),(abs(phi),vis['iso_fraction']*vmax,'teal','|phi|'))):
        ax=fig.add_subplot(1,3,i+1,projection='3d');tri,meta=isosurface(field,axes,level,vis['max_axis'],vis['max_triangles']);surface_meta.append(meta)
        if len(tri):ax.add_collection3d(Poly3DCollection(tri,alpha=.4,facecolor=color,edgecolor='none'))
        overlays(ax,grid,c['source']['center'],bounds);ax.set_title(label)
    fig.suptitle(f'Figura A — t={selected["t"]:g}; z=0 colorido por H auxiliar\n{tag}');fig.tight_layout();fig.savefig(out/'FigureA_isosurfaces.png',dpi=120);plt.close(fig)
    fig=plt.figure(figsize=(8,6));ax=fig.add_subplot(projection='3d');pts,values=point_cloud(phi,axes,vis['cloud_fraction']*vmax,vis['max_points'])
    if len(pts):ax.scatter(*pts.T,c=values,cmap='RdBu_r',vmin=-vmax,vmax=vmax,s=6,alpha=.6)
    overlays(ax,grid,c['source']['center'],bounds);ax.set_title(f'Figura A — nuvem acima do limiar\n{tag}');fig.tight_layout();fig.savefig(out/'FigureA_cloud.png',dpi=120);plt.close(fig)
    with store.read(selected,cuts=True) as cut:
        nz=len(c['diagnostics']['z_planes']);nc=3;nr=int(np.ceil(nz/nc));fig,axs=plt.subplots(nr,nc,figsize=(11,3*nr),squeeze=False)
        for iz,ax in enumerate(axs.flat):
            if iz>=nz:ax.axis('off');continue
            ax.imshow(cut['xy'][iz].T,origin='lower',extent=[*bounds[0],*bounds[1]],cmap='RdBu_r',vmin=-vmax,vmax=vmax,aspect='auto');ax.set_title(f'z pedido {grid["probe_z"][iz]:g}, real {grid["slice_actual_z"][iz]:.3g}');ax.set(xlabel='x',ylabel='y')
        fig.suptitle(f'Figura B — cortes xy, t={selected["t"]:g}; escala comum\n{tag}');fig.tight_layout();fig.savefig(out/'FigureB_xy.png',dpi=120);plt.close(fig)
        fig,axs=plt.subplots(1,2,figsize=(10,4))
        for ax,key,extent,label in ((axs[0],'xz',[*bounds[0],*bounds[2]],'x'),(axs[1],'yz',[*bounds[1],*bounds[2]],'y')):ax.imshow(cut[key].T,origin='lower',extent=extent,cmap='RdBu_r',vmin=-vmax,vmax=vmax,aspect='auto');ax.set(xlabel=label,ylabel='z',title=key)
        fig.suptitle('Figura B — cortes verticais; '+tag);fig.tight_layout();fig.savefig(out/'FigureB_vertical.png',dpi=120);plt.close(fig)
    # Amplitude is the lock-in envelope; undefined phase remains visibly masked.
    izs=np.unique(np.linspace(0,len(grid['probe_z'])-1,3).astype(int));fig,axs=plt.subplots(2,len(izs),figsize=(12,7),squeeze=False);pcmap=plt.colormaps['twilight'].copy();pcmap.set_bad('lightgray')
    for col,iz in enumerate(izs):
        with np.load(analysis/f'phase_xy_{iz:02d}.npz',allow_pickle=False) as phase:
            axs[0,col].imshow(phase['amplitude'][peak_index].T,origin='lower',extent=[*bounds[0],*bounds[1]],cmap='magma',aspect='auto');axs[0,col].set_title(f'amplitude lock-in, z={grid["probe_z"][iz]:g}')
            axs[1,col].imshow(np.ma.masked_invalid(phase['phase'][peak_index].T),origin='lower',extent=[*bounds[0],*bounds[1]],cmap=pcmap,vmin=-np.pi,vmax=np.pi,aspect='auto');axs[1,col].set_title('fase (cinza=indefinida)')
    fig.suptitle('Mapas de amplitude/fase; '+tag);fig.tight_layout();fig.savefig(out/'FigureB_amplitude_phase.png',dpi=120);plt.close(fig)
    valid=np.flatnonzero(diag['phase_valid_time']);phase_index=int(valid[len(valid)//2]) if len(valid) else peak_index;ir=len(diag['probe_r'])//2
    fig,axs=plt.subplots(1,2,figsize=(11,4));theta=diag['theta'];phase=diag['ring_phase'][phase_index,:,ir,:]
    axs[0].imshow(np.ma.masked_invalid(phase),origin='lower',extent=[0,2*np.pi,grid['probe_z'].min(),grid['probe_z'].max()],aspect='auto',vmin=-np.pi,vmax=np.pi,cmap=pcmap);axs[0].set(xlabel='theta',ylabel='z',title='fase angular por altura')
    idx=c['diagnostics']['m_values'].index(c['rotation']);cm=diag['mode_real'][phase_index,:,ir,idx]+1j*diag['mode_imag'][phase_index,:,ir,idx]
    if len(valid) and np.any(abs(cm)>1e-14):axs[1].plot(grid['probe_z'],np.unwrap(np.angle(cm)),'o-');axs[1].set_title('fase do harmônico primário')
    else:axs[1].text(.5,.5,'Janela temporal insuficiente\nFase/torção não medida',ha='center',va='center',transform=axs[1].transAxes)
    axs[1].set(xlabel='z',ylabel='fase do coeficiente');fig.suptitle('Figura D — diagnóstico de fase/torção; '+tag);fig.tight_layout();fig.savefig(out/'FigureD_phase_twist.png',dpi=120);plt.close(fig)
    with np.load(folder/'observations.npz',allow_pickle=False) as obs:
        cat=obs['active_catalog_indices'];points=grid['receiver_xyz'][cat];fig,axs=plt.subplots(2,1,figsize=(10,7),sharex=True)
        chosen=[]
        for zz in (-20.,-10.,-5.,0.,5.,10.,20.):
            index=int(np.argmin(np.linalg.norm(points-[c['receivers']['radii'][0],0,zz],axis=1)))
            if index in chosen:continue
            chosen.append(index);label='('+','.join(f'{v:g}' for v in points[index])+')';axs[0].plot(obs['ts'],obs['field'][:,index],label=label);axs[1].plot(obs['ts'],obs['readout'][:,index],label=label)
        axs[0].set(ylabel='campo nos receptores',title='coordenadas reais dos receptores');axs[1].set(xlabel='t',ylabel='leitura seletiva');axs[0].legend(ncol=3,fontsize=7);fig.suptitle('Figura E — diferentes alturas; '+tag);fig.tight_layout();fig.savefig(out/'FigureE_traces.png',dpi=120);plt.close(fig)
    fig=plt.figure(figsize=(9,6));ax=fig.add_subplot(projection='3d');ridge=diag['ridge_xy'][peak_index];good=np.isfinite(ridge).all(axis=1)
    if good.any():ax.plot(ridge[good,0],ridge[good,1],axes[2][good],'o-',label='crista única resolvida')
    center=diag['center_by_z'][peak_index];good=np.isfinite(center).all(axis=1)
    if good.any():ax.plot(center[good,0],center[good,1],axes[2][good],'.-',label='centro de energia por fatia')
    if not np.isfinite(ridge).all(axis=1).any():ax.text2D(.05,.95,'Crista única indefinida / lobos degenerados',transform=ax.transAxes)
    ax.set(xlabel='x',ylabel='y',zlabel='z');ax.legend();fig.suptitle('Figura F — crista e centro de energia; '+tag);fig.tight_layout();fig.savefig(out/'FigureF_ridge.png',dpi=120);plt.close(fig)
    fig=plt.figure(figsize=(11,4));ax=fig.add_subplot(1,2,1);ridges=json.loads((analysis/'ridges.json').read_text())
    for zz,peak in zip(axes[2],ridges[peak_index]['slices']):
        for xx,yy,amplitude in peak['points']:ax.scatter(np.arctan2(yy,xx),zz,c='gray' if peak['ambiguous'] else 'red',s=12)
    ax.set(xlabel='theta dos máximos candidatos',ylabel='z',title='empates preservados, sem crista forçada');ax=fig.add_subplot(1,2,2,projection='3d');center=diag['center_energy_3D'];valid=np.isfinite(center).all(axis=1)
    if valid.any():ax.plot(*center[valid].T,'o-')
    ax.set(xlabel='centro x',ylabel='centro y',zlabel='centro z',title='trajetória temporal do centro de energia');fig.suptitle('Máximos por altura e centro temporal; '+tag);fig.tight_layout();fig.savefig(out/'FigureF_angle_z_centers.png',dpi=120);plt.close(fig)
    fig,axs=plt.subplots(1,3,figsize=(13,4));iz=int(np.argmin(abs(axes[2])));E=D['energy_density'][:,:,iz];J=D['flux'][:,:,iz];axs[0].imshow(E.T,origin='lower',extent=[*bounds[0],*bounds[1]],cmap='magma',aspect='auto');jump=max(1,len(axes[0])//15);X,Y=np.meshgrid(axes[0][::jump],axes[1][::jump],indexing='ij');axs[0].quiver(X,Y,J[::jump,::jump,0],J[::jump,::jump,1],color='cyan');axs[0].set_title('energia Euleriana / fluxo local')
    for a,zz in zip(axs[1:],(-10.,10.)):
        zi=int(np.argmin(abs(diag['z']-zz)));data=diag['radial_time'][:,:,zi];a.imshow(data.T,origin='lower',extent=[diag['times'][0],diag['times'][-1],0,diag['radial_edges'][-1]],aspect='auto',cmap='magma');a.set(xlabel='t',ylabel='raio',title=f'raio × tempo; z={diag["z"][zi]:g}')
    fig.suptitle('Energia/fluxo e evolução radial; '+tag);fig.tight_layout();fig.savefig(out/'FigureG_energy_flux_radial.png',dpi=120);plt.close(fig);D.close()
    chosen=np.unique(np.linspace(0,len(frames)-1,min(len(frames),vis['max_animation_frames'])).astype(int));pngs=[];frameout=out/'frames';frameout.mkdir(exist_ok=True)
    for i,index in enumerate(chosen):
        with store.read(frames[index],cuts=True) as data:
            fig,axs=plt.subplots(1,3,figsize=(11,4));middle=int(np.argmin(abs(grid['probe_z'])))
            for ax,values,extent,label in ((axs[0],data['xy'][middle],[*bounds[0],*bounds[1]],'xy'),(axs[1],data['xz'],[*bounds[0],*bounds[2]],'xz'),(axs[2],data['yz'],[*bounds[1],*bounds[2]],'yz')):ax.imshow(values.T,origin='lower',extent=extent,cmap='RdBu_r',vmin=-vmax,vmax=vmax,aspect='auto');ax.set_title(label)
            fig.suptitle(f't={frames[index]["t"]:.6g}; {tag}');fig.tight_layout();path=frameout/f'frame_{i:05d}.png';fig.savefig(path,dpi=100);plt.close(fig);pngs.append(path)
    animation=export_frames(pngs,out/'animation',fps=vis['fps'],gif=vis['gif'],mp4=vis['mp4']);result=dict(gate='PASS_SPIRAL_VISUALIZATION_PIPELINE',scope='file generation only, not evidence of spiral',case_id=c['case_id'],common_field_vmax=vmax,isosurfaces=surface_meta,animation=animation,phase_information=summary['gates'],active_historical=run['active_historical'],historical_catalog=468,visible_extra_receivers=int((grid['receiver_active'][468:]).sum()),H_notice='H is auxiliary graph embedding scalar shown as color on z=0, not physical height in the coordinate bulk')
    atomic_json(out/'visualization.json',sanitize(result));return result

def paired_figure(folders,out,vmax):
    pairs=[]
    for f in folders:
        c=json.loads((f/'case.json').read_text())['config']
        if c['rotation']==1:
            target=json.loads(json.dumps(c));target['rotation']=-1;target.pop('case_id',None)
            for other in folders:
                oc=json.loads((other/'case.json').read_text())['config'];oc.pop('case_id',None)
                if oc==target:pairs.append((f,other))
    if not pairs:return {'status':'BLOCKED_NO_MATCHED_ROTATION_PAIR'}
    records=[]
    for n,(plus,minus) in enumerate(pairs):
        rr=json.loads((plus/'case.json').read_text());ss=FrameStore(plus/'frames',rr['run_id']);fr=ss.catalog['frames'][len(ss.catalog['frames'])//2];rm=json.loads((minus/'case.json').read_text());sm=FrameStore(minus/'frames',rm['run_id']);fm=min(sm.catalog['frames'],key=lambda x:abs(x['t']-fr['t']))
        if abs(fm['t']-fr['t'])>1e-8:raise ValueError('comparison frames differ in physical time')
        gp=np.load(plus/'grid.npz',allow_pickle=False);gm=np.load(minus/'grid.npz',allow_pickle=False)
        if any(not np.array_equal(gp[k],gm[k]) for k in ('x','y','z')):raise ValueError('comparison grids differ')
        fig,axs=plt.subplots(1,2,figsize=(10,4));iz=int(np.argmin(abs(gp['probe_z'])))
        for ax,store,frame,title in ((axs[0],ss,fr,'s=+1'),(axs[1],sm,fm,'s=-1')):
            with store.read(frame,cuts=True) as data:ax.imshow(data['xy'][iz].T,origin='lower',extent=[gp['x'][0],gp['x'][-1],gp['y'][0],gp['y'][-1]],cmap='RdBu_r',vmin=-vmax,vmax=vmax,aspect='auto')
            ax.set_title(title);ax.set(xlabel='x',ylabel='y')
        fig.suptitle(f'Figura C — mesma escala/paleta e tempo t={fr["t"]:g}\n'+rr['config']['classification']);fig.tight_layout();path=Path(out)/f'FigureC_rotation_pair_{n:03d}.png';fig.savefig(path,dpi=120);plt.close(fig);records.append(str(path.name))
        with np.load(plus/'analysis/diagnostics.npz',allow_pickle=False) as a,np.load(minus/'analysis/diagnostics.npz',allow_pickle=False) as b:comparison=paired_angular_statistics(a,b,rr['config']['diagnostics']['m_values'])
        def fit_statistics(case):
            profiles=json.loads((case/'analysis/twist.json').read_text());result={}
            for side in ('upper','lower','all'):
                fits=[p for p in profiles if p['side']==side and p.get('kz') is not None]
                result[side]={key:float(np.median([f[key] for f in fits if f.get(key) is not None])) if any(f.get(key) is not None for f in fits) else None for key in ('kz','phase_crest_dtheta_dz','pitch_z_per_2pi')}
            return result
        comparison.update(plus_case=plus.name,minus_case=minus.name,plus_twist=fit_statistics(plus),minus_twist=fit_statistics(minus));atomic_json(Path(out)/f'helicity_pair_{n:03d}.json',comparison)
        import csv
        with (Path(out)/f'helicity_pair_{n:03d}.csv').open('w',newline='') as f:
            writer=csv.writer(f);writer.writerow(['case','hemisphere','kz','phase_crest_dtheta_dz','pitch_z_per_2pi'])
            for name,fit in ((plus.name,comparison['plus_twist']),(minus.name,comparison['minus_twist'])):
                for side,values in fit.items():writer.writerow([name,side,values['kz'],values['phase_crest_dtheta_dz'],values['pitch_z_per_2pi']])
    return dict(status='GENERATED',figures=records)

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();folders=case_folders(a.input)
    if not folders:raise ValueError('no completed volume data; run an explicitly authorized preset first')
    vmax=0.
    for folder in folders:
        run=json.loads((folder/'case.json').read_text());store=FrameStore(folder/'frames',run['run_id'])
        for frame in store.catalog['frames']:
            with store.read(frame) as d:vmax=max(vmax,float(np.max(np.abs(d['phi']),initial=0)))
    vmax=max(vmax,1e-30);out=Path(a.output);out.mkdir(parents=True,exist_ok=True);records=[render_case(f,out/f.name,vmax) for f in folders];pair=paired_figure(folders,out,vmax);atomic_json(out/'visualizations.json',dict(cases=records,pair=pair));print(json.dumps({'visualized_cases':len(records),'pair':pair}))
if __name__=='__main__':main()
