# Resumo executivo — pré-registro

[D] Versão SPIRAL diagnostics0.1, derivada da bancada integral sem modificar resultados anteriores. Grandes simulações científicas não executadas. O pacote disponibiliza todo o código novo, configurações, testes, comandos e relatórios automáticos. Exemplos, quando presentes em examples/, são apenas smoke técnico mínimo.

[M] Implementados: volumes completos por frame; cortes xy/xz/yz; isosuperfícies de phi± e |phi|; nuvens; PNG/GIF/MP4 opcional; mapas de fase/amplitude; harmônicos e enrolamento angular; momento orbital operacional; ajuste axial por hemisfério; máximos locais sem desempate artificial; centros, energia e fluxo; catálogos468+extras e relés herdados. Dados exportáveis em NPZ/JSON/CSV e figuras científicas.

[H] A presença de estrutura helicoidal é pergunta aberta, não parâmetro inserido na fonte. [M] Rotação angular não exige transporte líquido ascendente. [D] Os presets exploratórios são explicitamente identificados e nenhum limiar é ajustado aos resultados novos.

[?] Permanecem sem certificação: estrutura física de espiral, equivalência histórica completa, convergência dos presets grandes e dicionário holográfico HRF. Veja LIMITES_DA_INTERPRETACAO.md, relatórios técnicos e os comandos de LEIA_PRIMEIRO.md.
