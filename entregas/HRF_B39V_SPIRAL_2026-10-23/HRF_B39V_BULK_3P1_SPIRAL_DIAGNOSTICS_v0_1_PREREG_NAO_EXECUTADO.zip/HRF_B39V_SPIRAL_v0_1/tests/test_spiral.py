import contextlib,io,json,tempfile,unittest
from pathlib import Path
from copy import deepcopy
from unittest.mock import patch
import numpy as np
from hrf_integral.spiral_config import ROOT,load_config,cases,estimate
from hrf_integral.mesh_adaptive import RectilinearMesh,axes_from_config
from hrf_integral.geometry import ADM
from hrf_integral.spiral_system import SpiralSystem
from hrf_integral.spiral_source import envelope,build_forcing
from hrf_integral.spiral_receivers import catalog
from hrf_integral.phase_analysis import demodulate,azimuthal,axial_phase_fit
from hrf_integral.helicity_metrics import chirality,axial_transport,paired_angular_statistics
from hrf_integral.ridge_tracking import local_peaks,classify_line
from hrf_integral.zscan import arrival_time,slice_centers
from hrf_integral.visualization_3d import isosurface,point_cloud
from hrf_integral.volume_observables import VolumeObserver
from hrf_integral.spiral_storage import FrameStore
from hrf_integral.boundary_angular import ads_cylindrical_mode,angular_projection
from hrf_integral.export_animation import export_frames

class PhaseTests(unittest.TestCase):
    def setUp(self):self.theta=np.arange(64)*2*np.pi/64;self.m=np.arange(-4,5)
    def test_known_m_sign_and_purity(self):
        for m in (-2,-1,0,1,2):
            a=azimuthal(np.exp(1j*m*self.theta),self.theta,self.m);self.assertEqual(int(self.m[np.argmax(a['power_fraction'])]),m);self.assertAlmostEqual(a['power_fraction'].max(),1);self.assertAlmostEqual(float(a['winding']),m)
    def test_vortex_has_no_fake_mean_phase(self):self.assertTrue(np.isnan(azimuthal(np.exp(1j*self.theta),self.theta,self.m)['circular_mean_phase']))
    def test_zero_field_has_no_phase_or_winding(self):
        a=azimuthal(np.zeros(64),self.theta,self.m);self.assertTrue(np.isnan(a['phase']).all());self.assertTrue(np.isnan(a['winding']))
    def test_power_outside_band_not_hidden(self):
        a=azimuthal(np.exp(7j*self.theta)+.01*np.exp(1j*self.theta),self.theta,self.m);self.assertLess(a['power_fraction'].sum(),.001)
    def test_standing_wave_has_no_signed_chirality(self):
        a=azimuthal(np.cos(self.theta),self.theta,self.m);self.assertAlmostEqual(float(chirality(abs(a['coefficients'])**2,self.m)),0,places=13);self.assertLessEqual(a['power_fraction'].max(),.50000001)
    def test_lockin_convention(self):
        t=np.linspace(0,100,1001);real=np.cos(self.theta[None,:]-t[:,None]);z,valid,_=demodulate(real,t,1,2);self.assertTrue(valid.any());self.assertLess(np.max(abs(z[len(t)//2]-np.exp(1j*self.theta))),.005)
    def test_temporal_edges_are_discarded(self):
        t=np.arange(1001)*.1;_,valid,_=demodulate(np.cos(t),t,1);self.assertFalse(valid[0]);self.assertFalse(valid[-1]);self.assertTrue(valid[500])
    def test_short_window_is_not_information(self):
        _,valid,meta=demodulate(np.ones((5,3)),np.arange(5)*.1,1);self.assertFalse(valid.any());self.assertIn('INSUFFICIENT',meta['status'])
    def test_temporal_aliasing_rejected(self):
        with self.assertRaises(ValueError):demodulate(np.ones(10),np.arange(10)*.1,40)
    def test_nonuniform_time_rejected(self):
        with self.assertRaises(ValueError):demodulate(np.ones(4),[0,.1,.2,.25],1)
    def test_known_axial_twist(self):
        z=np.linspace(-10,10,9);fit=axial_phase_fit(z,np.exp(.2j*z));self.assertEqual(fit['status'],'PHASE_TWIST_CANDIDATE');self.assertAlmostEqual(fit['kz'],.2)
    def test_no_twist_control(self):
        fit=axial_phase_fit(np.arange(9),np.ones(9,complex));self.assertEqual(fit['status'],'NO_RESOLVED_LINEAR_TWIST')
    def test_disconnected_phase_not_unwrapped_over_gap(self):
        z=np.arange(9);c=np.exp(.2j*z);c[[2,5]]=0;self.assertEqual(axial_phase_fit(z,c)['status'],'INSUFFICIENT_CONNECTED_Z')
    def test_axial_aliasing_rejected(self):
        z=np.arange(5);self.assertEqual(axial_phase_fit(z,np.exp(2.8j*z))['status'],'POSSIBLE_AXIAL_ALIASING')
    def test_paired_angular_sign_control(self):
        shape=(1,1,1,3);ca=np.zeros(shape,complex);cb=ca.copy();ca[...,2]=1;cb[...,0]=1
        a={'mode_real':ca.real,'mode_imag':ca.imag,'usable_phase_ring':np.ones((1,1,1),bool),'chirality_operational':np.ones((1,1,1)),'orbital_Lz':[1.]};b={'mode_real':cb.real,'mode_imag':cb.imag,'usable_phase_ring':np.ones((1,1,1),bool),'chirality_operational':-np.ones((1,1,1)),'orbital_Lz':[-1.]};s=paired_angular_statistics(a,b,[-1,0,1]);self.assertEqual(s['angular_power_reflection_relative_error'],0);self.assertEqual(s['orbital_sign_flip_relative_error'],0)
    def test_paired_no_phase_stays_inconclusive(self):
        a={'mode_real':np.zeros((1,1,1,3)),'mode_imag':np.zeros((1,1,1,3)),'usable_phase_ring':np.zeros((1,1,1),bool),'orbital_Lz':[0.]};s=paired_angular_statistics(a,a,[-1,0,1]);self.assertIsNone(s['angular_power_reflection_relative_error']);self.assertIn('INSUFFICIENT',s['status'])
    def test_angular_AdS_reference(self):
        a=ads_cylindrical_mode(0,2,0,.5);b=ads_cylindrical_mode(0,2,np.pi/2,.5);self.assertAlmostEqual(abs(b['bulk']/a['bulk']-1j),0);self.assertEqual(a['HRF_gate'],'BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY')
    def test_angular_projection(self):np.testing.assert_allclose(angular_projection(np.exp(1j*self.theta),self.theta,[-1,1]),[0,1],atol=1e-14)

class GeometryAndDetectors(unittest.TestCase):
    def test_graded_affine_gradient_and_volume(self):
        m=RectilinearMesh([[-1,-.1,.2,1],[-1,0,.3,1],[-1,-.2,.1,1]]);q=m.xyz@[2,3,4];g=np.einsum('ta,tai->ti',q[m.tets],m.grad);np.testing.assert_allclose(g,np.broadcast_to([2,3,4],g.shape),atol=1e-13);self.assertAlmostEqual(m.volume.sum(),8)
    def test_graded_receiver_affine_interpolation(self):
        m=RectilinearMesh([[-1,-.1,.2,1],[-1,0,.3,1],[-1,-.2,.1,1]]);p=np.array([[.15,.25,-.1]]);C=m.interpolation(p);np.testing.assert_allclose(C@m.xyz,p);np.testing.assert_allclose(C@np.ones(m.n),1)
    def test_468_and_extra_z_are_preserved(self):
        c=load_config(ROOT/'config/spiral_standard.json');a=catalog(c,[[-130,130],[-130,130],[-25,25]]);self.assertEqual(a['historical_count'],468);self.assertTrue(a['active'][:468].all())
        for z in (-20,-10,-5,5,10,20):self.assertTrue(np.any(np.isclose(a['xyz'][468:,2],z)))
    def test_outside_smoke_receivers_are_explicit(self):
        c=load_config(ROOT/'config/spiral_smoke.json');a=catalog(c,[[-25,25]]*3);self.assertEqual(len(a['active']),len(a['xyz']));self.assertFalse(a['active'][:468].all());self.assertEqual(a['xyz'][:468].shape,(468,3))
    def test_passive_extra_cannot_drive_field(self):
        m=RectilinearMesh([np.linspace(-1,1,3)]*3);s=SpiralSystem(m,ADM(),1,points=[[0,0,0]],reciprocal_mask=[False]);u=np.zeros(2*m.n+2);u[-2]=1;du=s.rhs(0,u);np.testing.assert_array_equal(du[m.n:2*m.n],0);self.assertEqual(s.energy(u),0)
    def test_reciprocal_detector_backreacts(self):
        m=RectilinearMesh([np.linspace(-1,1,3)]*3);s=SpiralSystem(m,ADM(),1,points=[[0,0,0]],reciprocal_mask=[True]);u=np.zeros(2*m.n+2);u[-2]=1;self.assertGreater(np.linalg.norm(s.rhs(0,u)[m.n:2*m.n]),0)
    def test_eulerian_energy_linear_field(self):
        m=RectilinearMesh([np.linspace(-1,1,3)]*3);s=SpiralSystem(m,ADM(),0,boundary='neumann');u=np.r_[m.xyz[:,0],np.zeros(m.n)];a=VolumeObserver(s).evaluate(u);self.assertAlmostEqual(a['total_Eulerian_energy'],4);np.testing.assert_allclose(a['flux'],0)
    def test_operational_orbital_sign(self):
        m=RectilinearMesh([np.linspace(-1,1,5)]*3);s=SpiralSystem(m,ADM(),0,boundary='neumann');u=np.r_[m.xyz[:,0],s.mm*m.xyz[:,1]];self.assertGreater(VolumeObserver(s).evaluate(u)['orbital_Lz_operational'],0)
    def test_source_is_even_in_z(self):
        c=load_config(ROOT/'config/spiral_smoke.json');c['rotation']=1;m=RectilinearMesh([np.linspace(-25,25,13)]*3);s=SpiralSystem(m,ADM(),.2);force,_=build_forcing(s,c);f=force(.2).reshape(m.shape);np.testing.assert_allclose(f,f[:,:,::-1],atol=1e-15)
    def test_pulse_train_and_harmonic_ramp(self):
        s=dict(mode='pulse_train',duration=2.,period=3.,count=2);self.assertAlmostEqual(envelope(1,s),1);self.assertEqual(envelope(2.5,s),0);self.assertAlmostEqual(envelope(4,s),1);self.assertEqual(envelope(7,s),0)
        s=dict(mode='quasi_harmonic',duration=10.,ramp=1.);self.assertEqual(envelope(0,s),0);self.assertEqual(envelope(5,s),1);self.assertEqual(envelope(10,s),0)

class RidgeTransport(unittest.TestCase):
    def setUp(self):self.d=load_config(ROOT/'config/spiral_smoke.json')['diagnostics']
    def test_equal_lobes_are_not_forced_into_ridge(self):
        x=np.linspace(-4,4,17);X,Y=np.meshgrid(x,x,indexing='ij');f=np.exp(-((X-2)**2+Y**2)) -np.exp(-((X+2)**2+Y**2));p=local_peaks(f,x,x);self.assertTrue(p['ambiguous']);self.assertIsNone(p['primary'])
    def test_known_synthetic_helix_is_detected(self):
        z=np.linspace(0,20,41);xy=np.c_[5*np.cos(.4*z),5*np.sin(.4*z)];res=classify_line(z,xy,.1,.1,self.d);self.assertEqual(res['label'],'HELIX_GEOMETRY_CANDIDATE')
    def test_line_is_not_helix(self):
        z=np.linspace(0,20,41);xy=np.c_[np.full(len(z),3.),np.zeros(len(z))];self.assertEqual(classify_line(z,xy,.1,.1,self.d)['label'],'LINE_LIKE')
    def test_symmetric_radiation_not_net_ascent(self):
        z=np.arange(-2,3);E=np.ones((3,5));J=np.broadcast_to(z,(3,5));a=axial_transport(z,E,J);np.testing.assert_allclose(a['net_z_flux_fraction'],0);np.testing.assert_allclose(a['energy_upper_lower_asymmetry'],0);np.testing.assert_allclose(a['outward_z_flux_fraction'],1)
    def test_zero_energy_is_not_evidence_of_no_ascent(self):
        a=axial_transport([-1,0,1],np.zeros((2,3)),np.zeros((2,3)));self.assertTrue(np.isnan(a['net_z_flux_fraction']).all())
    def test_energy_center_parity(self):
        x=np.linspace(-2,2,9);X,Y,Z=np.meshgrid(x,x,x,indexing='ij');e=np.exp(-X*X-Y*Y-Z*Z);_,_,center=slice_centers(e,np.ones_like(e),x,x,x);np.testing.assert_allclose(center,0,atol=1e-14)
    def test_arrival_no_signal_is_missing(self):self.assertIsNone(arrival_time(np.arange(5),np.zeros(5)))
    def test_threshold_arrival_interpolates(self):self.assertAlmostEqual(arrival_time(np.arange(4),[0,0,1,2],.25),1.5)

class IOAndVisualization(unittest.TestCase):
    def test_isosurface_exact_plane(self):
        x=np.linspace(-1,1,5);X,Y,Z=np.meshgrid(x,x,x,indexing='ij');tri,meta=isosurface(X,[x,x,x],.2);self.assertTrue(len(tri));np.testing.assert_allclose(tri[:,:,0],.2,atol=1e-14)
    def test_zero_field_has_no_invented_isosurface(self):
        x=np.arange(3);tri,meta=isosurface(np.zeros((3,3,3)),[x]*3,0);self.assertEqual(len(tri),0);self.assertEqual(meta['status'],'NO_LEVEL_CROSSING')
    def test_point_cloud_cap(self):
        x=np.arange(3);points,values=point_cloud(np.ones((3,3,3)),[x]*3,.5,5);self.assertEqual(points.shape,(5,3))
    def test_frame_store_is_idempotent_and_detects_corruption(self):
        with tempfile.TemporaryDirectory() as td:
            s=FrameStore(td,'x');r=s.write(0,0,0,{'phi':np.zeros(3)},{'xy':np.zeros(3)});s.write(0,0,0,{'phi':np.zeros(3)},{'xy':np.zeros(3)});self.assertEqual(len(s.catalog['frames']),1)
            with self.assertRaises(ValueError):FrameStore(td,'wrong')
            p=Path(td)/r['file'];p.write_bytes(b'corrupted')
            with self.assertRaises(ValueError):FrameStore(td,'x')
    def test_optional_video_missing_is_explicit(self):
        from PIL import Image
        with tempfile.TemporaryDirectory() as td:
            p=Path(td)/'frame_00000.png';Image.new('RGB',(4,4),'white').save(p)
            with patch('hrf_integral.export_animation.shutil.which',return_value=None):status=export_frames([p],Path(td)/'animation',gif=True,mp4=True)
            self.assertEqual(status['mp4'],'BLOCKED_OPTIONAL_FFMPEG_MISSING');self.assertTrue((Path(td)/'animation/slices.gif').exists())
    def test_all_presets_are_explicit_and_parseable(self):
        for p in (ROOT/'config').glob('spiral*.json'):
            c=load_config(p);self.assertTrue(list(cases(c)));self.assertIn('source_resolution_adequate',estimate(c))
    def test_memory_limit_blocks_before_allocation(self):
        c=load_config(ROOT/'config/spiral_standard.json');c['limits']['memory_bytes']=1;self.assertEqual(estimate(c)['status'],'BLOCKED_RESOURCE_LIMIT')
    def test_unlabelled_config_rejected(self):
        c=load_config(ROOT/'config/spiral_standard.json');c['classification']='MATCH_CONFIRMED'
        from hrf_integral.spiral_config import validate
        with self.assertRaises(ValueError):validate(c)
    def test_default_cli_only_plans(self):
        import sys
        from hrf_integral.run import main
        with tempfile.TemporaryDirectory() as td,patch.object(sys,'argv',['run','--config',str(ROOT/'config/spiral_smoke.json'),'--output',td]),patch('hrf_integral.run.run_case',side_effect=AssertionError('solver was called')),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main(),0);self.assertFalse((Path(td)/'execution.json').exists());self.assertEqual(json.loads((Path(td)/'plan.json').read_text())['status'],'PLANNED_NOT_EXECUTED')
