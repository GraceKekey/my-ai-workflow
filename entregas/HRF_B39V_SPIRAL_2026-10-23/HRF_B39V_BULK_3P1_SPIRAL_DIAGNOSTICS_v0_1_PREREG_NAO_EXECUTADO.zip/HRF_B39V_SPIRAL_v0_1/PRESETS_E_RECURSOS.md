# Presets e recursos (planejamento, sem execução)

| Preset | Casos | Nós/caso | Resolução nominal da fonte | Disco bruto total estimado GiB | Estado de recurso |
|---|---:|---:|---|---:|---|
| spiral_controls | 36 | 148137 | True | 136.71 | BLOCKED_RESOURCE_LIMIT |
| spiral_helicity_compare | 2 | 148137 | True | 7.59 | ADMITTED_PLANNING_ONLY |
| spiral_high_info | 2 | 998001 | True | 96.36 | ADMITTED_PLANNING_ONLY |
| spiral_historical_closest | 2 | 20339 | False | 1.14 | ADMITTED_PLANNING_ONLY |
| spiral_smoke | 2 | 2197 | False | 0.08 | ADMITTED_PLANNING_ONLY |
| spiral_standard | 2 | 148137 | True | 7.59 | ADMITTED_PLANNING_ONLY |
| spiral_zscan | 6 | 148137 | True | 34.92 | ADMITTED_PLANNING_ONLY |

[D] Números são estimativas sem alocar as malhas. ADMITTED não significa execução, convergência ou tempo garantido. O sweep controls ultrapassa o limite agregado padrão: selecionar um --case ou alterar conscientemente o limite em uma revisão exploratória.

[D] spiral_historical_closest conserva parâmetros históricos principais e amostra .5, mas troca superfície por volume e tem malha insuficiente. Os demais presets são EXPLORATORY_NOT_HISTORICAL_MATCH; smoke é TECHNICAL_SMOKE_ONLY. Variantes incluem trem de pulsos, quase-harmônico, sigma_z, massa quase nula/intermediária, frequência, largura, amplitude configurável, duas orientações e três contornos. source.amplitude e source.duration são entradas explícitas, não calibração de relés.

[?] A guarda nominal de resolução usa sigmas locais e comprimento de onda de Minkowski. Em geometria deformada ela é necessária e não certifica resolução em todo o bulk. O caso registra também a guarda espectral dos frames após construir o operador.
