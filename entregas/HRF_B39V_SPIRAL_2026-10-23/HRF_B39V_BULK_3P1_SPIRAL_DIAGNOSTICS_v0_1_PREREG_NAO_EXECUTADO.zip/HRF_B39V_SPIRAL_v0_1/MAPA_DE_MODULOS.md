# Módulos implementados

| Módulo | Função efetiva |
|---|---|
| run.py / spiral_storage.py | CLI, preflight, integração derivada RK4, frames volumétricos/cortes, checkpoint e retomada |
| mesh_adaptive.py | grade retangular uniforme ou graduada com FEM P1 e interpolação de sondas |
| spiral_system.py | núcleo histórico recíproco mais sondas extras passivas, energia com escopo explícito |
| spiral_source.py / spiral_geometry.py | pulso, quase-harmônico, trem, perfis em z; fundo plano/grafo histórico/grafo analítico |
| volume_observables.py | energia Euleriana, corrente local, carga orbital operacional, projeção nodal |
| phase_analysis.py | lock-in de fase, amplitude, média circular, harmônicos, winding e ajuste axial |
| helicity_metrics.py / zscan.py | quiralidade operacional, torção por hemisfério, energia/fluxo em z, chegadas e centros |
| ridge_tracking.py | máximos locais, degenerescências, linha de crista e classificações descritivas |
| spiral_diagnostics.py | JSON/CSV/NPZ, diagramas raio×tempo, ângulo×z e mapas de fase por altura |
| visualization_3d.py / plot3d.py | marching tetrahedra NumPy, superfícies±/absoluta, nuvem, cortes, figuras A–G e escala pareada |
| export_animation.py / export_data.py | PNG/GIF/MP4 opcional; dados volumétricos, fase e diagnósticos em CSV/JSON/NPZ |
| spiral_report.py | três relatórios automáticos com [M]/[H]/[?]/[D] |
| boundary_angular.py | harmônicos e modo angular livre de referência AdS4, sem identidade HRF |

[D] Arquivos integrais originais permanecem em reference/base_integral_source/ e no pacote anterior intacto. Seus comandos antigos não são a entrada da nova bancada. Hashes de todos os arquivos grandes históricos são preservados por proveniência; não são dependência desta camada.
