# Alterações da derivação

[D] Novo diretório e nova versão; nenhuma edição na entrega integral anterior. Cópias do núcleo/original e hashes preservados. A fonte dipolar não recebe k_z ou trajetória helicoidal.

[M] Acrescentadas grade graduada, frames completos, sondas extras passivas, observáveis e módulo de fase/visualização/exportação. Os presets exploratórios mudam escalas para obter dados resolvidos, e não recebem identidade histórica. No preset próximo do histórico, rede/relés mantêm regras herdadas e o diagnóstico informa falta de resolução.

[D] Correções identificadas antes do smoke: converter fluxos inteiros para float em frações de transporte; promover entradas de fase real para complexo para evitar warning de casting; amostrar frames na mesma malha temporal racional até o último instante; normalizar potência modal pela potência total do anel; excluir resposta de sondas passivas da energia fechada e da realimentação da PDE. Log do primeiro teste e sua falha de dtype preservado em reports/unit_tests_initial.log. Critérios científicos não foram ajustados para obter sucesso.
