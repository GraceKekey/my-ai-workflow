# Protocolo congelado proposto — HRF-HOLO-B39V-01
Data 2026-10-22 | Versão 0.1 | Status NÃO EXECUTADO

## Pergunta e hipóteses
- [H01] Em referência controlada com bulk espacial de AdS4 deformado radialmente, entropias RT de faixas em boundary 2D identificam os parâmetros do ansatz sob regularização e erro especificados.
- [H02] Uma boundary 2+1 do HRF, **se** possuir dicionário holográfico explicitado, permite prever observáveis de bulk 3+1 não usados no ajuste.
- [H03] Uma interface física independente B39V→bulk relaciona atrasos, foco, sombra e estrutura causal sem ajustes a posteriori.
- [H04] DIO→GMFt permanece hipótese distinta, não inferida de RT ou amplitude de receptor.

## Interfaces e dimensões
- B39V = superfície espacial 2D imersa em R3 (chamada 2,5D); campo scalar KG em geometria imposta, osciladores receptores; **não é boundary CFT3 demonstrada**.
- Boundary holográfica candidata = (2+1) dimensões; bulk = (3+1) dimensões.
- A coordenada de altura do vale B39V NÃO é a coordenada radial holográfica z.
- G geometria, W ondas, D dicionário boundary↔bulk são três interfaces independentes. D atualmente AUSENTE.

## Etapa 01A: referência controlada (única implementada em código)
Métrica espacial ansatz: ds² = (L²/z²)[dz² + exp(2u(z))(dx²+dy²)] com u(z)=a(z/zscale)^2 exp(-z/zscale) + b(z/zscale)^4 exp(-z/zscale).
Escolher faixas infinitas de largura ell em x e comprimento transversal Ly; em cada faixa extrair área extrema regularizada com cutoff epsilon.
Calcular S_RT=A/(4 G_N) para referência sintética, com L, G_N conhecidos. Ajustar a,b no conjunto train; reservar larguras test sem acesso pelo ajuste. A hipótese de equivalência RT é inserida apenas como gerador de dados de referência.

## Gates e controles PRÉ-REGISTRADOS
- G0 integridade: parâmetros, bibliografia e proveniência completos; ausência de resultados pré-gerados.
- G1 solver: para u=0, largura numérica deve concordar com largura analítica de tira AdS4 em erro relativo < 2e-3; se solver falhar, `FAIL_NUMERIC`.
- G2 inversão sintética: erro RMS relativo test < 2e-2 **e** |a_fit-a_true|, |b_fit-b_true| < 0.03 (limites em unidades do ansatz). Rodadas sem identificação inequívoca são INCONCLUSIVE.
- G3 independência: não usar geometrias B39V para gerar ou ajustar entropias. Se usar, `FAIL_LEAKAGE`.
- G4 boundary física: exigir sistema quântico, estado, álgebra de regiões, entropia real/renormalizada, regime holográfico e validação não trivial de RT. Até lá `BLOCKED_NO_DICTIONARY`.
- G5 bulk temporal: exigir componentes temporais da métrica, correladores causais, validade de HKLL ou outra reconstrução e testes holdout. Até lá `BLOCKED_NO_TEMPORAL_MAP`.
- G6 B39V: exigir mapa físico explicitado para observáveis de propagação, geometria, fonte e detector; testar velocidades de frente e grupo separadamente. Até lá `BLOCKED_NO_B39V_MAP`.
- G7 DIO/GMFt: exigir testemunha pré-estímulo independente, decodificação lógica versus ressonância, conservação e não-clonagem. Até lá `NOT_TESTED`.
- Qualquer resultado aprovado no G2 deve carregar o rótulo `PASS_SYNTHETIC_ONLY`, jamais `HOLOGRAPHY_VERIFIED`.

## Controle adversarial e limitações
1. Vácuo AdS sem deformação (a=b=0).
2. Deformações radialmente diferentes e faixa de larguras insuficiente; reportar incerteza/degenerescência.
3. Variação de cutoff epsilon, tolerâncias e ruído: sensibilidade.
4. Holdouts em largura; não reutilizar dados de treino.
5. Erros de gauge, regularização de entropia, fatoração de Hilbert em teorias gauge.
6. Não concluir métrica Lorentziana completa a partir de dados RT estáticos.
7. Não confundir igualdade de áreas com consistência gravitacional de Einstein.
8. Um modelo espacial radialmente homogêneo não representa os vales localizados da B39V; etapas 2D não homogêneas são FUTURAS e sem implementação no pacote.

## Interpretação por classe
[F] Fórmulas RT/HRT/HKLL em seus domínios estabelecidos. [M] Ajustes sintéticos do algoritmo (se executados). [H] Correspondência HRF a uma teoria holográfica. [?] Dual, causalidade, extensão 2D não homogênea, DIO/GMFt. [D] Executar apenas fase 01A quando autorizado; 01B bloqueada sem dados apropriados.

Nenhum código ou teste foi executado durante a preparação deste pacote.
