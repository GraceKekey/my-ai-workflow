# Resultados HRF-HOLO-B39V-01

Relatório: HRF_HOLO_B39V_01_RELATORIO_2026-10-22_212335.md

01A: PASS_SYNTHETIC_ONLY.
01B: BLOCKED_NO_DICTIONARY.

Arquivos originais com NOT_EXECUTED são históricos. Resultados da execução estão em results/.
