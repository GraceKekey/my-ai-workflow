# Referências e proveniência (seleção, NÃO auditoria matemática integral)
- Fonte interna: HRF_Caderno_Pesquisa_Bibliografica_v0_9 (CP-10, 14/10/2026), Google Drive: https://docs.google.com/document/d/1mssktGZZ51_ZB3L5unrq2CISVBLc2AV0BRIWRXgcglQ/edit
- Fonte normativa: HRF Research Book, Capítulo 0.1 RUP v0.1; Research Book, Capítulo 3 v0.2; Nota HRF boundary 2D/GMF/bulk 3D.
- [HRF-REF-0013] Ryu & Takayanagi (2006), Phys Rev Lett 96 181602, DOI 10.1103/PhysRevLett.96.181602 — RT.
- [HRF-REF-0014] Hubeny, Rangamani & Takayanagi (2007), JHEP 07 062, DOI 10.1088/1126-6708/2007/07/062 — HRT.
- [HRF-REF-0049] Hamilton, Kabat, Lifschytz & Lowe (2006), Phys Rev D 74 066009, DOI 10.1103/PhysRevD.74.066009 — reconstrução de campos.
- [HRF-REF-0046] Jokela et al. (2025), Bulk metric reconstruction from entanglement data via minimal surface area variations — referência de inversão de métrica; nosso código NÃO implementa esse algoritmo publicado.
- [HRF-REF-0061] Czech, Dong & Sully (2014), JHEP 11 015, DOI 10.1007/JHEP11(2014)015 — superfícies em dimensão geral.
- Engelhardt & Horowitz (2017), Towards a Reconstruction of General Bulk Metrics, Class Quantum Grav 34 015004 — cortes de cones de luz.
- [HRF-REF-0055] Tjoa & Gray (2022), Phys Rev D 106 025021 — campos e geometria assintoticamente planos.
- Ji-Seong Chae (2026), Covariant holographic entanglement entropy inversion to reconstruct bulk geometry, JHEP 09 (2026) 251 — inversão covariante, fora do presente escopo numérico.

Esta implementação demonstrativa restringe-se a otimização de um ansatz métrico radial; não implementa nem certifica provas de RT/HRT/HKLL, nem reproduz algoritmos específicos dos artigos acima.
