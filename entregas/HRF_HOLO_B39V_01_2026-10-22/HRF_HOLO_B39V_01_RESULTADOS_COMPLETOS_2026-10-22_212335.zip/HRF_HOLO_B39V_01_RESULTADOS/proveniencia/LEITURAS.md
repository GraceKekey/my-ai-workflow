Fonte normativa lida integralmente: HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_1_PT_2026-10-08(1).md.
Fonte principal: HRF_Research_Book_Cap03_Base_Quantica_Compartilhada_DIO_e_GMFt_v0_2_PT_2026-10-22.md.
Dados anteriores B39V: 4 pacotes, não redistribuídos, ver arquivos_manifesto.json.
Caderno bibliográfico: HRF_Caderno_Pesquisa_Bibliografica_v0_9_2026-10-14_1309 (Drive, CP-10, 83 refs).
Não há novo solver HRT, HKLL ou B39V; tais módulos são FUTUROS, não foram simulados nem validados.
