import pathlib,json,hashlib,zipfile,datetime,platform,sys
from zoneinfo import ZoneInfo
import numpy,scipy
P=pathlib.Path(__file__).resolve().parents[1]
m=json.loads((P/'results/benchmark/metrics.json').read_text());e=json.loads((P/'results/eligibility/eligibility.json').read_text())
assert m['gate']=='PASS_SYNTHETIC_ONLY'and e['status']=='BLOCKED_NO_DICTIONARY'
stamp=datetime.datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%d_%H%M%S')
(P/'auditoria/ambiente.json').write_text(json.dumps(dict(python=platform.python_version(),executavel=sys.executable,numpy=numpy.__version__,scipy=scipy.__version__,plataforma=platform.platform(),threads_BLAS_OMP_MKL=1,requisitos_satisfeitos=True,comandos=['python3 -m hrf_holo.cli benchmark --config config/benchmark.json --out results/benchmark','python3 -m hrf_holo.cli eligibility --config config/b39v_interface.json --out results/eligibility'],exit_codes=dict(benchmark=0,eligibility=0)),indent=2))
report=P/f'HRF_HOLO_B39V_01_RELATORIO_{stamp}.md'
report.write_text(f'''# HRF-HOLO-B39V-01 — Relatório da execução

Data: {stamp} (America/Sao_Paulo). Autor HRF: Mario José do Canto Filho, MD. Execução: Codex.

## Objetivo
[M] Executar a referência sintética 01A: recuperar dois parâmetros de uma métrica espacial radial por áreas RT de tiras. Verificar a admissibilidade da interface 01B com B39V.

## Hipóteses
[H] A recuperação em dados sintéticos é uma validação restrita do algoritmo. A correspondência de uma boundary HRF com bulk físico exige um dicionário independente que o pacote declara ausente.

## Parâmetros
[M] L=G_N=z_scale=length_y=1; cutoff=0,01. Verdade a=0,14, b=−0,04; início (0,0); oito larguras de treino e cinco de teste disjuntas. Tolerância 1e−8, máximo 250 avaliações, limites dos parâmetros ±0,6. Configurações originais preservadas.

## Protocolo
[D] Autorização: “Oi pode rodar por favor”. Foram conferidos os 11 hashes antes e depois. Executados os dois comandos do LEIA_PRIMEIRO usando o ambiente Python existente, cujas versões satisfazem requirements.txt, com BLAS/OMP/MKL limitados a uma thread. Ambos encerraram com código zero. Nenhuma fonte, configuração, tolerância ou resultado foi retocado.
[M] eligibility é somente um avaliador de admissibilidade: não executa a reconstrução física 01B. Os arquivos originais STATUS.json e configurações com rótulo NOT_EXECUTED são registros históricos congelados; os resultados desta execução estão em results/.

## Medidas e resultados
[D] Benchmark: **{m['gate']}**.

- a ajustado: {m['a_fitted']:.16g}; b ajustado: {m['b_fitted']:.16g}.
- Erro máximo nos parâmetros: {m['max_parameter_error']:.8g} (limite 0,03).
- RMS relativo de teste na diferença de entropia: {m['holdout_rms_relative_on_delta_entropy']:.8g} (limite 0,02; denominador com piso 0,01).
- Erro relativo da largura do vácuo: {m['vacuum_width_relative_error']:.8g} (limite 0,002).
- least_squares convergiu em {m['nfev']} avaliações.

[D] Interface B39V: **{e['status']}**. Requisitos ausentes:

'''+''.join('- '+x+'\n'for x in e['missing'])+'''
## Controles e limitações
[M] O código executa um caso sintético sem ruído, no mesmo ansatz do gerador, uma referência de vácuo e holdouts em largura. Não utiliza dados B39V como entropias. A recuperação pequena de erro indica consistência dessa inversão controlada.
[?] O pacote não implementa uma campanha de cutoff/tolerâncias/ruído, deformações alternativas, múltiplos inícios ou estimativa de incerteza/degenerescência. Esses controles aparecem como recomendações no protocolo, mas não foram produzidos pelos comandos implementados; o PASS do programa não os certifica. Não foram acrescentadas variações após conhecer os resultados.
[M] O programa grava métricas agregadas, não séries de áreas/entropias por largura ou a trajetória do ajuste. Foram preservadas exatamente as saídas disponíveis; sua reprodução depende do código e das configurações incluídos. Nenhum dado por largura foi inventado ou reconstruído posteriormente.

## Interpretação
[D] PASS_SYNTHETIC_ONLY não equivale a HOLOGRAPHY_VERIFIED. O vínculo RT foi inserido como gerador de dados sintéticos. Não foram demonstrados CFT3 físico, bulk Lorentziano 3+1, gravidade dinâmica, holografia HRF ou DIO/GMFt.
[?] A fase 01B permanece bloqueada por dados/dicionário físico ausentes; a altura do vale B39V não foi identificada com a coordenada radial holográfica.

## Arquivos
Pacote autocontido com entrada original, código/protocolo/configurações intactos, métricas e elegibilidade JSON, logs, ambiente e manifestos antes/depois. A proveniência das quatro partes B39V foi preservada como fornecida; não houve cópia ou reinterpretação desses dados.
''')
(P/'RESULTADOS_LEIA_PRIMEIRO.md').write_text(f'# Resultados HRF-HOLO-B39V-01\n\nRelatório: {report.name}\n\n01A: PASS_SYNTHETIC_ONLY.\n01B: BLOCKED_NO_DICTIONARY.\n\nArquivos originais com NOT_EXECUTED são históricos. Resultados da execução estão em results/.\n')
files=[p for p in sorted(P.rglob('*'))if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256_RESULTADOS.txt']
(P/'MANIFEST_SHA256_RESULTADOS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(P).as_posix()+'\n'for p in files))
archive=pathlib.Path('/workspace')/f'HRF_HOLO_B39V_01_RESULTADOS_COMPLETOS_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts:z.write(p,pathlib.Path('HRF_HOLO_B39V_01_RESULTADOS')/p.relative_to(P))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
r=dict(archive=str(archive),report=str(report),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)
pathlib.Path('/workspace/HRF_HOLO_B39V_01_ENTREGA_LOCAL.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
