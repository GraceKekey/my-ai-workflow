# HRF-HOLO-B39V-01 — PACOTE DE PRÉ-REGISTRO (NÃO EXECUTADO)

**Estado:** PROPOSTO / NÃO EXECUTADO. **Data:** 2026-10-22. **Método:** RUP B → A. Nenhum resultado novo foi produzido.

## O que este pacote faz

- Define formalmente duas fases: 01A (inversão RT controlada em fatia espacial AdS4) e 01B (interface temporal/HKLL/B39V, bloqueada).
- Inclui executável 01A **exclusivamente para dados sintéticos de referência** de uma classe radial homogênea. O código gera dados de áreas do próprio ansatz e recupera parâmetros previamente ocultados ao solver. Isso é validação de algoritmo, NÃO prova de dualidade holográfica de qualquer boundary HRF.
- Inclui avaliador de admissibilidade 01B: impede uso de dados B39V como entropias de emaranhamento; sem dicionário, 01B permanece BLOCKED.
- Relatórios e quatro ZIPs originais B39V **não foram copiados** para evitar inflação e alteração da proveniência; seus nomes/hashes constam em `proveniencia/`.

## Execução externa, somente quando autorizada

```
python -m venv .venv
.venv/bin/pip install -r requirements.txt
.venv/bin/python -m hrf_holo.cli benchmark --config config/benchmark.json --out results/benchmark
.venv/bin/python -m hrf_holo.cli eligibility --config config/b39v_interface.json --out results/eligibility
```

No Windows use `.venv\Scripts\python` e `.venv\Scripts\pip`.

As dependências devem ser obtidas num ambiente externo com acesso à internet. Não foi feita execução dos comandos acima. O pacote não contém dados sintéticos pré-calculados.

**Padrão anti-extrapolação:** PASS em sintético não é PASS em AdS/CFT real, DIO/GMFt, B39V, gravidade dinâmica ou bulk emergente.
