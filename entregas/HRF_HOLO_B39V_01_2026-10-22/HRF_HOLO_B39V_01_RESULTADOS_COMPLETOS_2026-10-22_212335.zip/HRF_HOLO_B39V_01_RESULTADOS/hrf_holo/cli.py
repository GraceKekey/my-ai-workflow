"""Controlled AdS4 strip RT toy reference. No B39V reconstruction is implemented."""
import argparse, json
from pathlib import Path
import numpy as np
from scipy.integrate import quad
from scipy.optimize import brentq, least_squares

def metric(z, a, b, scale, L):
    u=(a*(z/scale)**2+b*(z/scale)**4)*np.exp(-z/scale)
    gx=(L/z)**2*np.exp(2*u)
    gz=(L/z)**2
    return float(gx),float(gz)

def strip(zstar, params, cfg):
    """Area of two branches and strip width via first integral of minimal surface.
    Coordinates: x(z), y longitudinal. Assumes gxx=gyy and gzz as in protocol.
    """
    L=cfg['L'];eps=cfg['cutoff'];scale=cfg['z_scale'];Ly=cfg['length_y']
    if zstar <= 1.001*eps:raise ValueError('turning point too close to cutoff')
    gxstar,_=metric(zstar,*params,scale,L);p=gxstar
    # z= zstar*(1-t*t), endpoint t=0 regularizes square-root turning singularity.
    tmax=np.sqrt(1-eps/zstar)
    def vals(t):
        if t==0:t=1e-10
        z=zstar*(1-t*t)
        gx,gz=metric(z,*params,scale,L)
        ratio=(p/gx)**2
        den=np.sqrt(max(1-ratio,1e-30))
        jac=2*zstar*t
        xprime=(p/gx)*np.sqrt(gz/gx)/den
        aprime=np.sqrt(gx*gz)/den
        return jac*xprime,jac*aprime
    width=2*quad(lambda t:vals(t)[0],0,tmax,epsabs=1e-9,epsrel=1e-8,limit=160)[0]
    area=2*Ly*quad(lambda t:vals(t)[1],0,tmax,epsabs=1e-7,epsrel=1e-8,limit=160)[0]
    return width,area

def area_at_width(w,pars,cfg):
    eps=cfg['cutoff']
    def f(z):return strip(z,pars,cfg)[0]-w
    lo=eps*1.005;hi=max(w*3,eps*10)
    for _ in range(16):
        if f(hi)>0:break
        hi*=1.7
    else:raise ValueError('width not bracketed')
    zstar=brentq(f,lo,hi,xtol=1e-10)
    width,area=strip(zstar,pars,cfg)
    return area/(4*cfg['G_N']),zstar

def run_benchmark(cfg,out):
    true=(cfg['true']['a'],cfg['true']['b'])
    train=np.array(cfg['train_widths']);test=np.array(cfg['test_widths'])
    if len(set(train).intersection(set(test))):raise ValueError('LEAKAGE overlapping train/test')
    def calc(ws,params):return np.array([area_at_width(float(w),params,cfg)[0] for w in ws])
    ytrain=calc(train,true);ytest=calc(test,true)
    # vacuum (a=b=0) analytic strip width = 2*zstar*sqrt(pi)*Gamma(3/4)/Gamma(1/4)
    from scipy.special import gamma
    z0=0.5
    w0=strip(z0,(0.,0.),cfg)[0]
    # cutoff-dependent integral analytic via scipy beta integral over [epsilon/zstar,1]
    v=cfg['cutoff']/z0
    wanalytic=2*z0*quad(lambda q:q*q/np.sqrt(1-q**4),v,1,epsabs=1e-11)[0]
    vacuum_relative=abs(w0-wanalytic)/max(abs(wanalytic),1e-12)
    # Use subtraction of pure AdS reference at each width for numerical conditioning.
    vac_train=calc(train,(0.,0.));vac_test=calc(test,(0.,0.))
    delta_train=ytrain-vac_train;delta_test=ytest-vac_test
    def residual(p):return (calc(train,p)-vac_train-delta_train)
    sol=least_squares(residual,[cfg['initial']['a'],cfg['initial']['b']],bounds=([-0.6,-0.6],[0.6,0.6]),max_nfev=cfg['max_evaluations'],xtol=cfg['tolerance'],ftol=cfg['tolerance'],gtol=cfg['tolerance'])
    pred=calc(test,sol.x)-vac_test
    rmsrel=float(np.sqrt(np.mean(((pred-delta_test)/np.maximum(np.abs(delta_test),0.01))**2)))
    params_err=float(np.max(np.abs(sol.x-np.array(true))))
    gate='PASS_SYNTHETIC_ONLY' if (vacuum_relative<2e-3 and rmsrel<.02 and params_err<.03 and sol.success) else 'FAIL_OR_INCONCLUSIVE'
    result={'gate':gate,'scope':'controlled synthetic AdS4 radial strip reference ONLY', 'nonclaims':['No B39V reconstruction','No real CFT3 tested','No Lorentzian 3+1 bulk demonstrated','No DIO/GMFt tested'], 'a_true':true[0],'b_true':true[1],'a_fitted':float(sol.x[0]),'b_fitted':float(sol.x[1]),'holdout_rms_relative_on_delta_entropy':rmsrel,'max_parameter_error':params_err,'vacuum_width_relative_error':vacuum_relative,'train_widths':train.tolist(),'test_widths':test.tolist(),'least_squares_success':bool(sol.success),'nfev':int(sol.nfev)}
    out.mkdir(parents=True,exist_ok=True)
    (out/'metrics.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

def eligibility(cfg,out):
    need=['is_boundary_2plus1_cft','boundary_state_specified','entanglement_entropies_provided','operator_dictionary_specified','bulk_temporal_metric_recovered','independent_observable_mapping']
    missing=[k for k in need if not cfg.get(k,False)]
    result={'status':'BLOCKED_NO_DICTIONARY' if missing else 'REVIEW_REQUIRED_NOT_AUTOMATICALLY_AUTHORIZED','missing':missing,'notice':'B39V arrival times, areas, amplitude and thresholds are not RT entanglement entropies.'}
    out.mkdir(parents=True,exist_ok=True)
    (out/'eligibility.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
    print(json.dumps(result,indent=2))

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['benchmark','eligibility']);ap.add_argument('--config',required=True);ap.add_argument('--out',required=True)
    a=ap.parse_args();cfg=json.loads(Path(a.config).read_text(encoding='utf-8'))
    (run_benchmark if a.mode=='benchmark' else eligibility)(cfg,Path(a.out))
if __name__=='__main__':main()
