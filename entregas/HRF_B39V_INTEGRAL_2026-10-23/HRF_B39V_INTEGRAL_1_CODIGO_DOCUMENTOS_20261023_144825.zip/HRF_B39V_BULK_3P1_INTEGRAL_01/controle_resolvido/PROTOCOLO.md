# Controle volumétrico com fonte resolvida — suplemento independente

[D] O domínio histórico coarse não resolve σ=1.5. Este teste adicional é registrado antes de obter seus resultados para verificar propagação 3D com fonte resolvida, sem substituir o domínio histórico de 468 casas.

[M] Caixa [-12,12]^3, n=49 (dx=.5), massa1.6, Ω1.85, F=.02, σxy=1.5, σz=3.0, pulso sin² de duração12, t_end=60, dt=.04, amostra=.2. 24 receptores em anéis de raios3/6 e três planos z=-2/0/2, quatro azimutes por anel/plano =24. G=.05, γ_R=.1. Sem rede estacionária neste controle; medir campo e resposta da mensagem. Esponja .5 com Dirichlet externo. Fonte resolvida por 3 células/σ e comprimento de onda por >12 células.

[D] Casos: plano±; um vale conforme amp=.08 centro(2,0),σ3; dois vales adicionando centro(-2,3),amp=.05,σ2; lapso .05 no vale; plano n=65 (dx=.375) para refinamento; plano caixa[-16,16]^3 n=65 (mesmo dx=.5) para contorno. Perfis são escolhas controladas, não alturas históricas. Rotação± e refinamento conservam todos os outros parâmetros.

[D] Gates: todos os 24 receptores devem registrar pico de |campo|>1e-8 e pico de leitura seletiva>1e-12 nos dois planos; erro relativo L2 do vetor de picos entre grades49/65≤.1; mudança de picos por caixa≤.1; erro de reflexão (y→-y) entre rotações≤.05. Registrar FAIL sem ajustar se não atendidos. Diferenças de vale/lapso são observáveis descritivos; sem sinal obrigatório. Curvas gaussianas não definem frente causal compacta. Gate PASS_NUMERICAL apenas deste controle; nenhum PASS_B39V_TRANSFER.
