from pathlib import Path
import sys,json,hashlib,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from hrf_integral.fem import Mesh
from hrf_integral.geometry import ADM
from hrf_integral.dynamics import System,integrate
from hrf_integral.history import load
from hrf_integral.io import atomic_json,atomic_npz,digest,fingerprint
root=Path(__file__).resolve().parent
for line in (root/'hashes_antes.txt').read_text().splitlines():
 sha,p=line.split('  ',1)
 if digest(root/p)!=sha:raise RuntimeError('SUPPLEMENT_HASH_MISMATCH')
points=np.array([[r*np.cos(a),r*np.sin(a),z] for r in (3.,6.) for z in (-2.,0.,2.) for a in (0.,np.pi/2,np.pi,3*np.pi/2)])
cases=[('flat_plus',49,12.,1,[],0.),('flat_minus',49,12.,-1,[],0.),('valley',49,12.,1,[(2.,0.,.08,3.)],0.),('two_valleys',49,12.,1,[(2.,0.,.08,3.),(-2.,3.,.05,2.)],0.),('lapse',49,12.,1,[(2.,0.,.08,3.)],.05),('refined',65,12.,1,[],0.),('boundary',65,16.,1,[],0.)]
all_res={};rl=load('b39_rele')
for name,n,box,rot,valleys,depth in cases:
 folder=root/name;folder.mkdir(exist_ok=True);dest=folder/'metrics.json'
 if dest.exists():
  got=json.loads(dest.read_text())
  if got['signals_sha256']!=digest(folder/'signals.npz'):raise ValueError('data changed')
  all_res[name]=got;print(json.dumps({'id':name,'status':'REUSED_VERIFIED'}),flush=True);continue
 beg=time.monotonic();mesh=Mesh([[-box,box]]*3,[n]*3);sysm=System(mesh,ADM(valleys=valleys,lapse_depth=depth),1.6,points=points,omega=1.85,coupling=.05,gamma_r=.1,boundary='sponge')
 dip=sysm.source(1.5,3.)
 def force(t):
  e=np.sin(np.pi*t/12)**2 if 0<t<12 else 0.
  return .02*e*(dip[:,0]*np.cos(1.85*t)+rot*dip[:,1]*np.sin(1.85*t))
 d=integrate(sysm,60.,.04,forcing=force,sample=.2,checkpoint=folder/'checkpoint.npz',run_id=fingerprint([name,n,box,rot,valleys,depth]))
 R=rl.leitura(d['ts'],d['X'],d['P'],np.full(len(points),1.85));pk=R.max(axis=0);field=np.max(np.abs(d['field']),axis=0)
 atomic_npz(folder/'signals.npz',ts=d['ts'],field=d['field'],X=d['X'],P=d['P'],R=R,energy=d['energy'],power=d['power'],points=points)
 got=dict(id=name,status='EXECUTED',seconds=time.monotonic()-beg,n=n,box=box,dx=2*box/(n-1),rotation=rot,field_peak=field,response_peak=pk,field_detected=int(np.sum(field>1e-8)),response_detected=int(np.sum(pk>1e-12)),signals_sha256=digest(folder/'signals.npz'))
 atomic_json(dest,got);all_res[name]=json.loads(dest.read_text());(folder/'checkpoint.npz').unlink(missing_ok=True);print(json.dumps({'id':name,'seconds':got['seconds'],'field_detected':got['field_detected'],'response_detected':got['response_detected']}),flush=True)
base=np.array(all_res['flat_plus']['response_peak']);minus=np.array(all_res['flat_minus']['response_peak']);idx=[int(np.argmin(np.linalg.norm(points-[x,-y,z],axis=1))) for x,y,z in points]
rel=lambda a:float(np.linalg.norm(np.asarray(a)-base)/np.linalg.norm(base))
metrics=dict(parity_relative_error=rel(minus[idx]),spatial_refinement_relative_error=rel(all_res['refined']['response_peak']),boundary_relative_error=rel(all_res['boundary']['response_peak']))
checks={k:v<=limit for k,v,limit in [(k,metrics[k],.05 if k=='parity_relative_error' else .1) for k in metrics]}
checks['all_receivers_detected']=all(all_res[n]['field_detected']==24 and all_res[n]['response_detected']==24 for n in ('flat_plus','flat_minus'))
res=dict(gate='PASS_NUMERICAL' if all(checks.values()) else 'FAIL',checks=checks,metrics=metrics,cases=all_res,scope='compact resolved-source 3D reference; not complete historical transfer')
atomic_json(root/'summary.json',res);print(json.dumps({'gate':res['gate'],'checks':checks,'metrics':metrics}),flush=True)
