# Reproduzir a execução integral

[D] Instale requirements.txt e mantenha BLAS em uma thread. Na raiz extraída, execute:

```bash
python3 -I scripts/run.py all --preset standard
python3 -I scripts/run.py scenarios --preset smoke
python3 -I scripts/run.py scenarios --preset high_resolution
python3 -I suplementos/testar_ADM.py
python3 -I controle_resolvido/run.py
python3 -I scripts/run.py report
python3 -I reanalise/corrigir_comparacoes.py
python3 -I scripts/consolidar.py
```

[D] No Windows use python ou o caminho do venv. Os mesmos comandos funcionam; scripts/run_windows.ps1 executa a rodada principal e scripts/rodar_tudo_windows.ps1 acrescenta os suplementos e a consolidação. Não execute scripts/freeze.py sobre um freeze existente. Use pasta de saída nova para experimentos com parâmetros modificados e rotule-os fora deste pré-registro.

O primeiro ZIP guarda a fotografia de pré-registro com o nome solicitado dentro de preregistro/. Ela contém código e documentação anterior aos resultados novos; os dados históricos e resultados integrais são fornecidos pelos outros membros da distribuição. Extraia todas as partes ZIP independentes na mesma pasta e confira MANIFEST_SHA256.txt. A raiz única contém todos os dados necessários; não depende de links ao repositório.
