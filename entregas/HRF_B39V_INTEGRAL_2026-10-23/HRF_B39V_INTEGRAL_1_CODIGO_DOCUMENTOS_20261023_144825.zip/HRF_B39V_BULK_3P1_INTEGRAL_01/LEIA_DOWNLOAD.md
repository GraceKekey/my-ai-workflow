# Entrega integral com execução autorizada

Extraia TODAS as partes ZIP independentes na mesma pasta. Elas compartilham a raiz HRF_B39V_BULK_3P1_INTEGRAL_01. Não é necessário concatenar arquivos.

1. Código e documentos: fonte completa, protocolos, dicionário recebido, dependências, scripts, logs, relatórios, tabelas e fotografia de pré-registro solicitada em preregistro/.
2. Resultados novos: sinais das simulações e controles desta rodada.
3–4. Histórico: dados brutos originais preservados, complementando as fontes e entradas arquivadas na parte1.

Comece por resultados/RELATORIO_CONSOLIDADO.md e resultados/RESUMO_INTEGRAL.json. O registro de todos os testes está em resultados/REGISTRO_DE_TODOS_OS_TESTES.csv. São 35 simulações executadas, 32 testes de software aprovados e controles numéricos/referências AdS aprovados no escopo especificado. Os 26 cenários de alta resolução não foram executados por memória estimada ~85 GiB contra 32 GiB da máquina. Não há PASS de transferência histórica nem de holografia física HRF. HRT e QES não têm implementação efetiva.

A correção de incremento do teste unitário inicial está em EMENDAS.md. A correção pós-execução do observável descritivo de sombra está em reanalise/ERRATA.md, com análise original preservada; nenhum veredito científico foi promovido. A fonte estreita e o readout histórico não estão certificados na grade coarse.

Confira MANIFEST_SHA256.txt depois de extrair todas as partes. O pacote é autocontido e não precisa acessar o repositório para rodar. COMO_REPRODUZIR_TUDO.md descreve a instalação e os comandos.
