import unittest,tempfile
from pathlib import Path
import numpy as np
from hrf_integral.geometry import ADM
from hrf_integral.fem import Mesh,estimate_resources
from hrf_integral.dynamics import System,integrate,rk4
from hrf_integral.history import load,ROOT
from hrf_integral.holography import mass_dimension,gaussian_entropy
from hrf_integral.dictionary import fg_g2,euclidean_kernel
from hrf_integral.gates import transfer,reconstruction
from hrf_integral.io import atomic_json,atomic_npz,fingerprint

class Algebra(unittest.TestCase):
    def test_ADM_inverse_determinant_shift(self):
        a=ADM(shift=(.2,.1,0));e=[0,1,2,3];np.testing.assert_allclose(a.metric(e)@a.inverse(e),np.eye(4),atol=1e-14);self.assertAlmostEqual(a.determinant(e),-1)
    def test_AdS_inverse(self):
        a=ADM('ads',L=2);e=[0,1,2,3];self.assertAlmostEqual(a.determinant(e),-(2/3)**8)
    def test_invalid_geometry(self):
        with self.assertRaises(ValueError):ADM('ads').fields([[0,0,0]])
        with self.assertRaises(ValueError):ADM(lapse_depth=1)
    def test_characteristics_shift(self):
        a=ADM(shift=(.1,0,0));lo,hi=a.characteristics([0,0,0,0],[1,0,0]);np.testing.assert_allclose(lo,[-1.1,0,0]);np.testing.assert_allclose(hi,[.9,0,0])
    def test_mass_dimension_and_BF(self):
        self.assertAlmostEqual(mass_dimension(-2)['delta_plus'],2)
        self.assertFalse(mass_dimension(-2.25)['alternate_quantization_window'])
        with self.assertRaises(ValueError):mass_dimension(-3)
    def test_Euclidean_kernel_invalid(self):
        with self.assertRaises(ValueError):euclidean_kernel(0,1,2)
        with self.assertRaises(ValueError):euclidean_kernel(1,1,1)
    def test_FG_invalid_dimension(self):
        with self.assertRaises(ValueError):fg_g2(np.eye(2),2,np.eye(2),2)
    def test_gaussian_positive_whole_pure(self):
        d=gaussian_entropy(region=np.arange(16));self.assertLess(abs(d['entropy_von_neumann']),1e-10)
    def test_gaussian_uncoupled_zero(self):self.assertLess(abs(gaussian_entropy(kappa=0)['entropy_von_neumann']),1e-10)
    def test_gaussian_correlated_nonzero(self):self.assertGreater(gaussian_entropy()['entropy_von_neumann'],0)
    def test_gate_branches(self):
        t={'arrival_relative_error':.05,'response_relative_error':.1,'selection_fraction_error':.02}
        self.assertEqual(transfer({},t),'INCONCLUSIVE')
        m=dict(source_resolved=True,space_converged=True,time_converged=True,boundary_independent=True,arrival_relative_error=.01,response_relative_error=.01,selection_fraction_error=.01)
        self.assertEqual(transfer(m,t),'PASS_B39V_TRANSFER');m['response_relative_error']=1;self.assertEqual(transfer(m,t),'FAIL')
        m['space_converged']=False;self.assertEqual(transfer(m,t),'INCONCLUSIVE')
    def test_dictionary_gate_branches(self):
        self.assertEqual(reconstruction(False,0,.01),'BLOCKED');self.assertEqual(reconstruction(True,None,.01),'INCONCLUSIVE');self.assertEqual(reconstruction(True,1,.01),'FAIL');self.assertEqual(reconstruction(True,0,.01),'PASS_HOLOGRAPHIC_RECONSTRUCTION')
    def test_actual_historical_houses(self):
        m=load('b39v_membrana');houses=m.casas_grade(10,12,122)
        with np.load(ROOT/'historico/B39V/resultados/G_P_s+1.npz',allow_pickle=False) as d:np.testing.assert_array_equal(houses,d['casas'])
        self.assertEqual(len(houses),468)
    def test_relay_hysteresis(self):
        r=load('b39_rele');ts=np.arange(4.);a=np.array([[0.],[1.1],[.8],[.4]])
        np.testing.assert_array_equal(r.rele(ts,a,1,'solta').ravel(),[0,1,1,0]);np.testing.assert_array_equal(r.rele(ts,a,1,'trava').ravel(),[0,1,1,1])
    def test_resource_admission(self):
        self.assertGreater(estimate_resources([415,415,81],18000)['estimated_peak_bytes'],16*1024**3)
    def test_atomic_io(self):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'x.json';atomic_json(p,{'x':np.array([1,2])});self.assertTrue(p.exists());self.assertFalse(p.with_suffix('.json.tmp').exists())
    def test_fingerprint_key_order(self):self.assertEqual(fingerprint({'a':1,'b':2}),fingerprint({'b':2,'a':1}))

class Discretization(unittest.TestCase):
    def setUp(self):self.mesh=Mesh([[0,1]]*3,[5]*3)
    def test_mesh_volume(self):self.assertAlmostEqual(float(self.mesh.volume.sum()),1)
    def test_P1_gradient_exact_linear(self):
        p=self.mesh.xyz@np.array([2,3,4]);grad=np.einsum('ta,tai->ti',p[self.mesh.tets],self.mesh.grad);np.testing.assert_allclose(grad,np.broadcast_to([2,3,4],grad.shape),atol=1e-12)
    def test_stiffness_constant_neumann(self):
        M,K,B=self.mesh.operators(ADM(),0,boundary='neumann');np.testing.assert_allclose(K@np.ones(self.mesh.n),0,atol=1e-13);self.assertAlmostEqual(M.sum(),1)
    def test_offdiagonal_metric_linear_energy(self):
        class G:
            def fields(self,xyz,t=0):
                n=len(xyz);g=np.array([[1,.2,0],[.2,2,.1],[0,.1,1.]])
                return np.ones(n),np.zeros((n,3)),np.broadcast_to(g,(n,3,3))
        mm,K,_=self.mesh.operators(G(),0,boundary='neumann');q=self.mesh.xyz[:,0];g=G().fields([[0,0,0]])[2][0]
        self.assertAlmostEqual(float(q@(K@q)),np.sqrt(np.linalg.det(g))*np.linalg.inv(g)[0,0],places=12)
    def test_interpolation_partition_and_affine(self):
        points=np.array([[.13,.27,.51],[.8,.9,.3]]);C=self.mesh.interpolation(points);np.testing.assert_allclose(C@np.ones(self.mesh.n),1);np.testing.assert_allclose(C@self.mesh.xyz,points)
    def test_receiver_outside(self):
        with self.assertRaises(ValueError):self.mesh.interpolation([[-1,0,0]])
    def test_reciprocal_coupling_energy_derivative(self):
        s=System(self.mesh,ADM(),1,points=[[.4,.5,.6]],gamma_r=0);rng=np.random.default_rng(1);u=rng.normal(size=2*self.mesh.n+2);u[:self.mesh.n][self.mesh.boundary]=0;u[self.mesh.n:2*self.mesh.n][self.mesh.boundary]=0;du=s.rhs(0,u);e=1e-4
        derivative=(s.energy(u+e*du)-s.energy(u-e*du))/(2*e);self.assertLess(abs(derivative),1e-7)
    def test_timestep_guard(self):
        s=System(self.mesh,ADM(),1)
        with self.assertRaises(ValueError):integrate(s,1,s.dt_bound*2)
    def test_source_mass_normalization(self):
        m=Mesh([[-2,2]]*3,[9]*3);s=System(m,ADM(),1);f=s.source(.5,1);self.assertAlmostEqual(float(np.sum(f*f/s.mm[:,None])),1)
    def test_source_rotation_parity(self):
        m=Mesh([[-2,2]]*3,[9]*3);s=System(m,ADM(),1);f=s.source(.5,1).reshape(*m.shape,2);np.testing.assert_allclose(f[:,:,::-1],f,atol=1e-12);np.testing.assert_allclose(f[:,::-1,:,0],f[:,:,:,0],atol=1e-12);np.testing.assert_allclose(f[:,::-1,:,1],-f[:,:,:,1],atol=1e-12)
    def test_checkpoint_resume(self):
        m=Mesh([[0,1]]*3,[3]*3);s=System(m,ADM(),1);initial=np.zeros(2*m.n);initial[13]=1
        with tempfile.TemporaryDirectory() as t:
            cp=Path(t)/'cp.npz';d1=integrate(s,.6,.001,initial=initial,sample=.01,checkpoint=cp,run_id='x');self.assertTrue(cp.exists());d2=integrate(s,.6,.001,initial=initial,sample=.01,checkpoint=cp,run_id='x');np.testing.assert_array_equal(d1['final'],d2['final']);np.testing.assert_array_equal(d1['ts'],d2['ts'])
            with self.assertRaises(ValueError):integrate(s,.6,.001,checkpoint=cp,run_id='other')
    def test_invalid_boundary(self):
        with self.assertRaises(ValueError):self.mesh.operators(ADM(),1,boundary='fake')
