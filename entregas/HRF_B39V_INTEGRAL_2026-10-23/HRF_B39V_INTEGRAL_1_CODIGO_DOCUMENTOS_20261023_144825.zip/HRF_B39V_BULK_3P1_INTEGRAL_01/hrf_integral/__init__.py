"""HRF bulk integral: prescribed geometry, classical fields, controlled AdS reference."""
__version__ = '1.0.0'
