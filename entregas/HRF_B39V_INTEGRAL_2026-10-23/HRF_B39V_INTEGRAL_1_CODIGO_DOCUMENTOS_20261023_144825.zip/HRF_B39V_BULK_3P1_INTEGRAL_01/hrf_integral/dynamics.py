"""Hamiltonian KG with reciprocal classical oscillators. J sign explicit in source()."""
import numpy as np
from scipy.sparse import bmat,diags
from scipy.sparse.linalg import spsolve,eigsh
from .fem import Mesh
from .io import atomic_json,atomic_npz,fingerprint

class System:
    def __init__(self,mesh,metric,mass,points=(),omega=1.85,coupling=.05,gamma_r=.1,boundary='dirichlet',sponge=.5):
        self.mesh=mesh;self.metric=metric;self.mass=mass;self.bc=boundary;self.C=mesh.interpolation(np.asarray(points).reshape(-1,3))
        self.h=self.C.shape[0];self.g=coupling;self.omega=np.broadcast_to(omega,(self.h,)).copy();self.gamma_r=gamma_r
        self.mm,self.K,self.B=mesh.operators(metric,mass,boundary=boundary);self.dynamic=metric.period is not None
        distance=np.min(np.minimum(mesh.xyz-mesh.bounds[:,0],mesh.bounds[:,1]-mesh.xyz),axis=1)
        width=min(mesh.bounds[:,1]-mesh.bounds[:,0])*.2
        self.damp=sponge*np.maximum(1-distance/width,0)**2 if boundary=='sponge' else np.zeros(mesh.n)
        self.N,self.beta,self.gam=metric.fields(mesh.xyz)
        # Sufficient Gershgorin bound for beta=0 RK4 imaginary axis; separate advection bound.
        bound=np.max(np.asarray(abs(self.K).sum(axis=1)).ravel()/self.mm)
        adv=np.max(np.asarray(abs(self.B).sum(axis=1)).ravel())
        self.dt_bound=.55/max(np.sqrt(bound)+adv,np.max(self.omega,initial=0),self.gamma_r,1e-12)
        self.off=mesh.n*2
    def operators(self,t):return self.mesh.operators(self.metric,self.mass,t,self.bc) if self.dynamic else (self.mm,self.K,self.B)
    def source(self,width=1.5,z_width=3.,center=(0.,0.,0.)):
        r=self.mesh.xyz-np.asarray(center);a=np.exp(-.5*((r[:,:2]/width)**2).sum(1)-.5*(r[:,2]/z_width)**2)
        # Weak load -integral N sqrt(gamma) J; define J=-F*dipole and normalize in mass norm.
        f=np.column_stack((r[:,0]/width**2*a,r[:,1]/width**2*a))*self.mm[:,None]*self.N[:,None]**2
        if self.bc!='neumann':f[self.mesh.boundary]=0
        norm=np.sqrt(np.sum(f*f/self.mm[:,None]));
        if norm<1e-30:raise ValueError('unresolved/vanishing dipole')
        return f/norm
    def rhs(self,t,state,forcing=None):
        n=self.mesh.n;q=state[:n];p=state[n:2*n];x=state[2*n:2*n+self.h];v=state[2*n+self.h:]
        mm,K,B=self.operators(t);qd=p/mm+B@q
        pd=-K@q-B.T@p-self.damp*p-self.g*(self.C.T@x)
        if forcing is not None:pd+=forcing(t)
        vd=-self.omega**2*x-self.gamma_r*v-self.g*(self.C@q)
        if self.bc!='neumann':qd[self.mesh.boundary]=0;pd[self.mesh.boundary]=0
        return np.r_[qd,pd,v,vd]
    def energy(self,state,t=0.):
        n=self.mesh.n;q=state[:n];p=state[n:2*n];x=state[2*n:2*n+self.h];v=state[2*n+self.h:];mm,K,B=self.operators(t)
        return float(.5*np.sum(p*p/mm)+.5*q@(K@q)+p@(B@q)+.5*np.sum(v*v+self.omega**2*x*x)+self.g*x@(self.C@q))
    def network(self,forcing,omega):
        if self.dynamic or np.any(self.beta):raise ValueError('stationary network currently requires static zero shift')
        A=self.K-diags(self.mm*omega**2)+diags(1j*omega*self.mm*self.damp)
        # Dirichlet boundary rows set to identity rather than isolated -omega² M.
        C=self.g*self.C;D=diags(self.omega**2-omega**2+1j*omega*self.gamma_r)
        sol=spsolve(bmat([[A,C.T],[C,D]],format='csc'),np.r_[forcing,np.zeros(self.h)])
        return sol[self.mesh.n:]

def rk4(system,state,t,dt,forcing=None):
    a=system.rhs(t,state,forcing);b=system.rhs(t+dt/2,state+dt*a/2,forcing)
    c=system.rhs(t+dt/2,state+dt*b/2,forcing);d=system.rhs(t+dt,state+dt*c,forcing)
    return state+dt*(a+2*b+2*c+d)/6

def integrate(system,t_end,dt,forcing=None,initial=None,sample=1.,checkpoint=None,run_id='',resume=True):
    if dt>system.dt_bound:raise ValueError(f'dt {dt} exceeds conservative bound {system.dt_bound}')
    nsteps=int(np.ceil(t_end/dt));dt=t_end/nsteps;stride=max(1,int(round(sample/dt)));n=system.mesh.n
    state=np.zeros(2*n+2*system.h) if initial is None else np.asarray(initial).copy();start=0
    ts=[];xs=[];vs=[];phis=[];energies=[];powers=[];maxima=[]
    if checkpoint is not None and checkpoint.exists() and resume:
        with np.load(checkpoint,allow_pickle=False) as cp:
            if str(cp['run_id'])!=run_id:raise ValueError('checkpoint configuration mismatch')
            state=cp['state'].copy();start=int(cp['step']);ts=list(cp['ts']);xs=list(cp['xs']);vs=list(cp['vs']);phis=list(cp['phis']);energies=list(cp['energies']);powers=list(cp['powers']);maxima=list(cp['maxima'])
    for i in range(start,nsteps+1):
        t=i*dt
        if (i%stride==0 or i==nsteps) and not (start>0 and i==start):
            ts.append(t);xs.append(state[2*n:2*n+system.h].copy());vs.append(state[2*n+system.h:].copy());phis.append(system.C@state[:n]);energies.append(system.energy(state,t));maxima.append(float(np.max(np.abs(state))))
            load=np.zeros(n) if forcing is None else forcing(t);vel=system.rhs(t,state,forcing)[:n]
            powers.append(float(vel@load-np.sum(system.damp*state[n:2*n]*vel)-system.gamma_r*np.sum(state[2*n+system.h:]**2)))
        if i==nsteps:break
        if checkpoint is not None and i>start and i%500==0:
            atomic_npz(checkpoint,run_id=run_id,step=i,state=state,ts=ts,xs=xs,vs=vs,phis=phis,energies=energies,powers=powers,maxima=maxima)
        state=rk4(system,state,t,dt,forcing)
        if not np.isfinite(state).all() or np.max(np.abs(state))>1e30:raise FloatingPointError('divergence/nonfinite evolution')
    return dict(ts=np.asarray(ts),X=np.asarray(xs),P=np.asarray(vs),field=np.asarray(phis),energy=np.asarray(energies),power=np.asarray(powers),max_state=np.asarray(maxima),final=state,dt=dt,steps=nsteps)
