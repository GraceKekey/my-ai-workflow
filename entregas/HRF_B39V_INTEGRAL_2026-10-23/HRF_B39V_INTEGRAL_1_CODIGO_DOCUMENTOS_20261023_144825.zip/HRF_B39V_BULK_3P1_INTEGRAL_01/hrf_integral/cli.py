import argparse,json,os,platform,subprocess,sys,time,traceback
from pathlib import Path
from concurrent.futures import ProcessPoolExecutor,as_completed
import numpy as np,scipy
from .io import atomic_json,digest
ROOT=Path(__file__).resolve().parents[1]

def verify():
    p=ROOT/'hashes_antes_da_execucao.txt'
    if not p.exists():raise FileNotFoundError('run scripts/freeze.py before scientific execution')
    bad=[];count=0
    for line in p.read_text().splitlines():
        sha,name=line.split('  ',1);f=ROOT/name;count+=1
        if not f.exists() or digest(f)!=sha:bad.append(name)
    if bad:raise ValueError('FROZEN_HASH_MISMATCH '+str(bad))
    return {'checked':count,'status':'PASS','manifest_sha256':digest(p)}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('mode',choices=['all','audit','tests','numerical','reference','scenarios','estimate','report']);ap.add_argument('--preset',choices=['smoke','standard','high_resolution'],default='standard');ap.add_argument('--out',default='resultados');ap.add_argument('--workers',type=int,default=1)
    a=ap.parse_args();out=Path(a.out);out=out if out.is_absolute() else ROOT/out;out.mkdir(parents=True,exist_ok=True)
    if not 1<=a.workers<=2:raise ValueError('workers must be 1 or 2 for configured memory bounds')
    hashes=verify();atomic_json(out/'hash_verification.json',hashes)
    gates=json.loads((ROOT/'config/gates.json').read_text());preset=json.loads((ROOT/'config'/f'{a.preset}.json').read_text())
    atomic_json(out/'environment.json',dict(python=sys.version,numpy=np.__version__,scipy=scipy.__version__,platform=platform.platform(),machine=platform.machine(),threads={k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')},preset=preset,authorization='User explicitly authorized all tests after original no-execution prompt',pre_execution_manifest=digest(ROOT/'hashes_antes_da_execucao.txt')))
    if a.mode in ('all','audit'):
        from .history import audit
        print(json.dumps({'audit':audit(out/'audit')['status']}),flush=True)
    if a.mode in ('all','tests'):
        proc=subprocess.run([sys.executable,'-I',str(ROOT/'scripts/test.py')],capture_output=True,text=True)
        (out/'software_tests.log').write_text(proc.stdout+proc.stderr)
        atomic_json(out/'software.json',{'gate':'PASS_SOFTWARE' if proc.returncode==0 else 'FAIL','exit_code':proc.returncode})
        print(json.dumps({'software_exit_code':proc.returncode}),flush=True)
        if proc.returncode:return 1
    if a.mode in ('all','numerical'):
        from .numerics import run
        res=run(out,gates);print(json.dumps({'numerical':res['gate'],'seconds':res['seconds']}),flush=True)
    if a.mode in ('all','reference'):
        from .holography import reference
        from .dictionary import run
        cfg=json.loads((ROOT/'config/reference.json').read_text());res=reference(out/'reference',cfg);res2=run(out/'reference');print(json.dumps({'reference':res['gate'],'dictionary_formulas':res2['gate']}),flush=True)
    if a.mode in ('all','estimate','scenarios'):
        from .scenarios import plan,run_case,compare
        from .fem import estimate_resources
        cases=plan(preset);atomic_json(out/'plan.json',dict(preset=preset,cases=cases,base_resources=estimate_resources(preset['shape'],int(preset['t_end']/preset['dt']))))
        if a.mode!='estimate':
            res=[];dest=out/a.preset;dest.mkdir(exist_ok=True)
            if a.workers==1:
                for c in cases:
                    print(json.dumps({'starting':c['id'],'preset':a.preset}),flush=True)
                    try:r=run_case(c,preset,dest)
                    except Exception as exc:
                        r={'id':c['id'],'status':'FAIL','error':str(exc),'traceback':traceback.format_exc()};atomic_json(dest/c['id']/'error.json',r)
                    res.append(r);print(json.dumps({k:r[k] for k in ('id','status','seconds') if k in r}),flush=True)
            else:
                with ProcessPoolExecutor(max_workers=a.workers) as pool:
                    pending={pool.submit(run_case,c,preset,dest):c for c in cases}
                    for f in as_completed(pending):
                        c=pending[f]
                        try:r=f.result()
                        except Exception as exc:r={'id':c['id'],'status':'FAIL','error':str(exc)};atomic_json(dest/c['id']/'error.json',r)
                        res.append(r);print(json.dumps({'id':r['id'],'status':r['status']}),flush=True)
            comparison=compare(dest,res,gates);atomic_json(dest/'execution.json',{'cases':res,'comparison':comparison});print(json.dumps(comparison),flush=True)
    if a.mode in ('all','report'):report(out)
    return 0

def report(out):
    software=json.loads((out/'software.json').read_text()) if (out/'software.json').exists() else {'gate':'NOT_EXECUTED'}
    num=json.loads((out/'numerical.json').read_text()) if (out/'numerical.json').exists() else {'gate':'NOT_EXECUTED'}
    holo=json.loads((out/'reference/reference.json').read_text()) if (out/'reference/reference.json').exists() else {'gate':'NOT_EXECUTED'}
    dic=json.loads((out/'reference/dictionary.json').read_text()) if (out/'reference/dictionary.json').exists() else {'gate':'NOT_EXECUTED'}
    scenarios={}
    for p in ('smoke','standard','high_resolution'):
        f=out/p/'execution.json'
        if f.exists():scenarios[p]=json.loads(f.read_text())['comparison']
    summary={'software':software['gate'],'numerical':num['gate'],'controlled_reference':holo['gate'],'dictionary_formulas':dic['gate'],'transfer':'INCONCLUSIVE','HRF_holographic_reconstruction':'BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY','scenarios':scenarios,'HRT':'BLOCKED_NOT_IMPLEMENTED','QES':'BLOCKED_NO_VARIATIONAL_STATE_FUNCTIONAL'}
    atomic_json(out/'summary.json',summary)
    lines=['# Relatório integral — execução autorizada','', '## Objetivo','', '[D] Investigar extensão volumétrica e referências AdS controladas separadamente. Não se deriva partícula, DIO, ħ ou gravidade dinâmica.', '', '## Hipóteses e parâmetros','', '[M] As características são as do ADM prescrito; a resposta é de osciladores clássicos. Parâmetros, tolerâncias e casos constam dos arquivos congelados de config/.', '', '## Protocolo e medidas','', '[D] FEM P1 tetraédrico, massa concentrada, shift adjunto Hamiltoniano e RK4. Fonte desligada após 60; standard evolui até 460. CSV por receptor distingue campo, resposta seletiva e disparo.', '', '## Resultados','', '```json',json.dumps(summary,indent=2,ensure_ascii=False),'```','', '## Controles e convergência','', '[M] numerical.json contém refinamento espacial e temporal, conservação de energia, métrica, geodésicas, shift, geometria dependente do tempo e fuga externa. reference/ contém RT, holdout, HKLL espectral, kernel euclidiano, GKPW e FG. software_tests.log contém as asserções e casos negativos.', '', '## Interpretação','', '[?] A malha volumétrica histórica disponível não resolve σ=1,5 nem certifica continuidade da B39V. Resultados coarse são diagnósticos, não PASS_B39V_TRANSFER. A alta resolução é planejada e avaliada contra memória antes de alocar. HRT e QES permanecem sem implementação física efetiva. O novo dicionário é bibliográfico e declara ausentes as interfaces HRF.', '', '[D] PASS de referência controlada não comprova CFT dual da B39V. Métrica prescrita não é solução da gravitação; T efetivo é o tensor requerido, sem condição de matéria demonstrada. Sem dicionário HRF validado, a reconstrução física continua bloqueada.']
    (out/'RELATORIO_FINAL.md').write_text('\n'.join(lines)+'\n')
    try:
        import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
        fig,ax=plt.subplots(figsize=(6,4));sp=num['tests']['spatial_convergence']['measurements'];ax.loglog([r['h'] for r in sp],[r['relative_error'] for r in sp],'o-',label='FEM: frequência² vs contínuo');ax.set_xlabel('h');ax.set_ylabel('erro relativo');ax.legend();ax.grid(True,which='both',alpha=.2);fig.tight_layout();fig.savefig(out/'convergencia_espacial.png',dpi=180);plt.close(fig)
        f=out/'standard/G_P_s+1/signals.npz'
        if f.exists():
            with np.load(f,allow_pickle=False) as d:
                fig,ax=plt.subplots(figsize=(7,4));r=np.linalg.norm(d['houses'][:,:2],axis=1)
                for k in np.argsort(r)[[0,100,300,-1]]:ax.plot(d['ts'],d['R_message'][:,k],label=f'r={r[k]:.1f}')
                ax.set(xlabel='t',ylabel='leitura seletiva da mensagem',title='Bulk coarse: diagnóstico, sem certificação de transferência');ax.axvline(60,color='k',ls=':',label='fonte desliga');ax.legend();fig.tight_layout();fig.savefig(out/'receptores_bulk_coarse.png',dpi=180);plt.close(fig)
    except KeyError:pass

if __name__=='__main__':raise SystemExit(main())
