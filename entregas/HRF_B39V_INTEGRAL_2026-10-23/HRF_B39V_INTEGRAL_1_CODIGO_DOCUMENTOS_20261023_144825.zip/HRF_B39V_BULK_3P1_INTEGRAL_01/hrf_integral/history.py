"""Read-only historical adapter. New height extrusions are explicitly candidate geometry."""
from pathlib import Path
import importlib.util,json,csv
import numpy as np
from scipy.spatial import Delaunay
from .io import digest,atomic_json
ROOT=Path(__file__).resolve().parents[1]
HIST=ROOT/'historico'/'B39V'

def load(name):
    p=HIST/'src'/f'{name}.py';spec=importlib.util.spec_from_file_location('historical_'+name,p);mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);return mod

class Height:
    def __init__(self,rod,cache=None):
        mem=load('b39v_membrana');cfg=load('b39v_config');p=cfg.MODOS['completo']
        self.P,T=mem.disco(p['R'],p['A']);houses=mem.casas_grade(p['PASSO_CASAS'],p['RMIN'],p['RMAX']);gm=list(rod['gmft'])
        if rod.get('semente') is not None:extra,_=cfg.casas_v3(houses,rod['semente'],p['ALFA_CASA'],p['SIG_CASA']);gm+=extra
        # Historical height solve reused without edits; temporal N/proper clocks don't change h.
        self.h=mem.altura(self.P,T,p['R'],p['A'],gm);self.minimum=float(np.min(self.h));self.tri=Delaunay(self.P)
    def __call__(self,xy):
        xy=np.atleast_2d(xy);simp=self.tri.find_simplex(xy)
        outside=simp<0;simp=np.maximum(simp,0)
        tr=self.tri.transform[simp];bar=np.einsum('nij,nj->ni',tr[:,:2],xy-tr[:,2]);bar=np.c_[bar,1-bar.sum(axis=1)]
        vals=self.h[self.tri.simplices[simp]];h=np.einsum('ni,ni->n',vals,bar)
        grad=np.einsum('ni,nij->nj',vals[:,:2]-vals[:,2:3],tr[:,:2]);h[outside]=0;grad[outside]=0;return h,grad[:,0],grad[:,1]

def audit(out):
    cfg=load('b39v_config');mem=load('b39v_membrana');p=cfg.MODOS['completo'];houses=mem.casas_grade(p['PASSO_CASAS'],p['RMIN'],p['RMAX'])
    files=[dict(file=str(f.relative_to(ROOT)),sha256=digest(f),bytes=f.stat().st_size) for f in HIST.rglob('*') if f.is_file() and '__pycache__' not in str(f)]
    rows=[]
    for name in ('W0','OM','OM_R','RAZAO_REDE','GAM_R','G','F0','SIG_FONTE','DUR','DT','AMOSTRA','DMAX'):
        rows.append(dict(parameter=name,value=getattr(cfg,name),source='historico/B39V/src/b39v_config.py',mapping='preserved value; field dimension changed'))
    rows+=[dict(parameter='468 houses',value=len(houses),source='b39v_membrana.casas_grade',mapping='(x,y,0); trilinear sampling, reciprocal coupling'),dict(parameter='P1/P2',value='weak dipole mass norm',source='b39v_dinamica',mapping='3D Gaussian with NEW transverse sigma_z=3; not equal 2D force dimensions'),dict(parameter='relay thresholds',value='frozen historical G global theta',source='historico/B39V/resultados/avaliacao_B39V.json',mapping='same number diagnostic only; no volumetric calibration'),dict(parameter='GMFt/DIO',value='BLOCKED',source='Cap03',mapping='classical oscillator not DIO')]
    out.mkdir(parents=True,exist_ok=True)
    with (out/'correspondencia.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=rows[0].keys());writer.writeheader();writer.writerows(rows)
    res=dict(status='SOURCE_RECOVERED',houses=len(houses),historical_runs=len(cfg.rodadas('completo')),files=files,parameters=rows)
    atomic_json(out/'audit.json',res);return res

def global_threshold():
    p=HIST/'resultados'/'avaliacao_B39V.json'
    if not p.exists():raise FileNotFoundError('MISSING_SOURCE historical evaluation')
    obj=json.loads(p.read_text())
    # Match actual historical schema, never supply invented threshold.
    return obj

def threshold(case):
    """Reproduce original per-case calibration from immutable observations, never tune on new bulk."""
    rl=load('b39_rele');cfg=load('b39v_config');evaluation=global_threshold();cal=evaluation['medidas']['calibracao']
    with np.load(HIST/'resultados'/f'{case}.npz',allow_pickle=False) as d:
        ts=d['ts'];R=rl.leitura(ts,d['X'],d['Pm'],d['Omc'],Xr=d['Xr_h'],A=float(d['rho_r']),Om_r=cfg.OM_R)
        center=cal['tp0']+d['dgeo_casas']/cal['vp'];delta=cfg.MODOS['completo']['PASSO_OLA']/cal['vp'];H=len(center)
        m=rl.margens(ts,R,dict(enumerate(center-delta/2)),dict(enumerate(center+delta/2)),dict(enumerate(center+delta)),list(range(H)))
    return m['theta_trava'],m['theta_solta']
