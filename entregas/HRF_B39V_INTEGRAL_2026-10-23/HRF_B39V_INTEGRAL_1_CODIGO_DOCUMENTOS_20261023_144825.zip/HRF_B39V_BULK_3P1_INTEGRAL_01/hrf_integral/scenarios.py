"""All historical G/T/M candidates, plus paired adversarial controls. No fit to bulk outcomes."""
from pathlib import Path
import time,csv,json
import numpy as np
from .history import load,Height,threshold,HIST
from .geometry import ADM
from .fem import Mesh,estimate_resources
from .dynamics import System,integrate
from .io import fingerprint,atomic_json,atomic_npz,digest


def plan(preset):
    cfg=load('b39v_config');rods=cfg.rodadas('completo')
    if preset['name']=='smoke':rods=rods[:2]
    cases=[dict(id=r['nome'],rod=r,changes={}) for r in rods]
    if preset['name']!='smoke':
        base=rods[0]
        for tag,changes in [('C_mass0',{'mass':0.}),('C_mass1p2',{'mass':1.2}),('C_frequency2p2',{'frequency':2.2}),('C_neumann',{'boundary':'neumann'}),('C_half_dt',{'dt_factor':.5}),('C_harmonic',{'harmonic':True})]:
            cases.append(dict(id=tag,rod=base,changes=changes))
    return cases

def first_half(ts,a):
    peak=np.max(a,axis=0);idx=np.argmax(a>=.5*peak[None,:],axis=0);out=np.asarray(ts)[idx].astype(float)
    out[peak<=1e-30]=np.nan;return out

def finite_list(a):return [None if not np.isfinite(v) else float(v) for v in a]

def run_case(case,preset,out,seed=3901):
    cfg=load('b39v_config');mem=load('b39v_membrana');rl=load('b39_rele');p=cfg.MODOS['completo'];changes=case['changes'];rod=case['rod'];folder=out/case['id'];folder.mkdir(parents=True,exist_ok=True)
    run_config=dict(case=case,preset=preset,seed=seed);run_id=fingerprint(run_config);final=folder/'metrics.json'
    if final.exists():
        got=json.loads(final.read_text())
        if got.get('configuration_sha256')!=run_id:raise ValueError('completed case configuration mismatch')
        if got.get('status')!='BLOCKED' and digest(folder/'signals.npz')!=got['signals_sha256']:raise ValueError('completed data hash mismatch')
        return got
    shape=list(preset['shape'])
    if rod['parte']=='M':shape[:2]=[int(round((n-1)*1.25))+1 for n in shape[:2]];shape[:2]=[n if n%2 else n+1 for n in shape[:2]]
    resource=estimate_resources(shape,int(preset['t_end']/preset['dt']))
    if resource['estimated_peak_bytes']>preset['memory_limit_bytes']:
        res=dict(id=case['id'],status='BLOCKED',reason='RESOURCE_LIMIT',resources=resource,configuration_sha256=run_id);atomic_json(final,res);return res
    beg=time.monotonic();houses=mem.casas_grade(p['PASSO_CASAS'],p['RMIN'],p['RMAX']);points=np.c_[houses,np.zeros(len(houses))]
    hmap=None if not rod['gmft'] else Height(rod)
    metric=ADM('minkowski' if hmap is None else 'graph',height_map=hmap,thickness=preset['transverse_thickness'],lapse_depth=rod['phi'])
    omega=np.full(len(houses),cfg.OM);frequency=changes.get('frequency',cfg.OM)
    if rod['proprio']:
        omega*=metric.fields(points)[0];frequency*=metric.fields([[0,0,0]])[0][0]
    mesh=Mesh(preset['bounds'],shape);mass=changes.get('mass',cfg.W0);boundary=changes.get('boundary','sponge')
    sys=System(mesh,metric,mass,points=points,omega=omega,coupling=cfg.G,gamma_r=cfg.GAM_R,boundary=boundary,sponge=cfg.DMAX)
    dip=sys.source(cfg.SIG_FONTE,preset['source_z_width']);dt=min(preset['dt']*changes.get('dt_factor',1.),sys.dt_bound)
    # Euclidean force-ratio convention preserved, now on 3D lumped load (not continuum-dimension equivalence).
    netload=sys.mm*sys.N**2
    if boundary!='neumann':netload[mesh.boundary]=0
    rho=cfg.RAZAO_REDE*cfg.F0*np.linalg.norm(dip)/np.linalg.norm(netload)
    net_cache=out/'network_cache';net_cache.mkdir(exist_ok=True)
    net_id=fingerprint(dict(shape=shape,rod={k:v for k,v in rod.items() if k not in ('nome','s','parte','a')},mass=mass,boundary=boundary,omega=omega.tolist(),bounds=preset['bounds']))
    net_file=net_cache/(net_id+'.npz')
    if net_file.exists():
        with np.load(net_file,allow_pickle=False) as d:network=d['network']
    else:
        network=sys.network(netload,cfg.OM_R);atomic_npz(net_file,network=network)
    harmonic=changes.get('harmonic',False)
    def forcing(t):
        envelope=1. if harmonic else np.sin(np.pi*t/cfg.DUR)**2 if 0<t<cfg.DUR else 0.
        return cfg.F0*envelope*(dip[:,0]*np.cos(frequency*t)+rod['s']*dip[:,1]*np.sin(frequency*t))
    data=integrate(sys,preset['t_end'],dt,forcing,sample=preset['sample'],checkpoint=folder/'checkpoint.npz',run_id=run_id)
    R=rl.leitura(data['ts'],data['X'],data['P'],omega,Xr=network,A=rho,Om_r=cfg.OM_R);Rm=rl.leitura(data['ts'],data['X'],data['P'],omega)
    theta_lock,theta_release=threshold(rod['nome']);rlock=rl.rele(data['ts'],R,theta_lock,'trava');rrelease=rl.rele(data['ts'],R,theta_release,'solta');brightness=rl.lampada(data['ts'],rrelease)
    times=first_half(data['ts'],Rm);wave_arrival=first_half(data['ts'],data['field']**2);fired=np.any(rlock>0,axis=0);fire=np.where(fired,data['ts'][np.argmax(rlock>0,axis=0)],np.nan)
    power_work=float(np.trapezoid(data['power'],data['ts']));balance=float(data['energy'][-1]-data['energy'][0]-power_work)
    # A transfer PASS also requires quantitative pairwise agreement; coarse configurations cannot certify it.
    wavelength=2*np.pi/np.sqrt(max(frequency**2-mass**2,1e-20));adequate=bool(max(mesh.dx[:2])<=cfg.SIG_FONTE/3 and max(mesh.dx)<=wavelength/12)
    res=dict(id=case['id'],status='EXECUTED',gate='INCONCLUSIVE',configuration_sha256=run_id,resources=resource,seconds=time.monotonic()-beg,shape=shape,dx=mesh.dx,dt=data['dt'],steps=data['steps'],t_end=preset['t_end'],pulse_end=None if harmonic else cfg.DUR,post_source_time=None if harmonic else preset['t_end']-cfg.DUR,source_frequency=frequency,mass=mass,rotation=rod['s'],boundary=boundary,houses=len(houses),spatial_source_resolution_adequate=adequate,source_width_over_max_dx=float(cfg.SIG_FONTE/max(mesh.dx[:2])),theta_lock=theta_lock,theta_release=theta_release,threshold_policy='unchanged per-case value reconstructed solely from historical data',fired=int(fired.sum()),not_fired=np.flatnonzero(~fired),receiver_half_arrival=finite_list(times),field_half_arrival=finite_list(wave_arrival),relay_firing=finite_list(fire),receiver_peak=Rm.max(axis=0),energy_initial=float(data['energy'][0]),energy_final=float(data['energy'][-1]),energy_balance_absolute=balance,energy_balance_relative=abs(balance)/max(abs(power_work),abs(data['energy'][-1]),1e-30),energy_balance_note='sampled quadrature diagnostic; includes source, sponge, oscillator dissipation; static metric only',network_force_ratio=cfg.RAZAO_REDE,network_scale=float(rho),reason='3D candidate not continuum-certified; amplitude/threshold calibration cannot be assumed identical across dimensions')
    # Flux from Eulerian normal current; signed component average not a surface-integrated luminosity.
    flux=mesh.energy_flux(data['final'][:mesh.n],data['final'][mesh.n:2*mesh.n],metric,mass,preset['t_end'])
    res['final_mean_flux_vector']=flux.mean(axis=0)
    with np.load(HIST/'resultados'/f"{rod['nome']}.npz",allow_pickle=False) as hd:
        hr=rl.leitura(hd['ts'],hd['X'],hd['Pm'],hd['Omc']);ht=first_half(hd['ts'],hr);hp=hr.max(axis=0)
        mask=np.isfinite(times)&np.isfinite(ht)&(ht>0)
        res['historical_arrival_relative_error_median']=float(np.median(np.abs(times[mask]-ht[mask])/ht[mask])) if np.any(mask) else None
        res['historical_response_ratio_median']=float(np.median(Rm.max(axis=0)/np.maximum(hp,1e-30)))
        res['historical_comparison_scope']='same house indices and readout; no continuum transfer claim'

    atomic_npz(folder/'signals.npz',ts=data['ts'],X=data['X'].astype('f4'),P=data['P'].astype('f4'),field=data['field'].astype('f4'),R=R.astype('f4'),R_message=Rm.astype('f4'),brightness=brightness.astype('f4'),energy=data['energy'],power=data['power'],houses=points,omega=omega,network=network,final_phi=data['final'][:mesh.n].astype('f4'),mesh_shape=shape)
    res['signals_sha256']=digest(folder/'signals.npz');atomic_json(final,res)
    with (folder/'receivers.csv').open('w',newline='') as f:
        writer=csv.writer(f);writer.writerow(['id','x','y','z','field_half_arrival','selective_response_half','relay_first','message_peak','fired'])
        for i,point in enumerate(points):writer.writerow([i,*point,res['field_half_arrival'][i],res['receiver_half_arrival'][i],res['relay_firing'][i],float(Rm[:,i].max()),int(fired[i])])
    (folder/'report.md').write_text(f"# {case['id']}\n\n[M] EXECUTED, {len(houses)} receptores, {data['steps']} passos.\n\n[D] Gate INCONCLUSIVE: malha não certifica transferência histórica.\n\n[?] Chegada do campo, leitura seletiva e relé são colunas distintas. DIO permanece BLOCKED.\n")
    (folder/'checkpoint.npz').unlink(missing_ok=True);return res

def compare(out,results,gates):
    by={r['id']:r for r in results};pairs=[];base=by.get('G_P_s+1')
    if base and base['status']=='EXECUTED':
        reference=np.array(base['receiver_peak']);
        for r in results:
            if r['status']!='EXECUTED':continue
            ratio=np.array(r['receiver_peak'])/np.maximum(reference,1e-30);r['shadow_vs_flat']=int(np.sum(ratio<gates['shadow_ratio']));r['focus_peak_ratio']=float(np.max(ratio));r['median_peak_ratio']=float(np.median(ratio))
            a=np.array([np.nan if x is None else x for x in r['receiver_half_arrival']]);b=np.array([np.nan if x is None else x for x in base['receiver_half_arrival']]);mask=np.isfinite(a)&np.isfinite(b)
            r['median_arrival_delay_vs_flat']=float(np.median(a[mask]-b[mask])) if np.any(mask) else None
            pairs.append({k:r[k] for k in ('id','fired','shadow_vs_flat','focus_peak_ratio','median_peak_ratio','median_arrival_delay_vs_flat')})
    controls=[]
    if base and base['status']=='EXECUTED':
        for name in ('C_mass0','C_mass1p2','C_frequency2p2','C_neumann','C_half_dt','C_harmonic','M_P_s+1'):
            r=by.get(name)
            if r and r['status']=='EXECUTED':
                ratio=float(np.linalg.norm(np.array(r['receiver_peak'])-np.array(base['receiver_peak']))/max(np.linalg.norm(base['receiver_peak']),1e-30))
                controls.append(dict(case=name,relative_peak_vector_difference=ratio,status='PASS_NUMERICAL' if name=='C_half_dt' and ratio<.02 else 'FAIL' if name=='C_half_dt' else 'DESCRIPTIVE_NOT_CERTIFIED'))
        r=by.get('G_P_s-1')
        if r and r['status']=='EXECUTED':
            mem=load('b39v_membrana');hh=mem.casas_grade(10,12,122);lookup={tuple(q):i for i,q in enumerate(hh)};ix=[lookup[(x,-y)] for x,y in hh]
            p1=np.array(base['receiver_peak']);p2=np.array(r['receiver_peak'])[ix];err=float(np.linalg.norm(p1-p2)/max(np.linalg.norm(p1),1e-30))
            controls.append(dict(case='parity_reflected_rotation',relative_peak_vector_difference=err,status='PASS_NUMERICAL' if err<.02 else 'FAIL',scope='finite-mesh artifact diagnostic, not physical chirality inference'))
    res=dict(gate='INCONCLUSIVE',adversarial_controls=controls,reason='No continuum-certified full historical transfer; coarse candidate comparisons descriptive',comparisons=pairs,executed=sum(r['status']=='EXECUTED' for r in results),blocked=sum(r['status']=='BLOCKED' for r in results),planned=len(results))
    atomic_json(out/'comparisons.json',res);return res
