"""E1 controlled AdS4 only. No data from B39V is labelled CFT entropy."""
import importlib.util
from pathlib import Path
import numpy as np
from scipy.special import jv,gamma
from scipy.linalg import eigh
from .io import atomic_json

def mass_dimension(m2,L=1.):
    if m2*L*L < -2.25: raise ValueError('Breitenlohner-Freedman bound violated')
    nu=np.sqrt(2.25+m2*L*L)
    return {'delta_plus':1.5+nu,'delta_minus':1.5-nu,'alternate_quantization_window':bool(0<nu<1)}

def spectral_basis(events,m2=0.,modes=None):
    """Normalizable Poincare AdS4 solutions with positive radial q, not spacelike modes."""
    if modes is None:modes=np.array([[.7,0.,0.],[1.1,.4,0.],[1.4,0.,.3],[1.8,-.3,.4],[2.1,.5,-.3],[2.5,-.4,-.2]])
    ev=np.asarray(events);t,x,y,z=ev.T;q,kx,ky=modes.T;nu=np.sqrt(2.25+m2);omega=np.sqrt(q*q+kx*kx+ky*ky)
    phase=np.exp(-1j*t[:,None]*omega+1j*x[:,None]*kx+1j*y[:,None]*ky)
    bulk=z[:,None]**1.5*jv(nu,z[:,None]*q)*phase
    boundary=(q/2)**nu/gamma(nu+1)*phase
    return bulk,boundary,omega

def hkll_reference(seed=3901):
    rng=np.random.default_rng(seed);train=rng.uniform([-4,-3,-3,.1],[4,3,3,.2],(80,4));test=rng.uniform([-3,-2,-2,.2],[3,2,2,2.],(37,4))
    _,B,_=spectral_basis(train);Phi,_,_=spectral_basis(test)
    amplitude=rng.normal(size=6)+1j*rng.normal(size=6);data=B@amplitude
    fit,_,rank,s=np.linalg.lstsq(B,data,rcond=1e-12)
    # Finite-rank smearing kernel from boundary samples, no bulk values in fit.
    kernel=Phi@np.linalg.pinv(B,rcond=1e-12);true=Phi@amplitude;pred=kernel@data
    error=float(np.linalg.norm(pred-true)/np.linalg.norm(true));cond=float(s.max()/s.min())
    # Differential equation residual for a held-out exact AdS mode; (Box-m²) phi=0, L=1.
    e=np.array([[.4,.2,-.3,.8]]);h=1e-4;f=spectral_basis(e)[0][0];d2=[]
    for k in range(4):
        d=np.eye(4)[k]*h;d2.append((spectral_basis(e+d)[0][0]-2*f+spectral_basis(e-d)[0][0])/h**2)
    d=np.array([[0,0,0,h]]);dz=(spectral_basis(e+d)[0][0]-spectral_basis(e-d)[0][0])/(2*h)
    residual=e[0,3]**2*(-d2[0]+d2[1]+d2[2]+d2[3])-2*e[0,3]*dz
    pde=float(np.max(np.abs(residual))/np.max(np.abs(f)))
    # A positive Gaussian mode covariance gives a reference two-point function; no interacting CFT claim.
    corr_true=Phi@Phi.conj().T;corr_rec=kernel@(B@B.conj().T)@kernel.conj().T
    corr_error=float(np.linalg.norm(corr_rec-corr_true)/np.linalg.norm(corr_true))
    return dict(status='PASS_HOLOGRAPHIC_REFERENCE' if rank==6 and cond<1e6 and error<1e-9 and pde<1e-4 and corr_error<1e-9 else 'FAIL',scope='finite spectral HKLL reconstruction on supplied AdS4; not arbitrary boundary CFT',rank=int(rank),condition=cond,holdout_bulk_relative_error=error,mode_KG_relative_residual=pde,two_point_relative_error=corr_error,train_samples=80,test_samples=37,seed=seed)

def gaussian_entropy(nx=4,ny=4,mass=1.,kappa=.2,region=None):
    """Explicit lattice Gaussian vacuum. Correct flattening i=x*ny+y; not a holographic CFT."""
    n=nx*ny;K=mass**2*np.eye(n)
    for x in range(nx):
        for y in range(ny):
            i=x*ny+y
            for xx,yy in ((x+1,y),(x,y+1)):
                if xx<nx and yy<ny:
                    j=xx*ny+yy;K[i,i]+=kappa;K[j,j]+=kappa;K[i,j]-=kappa;K[j,i]-=kappa
    lam,U=eigh(K)
    if lam.min()<=0:raise ValueError('unstable Gaussian Hamiltonian')
    X=(U*(.5/np.sqrt(lam)))@U.T;P=(U*(.5*np.sqrt(lam)))@U.T
    A=np.arange(n//2) if region is None else np.asarray(region,int)
    nu=np.sqrt(np.maximum(np.linalg.eigvals(X[np.ix_(A,A)]@P[np.ix_(A,A)]).real,.25));a=nu+.5;b=np.maximum(nu-.5,0)
    entropy=float(np.sum(a*np.log(a)-np.where(b>1e-14,b*np.log(np.maximum(b,1e-300)),0)))
    return dict(entropy_von_neumann=entropy,min_symplectic_eigenvalue=float(nu.min()),hamiltonian_min_eigenvalue=float(lam.min()),state='specified finite lattice vacuum',region=A.tolist())

def reference(out,cfg):
    path=Path(__file__).resolve().parents[1]/'historico/holo01/hrf_holo/cli.py'
    spec=importlib.util.spec_from_file_location('frozen_rt',path);rt=importlib.util.module_from_spec(spec);spec.loader.exec_module(rt)
    rt.run_benchmark(cfg,out/'rt');metrics=__import__('json').loads((out/'rt/metrics.json').read_text())
    hk=hkll_reference();g=gaussian_entropy();whole=gaussian_entropy(region=np.arange(16));uncoupled=gaussian_entropy(kappa=0)
    # Generalized entropy at a FIXED supplied surface only, no QES minimization or claimed gravitational state.
    gen=dict(status='DEFINED_MODEL_FIXED_SURFACE_ONLY',area=2.,G_N=1.,bulk_state=g,S_generalized=.5+g['entropy_von_neumann'],counterterm_scheme='finite lattice, none; not continuum-renormalized',whole_state_entropy=whole['entropy_von_neumann'],uncoupled_entropy=uncoupled['entropy_von_neumann'])
    # Withhold an independent causal observable from the RT fit: lapse is NOT determined by static areas.
    a,b=metrics['a_fitted'],metrics['b_fitted'];z=np.linspace(.1,1.2,1001);u=lambda p,q:(p*z*z+q*z**4)*np.exp(-z)
    spatial_error=float(np.max(np.abs(np.exp(2*u(a,b))-np.exp(2*u(cfg['true']['a'],cfg['true']['b'])))))
    causal={'status':'INCONCLUSIVE','reason':'static RT data do not determine lapse; same spatial metric with N=1/z and N=0.9/z has same RT and different null time','radial_null_time_baseline':1.1,'radial_null_time_alternative':1.1/.9,'withheld_spatial_metric_max_error':spatial_error}
    res=dict(rt=metrics,hkll=hk,mass_dimension=mass_dimension(0),generalized_entropy=gen,causal_comparison=causal,HRT={'status':'BLOCKED','reason':'covariant extremal-surface solver not implemented; no substitution of RT for time-dependent HRT'},QES={'status':'BLOCKED','reason':'no variational bulk state/renormalized entropy functional supplied'},HRF={'status':'BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY','missing':['independent CFT3 state and Hamiltonian','boundary operator algebra and map','entanglement entropy data','bulk-to-boundary observable map','causal/energy dictionary']})
    res['gate']='PASS_HOLOGRAPHIC_REFERENCE' if metrics['gate']=='PASS_SYNTHETIC_ONLY' and hk['status']=='PASS_HOLOGRAPHIC_REFERENCE' and g['min_symplectic_eigenvalue']>=.5-1e-10 and abs(whole['entropy_von_neumann'])<1e-9 and abs(uncoupled['entropy_von_neumann'])<1e-9 else 'FAIL'
    atomic_json(out/'reference.json',res);return res
