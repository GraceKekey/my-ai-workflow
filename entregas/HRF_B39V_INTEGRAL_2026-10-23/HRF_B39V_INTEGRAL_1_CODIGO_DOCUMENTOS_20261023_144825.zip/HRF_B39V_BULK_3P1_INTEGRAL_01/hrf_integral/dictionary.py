"""Tests of formulas selected from user's 2026-10-23 dictionary. hbar=L=1 except FG."""
import numpy as np
from scipy.special import gamma
from scipy.integrate import quad
from .io import atomic_json

def euclidean_kernel(z,r,Delta,d=3):
    if z<=0 or Delta<=d/2:raise ValueError('kernel requires z>0, standard Delta>d/2')
    return gamma(Delta)/(np.pi**(d/2)*gamma(Delta-d/2))*(z/(z*z+r*r))**Delta

def fg_g2(ricci,scalar,g0,d=3):
    if d<=2:raise ValueError('FG g2 formula requires d>2')
    return -(np.asarray(ricci)-scalar/(2*(d-1))*np.asarray(g0))/(d-2)

def run(out):
    # d=3, m²=-2, Delta=2. Analytic regular Euclidean Fourier mode phi=z exp(-kz) J.
    k=.7;zs=np.array([.01,.005,.0025]);A=(np.exp(-k*zs)-1)/zs;err=np.abs(A+k)
    order=float(np.polyfit(np.log(zs),np.log(err),1)[0]);norms=[]
    for z in (.2,.7,1.3):
        integral=quad(lambda r:4*np.pi*r*r*euclidean_kernel(z,r,2),0,np.inf,epsabs=1e-11)[0]
        norms.append(abs(integral/z-1))
    ev=np.array([.8,.3,.4,.2]);h=1e-4
    def f(e):return euclidean_kernel(e[0],np.linalg.norm(e[1:]),2)
    f0=f(ev);lap=sum((f(ev+np.eye(4)[a]*h)-2*f0+f(ev-np.eye(4)[a]*h))/h**2 for a in range(4));dz=(f(ev+np.eye(4)[0]*h)-f(ev-np.eye(4)[0]*h))/(2*h)
    pde=abs(ev[0]**2*lap-2*ev[0]*dz+2*f0)/abs(f0)
    J=.4;W=lambda source:-.5*k*source**2;der=(W(J+h)-W(J-h))/(2*h);gkpwerr=abs(der-(-k*J))
    # FG near-boundary tensor: flat g0 gives g2=0; trace-free g3 gives traceless stress tensor.
    eta=np.diag([-1.,1.,1.]);g3=np.diag([2.,1.,1.]);T=3/(16*np.pi)*g3;trace=float(np.einsum('ab,ab',eta,T));g2=fg_g2(np.zeros((3,3)),0,eta)
    # Independent finite-code check of O_A V=V O_a only for commuting algebra; no physical dual inferred.
    V=np.zeros((4,2));V[0,0]=V[3,1]=1;Z=np.diag([1.,-1.]);X=np.array([[0.,1.],[1.,0.]])
    z_error=float(np.linalg.norm(np.kron(Z,np.eye(2))@V-V@Z));x_error=float(np.linalg.norm(np.kron(X,np.eye(2))@V-V@X))
    tests={
      'mass_dimension':{'status':'PASS_NUMERICAL','m2L2':-2.,'Delta_plus':2.,'Delta_minus':1.,'polynomial_residual':2.*(2.-3.)+2.},
      'Euclidean_kernel_normalization':{'status':'PASS_NUMERICAL' if max(norms)<1e-9 else 'FAIL','relative_errors':norms,'relation':'integral K d^3x=z^(3-Delta), constant source'},
      'Euclidean_kernel_KG':{'status':'PASS_NUMERICAL' if pde<1e-4 else 'FAIL','relative_residual':float(pde)},
      'GKPW_asymptotic_source_response':{'status':'PASS_NUMERICAL' if order>.9 and err[-1]<.001 else 'FAIL','A_estimates':A,'A_exact':-k,'convergence_order':order,'source':'J=1 Fourier mode, analytic regular bulk solution'},
      'GKPW_functional_derivative':{'status':'PASS_NUMERICAL' if gkpwerr<1e-9 else 'FAIL','error':gkpwerr,'convention':'W_ren=-k J²/2 per normalized real mode; O=(2Delta-d)A=-kJ; contact terms removed'},
      'FG_coefficients':{'status':'PASS_NUMERICAL' if np.max(abs(g2))<1e-12 and abs(trace)<1e-12 else 'FAIL','g2':g2,'T_trace':trace,'scope':'algebraic near-boundary formula, not reconstructed interior'},
      'operator_code_positive_negative':{'status':'PASS_NUMERICAL' if z_error<1e-12 and x_error>1 else 'FAIL','Z_reconstruction_error':z_error,'X_local_reconstruction_error':x_error,'scope':'finite commuting repetition-code algebra only; not JLMS gravity'}
    }
    res={'gate':'PASS_HOLOGRAPHIC_REFERENCE' if all(t['status']=='PASS_NUMERICAL' for t in tests.values()) else 'FAIL','tests':tests,'source_document':'documentacao_obrigatoria/HRF_Dicionario_AdS_CFT_Reconstrucao_Fisica_v0_1_PT_2026-10-23.md','HRF_gate':'BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY','reason':'document itself lists HRF-to-CFT, DIO-to-code and manifestation maps as absent; reference formulas do not supply those maps'}
    atomic_json(out/'dictionary.json',res);return res
