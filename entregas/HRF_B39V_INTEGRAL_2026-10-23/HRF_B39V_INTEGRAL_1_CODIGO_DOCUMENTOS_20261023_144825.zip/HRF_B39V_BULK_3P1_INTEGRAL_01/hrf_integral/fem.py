"""P1 tetrahedra, lumped mass; Hamiltonian adjoint shift; explicit RK4 elsewhere."""
from itertools import permutations
import numpy as np
from scipy.sparse import coo_matrix,diags
from scipy.spatial import Delaunay

class Mesh:
    def __init__(self,bounds,shape):
        self.bounds=np.asarray(bounds,float);self.shape=tuple(map(int,shape))
        if len(self.shape)!=3 or min(self.shape)<3 or np.any(self.bounds[:,1]<=self.bounds[:,0]): raise ValueError('invalid grid')
        self.axes=[np.linspace(*b,n) for b,n in zip(self.bounds,self.shape)]
        self.dx=np.array([a[1]-a[0] for a in self.axes]);self.xyz=np.stack(np.meshgrid(*self.axes,indexing='ij'),axis=-1).reshape(-1,3)
        ijk=np.stack(np.meshgrid(*[np.arange(n-1) for n in self.shape],indexing='ij'),axis=-1).reshape(-1,3)
        all_t=[]
        for perm in permutations(range(3)):
            verts=[ijk.copy()];cur=ijk.copy()
            for axis in perm:cur=cur.copy();cur[:,axis]+=1;verts.append(cur)
            all_t.append(np.stack([np.ravel_multi_index(v.T,self.shape) for v in verts],axis=1))
        self.tets=np.concatenate(all_t);v=self.xyz[self.tets];A=v[:,1:]-v[:,:1]
        self.volume=np.abs(np.linalg.det(A))/6;other=np.linalg.inv(A).transpose(0,2,1)
        self.grad=np.concatenate((-other.sum(axis=1)[:,None,:],other),axis=1);self.centers=v.mean(axis=1)
        self.boundary=np.any(np.isclose(self.xyz,self.bounds[:,0])|np.isclose(self.xyz,self.bounds[:,1]),axis=1)
        self.free=np.flatnonzero(~self.boundary);self.n=len(self.xyz)
    def interpolation(self,points):
        points=np.asarray(points);rows=[];cols=[];vals=[]
        # Trilinear receiver sampling is distinct from P1 volume interpolation; positive, partition of unity.
        if np.any(points<self.bounds[:,0]) or np.any(points>self.bounds[:,1]):raise ValueError('receiver outside domain')
        loc=(points-self.bounds[:,0])/self.dx;ii=np.minimum(loc.astype(int),np.array(self.shape)-2);u=loc-ii
        for a in (0,1):
            for b in (0,1):
                for c in (0,1):
                    d=np.array([a,b,c]);cols.extend(np.ravel_multi_index((ii+d).T,self.shape));rows.extend(range(len(points)))
                    vals.extend(np.prod(np.where(d,u,1-u),axis=1))
        return coo_matrix((vals,(rows,cols)),shape=(len(points),self.n)).tocsr()
    def operators(self,metric,mass,t=0.,boundary='dirichlet'):
        if boundary not in ('dirichlet','neumann','sponge'):raise ValueError('unsupported boundary')
        N,b,g=metric.fields(self.centers,t);w=self.volume*np.sqrt(np.linalg.det(g));inv=np.linalg.inv(g)
        local=np.einsum('tai,tij,tbj->tab',self.grad,inv,self.grad)*(w*N)[:,None,None]
        mm=np.bincount(self.tets.ravel(),weights=np.repeat(w/N/4,4),minlength=self.n)
        potential=np.bincount(self.tets.ravel(),weights=np.repeat(w*N*mass**2/4,4),minlength=self.n)
        rows=np.repeat(self.tets,4,axis=1).ravel();cols=np.tile(self.tets,(1,4)).ravel()
        K=coo_matrix((local.ravel(),(rows,cols)),shape=(self.n,self.n)).tocsr()+diags(potential)
        adv=(w/N/4)[:,None]*np.einsum('tj,tbj->tb',b,self.grad)
        C=coo_matrix((np.tile(adv[:,None,:],(1,4,1)).ravel(),(rows,cols)),shape=(self.n,self.n)).tocsr()
        B=diags(1/mm)@C
        if boundary in ('dirichlet','sponge'):
            mask=(~self.boundary).astype(float);P=diags(mask);K=P@K@P;B=P@B@P
        return mm,K.tocsr(),B.tocsr()
    def energy_flux(self,phi,p,metric,mass,t=0.):
        N,b,g=metric.fields(self.centers,t);sq=np.sqrt(np.linalg.det(g));grad=np.einsum('ta,tai->ti',phi[self.tets],self.grad)
        # Eulerian local current; p is integrated/lumped momentum. Static beta=0 used for measured flux.
        mm,_,_=self.operators(metric,mass,t,'neumann');normal_v=(p/mm)[self.tets].mean(axis=1)/N
        flux=-N[:,None]*normal_v[:,None]*np.einsum('tij,tj->ti',np.linalg.inv(g),grad)
        return flux

def estimate_resources(shape,steps):
    n=int(np.prod(shape));return {'nodes':n,'tetrahedra':int(6*np.prod(np.array(shape)-1)), 'estimated_peak_bytes':n*6500,'estimated_matvec_operations':int(steps*n*30*8),'method':'conservative planning bound, not measured peak RSS'}
