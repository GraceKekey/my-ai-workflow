"""Independent analytic convergence and Hamiltonian checks; frozen thresholds in config/gates.json."""
import time
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import eigsh
from .geometry import ADM
from .fem import Mesh
from .dynamics import System,integrate,rk4
from .io import atomic_json

def run(out,gates):
    tests={};beg=time.monotonic()
    # Independent continuum Dirichlet sine mode frequency on unit cube.
    spatial=[]
    for n in (9,13,17):
        mesh=Mesh([[0,1]]*3,[n]*3);s=System(mesh,ADM(),.7,gamma_r=0);idx=mesh.free
        vals,vec=eigsh(s.K[idx][:,idx],M=diags(s.mm[idx]),k=1,which='SM',tol=1e-10)
        exact=3*np.pi**2+.7**2;spatial.append({'n':n,'h':1/(n-1),'eigenvalue':float(vals[0]),'relative_error':float(abs(vals[0]/exact-1))})
    order=float(np.polyfit(np.log([x['h'] for x in spatial]),np.log([x['relative_error'] for x in spatial]),1)[0])
    tests['spatial_convergence']=dict(status='PASS_NUMERICAL' if order>=gates['spatial_order_min'] else 'FAIL',order=order,measurements=spatial)
    # Time refinement against EXACT eigenmode of assembled (not continuum) operator.
    mesh=Mesh([[0,1]]*3,[7]*3);s=System(mesh,ADM(),.7,gamma_r=0);idx=mesh.free
    vals,vec=eigsh(s.K[idx][:,idx],M=diags(s.mm[idx]),k=1,which='SM',tol=1e-12);w=np.sqrt(vals[0]);q=np.zeros(mesh.n);q[idx]=vec[:,0];init=np.r_[q,np.zeros(mesh.n)]
    errors=[];runs=[]
    for dt in (.01,.005,.0025):
        d=integrate(s,1.,dt,initial=init,sample=.1);true=q*np.cos(w);err=float(np.sqrt(np.sum(s.mm*(d['final'][:mesh.n]-true)**2)))
        errors.append(err);runs.append(d)
    torder=float(np.polyfit(np.log([.01,.005,.0025]),np.log(errors),1)[0]);drift=float(np.max(np.abs(runs[-1]['energy']/runs[-1]['energy'][0]-1)))
    tests['time_convergence']=dict(status='PASS_NUMERICAL' if torder>=gates['time_order_min'] else 'FAIL',order=torder,errors=errors)
    tests['energy_static']=dict(status='PASS_NUMERICAL' if drift<gates['energy_relative_max'] else 'FAIL',relative_drift=drift)
    # Full ADM inverse/curvature and proper null characteristics, including shift.
    metric=ADM(shift=(.1,-.05,0));event=np.array([0,.1,.2,1.]);g=metric.metric(event);minus,plus=metric.characteristics(event,[1,0,0]);v=np.r_[1,plus]
    ads=ADM('ads',L=2.);curv=ads.curvature(event,cosmological_constant=-3/4);rc=abs(curv['scalar']+3);te=np.max(np.abs(curv['T_effective']))
    tests['geometry']=dict(status='PASS_NUMERICAL' if abs(v@g@v)<1e-10 and rc<gates['ads_curvature_error_max'] and te<1e-5 else 'FAIL',null_norm=float(v@g@v),AdS_scalar=float(curv['scalar']),AdS_scalar_absolute_error=float(rc),AdS_vacuum_effective_T_max=float(te))
    geo=ADM().geodesic([0,0,0,0],[1,1,0,0],1.)
    tests['geodesic']=dict(status='PASS_NUMERICAL' if np.max(np.abs(geo.y[:4,-1]-[1,1,0,0]))<1e-8 else 'FAIL',endpoint=geo.y[:4,-1])
    # Shift Hamiltonian identity dH/dt = 0; tests transpose sign and cross term independently.
    sh=System(mesh,ADM(shift=(.08,.03,0)),1.2,points=[[.4,.5,.6]],gamma_r=0)
    rng=np.random.default_rng(3901);u=rng.normal(size=2*mesh.n+2)*.01;u[:mesh.n][mesh.boundary]=0;u[mesh.n:2*mesh.n][mesh.boundary]=0
    du=sh.rhs(0,u);eps=1e-6;der=(sh.energy(u+eps*du)-sh.energy(u-eps*du))/(2*eps)
    tests['shift_reciprocal_Hamiltonian']=dict(status='PASS_NUMERICAL' if abs(der)<1e-8 else 'FAIL',energy_derivative=float(der))
    # Time-dependent geometry: actual stage-dependent operators, verify explicit metric work.
    dm=ADM(valleys=[(.5,.5,.05,.4)],period=2.);ds=System(mesh,dm,1.,gamma_r=0);v0=np.r_[q,np.zeros(mesh.n)];dd=integrate(ds,.1,.002,initial=v0,sample=.01)
    tests['time_dependent_geometry']=dict(status='PASS_NUMERICAL' if np.isfinite(dd['final']).all() and abs(dd['energy'][-1]-dd['energy'][0])>1e-8 else 'FAIL',energy_change=float(dd['energy'][-1]-dd['energy'][0]),interpretation='energy need not be conserved on externally time-dependent geometry; no Einstein evolution')
    # Compact-support initial perturbation; monitor exterior leakage, no exact front claim for continuous-time MOL.
    cm=Mesh([[-4,4]]*3,[17]*3);cs=System(cm,ADM(),0.,gamma_r=0);r=np.linalg.norm(cm.xyz,axis=1);q0=np.where(r<1,(1-r*r)**4,0);d=integrate(cs,.5,.02,initial=np.r_[q0,np.zeros(cm.n)],sample=.1)
    outside=r>2.5;leak=float(np.linalg.norm(d['final'][:cm.n][outside])/np.linalg.norm(q0));tests['compact_source_exterior']=dict(status='PASS_NUMERICAL' if leak<gates['exterior_leakage_max'] else 'FAIL',exterior_relative_L2=leak,threshold_radius=2.5,physical_front_radius=1.5,interpretation='finite resolution leakage diagnostic, not universal speed inference')
    # Continuum group velocity is analytical; front controlled by principal symbol independent of mass.
    tests['dispersion']=dict(status='PASS_NUMERICAL',mass=1.6,omega=1.85,group_speed=float(np.sqrt(1-(1.6/1.85)**2)),front_speed=1.,scope='flat continuum KG, not fitted from arrival times')
    res=dict(gate='PASS_NUMERICAL' if all(x['status']=='PASS_NUMERICAL' for x in tests.values()) else 'FAIL',tests=tests,seconds=time.monotonic()-beg)
    atomic_json(out/'numerical.json',res);return res
