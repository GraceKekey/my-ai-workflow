"""Quantitative verdicts; software success cannot promote an unrelated scientific gate."""
def transfer(measurements,thresholds):
    required=('source_resolved','space_converged','time_converged','boundary_independent','arrival_relative_error','response_relative_error','selection_fraction_error')
    if any(k not in measurements for k in required):return 'INCONCLUSIVE'
    if not all(measurements[k] for k in required[:4]):return 'INCONCLUSIVE'
    return 'PASS_B39V_TRANSFER' if all(measurements[k]<=thresholds[k] for k in required[4:]) else 'FAIL'

def reconstruction(dictionary_validated,holdout_error,tolerance):
    if not dictionary_validated:return 'BLOCKED'
    if holdout_error is None:return 'INCONCLUSIVE'
    return 'PASS_HOLOGRAPHIC_RECONSTRUCTION' if holdout_error<=tolerance else 'FAIL'
