"""ADM signature -+++; finite-difference differential geometry, not Einstein evolution."""
import numpy as np
from scipy.integrate import solve_ivp

class ADM:
    def __init__(self, kind='minkowski', L=1., valleys=(), lapse_depth=0., shift=(0.,0.,0.), period=None, height_map=None, thickness=15.):
        self.kind=kind; self.L=float(L); self.valleys=valleys; self.depth=lapse_depth
        self.shift=np.asarray(shift,float); self.period=period; self.height_map=height_map; self.thickness=thickness
        if self.L<=0 or self.shift.shape!=(3,) or abs(lapse_depth)>=.5: raise ValueError('invalid ADM parameters')
    def fields(self, xyz, t=0.):
        xyz=np.atleast_2d(xyz); n=len(xyz); gam=np.broadcast_to(np.eye(3),(n,3,3)).copy()
        beta=np.broadcast_to(self.shift,(n,3)).copy(); N=np.ones(n)
        if self.kind=='ads':
            if np.any(xyz[:,2]<=0): raise ValueError('AdS Poincare requires z>0')
            c=self.L/xyz[:,2];gam*=c[:,None,None]**2;N=c
        elif self.kind not in ('minkowski','graph'): raise ValueError('unknown geometry')
        modulation=1. if self.period is None else 1.+.1*np.sin(2*np.pi*t/self.period)
        if self.kind=='graph':
            if self.height_map is None: raise ValueError('MISSING_SOURCE height map')
            h,hx,hy=self.height_map(xyz[:,:2]); z=xyz[:,2]; env=np.exp(-.5*(z/self.thickness)**2)
            grad=np.column_stack((hx*env,hy*env,-h*z/self.thickness**2*env))*modulation
            gam+=grad[:,:,None]*grad[:,None,:]
            N+=self.depth*h/max(abs(self.height_map.minimum),1e-12)*modulation
        for x,y,amp,sigma in self.valleys:
            f=np.exp(-((xyz[:,0]-x)**2+(xyz[:,1]-y)**2+xyz[:,2]**2)/(2*sigma*sigma))
            gam*=np.exp(2*amp*f*modulation)[:,None,None];N*=1-self.depth*f
        if np.any(N<=0) or not np.isfinite(gam).all(): raise ValueError('nonphysical/invalid ADM')
        return N,beta,gam
    def metric(self, event):
        t,*xyz=np.asarray(event,float);N,b,g=self.fields([xyz],t);N=N[0];b=b[0];g=g[0]
        out=np.zeros((4,4));out[1:,1:]=g;out[0,1:]=out[1:,0]=g@b;out[0,0]=-N*N+b@g@b
        return out
    def inverse(self,event): return np.linalg.inv(self.metric(event))
    def determinant(self,event): return float(np.linalg.det(self.metric(event)))
    def connection(self,event,h=2e-4):
        event=np.asarray(event,float);dg=np.empty((4,4,4))
        for k in range(4):
            d=np.eye(4)[k]*h;dg[k]=(self.metric(event+d)-self.metric(event-d))/(2*h)
        inv=self.inverse(event);G=np.zeros((4,4,4))
        for a in range(4):
            for b in range(4):
                for c in range(4): G[a,b,c]=.5*sum(inv[a,d]*(dg[b,d,c]+dg[c,d,b]-dg[d,b,c]) for d in range(4))
        return G
    def curvature(self,event,h=1e-3,cosmological_constant=0.,G_Newton=1.):
        event=np.asarray(event,float);conn=self.connection(event,h/3);der=np.empty((4,4,4,4))
        for k in range(4):
            d=np.eye(4)[k]*h;der[k]=(self.connection(event+d,h/3)-self.connection(event-d,h/3))/(2*h)
        R=np.empty((4,4,4,4))
        for a in range(4):
            for b in range(4):
                for c in range(4):
                    for d in range(4):
                        R[a,b,c,d]=der[c,a,d,b]-der[d,a,c,b]+sum(conn[a,c,e]*conn[e,d,b]-conn[a,d,e]*conn[e,c,b] for e in range(4))
        ric=np.einsum('abad->bd',R);g=self.metric(event);scalar=float(np.einsum('ab,ab',self.inverse(event),ric))
        ein=ric-.5*g*scalar
        return dict(riemann=R,ricci=ric,scalar=scalar,einstein=ein,T_effective=(ein+cosmological_constant*g)/(8*np.pi*G_Newton))
    def characteristics(self,event,direction):
        N,b,g=self.fields([np.asarray(event)[1:]],event[0]);u=np.asarray(direction,float);u=u/np.sqrt(u@g[0]@u)
        return -b[0]-N[0]*u,-b[0]+N[0]*u
    def geodesic(self,event,tangent,affine_end=1.,rtol=1e-8):
        def rhs(_,state):
            x=state[:4];v=state[4:];return np.r_[v,-np.einsum('abc,b,c->a',self.connection(x),v,v)]
        return solve_ivp(rhs,(0,affine_end),np.r_[event,tangent],rtol=rtol,atol=rtol*.01,dense_output=True)
