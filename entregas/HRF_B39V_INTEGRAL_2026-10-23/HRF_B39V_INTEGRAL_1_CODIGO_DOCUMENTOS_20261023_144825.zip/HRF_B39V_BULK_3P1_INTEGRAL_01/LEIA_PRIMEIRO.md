# HRF B39V bulk integral v1.0

[D] O pedido original era pré-registro não executado. Mario autorizou depois: “pode rodar tudo ate finalizar todos os testes propostos”. O ZIP com PREREG_NAO_EXECUTADO no nome é uma fotografia anterior aos testes novos; resultados são entregues separadamente, identificados como executados. Dados históricos executados permanecem em historico/ e não se confundem com esta rodada.

Instale Python 3.11 ou 3.12 e execute na raiz:

```bash
python3 -m venv .venv
.venv/bin/python3 -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python3 -I scripts/run.py all --preset standard
.venv/bin/python3 -I scripts/run.py scenarios --preset smoke
.venv/bin/python3 -I scripts/run.py scenarios --preset high_resolution
.venv/bin/python3 -I scripts/run.py report
```

No Windows use `.venv\Scripts\python.exe` e scripts/run_windows.ps1. Scripts não instalam automaticamente dependências. O modo `estimate` não aloca malha. `--workers 2` permite dois casos paralelos; o padrão é um. BLAS deve permanecer em uma thread por processo. Retomar o mesmo comando usa checkpoints por caso e intermediários a cada 500 passos. Modificar configuração exige pasta de saída nova; hashes de fonte e resultados prontos são verificados.

[D] Leia resultados/summary.json e RELATORIO_FINAL.md. PASS_SOFTWARE, PASS_NUMERICAL e PASS_HOLOGRAPHIC_REFERENCE são domínios distintos. A extensão histórica coarse é diagnóstica e não tem resolução suficiente para PASS_B39V_TRANSFER. HRT dependente do tempo e QES não foram implementados; a interface física HRF continua sem dicionário validado.

A distribuição contém código e dados históricos, documentos recebidos, parâmetros congelados, testes, logs, relatórios, CSV e figuras. Se distribuída em partes ZIP independentes, extraia todas na mesma pasta: compartilham esta raiz. MANIFEST_SHA256.txt verifica o pacote final; hashes_antes_da_execucao.txt verifica o estado prévio. Não reescreva o freeze; emendas devem preservar a fotografia antiga e justificar a alteração.
