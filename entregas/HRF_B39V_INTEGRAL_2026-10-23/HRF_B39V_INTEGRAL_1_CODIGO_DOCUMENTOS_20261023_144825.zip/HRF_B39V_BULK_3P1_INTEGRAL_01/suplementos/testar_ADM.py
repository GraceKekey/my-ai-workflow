from pathlib import Path
import sys,json,hashlib,time
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from scipy.special import jv,yv
from scipy.optimize import brentq
from scipy.sparse import diags
from scipy.sparse.linalg import eigsh
from hrf_integral.fem import Mesh
from hrf_integral.geometry import ADM
from hrf_integral.dynamics import System,rk4
from hrf_integral.io import atomic_json
r=Path(__file__).resolve().parent
for line in (r/'hashes_suplementares.txt').read_text().splitlines():
 sha,name=line.split('  ',1)
 if hashlib.sha256((r/name).read_bytes()).hexdigest()!=sha:raise RuntimeError('SUPPLEMENT_HASH_MISMATCH')
beg=time.monotonic();nu=1.5
f=lambda q:jv(nu,q*3)*yv(nu,q)-yv(nu,q*3)*jv(nu,q)
q=brentq(f,1,2);exact=q*q+np.pi**2/2;sp=[]
for n in (9,13,17):
 mesh=Mesh([[-1,1],[-1,1],[1,3]],[n]*3);s=System(mesh,ADM('ads'),0,gamma_r=0);idx=mesh.free
 val=eigsh(s.K[idx][:,idx],M=diags(s.mm[idx]),k=1,which='SM',tol=1e-10,return_eigenvectors=False)[0]
 sp.append(dict(n=n,h=2/(n-1),omega_squared=float(val),relative_error=float(abs(val/exact-1))))
order=float(np.polyfit(np.log([p['h'] for p in sp]),np.log([p['relative_error'] for p in sp]),1)[0])
mesh=Mesh([[0,1]]*3,[5]*3);s=System(mesh,ADM(valleys=[(.5,.5,.05,.4)],period=2.),1,gamma_r=0);phi=np.prod(np.sin(np.pi*mesh.xyz),axis=1);u=np.r_[phi,np.zeros(mesh.n)];H0=s.energy(u,0);work=[];ts=[]
for i in range(201):
 t=i*.002;eps=1e-4;partial=(s.energy(u,t+eps)-s.energy(u,t-eps))/(2*eps);ts.append(t);work.append(partial)
 if i<200:u=rk4(s,u,t,.002)
H1=s.energy(u,.4);W=float(np.trapezoid(work,ts));error=abs(H1-H0-W)/max(abs(H1-H0),abs(W),1e-30)
res={'AdS_cavity':{'status':'PASS_NUMERICAL' if order>=1.5 else 'FAIL','radial_q':q,'omega_squared_exact':exact,'order':order,'measurements':sp},'time_dependent_work':{'status':'PASS_NUMERICAL' if error<=.005 else 'FAIL','energy_change':H1-H0,'integrated_explicit_work':W,'relative_balance_error':error},'seconds':time.monotonic()-beg}
res['gate']='PASS_NUMERICAL' if all(res[k]['status']=='PASS_NUMERICAL' for k in ('AdS_cavity','time_dependent_work')) else 'FAIL'
atomic_json(r/'resultados_suplementares.json',res);print(json.dumps(res,indent=2))
