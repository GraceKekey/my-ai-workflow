# Controles adicionais independentes de ADM

[D] Registrados após controles iniciais de Minkowski e antes de obter os resultados destes dois casos; não substituem nem mudam critérios anteriores.

1. AdS4 Poincaré, L=1, z em [1,3], x/y em [-1,1], paredes Dirichlet. Escalar m=0. Modo radial z^(3/2)[J_(3/2)(qz)Y_(3/2)(q)-Y_(3/2)(qz)J_(3/2)(q)], q é primeira raiz em z=3. Autovalor exato ω²=q²+π²/2. FEM com n=9,13,17, ordem de erro de autovalor ≥1.5. Não são fronteiras conformes z→0: controle de cavidade no fundo AdS conhecido.
2. Geometria suave dependente do tempo, perturbação conforme .05, período2, caixa unitária n=5, massa1, t=.4, dt=.002. Verificar ∆H=∫∂H/∂t dt a estado fixo; derivada parcial central ε=1e-4; quadratura em todos os passos. Erro relativo ≤.005. Sem fonte, shift, osciladores ou amortecimento. É trabalho da geometria prescrita, não gravidade dinâmica.

[D] Manifesto próprio emitido antes da execução. Scripts e resultados entregues com freeze original intacto.
