"""Bootstrap explicit project root under python -I; no ambient PYTHONPATH."""
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hrf_integral.cli import main
raise SystemExit(main())
