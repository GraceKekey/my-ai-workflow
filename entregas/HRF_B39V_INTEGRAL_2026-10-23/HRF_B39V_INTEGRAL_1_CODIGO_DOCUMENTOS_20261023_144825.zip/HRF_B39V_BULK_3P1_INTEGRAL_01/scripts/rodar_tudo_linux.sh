#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python3 -I scripts/run.py all --preset standard
python3 -I scripts/run.py scenarios --preset smoke
python3 -I scripts/run.py scenarios --preset high_resolution
python3 -I suplementos/testar_ADM.py
python3 -I controle_resolvido/run.py
python3 -I reanalise/corrigir_comparacoes.py
python3 -I scripts/run.py report
python3 -I scripts/consolidar.py
