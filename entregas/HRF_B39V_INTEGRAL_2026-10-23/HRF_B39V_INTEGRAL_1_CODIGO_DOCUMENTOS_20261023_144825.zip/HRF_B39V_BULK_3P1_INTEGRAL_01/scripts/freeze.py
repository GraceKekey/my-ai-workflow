"""Freeze BEFORE tests/results. Existing freeze cannot be silently replaced."""
from pathlib import Path
import hashlib,json,datetime,sys,zipfile
root=Path(__file__).resolve().parents[1];dest=root/'hashes_antes_da_execucao.txt'
if dest.exists():raise SystemExit('Freeze already exists. Preserve it and record a versioned amendment before a new freeze.')
exclude={'resultados','graficos','relatorios','__pycache__','.pytest_cache','preregistro'}
files=sorted(p for p in root.rglob('*') if p.is_file() and not any(x in exclude for x in p.relative_to(root).parts) and p.name!='MANIFEST_SHA256.txt' and not p.name.startswith('execucao_'))
dest.write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(root).as_posix()}\n' for p in files))
print(json.dumps({'frozen_files':len(files),'manifest_sha256':hashlib.sha256(dest.read_bytes()).hexdigest()}))
# Named preregistration snapshot contains no new scientific results. Historical files are identified as historical.
archive=root.parent/'HRF_B39V_BULK_3P1_INTEGRAL_v1_0_PREREG_NAO_EXECUTADO.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=1) as z:
 for p in files+[dest]:z.write(p,arcname=(root.name+'/'+str(p.relative_to(root))))
print(archive)
