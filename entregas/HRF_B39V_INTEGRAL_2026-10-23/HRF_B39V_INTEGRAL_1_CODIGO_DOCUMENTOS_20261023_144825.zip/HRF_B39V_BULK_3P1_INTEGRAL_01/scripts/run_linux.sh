#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
export OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1
python3 -I scripts/run.py all --preset standard
python3 -I scripts/run.py scenarios --preset smoke
python3 -I scripts/run.py scenarios --preset high_resolution
python3 -I scripts/run.py report
