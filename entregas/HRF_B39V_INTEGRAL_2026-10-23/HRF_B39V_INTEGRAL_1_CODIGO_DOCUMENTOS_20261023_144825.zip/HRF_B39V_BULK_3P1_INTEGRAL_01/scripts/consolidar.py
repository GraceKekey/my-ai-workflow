"""Post-processing only; never changes frozen scientific decisions."""
from pathlib import Path
import sys,json,csv,re
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from hrf_integral.io import atomic_json,digest
from hrf_integral.cli import verify
r=Path(__file__).resolve().parents[1];out=r/'resultados';registry=[]
def read(p):return json.loads(p.read_text())
base=read(out/'summary.json');num=read(out/'numerical.json');supp=read(r/'suplementos/resultados_suplementares.json');resolved=read(r/'controle_resolvido/summary.json');dic=read(out/'reference/dictionary.json');holo=read(out/'reference/reference.json')
for line in (out/'software_tests.log').read_text().splitlines():
 if line.startswith('test_') and ' ... ' in line:
  name,status=line.split(' ... ',1);registry.append(dict(id='software/'+name,status='PASS_SOFTWARE' if status=='ok' else 'FAIL',evidence='resultados/software_tests.log'))
for name,test in num['tests'].items():registry.append(dict(id='numerical/'+name,status=test['status'],evidence='resultados/numerical.json'))
for name in ('AdS_cavity','time_dependent_work'):registry.append(dict(id='supplement/'+name,status=supp[name]['status'],evidence='suplementos/resultados_suplementares.json'))
for name,test in dic['tests'].items():registry.append(dict(id='dictionary/'+name,status=test['status'],evidence='resultados/reference/dictionary.json'))
registry.append(dict(id='RT_restricted_holdout',status='PASS_HOLOGRAPHIC_REFERENCE' if holo['rt']['gate']=='PASS_SYNTHETIC_ONLY' else 'FAIL',evidence='resultados/reference/reference.json'))
registry.append(dict(id='HKLL_spectral_holdout',status=holo['hkll']['status'],evidence='resultados/reference/reference.json'))
for p in ('smoke','standard','high_resolution'):
 e=read(out/p/'execution.json')
 for c in e['cases']:
  registry.append(dict(id=p+'/'+c['id'],status=c['status'],evidence=f'resultados/{p}/{c["id"]}/metrics.json' if c['status']!='FAIL' else f'resultados/{p}/{c["id"]}/error.json',scientific_gate=c.get('gate','BLOCKED' if c['status']=='BLOCKED' else 'FAIL'),reason=c.get('reason')))
 for c in e['comparison'].get('adversarial_controls',[]):registry.append(dict(id=p+'/'+c['case']+'/paired_control',status=c['status'],evidence=f'resultados/{p}/comparisons.json'))
for name,c in resolved['cases'].items():registry.append(dict(id='resolved/'+name,status=c['status'],evidence=f'controle_resolvido/{name}/metrics.json'))
for name,passed in resolved['checks'].items():registry.append(dict(id='resolved/check/'+name,status='PASS_NUMERICAL' if passed else 'FAIL',evidence='controle_resolvido/summary.json'))
for name,reason in [('HRT','covariant extremal-surface solver absent'),('QES','variational bulk state/entropy functional absent'),('HRF_CFT_dictionary','no validated physical dual, explicitly absent in user dictionary'),('multisector_compatibility','no Maxwell/Dirac/gauge extension implemented')]:registry.append(dict(id=name,status='BLOCKED',reason=reason,evidence='LIMITACOES_E_LACUNAS.md'))
reanalysis=read(r/'reanalise/testes.json')
for i in range(reanalysis['tests']):registry.append(dict(id=f'reanalysis/regression_{i+1}',status=reanalysis['status'],evidence='reanalise/testes.json'))
for preset in ('smoke','standard','high_resolution'):base['scenarios'][preset]=read(out/preset/'execution.json')['comparison']
status_counts={k:sum(t['status']==k for t in registry) for k in sorted({t['status'] for t in registry})}
summary=dict(base,controlled_AdS_and_external_work=supp['gate'],resolved_3D_control=resolved['gate'],resolved_3D_checks=resolved['checks'],status_counts=status_counts,scope='executed all implemented planned cases; explicit blocked gates and resource admission are not executed simulations',software_tests=sum(t['status']=='PASS_SOFTWARE' for t in registry),executed_volumetric_scenarios=sum(t['status']=='EXECUTED' for t in registry),frozen_hash_verification=verify())
atomic_json(out/'RESUMO_INTEGRAL.json',summary);atomic_json(out/'REGISTRO_DE_TODOS_OS_TESTES.json',registry)
with (out/'REGISTRO_DE_TODOS_OS_TESTES.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['id','status','evidence','scientific_gate','reason']);w.writeheader();w.writerows(registry)
failures=[t for t in registry if t['status']=='FAIL'];blocked=[t for t in registry if t['status']=='BLOCKED']
text=['# Relatório consolidado — HRF B39V integral','', '## Objetivo','', '[D] Executar a extensão volumétrica e controles conhecidos de AdS/CFT, com autorização posterior ao pedido original de pré-registro. O novo dicionário de 23/10 foi recebido e incorporado antes do freeze principal.', '', '## Hipóteses','', '[M] Convergência do campo KG em ADM prescrito e reconstrução de referências sintéticas conhecidas. [H/?] A identidade física HRF→CFT e DIO→manifestação não é fornecida pelas fórmulas bibliográficas.', '', '## Parâmetros','', '[D] Toda a configuração principal foi congelada em config/. Duas séries suplementares foram registradas antes de obter seus próprios resultados: cavidade AdS/trabalho externo e domínio compacto com fonte resolvida. Os protocolos e hashes respectivos são preservados. Não substituem nem ajustam a bancada histórica.', '', '## Protocolo','', '[D] FEM P1 tetraédrico, massa concentrada, shift adjunto Hamiltoniano, RK4, osciladores recíprocos, 468 posições históricas, regras e limiares herdados. Fontes e geometria 3D são candidatas explícitas. A única correção anterior à rodada científica foi o incremento de diferença finita do teste unitário de energia; fonte do teste e log inicial estão em preregistro/v1 e EMENDAS.md.', '', '## Medidas','', '[M] Campo nos receptores, resposta demodulada e filtrada, relé e luminosidade são canais distintos. Energia medida é o Hamiltoniano das perturbações (campo+osciladores+acoplamento); não inclui a energia total e as interferências da rede estacionária adicionada analiticamente ao readout. Arquivos signals.npz principais guardam sinais em float32 para distribuição, enquanto métricas/energia e decisões foram calculadas em float64. Controles compactos são guardados em float64.', '', '## Resultados','', '```json',json.dumps(summary,ensure_ascii=False,indent=2),'```','', '### Falhas avaliadas','',json.dumps(failures,ensure_ascii=False,indent=2),'', '### Bloqueios','', f'[D] {len(blocked)} itens com bloqueio explícito, incluindo os casos de alta resolução. O planejamento de memória excede os 32 GiB disponíveis; não houve alocação de malha alta nem simulação desses casos. HRT, QES, dicionário físico HRF e extensão multissetorial são lacunas concretas, não verificações aprovadas.', '', '## Controles e convergência','',f"[M] Ordens: Minkowski espacial {num['tests']['spatial_convergence']['order']:.6f}; temporal {num['tests']['time_convergence']['order']:.6f}; cavidade AdS espacial {supp['AdS_cavity']['order']:.6f}. Deriva energética estática {num['tests']['energy_static']['relative_drift']:.4g}. Balanço trabalho da métrica dinâmica: erro relativo {supp['time_dependent_work']['relative_balance_error']:.4g}.",'',f"[M] RT: erro relativo no holdout {holo['rt']['holdout_rms_relative_on_delta_entropy']:.4g}; HKLL: erro {holo['hkll']['holdout_bulk_relative_error']:.4g}. Kernel euclidiano, GKPW fonte/resposta, FG e código lógico com controle negativo constam de dictionary.json. Estes são testes em domínios conhecidos e não descoberta de uma dualidade HRF.",'', '## Interpretação','', '[?] O domínio histórico coarse não resolve σ=1.5 e não conserva amplitudes/disparos da superfície. Não se conclui equivalência ou refutação física antes de convergência, normalização dimensional e fronteiras adequadas. O controle compacto testa propagação 3D com fonte resolvida, mas não substitui os 468 receptores históricos. FAIL de refinamento/borda/simetria deve permanecer FAIL mesmo se o código executou corretamente.', '', '[D] A correção pós-execução da normalização descritiva de sombra está documentada em reanalise/ERRATA.md, com relatórios originais preservados. Os valores efetivos de subamostragem estão em CORRESPONDENCIA_FINAL.csv; AMOSTRA=1 no volume difere do valor histórico .5. Nenhum critério ou veredito físico foi promovido por essas correções.', '', '[D] Não se infere frente universal de meia-chegada, emergência de partícula de um relé, geometria gravitacional dinâmica de uma métrica prescrita ou holografia física de uma regressão sintética. PASS_HOLOGRAPHIC_REFERENCE e bloqueio de E2 são resultados compatíveis. Os resultados históricos e negativos permanecem intactos.']
(out/'RELATORIO_CONSOLIDADO.md').write_text('\n'.join(text)+'\n')
# Compare copies with the original preimplementation source audit, without rewriting it.
audit=read(r/'AUDITORIA_DE_ENTRADA.json');mismatches=[];checked=0
for item in audit['arquivos']:
 original=Path(item['arquivo'])
 if original.exists():
  checked+=1
  if digest(original)!=item['sha256']:mismatches.append(str(original))
# Verify every preserved copy against original source bytes, not only the original audit list.
collections={'B39V':Path('/workspace/hrf-b39v-20261022/HRF_B39V_OLA_Vale_2_5D_PREREGISTRO_2026-10-22_1944-clau'),'bulk_anterior':Path('/workspace/hrf-b39v-bulk-3p1/HRF_B39V_BULK_3P1_PREREG_2026-10-22'),'holo01':Path('/workspace/hrf-holo-b39v-01/HRF_HOLO_B39V_01_PREREG_NAO_EXECUTADO_2026-10-22'),'holo02':Path('/workspace/hrf-holo-b39v-02/HRF_HOLO_B39V_02_BOUNDARY_QUANTICA_PREREG_NAO_EXECUTADO_2026-10-22')}
for name,source in collections.items():
 for copy in (r/'historico'/name).rglob('*'):
  if not copy.is_file() or '__pycache__' in copy.parts:continue
  original=source/copy.relative_to(r/'historico'/name)
  if original.exists():
   checked+=1
   if digest(copy)!=digest(original):mismatches.append(str(copy))
# Every historical copy additionally has its own final distribution hash.
atomic_json(out/'AUDITORIA_FINAL.json',dict(status='COMPLETED_IMPLEMENTED_TESTS_WITH_EXPLICIT_BLOCKS',original_input_files_verified=checked,input_mismatches=mismatches,simulations_executed=summary['executed_volumetric_scenarios'],historical_data_unchanged=not mismatches,dictionary_source_sha256=digest(r/'documentacao_obrigatoria/HRF_Dicionario_AdS_CFT_Reconstrucao_Fisica_v0_1_PT_2026-10-23.md')))
import matplotlib;matplotlib.use('Agg');import matplotlib.pyplot as plt
fig,axes=plt.subplots(1,2,figsize=(10,4))
with np.load(r/'controle_resolvido/flat_plus/signals.npz',allow_pickle=False) as d:
 for k in (0,4,12,16):axes[0].plot(d['ts'],d['field'][:,k],label=f'casa {k}');axes[1].plot(d['ts'],d['R'][:,k],label=f'casa {k}')
for ax,label in zip(axes,('campo da mensagem','leitura seletiva')):ax.set(xlabel='t',ylabel=label);ax.axvline(12,color='k',ls=':');ax.legend()
fig.suptitle('Controle compacto 3D — fonte resolvida; sem certificação histórica');fig.tight_layout();fig.savefig(out/'controle_compacto_3D.png',dpi=180);plt.close(fig)
(r/'COMO_REPRODUZIR_TUDO.md').write_text('''# Reproduzir a execução integral\n\n[D] Instale requirements.txt e mantenha BLAS em uma thread. Na raiz extraída, execute:\n\n```bash\npython3 -I scripts/run.py all --preset standard\npython3 -I scripts/run.py scenarios --preset smoke\npython3 -I scripts/run.py scenarios --preset high_resolution\npython3 -I suplementos/testar_ADM.py\npython3 -I controle_resolvido/run.py\npython3 -I scripts/run.py report\npython3 -I reanalise/corrigir_comparacoes.py\npython3 -I scripts/consolidar.py\n```\n\n[D] No Windows use python ou o caminho do venv. Os mesmos comandos funcionam; scripts/run_windows.ps1 executa a rodada principal e scripts/rodar_tudo_windows.ps1 acrescenta os suplementos e a consolidação. Não execute scripts/freeze.py sobre um freeze existente. Use pasta de saída nova para experimentos com parâmetros modificados e rotule-os fora deste pré-registro.\n\nO primeiro ZIP guarda a fotografia de pré-registro com o nome solicitado dentro de preregistro/. Ela contém código e documentação anterior aos resultados novos; os dados históricos e resultados integrais são fornecidos pelos outros membros da distribuição. Extraia todas as partes ZIP independentes na mesma pasta e confira MANIFEST_SHA256.txt. A raiz única contém todos os dados necessários; não depende de links ao repositório.\n''')
print(json.dumps({'summary':summary,'failures':len(failures),'blocked':len(blocked)},ensure_ascii=False))
