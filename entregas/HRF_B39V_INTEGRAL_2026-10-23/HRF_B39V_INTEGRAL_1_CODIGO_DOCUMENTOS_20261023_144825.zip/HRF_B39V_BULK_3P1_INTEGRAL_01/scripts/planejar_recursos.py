"""Preflight memory/time estimate, calibrated to existing verified run when available."""
from pathlib import Path
import sys,json,argparse
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from hrf_integral.fem import estimate_resources
from hrf_integral.io import atomic_json
r=Path(__file__).resolve().parents[1];p=argparse.ArgumentParser();p.add_argument('--preset',default='high_resolution');a=p.parse_args();cfg=json.loads((r/'config'/f'{a.preset}.json').read_text());est=estimate_resources(cfg['shape'],int(cfg['t_end']/cfg['dt']))
mem=Path('/sys/fs/cgroup/memory.max');available=int(mem.read_text()) if mem.exists() and mem.read_text().strip().isdigit() else None
est.update(preset=a.preset,available_machine_memory_bytes=available,admission_limit_bytes=cfg['memory_limit_bytes'],admitted=est['estimated_peak_bytes']<=cfg['memory_limit_bytes'])
baseline=r/'resultados/standard/G_P_s+1/metrics.json'
if baseline.exists():
 b=json.loads(baseline.read_text());rate=b['resources']['estimated_matvec_operations']/b['seconds'];est.update(calibration_case='standard/G_P_s+1',calibration_seconds=b['seconds'],estimated_lower_bound_seconds=est['estimated_matvec_operations']/rate,time_note='linear operation-count projection only; ignores superlinear sparse factorization, height setup, caches and I/O; not a runtime guarantee')
else:est.update(time_status='MISSING_CALIBRATION_BENCHMARK',time_note='Operation count given; no invented throughput')
atomic_json(r/'resultados'/f'preflight_{a.preset}.json',est);print(json.dumps(est,indent=2))
