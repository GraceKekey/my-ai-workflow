$ErrorActionPreference = 'Stop'
Set-Location (Join-Path $PSScriptRoot '..')
$env:OPENBLAS_NUM_THREADS='1'; $env:OMP_NUM_THREADS='1'; $env:MKL_NUM_THREADS='1'
python -I scripts/run.py all --preset standard
if ($LASTEXITCODE -ne 0) { throw 'Falha na execução standard' }
python -I scripts/run.py scenarios --preset smoke
python -I scripts/run.py scenarios --preset high_resolution
python -I scripts/run.py report
