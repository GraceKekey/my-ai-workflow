# HRF — Dicionário de reconstrução física em AdS/CFT

**Versão:** v0.1 — 23 de outubro de 2026  
**Natureza:** nota técnico-bibliográfica de física estabelecida e interfaces abertas com HRF-OLA.  
**Método:** Reconstrução Unificadora Progressiva (RUP), B → A.  
**Status:** estudo bibliográfico; **nenhum cálculo numérico, simulação, bancada ou alteração teórica executados**.

## 0. Resumo: o que significa “dicionário”?

[F] A correspondência AdS/CFT identifica, em classes específicas de teorias, a teoria quântica de campos conforme (CFT) em `d` dimensões espaço-temporais com uma teoria gravitacional/string no espaço assintoticamente AdS de `d+1` dimensões. **Não se trata de converter diretamente qualquer grafo ou qualquer medida de emaranhamento em gravidade.** O dicionário reúne mapas distintos:

1. **Fontes ↔ campos:** GKPW associa valores de fronteira de campos bulk a fontes de operadores CFT.
2. **Funções geradoras ↔ correladores:** variações funcionais da ação bulk renormalizada calculam correladores CFT.
3. **Operadores locais bulk ↔ operadores não locais da CFT:** reconstrução HKLL, perturbativa e condicionada.
4. **Entropia da região boundary ↔ áreas e entropia bulk:** RT, HRT, FLM, QES.
5. **Subálgebras/estados ↔ sub-regiões bulk:** código quântico holográfico, JLMS e entanglement-wedge reconstruction.
6. **Métrica bulk ↔ fontes e expectativas de energia-momento:** expansão Fefferman–Graham e renormalização holográfica.
7. **Dinâmica de geometria ↔ identidades/condições da CFT:** leis de Ward, primeira lei do emaranhamento e equações gravitacionais em regimes específicos.

Usaremos `[F]` para relações consagradas **somente nos domínios indicados**, `[H]` para conjecturas do HRF e `[?]` para interfaces não construídas.

## 1. Espaços, dimensões, parâmetros e regimes

No patch de Poincaré da AdS euclidiana:

$$
 ds^2=\frac{L^2}{z^2}(dz^2+\delta_{\mu\nu}dx^\mu dx^\nu),\qquad z>0,\quad z\to0\ \text{na boundary}.
$$

O índice `μ` percorre `d` coordenadas da CFT, incluindo o tempo na versão lorentziana. Para o exemplo arquitetural do HRF, **AdS₄/CFT₃** significa bulk `3+1` e boundary `2+1` dimensões, **não** uma boundary tridimensional espacial.

No regime semiclássico clássico, `L/ℓ_P` grande, `G_N/L^{d-1}` pequeno, e uma expansão em `1/N` controlada permitem uma descrição gravitacional efetiva. O limite exato de grande `N` e de acoplamento forte depende do par dual escolhido. O acoplamento entre `G_N`, `N` e a constante da CFT não é universal sem especificar a teoria.

## 2. GKPW — o dicionário de fontes, estados e operadores

Para um operador escalar primário `\mathcal O` e uma fonte `J(x)`:

$$
 Z_{\rm CFT}[J]\equiv\left\langle\exp\!\left(\int d^d x\, J(x)\mathcal O(x)\right)\right\rangle
 = Z_{\rm grav}\left[\phi\xrightarrow[z\to0]{}z^{d-\Delta}J(x)\right].
$$

Em aproximação de sela euclidiana, após renormalização e com convenções apropriadas:

$$
 Z_{\rm grav}[J]\simeq e^{-S^{\rm ren}_{E,\rm on\!\! -\!shell}[\phi_J]},\qquad W[J]=\log Z_{\rm CFT}[J].
$$

A identificação de fontes é **um dado de contorno**; não afirma que `J` seja uma partícula na boundary. A variação da funcional geradora fornece observáveis:

$$
 \langle\mathcal O(x)\rangle_J=\frac{\delta W[J]}{\delta J(x)},\qquad
 \langle\mathcal O(x_1)\cdots \mathcal O(x_n)\rangle_{\!c}
 =\left.\frac{\delta^n W}{\delta J(x_1)\cdots\delta J(x_n)}\right|_{J=0}.
$$

Sinais e fatores de `i` variam entre assinaturas lorentziana/euclidiana e convenções do termo de fonte. Correladores de tempo real precisam ainda de prescrição de estado/contorno temporal, não apenas da fórmula euclidiana.

### 2.1. Massa bulk e dimensão de escala da CFT

Para escalar livre em `AdS_{d+1}`:

$$
 (\nabla^2-m^2)\phi=0,\qquad m^2 L^2=\Delta(\Delta-d),
$$

$$
 \Delta_\pm=\frac d2\pm\sqrt{\frac{d^2}{4}+m^2L^2}.
$$

Na quantização-padrão, com `\Delta=\Delta_+`, a expansão assintótica genérica é:

$$
 \phi(z,x)=z^{d-\Delta}\big[J(x)+\cdots\big]
                +z^{\Delta}\big[A(x)+\cdots\big].
$$

`J` é a fonte não normalizável; `A`, corrigida por termos de contato e contratermos, determina `\langle\mathcal O\rangle`. Para escalar livre e fonte plana, esquematicamente:

$$
 \langle\mathcal O\rangle_J=(2\Delta-d)A+\text{termos locais/contratermos},
$$

com normalização da ação escolhida apropriadamente. Existem janelas de massa com quantização alternativa, termos logarítmicos em casos especiais e o limite de Breitenlohner–Freedman `m^2L^2\ge-d^2/4`.

### 2.2. Exemplo calculável do correlador de dois pontos

Conformalidade fixa a forma do correlador euclidiano escalar (até uma constante):

$$
 \langle\mathcal O(x)\mathcal O(y)\rangle
 = \frac{C_{\mathcal O}}{|x-y|^{2\Delta}}.
$$

O propagador bulk-to-boundary euclidiano, com normalização convencional, é:

$$
 K_\Delta(z,x;x')=C_\Delta\left(\frac{z}{z^2+|x-x'|^2}\right)^\Delta,
 \qquad C_\Delta=\frac{\Gamma(\Delta)}{\pi^{d/2}\Gamma(\Delta-d/2)},
$$

válido na quantização-padrão com `\Delta>d/2` e fora de sutilezas de regularização. Uma solução regular é `\phi(z,x)=\int d^dx'\,K_\Delta(z,x;x')J(x')` com o sentido distribucional de contorno adequado. Não confundir esse kernel euclidiano com o kernel lorentziano HKLL.

## 3. Campos de spin 1 e spin 2: correntes e métrica

O padrão de acoplamento de fontes é:

$$
 A_\mu^{(0)}\longleftrightarrow J^\mu_{\rm CFT},
 \qquad g_{(0)\mu\nu}\longleftrightarrow T^{\mu\nu}_{\rm CFT},
 \qquad \phi_{(0)}\longleftrightarrow\mathcal O.
$$

Para corrente global conservada, a fonte boundary é o valor assimptótico de um campo gauge bulk. Para o tensor energia-momento, a fonte é a métrica da CFT:

$$
 \delta W=\int d^dx\sqrt{|g_{(0)}|}\left(\langle\mathcal O\rangle\delta J
 +\langle J^\mu\rangle\delta A_\mu^{(0)}
 +\tfrac12\langle T^{\mu\nu}\rangle\delta g_{(0)\mu\nu}\right).
$$

A igualdade é uma definição funcional das expectativas renormalizadas sob convenções de fontes. A presença de um campo `U(1)` em um regulador HRF não basta para garantir que exista uma corrente CFT dual ou uma teoria AdS holográfica.

## 4. Fefferman–Graham: dicionário geométrico junto à boundary

$$
 ds^2=\frac{L^2}{z^2}\left[dz^2+g_{\mu\nu}(z,x)dx^\mu dx^\nu\right],
$$

$$
 g_{\mu\nu}(z,x)=g_{(0)\mu\nu}+z^2g_{(2)\mu\nu}+\cdots
 +z^d\big(g_{(d)\mu\nu}+\log(z^2)h_{(d)\mu\nu}\big)+\cdots.
$$

O termo logarítmico aparece em casos aplicáveis, notadamente para `d` par. Para gravidade de Einstein e `d>2`:

$$
 g_{(2)\mu\nu}=-\frac1{d-2}\left[R_{\mu\nu}[g_{(0)}]
 -\frac{R[g_{(0)}]}{2(d-1)}g_{(0)\mu\nu}\right].
$$

O dado normalizável contém a expectativa de energia-momento:

$$
 \langle T_{\mu\nu}\rangle=\frac{dL^{d-1}}{16\pi G_{d+1}}g_{(d)\mu\nu}
 +X_{\mu\nu}[g_{(0)},\text{fontes}],
$$

onde `X` representa termos locais de renormalização e possíveis contribuições das outras fontes. **Não** é uma prescrição genérica para recuperar toda a métrica interior apenas conhecendo `T` de um único estado.

## 5. HKLL — operadores locais do bulk a partir de operadores CFT

No limite semiclássico, para um campo escalar livre, com região e condições adequadas:

$$
 \phi(X)=\int_{\partial\mathrm{AdS}}d^dx'\,K_{\rm HKLL}(X\mid x')\,\mathcal O(x')+O(1/N).
$$

O kernel lorentziano de *smearing* `K_HKLL` depende do patch, das condições de contorno, do estado e das escolhas de reconstrução. Para campos interagentes surgem correções de múltiplos operadores (*multi-trace*):

$$
 \phi(X)=\int K_1(X|x)\mathcal O(x)
 +\frac1N\iint K_2(X|x,y):\!\mathcal O(x)\mathcal O(y)\!:
 +\cdots.
$$

Esta última expressão é **esquemática**: a ordem em `1/N` depende da normalização das fontes e operadores, e em gravidade/gauge operadores precisam de *dressing* apropriado. Reconstrução perturbativa não garante observável estritamente local gauge-invariante em gravidade quântica completa.

## 6. RT, HRT, FLM e QES — entropia e geometria

Para região espacial `A` da boundary, com `\rho_A=\mathrm{Tr}_{\bar A}\rho` quando a fatorização for legítima:

$$
 S(A)=-\mathrm{Tr}(\rho_A\log\rho_A).
$$

Na descrição estática clássica RT:

$$
 S(A)=\frac{\mathrm{Area}(\gamma_A)}{4G_N\hbar}+\cdots,
 \quad \partial\gamma_A=\partial A,
 \quad \gamma_A\sim A\quad\text{(homologia)}.
$$

Para estados dependentes do tempo (HRT), `\gamma_A` é superfície extremal codimensão 2 no espaço-tempo bulk, respeitando o vínculo de homologia:

$$
 S(A)=\frac{\mathrm{Area}(X_A)}{4G_N\hbar}+\cdots.
$$

Correção quântica FLM / entropia generalizada:

$$
 S_{\rm gen}(X)=\frac{\mathrm{Area}(X)}{4G_N\hbar}
 +S_{\rm bulk}(\Sigma_X)+S_{\rm ct}(X)+\cdots.
$$

Formulação por superfície extremal quântica (QES), em regime semiclassico apropriado:

$$
 S(A)=\min_{X\,\text{extremal}} S_{\rm gen}(X).
$$

Na forma com `\hbar=1`, o denominador é simplesmente `4G_N`. O termo de área é do **bulk**, não da célula triangular de um regulador boundary. RT/HRT/QES não afirma equivalência entre a entropia de qualquer rede discreta e a geometria de Einstein.

## 7. Wedge de emaranhamento, JLMS e reconstrução algébrica

A superfície RT/HRT divide uma região espacial bulk `r_A` cuja fronteira inclui `A` e a superfície extremal. O *entanglement wedge* é o domínio de dependência:

$$
 \mathcal E[A]=D(r_A).
$$

Num subespaço de código semiclássico e mantendo controle das correções, a relação modular JLMS toma a forma:

$$
 P_{\rm code}K_A^{\rm CFT}P_{\rm code}
 \simeq P_{\rm code}\left(\frac{\widehat{\mathrm{Area}}(X_A)}{4G_N\hbar}
 +K_{r_A}^{\rm bulk}\right)P_{\rm code}+cP_{\rm code},
$$

onde `K=-\log\rho` e os termos de área central, de referência e as ordens sublíderes exigem tratamento cuidadoso. Um corolário, até a ordem controlada, é:

$$
 S_{\rm rel}^{\rm CFT}(\rho_A\|\sigma_A)
 \simeq S_{\rm rel}^{\rm bulk}(\rho_{r_A}\|\sigma_{r_A}),
$$

com `S_rel(ρ||σ)=Tr[ρ(logρ−logσ)]` quando bem definido.

A reconstrução de operadores na região é expressa por um operador boundary `O_A` cujo efeito no código equivale ao do operador lógico bulk `O_a`:

$$
 \boxed{O_A V=V O_a\quad\text{(código exato idealizado)}}
$$

ou `\|O_AV-VO_a\|\le\epsilon` no caso aproximado, para uma isometria `V:\mathcal H_{\rm code}\to\mathcal H_{\rm CFT}`. Esse é o sentido de *reconstruction*: **a mesma ação lógica pode ter representantes físicos diferentes**, sem clonar uma excitação e sem transmitir instantaneamente entre regiões.

Um canal de recuperação `\mathcal R_A` pode ser expresso, em um modelo fatorável de código, por:

$$
 \mathcal R_A\left(\mathrm{Tr}_{\bar A}[V\rho_LV^\dagger]\right)\approx\rho_L.
$$

A reconstruibilidade de um **operador** é diferente da aplicação de um decoder físico e também não representa automaticamente a criação local de uma partícula.

## 8. Estados, correladores, geometria e dinâmica gravitacional

A correspondência é mais do que fórmulas cinemáticas. Quando uma teoria dual existe, estados boundary e bulk são identificados de maneira apropriada:

$$
 |\Psi\rangle_{\rm CFT}\ \longleftrightarrow\ |\Psi\rangle_{\rm bulk/string}.
$$

No setor de baixas energias e em regime semiclassico, alguns estados admitirão geometria efetiva `g_{MN}`. Não existe geometria clássica suave associada a todo estado da CFT.

A primeira lei do emaranhamento, para variações infinitesimais em torno de um estado de referência com modular Hamiltoniano `K_A=-\log\rho_A^{(0)}`:

$$
 \delta S_A=\delta\langle K_A\rangle.
$$

Na CFT de vácuo, para uma bola de raio `R` em uma fatia temporal plana:

$$
 K_A=2\pi\int_{|\mathbf x|<R}d^{d-1}x\,
 \frac{R^2-|\mathbf x|^2}{2R}\,T_{00}(\mathbf x),
$$

com `\hbar=1` e normalização relativística padrão. Em famílias adequadas de estados holográficos, a primeira lei mais RT e as identidades gravitacionais recuperam **equações de Einstein linearizadas** em torno de AdS; isso não estabelece uma derivação universal da gravidade não linear a partir de qualquer emaranhamento.

## 9. Tabela compacta: mapa de entrada → saída e condições

| Setor | Entrada boundary | Saída bulk | Relação central | Condição decisiva |
|---|---|---|---|---|
| GKPW | fonte `J` de `O` | valor assintótico de `φ` | `Z_CFT[J]=Z_bulk[J]` | dual específico, renormalização |
| Escalar | dimensão `Δ` | massa `m` | `m²L²=Δ(Δ−d)` | escalar em AdS, quantização escolhida |
| Currente | `J^μ`, fonte `A₍₀₎` | campo gauge | `A₍₀₎↔J` | simetria global conservada e dual |
| Stress tensor | `T_{μν}`, fonte métrica | métrica e gráviton | `g₍₀₎↔T`, FG | gravidade assintoticamente AdS |
| HKLL | operadores CFT | campo bulk local efetivo | `φ=∫K_HKLL O+…` | semiclassico, código/patch |
| RT/HRT | entropia `S(A)` | superfície extremal | `S=A/(4G_N)` | estado holográfico e regime clássico |
| FLM/QES | `S(A)` com correções | área + entropia bulk | `S=min ext S_gen` | teoria semiclássica |
| JLMS | modular/entropia relativa | operador área + modular bulk | `K_A≈A/(4G)+K_a` | subespaço de código |
| EWR | álgebra boundary em `A` | álgebra bulk no wedge | `O_A V≈V O_a` | subespaço de código, wedge |
| Gravidade linear | `δS=δ⟨K⟩` | `δG_{MN}+Λδg_{MN}=8πGδT_{MN}` | primeira lei + RT | perturbações em estado holográfico |

## 10. Interface explícita com HRF-OLA — o que ainda NÃO existe

**Documentação HRF atual:** na proposta do Capítulo 3 v0.2 (22/10/2026), *DIO* é organização informacional distribuída [H] e *GMFt* é manifestação contextual/local candidata [H]. Isso substitui **prospectivamente** o uso amplo histórico de GMFt, sem reclassificar resultados antigos. As hipóteses `R/R′` permanecem distintas da notação usual de região boundary `A` e complemento `\bar A`.

| Interface almejada | Necessário demonstrar | Estado |
|---|---|---|
| Base HRF → CFT holográfica | Hilbert/álgebra, Hamiltoniano, simetrias conformes, grande `N`, espectro e correladores compatíveis | [?] Ausente |
| DIO → operador/código da CFT | isometria, subálgebras, setor lógico, persistência e observáveis de identificação | [?] Ausente |
| DIO → GMFt | canal físico de manifestação, resposta causal, energia, ausência de dupla contagem | [?] Ausente |
| GMFt → campo bulk | fontes/operadores e correlação massa–dimensão, spin, gauge, dicionário HKLL | [?] Ausente |
| Emaranhamento → geometria | estado holográfico, superfície QES, concordância entre entropias e dinâmica | [?] Ausente |
| R/R′ histórico | distinguir descrições do mesmo sistema de boundaries fisicamente separadas | [?] Indecidido |
| Boundary 2D do HRF → bulk 3D | exemplo AdS₄/CFT₃ genuíno, métrica, operadores, causalidade e propagação | [?] Ausente |

[D] **Sequência RUP B → A recomendada:** (1) reproduzir teoricamente um exemplo GKPW escalar em AdS fixo; (2) derivar correlador de dois pontos; (3) identificar kernel HKLL e seus limites; (4) reconstruir um operador lógico em um código holográfico de referência; (5) verificar RT/JLMS no domínio conhecido; **só então** perguntar se a base/DIO do HRF realiza a mesma estrutura, com diferenciais falsificáveis. Nenhuma etapa requer postular de início GMFt como partícula.

## 11. Fontes e proveniência — IDs preservados

As seguintes referências constam do *HRF Caderno Mestre de Referências v0.2*; os IDs são reaproveitados, **sem renumeração**.

- **[HRF-REF-0012]** Maldacena, J. (1998), *The Large N Limit of Superconformal Field Theories and Supergravity*. DOI: https://doi.org/10.4310/ATMP.1998.v2.n2.a1 — dualidade fundacional.
- **[HRF-REF-0013]** Ryu, S.; Takayanagi, T. (2006), *Holographic Derivation of Entanglement Entropy from AdS/CFT*. DOI: https://doi.org/10.1103/PhysRevLett.96.181602 — RT.
- **[HRF-REF-0014]** Hubeny, V. E.; Rangamani, M.; Takayanagi, T. (2007), *A Covariant Holographic Entanglement Entropy Proposal*. DOI: https://doi.org/10.1088/1126-6708/2007/07/062 — HRT.
- **[HRF-REF-0015]** Almheiri, A.; Dong, X.; Harlow, D. (2015), *Bulk Locality and Quantum Error Correction in AdS/CFT*. DOI: https://doi.org/10.1007/JHEP04(2015)163 — estrutura de código.
- **[HRF-REF-0016]** Pastawski, F.; Yoshida, B.; Harlow, D.; Preskill, J. (2015), *Holographic Quantum Error-Correcting Codes*. DOI: https://doi.org/10.1007/JHEP06(2015)149 — código toy model.
- **[HRF-REF-0017]** Dong, X.; Harlow, D.; Wall, A. C. (2016), *Reconstruction of Bulk Operators within the Entanglement Wedge*. DOI: https://doi.org/10.1103/PhysRevLett.117.021601 — reconstrução de operadores.
- **[HRF-REF-0018]** Harlow, D. (2018), *TASI Lectures on the Emergence of Bulk Physics in AdS/CFT*. DOI: https://doi.org/10.22323/1.305.0002 — revisão técnica.
- **[HRF-REF-0033]** Lewkowycz, A.; Maldacena, J. (2013), *Generalized Gravitational Entropy*. DOI: https://doi.org/10.1007/JHEP08(2013)090 — réplica gravitacional.
- **[HRF-REF-0034]** Faulkner, T.; Lewkowycz, A.; Maldacena, J. (2013), *Quantum Corrections to Holographic Entanglement Entropy*. DOI: https://doi.org/10.1007/JHEP11(2013)074 — entropia bulk.
- **[HRF-REF-0036]** Jafferis, D. L.; Lewkowycz, A.; Maldacena, J.; Suh, S. J. (2016), *Relative Entropy Equals Bulk Relative Entropy*. DOI: https://doi.org/10.1007/JHEP06(2016)004 — JLMS.
- **[HRF-REF-0038]** Faulkner, T.; Guica, M.; Hartman, T.; Myers, R. C.; Van Raamsdonk, M. (2014), *Gravitation from Entanglement in Holographic CFTs*. DOI: https://doi.org/10.1007/JHEP03(2014)051 — gravidade linear.
- **[HRF-REF-0041]** Kabat, D.; Lifschytz, G. (2013), *CFT Representation of Interacting Bulk Gauge Fields in AdS*. DOI: https://doi.org/10.1103/PhysRevD.87.086004 — gauge e dressing.

**Fontes primárias complementares (ainda sem ID mestre atribuído; não inventar HRF-REF):**

- Gubser, S. S.; Klebanov, I. R.; Polyakov, A. M. (1998), *Gauge Theory Correlators from Non-Critical String Theory*. https://arxiv.org/abs/hep-th/9802109 — GKPW.
- Witten, E. (1998), *Anti De Sitter Space and Holography*. https://arxiv.org/abs/hep-th/9802150 — GKPW.
- Hamilton, A.; Kabat, D.; Lifschytz, G.; Lowe, D. A. (2006), *Holographic Representation of Local Bulk Operators*. DOI: https://doi.org/10.1103/PhysRevD.74.066009 — HKLL.
- de Haro, S.; Solodukhin, S. N.; Skenderis, K. (2001), *Holographic Reconstruction of Spacetime and Renormalization in the AdS/CFT Correspondence*. https://arxiv.org/abs/hep-th/0002230 — FG e renormalização holográfica.

**Documentos HRF efetivamente consultados para este texto:** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`; `HRF_Caderno_Mestre_de_Referencias_v0_2_PT_2026-10-10.md`; `HRF_Research_Book_Cap03_Base_Quantica_Compartilhada_DIO_e_GMFt_v0_2_PT_2026-10-22.md`; nota de arquitetura boundary 2D–bulk 3D. As fontes públicas foram usadas para confrontar formulações; os mecanismos do HRF permanecem hipóteses abertas.

**Nota de governança bibliográfica:** esta nota reutiliza IDs existentes e **não altera o Caderno Mestre**. As quatro entradas complementares devem ser reconciliadas com a fila de pendências antes de ganhar identificadores novos.
