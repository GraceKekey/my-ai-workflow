# HRF — Caderno de Pesquisa Bibliográfica — versão cumulativa v1.6

**Atualização:** 18/10/2026 01:08 BRT · CP-18 · HRF-REF-0001 a HRF-REF-0108.  
**Método:** RUP B→A, mapas G/W/D separados e classes [F]/[M]/[H]/[?]/[D].  
**Preservação literal:** a seção histórica incorpora **byte por byte** todo o caderno v1.5 (CP-01–CP-17), seguido do checkpoint CP-18 integral. Os cabeçalhos históricos permanecem como proveniência e não representam o estado corrente.  
**SHA-256 do arquivo v1.5 integral incorporado:** `5ad4630b2627b6199dcd58c160b004055aa9e06702dbd7b1a69eaaf606181cfb`.  
**Índice de títulos correspondente:** `HRF_Caderno_Referencias_v1_8_PT_2026-10-18_0108_BRT.md` (108 IDs imutáveis).

---

# ARQUIVO HISTÓRICO INTEGRAL — v1.5 (CP-01 a CP-17)

# HRF — Caderno de Pesquisa Bibliográfica — versão cumulativa v1.5

**Atualização:** 17/10/2026 13:10 BRT · CP-17 · HRF-REF-0001 a HRF-REF-0105.  
**Método:** RUP B → A; mapas G/W/D separados; classes [F]/[M]/[H]/[?]/[D].  
**Preservação literal:** o bloco histórico seguinte contém, **byte por byte**, todo o arquivo v1.4 (CP-01 a CP-16), seguido pelo CP-17 integral. Os arquivos anteriores não foram editados nem renumerados.  
**SHA-256 da v1.4 incorporada:** `1cfa3524cdf09e1e1e8f7d8ede7d260f2910783f7dc9900b6f81d7efc15a1ad1`.  

---

# ARQUIVO HISTÓRICO INTEGRAL — v1.4 (CP-01 a CP-16)

# HRF — Caderno de Pesquisa Bibliográfica — versão cumulativa v1.4

**Atualização:** 17/10/2026 01:08 BRT · CP-16 · HRF-REF-0001 a HRF-REF-0102.  
**Método:** RUP B → A; G/W/D separados; classes [F]/[M]/[H]/[?]/[D].  
**Proveniência:** o bloco histórico abaixo é uma cópia byte a byte de v1.3 (CP-01 a CP-15), seguida do CP-16 integral. Nenhum resultado antigo foi removido, renumerado ou reclassificado retroativamente.

---

# ARQUIVO HISTÓRICO INTEGRAL — v1.3 / CP-01 a CP-15

# HRF — Caderno de Pesquisa Bibliográfica — versão cumulativa v1.3

**Atualização:** 16/10/2026 13:02 BRT · CP-15 · HRF-REF-0001 a HRF-REF-0098.  
**Conteúdo:** a seção de arquivo histórico abaixo preserva **integralmente, sem edição**, o caderno cumulativo CP-14 v1.2 (incluindo CP-01–CP-14). Depois dela está incorporado CP-15 com fórmulas, status de leitura/uso, controles, fontes, lacunas e histórico.  
**Regra:** este documento é autossuficiente; versões anteriores não são sobrescritas. As linhas de metadados antigas dentro da seção histórica são registros preservados, não o status corrente.

---

# ARQUIVO HISTÓRICO INTEGRAL — v1.2 / CP-01 a CP-14

# HRF — Caderno de Pesquisa Bibliográfica
## RT, reconstrução holográfica e ponte QFT–geometria


**Versão:** v1.1  
**Data:** 15 de outubro de 2026 (13:08 BRT)  
**Projeto:** Holographic Reconstruction Framework (HRF)  
**Natureza:** caderno cumulativo de pesquisa bibliográfica — incorpora CP-01 a CP-13, preservando a proveniência.  
**Método:** Reconstrução Unificadora Progressiva (RUP), B → A: primeiro física estabelecida e suas interfaces; depois hipóteses de fundamentação comum.  
**Status:** pesquisa em andamento; nenhum gap de literatura é declarado definitivo apenas por ausência em buscas parciais.


> **Estado mais recente:** CP-13, 15/10/2026 13:08 BRT; referências 0001–0093, G-GAUGE-6. CP-12 foi reconciliado no Drive. Este arquivo preserva integralmente CP-01–CP-12 e acrescenta a seção 32.

> **Regra de uso.** Este é o documento principal da pesquisa bibliográfica. A cada checkpoint de 12 h, as novidades devem ser incorporadas cumulativamente aqui. Os checkpoints individuais permanecem como histórico temporal, mas o caderno mais recente deve ser suficiente para recuperar o estado acumulado da pesquisa.



## ESTADO HISTÓRICO — CP-07, 12/10/2026 13:09 BRT

Novidade do CP-07: referências 0071–0074 e gate G-GAUGE para definição de álgebra/edge modes/entropia em teorias gauge antes de testes RT ou alegações sobre QED4. As conclusões e o estado da pesquisa do CP-06 seguem integralmente abaixo.

## ESTADO ANTERIOR — CP-06, 12/10/2026
A v0.4 incorpora integralmente a v0.3 (CP-01–CP-05) e o novo CP-06. O Capítulo 0.1 v0.1/v0.2 foi lido. Leitura de equações e hipóteses de Takeda [0052], Tjoa–Gray [0055], Sugiura–Takeda [0064], Bousso–Kaya [0067], sem réplica integral das provas. Referências novas [0069] Saravani et al. (2016), seções II–III consultadas, apêndice pendente; [0070] Dappiaggi et al. (2017), resumo consultado, leitura integral pendente. Auditoria algébrica interna de Val Baker [0031] já concluída em 09/10/2026. Nenhuma simulação executada. Gate aberto: independência do mapa Γ, smearing e informação geométrica. QED4 → bulk dinâmico → massa do elétron continua lacuna bibliográfica provisória.

## 1. Pergunta central


Até que ponto a literatura já construiu uma ponte matemática explícita entre estados/campos quânticos tradicionais e geometria gravitacional emergente — por RT/HRT, correções quânticas, QES, entanglement wedge reconstruction, JLMS, first law de emaranhamento e reconstruções inversas de métrica — e qual gap ainda permanece entre MQ/QFT padrão e gravidade relativística?


Subperguntas prioritárias:


1. O emaranhamento determina geometria? Em que classe de teorias e com quais hipóteses?
2. Dados de entropia podem reconstruir uma métrica completa ou apenas setores/perturbações?
3. As equações de Einstein podem ser obtidas a partir do emaranhamento e em que ordem perturbativa?
4. Campos bulk escalares, gauge e fermiónicos podem ser reconstruídos explicitamente?
5. Há uma ponte específica para um elétron físico da QED 3+1?
6. A massa pode emergir da informação/entropia, ou aparece apenas como parâmetro do dicionário holográfico?
7. Existe uma reconstrução convincente fora de AdS, especialmente em espaço-tempo aproximadamente Minkowski e para sistemas físicos finitos?
8. Qual é o menor passo realmente novo e testável que o HRF poderia executar sem ultrapassar o que a literatura já demonstrou?


## 2. Documentação interna HRF usada como enquadramento


- Capítulo 0.1 — Diretrizes de Reconstrução Unificadora Progressiva: estratégia B → A, proveniência, interfaces e classificação epistêmica.
- Esqueleto do Research Book: arquitetura HRF-PD / HRF-ST / HRF-FM.
- Capítulo 2 — Onda fotônica livre: setor U(1) relacional como modelo efetivo, sem derivação de U(1), ℏ ou matéria carregada.
- Nota de arquitetura boundary 2D / bulk 3D: separação entre **G** (reconstrução geométrica), **W** (propagação de ondas) e **D** (dicionário boundary↔bulk).
- Harlow, *TASI Lectures on the Emergence of Bulk Physics in AdS/CFT*, como revisão técnica de referência.


## 3. Estado acumulado — RT, HRT e entropia gravitacional


### 3.1 RT — [E] no domínio holográfico semiclassico estático


Ryu–Takayanagi associa a entropia de emaranhamento de uma região boundary à área de uma superfície mínima codimensão 2 no bulk:


\[
S_A = \frac{\mathrm{Area}(\gamma_A)}{4G_N}.
\]


A fórmula é uma relação de AdS/CFT sob hipóteses específicas; não é uma regra universal aplicável a qualquer estado quântico. **Referência:** [HRF-REF-0013].


### 3.2 HRT — [E] como extensão covariante no domínio apropriado


Hubeny–Rangamani–Takayanagi substitui a superfície mínima estática por uma superfície extremal covariante em geometrias dependentes do tempo. **Referência:** [HRF-REF-0014].


### 3.3 Replica gravity / generalized gravitational entropy — [E/P]


Lewkowycz–Maldacena fornece uma derivação gravitacional por réplica da estrutura RT em uma classe controlada de dualidades. **Referência:** [HRF-REF-0033].


### 3.4 FLM — correção quântica líder — [E]


Faulkner–Lewkowycz–Maldacena acrescenta a entropia dos campos quânticos no bulk à contribuição de área, esquematicamente:


\[
S_A = \frac{A(\gamma_A)}{4G_N} + S_{\rm bulk} + \cdots .
\]


**Referência:** [HRF-REF-0034].


### 3.5 Quantum Extremal Surfaces — [E/P]


Engelhardt–Wall promove a superfície extremal à extremização da entropia generalizada:


\[
S_{\rm gen}[X]
= \frac{\langle A[X]\rangle}{4G_N}
+ S_{\rm bulk}[X] + \text{contratermos/correções}.
\]


A QES satisfaz \(\delta S_{\rm gen}/\delta X=0\). **Referência:** [HRF-REF-0035].


**Estado acumulado:** a cadeia RT → HRT → FLM → QES é bem desenvolvida em holografia semiclassica, mas não fornece sozinha uma transformação universal “estado de QFT arbitrário → espaço-tempo gravitacional”.


## 4. Emaranhamento → dinâmica gravitacional


### 4.1 First law de emaranhamento


Para uma perturbação em torno de um estado de referência:


\[
\delta S_A = \delta \langle K_A\rangle ,
\]


onde \(K_A\) é o Hamiltoniano modular. Em bolas da CFT no vácuo, \(K_A\) possui forma local relacionada a \(T_{00}\).


### 4.2 Einstein linearizado em AdS — [E] sob hipóteses holográficas


Lashkari–McDermott–Van Raamsdonk e Faulkner et al. mostraram que first law + dicionário holográfico para todas as bolas apropriadas impõem as equações de Einstein linearizadas em torno de AdS. **Referências:** [HRF-REF-0037], [HRF-REF-0038].


Isso é uma ponte matemática profunda, mas deve ser descrita corretamente: **não deriva GR de uma QFT arbitrária**; deriva restrições gravitacionais dentro de uma classe de CFTs com dual semiclassico.


### 4.3 Jacobson — dois caminhos relacionados mas distintos


Jacobson (1995) interpreta a equação de Einstein como uma equação de estado de termodinâmica local de horizontes. **Referência:** [HRF-REF-0039].


Jacobson (2016) usa equilíbrio de emaranhamento do vácuo em pequenas bolas geodésicas para relacionar variações de entropia e geometria às equações de Einstein sob hipóteses explícitas. **Referência:** [HRF-REF-0040].


### 4.4 JLMS e entanglement wedge


JLMS relaciona entropia relativa da boundary e do bulk no regime apropriado e fornece uma relação modular/área no code subspace. **Referência:** [HRF-REF-0036].


Dong–Harlow–Wall formaliza reconstrução de operadores dentro do entanglement wedge. **Referência:** [HRF-REF-0017].


Harlow apresenta a equivalência, em formalizações reguladas de código, entre reconstrução de álgebra no wedge, fórmula RT quântica e igualdade de entropia relativa. **Referência:** [HRF-REF-0018].


**Conclusão acumulada:** há uma ponte explícita **em holografia controlada** entre informação quântica e dinâmica gravitacional perturbativa. O gap está em transformar isso em uma construção universal para QFTs físicas não holográficas conhecidas, especialmente QED4.


## 5. Reconstrução explícita de geometria


### 5.1 Geometria a partir de emaranhamento — precedentes


Cao–Carroll–Michalakis mostra que estrutura de informação mútua pode definir uma geometria de melhor ajuste sob hipóteses de fatorização/localidade. **Referência:** [HRF-REF-0008].


### 5.2 Tensor networks


HaPPY e quantum error correction reproduzem estruturalmente leis do tipo RT em toy models. **Referências:** [HRF-REF-0015], [HRF-REF-0016].


Swingle/MERA fornece um precedente de interpretar estrutura multiescala de emaranhamento como geometria emergente. **Referência:** [HRF-REF-0047].


Random tensor networks reproduzem propriedades holográficas e leis de área em regimes apropriados. **Referência:** [HRF-REF-0048]. Esta fonte foi identificada e consultada, mas ainda não foi usada como evidência primária em uma conclusão final.


### 5.3 Reconstrução métrica recente


Ji et al. (2025) explora reconstrução métrica holográfica usando informação mútua condicional e escolha explícita de gauge. **Referência:** [HRF-REF-0045].


Jokela et al. (2025) apresenta reconstrução perturbativa da métrica a partir de variações de áreas mínimas/dados de emaranhamento, incluindo recuperação de classes de deformações como Schwarzschild–AdS no regime tratado. **Referência:** [HRF-REF-0046].


### 5.4 Linhas que estavam pendentes até o CP-02 (ver atualizações CP-03/CP-04 abaixo)


- hole-ography / differential entropy;
- kinematic space / integral geometry;
- boundary rigidity e entanglement tomography;
- algoritmos de inversão/machine learning posteriores;
- condições de unicidade, entanglement shadows e estabilidade numérica.


**Estado acumulado:** já existem reconstruções reais de geometria, mas tipicamente dentro de classes geométricas/holográficas previamente estruturadas. Ainda não há uma regra geral “matriz densidade arbitrária → métrica completa de GR”.


## 6. Campos bulk e reconstrução de operadores


### 6.1 Bulk reconstruction


A literatura HKLL e extensões reconstrói campos bulk perturbativos a partir de operadores boundary. O artigo HKLL de 2006 foi normalizado como [HRF-REF-0049] no CP-03; outros trabalhos da série ainda exigem normalização.


### 6.2 Gauge e operadores carregados


Kabat–Lifschytz mostra que a lei de Gauss impõe não-localidade/dressing na reconstrução de campos gauge e matéria carregada. **Referência:** [HRF-REF-0041].


Marolf–Ross mostra que diferentes condições de contorno para campos vetoriais alteram o dicionário boundary; em particular, um U(1) no bulk não deve ser identificado automaticamente com o fóton dinâmico da QED4. **Referência:** [HRF-REF-0044].


### 6.3 Spinors


Foit–Kabat–Lifschytz reconstrói spinors livres no bulk de AdS/CFT. **Referência:** [HRF-REF-0042].


Lifschytz–Patra trata dressing de spinors em AdS3 com Chern–Simons. **Referência:** [HRF-REF-0043].


**Conclusão acumulada:** “reconstruir um férmion holograficamente” já existe. Isso não equivale a reconstruir o **elétron físico do Modelo Padrão/QED4**.


## 7. Massa no dicionário holográfico


Para um escalar em AdS_{d+1}:


\[
m^2L^2 = \Delta(\Delta-d).
\]


Para um spinor em quantização padrão:


\[
\Delta = \frac{d}{2} + |mL|
\]


(com detalhes de sinal, quiralidade e quantização alternativa dependendo do caso).


O ponto conceitual central é:


> **massa–dimensão é um dicionário espectral**, não uma derivação geral da massa a partir do emaranhamento.


Até aqui não foi encontrado um resultado mainstream que derive a massa física conhecida do elétron exclusivamente da geometria/entropia holográfica.


## 8. Elétron, QED4 e 511 keV


### 8.1 O que já existe


Há literatura de:
- holographic fermions;
- finite-density fermions;
- electron stars;
- spinors bulk;
- charged operators e dressings.


Essas linhas ainda serão examinadas uma a uma, mas **não podem ser identificadas por nomenclatura com o elétron real da QED**.


### 8.2 Val Baker–Haramein–Alirol (2019)


O artigo *The electron and the holographic mass solution* existe e afirma reproduzir a massa do elétron por uma “generalized holographic approach”. **Referência:** [HRF-REF-0031].


A auditoria do checkpoint 2 encontrou a seguinte estrutura algébrica, conforme a extração disponível:


\[
\Phi_e = \frac{\eta_e}{R_e}
       = \frac{2\ell_P}{a_0},
\]


e


\[
m_e = \frac{1}{2\alpha}\Phi_e m_P
     = \frac{\hbar}{\alpha c a_0}.
\]


Entretanto, o raio de Bohr convencional satisfaz:


\[
a_0 = \frac{\hbar}{\alpha m_e c}.
\]


Logo, se o valor convencional de \(a_0\) é utilizado como entrada, a expressão final reproduz algebricamente a massa já contida na definição do raio. Isso é uma **forte indicação de dependência circular do dado de entrada** para a alegação de previsão independente de 511 keV.


**Status:** [F] auditoria algébrica interna concluída em 09/10/2026 (Val Baker/E69); réplica externa opcional. Isso não prova que todas as hipóteses físicas do artigo são falsas; mostra que o valor de 511 keV não deve ser tratado como validação independente sem derivação de \(a_0\) que não use \(m_e\).


### 8.3 Gap específico atualmente em busca


Até o estado acumulado deste caderno, **não foi identificado um trabalho padrão e aceito** que execute a cadeia:


\[
\text{estado físico do elétron em QED4}
\rightarrow
\text{dados de emaranhamento/operadores}
\rightarrow
\text{RT/HRT/QES ou reconstrução equivalente}
\rightarrow
\text{geometria bulk}
\rightarrow
\text{massa física de 511 keV}.
\]


Isto é **busca aberta**, não declaração de inexistência absoluta.


## 9. Além de AdS


Linhas já identificadas:
- flat-space holography;
- celestial holography;
- dS/CFT;
- causal diamonds / holographic screens;
- holografia de sistemas finitos e propostas de local holography.


Até o checkpoint 2, nenhuma dessas linhas havia sido classificada como um dual completo e consensual capaz de reconstruir diretamente um elétron, átomo ou objeto astrofísico finito em espaço-tempo aproximadamente Minkowski. A leitura primária deste bloco ainda está pendente.


## 10. Mapa acumulado provisório


| Pergunta | Estado provisório | Síntese |
|---|---|---|
| Entropia/emaranhamento → geometria? | **[E/P]** | Sim em classes holográficas/estruturadas. |
| Entropia → métrica completa? | **[P]** | Sim em problemas inversos restritos; não universal. |
| Emaranhamento → Einstein? | **[E/P]** | Einstein linearizado e extensões em regimes controlados; não GR universal de QFT arbitrária. |
| Entanglement wedge reconstruction? | **[E]** | Bem estabelecida no code subspace adequado. |
| Bulk spinors? | **[E]** | Sim. |
| Campos gauge/charged operators? | **[E/P]** | Sim, com dressing e sutilezas de Gauss. |
| Elétron holográfico genérico? | **[E/T]** | Existem “holographic fermions/electron stars”, mas são modelos holográficos, não o elétron físico. |
| Elétron real da QED4 → geometria bulk? | **[G]** | Nenhuma construção padrão aceita localizada até agora. |
| Massa como parâmetro holográfico? | **[E]** | Dicionário massa–dimensão. |
| Massa do elétron derivada holograficamente? | **[G/?]** | Propostas existem, mas nenhuma derivação RT/QED4 independente aceita foi localizada. |
| Minkowski/finite systems com dual completo? | **[P/C]** | Há reconstrução métrica em espaço assintoticamente plano por correladores de campos livres [HRF-REF-0055], mas não um dual gravitacional dinâmico universal. |


**Legenda deste caderno:** [E] estabelecido no domínio indicado · [P] parcial · [T] toy/proof of concept · [C] conjectural · [G] gap ainda aberto.


## 11. Rastreador de referências desta pesquisa


| ID | Status de uso | Papel neste caderno |
|---|---|---|
| `HRF-REF-0008` | **USADO** | Space from Hilbert space: Recovering geometry from bulk entanglement |
| `HRF-REF-0013` | **USADO** | Holographic derivation of entanglement entropy from AdS/CFT |
| `HRF-REF-0014` | **USADO** | A covariant holographic entanglement entropy proposal |
| `HRF-REF-0015` | **USADO** | Bulk locality and quantum error correction in AdS/CFT |
| `HRF-REF-0016` | **USADO** | Holographic quantum error-correcting codes: Toy models for the bulk/boundary correspondence |
| `HRF-REF-0017` | **USADO** | Reconstruction of bulk operators within the entanglement wedge in gauge-gravity duality |
| `HRF-REF-0018` | **USADO** | TASI lectures on the emergence of bulk physics in AdS/CFT |
| `HRF-REF-0031` | **USADO / AUDITADO CRITICAMENTE** | The electron and the holographic mass solution |
| `HRF-REF-0033` | **USADO** | Generalized gravitational entropy |
| `HRF-REF-0034` | **USADO** | Quantum corrections to holographic entanglement entropy |
| `HRF-REF-0035` | **USADO** | Quantum extremal surfaces: Holographic entanglement entropy beyond the classical regime |
| `HRF-REF-0036` | **USADO** | Relative entropy equals bulk relative entropy |
| `HRF-REF-0037` | **USADO** | Gravitational dynamics from entanglement “thermodynamics” |
| `HRF-REF-0038` | **USADO** | Gravitation from entanglement in holographic CFTs |
| `HRF-REF-0039` | **USADO** | Thermodynamics of spacetime: The Einstein equation of state |
| `HRF-REF-0040` | **USADO** | Entanglement equilibrium and the Einstein equation |
| `HRF-REF-0041` | **USADO** | CFT representation of interacting bulk gauge fields in AdS |
| `HRF-REF-0042` | **USADO** | Bulk reconstruction for spinor fields in AdS/CFT |
| `HRF-REF-0043` | **USADO** | Dressing bulk spinor fields in AdS3 |
| `HRF-REF-0044` | **USADO** | Boundary conditions and new dualities: Vector fields in AdS/CFT |
| `HRF-REF-0045` | **USADO** | Holographic geometry/real-space entanglement correspondence and metric reconstruction |
| `HRF-REF-0046` | **USADO** | Bulk metric reconstruction from entanglement data via minimal surface area variations |
| `HRF-REF-0047` | **CONSULTADO / USADO COMO PRECEDENTE** | Entanglement renormalization and holography |
| `HRF-REF-0048` | **CONSULTADO / AINDA NÃO USADO COMO EVIDÊNCIA PRIMÁRIA** | Holographic duality from random tensor networks |


### 11.1 Referências identificadas mas ainda pendentes de leitura/normalização


- `HRF-PEND-017` — Dong (2014), higher-derivative holographic entanglement entropy.
- `HRF-PEND-018` — Dong–Lewkowycz–Rangamani, derivação covariante de entropia holográfica.
- `HRF-PEND-019` — Dong–Lewkowycz, extremalidade/equações de movimento.
- `HRF-PEND-020` — Blanco–Casini–Hung–Myers, relative entropy and holography.
- `HRF-PEND-021` — série HKLL.
- `HRF-PEND-022` — hole-ography.
- `HRF-PEND-023` — kinematic space / integral geometry.
- `HRF-PEND-024` — electron stars.
- `HRF-PEND-025` — holographic non-Fermi liquids.
- `HRF-PEND-026` — celestial/flat-space holography.
- `HRF-PEND-027` — dS/CFT.


## 12. Histórico dos checkpoints incorporados


### CP-01 — 09/10/2026 13:05 BRT


**Contribuições incorporadas neste caderno:**
- mapa inicial RT/HRT/FLM/QES;
- first law, JLMS e Einstein-from-entanglement;
- hole-ography, kinematic space e tensor networks como frentes;
- campos bulk, spinors e dressing como literatura existente;
- distinção massa–dimensão versus massa derivada;
- descoberta de Val Baker et al. (2019);
- primeiro gap operacional QED4/elétron real;
- primeiro mapa além de AdS.


**Arquivo histórico:** `HRF_Checkpoint_Pesquisa_RT_QFT_Geometria_2026-10-09_1305_BRT.md`.


### CP-02 — 10/10/2026 01:00 BRT


**Novidades incorporadas cumulativamente:**
- auditoria algébrica de Val Baker e identificação da dependência via raio de Bohr;
- identificação explícita de reconstrução de spinors em AdS/CFT;
- exemplos de spinors carregados/dressing;
- distinção entre U(1) bulk e fóton dinâmico de QED4;
- trabalhos de reconstrução métrica de 2025;
- refinamento do gap “QED4 → RT/HRT/QES → bulk”;
- regra de não declarar originalidade por busca negativa limitada.


**Arquivo histórico:** `HRF_Checkpoint_Bibliografia_2026-10-10_0100_BRT.md`.


## 13. Próximo bloco de pesquisa (plano histórico do CP-02)


1. Conferir diretamente a versão tipográfica do artigo de Val Baker, especialmente equações 19–27 e parâmetros de entrada.
2. Completar matriz RT/HRT/QES/JLMS/Einstein: hipóteses, ordem em \(G_N\), regime, observáveis e limites.
3. Normalizar e ler HKLL, hole-ography, kinematic space e entanglement tomography.
4. Ler electron stars e holographic non-Fermi liquids, separando terminologia “electron” de QED/Modelo Padrão.
5. Executar busca negativa reprodutível para QED4 real / elétron físico / 511 keV.
6. Auditar flat-space, celestial e dS holography.
7. Só depois propor “Possíveis nichos originais para o HRF”.


## 14. Regra de atualização daqui em diante


Cada ciclo de 12 h deve:


1. produzir um checkpoint curto datado;
2. incorporar **tudo que for novo** à próxima versão deste caderno, mantendo o estado acumulado;
3. atualizar o status das referências aqui, não no índice enxuto;
4. acrescentar novos `HRF-REF-####` somente depois de normalização;
5. manter o **Caderno de Referências** separado como índice mínimo `ID → título`;
6. preservar versões anteriores e checkpoints individuais como proveniência.






## 15. CP-03 incorporado — 10/10/2026 13:08 BRT


**Fonte histórica:** `HRF_Checkpoint_Bibliografia_2026-10-10_1308_BRT.md` (cópia preservada no Drive). Esta seção corrige explicitamente as lacunas excessivamente amplas da versão anterior.


### 15.1 Reconstrução geométrica mais completa — [F] dentro de classes restritas


**[HRF-REF-0052] Takeda (2022):** `Light-cone cuts and hole-ography: explicit reconstruction of bulk metrics`, JHEP 04 (2022) 124, DOI 10.1007/JHEP04(2022)124. Combina *light-cone cuts* (informação causal/conformal) e *hole-ography* (informação de área/comprimento) para reconstruir métricas completas de espaços-tempos estáticos localmente AdS3, com demonstrações em AdS3, soliton e BTZ. O domínio requer uma classe em que *entanglement wedge* e *causal wedge* coincidam; não é uma inversão universal de QFT.


**[HRF-REF-0050] Balasubramanian et al. (2014):** `Bulk curves from boundary data in holography`, Phys. Rev. D 89, 086004, DOI 10.1103/PhysRevD.89.086004. *Differential entropy* para reconstruir áreas/comprimentos de curvas bulk em classes holográficas.


**[HRF-REF-0051] Czech et al. (2015):** `Integral geometry and holography`, JHEP 10 (2015) 175, DOI 10.1007/JHEP10(2015)175. *Kinematic space* e volumes de Crofton a partir de dados entrópicos em AdS3/CFT2. O espaço cinemático não deve ser confundido com a própria métrica Lorentziana bulk sem hipóteses adicionais.


**[HRF-REF-0061] Czech, Dong & Sully (2014):** `Holographic reconstruction of general bulk surfaces`, JHEP 11 (2014) 015, DOI 10.1007/JHEP11(2014)015. Extensão de entropia diferencial para classes de superfícies bulk em dimensões gerais, sob folheação e condições específicas.


### 15.2 Reconstrução fora de AdS — correção essencial


**[HRF-REF-0055] Tjoa & Gray (2022):** `Modest holography and bulk reconstruction in asymptotically flat spacetimes`, Phys. Rev. D 106, 025021, DOI 10.1103/PhysRevD.106.025021, arXiv:2204.13133. Usa correspondência de campos livres bulk↔fronteira nula (infinito nulo/horizontes) e estrutura singular de Hadamard dos correladores de dois pontos para recuperar a métrica. **Já existe reconstrução de métricas fora de AdS**. Porém o método não fornece, por si só, uma dualidade forte-fraca, a equação de Einstein emergente, nem um mapa do elétron físico QED4 com massa derivada.


### 15.3 Férmions: o termo “elétron” é insuficiente para identidade física


**[HRF-REF-0053] Hartnoll & Tavanfar (2011):** `Electron stars for holographic metallic criticality`, Phys. Rev. D 83, 046003, DOI 10.1103/PhysRevD.83.046003. Estrelas de fluido ideal gravitante de férmions carregados em densidade finita, com regime de escala Lifshitz; não reconstrução de elétron do Modelo Padrão.


**[HRF-REF-0054] Liu, McGreevy & Vegh (2011):** `Non-Fermi liquids from holography`, Phys. Rev. D 83, 065029, DOI 10.1103/PhysRevD.83.065029. Respostas de operadores fermiônicos compostos em teorias fortemente acopladas 2+1, não QED4 física.


**[HRF-REF-0049] Hamilton et al. (2006):** `Local bulk operators in AdS/CFT correspondence: A boundary view of horizons and locality`, Phys. Rev. D 73, 086003, DOI 10.1103/PhysRevD.73.086003. Representação de operadores bulk locais por operadores boundary não locais no limite semiclassico.


### 15.4 Além de AdS: linhas distintas


**[HRF-REF-0059] Pasterski, Shao & Strominger (2017):** `Flat space amplitudes and conformal symmetry of the celestial sphere`, Phys. Rev. D 96, 065026, DOI 10.1103/PhysRevD.96.065026. Organiza amplitudes de espalhamento e estados escalares massivos de Minkowski como objetos conformes na esfera celeste; não é métrica emergente de elétron físico.


**[HRF-REF-0060] Strominger (2001):** `The dS/CFT correspondence`, JHEP 10 (2001) 034, DOI 10.1088/1126-6708/2001/10/034. Proposta de dualidade de Sitter/CFT com limitações de unitariedade e generalidade; não é uma construção completa e consensual da QED4.


## 16. CP-04 incorporado — 11/10/2026 01:04 BRT


### 16.1 Gate entrópico adversarial para RT clássico


**[HRF-REF-0056] Bao et al. (2015):** `The holographic entropy cone`, JHEP 09 (2015) 130, DOI 10.1007/JHEP09(2015)130. Para entropias obedecendo à prescrição RT clássica em geometrias adequadas, a monogamia da informação mútua impõe


```
I3(A:B:C) = S(A)+S(B)+S(C)-S(AB)-S(AC)-S(BC)+S(ABC) <= 0.
```


A violação I3>0 **exclui uma representação direta por RT clássico para aquele vetor de entropias/partição**, sob as hipóteses do teorema. Não exclui QES com correções quânticas, outras partições, diferentes algebras ou uma eventual dualidade não clássica. I3<=0 é condição necessária, **não suficiente**, para um dual geométrico RT.


**[HRF-REF-0057] Sokolovs (2026):** `Tripartite information of two-dimensional free fermions: a sine-kernel spectral constant from Fermi surface geometry`, arXiv:2603.03103. Preprint que relata mudança de sinal de I3 em função da escala z=k_F w; transição alegada em z*≈1,329 para tiras adjacentes na classe estudada.


**[HRF-REF-0058] Sokolovs (2026):** `Parity superselection obstructs monogamy of mutual information in free fermions`, arXiv:2603.14154. Preprint que mostra sensibilidade de I3 à álgebra/fatorização spin versus fermiônica, com inserções de paridade nas reduções de regiões disjuntas. **Status: abstracts consultados; provas integrais e robustez não auditadas; não elevar preprints a consenso.**


**Consequência para HRF [D/H]:** antes de ajustar superfícies RT aos dados gaussianos, fixar regiões A/B/C, álgebra de observáveis, escala, condições de contorno, setor de paridade e método de entropia. Calcular I3 e classificar: PASS/FAIL apenas para a hipótese de **RT clássico direto** naquela configuração. Em seguida verificar controle de escala, mudança de álgebra, estados de referência, excitados de um quantum e efeitos de cutoff. Nenhum resultado numérico foi executado neste ciclo.


### 16.2 Status das fontes e limites de leitura


| ID | Situação operacional no CP-04 | O que já sustenta |
|---|---|---|
| HRF-REF-0049 | USADO — resumo primário/metadata verificados | HKLL semiclassico e operadores bulk |
| HRF-REF-0050 | USADO — resumo primário/metadata verificados | differential entropy e curvas bulk |
| HRF-REF-0051 | USADO — resumo primário/metadata verificados | kinematic space em AdS3 |
| HRF-REF-0052 | USADO — resumo primário/metadata verificados | métrica completa em classe AdS3 estática |
| HRF-REF-0053 | USADO — resumo primário/metadata verificados | electron stars ≠ QED4 |
| HRF-REF-0054 | USADO — resumo primário/metadata verificados | non-Fermi liquids holográficos |
| HRF-REF-0055 | USADO — resumo primário/metadata verificados | reconstrução métrica assintoticamente plana por correladores |
| HRF-REF-0056 | USADO — resumo primário/metadata verificados | cone entrópico e MMI de RT clássico |
| HRF-REF-0057 | USADO COMO ALERTA — abstract de preprint, prova pendente | dependência de escala |
| HRF-REF-0058 | USADO COMO ALERTA — abstract de preprint, prova pendente | dependência de álgebra |
| HRF-REF-0059 | CONSULTADO — resumo primário/metadata verificados | celestial holography e estados massivos |
| HRF-REF-0060 | CONSULTADO — resumo primário/metadata verificados | proposta dS/CFT |
| HRF-REF-0061 | USADO — resumo primário/metadata verificados | entropia diferencial para superfícies |


**Referências adicionais identificadas, mas ainda não normalizadas:** Engelhardt & Horowitz (2017), `Recovering the spacetime metric from a holographic dual`, arXiv:1612.00391; estudos de rigidez, sombras e restrições de reconstrução. Permanecem em HRF-PEND, não recebem ID sem auditoria específica.


### 16.3 Quadro de lacunas revisado


| Pergunta | Status | Correção/limite |
|---|---|---|
| Métrica completa a partir de dados boundary? | [F/P] | SIM em classes especiais (Takeda), não universal. |
| Métrica fora de AdS? | [F/P] | SIM para campos livres em espaço assintoticamente plano (Tjoa–Gray). |
| Dados entrópicos livres garantem bulk RT clássico? | [G] | NÃO; teste necessário MMI e outras restrições. |
| Elétron QED4 real → métrica gravitacional dinâmica → 511 keV? | [?] | Nenhum candidato aceito identificado nesta busca; não provar inexistência. |
| Massa como parâmetro espectral? | [F] | Dicionário m–Delta em AdS/CFT, não derivação independente da massa do elétron. |
| Gravidade dinâmica universal de QFT arbitrária? | [?] | Não demonstrada pelos trabalhos aqui analisados. |


### 16.4 Referências de navegação para conferência posterior


- Takeda (2022): https://doi.org/10.1007/JHEP04(2022)124
- Tjoa & Gray (2022): https://doi.org/10.1103/PhysRevD.106.025021
- Bao et al. (2015): https://doi.org/10.1007/JHEP09(2015)130
- Czech et al. (2015): https://doi.org/10.1007/JHEP10(2015)175
- Sokolovs (2026): https://arxiv.org/abs/2603.03103 e https://arxiv.org/abs/2603.14154


## 17. Histórico cumulativo consolidado


- **CP-01 — 09/10/2026 13:05 BRT:** mapa RT/HRT/FLM/QES, Einstein linearizado, fermions, massa-dimensão, gap QED4.
- **CP-02 — 10/10/2026 01:00 BRT:** auditoria algébrica Val Baker, spinors, gauge e reconstrução métrica 2025.
- **CP-03 — 10/10/2026 13:08 BRT:** Takeda, Tjoa–Gray, HKLL, hole-ography, kinematic space, electron stars, entropy cone e programas flat/dS.
- **CP-04 — 11/10/2026 01:04 BRT:** reconciliação de CP-03, formalização do gate adversarial I3 com ressalvas de escala e álgebra, normalização das refs 0049–0061.


## 18. Próximas ações


1. Ler integralmente demonstrações de Takeda e Tjoa–Gray e comparar a informação de entrada necessária (causal, entrópica, correladores).
2. Verificar em detalhe os preprints Sokolovs; evitar usar abstracts como prova definitiva.
3. Definir um protocolo de *no-go test* de RT clássico em gaussianos fermiônicos com I3 e controle de álgebra.
4. Auditoria de parâmetros da proposta Val Baker 2019; distinguir predição de reparametrização do raio de Bohr.
5. Continuar busca por QED4 física e estados de um elétron em Minkowski; nenhum resultado de massa independente será reivindicado sem controle dimensional e de entradas.




## 19. CP-05 incorporado — 11/10/2026 13:08 BRT


# HRF — Checkpoint bibliográfico CP-05
**Data:** 2026-10-11, 13:08 BRT
**Programa:** Holographic Reconstruction Framework (HRF)
**Método:** Capítulo 0.1, Reconstrução Unificadora Progressiva B → A. [F] resultados sob hipóteses; [?] lacunas; [D] decisões metodológicas.
**Status:** síntese de leitura de resumos/fontes primárias e metadados editoriais, NÃO auditoria integral de todas as demonstrações. Nenhuma simulação executada.




## O que foi conferido neste ciclo




1. **[HRF-REF-0062] Engelhardt & Horowitz (2017), Towards a Reconstruction of General Bulk Metrics**, Classical and Quantum Gravity 34, 015004. DOI 10.1088/1361-6382/34/1/015004; arXiv:1605.01070. *Light-cone cuts* determinam a métrica **até fator conforme** em pontos causalmente acessíveis da boundary; singularidades de correladores ajudam a identificar cortes. Não é uma métrica completa universal.




2. **[HRF-REF-0063] Engelhardt & Horowitz (2017), Recovering the spacetime metric from a holographic dual**, Advances in Theoretical and Mathematical Physics 21, 1635. DOI 10.4310/ATMP.2017.v21.n7.a2; arXiv:1612.00391. Explora como obter fator conforme sob condições adicionais. **Status: consultado por resumo, não auditoria da prova.**




3. **[HRF-REF-0064] Sugiura & Takeda (2023), Bulk reconstruction of AdS_{d+1} metrics and developing kinematic space**, JHEP 06 (2023) 035. DOI 10.1007/JHEP06(2023)035; arXiv:2212.10065. Reconstrói explicitamente métricas global, Poincaré e Rindler de AdS_{d+1} combinando cortes causais com superfícies de informação causal mínimas. O fator conforme continua sem prescrição universal.




4. **[HRF-REF-0065] Engelhardt & Fischetti (2017), Causal density matrices**, Physical Review D 95, 126012. DOI 10.1103/PhysRevD.95.126012; arXiv:1703.05328. Introduz objeto derivado da estrutura de singularidades dos correladores para diagnosticar geometria causal holográfica semiclassica. A alegação de condição necessária/suficiente vale para a geometria **causal** no enquadramento definido, não garante fator conforme, dinâmica Einstein ou dual da QED4.




5. **[HRF-REF-0066] Bousso & Kaya (2024), Geometric quantum states beyond the AdS/CFT correspondence**, Physical Review D 110, 066017. DOI 10.1103/PhysRevD.110.066017; arXiv:2404.11644. Demonstra MMI para áreas de wedges generalizados em espaços-tempos arbitrários **quando** entropia de matéria é desprezível ante a geométrica e regiões de entrada são independentes. Não autoriza aplicar MMI a qualquer estado fermiônico livre.




6. **[HRF-REF-0067] Bousso & Kaya (2025), Holographic entropy cone beyond AdS/CFT**, Physical Review D 111, 086014. DOI 10.1103/PhysRevD.111.086014; arXiv:2502.03516. Estende desigualdades conhecidas de área RT para wedges generalizados **estáticos** em espaços-tempos arbitrários, sob condição de independência mútua das regiões. Resultado mais forte do que o resumo de CP-04 sugeria; não é universalidade irrestrita.




7. **[HRF-REF-0068] Bousso & Penington (2023), Entanglement wedges for gravitating regions**, Physical Review D 107, 086002. DOI 10.1103/PhysRevD.107.086002. Propõe wedges generalizados para regiões gravitantes; a construção geral é **conjectural**, com propriedades parciais demonstradas. Base estrutural das extensões de 2024–25.




## Correção importante ao CP-04
A monogamia da informação mútua (MMI) não é apenas uma desigualdade do RT em AdS: existem extensões geométricas além de AdS [0066–0067]. Mas o gate I3<=0 **continua condicional** à identificação apropriada de regiões, álgebra, fatoração, dominância da contribuição geométrica, independência mútua e classe de wedge. Violação de I3 exclui a representação pelo modelo geométrico específico testado; não elimina toda holografia, QES ou gravidade emergente.




## Síntese das interfaces e lacunas
- [F/P] Dados causais → classe conforme da métrica: Engelhardt–Horowitz 2017.
- [F/P] Informação geométrica adicional → fator conforme em classes especiais: Takeda 2022 e Sugiura–Takeda 2023.
- [F/P] Correladores de campos livres → reconstrução métrica assintoticamente plana: Tjoa–Gray 2022 [0055], não dinâmica gravitacional emergente.
- [?] Estado de um elétron da QED4 → dados de fronteira → métrica gravitacional dinâmica + massa 511 keV: nenhum candidato aceito identificado até aqui; busca continua aberta.
- [?] Preprints de férmions livres [0057–0058]: somente resumos consultados, demonstrações e álgebra ainda não auditadas.




## Próximo bloco
1. Auditoria integral das provas de Takeda 2022, Tjoa–Gray 2022 e Sugiura–Takeda 2023.
2. Construir matriz de entradas (entropias, cortes causais, correladores, superfícies, condições de contorno) e saídas (métrica conforme, fator, equações de movimento).
3. Comparar [0066–0067] com [0056] antes de formular o gate de MMI para estados gaussianos.
4. Continuar pesquisa QED4/elétron físico e auditoria Val Baker.




**Proveniência:** este CP-05 soma-se aos CP-01–CP-04; o Caderno de Pesquisa Bibliográfica v0.3 deve conter o estado acumulado.


## 20. Histórico cumulativo atualizado


- CP-05 (11/10/2026 13:08 BRT): referências 0062–0068; distinção entre classe conforme, fator conforme e dinâmica; cone de áreas fora de AdS sob condições; revisão do gate MMI. Nenhuma simulação executada.

---
## 21. CP-06 incorporado — 12/10/2026 01:12 BRT

﻿HRF — Checkpoint bibliográfico CP-06
Data: 12/10/2026, 01:12 BRT
Método: Capítulo 0.1 v0.1 e v0.2 efetivamente consultados. RUP B → A; [F] resultado condicionado, [H] hipótese, [?] pendente, [D] decisão. Nenhuma simulação executada. Auditoria textual de trechos e equações, NÃO replicação integral de provas.


1. Takeda (2022) [HRF-REF-0052]. Equações (2.2) e (3.9)–(3.12): light-cone cuts determinam a classe conforme, e a distância de hole-ography permite recuperar o fator conforme somente quando a identificação de pontos entre métodos está disponível, em particular quando causal wedge e entanglement wedge coincidem. O artigo reconhece falta de transformação conhecida entre rótulos fora desse caso; BTZ reconstruído no exterior do horizonte. No caso analisado de BTZ, alerta para entwinement em vez de entropia ordinária.
2. Tjoa–Gray (2022) [HRF-REF-0055]. Equações (50)–(58): correladores de fronteira smearizados, via projeção Γ, dão correladores bulk; o limite Hadamard reconstrói g_{μν}(x)=−(1/8π²)lim_{x'→x}∂_μ∂_{ν'}[W(x,x')^{-1}]. Hipóteses: campo livre, estado Hadamard, dados nulos suficientes, mapa Γ existente. O smearing transporta informação geométrica. Pergunta aberta: como obter Γ sem pressupor a geometria-alvo? Não alegar circularidade demonstrada. No exemplo Minkowski, limites T→0 e δ→0 não comutam.
3. Sugiura–Takeda (2023) [HRF-REF-0064]. Recuperação do fator conforme para patches global/Poincaré/Rindler de AdS(d+1) a partir de cortes nulos DADOS, quando CIS pode ser tratada como superfície mínima. Não há algoritmo universal para QFT arbitrária.
4. Bousso–Kaya (2025) [HRF-REF-0067]. Teorema 12, equações (2.9)–(2.12): desigualdades de ÁREA de wedges generalizados ESTÁTICOS com independência mútua das regiões a_i ⊂ [E(união dos demais a_j)]'. Prova por mapas de contração. Não é prova de I3≤0 para toda entropia de matéria de estados fermiônicos. [0066] cobre MMI geométrica além AdS sob hipóteses.
5. Nova referência [HRF-REF-0069]: Saravani, Aslanbeigi e Kempf, Spacetime Curvature in terms of Scalar Field Propagators, Phys Rev D 93, 045026 (2016), DOI 10.1103/PhysRevD.93.045026, arXiv:1510.02725. Eq. (10) reconstrói métrica de propagadores; eqs. (17)–(19) tratam cutoff UV e não comutatividade de limites. Seções II–III consultadas, prova do apêndice pendente.
6. Nova referência [HRF-REF-0070]: Dappiaggi, Moretti e Pinamonti, Hadamard States From Light-like Hypersurfaces (2017), DOI 10.1007/978-3-319-64343-4, arXiv:1706.09666. Consultada por resumo; leitura integral pendente, não usar como prova auditada.
7. Correção de proveniência [HRF-REF-0031]: auditoria algébrica interna Val Baker/E-69 de 09/10/2026 já demonstra que m_P ℓ_P/(α a0)=ℏ/(α c a0)=m_e quando a0=ℏ/(α m_e c). A auditoria algébrica interna está concluída; réplica externa opcional.


Matriz de interfaces:
Takeda: cortes + entropia + coincidência de wedges → métrica em classes AdS3 estáticas; não gravidade universal.
Tjoa–Gray: correladores smearizados + Γ + Hadamard → métrica em casos controlados 3+1; não dualidade forte-fraca.
Sugiura–Takeda: cortes dados + CIS mínima → fator conforme em patches AdS; não receita universal.
Bousso–Kaya: wedges generalizados estáticos e independentes → desigualdades de área; não MMI de matéria universal.
Saravani: propagador bulk + limite de coincidência → métrica local; não emergência dinâmica de Einstein.


Pendências: auditoria independente integral das provas, unicidade/independência de Γ, estabilidade sob smearing e cutoff, área geométrica versus entropia total, busca QED4/elétron físico → geometria dinâmica → massa 511 keV ainda aberta. Próximo bloco: gates de entradas independentes, contraexemplos, estabilidade de limites e condições de contorno.


Fontes: arXiv 2112.11437, 2204.13133, 2212.10065, 2502.03516, 1510.02725, 1706.09666. Documentação interna: Capítulo 0.1 v0.1/v0.2; Caderno cumulativo v0.3; auditoria HRF Val Baker/E69 09/10/2026.

## 22. Status de leitura atualizado
| ID | Leitura | Uso |
|---|---|---|
| 0052 | equações (2.2), (3.1), (3.9–3.12); prova não replicada | métrica conforme + fator sob coincidência de wedges |
| 0055 | equações (50–58), exemplos e limites; prova não replicada | Hadamard, projeção Γ, smearing |
| 0064 | texto e conclusões; prova não replicada | fator conforme em AdS com cortes dados |
| 0066 | resumo primário; prova não replicada | MMI geométrica além AdS sob hipóteses |
| 0067 | Teorema 12, eqs. (2.9–2.12); prova não replicada | cone de áreas estático, independência |
| 0069 | texto parcial, seções II–III; prova do apêndice pendente | inversão de propagador e cutoff UV |
| 0070 | resumo/metadados, ainda não usado como prova primária | estados Hadamard e fronteiras nulas |
| 0031 | auditoria algébrica interna concluída em 09/10 | dependência via raio de Bohr |

Novas referências detalhadas: [HRF-REF-0069] Mehdi Saravani, Siavash Aslanbeigi e Achim Kempf, *Spacetime Curvature in terms of Scalar Field Propagators*, Phys Rev D 93, 045026 (2016), DOI 10.1103/PhysRevD.93.045026, arXiv:1510.02725. [HRF-REF-0070] Claudio Dappiaggi, Valter Moretti e Nicola Pinamonti, *Hadamard States From Light-like Hypersurfaces* (2017), DOI 10.1007/978-3-319-64343-4, arXiv:1706.09666.

Frentes negativas abertas: sem busca exaustiva nova para QED4 real → geometria gravitacional dinâmica → massa 511 keV; não declarar inexistência. Auditoria de estabilidade de Γ, limites e teoremas completa pendente.

---

## 23. CP-07 incorporado — 12/10/2026 13:09 BRT

# HRF — Checkpoint bibliográfico CP-07

**Data/hora:** 12/10/2026 13:09 BRT  
**Projeto:** Holographic Reconstruction Framework (HRF) — revisão RT/HRT/QES, reconstrução e QED4  
**Método:** Capítulo 0.1 v0.2 efetivamente consultado neste ciclo; v0.1 histórica não recuperada independentemente neste ciclo. RUP B → A, [F]/[M]/[H]/[?]/[D].  
**Tipo de leitura:** resumos de fontes primárias e metadados editoriais; artigo [0073] consultado no portal editorial (resumo e referências). **Não houve auditoria integral das provas, simulação ou cálculo numérico.**

## Progresso e resultado novo

**[F/P] A escolha da álgebra e do tratamento de bordas é um requisito independente antes de interpretar entropia de gauge/QED como geometria RT.** A fatorização ingênua H = H_A ⊗ H_B de espaços físicos pode falhar em teorias gauge devido à lei de Gauss; prescrições de sub-regiões com *edge modes*, setores de superseleção e/ou álgebras de observáveis alteram a entropia operacional. Isto é distinto da dependência da álgebra de férmions livres já anotada em [0057–0058].

- **[HRF-REF-0071]** William Donnelly (2012), *Decomposition of entanglement entropy in lattice gauge theory*, Phys. Rev. D **85**, 085004, DOI 10.1103/PhysRevD.85.085004. A decomposição da entropia em contribuições de setores de borda e correlações não locais exige definição da partição. **Fonte: resumo editorial primário; prova integral pendente.**
- **[HRF-REF-0072]** William Donnelly & Aron C. Wall (2015), *Entanglement Entropy of Electromagnetic Edge Modes*, Phys. Rev. Lett. **114**, 111603, DOI 10.1103/PhysRevLett.114.111603. Modos de borda do campo elétrico normal à superfície explicam contribuição à entropia do vácuo de Maxwell. **Fonte: resumo editorial primário; prova integral pendente.**
- **[HRF-REF-0073]** William Donnelly & Laurent Freidel (2016), *Local subsystems in gauge theory and gravity*, JHEP **09** (2016) 102, DOI 10.1007/JHEP09(2016)102, arXiv:1601.04744. Construção de espaço de fase gauge-invariante para regiões com borda mediante graus de liberdade adicionais; o artigo distingue bordas em Yang–Mills e GR. **Fonte: resumo e referências editoriais; prova integral pendente.**
- **[HRF-REF-0074]** Karel Van Acoleyen et al. (2016), *Entanglement of Distillation for Lattice Gauge Theories*, Phys. Rev. Lett. **117**, 131602, DOI 10.1103/PhysRevLett.117.131602. Distingue componente não destilável de gauge e emaranhamento operacionalmente destilável, em regimes e classes especificados. **Fonte: resumo editorial primário; prova integral pendente.**

## Consequência metodológica para o HRF — novo gate G-GAUGE [D]

1. Identificar se o estado é escalar livre, férmion gaussiano ou setor gauge com matéria carregada; não transferir automaticamente o gate de uma classe a outra.
2. Especificar regiões A/B/C, álgebra física de observáveis, centros, restrições de Gauss, escolha de *edge modes*, cutoff e setores de superseleção antes de calcular S(A), I3 ou fazer ajuste RT.
3. Registrar **separadamente** entropia geométrica de área, entropia de matéria bulk, contribuições de borda e entropia operacionalmente destilável; não tratá-las como intercambiáveis.
4. Se I3 > 0, marcar apenas **FAIL para a representação RT clássica direta daquela partição e definição entrópica**; não inferir refutação de QES ou holografia em geral.
5. Para alegar elétron QED4 físico, exigir também setor carregado gauge-invariante, dressing de Gauss, spin 1/2, massa e observáveis de espalhamento, além da métrica. Uma excitação fermiônica genérica não basta.

## Checagens e lacunas

- **Revisados sem nova prova integral:** Takeda [0052], Tjoa–Gray [0055], Sugiura–Takeda [0064], Bousso–Kaya [0066–0067], Saravani [0069]. A pergunta sobre independência do mapa Γ e dos dados geométricos continua aberta.
- **Correção preservada:** Tjoa–Gray [0055] reconstrói métrica fora de AdS sob hipóteses de campos livres/Hadamard; não deriva gravidade dinâmica universal.
- **Val Baker [0031]:** a dependência algébrica da massa via raio de Bohr permanece auditada internamente; não constitui previsão independente sem derivar a0.
- **Busca negativa QED4:** não foi feita busca exaustiva nova neste ciclo. A ausência de candidato para QED4 física → métrica gravitacional dinâmica → 511 keV permanece provisória, não prova inexistência.

## Próximo bloco

Auditar demonstrações completas [0071–0074] e formalizar o gate G-GAUGE para partições de U(1) com matéria; confrontar o gate com [0056–0058, 0066–0067]; retornar à independência/estabilidade de Γ e às condições de contorno de [0055, 0069]. Priorizar análise simbólica e controles pequenos, sem simulação não autorizada.

## Fontes primárias consultadas

- [0071] https://doi.org/10.1103/PhysRevD.85.085004
- [0072] https://doi.org/10.1103/PhysRevLett.114.111603
- [0073] https://doi.org/10.1007/JHEP09(2016)102
- [0074] https://doi.org/10.1103/PhysRevLett.117.131602

**Proveniência:** CP-07 soma-se a CP-01–CP-06. Novo caderno v0.5 incorpora integralmente o texto da v0.4; índice enxuto v0.7 preserva 0001–0070 e acrescenta 0071–0074.

## 24. Histórico cumulativo atualizado

- **CP-07 (12/10/2026 13:09 BRT):** revisão de fatorização, edge modes, setores de superseleção e entropia operacional de gauge; 4 fontes novas [0071–0074]; gate G-GAUGE; sem simulação ou réplica de provas.


---
## 25. CP-08 incorporado — 13/10/2026 01:04 BRT

# HRF — Checkpoint bibliográfico CP-08

**Data/hora:** 2026-10-13 01:04 BRT  
**Programa:** Holographic Reconstruction Framework (HRF) — RUP B → A  
**Base lida:** Capítulo 0.1 v0.1 (Projeto, integral), v0.2 (Drive, integral); Caderno cumulativo v0.5; índice v0.7.  
**Estado:** pesquisa documental e leitura seletiva de seções/equações; nenhuma simulação, réplica de prova integral ou teste físico executado.

## Conferências e resultados

1. **[HRF-REF-0075] Casini, Huerta & Rosabal (2014), Phys. Rev. D 89, 085012, DOI 10.1103/PhysRevD.89.085012.** Lidas seções 2–3 e 6 e equações (21), (26)–(28), (31)–(35), (66). A álgebra gauge-invariante local pode ter centro não trivial, `Z(A)=A∩A'`; para setores centrais `k`, `S(A)=H(p_k)+Σ_k p_k S(ρ_{A,k})`. Atribuir região a álgebra é escolha adicional; mutual information e entropia relativa têm comportamento universal no limite contínuo sob condições de separação e regularização discutidas pelos autores. **Leitura parcial de texto integral; demonstrações e hipóteses de convergência não auditadas integralmente.**
2. **[HRF-REF-0076] Casini & Huerta (2014), Phys. Rev. D 90, 105013, DOI 10.1103/PhysRevD.90.105013.** Exemplo computacional publicado para Maxwell em rede 2D: entropia sensível à álgebra, informação mútua com limite contínuo bem definido na classe examinada. **Resumo editorial conferido; detalhes numéricos e prova não auditados.**
3. **[HRF-REF-0077] Soni & Trivedi (2016), JHEP 01 (2016) 136, DOI 10.1007/JHEP01(2016)136.** Seção 2 e equações (2.19)–(2.28) e fórmula da entropia na seção 2 foram consultadas. Para grupos não abelianos, a prescrição de Hilbert estendido distingue: Shannon dos setores, termo de representação `Σ_k p_k Σ_i log d_{k,i}` e termo quântico condicionado. O termo de dimensão de representação não deve ser transportado automaticamente para U(1) abeliano, onde `d=1`. **Leitura parcial; protocolos de destilação não auditados.**
4. **[HRF-REF-0078] Harlow (2017), Commun. Math. Phys. 354, 865–912, DOI 10.1007/s00220-017-2904-z.** Lidos teorema 5.1 e equações (5.22)–(5.36) e (5.37)–(5.39). Em códigos de correção de erros de dimensão finita com recuperação complementar, `S(ρ_A)=Tr(ρ L_A)+S(ρ,M)`, com `L_A` no centro da álgebra lógica; igualdade de entropias relativas liga reconstrução algébrica e fórmula RT corrigida. **A prova integral e a passagem a QED4/gravidade dinâmica não foram auditadas nem demonstradas.**

## Inferência metodológica para G-GAUGE [D]

- **G1:** declarar teoria, estado, região, álgebra gauge-invariante e centro; especificar fluxos de Gauss, condições de borda, setores e regularização.
- **G2:** separar `S_setores`, `S_quântico|setor` e, quando aplicável, `S_representações`; não confundir entropia estendida com destilável nem com área RT.
- **G3:** calcular `I(A:B)` e `I3(A:B:C)` apenas com uma família consistente de álgebras para A, B, C e uniões; registrar efeito de mudança de prescrição, adjacência e cutoff. `I3>0` só rejeita a classe RT clássica geométrica apropriada, não toda holografia.
- **G4:** para promover a um mapa holográfico, exigir código/subespaço, operadores lógicos, recuperação complementar, operador de área e dicionário boundary↔bulk; as identidades algébricas isoladas não geram métrica nem equações de Einstein.

## Lacunas e próxima frente

**[?]** Ainda faltam: auditoria integral das provas [0075–0078]; robustez de `I3` em regiões contíguas/disjuntas e centros diferentes; implementação de G-GAUGE em U(1) com matéria carregada; condições para usar RT/QES em QED4; independência do mapa Γ em Tjoa–Gray [0055]; demonstração não circular da massa eletrônica de 511 keV. A busca negativa QED4→bulk dinâmico→massa **não foi repetida de modo exaustivo** neste ciclo. **Próximo bloco:** matriz comparativa centro elétrico/magnético/Hilbert estendido; derivar pequeno exemplo analítico de álgebra U(1) em rede, sem simulação não autorizada; confrontar [0075–0078] com [0056–0058, 0066–0067] e JLMS [0036].

**Fontes:** arXiv:1312.1183 (equações indicadas); DOI 10.1103/PhysRevD.90.105013 (resumo); arXiv:1510.07455 (seção 2); arXiv:1607.03901 (seção 5). Referências [0075–0078] normalizadas; *Notes on Entanglement in Abelian Gauge Theories* (Radičević, arXiv:1404.1391) permanece **HRF-PEND-028**, apenas resumo consultado, sem ID definitivo.

## 26. Consolidação analítica e matriz de interfaces (CP-08)

| Objeto | Dados de entrada e pressupostos | Saída controlada | O que NÃO demonstra | Status de uso |
|---|---|---|---|---|
| Casini–Huerta–Rosabal [0075] | álgebra gauge-invariante local, centro, estado e escolha de região | entropia por setores, fórmulas de entropia relativa e informação mútua | dualidade holográfica, independência de qualquer regulador | **USADO**: equações selecionadas; prova completa pendente |
| Casini–Huerta [0076] | Maxwell em rede 2D, escolha de álgebra e limite contínuo | comparação de entropia vs informação mútua | resultado universal de QED4 com matéria carregada | **CONSULTADO**: resumo; detalhes numéricos pendentes |
| Soni–Trivedi [0077] | espaço de Hilbert estendido, lei de Gauss, irreps de borda não abelianas | decomposição Shannon + dimensão de representação + parte quântica | termo não abeliano obrigatório em U(1) | **USADO**: seções/equações parciais; destilação pendente |
| Harlow [0078] | código de subálgebra de dimensão finita, recuperação complementar | fórmula RT algébrica com operador central de área, equivalência de entropias relativas | gravidade emergente de QED4, massa de elétron | **USADO**: teorema e fórmulas selecionadas; prova integral pendente |
| Tjoa–Gray [0055] | campo livre Hadamard, dados nulos e mapa Γ | métrica em classes assintoticamente planas | Γ independente da métrica, dinâmica de Einstein | **USADO ANTERIORMENTE**: leitura parcial; gate Γ pendente |
| Bousso–Kaya [0066–0067] | áreas de wedges generalizados e hipóteses geométricas/independência | MMI/cone de áreas sob condições | `I3<=0` para toda entropia gauge de matéria | **USADO ANTERIORMENTE**: teorema parcial; aplicação gauge pendente |

**Formulação operacional da costura:** para um estado `ρ` e uma região `A`, especificar a álgebra física `𝔄(A)` e seu centro `𝔃(A)=𝔄(A)∩𝔄(A)'` antes de definir `S_𝔄(A)(ρ)`. A decomposição de setores não autoriza igualar `S_𝔄(A)` a `Area(γ_A)/(4G_N)`: isso requer um dicionário holográfico independente e condições de código/gravidade. Em particular, a área RT é área no bulk, não área das faces Delaunay da boundary 2D.

**Advertência sobre o contínuo:** a robustez da informação mútua em regiões separadas não elimina automaticamente ambiguidades para partições adjacentes nem garante invariância do sinal de `I3` sob toda escolha de centro ou cutoff. O gate deverá declarar geometria e álgebra das sete regiões `A`, `B`, `C`, `AB`, `AC`, `BC`, `ABC`.

**Status e frente negativa:** nenhum cálculo novo de massa, carga, spin ou gravitação do elétron físico. A literatura revista demonstra estruturas algébricas úteis, mas não estabelece a cadeia QED4→dados gauge-invariantes→dual gravitacional dinâmico→massa 511 keV. A ausência de trabalho aceito continua uma conclusão limitada à busca executada; nenhuma inexistência absoluta é alegada.

## 27. Histórico cumulativo atualizado

- **CP-08 (13/10/2026 01:04 BRT):** Casini–Huerta–Rosabal, Maxwell 2D, Soni–Trivedi e Harlow [0075–0078]; decomposição por centro, termo não abeliano de dimensão de representação, conexão algébrica RT/JLMS e refinamento do gate G-GAUGE; prova integral e simulações não executadas.


## 28. CP-09 incorporado — 13/10/2026 13:04 BRT

### 28.1 Escopo documental e estatuto

**[D]** Leitura obrigatória realizada: Capítulo 0.1 v0.2 (09/10/2026, arquivo HRF no Drive `1ONUO_YzYWVnIRPUA2ho562MPGEl7_3dy`, seções 0.1.1–0.1.17); diretriz RUP **B → A** e separação dos mapas **G** (geometria), **W** (onda) e **D** (dicionário). O Cap. 0.1 v0.1 é referenciado e preservado historicamente na v0.2, mas não foi localizado independentemente nesta execução. Base cumulativa v0.6 e índice v0.8 consultados, com 78 IDs prévios. Nenhuma simulação ou auditoria integral independente de provas foi executada.

### 28.2 Novo confronto bibliográfico: centro elétrico, magnético e buffer zone

**[HRF-REF-0079] Radičević (2014), _Notes on Entanglement in Abelian Gauge Theories_, arXiv:1404.1391, https://arxiv.org/html/1404.1391.**

**Status: USADO — leitura direta de texto e equações das seções 1–8; não reprodução independente de toda a prova.** A obra estava marcada `HRF-PEND-028` no CP-08; agora normalizada como [0079]. O autor formula uma partição de links separada por uma zona intermediária de plaquetas e mostra, na classe abeliana tratada, que diferentes escolhas elétricas/magnéticas de centro correspondem a mudanças de base dos graus de liberdade da zona, resultando em igualdade de entropia quando a partição física e os graus contabilizados são os mesmos. Isso não significa que duas escolhas arbitrárias de álgebra para regiões diferentes sempre produzam o mesmo valor.

A decomposição física em setores de superseleção para uma região V é

```text
H_phys = ⊕_k ( H_V^(k) ⊗ H_Vbar^(k) )
rho_V = ⊕_k p_k rho_V^(k)
S_V = H({p_k}) + Σ_k p_k S(rho_V^(k))
H({p_k}) = -Σ_k p_k ln p_k.
```

A eq. (5.1) de Radičević é `S_V^(alpha) = S_V` **somente sob o esquema de buffer e identificação de bases adotado**. Sua eq. (3.17), para estado topológico e setores equipotentes em `Z_N`, é

```text
S_V = (|∂V| - n_∂) ln N.
```

Exemplo de substituição analítica, não resultado original HRF: `N=2`, `|∂V|=4`, `n_∂=1` → `S_V=3 ln 2`. A generalização a `U(1)` compacta troca setores discretos finitos por infinitos rótulos de fluxo `k∈Z` e exige estado/medida/regularização; não é legítimo declarar a entropia física do elétron infinita por mera extrapolação de `N`.

**Conciliação com [0075–0076].** Casini–Huerta–Rosabal (2014) documentam dependência da entropia com a escolha de álgebra/centro para uma região dada, enquanto quantidades como informação mútua e entropia relativa têm propriedades universais no contínuo sob hipóteses próprias. Radičević não elimina essas sutilezas genericamente: muda a organização do corte, mantendo uma *buffer zone* e identificando os graus de liberdade que são reexpressos em bases diferentes. Portanto, a aparente tensão é em parte diferença entre **o que está sendo comparado**. A demonstração de equivalência para uma geometria, álgebra e estado do HRF deve ser feita explicitamente, não importada como axioma.

### 28.3 Maxwell: edge modes e o termo de contato

**[HRF-REF-0080] Donnelly & Wall (2016), _Geometric entropy and edge modes of the electromagnetic field_, Physical Review D 94, 104053, DOI 10.1103/PhysRevD.94.104053; arXiv:1506.05792, https://arxiv.org/html/1506.05792.**

**Status: USADO — leitura da introdução, hipóteses de fundo, decomposição da partição e descrição dos modos de borda; prova integral e determinantes não reproduzidos.** O artigo estende [0072], explicando, em teoria Maxwell U(1) **sem cargas**, em uma classe de geometrias com fatoração base bidimensional × fibra compacta e horizonte de Killing bifurcado, como a função de partição se separa em torres de escalares, fluxos elétricos/magnéticos e termo de contato. Os modos de borda associados a `E_⊥` permitem interpretação estatística desse termo na regularização especificada. O coeficiente aparente de certos termos divergentes depende do esquema de corte; não usar sinal isolado como contagem física negativa de estados. Esse resultado não inclui férmion Dirac interagente, massa de 511 keV ou equações de Einstein emergentes.

### 28.4 Matriz de prescrições e gates para o HRF

| Prescrição | Dados físicos necessários | Possível saída | Advertência / gate |
|---|---|---|---|
| Centro elétrico [0075,0079] | links/região, fluxos `E_⊥`, lei de Gauss, estado e setores | `H(p_k)+Σ p_k S_k` | setores não são por si áreas RT; fixar corte e regulador |
| Centro magnético [0075,0079] | plaquetas/Wilson loops de fronteira, região e buffer idênticos | entropia em base magnética, comparação unitária condicional | igualdade com elétrico exige **mesmo** conjunto físico e buffer, não apenas mesmo nome de região |
| Hilbert estendido [0071–0074] | embedding gauge-compatível, graus de borda, eventual representação não abeliana | entropia estendida, termos de borda | distinguir entropia estendida de destilável; para U(1) irreps unidimensionais |
| Maxwell geométrico [0072,0080] | U(1) sem cargas, fundo/horizonte, condições de contorno e regulador | entropia de edge modes e termo de contato | não é QED4 com elétron dinâmico |
| RT/QES/JLMS [0013,0035–0036,0078] | estado com dual semiclassico, code subspace, wedge, operador de área | relação área + bulk sob hipóteses | nenhuma das linhas anteriores demonstra automaticamente um dual gravitacional |

**[D] G-GAUGE-2 proposto:** pré-fixar sete álgebras compatíveis para `A`, `B`, `C`, `AB`, `AC`, `BC`, `ABC`; registrar cortes, buffer, setores, regularização, topologia, adjacência, estado, fluxos e centro. Calcular `I3=S(A)+S(B)+S(C)-S(AB)-S(AC)-S(BC)+S(ABC)` e testar invariância/robustez **antes** de aplicar gate de RT clássico `I3≤0`. A universalidade de informação mútua para regiões separadas no contínuo não implica automaticamente invariância do sinal de `I3` em regiões adjacentes ou em todas as escolhas de álgebra. A desigualdade RT é necessária, não suficiente, para uma classe geométrica definida; resultados além de AdS [0066–0067] exigem independência e dominância geométrica. Nenhum cálculo de `I3` executado neste ciclo.

### 28.5 Registro de fontes, fronte negativa e história

| ID | Situação nesta execução | Uso científico |
|---|---|---|
| 0075 | CONSULTADO ANTERIORMENTE; resumo e fórmulas já auditados parcialmente | dependência de centro, limites de universalidade |
| 0076 | CONSULTADO ANTERIORMENTE por resumo | Maxwell 2D e contínuo; detalhes numéricos pendentes |
| 0077 | CONSULTADO ANTERIORMENTE, prova parcial | termo de dimensão de irreps não abelianas; não aplicar indiscriminadamente a U(1) |
| 0078 | CONSULTADO ANTERIORMENTE, teorema parcial | RT algébrico condicionado a código e recuperação complementar |
| **0079** | **USADO, texto direto e equações 3.12/3.17/5.1/6.3; auditoria integral pendente** | buffer zone e equivalência condicional de bases |
| **0080** | **USADO, introdução e fórmulas selecionadas; auditoria integral pendente** | edge modes Maxwell e termo de contato |
| `HRF-PEND-029` | IDENTIFICADO, resumo/metadata | Radičević (2016), _Entanglement in weakly coupled lattice gauge theories_, JHEP 04 (2016) 163; leitura integral pendente; sem ID definitivo |

**[?] Frentes negativas ainda abertas:** estado de elétron físico QED4 com carga/spin/estatística → dados de álgebra e entropia gauge-invariantes → dual gravitacional dinâmico → massa de 511 keV independente; independência do mapa Γ em Tjoa–Gray [0055]; validade de Hadamard e reconstrução de métrica fora de AdS; robustez `I3` para férmions gaussianos sob escolha de centro; generalização de Maxwell livre a QED interagente. Nenhuma busca negativa exaustiva nova foi executada neste ciclo; não afirmar inexistência absoluta.

**[D] Próximo bloco:** comparar formalmente `rho_V^electric`, `rho_V^magnetic` e embedding estendido no **mesmo** pequeno sistema gauge com regiões e buffer explicitados; verificar condição unitária, então construir protocolo `I3` com controles de adjacência e cutoff. Em paralelo, voltar ao gate Γ de Tjoa–Gray e à auditoria Val Baker para checar independência de parâmetros. Preservar CP-01–CP-09.

**Histórico:** CP-09 (13/10/2026 13:04 BRT) normaliza 0079–0080, promove HRF-PEND-028 e introduz G-GAUGE-2. CP-01–CP-08 continuam incorporados nas seções precedentes deste caderno.

---
## 29. CP-10 incorporado — 14/10/2026 01:11 BRT

# HRF — Checkpoint bibliográfico CP-10

**Data/hora:** 14/10/2026 01:11 BRT  
**Programa:** HRF / RUP B → A  
**Fontes internas:** Cap. 0.1 v0.2 (leitura integral via Drive; v0.1 histórica não localizada separadamente nesta execução), caderno cumulativo v0.7 (CP-01–CP-09), índice v0.9 (0001–0080).  
**Escopo:** G-GAUGE-3 — estado de carga física, dressing eletromagnético e gravitacional; dimensões da entropia de gauge. **Sem simulações, sem réplica integral de provas.**

## Achados verificados

1. **[F, domínio limitado] [HRF-REF-0081] Radičević (2016)**, *Entanglement in weakly coupled lattice gauge theories*, JHEP 04 (2016) 163, DOI `10.1007/JHEP04(2016)163`, arXiv:1509.08478v2. Lidas seções sobre decomposição de setores e derivação de acoplamento fraco, especialmente eqs. (22), (51)–(53), e ressalvas de validade. Em **duas dimensões espaciais** no regime fraco: `ΔS(e) = [dim(G)/2] ln(e² r)` para contribuição específica da entropia; não é fórmula geral da entropia total. Para **três dimensões espaciais**, a estrutura dos termos finitos e de regularização difere (eq. 53); não substituir `r` por uma escala de QED4 nem inferir massa. **Status: USADO, leitura parcial de texto integral; demonstração completa não reproduzida.**
2. **[F, domínio perturbativo] [HRF-REF-0082] Donnelly & Giddings (2016)**, *Observables, gravitational dressing, and obstructions to locality and subsystems*, Phys. Rev. D 94, 104038, DOI `10.1103/PhysRevD.94.104038`, arXiv:1607.01025. Lidas introdução e seção III.1 (teorema de dressing), eqs. (15)–(16). Carga elétrica isolada exige campo de longo alcance pela lei de Gauss; operadores compostos eletricamente neutros podem ter dressing localizado em QED. No caso gravitacional, operadores com cargas de Poincaré não triviais exigem dependência assintótica da métrica, já na ordem perturbativa líder. **Não** equiparar o teorema gravitacional a um teorema sobre qualquer operador gauge de QED. **Status: USADO, leitura de texto e teorema, sem réplica integral da prova.**
3. **[F, construção formal] [HRF-REF-0083] Wilson-Gerow & Stamp**, *Gauge Invariant Propagators and States in Quantum Electrodynamics*, arXiv:2011.05305v2 (2023), periódico indicado: *Annals of Physics*. Lidas seções 2.1, 2.3, eqs. (1), (3)–(5), (30), (42), introdução às fronteiras nulas. Para QED **espinorial** os autores constroem estados/propagadores gauge-invariantes com dressing coulombiano e termos radiativos/soft sob hipóteses de fronteira. O resultado é um precedente direto para definir **o estado físico do elétron**, mas não reconstrói métrica gravitacional nem deriva `m_e`. **Status: USADO, leitura parcial do texto integral; apêndices/prova completa pendentes.**

## Consequência metodológica G-GAUGE-3 [D]

Para uma ponte `QED4 → entropia/observáveis → bulk`:

- Especificar setor de carga `Q`, estado de Dirac, `ψ_dressed(x)=U[A;x]ψ(x)`, condição de gauge, fronteira e classe de dressings admissíveis; identificar fluxos assintóticos e modos soft.
- Impor `(∇·E − ρ)|Ψ_phys⟩=0`, e distinguir dados fixados por Gauss de graus transversos/radiativos. Em unidades adequadas, `∮_(∂V) E·dS = Q_V` (com ressalvas sobre fluxos na fronteira).
- Definir álgebras `A(R)` e centros para regiões e uniões; testar entropias somente no **mesmo** espaço físico, regulador, geometria de corte e condições de contorno. Manter `S_setores` separado de `S_quantum|setor` e de qualquer `Area/4G`.
- Declarar separadamente mapa **G** (entropia → geometria), **D** (operadores/estados boundary↔bulk) e **W** (dinâmica). Uma fórmula para dressing não demonstra D nem gravidade emergente.
- **Gate adversarial analítico:** tentar operador de criação de carga `q≠0` estritamente suportado em região limitada e campo externo inalterado; pela lei de Gauss, fluxo externo mede `q`, logo a construção viola o requisito. Isso é consequência de uma identidade conhecida, **não simulação nem descoberta nova**.

## Frentes negativas, fontes e próximos passos

**Não usado neste ciclo:** resultados anteriores de RT/HRT/QES/JLMS [0013–0014, 0035–0036], Takeda [0052], Tjoa–Gray [0055], Bousso–Kaya [0066–0067] permanecem como contexto, sem nova auditoria das provas. **Pendente:** reprodução completa dos três artigos novos, construção de um estado QED4 regulado com dressing e álgebra, controle `I3` sob diferentes cortes, independência do mapa Γ de Tjoa–Gray, extensão de Maxwell livre a QED interagente, validade do Hadamard em casos relevantes, e auditoria adicional de Val Baker [0031]. **Busca negativa:** nenhuma busca exaustiva demonstra inexistência de derivação `QED4 → geometria dinâmica → m_e≈511 keV`; lacuna permanece provisória.

**Próximo bloco:** confrontar a prescrição de estados QED espinorial [0083] com o gate G-GAUGE-2 [0075,0079,0080], e propor teste mínimo de consistência de fluxos/centros em um exemplo gauge finito antes de qualquer teste RT; em paralelo retomar Γ de Tjoa–Gray. **Nenhuma execução física autorizada ou realizada.**

## Fontes primárias verificadas

- [0081] https://arxiv.org/html/1509.08478 ; https://doi.org/10.1007/JHEP04(2016)163
- [0082] https://arxiv.org/html/1607.01025 ; https://doi.org/10.1103/PhysRevD.94.104038
- [0083] https://arxiv.org/html/2011.05305

**Histórico:** CP-10 acrescentado após CP-01–CP-09. O caderno cumulativo novo v0.8 incorpora integralmente v0.7 e este bloco; índice v1.0 mantém 0001–0080 e adiciona 0081–0083.

---

## 30. CP-11 incorporado — 14/10/2026 13:09 BRT

# HRF — Checkpoint bibliográfico CP-11

**Data/hora:** 14/10/2026 13:09 BRT  
**Framework:** Holographic Reconstruction Framework (HRF) — RUP B → A  
**Setores:** HRF-FM (QED4, estados carregados, massa), HRF-ST (reconstrução métrica além de AdS), interface G–D; W não investigado neste ciclo.  
**Classificação:** [F] estabelecido sob hipóteses; [M] resultado de bancada reportado; [H] hipótese; [?] aberto; [D] decisão metodológica.  
**Base preservada:** Caderno cumulativo v0.8 (CP-01–CP-10) e índice v1.0 (HRF-REF-0001–0083); novas referências 0084–0087. Nenhuma simulação nova, nem replicação independente de prova completa.

## 1. Ordem de fontes e verificação documental

1. **Capítulo 0.1 v0.2 — LIDO INTEGRALMENTE**, arquivo `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`. Mantidos os critérios de interface da seção 0.1.5, os mapas G/W/D da seção 0.1.13 e a proibição de converter entropia de toy model em gravidade ou partícula física. Não se alegou leitura independente da v0.1.
2. **Arquivos do Projeto/conversa:** Caderno v0.8 e índice v1.0 efetivamente recuperados no runtime, comparados e usados como base de versão; CP-10 e CP-09 presentes na cumulativa.
3. **Drive HRF complementar:** `HRF_ELETRON_71_RELATORIO_2026-10-14_1239-clau.md` (ID `1wm_eQBWytZOUJ1Q-0Hmb8EDvAjAbKtBi`) e `HRF_STAR_01_Investigacao_Massa_Referencias_e_Testes_v0_2_PT_2026-10-14.md` (ID `1E9Foh4REkgGVcUqOLtuMAoI1sbJ8jl33`), ambos lidos; resultados relatados por terceiros **não foram replicados aqui**.
4. **Literatura externa primária:** Dirac 1955, Kulish–Faddeev 1970, Buchholz 1986, Mund–Rehren–Schroer 2022 e reexame de equações de Tjoa–Gray 2022 [0055]. Leitura diferenciada abaixo.

## 2. Novas referências normalizadas e nível real de leitura

| ID | Fonte e identificação | Achado utilizável | Estatuto de leitura |
|---|---|---|---|
| **HRF-REF-0084** | P. A. M. Dirac, *Gauge-Invariant Formulation of Quantum Electrodynamics*, Canadian Journal of Physics **33** (1955), 650–660, DOI `10.1139/p55-081` | Criar um elétron gauge-invariante envolve criar conjuntamente seu campo coulombiano; elétron nu separado do campo não é objeto físico gauge-invariante. | **USADO: resumo bibliográfico primário e metadados; texto/prova integral PENDING.** |
| **HRF-REF-0085** | P. P. Kulish & L. D. Faddeev, *Asymptotic conditions and infrared divergences in quantum electrodynamics*, Theor. Math. Phys. **4** (1970), 745–757, DOI `10.1007/BF01066485` | Estados assintóticos carregados exigem modificação do Fock ingênuo para lidar com infravermelho; a construção é específica de espalhamento em QED. | **USADO: resumo original e registro da revista; prova integral PENDING.** |
| **HRF-REF-0086** | D. Buchholz, *Gauss' law and the infraparticle problem*, Physics Letters B **174** (1986), 331–334, DOI `10.1016/0370-2693(86)91110-X` | Sob hipóteses sobre fluxo assintótico de Gauss, um estado carregado não pode ser autoestado do operador de massa. | **USADO: resumo e início do texto original disponibilizado pelo autor; prova completa PENDING.** |
| **HRF-REF-0087** | J. Mund, K.-H. Rehren & B. Schroer, *Infraparticle quantum fields and the formation of photon clouds*, JHEP **04** (2022) 083, DOI `10.1007/JHEP04(2022)083`, arXiv:2109.10342 | Modelo exatamente solúvel de campo de Dirac vestido com estrutura infravermelha e nuvens de fótons; é **modelo intermediário não interagente**, não QED4 completa. | **USADO: texto integral acessível, seções 1.1–1.2 e eqs. (1.1)–(1.3) efetivamente lidas; prova do restante PENDING.** |

**Correção epistemológica importante [F/?]:** a inexistência de um autoestado de massa pontual num setor infrapartícula **não elimina** a massa física inferida experimentalmente, o limiar espectral ou parâmetros de renormalização. Não identificar `m_e≈0,511 MeV` com um autovalor isolado de `P_μP^μ` sem discutir a estrutura infravermelha. O teorema de Buchholz tem hipóteses; não atribuir automaticamente sua conclusão a toda representação possível nem a modelos com fóton massivo.

**Cuidado em [0087]:** os autores dizem expressamente que o modelo intermediário não contém ainda a interação QED; na etapa intermediária a carga total é zero, enquanto a lei de Gauss local em QED é discutida na primeira ordem perturbativa. **Não** registrar como construção não perturbativa completa de elétron interagente.

## 3. Fórmulas e costura G-GAUGE-4 — carga, dressing, setores e massa

**[F] Lei de Gauss integrada, unidades convencionais apropriadas:**

`(∇·E − ρ)|Ψ_phys⟩ = 0`, portanto `Q_R = ∫_R ρ d³x = ∮_{∂R} E·dS` em estados físicos e para contornos compatíveis.

**[F] Forma de dressing não local ilustrativa [0087, eqs. (1.1)–(1.3)]:**

`Ψ_d(x) = exp[i q ∫_{Γ_x}^{∞} A_μ(y) dy^μ] ψ(x)` (com orientação e transformações de gauge/condições no infinito consistentes). O integral em linha isolada é formal e IR-singular: a construção rigorosa do artigo usa integração/smearing de direções e espaço de estados apropriado. Essa fórmula **não** constitui um dicionário holográfico `D` nem determina `m_e`.

**[F] Modelo analítico mínimo de centro elétrico — sem execução numérica:** em rede `Z₂` com links elétricos `X_ℓ=±1` e carga de matéria `(-1)^{n_v}`, as restrições locais `G_v=(-1)^{n_v}∏_{ℓ∋v}X_ℓ=+1` implicam, multiplicando todos os vértices de `R`,

`(-1)^{N_R} = ∏_{ℓ∈∂R} X_ℓ`.

Links interiores aparecem duas vezes e cancelam (`X_ℓ²=1`). Portanto, criar carga ímpar em `R` sem alterar o fluxo elétrico na fronteira viola a restrição. Trata-se de **dedução algébrica de Gauss em toy model Z₂**, não de simulação, e não demonstra um elétron de QED4. A versão U(1) usa soma orientada de fluxos no lugar do produto de paridades.

**[F] Centro e entropia:** para uma álgebra com setores de fluxo ortogonais e decomposição em blocos `ρ_R=⊕_q p_q ρ_{R,q}`,

`S(ρ_R)=−Σ_q p_q ln p_q + Σ_q p_q S(ρ_{R,q})`.

Se cada bloco for puro, resta a entropia de Shannon dos setores. Essa identidade **não** implica que `S` seja área RT ou que Rényi-2 se decomponha linearmente do mesmo modo.

**[D] G-GAUGE-4 (novo):** antes de chamar um modo de 'elétron reconstruído', exigir (i) estado espinorial carregado gauge-invariante; (ii) dressing e fluxo assintótico; (iii) tratamento de setores soft/infrapartículas e significado operacional da massa; (iv) álgebra e centros das regiões, regulador e estados; (v) mapas G e D separados, sem inserir `m_e` por ajuste oculto. Gates G-GAUGE-2/3 permanecem válidos e cumulativos.

## 4. Reexame de Tjoa–Gray [HRF-REF-0055] — gate Γ

**[F, domínio restrito]** Releitura direta das seções III.5 e IV e eqs. (47), (50), (51), (57)–(58) do texto integral arXiv:2204.13133. A projeção precisa satisfazer `σ(φ₁,φ₂)=σ_𝓘(Γφ₁,Γφ₂)` e `W(f,g)=W_𝓘(ΓEf,ΓEg)`; a receita assintótica é

`ΓEf = lim_(r→∞) Ω⁻¹ Ef`, com `Ω=1/r` no chart Bondi considerado.

A métrica é então formalmente recuperada de uma combinação de derivadas da inversa da função de Wightman (equação 51) ou de diferenças finitas (equação 58). O próprio artigo identifica o **propagador causal E** como gargalo clássico. Como E depende do operador hiperbólico do bulk e, portanto, da geometria usada para defini-lo, a aplicação **não estabelece por si só** um algoritmo independente de reconstrução da métrica a partir apenas de dados de fronteira sem informação bulk auxiliar. Isto é uma **lacuna de independência de entrada para o objetivo mais forte do HRF**, não prova de circularidade interna ou invalidade do resultado de Tjoa–Gray.

**[D] G-GAMMA-2:** listar, para cada exemplo, quais componentes de `g`, propagador `E`, compactificação `Ω`, escolha de coordenadas, smearing `f,g` e dados de contorno são previamente fixados. Exigir comparação com um caso em que `E` seja reconstruído de observáveis independentes, ou rotular a reconstrução como **condicional**. **Não** transportar esse resultado para QED interagente, férmions vestidos ou equações de Einstein sem nova demonstração.

## 5. Novos arquivos HRF no Drive: resultados reportados, não replicados

**[M — apenas reportado] ELETRON-71**, relatório 14/10/2026 12:39 BRT, examina campos Maxwell livres 2D3V e centros elétrico/magnético; relata classes pré-registradas H71-P/E/M/D/S/T/Q e controles internos PASS. O resultado **H71-Q = nenhuma carga no campo livre** concorda com Gauss e é diretamente pertinente ao G-GAUGE-4. O relatório explicita que `f_c` é índice indicativo de Rényi-2, **não fração física do bit**, e que a regra 'RT' foi uma escolha operacional, **não uma dualidade holográfica demonstrada**. A análise foi realizada por Claude em outra execução, com uma rede/caixa, sem réplica independente neste ciclo; resultados e hashes não foram auditados aqui. Não classificar como evidência empírica de elétron, spin 1/2, massa ou gravidade.

**[M/? — apenas reportado] STAR-01 v0.2**, nota 14/10/2026: em teste de reconstrução de estrelas AdS4 baseado em Treviño (2017), 13/18 comparações de massa com figuras permanecem divergentes; a correção de cauda e a fórmula de massa assintótica usual não resolveram as diferenças, e não foi demonstrado erro no artigo original. Não converter esse teste de estrela de bósons/radiação em derivação da massa do elétron. As referências Treviño (2017), Astefanesei–Radu (2003) e Fischetti–Kelly–Marolf (2012) ficam **HRF-PEND** neste ciclo por não terem sido auditadas diretamente na fonte primária; sem atribuição de novos IDs.

## 6. Situação das fontes anteriores e frentes negativas

| IDs/objetos | Situação neste ciclo | Limite |
|---|---|---|
| [0055] Tjoa–Gray | **USADO, eqs. 47, 50, 51, 57–58 e seções III.5/IV lidas diretamente** | prova completa e independência do mapa Γ PENDING |
| [0083] Wilson-Gerow–Stamp | **USADO ANTERIORMENTE; confrontado conceitualmente com [0084–0087]** | detalhes da prescrição espinorial/IR e confronto equação por equação PENDING |
| [0075], [0079], [0080] | **USADOS ANTERIORMENTE; contexto algébrico** | equivalência de centros sob mesmo buffer e QED4 interagente PENDING |
| [0013–0014], [0035–0036], [0078] RT/HRT/QES/JLMS | **NÃO RELIDOS neste ciclo** | nenhuma aplicação nova validada a setores infrapartículas |
| [0052], [0064], [0066–0067] | **NÃO RELIDOS neste ciclo** | provas integrais e condições de aplicabilidade ainda PENDING |
| [0031] Val Baker | **NÃO REAUDITADO**; auditoria algébrica interna de 09/10 consta do histórico | não validar alegações de massa holográfica sem parâmetros independentes |

**[?] Frente negativa QED4 → geometria dinâmica → massa:** pesquisa focalizada em dressing, IR e infrapartículas encontrou **obstáculos conceituais adicionais**, não uma derivação completa. Não foi realizada revisão negativa exaustiva de toda literatura. Não se conclui inexistência absoluta. A massa experimental permanece observável, mas o alvo teórico deve ser explicitado como parâmetro renormalizado/limiar espectral em setor carregado, não automaticamente polo isolado.

**[D] Próximo bloco:** (1) confrontar [0083] com [0087] e a escolha de álgebra regional em QED espinorial; (2) especificar controle analítico de setor de carga em rede U(1) com matéria, sem executar antes de autorização quando requerida; (3) separar dados independentes/pressupostos no cálculo Γ/E de Tjoa–Gray; (4) retomar full-text Takeda, Sugiura–Takeda, Bousso–Kaya; (5) incorporar o resultado E71 apenas após auditoria de protocolo/código/observáveis, preservando falhas e a diferença Rényi-2/von Neumann.

## 7. Referências de acesso e proveniência

- [0084] DOI: https://doi.org/10.1139/p55-081 ; resumo original: https://cir.nii.ac.jp/crid/1362544418751248000
- [0085] Registro primário: https://www.mathnet.ru/eng/tmf4141 ; DOI: https://doi.org/10.1007/BF01066485
- [0086] DOI: https://doi.org/10.1016/0370-2693(86)91110-X ; cópia do autor: https://www.researchgate.net/publication/256576300_Gauss%27_law_and_the_infraparticle_problem
- [0087] Texto original: https://arxiv.org/html/2109.10342 ; editora: https://link.springer.com/article/10.1007/JHEP04(2022)083
- [0055] Texto original: https://arxiv.org/html/2204.13133 ; DOI: https://doi.org/10.1103/PhysRevD.106.025021
- Cap. 0.1 v0.2: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view
- HRF E71: https://drive.google.com/file/d/1wm_eQBWytZOUJ1Q-0Hmb8EDvAjAbKtBi/view
- HRF STAR-01: https://drive.google.com/file/d/1E9Foh4REkgGVcUqOLtuMAoI1sbJ8jl33/view

**Histórico:** CP-11 (14/10/2026 13:09 BRT) integra os quatro novos trabalhos [0084–0087], a revisão de Γ em [0055], e os relatórios internos E71/STAR-01. O novo caderno v0.9 inclui literalmente a v0.8 e este checkpoint; o índice v1.1 mantém [0001–0083] e acrescenta [0084–0087]. Versões anteriores não devem ser sobrescritas.



---

## 31. CP-12 incorporado — 15/10/2026 01:10 BRT

# HRF — Checkpoint bibliográfico CP-12

**Data:** 15/10/2026 01:10 BRT  
**Base cumulativa:** v0.9 / CP-01–CP-11; índice v1.1 com HRF-REF-0001–0087.  
**Novo estado:** caderno cumulativo v1.0; índice enxuto v1.2, HRF-REF-0001–0091.  
**Mapa prioritário:** D (QED espinorial física → álgebra/região/boundary), com controles G separados; W não estudado nesta rodada.  
**Método:** RUP B → A, classificação [F]/[M]/[H]/[?]/[D]. Nenhuma simulação executada.

## 1. Ordem de leitura e proveniência

1. **[D] Cap. 0.1 v0.2 lido integralmente nesta execução**, fonte: `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`. Preservados §§0.1.5, 0.1.13–0.1.17: interfaces verificáveis, G/W/D separados, nunca identificar entropia de toy model com RT/QES por definição.
2. **Arquivos do Projeto/conversa:** caderno v0.9 e índice v1.1 recuperados integralmente do runtime; 87 IDs contínuos verificados. A busca semântica do catálogo da conversa não retornou resultados, mas os arquivos originais montados estavam disponíveis e foram efetivamente lidos.
3. **Drive HRF:** conferidos os três originais do CP-11 por metadados e pasta-pai; lido `HRF_ELETRON_71_RELATORIO_2026-10-14_1239-clau.md` (ID `1wm_eQBWytZOUJ1Q-0Hmb8EDvAjAbKtBi`), sem reproduzir a execução.
4. **Literatura externa primária:** relidas seções/equações selecionadas de [0083] e [0087]; conferidos texto da revista e trechos de [0088], resumo editorial de [0089–0090], texto integral com seções selecionadas de [0091]. As demonstrações completas **não foram rederivadas**.

## 2. Resultados bibliográficos novos e nível de leitura

| ID | Obra, metadados verificados | Uso e limites | Nível real de leitura |
|---|---|---|---|
| **HRF-REF-0088** | D. Carney, L. Chaurette, D. Neuenfeld, G. W. Semenoff, *Dressed infrared quantum information*, Physical Review D **97**, 025007 (2018), DOI `10.1103/PhysRevD.97.025007`. | **USADO:** o espalhamento com estados eletrônicos vestidos por fótons suaves afeta coerências e informação do setor IR; não fornece dicionário RT nem massa emergente. | Resumo, conclusão e apêndice visíveis na fonte editorial; **auditoria integral PENDING**. |
| **HRF-REF-0089** | H. Hirai, S. Sugishita, *Dressed states from gauge invariance*, JHEP **06** (2019) 023, DOI `10.1007/JHEP06(2019)023`. | **USADO:** a condição gauge apropriada/Gauss orienta o dressing de estados assintóticos e a S-matrix IR-finita; domínio de espalhamento assintótico, não região finita do E71. | **Resumo e metadados editoriais**, prova integral PENDING. |
| **HRF-REF-0090** | D. Carney, L. Chaurette, D. Neuenfeld, G. Semenoff, *On the need for soft dressing*, JHEP **09** (2018) 121, DOI `10.1007/JHEP09(2018)121`, arXiv:1803.02370. | **USADO:** o tratamento inclusivo e o vestido podem diferir em superposições de momento; não se deve escolher prescrição IR apenas por conveniência numérica. | Resumo primário indexado e metadados editoriais; **prova integral PENDING**. |
| **HRF-REF-0091** | R. Bousso, E. Tabor, *Simple holography in general spacetimes*, JHEP **10** (2025) 020, DOI `10.1007/JHEP10(2025)020`, arXiv:2505.00695. | **USADO:** construção de *simple wedge* em espaços-tempos gerais a partir de *lightsheets* antinormais; geometria lorentziana e hipóteses de focalização são **entradas**, não geometria derivada de QED. Seu “zigzag” de folhas nulas **não** é o zigue-zague de transporte da malha HRF. | Resumo, introdução, §§2.1–2.2, definições e eqs. (10)–(13) lidas; **prova dos teoremas PENDING**. |

## 3. Confronto equação a equação: QED espinorial [0083] × modelo vestido [0087]

**[F] Wilson-Gerow–Stamp [0083], §2.3, eqs. (30)–(37):** o funcional de caminho integra campos de Dirac e Maxwell; a ação espinorial já contém **massa m como parâmetro explícito** (eq. 31). A invariância sob `A_μ→A_μ+∂_μΛ`, `ψ→e^(ieΛ)ψ` conduz à restrição de Gauss na amplitude de fronteira, `(∂_j E^j−J^0)K=0` (eq. 36). O dressing coulombiano é determinado pelo problema de contorno, mas Gauss isoladamente não fixa a parte transversa do campo (discutido em eqs. 1–6). **Não deriva m_e nem a geometria.**

**[F] Mund–Rehren–Schroer [0087], §§1.3, 3.1 e 3.3:** modelo exatamente solúvel do campo de Dirac vestido, com `ψ_(q,e)(x)=exp[iq φ(x,e)] ψ_0(x)` (eq. 3.1, formal antes de regularização). O modelo intermediário é cinemático, **sem interação QED completa**. O texto observa explicitamente que **a lei de Gauss global não vale no modelo intermediário** (discussão §1.3); logo, a nuvem infravermelha e os setores de superseleção não constituem prova de uma carga de QED plenamente dinâmica. A massa `M` já aparece na equação de Dirac que o modelo veste (§3.1). Seu limiar espectral não é autovalor de massa isolado.

**[?] Comparação:** [0083] fornece um esquema para estados/propagadores gauge-invariantes com QED espinorial e fronteiras; [0087] oferece controle infravermelho não perturbativo em modelo intermediário. **Não** se demonstrou equivalência das duas construções, dos setores de Hilbert, dos operadores de borda ou de seus estados reduzidos. Requer mapa explícito e critérios de IR/UV para usar como entrada de G/D.

## 4. Controle analítico mínimo U(1) — carga, fluxo e entropias (sem simulação)

**[F, álgebra elementar]** Em rede orientada U(1) compacta, fluxos inteiros `E_ℓ∈ℤ` e cargas `q_v∈ℤ` obedecem a `G_v=Σ_{ℓ sai de v} E_ℓ−Σ_{ℓ entra em v}E_ℓ−q_v=0`. Somando sobre vértices de uma região `R`, cancelam-se fluxos internos:

`Q_R = Σ_(v∈R) q_v = Σ_(ℓ∈∂R) s_(R,ℓ) E_ℓ`.

**Exemplo simbólico:** cadeia `v1→v2→v3`, `E_12=E_23=1`, `q=(+1,0,−1)` satisfaz Gauss em cada vértice. Para `R={v1,v2}`, `Q_R=+1=E_23`; a carga local exige fluxo na fronteira. Em rede fechada periódica sem borda física, `Σ_v q_v=0` para Gauss sem background: **não é possível inserir carga total líquida isolada sem modificar setor, contorno ou introduzir fundo**. Isso importa para a caixa periódica do E71, cujo teste de cargas estáticas usa par `+1/−1`.

**[F, identidade espectral]** Para blocos de superseleção `ρ_R=⊕_q p_q ρ_q` com `Trρ_q=1`,

`S_1(ρ_R)=−Σ_q p_q ln p_q + Σ_q p_q S_1(ρ_q)`;

`S_2(ρ_R)=−ln[Σ_q p_q² Tr(ρ_q²)]=−ln[Σ_q p_q² exp(−S_2(ρ_q))]`.

**Contraexemplo analítico à identificação S₂=S₁:** dois setores ortogonais puros com probabilidades `p=(3/4,1/4)` dão `S_1≈0,562335` nats e `S_2=−ln(5/8)≈0,470004` nats; diferença `≈0,092332` nats. É apenas cálculo fechado de entropia de matriz diagonal, **não é rodada E71 nem resultado de gravidade**. O caso de probabilidades iguais `p=(1/2,1/2)` teria ambas `ln2`, portanto igualdade pontual não valida equivalência geral.

**[D] G-GAUGE-5:** para cada resultado E71, registrar tipo de álgebra/centro, estado físico e fluxo de Gauss, regulador, probabilidade setorial `p_q`, entropia realmente medida (`S₂` versus `S₁`), efeito do dressing/soft modes e eventual correspondência com `S_gen=Área/(4G_N)+S_vN(bulk)+…`. **Não** interpretar o índice `f_c` do E71 como fração física do bit, nem substituir S_vN por S₂ numa alegação RT/QES sem justificativa.

## 5. Releitura de fronteiras de validade e frentes negativas

**[M — somente relatório] E71:** reporta H71-Q sem carga persistente em campo Maxwell livre e checagens de Gauss de pares estáticos. Uma única rede periódica 64×74, sem réplica independente nem auditoria do pacote nesta rodada. Relata índice de Rényi-2 e RT operacional; isso não é dualidade gravitacional, nem elétron. **Gate G-GAUGE-5 PENDING.**

**[F/?] Bousso–Tabor [0091] e Bousso–Kaya [0066–0067]:** *simple wedge* e desigualdades de área além de AdS são avanços condicionais em geometrias/gravitating wedges; [0091] assume um espaço-tempo lorentziano com métrica e, na discussão clássica, Einstein + condição de energia nula; no regime quântico emprega condições de focalização/entropia generalizada. [0067] requer independência mútua das regiões e regime estático. **Não** equivalem à derivação de geometria dinâmica a partir de QED. [0066–67] conferidos por resumos originais neste ciclo, sem nova auditoria de provas.

**[?] G-GAMMA-2 [0055]:** preservada a lacuna já documentada sobre independência de `Γ`, propagador causal `E` e métrica de entrada no resultado de Tjoa–Gray. O texto integral **não foi reexaminado nesta rodada**; status anterior de leitura de equações permanece histórico, não nova validação.

**[?] QED4 → geometria gravitacional dinâmica → massa 511 keV:** nenhuma fonte nova deste ciclo fornece a derivação; [0083] contém `m` na ação, [0087] contém `M` na equação, [0088–0090] tratam dressing/IR. **Busca focalizada, não negativa exaustiva**; inexistência universal não alegada. [0031] Val Baker **não reavaliado**; auditoria interna de 09/10 permanece no histórico.

**Não relidos neste ciclo:** [0052] Takeda 2022, [0064] Sugiura–Takeda 2023, provas integrais [0066–0067], demonstrações de JLMS/first-law→Einstein. Permanecem PENDING, não PASS.

## 6. Próximo bloco e gates

1. Verificar no pacote/protocolo do E71 a fórmula exata de `f_c`, sua álgebra e a correspondência com os setores U(1) compactos; **sem executar simulação não autorizada**.
2. Investigar estados carregados em volume finito com fronteira aberta ou fluxo de background; comparar prescrições elétricas/magnéticas e S₁/S₂ em um mesmo estado definido.
3. Retomar provas de Takeda/Sugiura–Takeda/Bousso–Kaya e separar pressupostos de métrica de resultados reconstruídos; revisar `Γ/E` de Tjoa–Gray.
4. Definir se há um estado físico de QED₄ vestido cujo espaço de observáveis possa servir como boundary de um dicionário D, sem introduzir massa por parâmetro oculto.

## 7. Fontes primárias e referências de acesso

- [0083] https://arxiv.org/html/2011.05305 — §2.3, eqs. (30)–(37) lidas.
- [0087] https://arxiv.org/html/2109.10342 — §§1.3, 3.1, 3.3 e eq. (3.1) lidas; prova integral não auditada.
- [0088] https://doi.org/10.1103/PhysRevD.97.025007 — resumo, conclusão e apêndice consultados.
- [0089] https://doi.org/10.1007/JHEP06(2019)023 — resumo editorial consultado.
- [0090] https://doi.org/10.1007/JHEP09(2018)121 — resumo e metadados consultados.
- [0091] https://arxiv.org/html/2505.00695 — §§2.1–2.2 e eqs. (10)–(13) lidas; DOI https://doi.org/10.1007/JHEP10(2025)020.
- [0066–0067] https://doi.org/10.1103/PhysRevD.110.066017 ; https://doi.org/10.1103/PhysRevD.111.086014 — resumos editoriais revisitados.
- Cap. 0.1: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view
- E71: https://drive.google.com/file/d/1wm_eQBWytZOUJ1Q-0Hmb8EDvAjAbKtBi/view

**Histórico:** CP-12 (15/10/2026 01:10 BRT) acrescenta [0088–0091], G-GAUGE-5 e análise U(1)/S₁/S₂; mantém integralmente CP-01–CP-11 e todos os resultados negativos/pendentes. Nenhum arquivo histórico é sobrescrito.

---

## 32. CP-13 incorporado — 15/10/2026 13:08 BRT

### 32.1 Leitura e reconciliação documental

- **Cap. 0.1 v0.2 [D]**: lido integralmente, §§0.1.1–0.1.17, no Drive (ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`). RUP B→A; não converter dados de discretização ou Rényi-2 operacional em dualidade G/D. Classes [F]/[M]/[H]/[?]/[D] mantidas.
- **Arquivos do Projeto/conversa**: inspecionados os originais locais do caderno v1.0 (91 IDs e CP-01–12, 1.167 linhas) e índice v1.2 (91 linhas); consulta semântica a documentos HRF na Library (incluindo nota de arquitetura 2D). Não há base para afirmar leitura de todos os documentos históricos do Projeto.
- **Drive HRF**: lidos o protocolo E71 (`HRF_ELETRON_71_PROTOCOLO_2026-10-14_1144-clau.md`, ID `1poOjE14F6DzKQv-TWiQMJPuZttJO8BYj`) e o relatório executado (`HRF_ELETRON_71_RELATORIO_2026-10-14_1239-clau.md`, ID `1wm_eQBWytZOUJ1Q-0Hmb8EDvAjAbKtBi`); consultada a orientação boundary 2D, ID `12qpZUwai8ZNC83T1Vj19JXmFsrZr2Dv-`. **Os scripts e dados brutos E71 não foram reexecutados nem auditados independentemente.**
- **Pendência CP-12 resolvida:** os três `.md` originais do CP-12 foram enviados com `source_file_ref` ao diretório de Drive `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`, sem sobrescrever. IDs novos: checkpoint `1WpL4hDj4FFLRM9eIVc17le_tHHcZyhJl`, cumulativo v1.0 `1Rb29rVw_5X1k08p-PzxjTMhuk5Y_Joyp`, índice v1.2 `1O_FMfm3vXNa6b417otcno4vm6ynUSjWr`. Conteúdo e nomes confirmados por leitura do Drive.

### 32.2 Novas fontes primárias verificadas

| ID | Obra | Leitura efetiva | Uso e limites |
|---|---|---|---|
| **HRF-REF-0092** | Xi Dong, *The gravity dual of Rényi entropy*, Nature Communications **7**, 12472 (2016), DOI `10.1038/ncomms12472`; https://www.nature.com/articles/ncomms12472 | **Texto aberto**: introdução, enunciado do resultado, derivação por réplica (seções e equações principais); **prova integral não rederivada**. | **USADO**: em holografia gravitacional, o objeto geométrico natural para Rényi-n é uma *cosmic brane* com retroação; não basta aplicar a área RT usual a `S₂` de um toy model. |
| **HRF-REF-0093** | A. Belin, L.-Y. Hung, A. Maloney, S. Matsuura, R. C. Myers, T. Sierens, *Holographic Charged Renyi Entropies*, JHEP **12** (2013) 059, DOI `10.1007/JHEP12(2013)059`; https://arxiv.org/abs/1310.4180 | **Texto aberto em HTML**: definição de `S_n(μ)`, seção 2.1 (Wilson line) e conclusão; **cálculos gravitacionais completos não auditados**. | **USADO**: potencial químico acoplado a carga global conservada em CFT holográfica, com holonomia de fundo; **não é automaticamente** a decomposição por centro de fluxo elétrico em U(1) gauge dinâmico do E71. |

**Status de fontes antigas:** [0071–0080] continuam USADAS como enquadramento de álgebra/centros/edge modes, mas não rederivadas nesta rodada; [0083], [0087–0090] são fontes de *dressing* e infrapartículas, não prova de massa emergente. Takeda [0052], Tjoa–Gray [0055], Sugiura–Takeda [0064], Bousso–Kaya [0066–0067], JLMS/first-law→Einstein e Val Baker [0031]: **sem nova auditoria integral nesta execução**.

### 32.3 Auditoria de interpretação do ELETRON-71 — G-GAUGE-6

**Definição exata do protocolo [D]:** `f_c = 1 − ΔS₂(cond)/ΔS₂(compl)` avaliado no raio do pico da leitura completa. `ΔS₂` é variação de Rényi-2 relativa ao vácuo; `cond` é média por setor do centro; `compl` é leitura completa. O próprio protocolo avisa: **`f_c` não é porcentagem física do bit, nem entropia destilável operacional**. A frase do relatório “H71-E = DESTILÁVEL” deve ser entendida como **rótulo de classificação interna** do teste (`f_c ≤ 0,10`), não como prova de destilação LOCC ou fração de entropia de von Neumann.

**Números reportados [M, não replicados]:** `f_c(UE, d=0)=0,056; 0,033; 0,022; 0,018` para `w=4–7`. Para `w=4, d=0`, `f_c(ZE)=0,67`, `f_c(UE)=0,06`; para `w=4, d=2w`, `f_c(ZE)=0,02`, `f_c(UE)=0,61`. Esses valores indicam **sensibilidade ao centro e à posição da região** no modelo; não medem carga elétrica do quantum. O relatório declara `H71-Q = NENHUMA CARGA NO CAMPO LIVRE` e ressalta que **helicidade não é carga elétrica**. A carga `+1/−1` usada no protocolo foi fonte estática externa apenas para testar Gauss, **sem estado quântico carregado calculado**.

**Limitações registradas pelo próprio E71:** `S₁` de von Neumann do estado de Fock **não calculada**; regra “Ryu–Takayanagi” **escolhida** operacionalmente, sem dualidade demonstrada; linearização quadrática de `U_nm` sem compacidade; modo constante/harmônicos do toro excluídos; uma única caixa/rede, instante `t=0`, sem réplica externa; limiares definidos depois da fumaça. Portanto: PASS dos controles internos reportados **não é** PASS de G ou D, nem evidência de massa, spin 1/2 ou elétron físico.

### 32.4 Equações de confronto [F] e cálculo analítico mínimo [D]

Se a álgebra regional tem setores ortogonais `q` e `ρ_R = ⊕_q p_q ρ_{R,q}` com `Tr ρ_{R,q}=1`, então:

```
S_1(ρ_R) = H(p) + Σ_q p_q S_1(ρ_{R,q})
S_2(ρ_R) = -ln[Σ_q p_q² exp(-S_2(ρ_{R,q}))]
S_2^cond (média por setor) = Σ_q p_q S_2(ρ_{R,q})  [convenção, NÃO decomposição de S_2]
```

**Contraprova analítica de equivalência de “frações”:** dois setores com `p_0=p_1=1/2`, `ρ_0=I₂/2` e `ρ_1=|0⟩⟨0|` dão `S₂^cond = (ln 2)/2 = 0,346574`, `S₂(ρ_R)=−ln(3/8)=0,980829`, e `1−S₂^cond/S₂(ρ_R)=0,6467`. Já a fração do termo clássico na entropia von Neumann é `H(p)/S₁(ρ_R)=ln2/(3ln2/2)=2/3≈0,6667`. **A razão de Rényi-2 não coincide em geral com a fração de von Neumann**, mesmo antes da subtração do vácuo do E71. Cálculo algébrico ilustrativo; **não é execução da bancada**.

**Rényi holográfica [0092]:** `S_n=(1/(1−n))ln Trρ^n`, mas o enunciado geométrico clássico é para a entropia refinada `S̃_n=n² ∂_n[((n−1)/n)S_n] = Área(C_n)/(4G_N)`, com tensão `T_n=(n−1)/(4nG_N)` da brana cósmica. Em `n→1`, recupera-se RT em hipóteses adequadas. Isso **não autoriza** converter o `ΔS₂` do E71 diretamente em área de RT ou de uma brana cósmica: faltam teoria holográfica boundary, bulk gravitacional, dicionário D, geometria com retroação e correspondência de entropias.

**Rényi carregada [0093]:** para carga conservada `Q_A` em setor apropriado, `ρ_A(μ)=ρ_A exp(μQ_A)/Tr[ρ_A exp(μQ_A)]` e `S_n(μ)=(1/(1−n))ln Tr[ρ_A(μ)^n]`. No artigo, `Q_A` é uma carga **global** de CFT, e a construção usa potencial de gauge **de fundo** e linha de Wilson em torno da superfície de emaranhamento. Isso **não é**, por identidade, o centro de fluxo de Gauss de uma região com gauge dinâmico nem um elétron vestido da QED₄.

### 32.5 Gate proposto e lacunas [D/?]

**G-GAUGE-6 [D] — PRÉ-REQUISITOS PARA INTERPRETAÇÃO FÍSICA (NÃO TESTADO):** (i) especificar álgebra física gauge-invariante, fluxos de borda e setores de superseleção; (ii) construir estado carregado dinâmico, com `q_R=Σ_{∂R}E` e *dressing* consistente (em toro periódico, carga total zero sem fundo/condições especiais); (iii) calcular `S₁` e `S₂` completos e condicionais no mesmo estado e regulador, sem interpretar `f_c` como fração de bit; (iv) separar Rényi ordinária, Rényi refinada holográfica e Rényi com potencial químico; (v) testar um dicionário D e mapa G independentes antes de falar em RT/QES/JLMS físico; (vi) verificar limite contínuo/refinamento, IR e condições de contorno. **Status PENDING/NOT_EXECUTED.**

**Frentes abertas:** provas completas de [0052], [0055], [0064], [0066–0067]; independência de `Γ` e propagador `E`; área de wedge versus entropia de matéria; JLMS e primeira lei→Einstein; spin 1/2, estatística fermiônica e setor infrapartícula da QED₄; origem não ajustada de `m_e≈511 keV`; réplica independente de E71. A pesquisa bibliográfica **não** estabelece impossibilidade de uma futura derivação, mas **não encontrou nesta rodada** uma derivação QED₄→geometria dinâmica→massa eletrônica.

### 32.6 Histórico e próximo bloco

**CP-01–CP-12** preservados integralmente no Caderno cumulativo v1.0; **CP-13** acrescenta duas referências [0092–0093], o confronto de Rényi ordinária/refinada/carregada, a leitura do protocolo E71 e G-GAUGE-6. O índice de referências permanece **somente ID → título**, sem estados de leitura.

**Próximo bloco:** obter código/dados brutos E71 e conferir o cálculo de `ΔS₂` e `f_c` (somente mediante autorização para executar); avançar para um estado físico de matéria carregada em U(1), incluindo dressing/fluxo e `S₁`; retomar a prova de Takeda/Sugiura–Takeda e os limites de Tjoa–Gray; auditar JLMS/first-law→Einstein. **Não executar simulações sem autorização.**

### 32.7 Fontes de acesso

- Cap. 0.1 v0.2: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view
- Protocolo E71: https://drive.google.com/file/d/1poOjE14F6DzKQv-TWiQMJPuZttJO8BYj/view
- Relatório E71: https://drive.google.com/file/d/1wm_eQBWytZOUJ1Q-0Hmb8EDvAjAbKtBi/view
- Dong (2016): https://www.nature.com/articles/ncomms12472
- Belin et al. (2013): https://arxiv.org/abs/1310.4180
- Arquivos CP-12 recuperados: checkpoint https://drive.google.com/file/d/1WpL4hDj4FFLRM9eIVc17le_tHHcZyhJl/view ; caderno v1.0 https://drive.google.com/file/d/1Rb29rVw_5X1k08p-PzxjTMhuk5Y_Joyp/view ; índice v1.2 https://drive.google.com/file/d/1O_FMfm3vXNa6b417otcno4vm6ynUSjWr/view

---

## 33. CP-14 incorporado — 16/10/2026 01:08 BRT

# HRF — Checkpoint bibliográfico CP-14

**Data:** 16/10/2026 01:08 BRT  
**Programa:** Holographic Reconstruction Framework (HRF), pesquisa bibliográfica RUP B → A.  
**Entrada documental:** CP-13, caderno cumulativo v1.1 (1233 linhas, 93 referências), índice v1.3.  
**Saída:** caderno cumulativo v1.2, índice v1.4, IDs HRF-REF-0001–0096.  
**Mapas:** G (reconstrução geométrica) e D (dicionário holográfico) em auditoria bibliográfica; W **não testado**.  
**Execuções:** nenhuma simulação, nenhuma reprodução numérica da E71, nenhuma prova integral independente.

## 1. Ordem obrigatória de consulta e proveniência

1. **Projeto/arquivos de conversa**: busca semântica do HRF e nota de arquitetura boundary 2D; lido o roteiro PDST do Projeto e conferida a separação G/W/D. Não reivindicamos leitura integral de todos os anexos históricos.
2. **Capítulo 0.1 v0.2**: lido integralmente (27.751 caracteres) a partir do arquivo Markdown do Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, §§0.1.1–0.1.17; B→A, [F]/[M]/[H]/[?]/[D], gates e restrições contra promoção de toy models a física estabelecida. A versão v0.1 permanece histórica, sem releitura integral neste ciclo.
3. **Drive HRF**: recuperados **arquivos Markdown originais**, não apenas trechos: caderno v1.1 (ID `1VbG_tG9DVwE-lBqaye9fREBY5P22zBCe`), índice v1.3 (`1C-6JuUEHlFXfzPJByMo-g-ZV1-7vQ4sP`), checkpoint CP-13 (`1Rn065phzGjkjjcVlhWSEcfmBbVrkqc7h`), relatório E71 (`1wm_eQBWytZOUJ1Q-0Hmb8EDvAjAbKtBi`) e protocolo E71 (`1poOjE14F6DzKQv-TWiQMJPuZttJO8BYj`). A pasta de destino foi confirmada como `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`.
4. **Literatura externa primária**: textos completos HTML de JLMS [0036], Lashkari–Van Raamsdonk [0094], Blanco et al. [0095], Casini–Huerta–Myers [0096] e Takeda [0052] consultados em seções/equações específicas. Acesso a texto completo **não** equivale a auditoria integral de todas as demonstrações.

## 2. Novas referências normalizadas e status de leitura

| ID | Obra e proveniência | Leitura efetiva | Uso e limite |
|---|---|---|---|
| **HRF-REF-0094** | N. Lashkari e M. Van Raamsdonk, *Canonical energy is quantum Fisher information*, JHEP 04 (2016) 153; DOI `10.1007/JHEP04(2016)153`; https://arxiv.org/html/1508.00897 | **Texto integral acessado; §§2.1, 3.3–3.5 e equações (14)–(17), (45), (47), (49)–(50), (68) lidas seletivamente; prova completa não reproduzida.** | **USADO:** a segunda variação de entropia relativa corresponde à energia canônica para perturbações holográficas controladas de AdS; não para QED₄ arbitrária. |
| **HRF-REF-0095** | D. D. Blanco, H. Casini, L.-Y. Hung e R. C. Myers, *Relative Entropy and Holography*, JHEP 08 (2013) 060; DOI `10.1007/JHEP08(2013)060`; https://arxiv.org/html/1305.3182 | **Texto integral acessado; introdução e equações (2), (6)–(13), (24)–(27) lidas seletivamente; prova completa não reproduzida.** | **USADO:** primeira lei e Hamiltoniano modular local para bola no vácuo de CFT; o teste de black brane é perturbativo e não generaliza para elétron massivo. |
| **HRF-REF-0096** | H. Casini, M. Huerta e R. C. Myers, *Towards a derivation of holographic entanglement entropy*, JHEP 05 (2011) 036; DOI `10.1007/JHEP05(2011)036`; https://arxiv.org/html/1102.0440 | **Texto integral acessado; §§ de fluxo modular e eq. (22) lidas seletivamente; prova completa não reproduzida.** | **USADO:** origem conforme do Hamiltoniano modular local para bola de CFT; não transferir a QED₄ massiva. |

**Fontes antigas relidas (sem novos IDs):** [0036] JLMS (texto original, eqs. (1.2)–(1.4), (2.7), (3.8)–(3.9), Apêndice A, eqs. (A.22)–(A.24)); [0038] Faulkner et al. (resumo e condições do artigo original); [0052] Takeda (texto original, §§3.1–3.3, eqs. (3.9)–(3.12), conclusão). **Não** houve rederivação independente de JLMS, Einstein linearizado ou métrica BTZ.

## 3. [F] Entropia relativa com centro de álgebra: JLMS Apêndice A

Para a **mesma álgebra** e dois estados blocados por setores ortogonais `i`, com probabilidades `p_i`, `q_i` e estados normalizados `ρ_i`, `σ_i`, JLMS eq. (A.22) fornece:

```text
D(ρ||σ) = D_KL(p||q) + Σ_i p_i D(ρ_i||σ_i),
D_KL(p||q) = Σ_i p_i ln(p_i/q_i).
```

O primeiro termo é distinguibilidade **clássica entre distribuições de centro**, não automaticamente emaranhamento destilável; o segundo é distinguibilidade quântica **condicionada ao setor**. Requer `supp(p) ⊆ supp(q)` para finitude e uma identificação de setores/álgebra entre os estados. A fórmula não implica invariância de `D` sob **qualquer** troca de álgebra elétrica/magnética; a discussão de JLMS sobre independência de regularização/termos locais tem hipóteses próprias.

**Confronto analítico mínimo [F/M, álgebra apenas, sem simulação]:** com `p=(3/4,1/4)`, `q=(1/2,1/2)` e `ρ_i=σ_i` em cada bloco, a parcela quântica condicionada é zero, mas:

```text
D(ρ||σ) = (3/4) ln(3/2) + (1/4) ln(1/2) = 0,130812036...
H(p) = -(3/4)ln(3/4) -(1/4)ln(1/4) = 0,562335145...
S₂(p) = -ln[(3/4)^2+(1/4)^2] = 0,470003629...
```

As três quantidades **não são intercambiáveis**. Em particular, o índice operacional `f_c` da E71 baseado em variações de `S₂` não mede `D_KL` ou `D(ρ||σ)` sem uma definição de estados, centros, referência e cálculo independente.

**G-RELENT-1 [D, proposto; NOT_EXECUTED]:** exigir pares `(ρ,σ)` físicos na mesma álgebra, centro e regulador; calcular `D_KL`, `Σp D_i`, `S₁` e `S₂` separadamente; controlar fluxo elétrico e cargas dinâmicas; só então examinar um possível dicionário D. O toy analítico acima não é uma bancada U(1) executada nem uma prova de holografia.

## 4. [F] Primeira e segunda ordens não equivalem à derivação universal de gravidade

**Primeira lei:** `D(ρ||σ)=Δ⟨K_σ⟩−ΔS`, `K_σ=−ln σ`; para variações suaves próximas de `σ`, `δS=δ⟨K_σ⟩`. Para bola `B` no **vácuo de uma CFT** em Minkowski, [0095] eq. (10), [0096] eq. (22):

```text
K_B = 2π ∫_(|x|<R) d^(d−1)x [(R²−|x|²)/(2R)] T₀₀(x) + constante.
```

**Não** é fórmula local genérica do Hamiltoniano modular de QED₄ massiva ou de estados arbitrários. [0038] obtém equações de Einstein **linearizadas ao redor de AdS** quando entropias das bolas são dadas pela prescrição holográfica e demais hipóteses se verificam.

**Segunda ordem:** [0094], eqs. (49)–(50), sob suas convenções, para perturbações *on-shell* em AdS com regiões esféricas holográficas:

```text
∂²_λ D(ρ_B(λ)||ρ_B(0)) |_(λ=0) = 𝓔_B(δg,δg),
𝓔_B(δg,δg) = W_Σ(g,δg,𝓛_ξ δg) ≥ 0.
```

`W_Σ` é forma simplética gravitacional (energia canônica), não energia de um pacote elétrico genérico; fatores convencionais na definição da informação de Fisher precisam acompanhar a normalização da segunda derivada. O trabalho discute contribuições de matéria e correções de gauge (Hollands–Wald). **Nenhuma dessas relações fornece diretamente `m_e` ou demonstra G/D para o HRF.**

**G-EINSTEIN-2 [D, proposto]:** antes de afirmar gravidade derivada de entropia, exigir CFT holográfica especificada, estado de referência, todas as bolas/perturbações relevantes, dicionário stress tensor, RT/HRT/QES adequado, controle de ordem perturbativa e equações gravitacionais resultantes; não substituir por Rényi-2 E71.

## 5. [F] Takeda [0052] — condições e não unicidade

Releitura direta das eqs. (3.9)–(3.12): a distância holográfica infinitesimal usada para fixar o fator conforme é inferida de derivadas da entropia de intervalos `S'(α)` e do ponto holográfico, com fórmula local (3.12):

```text
2 G_N |δφ S'(α_λ(φ))| = √[g_μν(λ) δλ^μ δλ^ν]
```

O método depende de **coincidência entre causal wedge e entanglement wedge**, simetria estática e classe localmente AdS₃. Sem essa coincidência, a identificação de pontos via *light-cone cuts* e *hole-ography* exige um mapa de coordenadas não fornecido genericamente; o próprio artigo explicita essa lacuna. A reconstrução BTZ exemplificada é **exterior ao horizonte**. Portanto, reconstrução completa de uma métrica em **classe restrita** ≠ reconstrução única de qualquer métrica ≠ emergência independente de uma geometria dinâmica QED₄.

**G-METRIC-3 [D]:** matriz de dependências para cada algoritmo: entradas de entropia/correladores, hipóteses de wedges, identificação de pontos, métrica de fundo e dicionário D, cobertura espacial/temporal e classes de não unicidade. Tjoa–Gray [0055] `Γ/E` segue PENDING quanto à independência de entrada.

## 6. E71, lacunas e frentes negativas

- **[M, somente reportado] E71**: protocolo e relatório lidos; a busca por `E71_resumo.json` e `perfis.json` no Drive não retornou arquivos brutos individuais. A pasta `Test results` listada não mostrou uma pasta E71 direta. **Isso não demonstra ausência global de ZIP/dados**, apenas que não foram recuperados neste ciclo. Não houve execução de código nem validação de hashes.
- **[?]** O E71 usa `f_c=1−ΔS₂(cond)/ΔS₂(completa)` como índice; não mede `S₁`, `D(ρ||σ)` ou fração de bit. G-GAUGE-6 permanece **PENDING**. Um par físico com cargas dinâmicas em U(1), dressing e setores soft ainda não foi construído.
- **[?]** Sugiura–Takeda [0064] e Bousso–Kaya [0066–0067] **não receberam auditoria integral de provas** neste ciclo. Em particular, não identificar cone de áreas geométricas com entropia de matéria arbitrária ou inferir independência estatística não demonstrada.
- **[?]** Val Baker [0031] tem auditoria algébrica histórica de 09/10, **não reexecutada**. Nenhuma nova derivação QED₄ → gravidade dinâmica → massa eletrônica 511 keV foi encontrada nas fontes examinadas **neste ciclo**; a busca negativa não é exaustiva.
- **[?]** Escopo Hadamard [0070] e reconstrução via propagador [0069] seguem sem auditoria nova; não extrapolar automaticamente de campos livres escalares a QED espinorial interagente.

## 7. Histórico e próximo bloco

**CP-14** incorpora integralmente CP-01–CP-13 (arquivo v1.1 original preservado, sem remover trechos) e acrescenta [0094–0096], G-RELENT-1, G-EINSTEIN-2 e G-METRIC-3. O índice v1.4 é **apenas ID → título**, 96 linhas. **Sem novas simulações.**

**Próximo bloco:** (i) localizar ZIP/JSON/código E71 e conferir definições sem execução; (ii) construir matriz analítica U(1) com estados carregados e centro de fluxo (sem promover a simulação); (iii) ler demonstrações completas Sugiura–Takeda e Bousso–Kaya; (iv) verificar não unicidade Γ/E em Tjoa–Gray; (v) auditar setores de matéria, JLMS e o significado de massa infrapartícula sem inserir `m_e` como input oculto.

**URLs primárias:** https://arxiv.org/html/1512.06431 ; https://arxiv.org/html/1508.00897 ; https://arxiv.org/html/1305.3182 ; https://arxiv.org/html/1102.0440 ; https://arxiv.org/html/2112.11437 ; https://link.springer.com/article/10.1007/JHEP03(2014)051 .

---

# INTEGRAÇÃO CUMULATIVA — CP-15

# HRF — Checkpoint bibliográfico CP-15

**Data:** 16/10/2026 13:02 BRT  
**Programa:** HRF — Reconstrução Unificadora Progressiva (B → A)  
**Escopo:** G (geometria), D (dicionário boundary–bulk), interfaces gauge; nenhuma bancada ou simulação executada.

## Leitura documental e status

- **Primeiro:** Capítulo 0.1 v0.2 integral, arquivo Drive `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`; preservadas classes [F]/[M]/[H]/[?]/[D], separação G/W/D e gates B0–B5.
- **Projeto/conversa:** arquivos cumulativos CP-01–CP-14 e índice de 96 títulos consultados; a versão local CP-14 foi confrontada com a cópia original no Drive (ID `1REnMlFrDXfY3rXIZxDkDQa7nRWjt3P8z`).
- **Drive:** recuperados CP-14 e índice v1.4; `LEIAME_E71_resultados.md` (ID `1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf`) documenta ZIP congelado `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, mas busca por nome de ZIP e `E71_resumo.json` **não recuperou bytes brutos**. A existência declarada do ZIP não equivale a acesso ao ZIP. Não foi executado nenhum código.

## Resultados e provas examinadas

### 1. Bousso–Kaya [0067]: desigualdade de **áreas**, não de entropia de matéria arbitrária

Leitura da demonstração do Teorema 12, eqs. (2.8)–(2.21), páginas 5–9 de `arXiv:2502.03516`. Para regiões de entrada `a_i` em uma fatia de Cauchy estática, requer-se **independência mútua**:

`a_i ⊂ [E(⋓_(j≠i) a_j)]'`.

Dado mapa de contração `f:{0,1}^L→{0,1}^R` com distâncias de Hamming ponderadas `d_α(x,y)≥d_β(f(x),f(y))`, a partição em tiles leva a

`Σ_l α_l Area[E(v_l)] ≥ Σ_r β_r Area[E(w_r)]`.

**Verificação independente parcial:** transcrita a tabela de MMI (3 bits → 4 bits, p. 7), verificados por enumeração finita **28 pares**: 0 violações da contração; 18 igualdades e 10 desigualdades estritas. Isso confere a **tabela de contração**, não rederiva toda a teoria de wedges ou a existência de superfícies minimizantes. A etapa geométrica final depende da admissibilidade de regiões candidatas `c_r`, que exige independência, e de `Area[E(w_r)]≤Area[c_r]`. **Não** extrapolar a `S_matter` ou à entropia quântica total em qualquer estado.

Fonte: https://arxiv.org/pdf/2502.03516 ; DOI: 10.1103/PhysRevD.111.086014. **Leitura:** texto e prova selecionada; auditoria independente **parcial**, não prova completa.

### 2. Sugiura–Takeda [0064]: cortes fornecidos e fator conforme condicionado

Leitura de §§2.1, 3.1–3.2 e Apêndice A de `arXiv:2212.10065`. A condição de tangência de *lightcone cuts* (2.2) fornece vetores nulos; a equação homogênea `g_μν δλ^μδλ^ν=0` (2.3) fixa somente a classe conforme. O algoritmo da §3.1 **começa com cortes dados** e assume, para as bolas tratadas, `C_A=E_A` (CIS = superfície mínima); então a condição de extremalidade restringe `g=e^(2ω) g̃`, e o termo universal da entropia via RT fixa a constante global. Reconstrói patches de AdS puro global/Poincaré/Rindler; não algoritmo geral independente de geometria. Os próprios autores registram a dificuldade de obter os cortes via correladores e de estender a construção para métricas genéricas.

Fonte: https://arxiv.org/pdf/2212.10065 ; DOI: 10.1007/JHEP06(2023)035. **Leitura:** seções e equações específicas, não reprodução integral do Apêndice A.

### 3. Tjoa–Gray [0055]: `Γ` e propagador `E` são dados condicionantes

Leitura §§II, III.E e IV de `arXiv:2204.13133`. A projeção `Γ:Sol_R(M)→Sol_R(ℐ⁺)` e a correspondência de álgebras de Weyl exigem hipóteses sobre a teoria escalar livre, estado Hadamard e espaço-tempo. `E=E⁻−E⁺` é o propagador causal do operador Klein–Gordon no bulk. A reconstrução é válida no domínio anunciado, mas um algoritmo HRF que alegue geometria independente deve contabilizar como obtém `Γ`, `E`, smearing e a estrutura causal **sem usar a métrica alvo como entrada oculta**. Não é prova de circularidade no artigo. Alcance limitado pela suficiência de dados em ℐ⁺/horizonte, não interior genérico.

Fonte: https://arxiv.org/pdf/2204.13133 ; DOI: 10.1103/PhysRevD.106.025021. **Leitura:** seções e equações específicas; auditoria independente do mapa Γ pendente.

### 4. Novas referências normalizadas [0097–0098]

**[0097] Jokela et al. (2023), JHEP12(2023)137** — dados de teoria SU(2) *pure glue* em 2+1 dimensões (Euclidiana 3D), na fase desconfinada, ajustados a um ansatz de métrica dual. **Ponto crítico:** §2, eqs. (2.9)–(2.13), o cálculo usa replica `s=2`, de modo que a aproximação `S_EE≈H₂` substitui a derivada `s→1` por diferença finita. Trata-se de uma aproximação **declarada pelos autores**, não identidade universal de `S₁` e `S₂`. Logo, o precedente **não** valida o `f_c` da E71 como fração física de emaranhamento. Também não envolve QED₄ espinorial nem massa eletrônica. Fonte: https://arxiv.org/pdf/2304.08949 ; DOI 10.1007/JHEP12(2023)137. **Leitura:** §§1–2, 3.2, 4; cálculos numéricos não reproduzidos.

**[0098] Jokela–Liimatainen–Sarkkinen–Tzou (2025), JHEP10(2025)079** — reconstrução inversa de perturbação de métrica de *slice espacial* assintoticamente AdS, ansatz `g=z^(-2)[f(z,x) dz²+δ_ij dx^i dx^j]` perto de `f=1`. Para dimensão espacial `n=3`, eq. (1.4):

`δf(z) = (12 G_N/π)[−δS_EE(z)+z δS'_EE(z)+z² δS''_EE(z)]`.

**Checagem algébrica mínima (não simulação):** se `δS_EE(z)=A z³`, a combinação é `8 A z³`, logo `δf=(96 G_N A/π) z³`. O caso `A=π/(96 G_N z_H³)` recupera formalmente `δf=(z/z_H)³`; isto verifica a aplicação da fórmula a um monômio, **não** o cálculo holográfico que produz esse `A`. O artigo reconhece questões abertas de unicidade para áreas mínimas e limita a fórmula à classe de métricas, perturbação e dados diferenciáveis assumidos. Fonte: https://arxiv.org/pdf/2504.07016 ; DOI 10.1007/JHEP10(2025)079. **Leitura:** §§1–2 e equações; demonstração completa da inversão não rederivada.

## Gates, lacunas e próximo ciclo

- **G-CONE-1 [D]**: antes de aplicar HEC além de AdS, verificar geometria estática, existência de wedges minimizantes, independência `a_i`, contração admissível, diferença `Area`/`S_matter`/`S_gen` e limite clássico. Verificação da tabela MMI **PASS parcial**; interface HRF **PENDING**.
- **G-METRIC-4 [D]**: declarar entradas geométricas/cortes/`Γ`/`E`/ansatz AdS, cobertura, classe de perturbação, regularização e hipóteses de unicidade. Se métrica de referência é entrada, chamar reconstrução **perturbativa condicionada**, não emergência sem geometria.
- **G-RENYI-3 [D]**: comparar `S₁`, `S₂`, réplica `s→1`, centro e `f_c` explicitamente. Aproximação `S_EE≈H₂` em [0097] é controlável apenas com erro estimado, não licença geral.
- **[?]** ZIP/dados brutos E71 ainda não recuperados; não executar código sem autorização. U(1) com matéria carregada dinâmica, soft dressing, JLMS e QES físico permanecem abertos.
- **[?]** QED₄ → geometria gravitacional dinâmica → massa `m_e≈511 keV` permanece sem derivação nas fontes lidas; busca negativa **não exaustiva**. Val Baker [0031] apenas auditoria histórica, sem réplica nova.
- **Próximo ciclo:** tentar localizar o ZIP E71; ler os apêndices completos de [0064]/[0098] e testar unicidade/dados suficientes; comparar área cone e correções quânticas; retomar `Γ` e carga dinâmica em U(1), sem simulações não autorizadas.

**Status:** CP-15 documenta leitura de provas **parcial**, checagens algébricas finitas independentes e 2 novas referências; nenhum resultado físico HRF novo reivindicado.


---

# INTEGRAÇÃO CUMULATIVA — CP-16

# HRF — Checkpoint bibliográfico CP-16

**Data:** 17/10/2026, 01h08 BRT  
**Programa:** Holographic Reconstruction Framework (HRF), Reconstrução Unificadora Progressiva (B → A)  
**Frentes:** G (reconstrução geométrica), D (dicionário), QES/JLMS, entropia gauge, massa QED₄; W não testado.  
**Estado:** revisão bibliográfica e cálculo algébrico; **nenhuma simulação ou bancada executada**.

## 1. Proveniência e ordem obrigatória

1. **Leitura integral inicial:** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I` (27.751 caracteres de texto retornados). Mantidas as classes [F]/[M]/[H]/[?]/[D], RUP B→A, distinção G/W/D e não promoção de resultados operacionais a partículas.
2. **Projeto/conversa:** arquivo cumulativo CP-15 v1.3 (124.497 bytes) e índice v1.5 (7.218 bytes), disponíveis na conversa; verificados 98 IDs estáveis. Busca nos arquivos de conversa/Library por materiais HRF/E71 retornou arquivos históricos; não foi encontrado um anexo mais recente do Projeto que substituísse Cap. 0.1.
3. **Google Drive:** metadados da v1.3 e do índice v1.5 conferidos com tamanho local e `parent_ids=[1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9]`. Capítulo 0.1 v0.2 segue a versão mais recente encontrada por busca nominal. `LEIAME_E71_resultados.md` (Drive `1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf`) relido; documenta pacote ZIP E71 e nomes dos JSON. Busca Drive por ZIP, `E71_resumo.json`, e MIME `application/zip` não recuperou os arquivos brutos. **Ausência na busca não prova inexistência.**
4. **Literatura externa primária:** Bousso–Kaya (2024) [0066], Akers et al. (2020) [0099], Bousso et al. (2016) [0100], e resultados anteriores [0067], [0034–0035], [0098]. Freivogel et al. [0101] e Hong [0102] lidos **somente em resumos originais**.

## 2. Resultado principal: cone de áreas ≠ cone da entropia total com matéria

### 2.1 Bousso–Kaya 2024 [0066]: demonstração covariante condicionada

**[F, domínio especificado]** Leitura do texto integral `arXiv:2404.11644`, Defs. 15–18, Convenção 26, Lemas 23–28, Teorema 29 e eqs. (3.7)–(3.18). A prova de MMI para áreas de wedges generalizados admite espaço-tempo dinâmico, mas **não** é irrestrita: exige condição de *weak classical focusing* (WCF), wedges definidos com `e_max=e_min` para regiões relevantes e suas uniões, e independência `x ⊂ e(yz)'`, `y ⊂ e(zx)'`, `z ⊂ e(xy)'`. O artigo utiliza resultados geométricos de Bousso–Penington [0068] e argumento de áreas de fronteiras. A desigualdade é

`Area[e(xy)]+Area[e(yz)]+Area[e(zx)] >= Area[e(x)]+Area[e(y)]+Area[e(z)]+Area[e(xyz)]`.

A demonstração geral da **MMI geométrica** de 2024 não deve ser confundida com a extensão de **todas as desigualdades conhecidas** do cone em fatias **estáticas** de 2025 [0067]. Tampouco transforma `S_matter` arbitrária em área. **Nível de leitura:** texto e cadeia de lemas selecionados, **não** auditoria independente de cada lema/teorema importado.

### 2.2 Akers–Engelhardt–Penington–Usatyuk [0099]: correção quântica e contraexemplo

**[F, sob hipóteses]** `Quantum Maximin Surfaces`, JHEP08(2020)140, arXiv:1912.02799, §§2.1–2.2, 4.2–4.3, eqs. (4.20)–(4.25). O funcional relevante é, esquematicamente, em unidades naturais:

`S_gen(X)=Area(X)/(4 G_N) + S_bulk^vN(W_X) + S_grav,subleading(X)`.

A prova de subaditividade forte (SSA) para QES via quantum maximin usa **SSA do estado de matéria bulk**, regularização/renormalização, hipóteses semiclassicas, condições de contorno e **quantum focusing conjecture (QFC)**, não um teorema universal da QED₄. O artigo afirma explicitamente que a **MMI pode falhar** com correções quânticas quando a desigualdade de área está saturada, dando um exemplo GHZ com quatro qubits (§4.3). A prova da QFC não é reivindicada no artigo.

**Verificação algébrica independente e exata, sem simulação:** seja o estado puro de quatro qubits

`|GHZ_4>=(|0000>+|1111>)/sqrt(2)`.

Traçando o quarto qubit D, `rho_ABC=(|000><000|+|111><111|)/2`. Toda redução não vazia de A, B, C tem dois autovalores não nulos `(1/2,1/2)` e portanto `S(A)=S(B)=S(C)=S(AB)=S(AC)=S(BC)=S(ABC)=ln 2`. Assim:

`I_3(A:B:C)=S(A)+S(B)+S(C)-S(AB)-S(AC)-S(BC)+S(ABC)=ln 2=0,69314718056 > 0`.

Como MMI requer `I_3<=0`, ela é violada **pela entropia de matéria**; entretanto `S(AB)+S(BC)-S(B)-S(ABC)=0`, logo SSA continua satisfeita. Se a contribuição geométrica a MMI satura em ordem líder e esse setor bulk é permitido, o termo de matéria pode determinar o sinal sublíder. **Não** se construiu aqui um estado de elétron físico nem uma solução gravitacional concreta; trata-se de verificação da identidade entrópica do contraexemplo descrito em [0099].

### 2.3 QFC [0100]: hipótese adicional, não derivação da gravidade

**[F quanto à formulação; H quanto à validade geral da conjectura]** Bousso–Fisher–Leichenauer–Wall, *Quantum focusing conjecture*, Phys. Rev. D 93, 064044 (2016), arXiv:1506.02669: propõe não crescimento da expansão quântica ao longo de congruências nulas, definida por variações de `S_gen`. A QFC **é formulada como conjectura**; não a tratar como prova universal nem confundi-la com a QNEC. **Leitura:** resumo da fonte primária e referências cruzadas nas §§2–4 de [0099]; demonstração completa não auditada.

## 3. Reconstrução métrica e frente QED₄: novos controles negativos

- **[0101] Freivogel et al. (2015), *Casting shadows on holographic reconstruction*.** O resumo original mostra regiões do bulk que não são atravessadas pelas superfícies mínimas usadas como sondas; isso limita cobertura de reconstrução, mesmo em AdS. **Leitura:** resumo; nenhum mapa de sombra ou cálculo refeito. `G-METRIC-5`: antes de alegar unicidade global, demonstrar cobertura por superfícies e estabilidade da inversão; [0098] permanece condicionado a ansatz, linearização e dados suficientes.
- **[0102] Hong (2015), *Holographic estimate of electromagnetic mass*.** **Falso positivo relevante da busca QED₄/elétron:** o trabalho calcula **diferenças de massas de hádrons** (próton–nêutron, píons) no modelo holográfico de QCD de Sakai–Sugimoto; **não** deriva `m_e=511 keV`. **Leitura:** resumo primário apenas; uso bibliográfico como exclusão de escopo, não validação de método HRF.
- **Tjoa–Gray [0055]**: `Γ` e propagador causal `E` continuam como entradas cujo grau de independência deve ser auditado; nenhuma prova integral adicional neste ciclo. **Sugiura–Takeda [0064]**: cortes causais dados e identificação CIS=superfície mínima permanecem hipóteses de reconstrução; sem auditoria integral adicional.
- **E71**: LEIAME confirma ZIP congelado e nomes dos JSON, mas não foi possível acessar bytes brutos; `f_c` baseado em Rényi-2 segue **índice operacional**, não fração física de emaranhamento. Nenhuma execução/avaliação de código autorizada ou realizada.
- **Val Baker [0031]**: auditoria algébrica histórica registrada em 09/10, **não** reproduzida nesta rodada. Busca dirigida por “holographic electromagnetic mass” localizou [0102], mas não uma derivação da massa do elétron QED₄; **busca negativa não exaustiva**.

## 4. Gates, uso bibliográfico e histórico

- **G-QES-2 [D]:** separar `S_area`, `S_bulk^vN`, `S_gen`, `S_2`, `S_refined`, SSA e MMI; não aplicar cone geométrico à entropia total sem demonstrar controle da correção de matéria. Exemplo GHZ: `I3=+ln2`, `SSA gap=0`. Gate de cone de áreas para E71: **PENDING**.
- **G-CONE-2 [D]:** em [0066] verificar WCF, `e_max=e_min`, independência mútua e condições de contorno; em [0067] verificar fatia estática e mapa de contração; **não** usar “além de AdS” como sinônimo de “sem geometria prévia”.
- **G-METRIC-5 [D]:** mapear regiões não cobertas por superfícies (sombras), classe de métricas, dados de entrada e regularidade da inversão; `Γ/E` e reconstrução Hadamard continuam **PENDING**.
- **Novos IDs imutáveis:** HRF-REF-0099 a HRF-REF-0102. [0099] texto original e prova selecionada, [0100] resumo e uso como hipótese, [0101–0102] apenas resumos. Não há prova completa independentemente rederivada; apenas a álgebra do GHZ foi conferida.
- **Histórico:** CP-16 acrescenta estes resultados sem alterar CP-01–CP-15. A nova v1.4 inclui **literalmente** o caderno v1.3 anterior e, em seguida, este CP-16. Índice v1.6 preserva as 98 linhas anteriores e acrescenta quatro.

## 5. Próxima prioridade

Auditar a derivação geométrica de [0066] (Lemas 23–28, dependências Bousso–Penington) e compará-la com [0067]; verificar se `S_gen` ou desigualdades condicionais de informação fornecem teste robusto para matéria carregada; obter E71 ZIP/JSON sem rodar; investigar limites de unicidade/sombras [0101] e `Γ/E` [0055]; aprofundar QED₄ e massa sem confundir hádrons com elétron.

**Fontes primárias:**
- [0066] https://arxiv.org/pdf/2404.11644 ; DOI 10.1103/PhysRevD.110.066017.
- [0067] https://arxiv.org/pdf/2502.03516 ; DOI 10.1103/PhysRevD.111.086014.
- [0099] https://arxiv.org/pdf/1912.02799 ; DOI 10.1007/JHEP08(2020)140.
- [0100] https://arxiv.org/abs/1506.02669 ; DOI 10.1103/PhysRevD.93.064044.
- [0101] https://doi.org/10.1103/PhysRevD.91.086013.
- [0102] https://arxiv.org/abs/1409.8139 ; DOI 10.1007/JHEP08(2015)066.


---

# INTEGRAÇÃO CUMULATIVA — CP-17

# HRF — Checkpoint bibliográfico CP-17

**Data:** 17/10/2026, 13h10 BRT  
**Frentes:** HRT/RT e cone entrópico covariante; wedges generalizados, Crofton e SSA; QES/matéria; proveniência E71.  
**Execução:** apenas leitura e conferência algébrica; **nenhuma simulação HRF executada**.

## 1. Proveniência e sequência de leitura

1. **Leitura obrigatória integral:** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`; 27.751 caracteres textuais retornados. Não foi encontrada versão nominal posterior na busca ao Drive. Mantidos RUP **B→A**, mapas **G/W/D** independentes, classificação **[F]/[M]/[H]/[?]/[D]**, e veto à promoção de analogia geométrica a dualidade física.
2. **Arquivos do Projeto/conversa:** busca semântica em arquivos do Projeto e Library, incluindo `HRF_Pacote_Continuidade_Chat_Boundary2D_Bulk3D_GMF_Ondas_v0_1_PT_2026-10-09.md` e `HRF_Nota_Arquitetura_Boundary_2D_GMF_Bulk_3D_e_Propagacao_Fotonica_v0_1_PT_2026-10-09.docx`. Mantida distinção entre triangulação Delaunay da boundary, área RT do bulk e a necessidade de dicionário físico D. O arquivo especializado de orientação não foi relido integralmente neste ciclo; as regras pertinentes constam do Cap. 0.1.
3. **Drive HRF:** conferidos caderno v1.4 (`1f2rIT_1gE2je7EPfIEalFWUpzpJeqwu5`), índice v1.6 (`1506c9bNqeVlgoJeZXuneoLKbv5vYxaq4`) e pasta `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`; 102 IDs preexistentes. Busca por `E71`, `ELETRON_71`, `perfis.json` e ZIP no diretório Physics localizou protocolo, relatório e LEIAME, mas não os arquivos brutos. Uma busca por MIME ZIP diretamente na pasta não retornou itens. **Não é prova de inexistência.**
4. **Fontes externas primárias:** [0103] Zhao 2026, [0104] Sahu 2026 e [0105] Grado-White et al. 2025; confronto com [0066–0068], [0099] e [0036]. Nenhuma demonstração completa foi reproduzida independentemente.

## 2. Achado central — a equivalência dos cones RT/HRT em 2026 é **condicionada**

**HRF-REF-0103 [F sob hipóteses; texto integral em seções selecionadas]:** Bowen Zhao, preprint arXiv:2602.04888, título do manuscrito **Graph models for covariant holographic entropy I** (página arXiv intitulada *Covariant Holographic Entropy Cone*). O resumo da página anuncia equivalência do cone covariante com o estático, mas o Teorema 1.1 e a conclusão delimitam a demonstração ao regime em que os pares relevantes de superfícies HRT têm **regiões de interação expostas não vazias**, possivelmente após redução por *timelike clusters*. Hipóteses adicionais da Assumption 1: condição de curvatura nula, construção maximin e estrutura AdS-hiperbólica. Configurações em que uma região de interação é coberta pela união de outras permanecem explicitamente para trabalho futuro (§4.3.2 e conclusão). A extensão a QES também fica aberta.

O Teorema 3.2 identifica, sob a hipótese de pesos iguais às áreas dos componentes HRT, uma equivalência **dentro de um modelo de grafo** entre compatibilidade global dos cortes e desigualdades poligonais locais:

`w(Γ) ≤ Σ_{Γ'⊂∂R, Γ'≠Γ} w(Γ')`.

Se o modelo geométrico satisfaz essas condições, o peso de qualquer corte homólogo é ao menos a área da HRT correspondente: `Area(γ_HRT) ≤ w(C)`. Isto **não** demonstra que todo estado HRT genérico admita o modelo, nem que o cone de `S_gen` quântico coincida com o cone clássico. **G-COVCONE-1 [D]:** registrar a condição de *exposed regions*, maximin, curvatura nula, homologia e natureza clássica antes de importar desigualdades ao HRF.

**Controle editorial matemático independente:** a equação (4.1) do PDF v1 apresenta `d(x₁,xₙ) ≥ Σ d(xᵢ,xᵢ₊₁)` sob o nome de desigualdade triangular. Para uma métrica, a desigualdade correta é `d(x₁,xₙ) ≤ Σ d(xᵢ,xᵢ₊₁)`. Por exemplo, na reta `x₁=0,x₂=1,x₃=2`, obtém-se `2≤1+1`; o sinal `≥` escrito no PDF não é a forma geral da desigualdade. A desigualdade poligonal (3.2), que é efetivamente usada no argumento, **tem o sentido correto `≤`**. Registro como provável erro tipográfico localizado, **não** como refutação da prova, cuja auditoria integral permanece PENDING.

**Comparação HRF-REF-0105 [resumo original, não prova integral]:** Grado-White, Grimaldi, Headrick e Hubeny (2025), *Minimax surfaces and the holographic entropy cone*, JHEP 05 (2025) 104, arXiv:2502.09894. A construção de grafos HRT requer a propriedade de *cooperating time-sheets*, demonstrada apenas em exemplos e parcialmente em geral; os autores registram situações problemáticas. **Não** converter esse trabalho nem [0103] em prova incondicional da igualdade RT/HRT.

## 3. Wedges generalizados: SSA da CFT → medida Crofton positiva, não MMI de matéria

**HRF-REF-0104 [F sob hipóteses; seções II–V e equações selecionadas]:** Abhisek Sahu, *Generalised entanglement wedges in three dimensions*, arXiv:2610.07176 (outubro de 2026). Em **AdS₃ vácuo**, fatia **estática** e ordem geométrica líder `1/G`, as GWs são caracterizadas por uniões de componentes geodesicamente convexos com condição de perímetro. Na *kinematic space* de intervalos da CFT₂, a forma de Crofton é positiva pela subaditividade forte da entropia de von Neumann:

`S(p,q) = (c/3) ln[(2/ε) sin((q−p)/2)]`, `c=3/(2G)`;

`h(p,q) = ∂p∂q S(p,q) = (c/12)csc²[(q−p)/2] ≥ 0`;

`I(A:C|B)=S(AB)+S(BC)−S(B)−S(ABC)=h(p,q)dpdq ≥ 0` para três intervalos adjacentes infinitesimais.

A diferença de entropias de wedges convexos é uma medida de conjuntos, e a folga de SSA pode ser expressa como `S_gen(K₁)+S_gen(K₂)−S_gen(K₁∨K₂)−S_gen(K₁∧K₂)=ν(D₁∩D₂)≥0`. **Leitura:** seções e identidades originais; não foi refeito o teorema completo para wedges desconectados nem verificado um dual fora de AdS.

**Checagem analítica independente (sem simulação):** escrevendo `u=(q−p)/2`, temos `∂p ln(sin u)=−(1/2)cot u` e `∂q[−(c/6)cot u]=(c/12)csc²u`, confirmando a fórmula de `h`. A checagem é de derivada, **não** da fórmula Crofton/RT completa.

**Controle adversarial com [0099] (GHZ já calculado no CP-16):** para `ρ_ABC=(|000⟩⟨000|+|111⟩⟨111|)/2`, todas as entropias de subconjuntos não vazios são `ln 2`. Então `I(A:C|B)=ln2+ln2−ln2−ln2=0` (SSA saturada), enquanto `I₃(A:B:C)=ln2>0` (MMI violada). Logo **positividade de informação mútua condicional/SSA não implica MMI para matéria quântica arbitrária**. O resultado de Sahu depende adicionalmente da geometria estática de AdS₃, RT, Crofton e ordem líder. **G-CROFTON-1 [D]:** não usar `S₂` da E71 como `S₁` dos intervalos nem confundir positividade local da medida com o cone completo de áreas.

## 4. Relação com os resultados anteriores e lacunas

- **Bousso–Kaya [0066]:** MMI geométrica covariante para wedges gravitantes sob WCF, `e_max=e_min`, independência mútua e regime de matéria desprezível. **Bousso–Kaya [0067]:** cone geométrico estático sob independência. **Zhao [0103]:** problema distinto — cone HRT **em holografia AdS**, com *exposed-region condition*. Não fundir esses três teoremas.
- **Bousso–Penington [0068]:** wedges gravitantes são construção geométrica/entrópica com hipóteses; não fornece por si só uma álgebra concreta de elétrons QED₄ nem um dicionário D para o HRF.
- **QES [0099]:** `S_gen=Area/(4G)+S_bulk^vN+...`; SSA sob hipóteses semiclassicas não assegura MMI após correções de matéria. O novo resultado [0104] é de ordem geométrica líder, não soluciona esse obstáculo.
- **Métrica [0052,0055,0064,0098,0101]:** Γ, propagador E, dados causais, *ansatz* de métrica, sombras, cobertura e unicidade continuam PENDING. Nenhuma nova prova de independência foi realizada neste ciclo.
- **E71:** protocolo/relatório/LEIAME localizados, ZIP e `E71_resumo.json`/`perfis.json` não recuperados. Índice `f_c` da E71 segue baseado em Rényi-2 e é apenas operacional; não prova RT/QES nem carga quântica dinâmica. **Nenhuma simulação ou execução de código científico.**
- **QED₄ → geometria gravitacional dinâmica → `m_e c²≈511 keV`:** nenhuma derivação nas fontes examinadas; busca negativa **não exaustiva**. Val Baker [0031] não foi reexecutado. Estados espinoriais vestidos [0083,0087] já inserem parâmetro de massa; lacuna permanece.

## 5. Status bibliográfico, histórico e próximo bloco

**Novos IDs imutáveis:** [0103] Zhao (2026), [0104] Sahu (2026), [0105] Grado-White et al. (2025). [0103] texto integral selecionado (Teoremas 1.1, 3.2, §§4.3–4.4, conclusão e eq. 4.1); [0104] §§II–V, equações de Crofton/SSA, derivada conferida; [0105] resumo original, sem prova integral. Nenhum dos três foi auditado integralmente de forma independente. Nenhum identificador anterior alterado.

**Gates novos:** `G-COVCONE-1` (condições geométricas da extensão HRT), `G-CROFTON-1` (SSA/medida e domínio AdS₃) e `G-TRIANGLE-1` (verificação do sinal da eq. 4.1, editorial, sem promover a FAIL da prova). `G-QES-2`, `G-CONE-2`, `G-METRIC-5`, `G-GAUGE-6` permanecem ativos.

**Próximo bloco:** comparar formalmente os pressupostos de [0103] e [0105] com os de [0066–67], testar a consistência da construção de pesos com exemplos mínimos de cortes sem simular, aprofundar a demonstração desconexa de [0104] e a interface Crofton–QES, buscar os brutos E71, auditar `Γ/E` e Hadamard, manter frente QED₄/massa e Val Baker. Preservar classes [F]/[M]/[H]/[?]/[D] e RUP B→A.

### Fontes primárias e acesso

- [0103] https://arxiv.org/abs/2602.04888 ; https://arxiv.org/pdf/2602.04888 (preprint, leitura selecionada).
- [0104] https://arxiv.org/abs/2610.07176 (preprint de outubro de 2026, leitura selecionada).
- [0105] https://arxiv.org/abs/2502.09894 ; DOI: 10.1007/JHEP05(2025)104 (resumo original).
- [0066] https://arxiv.org/abs/2404.11644 ; [0067] https://arxiv.org/abs/2502.03516 ; [0068] https://arxiv.org/abs/2208.04993 ; [0099] https://arxiv.org/abs/1912.02799.


---

# INTEGRAÇÃO CUMULATIVA — CP-18

# HRF — Checkpoint bibliográfico CP-18

**Data:** 18/10/2026, 01h08 BRT  
**Base documental:** CP-17; caderno cumulativo v1.5 (145.310 bytes); índice v1.7 (105 referências).  
**Escopo:** QES e cone entrópico, wedges generalizados e connected-wedge além de AdS, hipóteses covariantes, setores U(1) e auditoria bibliográfica.  
**Execução:** leitura e verificações algébricas; **nenhuma simulação ou execução de código de bancada HRF**.

## 1. Ordem das fontes e proveniência

1. **Capítulo 0.1 lido integralmente:** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md` (Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`; 27.751 caracteres retornados). Diretriz [D] RUP **B→A**, separação **G/W/D**, classes **[F]/[M]/[H]/[?]/[D]**; não converter Delaunay, fluxo, S₂ ou correspondência de forma em dualidade holográfica física.
2. **Arquivos do Projeto/conversa:** busca semântica pelo caderno e relatórios E71, incluindo registros de síntese B2B/ABJM/STAR e cadernos históricos. O material do Projeto foi priorizado antes do Drive; nenhum resultado de bancada foi reinterpretado como prova.
3. **Google Drive HRF:** recuperados originais CP-17, caderno v1.5 e índice v1.7 da pasta `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`, com tamanhos 10.136, 145.310 e 7.625 bytes respectivamente. Pesquisa por `E71_resumo`, `perfis.json`, `ELETRON_71` e `E71.zip` devolveu apenas relatório, protocolo, LEIAME e cadernos que mencionam os nomes; busca por MIME ZIP/JSON na pasta não retornou os brutos. **Não prova inexistência.**
4. **Fontes primárias externas:** artigos [0106] Akers–Hernández-Cuenca–Rath (2021), [0107] Arayath–Pasterski (2026), [0108] May–Sorce–Yoshida (2022), com reexame de [0105] Grado-White et al. (2025) e [0103] Zhao (2026). Distinção explícita entre resumo, trechos completos e prova reproduzida.

## 2. Achado central: QES pode preservar MMI sob condições sobre o *bulk*, mas não por SSA isolada

**HRF-REF-0106 — *Quantum Extremal Surfaces and the Holographic Entropy Cone*.** Fonte primária: https://arxiv.org/pdf/2108.07280 (v2, 08/09/2021), DOI não confirmado neste ciclo. **Leitura:** introdução, §3.2 (equações 3.16–3.18, Teorema 2), §4 (Proposições 1–2) e Apêndice A apenas por remissão; **prova integral NÃO rederivada**.

- [F, condicionado] Para superfícies QES em contexto holográfico apropriado, `S_QES(R) = min_ext [Area(γ_R)/(4G_N) + S_bulk^vN(Σ_R)]` (esquema renormalizado). O artigo demonstra **`bulk HEC ⇒ boundary HEC`** (Teorema 2) quando as entropias *bulk* satisfazem todas as desigualdades HEC relevantes para sub-regiões; a prova usa mapas de contração e homologia. É uma **condição suficiente, não necessária**.
- [F, condicionado] Demonstra também **`bulk MMI ⇒ boundary MMI`** (Proposição 2) sob a estrutura QES e condições entrópicas pertinentes. A mera SSA universal de matéria **não** é suficiente. Não se pode impor ao elétron QED₄ uma hipótese HEC/ MMΙ de *bulk* sem justificá-la independentemente.
- [F, sob hipóteses] A identidade RT clássica `S≈Area/(4G_N)` não equivale a `S_gen` e nem à entropia de Rényi-2 da E71. É indispensável demonstrar o mapa físico D e o setor quântico em que as hipóteses de QES se aplicam.

**Auditoria algébrica e possível inconsistência editorial da fonte [0106]:** a equação (1.2) afirma MMI como `S(AB)+S(AC)+S(BC) ≥ S(A)+S(B)+S(C)+S(ABC)`. Para `|GHZ₄⟩=(|0000⟩+|1111⟩)/√2`, traçando D, todos os sete subconjuntos não vazios de ABC têm entropia `s=ln 2`. Logo `LHS=3s`, `RHS=4s`, e a **violação tem módulo `s`**, com informação tripartida convencional `I₃=S(A)+S(B)+S(C)-S(AB)-S(AC)-S(BC)+S(ABC)=+s`. Entretanto, a versão PDF v2 §4, eq. (4.1c), define `I₃` com sinal inverso (`−s` neste exemplo), eq. (4.2c) escreve `−I₃≥0`, e a prova da Proposição 1 escreve `I₃=2S₀≥0` para os mesmos subconjuntos. Essas três expressões **não são simultaneamente consistentes** com o cálculo direto quando `S₀=s`. **G-QES-3 [D]: provável problema editorial de sinal/fator a esclarecer por errata ou versão posterior; não refuta a conclusão qualitativa de que GHZ viola MMI, nem demonstra erro nas demais provas.** Esta constatação foi conferida também na imagem da página 17 do PDF, não apenas na extração textual.

## 3. Controle analítico U(1) com matéria carregada: lei de Gauss ≠ entropia ≠ dualidade

**G-U1-1 [M: modelo algébrico mínimo, não QED₄ dinâmica].** Considerar dois sítios L,R conectados por um elo U(1) orientado L→R, fluxo elétrico inteiro `E`, cargas `Q_L,Q_R` e geradores de Gauss `G_L=E−Q_L`, `G_R=−E−Q_R`. Dois vetores físicos de base satisfazem Gauss exatamente: `|1,+1,−1⟩` e `|0,0,0⟩` (ordem E,Q_L,Q_R). O estado `|ψ⟩=√(3/4)|1,+1,−1⟩+√(1/4)|0,0,0⟩` obedece `G_L|ψ⟩=G_R|ψ⟩=0` e `Q_L+Q_R=0` em ambos os setores.

Para a álgebra regional esquerda cujo centro mede o fluxo de fronteira, a distribuição setorial é `p=(3/4,1/4)`. Como os blocos internos são puros neste exemplo, a contribuição de centro é:

`S₁=H(p)=−Σ p_i ln p_i = 0.562335144619`;  
`S₂=−ln Σ p_i² = 0.470003629246`;  
`D(p||q)=Σ p_i ln(p_i/q_i) = 0.130812035941`, para `q=(1/2,1/2)`.

Essas quantidades são diferentes apesar de todas satisfazerem a lei de Gauss. No estado de setor único `E=1`, a carga física local continua não nula mas a **entropia setorial é zero**. Portanto, fluxo/carga não equivale a emaranhamento, e nenhum dos números é área RT/QES ou massa eletrônica. A fatorização física e a álgebra de borda precisam ser explicitadas para qualquer extrapolação. **Verificação:** substituição direta e identidades logarítmicas, sem solver, sem QED₄ contínua, sem campo de Dirac, sem *soft dressing* assintótico. Gates G-GAUGE-4/5/6 permanecem PENDING para o elétron real.

## 4. Além de AdS e cones HRT: separar teoremas distintos

**HRF-REF-0107 — *Generalized Entanglement Wedges and the Connected Wedge Theorem*.** Arayath–Pasterski (24/04/2026), https://arxiv.org/pdf/2604.22612. **Leitura:** resumo, §§2 e 4–5, equações e passagens selecionadas (incluindo §5.2 sobre limite assintoticamente plano); **sem auditoria integral**. O artigo reformula limites sobre informação mútua via wedges generalizados de regiões *bulk*, propõe regiões de decisão e obtém um análogo de *connected-wedge theorem* que pode ser formulado em espaço-tempo assintoticamente plano com **tela finita** e hipóteses de foco/causalidade. O próprio §5 destaca que as regiões de decisão na fronteira nula degeneram no limite plano, perdendo informação sobre pontos de saída. **Não** é uma demonstração de AdS/CFT para QED₄, nem dicionário holográfico na infinidade nula sem limitações. **G-FLATCWT-1 [D]:** exigir tela, definição das regiões, condição de foco, causalidade e papel de geometria já assumida.

**HRF-REF-0108 — *The connected wedge theorem and its consequences*.** May–Sorce–Yoshida (2022), https://arxiv.org/pdf/2210.00018. **Leitura:** resumo e §§1–2 com teoremas selecionados; sem reprodução integral. O teorema `n→n` é demonstrado em *bulk* AdS₂₊₁ sob hipóteses geométricas e condição de curvatura nula, com extensão semiclássica condicionada a conjecturas usuais. Os autores corrigem alegação de prova anterior acima de três dimensões. Não inferir universalidade dimensional.

**Reexame HRF-REF-0105:** *Minimax surfaces and the holographic entropy cone*, https://arxiv.org/pdf/2502.09894, §§3.4 e 4.1–4.4. O Teorema 4.1 afirma **se** a configuração de *time-sheets* for *cooperating*, então o corte mínimo do grafo recupera `S_HRT`. A existência para coleções gerais é **Conjectura 4.1**, com exemplos desafiadores. Isto difere do teorema condicional por *exposed regions* de Zhao [0103], da MMI de wedges gravitantes de Bousso–Kaya [0066] e do cone geométrico estático [0067]. **G-COVCONE-2 [D]:** não tratar esses pressupostos como intercambiáveis.

## 5. Situação dos demais eixos e leitura bibliográfica

- **RT/HRT/QES:** [0106] aprofundado (seções e equações selecionadas; prova completa PENDING); [0105] reexaminado (teorema condicional/conjectura); [0107–0108] trechos selecionados. **Não houve reprodução integral independente de qualquer teorema novo.**
- **JLMS/entanglement wedge:** [0036] permanece com decomposição por centro e hipóteses de álgebra; não confundir entropia relativa com S₁/S₂. A interface entre álgebra gauge carregada e QES está **PENDING**.
- **Primeira lei → Einstein:** [0038], [0094–0096] continuam válidos em seus regimes holográficos; nenhuma derivação nova neste ciclo.
- **Métrica:** [0052], [0055], [0064], [0098], [0101], [0104] mantêm restrições de entrada (Γ/E, Hadamard, *lightcone cuts*, conformal factor, *ansatz*, sombras, unicidade). Nenhuma prova adicional de independência do mapa Γ foi realizada neste ciclo.
- **QED₄/elétron/massa:** estados vestidos [0083,0087–0090] e infrapartículas [0086] não eliminam o parâmetro de massa. `QED₄ → gravidade dinâmica → m_e c²≈511 keV` permanece **[?] NÃO DERIVADO**; busca negativa não exaustiva. Val Baker [0031] **não reexecutado**.
- **E71:** relatório/protocolo/LEIAME acessíveis, brutos `E71_resumo.json`, `perfis.json` e ZIP não localizados nesta pasta por busca textual ou filtro MIME. Não foram reprocessados, e `f_c` segue índice operacional Rényi-2, não fração de emaranhamento nem RT.

**Novos IDs:** [0106] Akers–Hernández-Cuenca–Rath (texto original em seções selecionadas; uso direto), [0107] Arayath–Pasterski (trechos originais; uso para limites além de AdS), [0108] May–Sorce–Yoshida (resumo e teoremas selecionados; uso histórico). IDs anteriores 0001–0105 preservados; próximos a partir de 0109. Fontes não verificadas devem continuar `HRF-PEND`, sem inventar título ou status.

**Gates novos:** G-QES-3 (auditoria de sinal/fator editorial), G-U1-1 (Gauss e entropias setoriais), G-FLATCWT-1 (limite plano e tela), G-COVCONE-2 (minimax/condição de cooperação). Nenhum PASS holográfico atribuído.

**Próximo bloco:** conferir errata/versões de [0106] e rederivar passo-a-passo Proposição 2; aprofundar [0107] definições de `e_min,0` e limites com telas; auditar Γ/E e reconstrução Hadamard; localizar E71 ZIP/JSON; tentar modelo U(1) com estado vestido físico, mantendo setor gauge e álgebra explícitos; retomar QED₄/massa e Val Baker. Não executar simulações sem autorização.

## Fontes primárias e links

- [0106] https://arxiv.org/abs/2108.07280 ; https://arxiv.org/pdf/2108.07280 (v2, 08/09/2021).
- [0107] https://arxiv.org/abs/2604.22612 ; https://arxiv.org/pdf/2604.22612 (v1, 24/04/2026).
- [0108] https://arxiv.org/abs/2210.00018 ; https://arxiv.org/pdf/2210.00018 (v3, 03/11/2022).
- [0105] https://arxiv.org/abs/2502.09894 ; [0103] https://arxiv.org/abs/2602.04888 ; [0066] https://arxiv.org/abs/2404.11644 ; [0067] https://arxiv.org/abs/2502.03516.


---

# HRF — Checkpoint bibliográfico CP-19

**Data:** 18/10/2026, 13h04 BRT  
**Base:** CP-18, caderno cumulativo v1.6 (157.290 bytes; CP-01–CP-18), índice v1.8 (108 referências).  
**Natureza:** auditoria de fontes primárias, verificação algébrica simbólica e continuidade documental. **Nenhuma simulação HRF ou execução de bancada autorizada/realizada.**  
**Mapas:** G (geometria) e D (dicionário) neste ciclo; W (dinâmica) não testado.  
**Método:** RUP B → A; classes [F]/[M]/[H]/[?]/[D]; não promover reconstrução condicionada a dualidade microscópica.

## 1. Ordem de leitura e documentação efetivamente consultada

1. **Projeto/arquivos da conversa:** busca por Cap. 0.1, diretrizes B→A, caderno cumulativo, sínteses B2B/ABJM/STAR; recuperada a orientação que exige preservar proveniência e separar G/W/D. **Antes da literatura externa**, li integralmente no Drive o **Capítulo 0.1 v0.2** (09/10/2026, ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, 27.751 caracteres). Nenhuma versão posterior foi identificada nesta consulta; a v0.1 permanece histórica.
2. **Google Drive HRF:** metadados da versão v1.6 (157.290 bytes) e do índice v1.8 (7.845 bytes) conferidos, ambos filhos da pasta `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`. O arquivo local correspondente está disponível integralmente; a nova versão é construída por **concatenação binária**, sem alterar nenhum byte anterior. Buscas `E71_resumo`, `perfis.json`, `ELETRON_71` e `E71.zip` retornaram relatórios, LEIAME e menções, mas não um arquivo bruto ZIP/JSON identificável. **Não prova ausência global**.
3. **Fontes primárias:** [0106] Akers–Hernández-Cuenca–Rath, PDF v2 (eqs. 4.1–4.12); [0055] Tjoa–Gray, PDF v3 (eqs. 47–54 e seções IV–V); [0109] Tjoa–Gray, preprint curto (eqs. 4–15); [0110] Dappiaggi–Moretti–Pinamonti, teoremas 2.1 e 4.1; [0111] Moretti, §4 e teoremas 4.1–4.2. As provas completas de [0110]/[0111] **não foram auditadas integralmente**.

## 2. [0106] Proposição 2: auditoria algébrica independente e questão editorial G-QES-4

**Fonte:** https://arxiv.org/pdf/2108.07280 (v2; *Quantum Extremal Surfaces and the Holographic Entropy Cone*; JHEP 11 (2021) 177, DOI `10.1007/JHEP11(2021)177`).

No artigo, a eq. (4.1c) **define** `I3_alt(X:Y:Z) = S(XY)+S(XZ)+S(YZ)-S(X)-S(Y)-S(Z)-S(XYZ)` — isto é, **menos** a informação tripartida convencional. Portanto, MMI exige `I3_alt ≥ 0`. Porém, a eq. (4.2c) e o sinal em (4.12) escrevem `−I3_alt ≥ 0`; a prova da Proposição 1 também afirma `I3_alt=2S0≥0` para GHZ, embora a substituição de sete entropias iguais a `S0` dê **`I3_alt = −S0`**. Para GHZ₄, `I3_conv = +ln2`, violação MMI de módulo `ln2`.

**Teste exato independente (sem solver físico):** representar `S(X)` por símbolo formal indexado por subconjunto de `A,B,C,D,E,F,G,O`, impor pureza global `S(X)=S(Xᶜ)`, definir `Q(I;J:K)=S(IJ)+S(IK)-S(I)-S(IJK)`. O lado direito da decomposição publicada em (4.12), com **`+I3_alt(AG:B:C)` em vez de `−I3_alt`**, resulta exatamente em:

`S(ABDG)+S(ACEG)+S(BCFG)−S(A)−S(B)−S(C)−S(ABCDEFG)`.

A soma dos cinco termos positivos é:

`+I3_alt(AG:B:C) + Q(A;DEFO:G) + Q(ABG;C:D) + Q(ACG;BD:E) + Q(BCG;ADE:F)`.

A expansão simbólica reduziu a **zero** a diferença dessa soma para a desigualdade-alvo (4.3); com o sinal `−I3_alt` impresso em (4.12), a diferença é `−2 I3_alt(AG:B:C)`, não zero em geral. **Isso verifica a decomposição algébrica corrigida, não toda a derivação QES nem a validade irrestrita da Proposição 2.** O corpo da prova (4.5–4.11) usa as desigualdades no sentido coerente com MMI. A conclusão qualitativa permanece compatível com as desigualdades explícitas. Nenhuma errata específica foi localizada na busca editorial desta rodada; **não se afirma que não exista**. Gate **G-QES-4 [M/D]**: discrepância de sinais e fator localizada, manter auditoria de versão publicada e eventual comunicação editorial como PENDING.

## 3. [0055], [0109–0111]: cadeia de pressupostos de Hadamard/Γ/E — G-GAMMA-3

**[0055] Tjoa–Gray (2022), *Modest holography and bulk reconstruction in asymptotically flat spacetimes*,** https://arxiv.org/pdf/2204.13133, DOI `10.1103/PhysRevD.106.025021`.

A correspondência de Weyl exige que a projeção `Γ` envie soluções físicas para o espaço de soluções da fronteira **e preserve a forma simplética**: `σ_M(φ₁,φ₂)=σ_ℐ(Γφ₁,Γφ₂)`, produzindo uma inclusão de álgebras, **sob hipóteses**. O correlador satisfaz `W_M(f,g)=W_ℐ(ΓEf,ΓEg)` (eq. 50) **apenas após** fornecer o propagador causal `E` do operador Klein–Gordon e a projeção `Γ`. O próprio texto reconhece que `ΓEf` pode não pertencer ao espaço admissível em ℐ⁺ (horizontes, ergorregiões, dados em `i⁺`), e que `E` é gargalo computacional (seções III–IV). **A independência dos dados geométricos na entrada não foi demonstrada**.

**[0109] Tjoa–Gray (2022), *Holographic reconstruction of asymptotically flat spacetimes*,** https://arxiv.org/pdf/2203.15830. Este preprint curto **não é** o mesmo item bibliográfico que [0055], mas é precursor dos mesmos autores; eqs. (4), (7), (15) mostram explicitamente `ψ_f=Γ(Ef)` e a dependência do *smearing* no bulk. A eq. (7) afirma `W_M(f,g)=W_ℐ(ψ_f,ψ_g)` no domínio admissível. Os autores afirmam que geometrias distintas geram projeções `Γ` distintas; a estrutura universal de ℐ⁺, isoladamente, não especifica a métrica interior. **Leitura:** texto completo curto, com foco em eqs. 4–15; não rederivada a integral de fronteira.

**[0110] Dappiaggi–Moretti–Pinamonti (2006), *Rigorous steps towards holography in asymptotically flat spacetimes*,** https://arxiv.org/pdf/gr-qc/0506069. Teorema 2.1: forma simplética BMS-invariante na fronteira. Teorema 4.1: no espaço-tempo de Minkowski 4D, `Γ` preserva a forma simplética e fornece a inclusão da álgebra Weyl do campo escalar real livre na álgebra da fronteira. É um resultado condicional de **QFT em geometria preexistente**, não um mapa universal para campos de Dirac/QED interagentes. **Leitura:** resumo, enunciados e passagens da prova dos Teoremas 2.1/4.1; prova integral NÃO reproduzida.

**[0111] Moretti (2008), *Quantum out-states holographically induced by asymptotic flatness: Invariance under spacetime symmetries, energy positivity and Hadamard property*,** https://arxiv.org/pdf/gr-qc/0610143. Teoremas 4.1–4.2 estabelecem, sob condições de assintoticidade, hiperbolicidade global do espaço-tempo físico e do conforme e presença de `i⁺`, propriedades distribucionais e Hadamard do estado induzido para **campo escalar sem massa conformemente acoplado**. O argumento emprega propagador causal, propriedades microlocais e *wavefront sets*. **Leitura:** resumo, §4 e enunciados selecionados; prova integral NÃO reproduzida. A condição de Hadamard controla singularidade ultravioleta do correlador; não constrói sozinha `Γ` nem `E`.

**Verificação analítica independente (local, Minkowski):** para separação infinitesimal `Δx=x−y`, a parte singular do correlador escalar Hadamard satisfaz `W(x,y)≈[4π² η_{μν}Δx^μΔx^ν]⁻¹` (fora do cone singular e no sentido de limites adequados), portanto `W⁻¹≈4π² η_{μν}Δx^μΔx^ν`; logo `∂_{x^μ}∂_{y^ν} W⁻¹≈−8π²η_{μν}`, e `−(8π²)⁻¹∂_{x^μ}∂_{y^ν}W⁻¹≈η_{μν}`. **Isto confirma somente a identidade local quando o correlador de bulk já está disponível**, não a sua obtenção de dados independentes da métrica.

**G-GAMMA-3 [D]:** para reivindicar emergência geométrica, registrar separadamente entradas `(Γ,E,Ω, álgebra, estado Hadamard, coordenadas, suportes)`, demonstrar a obtenção delas sem fornecer antecipadamente a métrica alvo ou limitar a conclusão a *reconstrução condicional em fundo dado*. Preservar os limites de cobertura (ℐ⁺, horizonte, `i⁺`), smearing/resolução, massa/coupling do campo escalar e ausência de retroação dinâmica.

## 4. Status dos demais eixos, resultados negativos e próximos passos

- **RT/HRT/QES/cones:** [0106] prova da decomposição entrópica (4.12) auditada algebricamente após corrigir sinal; Teorema 2 e Proposição 2 ainda **não** reproduzidos integralmente a partir de QES. Hipóteses de bulk HEC/MMI continuam explícitas; SSA não implica MMI. [0066–67,0103,0105] sem nova auditoria integral neste ciclo.
- **JLMS/primeira lei→Einstein:** [0036–0038,0094–0096] mantêm seus domínios holográficos. Não há derivação nova de Einstein a partir de QED₄ arbitrária.
- **Métrica/Hadamard/fora de AdS:** [0055] reexaminado em eqs. 47–54 e IV–V; [0109–0111] normalizados; o escopo da cadeia AQFT→correlador→métrica é **condicional** e não é dualidade gravitacional microscópica. [0052,0064,0098] aguardam prova integral de unicidade/entrada independente.
- **Gauge/QED₄/elétron/massa:** nenhuma fonte consultada neste ciclo demonstra `QED₄ → gravidade dinâmica → m_e c²≈511 keV`. Os setores infrapartícula/dressing [0082–0090] continuam exigindo estado físico, Gauss, álgebra regional e controle de massa como parâmetro vs derivação. Val Baker [0031] **não reexecutado**; busca negativa **não exaustiva**.
- **E71:** Drive pesquisado por nomes e termos; somente relatório/protocolo/LEIAME e menções recuperados, não `E71_resumo.json`, `perfis.json` nem ZIP bruto. Nenhuma leitura de dados brutos, reprocessamento ou simulação. `f_c` permanece índice operacional Rényi-2, não fração física de emaranhamento.
- **Classificação e uso:** [0109] **texto original curto, usado** para dependência Γ; [0110] **teoremas selecionados, usado** como base algébrica condicional; [0111] **teoremas selecionados, usado** para domínio Hadamard; [0106] **eqs. 4.1–4.12 verificadas algebricamente, usado**; [0055] **trechos originais, usado**. Provas completas, dicionário D e derivação de massa: **PENDING**. Nenhum título incompleto foi promovido a HRF-REF.

**Novos IDs:** HRF-REF-0109, 0110, 0111. Os IDs 0001–0108 não mudam; próxima referência disponível HRF-REF-0112.

**Próximo bloco:** conferir a versão publicada e eventual errata de [0106]; formalizar teste de independência de Γ/E em dois backgrounds com mesmos dados ℐ⁺; auditar as hipóteses de telas finitas e `e_min,0` em [0107]; verificar se os ZIP/JSON E71 estão fora da pasta ou em arquivo com outro nome; retomar correções quânticas dos cones, elétron vestido e o gap QED₄–gravidade–massa. **Nenhuma simulação sem autorização.**

## 5. Fontes primárias e proveniência verificável

- [0106] https://arxiv.org/pdf/2108.07280 ; https://link.springer.com/article/10.1007/JHEP11(2021)177
- [0055] https://arxiv.org/pdf/2204.13133 ; https://journals.aps.org/prd/abstract/10.1103/PhysRevD.106.025021
- [0109] https://arxiv.org/pdf/2203.15830
- [0110] https://arxiv.org/pdf/gr-qc/0506069 ; DOI `10.1142/S0129055X0600270X`
- [0111] https://arxiv.org/pdf/gr-qc/0610143
- Cap. 0.1 v0.2: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view
- Base CP-18: https://drive.google.com/file/d/1dUa09k_-mLZbkLy5FWtqQbwiXhI_vryB/view


---

# HRF — Checkpoint bibliográfico CP-20 — 19/10/2026 01h08 BRT

**Framework:** Holographic Reconstruction Framework (HRF) · **RUP B → A** · **Mapas:** G (geometria) e D (dicionário) estudados; W (dinâmica) **NOT_TESTED**.  
**Classificação:** [F] física/matemática publicada sob hipóteses; [M] verificação algébrica do caderno; [H] ponte não demonstrada; [?] pendência; [D] decisão metodológica.  
**Base real:** CP-19 (18/10/2026, 13h04 BRT), caderno cumulativo **v1.7, 168.558 bytes**, índice v1.9 **111 títulos**. Esta execução acrescenta **0112–0114**, chegando a **114 títulos**. Nenhum ID anterior foi renumerado. **Nenhuma simulação HRF, execução de bancada ou auditoria numérica de E71 foi realizada.**

## 1. Ordem de leitura e proveniência

1. **Leitura integral obrigatória concluída:** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, seções 0.1.1–0.1.17. A versão v0.2 foi a mais recente identificada na busca pelo nome do capítulo; a busca não é inventário global exaustivo. Regras aplicadas: separar G/W/D, nunca promover analogia a dualidade, conservar gates e resultados negativos, e distinguir *boundary 2D* de um bulk 3D.
2. **Arquivos do Projeto/conversa:** busca específica por Cap. 0.1, caderno e ELETRON-71 não retornou arquivos indexados diretamente no escopo de conversa. Foram utilizados os arquivos Markdown históricos efetivamente montados nesta sessão, sem atribuir a eles o status de anexos originais do Projeto. **Nenhuma leitura de arquivo de Projeto não encontrado foi reivindicada.**
3. **Google Drive HRF:** conferidos metadados do CP-19: caderno v1.7 ID `16_ImKwgphaEUj6APfKQ95KFj0Yj-6lIW` (168.558 bytes), índice v1.9 ID `112ZuYj6CmSdvwk2VZTooFDOVxu_Nrmla` (8.168 bytes), checkpoint ID `1Q2uzPp-rGaFLxqwvvUGHdwuBu3fsaDve`, todos na pasta Physics ID `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`. O conteúdo integral local do caderno v1.7 foi usado como **prefixo binário sem alterações**.
4. **Busca E71:** `LEIAME_E71_resultados.md` ID `1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf` identifica o pacote `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip` e os arquivos `dados/perfis.json` e `resultados/E71_resumo.json`. Busca nominal do ZIP e filtro MIME ZIP entre filhos diretos da pasta Physics **não recuperaram o pacote**. A ausência na busca **não prova inexistência no Drive**, especialmente em outras pastas/ZIP não indexado.
5. **Fontes primárias externas (após o Drive):** [0112] Harlow 2016/2017, texto original §§5.1–5.2; [0113] Kamal–Penington 2019, PDF §§II–VI, Teoremas 1–2, eqs. (6), (18)–(24); [0114] Camps 2019, texto original §4 e eqs. (17)–(21). Foram lidos **trechos e demonstrações selecionados**, não integralmente rederivados os teoremas gerais.

## 2. [0112] Harlow — álgebra central e RT por correção de erros

**HRF-REF-0112 — The Ryu-Takayanagi Formula from Quantum Error Correction** (Daniel Harlow, *Communications in Mathematical Physics* 354, 865–912, 2017; arXiv:1607.03901; DOI 10.1007/s00220-017-2904-z). Fonte: https://arxiv.org/pdf/1607.03901 . **Leitura:** §§5.1–5.2 e §6.1 selecionadas; usado; prova global não replicada.

**[F, condicionado]** Para código quântico finito com reconstrução complementar, a álgebra lógica `M` pode ter centro `Z(M)` não trivial, e o operador de área `L_A` pertence a esse centro. Nas eqs. (5.26)–(5.28):

`L_A = ⊕_α S(χ_{A2}^α) I_α`, `S(ρ_A)=Tr(ρ L_A)+S_alg(ρ,M)`.

As eqs. (5.33)–(5.36) estabelecem relações correspondentes de Hamiltonianos modulares e entropias relativas **no código e nas condições do teorema**, não uma derivação de geometria dinâmica de QED₄. Harlow discute restrições de gauge e *edge modes* em §6.1. O termo `L_A` é uma construção algébrica do código; interpretá-lo como área gravitacional física requer dicionário adicional [H/?].

## 3. [0113] Kamal–Penington — centro da boundary e entropia que entra em RT

**HRF-REF-0113 — The Ryu-Takayanagi Formula from Quantum Error Correction: An Algebraic Treatment of the Boundary CFT** (Helia Kamal e Geoffrey Penington, 2019, arXiv:1912.02240). Fonte: https://arxiv.org/pdf/1912.02240 . **Leitura:** PDF §§II–VI, Teoremas 1–2, eqs. (6), (18)–(24); usado; apêndices/prova integral não rederivados.

**[F, condicionado]** O trabalho estende a recuperação complementar a **álgebras tanto de bulk quanto de boundary com centro**. O Teorema 2 é formulado em espaços de Hilbert **finitos**, com subespaço de código e recuperação de `M` a partir de `N` e de `M'` a partir de `N'`. Nessas condições:

`S_alg(ρ,N) = Tr(ρ L) + S_alg(ρ,M)`, `L ∈ Z(M)`; e a entropia relativa algébrica é preservada. A generalização a CFT contínua com álgebras tipo III, correções `G_N` e reconstrução aproximada **não** é afirmada pelo teorema finito.

Para decomposição por setores de superseleção `α`:

`S_alg(ρ,N)=H(p_α)+Σ_α p_α S(ρ_α)`  [eq. (6)];

`S_dist(ρ,N)=Σ_α p_α S(ρ_α)`  [eq. (22)];

`S_ext(ρ,N)=S_alg(ρ,N)+Σ_{e,R}p_{e,R} log dim(R)`  [eq. (24), escolha de Hilbert estendido em gauge não abeliano].

**Crucial para E71:** a entropia *distillable* não obedece em geral à mesma fórmula RT algébrica (texto §V); portanto, chamar `f_c` (construído com Rényi-2) de “fração de emaranhamento destilável” **não** é autorizado por JLMS, Harlow ou Kamal–Penington. Para U(1), as representações irredutíveis são unidimensionais, `log dim R=0`; isto elimina o termo específico `log dim R`, **não** a entropia de mistura dos setores `H(p)`.

**G-ALGRT-1 [D]:** qualquer tentativa HRF de B5/JLMS/QES deve declarar `M`, `M'`, `N`, `N'`, centros, setor de carga, *cutoff*, definição de entropia (`S_alg`, `S_dist`, `S_ext`, `S_1`, `S_2`) e prova de recuperação complementar. O termo de área **não pode ser inferido** de `H(p)` isoladamente. *PASS* para identidade algébrica no exemplo abaixo; **PENDING** para dicionário físico e código holográfico HRF.

## 4. [M] Controle algébrico independente — código de repetição de dois qubits

**Definição:** `H_phys = C²_A ⊗ C²_B`; `H_code=span{|00>,|11>}`; `M=span{I_L,Z_L}` (álgebra lógica abeliana, `M'=M` dentro do código), `N=B(C²_A)⊗I_B` e `N'=I_A⊗B(C²_B)`. O operador lógico `Z_L` possui representantes `Z_A` e `Z_B` sobre o código, logo há recuperação complementar **neste modelo finito**.

Estado puro codificado `|ψ_p>=√p|00>+√(1-p)|11>`, `0≤p≤1`. A redução da boundary é `ρ_A=diag(p,1-p)`; a restrição à álgebra `M` possui probabilidades `(p,1-p)` e **blocos unidimensionais**. Portanto:

`S(ρ_A)=H_2(p)=−p ln p−(1−p)ln(1−p)`;

`S_alg(ρ,M)=H_2(p)`; `S_dist(ρ,M)=0`; `L=0` fornece `S(ρ_A)=Tr(ρL)+S_alg(ρ,M)` para **todo p**.

**Prova de falha da troca indevida por entropia destilável:** suponha `S(ρ_A)=Tr(ρ L)+S_dist(ρ,M)` para todos os `p`, com `L` operador central fixo de autovalores `ℓ_0,ℓ_1`. Em `p=0` e `p=1`, `S(ρ_A)=0` implica `ℓ_0=ℓ_1=0`; em `p=1/2`, a equação exigiria `ln2=0`. Contradição. Não existe esse `L` fixo. Para `p=3/4`, `S_alg=0,562335144619` nats, `S_2=0,470003629246` nats e `S_dist=0`.

**Teste JLMS neste código:** para duas restrições de estados `p,q∈(0,1)`, `D(ρ_A(p)||ρ_A(q))=p ln(p/q)+(1−p)ln((1−p)/(1−q))=D_alg(ρ_M(p)||ρ_M(q))`. Com `p=3/4`, `q=1/2`, resulta `0,130812035941` nats. Esta é **identidade elementar verificada**, não prova da correspondência gravitacional geral.

**Limites explícitos:** modelo sem campo EM dinâmico, sem Gauss em rede U(1), sem fermion, sem massa, sem geometria/área gravitacional; `L=0`. A construção **não** é uma simulação nem uma dualidade RT física. Conecta os controles anteriores G-GAUGE-5/6, G-RELENT-1 e G-U1-1.

## 5. [0114] Camps — centros gravitacionais e extremalidade

**HRF-REF-0114 — Superselection sectors of gravitational subregions** (Joan Camps, *JHEP* 01 (2019) 182; arXiv:1810.01802; DOI 10.1007/JHEP01(2019)182). Fonte: https://arxiv.org/pdf/1810.01802 . **Leitura:** resumo, §§3–4 e eqs. (17)–(21) selecionadas; usado; prova integral não reproduzida.

**[F, condicionado]** O trabalho analisa a forma simplética das perturbações gravitacionais e condições para definir subregiões com superfícies de separação não físicas. No procedimento estudado, a extremalidade `K_a=0` e a restrição de variação `δK_a=0` eliminam certos termos de translação na forma simplética; a eq. (21) exige adicionalmente `K̄_a^{ij} δh̄_{ij}=0`. O centro pode ser descrito pela classe conforme da métrica induzida, sob vínculos geométricos. Isso **não equivale** a simplesmente substituir o fluxo elétrico de U(1) por área de triângulos Delaunay da boundary.

**G-GRAVCENTER-1 [D]:** distinguir centro elétrico da álgebra gauge, centro gravitacional no espaço de fases e operador central de área em código holográfico. Os três podem estar relacionados por um dicionário físico **a construir**, não por identificação de nomes. A escolha de superfície extrema e condições de contorno entra nas hipóteses, não emerge de um modelo sem geometria prévia.

## 6. Síntese científica e auditoria dos eixos

| Eixo | Estado da leitura e do uso neste CP-20 | Limite |
|---|---|---|
| RT/HRT/QES, entanglement wedge e JLMS | [0112] §§5.1–5.2 e [0113] Teorema 2/eqs. 6,18–24 **usados**; cálculo exato do código de dois qubits **replicado** | Código finito + recuperação complementar, não equivalência física HRF nem QES dinâmica |
| Entropias e centros gauge | Distinção `S_alg`, `S_dist`, `S_ext`, `S_2` **usada**; U(1) `dim R=1` | E71 `f_c` operacional, não destilabilidade certificada |
| Gravidade e superfícies extremas | [0114] §4 e eqs. 17–21 **usados** | Condições de contorno, fase simplética, geometria assumida |
| Primeira lei→Einstein | [0038], [0094–0096] mantidos, **não rederivados neste ciclo** | CFT holográfica, perturbações adequadas; não QED₄ genérica |
| Métrica, Γ/E, Hadamard | [0055], [0109–0111] herdados de CP-19; **sem nova prova de unicidade** | Dependência de fundo e propagador permanece G-GAMMA-3 PENDING |
| Cones e além de AdS | [0066–67], [0103–0108] preservados, **não reauditados integralmente** | Diferenciar áreas geométricas, matéria quântica, covariância e telas finitas |
| Férmions/QED₄/elétron | [0042], [0083–0090] **referências prévias, sem nova derivação** | Gauss, spinor vestido, modos soft, espectro de massa e backreaction não costurados |
| E71 | LEIAME original **lido**, ZIP e JSON não recuperados | Sem dados brutos, sem auditoria de código e sem simulação |
| Val Baker [0031] | Referência histórica mantida, **não reexecutada** | Nenhuma evidência nova de massa eletrônica emergente |

**Frente negativa não exaustiva [?/H]:** nenhuma fonte examinada neste ciclo deriva `QED₄ → geometria gravitacional dinâmica → m_e c²≈511 keV`. Harlow/Kamal–Penington demonstram relações condicionais entre álgebras, entropias e códigos; Camps analisa subregiões gravitacionais sobre fundo geométrico. **Nenhum deles fornece sozinho os mapas G, W e D para um elétron físico.**

## 7. Histórico, decisões e próximo bloco

- **CP-01–CP-19:** preservados integralmente pelo prefixo binário v1.7 (168.558 bytes), sem reedição retroativa. **CP-20** acrescenta três trabalhos, IDs [0112–0114]; próxima referência normalizada **HRF-REF-0115**. Incompletos continuam `HRF-PEND`, não são numerados.
- **G-ALGRT-1:** PASS somente no código analítico finito; PENDING na interface HRF (álgebra gauge física → código holográfico → área/gravitação).
- **G-GRAVCENTER-1:** distinção entre centro gauge, gravitacional e operador central de área, sem equivalência assumida.
- **Próximo bloco:** (i) auditoria de Teorema 2 [0113] e prova apêndice B; (ii) investigar códigos finitos com centro não trivial **e** operador de área não zero; (iii) confrontar [0114] com JLMS [0036] e QES [0106]; (iv) retornar a Γ/E e unicidade; (v) localizar ZIP E71 em outras pastas; (vi) continuar o gap QED₄–gravidade–massa e a auditoria Val Baker, sem simulação não autorizada.

## 8. Referências e URLs primárias

- [0112] https://arxiv.org/pdf/1607.03901 ; https://doi.org/10.1007/s00220-017-2904-z
- [0113] https://arxiv.org/pdf/1912.02240
- [0114] https://arxiv.org/pdf/1810.01802 ; https://doi.org/10.1007/JHEP01(2019)182
- Cap. 0.1 v0.2: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view
- Caderno CP-19: https://drive.google.com/file/d/16_ImKwgphaEUj6APfKQ95KFj0Yj-6lIW/view
- Índice CP-19: https://drive.google.com/file/d/112ZuYj6CmSdvwk2VZTooFDOVxu_Nrmla/view
- LEIAME E71: https://drive.google.com/file/d/1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf/view


---

# HRF — Checkpoint de Pesquisa Bibliográfica CP-21

**Data/hora:** 19/10/2026, 13:09 BRT. **Caderno cumulativo:** v1.9. **Índice:** v2.1. **Identificadores preservados:** HRF-REF-0001–0114; novos 0115–0117; próximo 0118. **Estatuto:** auditoria bibliográfica e cálculo analítico; nenhuma simulação autorizada ou executada.

## 1. Ordem de fontes, método e proveniência

1. **Capítulo 0.1 v0.2:** leitura integral real de `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, 27.751 caracteres de texto retornados. Sem versão posterior confirmada na busca pelo nome. Diretriz [D]: RUP B→A, mapa **G** (geometria), **W** (dinâmica de excitação), **D** (dicionário físico); classificação [F]/[M]/[H]/[?]/[D]. Proibido converter entropia, código ou área de rede em gravidade física por analogia.
2. **Arquivos do Projeto/conversa:** conferidos caderno v1.8 CP-20, índice v2.0 e checkpoint CP-20 disponíveis na conversa. **Google Drive:** recuperado o caderno CP-20, ID `1YNue15nYS0oMme2odkBUQOxxGgeCy0eg`, e índice, ID `1I67EyrwBxe-nFuXTPtQdlr0QI6MkmxXN`; ambos na pasta `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`. Caderno anterior tem **181.521 bytes UTF-8**; este novo caderno conserva exatamente esse prefixo, sem edição retrospectiva.
3. **Fontes primárias externas:** PDF completo de Donnelly–Marolf–Michel–Wien [0115], seções 2–4.1 e equações (3.3)–(3.8), (4.12)–(4.16); PDF de Cao–Lackey [0116], resumo, §§3, 6 e 7.2–7.4 selecionadas; artigo integral online de Kurihara [0117], §§3.1, 5.2.5 e equações (189b), (193b), (198)–(200) selecionadas. Harlow [0112], Kamal–Penington [0113] e Donnelly–Freidel [0073] revisitados como controles; leitura do Teorema 2 [0113] e começo do Apêndice B, **sem reprodução integral da prova**.
4. **Níveis de evidência:** [F] resultados condicionais dos artigos no domínio declarado; [M] álgebra finita abaixo **recalculada independentemente**, inspirada no exemplo explícito (3.7) de [0115], não descoberta original; [H] possível dicionário gauge/gravity no HRF; [?] implementação física QED₄ e área gravitacional; [D] novos gates. Leitura de PDF ≠ replicação da demonstração completa.

## 2. [0115] Código com centro e operador de área não trivial

**HRF-REF-0115 — Living on the Edge: A Toy Model for Holographic Reconstruction of Algebras with Centers.** William Donnelly, Ben Michel, Donald Marolf e Jason Wien; *JHEP* 04 (2017) 093; arXiv:1611.05841; DOI 10.1007/JHEP04(2017)093. **Fonte primária:** https://arxiv.org/pdf/1611.05841 . **Leitura:** texto selecionado §§2, 3, 4.1, equações (3.3)–(3.8), (4.12)–(4.16); **usado**; prova da rede completa **não** replicada.

O artigo amplia o código HaPPY com graus de liberdade nas arestas e tensores copiadores `G`, permitindo reconstruir operadores centrais a partir de ambas as partes complementares. O operador `Z` da aresta pode ser representado em A e em B, mas `X` requer as duas partes; esta estrutura **não** demonstra por si só que os modos de borda de um modelo HRF sejam fótons/elétrons físicos. Os autores admitem que a região residual `X` da rede discreta nem sempre é negligenciável e, para a expressão simples, restringem a análise a `X=∅` (§4.1). O termo linear setorial `Σ p_α S(ρ_aux(α))` é **análogo** a correção de área, não medição independente de área gravitacional. A própria discussão ressalva a identificação completa com gravitons FLM.

### [M] Controle algébrico exato, sem simulação — área central dependente do setor

Considere Hilbert lógico `H_code = span{|0_L>,|1_L>}` e regiões físicas `A=(f_A,e_A)` e `B=(f_B,e_B)` com dois qubits por região. Defina a isometria `V` (uma forma explícita da eq. (3.7) de [0115]):

`V|0_L> = |0>_{f_A}|0>_{f_B} ⊗ |0>_{e_A}|0>_{e_B}`;

`V|1_L> = |1>_{f_A}|1>_{f_B} ⊗ (|00>_{e_Ae_B}+|11>_{e_Ae_B})/√2`.

As imagens são ortonormais (flags distintas), logo `V†V=I_code`. Para `|ψ_p>=√(1-p)|0_L>+√p|1_L>`, com `0≤p≤1`, após traçar B:

`spec(ρ_A) = {1-p, p/2, p/2, 0}`.

Defina álgebra lógica abeliana `M=span{I_L,Z_L}` e seu centro `Z(M)=M`; ela pode ser reconstruída nas flags de A **e** B (recuperação complementar da álgebra **M**, não da álgebra lógica total). Restrição a M tem pesos `(1-p,p)`, blocos unidimensionais e `S_alg(ρ,M)=H(p)`.

**Identidade RT algébrica do código:**

`S_1(ρ_A)=H(p)+p ln 2 = S_alg(ρ,M)+Tr(ρ L)` com `L=(ln 2)|1_L><1_L| ∈ Z(M)`.

O operador L é fixo e central, com autovalores distintos `0` e `ln 2`, de modo que o termo de área **não é constante** entre setores. A identidade vale para todos os estados codificados porque as reduções à álgebra M e a A descartam coerências entre flags, e os blocos auxiliares condicionais são fixos.

**Entropia relativa JLMS algébrica neste código:** para duas distribuições `p,q∈(0,1)`, com os mesmos blocos auxiliares condicionais,

`D(ρ_A(p)||ρ_A(q))=(1-p)ln[(1-p)/(1-q)] + p ln(p/q) = D_alg(ρ_M(p)||ρ_M(q))`.

Não equivale à entropia relativa dos dois **estados puros globais**, que é infinita para vetores diferentes; a igualdade vale nas **restrições de A e M**. Para `p=3/4, q=1/2`, ambas dão `0,130812035941` nats.

**Rényi-2 não possui a mesma fórmula linear:**

`S_2(ρ_A) = -ln[(1-p)^2+p^2/2]`, `S_2(ρ_M)=-ln[(1-p)^2+p^2]`.

Em `p=3/4`, `H(p)=0,562335144619`, `S_1(ρ_A)=1,082195530039`, `S_2(ρ_A)=1,067840630001`, `S_2(ρ_M)=0,470003629246`, e `S_2(ρ_A)-S_2(ρ_M)=0,597837000756`, diferente de `Tr(ρL)=p ln2=0,519860385420`. Os extremos `p=0,1` exigiriam `L_0=0`, `L_1=ln2`, mas a identidade falha para valores intermediários: **nenhum operador central fixo com esses extremos torna `S_2(A)=S_2(M)+TrρL` válido para todo p**. Este é um controle algébrico exato, não simulação nem prova de RT gravitacional.

**G-ALGRT-2 [D]:** PASS para construção finita explícita com `L≠constante`, `S_1` e entropia relativa algébrica; FAIL para substituição universal `S_1→S_2` mantendo mesmo L; PENDING para código HRF com Gauss dinâmico, gravidade e dicionário D. É possível **fabricar** L via entropia auxiliar sem derivar área geométrica. Isso constitui um controle adversarial contra alegar geometria emergente só por ajustar entropia.

## 3. [0113] Teorema 2 e Apêndice B — hipóteses precisas

Kamal–Penington [0113], https://arxiv.org/pdf/1912.02240, Teorema 2: em **Hilbert físico finito**, com subespaço `H_code`, álgebras de von Neumann `N` e `M` e suas comutantes, equivalência entre (a) recuperação complementar de operadores e adjuntos, (b) fórmulas RT algébricas em `N/N'` e `M/M'` para **todo** estado do código com `L∈Z(M)`, e (c) igualdades de entropia relativa algébrica em ambas as partes para todo par de estados admissíveis. O Apêndice B deriva estrutura de estados condicionais `|χ_α>` e `L=⊕_α S(χ_α,N)I_α` (eqs. 18–19). A auditoria deste ciclo **reproduziu um caso finito especial** da direção (a)⇒(b,c); não reexecutou a prova do Teorema 2 para álgebras arbitrárias nem sua extensão a QFT tipo III.

**G-JLMS-2 [D]:** ao comparar entropias e operadores de área no HRF, declarar algebras `N,N',M,M'`, centro, cutoffs, condição de recuperação e estado/intervalo de validade. Um operador central construído por isometria arbitrária não é evidência de Einstein dinâmico, nem prova de bulk físico.

## 4. [0116] Códigos aproximados e o limite da analogia de backreaction

**HRF-REF-0116 — Approximate Bacon-Shor Code and Holography.** ChunJun Cao e Brad Lackey, *JHEP* 05 (2021) 127, arXiv:2010.05960. Fonte primária https://arxiv.org/pdf/2010.05960 . **Leitura:** resumo, §§3, 6, 7.2–7.4 e trechos de §5.5; **usado**; rede completa e provas **não** replicadas.

Os códigos híbridos Bacon–Shor e suas versões *skewed* exibem centros não triviais, reconstrução de subregiões e mudança de acesso aos operadores conforme o estado lógico. O artigo registra que **a recuperação complementar exata pode falhar** nos códigos aproximados, embora subsistemas particulares mantenham recuperação parcial. Os autores **não reivindicam** que a resposta geométrica seja necessariamente gravidade de Einstein (nota 20) e explicitam que a ligação entre sua backreaction análoga e a gravidade física continua por compreender (§7.4). **G-APPROXCODE-1 [D]:** se o HRF passar de código exato para aproximado, registrar norma de erro de recuperação, intervalo de estados, tamanho do código, dependência da região e controle de backreaction; a palavra “backreaction” não basta para validar a equação de Einstein.

## 5. [0117] Frente negativa direta — massa do elétron como parâmetro de entrada

**HRF-REF-0117 — Quantum GraviElectro Dynamics.** Kurihara, *Annalen der Physik* (2026), DOI 10.1002/andp.202500318. Texto original: https://onlinelibrary.wiley.com/doi/full/10.1002/andp.202500318 . **Leitura:** §§3.1, 5.2.5 e equações selecionadas (189b), (193b), (198)–(200); **usado como controle negativo**, sem auditoria da renormalização integral.

O título sugere ligação direta entre eletromagnetismo e gravitação. Contudo, §5.2.5 explicita **três parâmetros físicos da lagrangiana bare**, incluindo `m_e^∞`, a serem substituídos por **valores medidos**. O artigo calcula contratermos/renormalização e discute como determinar experimentalmente massa e carga; **não deriva o valor 511 keV sem entrada de massa**. A eq. (189b) para correção eletromagnética é proporcional a `m_e` e contém escala de renormalização; isso não é geração de massa a partir de zero. **G-MASSINPUT-1 [D]:** para reivindicar derivação de `m_e`, auditar se `m_e` ou parâmetro equivalente já aparece na ação, condições de contorno, espectro de referência, unidade calibrada ou dados experimentais. Resultado da fonte [0117]: **FAIL** como derivação independente da massa; **não** implica invalidar toda a proposta de QGED.

**Busca negativa delimitada (não exaustiva):** consultas específicas em 19/10/2026 por QED₄ + holografia + massa do elétron + gravidade emergente produziram [0117] e trabalhos adjacentes que calculam correções a massas/parâmetros existentes, sem uma prova independente `QED₄→gravidade dinâmica→m_e`. Não confundir ausência nas buscas com impossibilidade matemática.

## 6. Frente E71 e mapa de lacunas

**Drive E71:** nova busca por nome exato `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, prefixo `HRF_ELETRON_71`, `E71_resumo` e `perfis.json`. Apenas relatório, protocolo, LEIAME e menções em cadernos/checkpoints retornaram; **ZIP e JSON brutos não localizados**. LEIAME documenta existência esperada do pacote, não comprova cópia recuperável. Sem reprocessamento, auditoria de hash, execução de código ou simulação.

| Eixo | Resultado CP-21 | Pendente |
|---|---|---|
| RT/HRT/QES/JLMS | [0115] §§3–4.1 e [0113] Teorema 2/Apêndice B selecionados; identidade finita **recalculada** | Bulk físico, superfícies extremas, correções QES, álgebra tipo III |
| Centros gauge/gravidade | `L∈Z(M)` construído; `S_alg` vs `S_2` distinguidos | Gauss dinâmico, dressings QED₄, modos soft, centro gravitacional físico |
| Reconstrução geométrica G | Nenhuma prova nova de independência de métrica | Γ/E Hadamard [0055,0109–0111], Takeda/Sugiura [0052,0064], unicidade e sombras |
| Dinâmica W e dicionário D | Código matemático estático, sem Hamiltoniano físico | Maxwell/Dirac/QED₄ e mapeamento boundary↔bulk |
| Primeira lei→Einstein | [0038,0094–0096] preservados; [0116] ressalva Einstein | Demonstrar equações dinâmicas, não apenas variação entrópica |
| Férmions e massa | [0117] rejeitado como derivação independente de `m_e` | Carga, spin 1/2, estatística, infrapartículas, massa sem parâmetro de entrada |
| Além AdS | [0066–67,0103–0108] preservados; não reauditados neste ciclo | Condições de wedges e telas finitas; dualidade QED₄ não estabelecida |
| Val Baker [0031] | Preservado como frente histórica | Auditoria independente não realizada |

## 7. Histórico, decisões e próximo bloco

- **CP-01–CP-20:** preservados **byte por byte** como prefixo do caderno v1.8 (181.521 bytes); este checkpoint CP-21 é **somente acrescentado**, sem reescrever texto anterior. Índice preserva HRF-REF-0001–0114 exatamente; novas entradas 0115–0117. Próximo ID 0118; itens incompletos permanecem `HRF-PEND`.
- **Novos gates:** G-ALGRT-2 (PASS em S1, FAIL em troca universal S2), G-JLMS-2 (condições exatas), G-APPROXCODE-1 (erro de recuperação), G-MASSINPUT-1 (massa preexistente).
- **Próximo bloco:** (i) confrontar a construção (3.6)–(4.16) [0115] com centro de fluxo U(1) e carga dinâmica (não apenas flag artificial); (ii) QES/JLMS com centro gravitacional e correções aproximadas; (iii) tentar recuperar o pacote E71 por localização em outros diretórios sem executar; (iv) voltar à independência Γ/E e às provas de reconstrução métrica; (v) aprofundar o front QED₄–gravidade–massa e a auditoria Val Baker. Preservar RUP B→A e G/W/D separados.

## 8. Fontes primárias e identificadores

- [0115] https://arxiv.org/pdf/1611.05841 ; https://doi.org/10.1007/JHEP04(2017)093
- [0116] https://arxiv.org/pdf/2010.05960 ; https://doi.org/10.1007/JHEP05(2021)127
- [0117] https://onlinelibrary.wiley.com/doi/full/10.1002/andp.202500318
- [0112] https://arxiv.org/pdf/1607.03901 ; [0113] https://arxiv.org/pdf/1912.02240
- Capítulo 0.1 v0.2: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view
- Caderno CP-20: https://drive.google.com/file/d/1YNue15nYS0oMme2odkBUQOxxGgeCy0eg/view
- Índice CP-20: https://drive.google.com/file/d/1I67EyrwBxe-nFuXTPtQdlr0QI6MkmxXN/view
- LEIAME E71: https://drive.google.com/file/d/1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf/view


---

# HRF — Checkpoint de pesquisa bibliográfica CP-22

**Data/hora:** 20/10/2026 01:05 BRT (America/Sao_Paulo).  
**Base documental:** CP-21, caderno cumulativo v1.9 (195.534 bytes), índice v2.1 (117 linhas, HRF-REF-0001–0117).  
**Novas entradas:** HRF-REF-0118–0120; próximo identificador 0121.  
**Mapas em foco:** G (estrutura de entropia regional e centros), D (costura física ainda não demonstrada), W (não testado).  
**Método:** RUP B→A; classes [F]/[M]/[H]/[?]/[D]; **nenhuma simulação ou execução de protocolo HRF**.

## 1. Ordem das fontes e integridade

1. **Capítulo 0.1:** leitura integral efetiva do arquivo `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, ID Drive `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, seções 0.1.1–0.1.17. Busca por título não identificou versão posterior; a duplicata v0.2 não foi tomada por revisão. O capítulo distingue Delaunay/Voronoi de superfície RT/HRT, separa G/W/D e proíbe interpretar sucesso de discretização como holografia física.
2. **Projeto/conversa:** foram consultados os arquivos CP-21 e os cadernos/índices historicamente disponibilizados na conversa, incluindo a cópia local íntegra v1.9. Nenhuma nova fonte especializada do Projeto foi pressuposta sem leitura.
3. **Google Drive HRF:** recuperado CP-21 v1.9 (ID `1xlIAWPPDsnXJIxE7B4XB9UrHxFd-xevQ`, 195.534 bytes) e verificado índice v2.1 (ID `1WMYgFdTQ4dHfNUtT1YPwyhKcEIceO9ow`); consultada pasta Physics, ID `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`.
4. **Literatura primária:** PDFs integrais disponibilizados para leitura de trechos específicos: Ghosh–Soni–Trivedi (2015), Soni–Trivedi (2016), Van Acoleyen et al. (2016). Não foi reproduzida a totalidade das demonstrações dos artigos.

## 2. Novas fontes normalizadas e nível de leitura

**HRF-REF-0118 — On the entanglement entropy for gauge theories** — S. Ghosh, R. M. Soni, S. P. Trivedi, *JHEP* 09 (2015) 069, DOI `10.1007/JHEP09(2015)069`, arXiv:1501.02593. **Leitura:** texto integral aberto para inspeção, selecionadas seções 2–3, equações (2.18)–(2.23) e discussão de U(1) (páginas 7–11). **Uso:** a lei de Gauss força a matriz regional a ser bloco-diagonal em fluxos de fronteira, `ρ_A=⊕_k p_k ρ_{A,k}`, e `S_1=H(p_k)+Σ_k p_k S(ρ_{A,k})`; a definição depende da escolha de álgebra/embedding. A equivalência com o centro elétrico é apresentada para setores abelianos sem matéria na construção considerada. **Status:** equações selecionadas lidas; prova integral e generalização para matéria não auditadas.

**HRF-REF-0119 — Aspects of entanglement entropy for gauge theories** — R. M. Soni, S. P. Trivedi, *JHEP* 01 (2016) 136, DOI `10.1007/JHEP01(2016)136`, arXiv:1510.07455. **Leitura:** introdução, sumário e discussão das definições e dos setores de superseleção; partes das seções 2–4 examinadas. **Uso:** no caso não abeliano, o embedding estendido pode adicionar termo de dimensão de representação, além de Shannon e entropia intrassetor; operações locais gauge-invariantes não destilam automaticamente toda a entropia de embedding. **Status:** texto selecionado; protocolos completos de destilação/diluição não reproduzidos.

**HRF-REF-0120 — Entanglement of Distillation for Lattice Gauge Theories** — K. Van Acoleyen, N. Bultinck, J. Haegeman, M. Mariën, V. B. Scholz, F. Verstraete, *Phys. Rev. Lett.* 117 (2016) 131602, DOI `10.1103/PhysRevLett.117.131602`, arXiv:1511.04369. **Leitura:** texto integral acessível; seções introdutórias e demonstração da estrutura de superseleção nas páginas 1–4, discussão de matéria e equações correspondentes. **Uso:** distingue a entropia estendida do emaranhamento operacionalmente destilável por operações locais que respeitam gauge; inclui matéria, com condições específicas sobre a restrição por cópia em protocolos assintóticos. **Status:** equações selecionadas e hipóteses; apêndice completo não replicado.

**Controle de duplicatas:** [0072] Donnelly–Wall, [0073] Donnelly–Freidel, [0075] Casini–Huerta–Rosabal e [0080] Donnelly–Wall já estavam catalogados; foram **reutilizados**, não renumerados nem acrescentados novamente.

## 3. G-U1-2 — Modelo analítico com cargas dinâmicas permitidas e fluxo elétrico físico

**Objetivo:** superar a limitação do CP-21, em que um `flag` lógico artificial rotulava setores sem impor Gauss. Aqui, construir *apenas algebricamente* estados em uma cadeia aberta compacta U(1), com três vértices `1—2—3` e dois elos orientados `1→2`, `2→3`. Impor campo externo nulo `E_0=E_3=0` e operador de Gauss local

`G_i = E_{i,i+1} - E_{i-1,i} - Q_i = 0`.

Para `n∈{0,1}`, definir a base física `|n⟩` por

`(Q_1,Q_2,Q_3)=(n,0,-n)`, `(E_12,E_23)=(n,n)`.

**Verificação independente:** `G_1=n-0-n=0`; `G_2=n-n-0=0`; `G_3=0-n-(-n)=0`, nos dois setores. A carga total é `ΣQ_i=0`, como exigido pelas condições abertas de fluxo externo nulo. `n=1` representa um par de cargas opostas conectado por fluxo/Wilson string; `n=0`, vácuo de carga. Ambos são estados gauge-invariantes no espaço físico restrito; sua superposição também satisfaz Gauss por linearidade. **Limites:** truncamento `n=0,1`, ausência de Hamiltoniano, de dinâmica de pares, de campo contínuo e de dressings infravermelhos de QED₄.

Considere a região `A` envolvendo o vértice 1, um recorte elétrico da aresta 12 e uma ancila **neutra** `a`; o complemento contém o restante e uma ancila neutra `b`. No setor `n=0`, as ancilae estão em `|0_a0_b⟩`; em `n=1`, estão no estado de Bell `|Φ+⟩=(|0_a0_b⟩+|1_a1_b⟩)/√2`. O estado físico global é

`|Ψ_p⟩ = √(1-p)|n=0;00⟩ + √p|n=1;Φ+⟩`, com `0≤p≤1`.

O traço regional no embedding de centro elétrico, com setores ortogonais de fluxo, tem espectro não nulo

`spec(ρ_A) = (1-p, p/2, p/2)`.

**Derivação [M], sem simulação:**

- `S_1(A)=H_2(p)+p ln 2`, onde `H_2(p)=-(1-p)ln(1-p)-p ln p` é a **entropia binária de Shannon** (não a entropia de Rényi-2).
- `S_{Rényi,2}(A)=-ln[(1-p)^2+p^2/2]`.
- `S_{alg,centro}(A)=H_2(p)+p ln2` na convenção com centro elétrico e espaço intrassetor da ancila; a parte central de superseleção é `H_2(p)`.
- `E_D^{SSR}(A:B)=p ln2` em unidades de entropia, **sob LOCC local gauge-invariante e regra de superseleção imposta separadamente a cada cópia**; a parte `H_2(p)` não é destilável nessas condições. Sem ancila Bell, o mesmo estado de fluxo tem `E_D^{SSR}=0` apesar de `S_1=H_2(p)`.
- Para dois estados com os mesmos condicionais intrassetor e pesos `p` e `q`, `D(ρ_A(p)||ρ_A(q))=D_KL((1-p,p)||(1-q,q))` se `p,q∈(0,1)`. Não existe daí uma identidade JLMS gravitacional sem código/área/dual.

**Checagem numérica de fórmulas exatas (p=3/4; não simulação):** `H_2(p)=0.562335144619`; `p ln2=0.519860385420`; `S_1(A)=1.082195530039`; `S_{Rényi,2}(A)=1.067840630001`; `S_{Rényi,2}(centro)=0.470003629246`. A diferença entre Rényi-2 total e central é `0.597837000756`, **distinta** de `p ln2`. Essa diferença não é fração de bits nem área física.

**Resultado G-U1-2:** **PASS [M]** para restrições de Gauss, espectro e separação Shannon/intrassetor no brinquedo com matéria e ancila; **PENDING [?]** para Hamiltoniano dinâmico U(1), estados eletrônicos vestidos físicos, QED₄, modos soft, fatorização local contínua e ligação a QES/RT. A ancila foi introduzida explicitamente para separar entropia intrassetor; não deve ser confundida com polarização ou fóton.

## 4. G-GAUGE-7 e G-DISTILL-1 — implicações para HRF E71 e JLMS

**[F]** Em teoria gauge, o centro elétrico regional pode codificar fluxo de fronteira e setores que operações locais gauge-invariantes não misturam. A entropia de embedding estendido depende da convenção e pode conter termos não destiláveis; para grupos não abelianos surge ainda termo de representação `Σ_k p_k ln(dim R_k)` (com fatores por corte), que desaparece para irreps de U(1), `dim R_k=1`, mas o Shannon de fluxos pode persistir. Ver [0075,0118–0120].

**[D] G-GAUGE-7:** uma proposta de dicionário `D` deve indicar (a) a álgebra regional escolhida, (b) o centro/fluxo, (c) as cargas físicas e seus dressings, (d) as operações acessíveis e restrições de superseleção, (e) o tipo de entropia `S_1`, `S_2`, refinada ou destilável, e (f) o operador geométrico de área **derivado**, não identificado por nome. PASS para cada objeto isolado não implica PASS da costura.

**[D] G-DISTILL-1:** `f_c=1-ΔS_2(cond)/ΔS_2(complete)` da E71 continua **indicador operacional do modelo**, não fração de entropia destilável, de carga, de energia nem área RT/QES. A E71 reporta Gauss com cargas externas estáticas; não demonstra um setor quântico de pares carregados e dressings. O modelo analítico acima é um controle novo, **não reexecução ou validação da E71**.

**[?] JLMS/RT:** [0036,0112–0115] usam hipóteses de dualidade holográfica e recuperação complementar. A igualdade de entropia relativa em um código finito ou no brinquedo gauge **não** constrói o operador de área gravitacional, o wedge ou a dinâmica de Einstein. Em QED₄, carga assintótica, álgebras regionais e dressings infravermelhos exigem análise adicional; um Wilson string de malha finita não resolve o problema das infrapartículas.

## 5. Frentes negativas, falhas e trabalho não realizado

- **E71 [NOT_FOUND]:** nova busca Google Drive por nome exato `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `E71_resumo.json`, `perfis.json` e prefixo `ELETRON_71_PACOTE` não encontrou ZIP ou JSON bruto; `perfis.json` recupera apenas menções textuais em LEIAME, relatórios e cadernos. Não atribuir aos dados brutos um status de auditado.
- **Sem simulação [NOT_EXECUTED]:** nenhum notebook, código de bancada, solver, evolução temporal ou protocolo E71 foi executado. Os números de G-U1-2 decorrem de logaritmos de autovalores exatos.
- **QED₄ → gravidade dinâmica → massa do elétron [OPEN/NEGATIVE]:** nenhuma das três novas fontes estabelece essa derivação. [0117] contém massa eletrônica como entrada; [0031] Val Baker continua sem auditoria independente. Não declarar prova de inexistência.
- **Reconstrução geométrica G [PENDING]:** a independência dos mapas `Γ/E` e das hipóteses Hadamard [0055,0109–0111], a unicidade/injetividade de reconstruções [0052,0064,0098] e sombras métricas [0101] não foram reavaliadas neste ciclo.
- **QES/HEC além de AdS [PENDING]:** [0066–67,0103–0108] mantêm seus domínios e condições; não extrapolar o cone clássico para toda matéria quântica. O gate editorial G-QES-4 sobre sinais em [0106] permanece aberto à confirmação por errata.
- **Distilação:** o valor `p ln2` exige ancila neutra Bell e LOCC com restrições por cópia. Não extrapolar a qualquer estado de gauge U(1), a todos os protocolos operacionais ou a entropia de vácuo de Maxwell.

## 6. Histórico, preservação e próximo bloco

**[D]** O novo caderno v2.0 deve começar **exatamente** com os 195.534 bytes do caderno v1.9 CP-21 e acrescentar integralmente este checkpoint CP-22, sem alterar nenhum byte histórico. Índice v2.2: linhas 0001–0117 intactas; acrescentar somente 0118–0120, sem cabeçalhos, resumos ou links. Não sobrescrever versões anteriores.

**Próximas leituras prioritárias:** (1) [0118–0120] provas completas da definição de entropia em setores com matéria e limitações LOCC, incluindo tratamento não abeliano; (2) ligação de dressings de carga física/soft sectors [0083–0090] com álgebras regionais; (3) auditoria E71 quando ZIP/JSON aparecerem; (4) `Γ/E` e unicidade métrica, JLMS/QES gravitacional; (5) renormalização QED₄ e frente negativa da massa eletrônica. **Não executar simulações sem autorização.**

## 7. Fontes primárias verificadas neste ciclo

- [0118] Ghosh–Soni–Trivedi: https://arxiv.org/pdf/1501.02593 ; https://doi.org/10.1007/JHEP09(2015)069 .
- [0119] Soni–Trivedi: https://arxiv.org/pdf/1510.07455 ; https://doi.org/10.1007/JHEP01(2016)136 .
- [0120] Van Acoleyen et al.: https://arxiv.org/pdf/1511.04369 ; https://doi.org/10.1103/PhysRevLett.117.131602 .
- Reutilizadas [0075] Casini–Huerta–Rosabal, [0072] e [0080] Donnelly–Wall, [0073] Donnelly–Freidel, [0112–0115] códigos/centros e [0036] JLMS.
- Cap. 0.1 v0.2: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view .
- CP-21 v1.9: https://drive.google.com/file/d/1xlIAWPPDsnXJIxE7B4XB9UrHxFd-xevQ/view .
- Índice CP-21 v2.1: https://drive.google.com/file/d/1WMYgFdTQ4dHfNUtT1YPwyhKcEIceO9ow/view .


---

# HRF — Checkpoint de Pesquisa Bibliográfica CP-23

**Data/hora:** 20/10/2026, 13h02 BRT (America/Sao_Paulo).  
**Tipo:** revisão bibliográfica, auditoria de hipóteses e verificações analíticas; **sem execução de simulações**.  
**Baseline:** CP-22, Caderno cumulativo v2.0 de 208.281 bytes e índice v2.2 de 120 IDs.  
**Novos IDs:** HRF-REF-0121 a HRF-REF-0125; próximo disponível HRF-REF-0126.  
**Método:** RUP B → A; mapas **G** (geometria), **W** (dinâmica), **D** (dicionário) separados; classes [F]/[M]/[H]/[?]/[D].  
**Origem e limites:** não atribuir a um modelo analítico a execução da bancada E71 nem a reconstrução física de um elétron.

## 1. Leituras efetivamente realizadas, em ordem e com proveniência

1. **Capítulo 0.1 v0.2 integral:** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, conteúdo integral das seções 0.1.1–0.1.17, sem versão posterior identificada na busca nominal. Preservados os gates B0–B5, as diferenças entre 2D3V e bulk holográfico, e o veto a promover regulador geométrico ou imagem a ontologia.
2. **Arquivos do Projeto/Library antes da literatura externa:** `HRF_Master_Research_Notebook_B2B_ABJM_STAR_v1_0_PT_2026-10-14.md` (trechos de roteiro/proveniência recuperados), nota de arquitetura boundary 2D/GMF/bulk 3D (trechos recuperados), e documentos anteriores da conversa CP-01–CP-22. Não foi alegada leitura integral dos arquivos de Projeto recuperados apenas por trechos.
3. **Google Drive HRF:** conferidos metadados do caderno CP-22 (ID `1J1dNrZAYRMABMtg54LDAttE3fFLHmwsA`, 208.281 bytes) e índice CP-22 (ID `1S593DIBRPUpgduPJHHjksBdzVoMgTW5G`, 8.836 bytes), ambos no pai `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`. As cópias rematerializadas do Drive foram comparadas com as cópias locais: **bytes idênticos**. Consultada a pasta Physics e feitas buscas pelos dados brutos E71 (ver seção 7).
4. **Literatura externa primária, só após as etapas anteriores:** artigos [0121]–[0125] em arXiv/PDF originais. Os níveis de leitura estão individualizados na seção 2.

**Integridade do baseline incorporado:** SHA-256 do caderno CP-22 = `8c87b8707eec05eaeb0229cd2120add7a0aceb4ad29a4a5c14d8d5330eebad50`; SHA-256 do índice CP-22 = `8b6734de7f86235b6224b8996c828c47367bae14d12d9ee5ed754ccea6667933`. O novo caderno será produzido por concatenação binária do **arquivo CP-22 integral** como prefixo inalterado, seguido deste checkpoint integral; os nomes históricos e todas as falhas/pendências anteriores permanecem literalmente preservados.

## 2. Cinco referências novas — leitura, uso e limites

- **HRF-REF-0121 — Bagan, Lavelle e McMullan, _Charges from Dressed Matter: Construction_** (Annals of Physics 282, 2000; arXiv:hep-ph/9909257v2). **Leitura:** seções 1, 3 e trechos da seção 4, equações (1)–(7), (48)–(62); texto original selecionado, **não prova integral replicada**. **Uso [F, condicional]:** campos carregados fisicamente observáveis exigem dressing eletromagnético não local; a invariância gauge local é necessária, mas insuficiente para escolher um dressing com energia/assíntotas físicas. A string fina de Wilson pode produzir estado de energia singular; o dressing estático de Dirac reproduz campo Coulomb. **Gate:** G-DRESS-2. **Limite:** massa `m` já entra na lagrangiana (eq. 8) e em `E_p=√(p²+m²)`; o artigo não deriva `m_e`.
  Fonte: https://arxiv.org/pdf/hep-ph/9909257 .
- **HRF-REF-0122 — Bagan, Lavelle e McMullan, _Charges from Dressed Matter: Physics and Renormalisation_** (Annals of Physics 282, 2000; arXiv:hep-ph/9909262v2). **Leitura:** resumo, introdução e partes das equações de propagador e renormalização; **afirmações all-orders não rederivadas**. **Uso:** tratamento perturbativo de correladores on-shell de campos vestidos e estrutura de polos sob hipóteses de cálculo; não generalizar automaticamente para setores carregados exatos não perturbativos. **Gate:** G-IR-2. Fonte: https://arxiv.org/pdf/hep-ph/9909262 .
- **HRF-REF-0123 — Bagan, Lavelle e McMullan, _An Infra-Red Finite Electron Propagator_** (Physical Review D 56, 1997; arXiv:hep-th/9602083v2). **Leitura:** seções selecionadas de renormalização, equações (22)–(29), **integrais de loop não recalculadas**. **Uso:** condição on-shell `p²=m²` e contratermo `δm` explicitam a massa física **como condição de renormalização**, não valor numérico emergente calculado sem entrada. **Gate:** G-MASSINPUT-2. Fonte: https://arxiv.org/pdf/hep-th/9602083 .
- **HRF-REF-0124 — Kudler-Flam e Rath, _Large and Small Corrections to the JLMS Formula from Replica Wormholes_** (JHEP 08, 189, 2022; arXiv:2203.11954v3). **Leitura:** introdução, equação (1.4), seções 3.1–3.4 e partes da discussão; **somas de réplicas e provas integrais não replicadas**. **Uso:** JLMS/qJLMS pode receber correções não perturbativas e grandes perto de transições de entanglement wedge; a entropia relativa é sensível a deficiências de suporte. **Domínio:** modelos PSSY/JT e hipóteses semiclassicas, não QED₄ arbitrária. **Gate:** G-JLMS-3. Fonte: https://arxiv.org/pdf/2203.11954 .
- **HRF-REF-0125 — Ilderton, Lavelle e McMullan, _Physical charges in QED and QCD_** (proceedings, arXiv:0910.5395v2, 2009). **Leitura:** seções 2–3, equações (2.2)–(2.7), (3.1)–(3.4) e discussão de estados compactos; **sem replicação integral da solução do problema de contorno**. **Uso:** pares carga–anticarga podem ter dressing de campo distribuído em volume finito e energia finita (excluídas autenergias pontuais usuais), em contraste com string de Wilson infinitamente fina. **Gate:** G-STRING-2. Fonte: https://arxiv.org/pdf/0910.5395 .

**Leituras anteriores reutilizadas sem novo ID:** [0083] Wilson-Gerow/Stamp, [0085] Kulish–Faddeev, [0086] Buchholz, [0087] Mund–Rehren–Schroer, [0088–0090] dressings soft, [0036] JLMS, [0112–0115] códigos algébricos, [0118–0120] centros gauge. **Não se atribui nova leitura integral a esses trabalhos neste ciclo.**

## 3. G-DRESS-2 — verificação independente da transformação gauge do dressing de Dirac

**Objeto e condições [F/M]:** em uma fatia espacial de `R³`, para transformações gauge pequenas `α(x)` que decaem suficientemente no infinito, adotar as convenções `A_i → A_i + ∂_i α` e `ψ → exp(iqα) ψ`. Definir `χ[A]=∇⁻² ∂_i A_i`, com Green de Laplace e condição de contorno fixada, e `Ψ_D(x)=exp[-iqχ[A](x)] ψ(x)`.

Pela linearidade e `∇⁻²∇² α=α` **apenas no domínio das condições de contorno escolhidas**,

`χ[A+∇α] = χ[A] + α`;

`Ψ_D' = exp[-iq(χ+α)] exp(iqα) ψ = Ψ_D`.

**PASS [M]** para a identidade algébrica de invariância sob transformações locais pequenas; **PENDING [?]** para completude dinâmica, estado físico normalizável, espectro de massa, IR infinito e representação Hilbert. **Não** é operador estritamente localizado: `∇⁻²` integra dados espaciais não locais. Uma transformação global constante pode agir com fase de carga: a neutralidade sob gauge redundante local não significa neutralidade sob simetria global de carga.

**Gate de contorno:** em uma caixa periódica sem fundo neutralizante, `Σ_i (div E)_i=0` por cancelamento de fluxos internos, logo `Q_total=0`. Além disso, `∇²` tem modo zero e `∇⁻²` requer projeção para o subespaço de média zero. **FAIL [M]** para introduzir um elétron isolado com carga total não nula em uma caixa periódica neutra sem condição de contorno ou fonte compensadora. **PASS [M]** para par de cargas opostas da CP-22. Esta checagem não é uma simulação nem um modelo contínuo completo de QED₄.

## 4. G-STRING-2 — energia de fluxo confinado e contraste Coulomb/linha de Wilson

**Verificação analítica [M]:** considerar tubo de comprimento `L`, seção transversal constante `A>0` e fluxo elétrico `q` em cada seção. Cauchy–Schwarz fornece

`(∫_A E_∥ dA)² ≤ A ∫_A E_∥² dA`.

Com `∫_A E_∥ dA=q` e energia eletrostática `U_E=(1/2)∫d³x |E|²` em unidades de Heaviside–Lorentz, segue

`U_E ≥ (1/2)∫_0^L ds q²/A = q² L/(2A)`.

Portanto, no limite de uma string de espessura transversal nula `A→0`, a energia diverge para `q≠0` e `L>0`. **PASS [M]** como limite inferior de um tubo com fluxo fixo, não como derivação integral da energia de um operador Wilson em QED quântica.

Em contraste, para campo Coulomb radial `|E(r)|=|q|/(4πr²)` fora de um raio `R>0`,

`U_E(r≥R)=(1/2)∫_R^∞4πr²[q²/(16π²r⁴)]dr = q²/(8πR)`.

A contribuição **IR** do campo Coulomb é finita para `R>0`; o limite pontual **UV** `R→0` diverge e demanda regularização/renormalização. **Não** calcular `m_e` pela expressão sem escala física independente e prescrição UV. O estado compactamente vestido [0125] fornece alternativa física ao fio infinitamente fino; a escolha de volume/condições de contorno não pode ser omitida. **G-STRING-2: PASS analítico condicionado, PENDING dinâmica e estado quântico.**

## 5. G-IR-2, G-JLMS-3 e G-MASSINPUT-2 — tensões e controles negativos

### 5.1. Dressings com polos versus infrapartículas

**[?] Tensão explícita:** [0121–0123] descrevem polos e interpretação de partícula para certos correladores vestidos em tratamento perturbativo e condições on-shell; [0086] Buchholz demonstra, **sob hipóteses de Gauss/fluxo assintótico em representação física**, ausência de autovetor de massa nítida no setor carregado; [0087] trata nuvens de fótons e modelos intermediários. Não concluir nem compatibilidade automática nem refutação de qualquer resultado. É necessário confrontar: representação física, IR cutoff e sua remoção, suporte espectral exato, limites `t→∞`, campo vestido e domínio perturbativo. **G-IR-2 = PENDING**, não há resolução universal da tensão.

### 5.2. Estabilidade de JLMS sob aproximação

**[F]** A identidade JLMS de códigos exatos [0036,0113] requer hipóteses de recuperação; [0124] identifica correções em cenários de gravidade JT/replica wormholes. **Controle independente [M]:** para distribuições binárias `p=(1−ε,ε)` e `q=(1,0)`, com `0<ε<1`, a distância de variação total é `TV(p,q)=ε`, mas

`D(p||q)=+∞` (pois `q₂=0<p₂`), ao passo que `D(q||p)=−ln(1−ε)<∞`.

Assim, **proximidade em distância de traço/variação total não controla uniformemente entropia relativa** sem condições adicionais de suporte e espectro. Esse é um exemplo clássico exato, não reprodução das integrais de wormholes. **G-JLMS-3 = PASS algébrico para sensibilidade de suporte; PENDING transferência para geometria HRF**. A expressão qJLMS da eq. (1.4) de [0124] usa superfícies extremas e operador de área **assumidos no modelo gravitacional**, não gerados por gauge U(1) de malha.

### 5.3. Massa do elétron continua parâmetro de entrada

**[F, condicional]** [0121] eq. (8) contém `−m ψ̄ψ` e a dispersão `E_p=√(p²+m²)`; [0123] eqs. (28)–(29) escolhem explicitamente `p²=m²` e fixam `δm` por condição de polo. **G-MASSINPUT-2 = FAIL** como derivação independente de `m_e`, **sem** negar utilidade das técnicas de dressing/renormalização. A autenergia clássica de Coulomb com cutoff `R` tampouco prediz `R` ou `m_e` sem física UV adicional.

## 6. G-REF-DUP-1 — auditoria histórica do índice imutável

**[M]** O índice CP-22 contém 120 IDs, mas pelo menos quatro pares têm títulos normalizados idênticos:

- `HRF-REF-0046` e `HRF-REF-0098`: _Bulk metric reconstruction from entanglement data via minimal surface area variations_;
- `HRF-REF-0074` e `HRF-REF-0120`: _Entanglement of Distillation for Lattice Gauge Theories_;
- `HRF-REF-0077` e `HRF-REF-0119`: _Aspects of entanglement entropy for gauge theories_;
- `HRF-REF-0078` e `HRF-REF-0112`: _The Ryu-Takayanagi Formula from Quantum Error Correction_ (variação tipográfica no traço).

**[D] NÃO renumerar, remover nem sobrescrever.** Todos os 120 IDs históricos permanecem imutáveis. O índice v2.3 terá **125 IDs**, mas não deve ser apresentado como 125 trabalhos bibliográficos distintos: no critério literal de títulos normalizados, são **121 títulos distintos** (125 menos quatro duplicatas). A validação de metadados bibliográficos de todos os pares continua **PENDING**, embora os títulos coincidam. Nas futuras leituras, verificar antes de alocar novo ID.

## 7. E71, lacunas, frentes negativas e execução

- **E71 [NOT_FOUND]:** buscas no Drive por `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `E71_resumo.json` e `perfis.json` não localizaram o ZIP/JSON bruto. A busca `perfis.json` encontrou apenas referências textuais em LEIAME, relatório e checkpoints. O protocolo e relatório E71 permanecem documentação indireta; **dados brutos não auditados**.
- **Sem execução [NOT_EXECUTED]:** nenhuma simulação, código de bancada, notebook, solver, E71, B0–B5 ou experimento foi executado. Verificações foram identidades algébricas, desigualdade Cauchy–Schwarz e comparação de arquivos.
- **[?] Dicionário HRF:** dressing Coulomb ou compacto não é por si operador de área gravitacional, QES, RT/HRT, nem demonstra dicionário boundary↔bulk. `f_c` E71 continua Rényi-2 operacional, não fração de emaranhamento destilável.
- **[?] Geometria:** Γ/E e Hadamard [0055,0109–0111], unicidade métrica [0052,0064,0098], regiões cegas [0101] e resultados covariantes condicionais [0066–67,0103–0108] continuam PENDING, não auditados integralmente neste ciclo.
- **[?] Gravitação/massa:** QED₄→gravidade dinâmica→`m_e c²≈511 keV` permanece não demonstrada; não declarar inexistência universal. [0031] Val Baker ainda não foi reexecutado independentemente.
- **[?] IR/soft:** o confronto técnico de [0121–0123] com [0086–0087] e a independência da escolha de dressing permanecem abertos. Nenhum resultado novo sobre spin 1/2, estatística fermiônica ou massa foi obtido.

## 8. Próximo bloco proposto — sem autorização implícita para simular

1. Comparar formalmente [0121–0123] com [0086–0087] em condições de Hilbert, infrapartículas e limites IR; distinguir estados de par compacto [0125] de carga isolada em espaço aberto.
2. Construir gate analítico de **álgebra regional gauge** para estados vestidos e fluxo de fronteira, especificando observáveis, contornos e operações permitidas, antes de propor mapa D para QES/JLMS.
3. Auditar equações de correção de JLMS [0124] e condições de recuperação aproximada; não confundir distância de traço com controle de entropia relativa sem suporte.
4. Repetir busca pelo pacote E71 e verificar sua integridade se aparecer; não executar simulações sem autorização.
5. Retomar Takeda/Sugiura–Takeda, Tjoa–Gray Γ/E, e derivação da massa eletrônica sem inserção do parâmetro, preservando frentes negativas.

**Conclusão [D]:** RUP B→A preservada. **G** ganhou controles analíticos de contorno/entropia; **W** não foi testado; **D** permanece PENDING. A nova documentação não altera classificações históricas nem reivindica holografia física ou elétron emergente.


---

# HRF — Checkpoint de Pesquisa Bibliográfica CP-24

**Data/hora:** 21/10/2026, 01h06 BRT (America/Sao_Paulo).  
**Natureza:** pesquisa bibliográfica, auditoria de pressupostos e provas algébricas pequenas; **nenhuma simulação ou bancada executada**.  
**Baseline preservado:** CP-23, caderno cumulativo v2.1 de 223.618 bytes, índice v2.3 com 125 IDs.  
**Novos IDs imutáveis:** HRF-REF-0126 a HRF-REF-0129. Próximo: HRF-REF-0130.  
**Estratégia:** RUP B → A; classes [F]/[M]/[H]/[?]/[D]; mapas G (geometria), W (dinâmica) e D (dicionário) **não intercambiáveis**.

## 1. Proveniência e ordem efetiva de leitura

1. **Capítulo 0.1 v0.2 integral, PRIMEIRO:** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`. Foram consultadas integralmente as seções 0.1.1–0.1.17 (27.751 caracteres de texto retornado). Busca nominal posterior encontrou duas cópias v0.2, nenhuma v0.3 ou versão mais recente. A metodologia mantém a classificação epistêmica, a distinção entre malha-regulador e ontologia, os gates B0–B5 e o veto à identificação de W com G ou D.
2. **Arquivos de Projeto/conversa:** `files__search` e `files__list` da conversa/Library localizaram versões históricas do caderno e registros HRF, inclusive CP-23. A consulta ao texto completo de CP-23 e do índice CP-23 ocorreu a partir das cópias Markdown disponíveis no ambiente, com confronto de tamanho e conteúdo com o Drive. Arquivos como `HRF_B23R2_Relatorio_e_Auditoria_PT_2026-10-20_0750-clau.md` apareceram na busca, mas **não** foram lidos integralmente nem usados como evidência para o gate IR.
3. **Google Drive HRF:** cópia CP-23 v2.1 ID `1xAJqLA9z4GOvg-DmSsQc1JFEmoNv1os9`, 223.618 bytes, pai `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`; índice CP-23 v2.3 ID `1w1gJQLh6fmA8ccDWtQobRXAoLIa8lLUR`, 125 linhas e 9.158 bytes, mesmo pai. A busca pelo pacote E71 foi repetida. Não se executou código de bancada.
4. **Literatura externa primária, depois das fontes internas:** PDFs originais de [0127]–[0129] lidos em seções selecionadas; [0126] consultado via resumo bibliográfico do artigo original em INSPIRE e registro de PDF CERN, cuja página PDF bloqueou acesso por proteção automatizada. Os níveis de leitura são discriminados a seguir.

## 2. Quatro novas referências — nível de leitura e emprego controlado

**HRF-REF-0126 — Fröhlich, Morchio e Strocchi, _Charged Sectors and Scattering States in Quantum Electrodynamics_ (Annals of Physics 119, 1979).**  
**Leitura:** metadados e **resumo do artigo original** em INSPIRE; PDF original do CERN encontrado, mas o acesso automatizado retornou bloqueio Anubis. **Não** houve leitura das demonstrações nem validação independente.  
**Uso [F, condicionado às hipóteses dos autores]:** em QED₄, estados com carga podem exigir representações não-Fock dos campos assintóticos, com questões de invariância de boosts e noção de massa de infrapartículas. O resumo distingue uma definição não ambígua de massa da existência de autovetor de massa.  
**Gate:** G-IR-3 e G-MASSTHRESH-1. **Limite:** não demonstra que um propagador perturbativo vestido de [0121–0123] possua polo isolado na representação física sem corte IR, nem deriva o valor de m_e.  
Fonte: https://inspirehep.net/literature/132032 ; original CERN: https://cds.cern.ch/record/133273/files/197811013.pdf .

**HRF-REF-0127 — Buchholz e Roberts, _New Light on Infrared Problems: Sectors, Statistics, Symmetries and Spectrum_ (Communications in Mathematical Physics 330, 2014; arXiv:1304.2794).**  
**Leitura:** PDF original, introdução, seções 2–4, definição de classe de carga em A(V), critério de cargas simples, teorema de estatística nas seções 4–5; **leitura de seções, sem replicação integral dos lemas**.  
**Uso [F, condicional]:** ao restringir observáveis a um cone de luz futuro V, setores globais distinguíveis por diferentes nuvens IR podem pertencer à mesma **classe de carga**; para cargas simples e axiomas de dualidade/localização, obtêm-se estruturas de conjugação e estatística Bose/Fermi.  
**Gate:** G-CHARGECLASS-1. **Limite:** a classe de carga não é uma partição finita de fluxo de uma malha nem uma identificação de massa/spin do elétron HRF. As hipóteses de álgebra local e cone de luz não são satisfeitas por mera triangulação Delaunay.  
Fonte: https://arxiv.org/pdf/1304.2794 ; https://arxiv.org/abs/1304.2794 .

**HRF-REF-0128 — Duch e Dybalski, _Infrared problem in quantum electrodynamics_ (2023; arXiv:2307.06114).**  
**Leitura:** PDF original, seções 1, 2.2, 3.1–3.2 e 4.1, inclusive equações (1.1), (2.4), (3.1)–(3.3), (4.1), e conclusão; **não** reprodução dos resultados de espalhamento. É revisão técnica dos autores, não prova inédita universal da QED₄.  
**Uso [F/?, domínios separados]:** distingue QED relativística algébrica, QED não relativística com cutoff UV e número fixo de partículas, e QED perturbativa. A eq. (1.1) contém explicitamente `m`; a eq. (4.1) exibe, formalmente após ressoma perturbativa, singularidade de tipo ramo em vez de polo livre. No modelo não relativístico, H(p) pode não ter estado fundamental para momento não nulo no setor carregado; as provas têm hipóteses de modelo.  
**Gate:** G-IR-3 e G-MASSINPUT-3. **Limite:** não transferir teorema do modelo NR a toda QED₄; não confundir expressão perturbativa com medida espectral exata.  
Fonte: https://arxiv.org/pdf/2307.06114 ; https://arxiv.org/abs/2307.06114 .

**HRF-REF-0129 — Morchio e Strocchi, _Charge density and electric charge in quantum electrodynamics_ (2003; arXiv:hep-th/0301111).**  
**Leitura:** PDF original, introdução, seções 2–4, Proposições 3.1 e 3.2 e discussão de smearing; **provas completas não replicadas**.  
**Uso [F, condicionado]:** operadores de carga definidos por limites de densidades locais dependem de domínio, topologia e suavização temporal; na QED física, o limite sobre estados carregados não precisa coincidir com o limite sobre estados locais. A regularização temporal é relevante para controlar polarização de vácuo.  
**Gate:** G-CHARGEDOMAIN-1. **Limite:** um `Q=Σ_i Q_i` em rede finita não demonstra convergência de operadores de carga no contínuo nem seleciona representação física.  
Fonte: https://arxiv.org/pdf/hep-th/0301111 ; https://arxiv.org/abs/hep-th/0301111 .

**Reutilização sem novo ID:** [0085] Kulish–Faddeev; [0086] Buchholz 1986; [0087] Mund–Rehren–Schroer; [0088–0090] dressing soft; [0121–0123] Bagan–Lavelle–McMullan; [0125] pares compactos; [0118–0120] centros gauge; [0036,0113,0124] JLMS. Nenhum desses recebeu alegação de nova prova integral nesta rodada.

## 3. G-IR-3 — verificação analítica de nuvens soft e corte infravermelho

**[M] Modelo matemático, não simulação de QED:** representar perfis coerentes infravermelhos na região `λ<|k|<κ`, `0<λ<κ`, por

`f_a(k,Ω)=h_a(Ω)/|k|^{3/2}` e `f_b(k,Ω)=h_b(Ω)/|k|^{3/2}`,

onde `h_a,h_b∈L²(S²)` e `C=∫_{S²}|h_a(Ω)-h_b(Ω)|²dΩ`. Usando a medida de momento tridimensional `d³k=|k|²d|k|dΩ`, tem-se a identidade exata

`||f_a-f_b||² = C ∫_λ^κ (dk/k) = C ln(κ/λ)`.

Para estados coerentes normalizados na mesma representação Fock **com λ>0**, o módulo do produto interno é

`|⟨f_a|f_b⟩|=exp[-||f_a-f_b||²/2]=(λ/κ)^{C/2}`.

Se `C>0`, `lim_{λ→0}|⟨f_a|f_b⟩|=0`. Se `C=0`, o módulo permanece 1. Esta é uma verificação de ortogonalidade IR **no modelo de coerentes com perfil k^{-3/2}**, não prova de que todo dressing físico de QED possua exatamente esse perfil nem prova independente do teorema de Buchholz. Para cada λ>0 os estados pertencem à Fock regularizada; o limite λ→0 não fornece automaticamente vetor normalizável na mesma representação. A energia soft correspondente tem integrando `|k| |f|² d³k ∼ dk`, logo pode permanecer finita enquanto o número de fótons `∫|f|²d³k∼ln(κ/λ)` diverge: infinito número soft ≠ infinito de energia soft.

**Resultado:** **G-IR-3 PASS [M]** para integrais radial, sobreposição coerente e divergência logarítmica de número; **PENDING [?]** para reconstrução física do estado eletrônico, escolha de h(Ω), limites de espalhamento, Hamiltoniano e equivalência com dressings [0121–0123]. **Não há simulação.**

## 4. G-CHARGECLASS-1 — carga total não determina perfil angular nem classe global

**[M] Controle cinemático:** para fluxo assintótico `φ(n)=lim_{r→∞} r² n·E(rn)` com integral angular de Gauss `Q=∫_{S²}φ(n)dΩ`, considere

`φ_+(θ)=Q/(4π)+a cosθ` e `φ_-(θ)=Q/(4π)-a cosθ`.

Como `∫_{S²}cosθ dΩ=0`, segue `∫φ_+dΩ=∫φ_-dΩ=Q`, mas `φ_+≠φ_-` para `a≠0`. **Apenas igualdade de carga global não fixa os dados angulares de campo assintótico.** O exemplo é cinemático; não certifica que ambos os perfis sejam realizáveis como estados físicos assintóticos em qualquer representação de QED.

**[F, condicionado]:** [0127] mostra que a distinção entre setores IR globais e **classes de carga em A(V)** depende da álgebra de observáveis acessível no cone futuro. Isso não equivale a apagar dados físicos arbitrariamente: é uma equivalência operacional sob restrição de observáveis e axiomas específicos. **G-CHARGECLASS-1 PASS [M]** para integral angular, **PENDING [?]** para construir A(V) e a classe de carga a partir dos graus de liberdade HRF.

## 5. G-MASSTHRESH-1 — limiar de massa sem autovetor de massa

**[M] Controle espectral abstrato:** escolha `m²>0`, `0<η<1` e medida contínua positiva

`dμ(s)=C Θ(s-m²)(s-m²)^{η-1}ds`, para `s` em uma janela finita acima de `m²` e `C>0`.

O suporte tem limiar inferior `s=m²`, mas `μ({m²})=0` porque não há átomo `δ(s-m²)`. Com `δ>0`,

`μ([m²,m²+δ])=C δ^η/η → 0` quando `δ→0`.

Logo, **um limiar espectral bem definido pode coexistir com ausência de estado próprio de massa**. Isso fornece um controle conceitual da compatibilidade entre a frase de [0126] sobre uma definição de massa de infrapartícula e a proibição de autovetor de massa nítida em [0086], **sem provar que ambas as construções utilizam o mesmo operador, domínio e representação**. A eq. (4.1) de [0128] motiva uma singularidade de ramo, mas não demonstra que a medida abstrata acima seja o espectro exato da QED₄. **G-MASSTHRESH-1 PASS [M]**, aplicação física **PENDING [?]**.

## 6. G-CHARGEDOMAIN-1 e G-MASSINPUT-3 — limites adicionais

**[F, condicionado] G-CHARGEDOMAIN-1:** [0129] discute que operadores locais de carga `Q_{R,T}=j^0(f_R α_T)` requerem domínio e escala de smearing temporal adequados para limites fortes; as Proposições 3.1/3.2 não podem ser substituídas por somatório discreto em caixa periódica. O zero de Gauss em um domínio denso de estados locais não determina sozinho o limite sobre estados carregados não locais. **PENDING** prova de convergência e construção de estados físicos do HRF.

**[F] G-MASSINPUT-3:** [0128] eq. (1.1) contém explicitamente `−m ψ̄ψ`; o Hamiltoniano não relativístico eqs. (3.1)/(3.3) contém `1/(2m)`. Logo esse trabalho **não** deriva `m_e` sem parâmetro de massa, mesmo ao fornecer técnicas importantes para espalhamento IR. **FAIL como derivação independente de m_e**, não como revisão do IR.

**[D] Dicionário mínimo a pré-registrar antes de alegar elétron físico:** (i) álgebra de observáveis e região/cone, (ii) espaço de Hilbert/representação e topologia, (iii) carga total e fluxo angular assintótico, (iv) dressing longitudinal Coulomb versus nuvem soft transversal/velocidade, (v) Hamiltoniano e estado assintótico, (vi) cutoff IR e seu limite, (vii) espectro/limiar e existência ou não de autovetor, (viii) renormalização UV e parâmetro m, (ix) comparabilidade de S1/S2 e centros, (x) se houver holografia, um **dicionário D e área gravitacional derivados**. Nenhum item pode ser promovido a PASS por semelhança verbal.

## 7. E71, gates abertos, frentes negativas e status de execução

- **E71 [NOT_FOUND]:** repetidas buscas no Google Drive por `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `PACOTE_EXECUCAO_2026-10-14`, `E71_resumo`, `perfis.json`, `HRF_ELETRON_71` e filtro `name contains 'E71' and mimeType='application/zip'`. Encontrados relatório, protocolo, LEIAME e menções em checkpoints; **não** encontrados o ZIP original nem `E71_resumo.json` e `perfis.json` como arquivos brutos. Não alegar auditoria de dados ausentes.
- **Nenhuma execução [NOT_EXECUTED]:** não foram rodados E71, B0–B5, solver, notebook, propagação, dinâmica quântica ou simulação. Apenas leitura, identidades integrais e manipulação documental. **Sem autorização implícita para executar testes.**
- **G/Geometria [?]:** Γ/E, Hadamard [0055,0109–0111], unicidade/injetividade [0052,0064,0098], sombras [0101] e condições de teoremas covariantes [0066–67,0103–0108] não reavaliados neste ciclo; manter PENDING.
- **D/QES-JLMS [?]:** centros gauge U(1) [0118–0120], operador de área central [0112–0115] e correções aproximadas [0124] não implicam automaticamente equivalência física. `f_c` E71 permanece Rényi-2 operacional, não fração de bit, emaranhamento destilável ou área.
- **G-IR-2 [?]:** a tensão entre polos perturbativos vestidos [0121–0123] e infrapartículas [0086,0126–0128] foi **esclarecida conceitualmente**, mas **não resolvida rigorosamente**. Fock com cutoff e representação física IR são objetos diferentes; massa como limiar não é massa como autovetor. Exigir confronto de estados, operadores e limites para resolver.
- **QED₄→gravidade dinâmica→m_e [OPEN/NEGATIVE]:** nenhuma fonte examinada neste ciclo fornece derivação completa e validada. Isso não é prova de inexistência universal. Val Baker [0031] segue sem reexecução independente; não reivindicar spin 1/2, estatística fermiônica ou massa de repouso a partir dos controles.
- **[D] Integridade bibliográfica:** manter IDs 0001–0125 intactos, inclusive pares históricos duplicados [0046/0098], [0074/0120], [0077/0119], [0078/0112]. A nova versão terá 129 IDs, não necessariamente 129 trabalhos únicos. Índice slim com somente `HRF-REF-#### -> título`, sem comentários.

## 8. Próximas prioridades — sem simulações

1. Confrontar com maior profundidade as provas de Buchholz [0086], a construção de classes [0127] e os limites IR de Bagan [0121–0123], explicitando o que muda de representação.
2. Estudar dressings com fluxos assintóticos não triviais, álgebra regional e limites de entropia em QED relativística, sem equiparar S2 a emaranhamento destilável.
3. Buscar E71 ZIP/JSON bruto por proveniência, incluindo possíveis pastas de execução externas à Physics; não executar o pacote sem autorização.
4. Retomar JLMS exato/aproximado, Γ/E e Hadamard, unicidade métrica e gates G/W/D, mantendo o trabalho negativo de massa eletrônica e Val Baker.
5. Auditoria futura de títulos duplicados sem apagar ou renumerar registros históricos.

**Síntese:** há avanço em controle de **representação IR**, **classe de carga** e **limiar de massa**, não em derivação de elétron, massa, gravitação ou dualidade física. `G-IR-3`, `G-CHARGECLASS-1` e `G-MASSTHRESH-1` recebem PASS somente para seus controles matemáticos; as costuras físicas permanecem PENDING.

## 9. Fontes consultadas e estado da leitura

- Capítulo 0.1 v0.2 (integral): https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view .
- Baseline CP-23 cumulativo v2.1 (integral, 223.618 bytes): https://drive.google.com/file/d/1xAJqLA9z4GOvg-DmSsQc1JFEmoNv1os9/view .
- Baseline índice CP-23 v2.3 (integral, 125 linhas): https://drive.google.com/file/d/1w1gJQLh6fmA8ccDWtQobRXAoLIa8lLUR/view .
- [0126] Fröhlich–Morchio–Strocchi (resumo/metadados, PDF CERN bloqueado): https://inspirehep.net/literature/132032 .
- [0127] Buchholz–Roberts (seções selecionadas do PDF): https://arxiv.org/pdf/1304.2794 .
- [0128] Duch–Dybalski (seções selecionadas do PDF): https://arxiv.org/pdf/2307.06114 .
- [0129] Morchio–Strocchi (seções selecionadas do PDF): https://arxiv.org/pdf/hep-th/0301111 .


# HRF — Checkpoint de Pesquisa Bibliográfica CP-25

**Data/hora:** 21 de outubro de 2026, 13h04 BRT (America/Sao_Paulo).  
**Programa:** Holographic Reconstruction Framework — HRF; Research Book Cap. 0.1 v0.2.  
**Status:** [D] auditoria bibliográfica, leitura de seções primárias e álgebra independente; **NENHUMA SIMULAÇÃO HRF EXECUTADA**.  
**Continuidade:** CP-24, caderno cumulativo v2.2 (240.005 bytes; SHA-256 `1fdd0a62abcbce5b6c8600e57fb97574a3b554e1dc2af90eef4a6ede08dd80b4`), índice v2.4 (129 IDs).  
**Princípio:** RUP **B → A**, preservar [F]/[M]/[H]/[?]/[D], separar mapas G/W/D e distinguir *abstract*, *seções selecionadas do texto integral*, *álgebra independentemente conferida* e *prova integral replicada*.

## 1. Ordem documental, escopo e método

1. **Capítulo 0.1 v0.2 lido integralmente** via Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, incluindo §§0.1.12–0.1.17. Busca por versão superior não identificou substituição explicitamente adotada. Preservar decisões [D] sem promover observáveis de E71 a partículas ou dualidade.
2. Consultados os arquivos de conversa/Projeto recuperáveis por Files e a base cumulativa local de CP-24, conferida por comprimento e SHA-256; as 129 linhas do índice foram validadas. Em seguida, conferidos no Drive os metadados da base e a pasta de destino `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`.
3. **Literatura primária:** PDFs originais arXiv de Hirai–Sugishita 2020/2021, Carney et al. 2017, Prabhu–Satishchandran–Wald 2022 e Gómez–Letschka–Zell 2018/2019; inspeção de seções indicadas abaixo, **não** de todas as provas integrais. [0088], [0089], [0090], [0085], [0086], [0121–0129] reutilizados sem renumeração.
4. Frente específica: **D** (definição de subsistemas/observáveis e dicionário entre estados carregados, dressing e entropia); **W** (espalhamento assintótico conhecido, não evolução HRF); **G** (nenhuma métrica reconstruída). Os controles abaixo são [M] algébricos e não validam o dicionário holográfico.

## 2. Novas referências normalizadas e níveis de leitura

**HRF-REF-0130 — Hirai e Sugishita, _IR finite S-matrix by gauge invariant dressed states_ (JHEP 02 (2021) 025; arXiv:2009.11716).**  
**Leitura:** PDF original v2, introdução, §§2.4–2.6 e §3, conclusões; não foi reproduzida integralmente a demonstração BRST nem o cálculo da matriz S.  
**[F, domínio]** No **modelo exatamente solúvel de correntes externas**, dressing de Kulish–Faddeev isolado não assegura as condições de simetria assintótica nem elimina todos os fatores IR no esquema do artigo. É necessária uma contribuição adicional de deslocamento transversal/coerente associada a cargas assintóticas. Em §3, os autores **argumentam a extensão à QED completa usando a universalidade soft**; não apresentam cálculo completo não perturbativo da matriz S física da QED. **G-IR-DRESS-4 = PASS para distinção do modelo; PENDING para prova física geral.**  
Fonte primária: https://arxiv.org/pdf/2009.11716 ; https://arxiv.org/abs/2009.11716 .

**HRF-REF-0131 — Carney, Chaurette, Neuenfeld e Semenoff, _Infrared quantum information_ (Phys. Rev. Lett. 119 (2017) 180502; arXiv:1706.03782).**  
**Leitura:** PDF original de cinco páginas, eqs. (1)–(4), (11), (18) e discussão da matriz reduzida; álgebra do artigo não reproduzida integralmente.  
**[F, domínio]** No formalismo inclusivo com radiação soft não observada, traçar os bósons abaixo de uma resolução operacional pode suprimir coerências entre saídas com correntes angulares distintas; o trabalho calcula entropia hard/soft IR-finita no regime de fatorização/resummation considerado. **Não** diz que toda definição de subsistema ou todo estado vestido produz a mesma decoerência. **G-SOFTTRACE-1.**  
Fonte: https://arxiv.org/pdf/1706.03782 ; https://doi.org/10.1103/PhysRevLett.119.180502 .

**HRF-REF-0132 — Prabhu, Satishchandran e Wald, _Infrared Finite Scattering Theory in Quantum Field Theory and Quantum Gravity_ (2022; arXiv:2203.14334).**  
**Leitura:** PDF original, resumo, introdução, sumário de §§4–8, hipóteses de matéria massiva versus não massiva e conclusões; **não** foram auditadas integralmente as demonstrações de inexistência de autovetores BMS.  
**[F, condicionado]** Distinguem QED com campo escalar **massivo** (em que representações com memória podem ser construídas) de QED com campo escalar carregado **sem massa**, cujo dressing de FK pode ter fluxo de energia divergente por colinearidade. Em gravidade quântica perturbativa/assintótica estudam obstruções mais severas à construção de espaços FK com autovetores de supertranslações; **não** provam que a gravidade emerge da QED nem derivam a massa do elétron. A lagrangiana escalar massiva de §4 contém explicitamente `m²`. **G-FK-DOMAIN-1.**  
Fonte: https://arxiv.org/pdf/2203.14334 ; https://arxiv.org/abs/2203.14334 .

**HRF-REF-0133 — Gómez, Letschka e Zell, _The Scales of the Infrared_ (JHEP 09 (2018) 115; arXiv:1807.07079).**  
**Leitura:** PDF original, resumo, §§2, 4.1–4.3, especialmente eqs. (53)–(54); **sem** reprodução completa do cálculo de espalhamento.  
**[F, condicionado]** O artigo diferencia escala do dressing assintótico `r` da resolução de radiação não detectada `ε` (aqui escrita `epsilon`), e propõe traçar **radiação não observada, não o dressing necessário à definição do estado assintótico**. A matriz reduzida conserva, em regimes especificados, termos fora da diagonal, em contraste com a conclusão de decoerência completa obtida sob outro procedimento de trace e limites. Isso **não refuta** [0131]: os protocolos de redução e as escalas são distintos. **G-SOFTTRACE-2.**  
Fonte: https://arxiv.org/pdf/1807.07079 ; https://arxiv.org/abs/1807.07079 .

**Normalização:** [0088] _Dressed infrared quantum information_ ≠ [0131] _Infrared quantum information_; [0089] _Dressed states from gauge invariance_ ≠ [0130] _IR finite S-matrix by gauge invariant dressed states_. Nenhum ID novo atribuído a obra de título já registrado. Mantidos os quatro pares duplicados históricos [0046/0098], [0074/0120], [0077/0119], [0078/0112].

## 3. G-SOFTTRACE-3 — modelo analítico de dois ramos: overlap, entropia e definição de subsistema

**[M] Controle algébrico sem simulação:** seja `|a>`, `|b>` ortonormais no setor hard e `|f_a>`, `|f_b>` coerentes normalizados no setor soft, com `c=<f_b|f_a>` (fase ajustável), e estado global puro

`|Ψ> = sqrt(p)|a>⊗|f_a> + sqrt(1-p)|b>⊗|f_b>`, com `0<p<1`.

Se **e somente se** a bipartição hard⊗soft for a definição operacional adotada e os estados coerentes pertencerem à mesma representação com regulador IR positivo, o traço soft dá

`ρ_hard = [[p, sqrt(p(1-p)) c], [sqrt(p(1-p)) c*, 1-p]]`.

Os autovalores são

`λ_± = (1 ± sqrt(1-4p(1-p)(1-|c|²)))/2`,

com `S1(ρ_hard) = -Σ λ_± ln λ_±`, `S2(ρ_hard)=-ln(λ_+²+λ_-²)` e `Tr(ρ_hard²)=1-2p(1-p)(1-|c|²)`. Para `c=1`, o estado hard é puro, `S1=S2=0`; para `c→0`, o estado hard diagonaliza, `S1→H(p)` e `S2→-ln[p²+(1-p)²]`. Esses limites são identidades exatas do modelo.

Usando apenas o **perfil ilustrativo** do CP-24 `|c|=(λ_IR/κ)^(C/2)` com `C=0.2`, `λ_IR/κ=10^-6`, `p=0.75`, resulta:

- `|c|=0.251188643151`, `|c|²=0.063095734448`;
- `spec(ρ_hard)=(0.772636113178, 0.227363886822)`;
- `S1=0.536071424376`, `S2=0.432845194330`, `Tr(ρ²)=0.648660900418`;
- limite `c→0`: `H(0.75)=0.562335144619` e `S2→-ln(0.75²+0.25²)=0.470003629246`.

**Interpretação restrita:** a supressão da coerência ao traçar o fator soft é **dependente da bipartição**. O formalismo de [0133] trata dressing como parte constitutiva dos estados assintóticos e traça radiação adicional, portanto **não se pode identificar automaticamente** o `c` deste modelo com o fator de decoerência físico de [0133], nem comparar numericamente seus `S1/S2` com `f_c` da E71. O limite `λ_IR→0` pode mudar de representação e inviabilizar a fatorização Fock ingênua. **G-SOFTTRACE-3 PASS [M] para diagonalização, entropias e limites; PENDING [?] para QED física.**

## 4. G-IR-DRESS-4, G-FK-DOMAIN-1 — condições de contorno e extrapolação controlada

- **[F] [0130]** identifica no modelo de correntes externas a necessidade de um dressing coerente adicional para satisfazer condições de carga assintótica e remover divergências do seu `S`. **[?]** Sua §3 argumenta a universalidade da estrutura soft para QED completa, mas declara cálculo explícito completo futuro; não elevar argumento perturbativo a teorema geral.
- **[F] [0132]** separa rigorosamente *massive charged scalar QED*, *massless charged scalar QED* e *vacuum gravitational asymptotic algebra*. O problema colinear de cargas **sem massa** não é automaticamente problema do elétron físico massivo. A obstrução de supertranslações gravitacionais não é derivação da dinâmica de Einstein a partir de estados soft da QED.
- **[?]** A tensão de CP-24 `G-IR-2` (polo perturbativo de campos vestidos [0121–0123] versus teorema de infrapartícula [0086]) continua **PENDING**: é preciso identificar a mesma álgebra física, operador de massa, domínio, estado assintótico, representação e ordem dos limites `t→∞`, `λ_IR→0`, resolução `ε→0`. Os novos artigos reforçam que uma comparação sem esses dados é ambígua, não resolvem o teorema de Buchholz por si só.
- **[?]** Requisito D: definir de modo independente álgebra regional, centros gauge, carga e fluxo assintótico, dressed-state Hilbert space, radiação observável e a operação de trace; só depois comparar `S1`, `S2`, entropia algébrica e destilável. A álgebra gauge física não se identifica por decreto com um tensor product hard⊗soft.

## 5. Auditoria documental E71 — leitura do LEIAME de resultados e limites

**Fonte Drive efetivamente lida:** `LEIAME_E71_resultados.md` (ID `1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf`) e `LEIAME_E71.md` (ID `1UysFKMT5LdmjzuV6RYCOv6iM6IzaJ1QE`). O LEIAME registra execução histórica autorizada em 14/10/2026 e classifica operacionalmente `H71-E = DESTILÁVEL`, mas o mesmo documento aponta os arquivos `dados/perfis.json` e `resultados/E71_resumo.json` como **membros internos de um ZIP**; não os fornece como arquivos brutos independentes. A palavra `DESTILÁVEL` no avaliador **não demonstra**, sem um protocolo operacional LOCC/SSR, que `f_c` Rényi-2 seja entropia destilável em teoria gauge. Preservar ambas as informações: **status histórico do avaliador** e **limite de interpretação física**.

**Busca Drive em todo o escopo acessível:** `HRF_ELETRON_71_PACOTE_EXECUCAO`, `E71_resumo`, `perfis.json`, `ELETRON_71`, `2026-10-14_1147`, além de filtros históricos por MIME. Encontrados relatório, protocolo, dois LEIAME e menções nos cadernos; **não recuperados** `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `dados/perfis.json` ou `resultados/E71_resumo.json` como bytes brutos. **NOT_FOUND, não equivaler a inexistência do pacote fora do Drive.** Nenhum código foi executado e não foi reivindicada auditoria independente da E71.

## 6. Gates, frentes negativas, status de uso e próxima rodada

| Gate | Resultado estrito | Status físico |
|---|---|---|
| `G-SOFTTRACE-1` | [0131] rastreamento de radiação não observada em formalismo inclusivo | [F] no regime do artigo; sem transferência à E71 |
| `G-SOFTTRACE-2` | [0133] dressing `r` distinto de resolução `ε`; trace de radiação | [F] no esquema do artigo; não é prova de dualidade |
| `G-SOFTTRACE-3` | [M] espectro, `S1/S2`, pureza e limites de matriz 2×2 | PASS álgebra; QED e entropia gauge PENDING |
| `G-IR-DRESS-4` | [0130] KF isolado insuficiente no modelo de correntes | PASS condicional; QED completa PENDING |
| `G-FK-DOMAIN-1` | [0132] distinguir QED escalar massiva, sem massa e gravidade | PASS classificação; nenhuma gravidade emergente |
| `G-IR-2` | compatibilidade de polos perturbativos com infrapartícula [0086] | PENDING rigoroso |
| `G-MASSINPUT-4` | [0132] §4 eq. (4.1) tem `m²ϕ̄ϕ` como entrada | FAIL como derivação independente de `m_e` |
| `G-E71-RAW` | ZIP/JSON ausentes no Drive acessível | NOT_FOUND; sem reexecução |

**Frentes negativas preservadas:** nenhuma fonte nova demonstra QED₄→gravidade dinâmica→`m_e`, spin 1/2 ou estatística fermiônica; [0132] usa massa escalar como entrada, [0130] pressupõe partículas carregadas. Val Baker [0031] segue sem replicação independente. Γ/E Hadamard [0055,0109–0111], Takeda/Sugiura [0052,0064], métrica inversa [0098], QES/JLMS [0036,0106,0113,0124] e centros gauge [0118–0120] continuam PENDING neste ciclo, sem alegar releitura integral.

**Próximo bloco, sem simulação:** confrontar detalhes do BRST e do dressing transversal de [0130] com [0089]; examinar [0132] §§4.4, 5.4 e 6.3 e hipóteses de seus teoremas; estudar compatibilidade de álgebra local e trace soft; buscar pacote E71 em proveniência de execução externa; retomar Γ/E Hadamard e reconstrução métrica com gates de independência dos dados. Manter os três mapas G/W/D e a classificação RUP B→A.

**Controle bibliográfico final:** referências `0001–0129` mantidas byte a byte no índice; novas `0130–0133`; total **133 IDs imutáveis**, próximo `HRF-REF-0134`. Quatro pares históricos de títulos duplicados preservados, total normalizado **129 títulos distintos**. O índice slim contém **somente** `HRF-REF-#### -> título`.

## 7. Fontes primárias e internas — acesso efetivo

- Research Book Cap. 0.1 v0.2, texto integral: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view .
- Caderno CP-24 v2.2, prefixo integral: https://drive.google.com/file/d/1Zb_2hHB8LOUZTu6iRK3AXNgpTHROTUbc/view .
- Índice CP-24 v2.4, 129 linhas: https://drive.google.com/file/d/1q123_ANwOaVCp2pbb9u1Ws5c8kmrsGwv/view .
- LEIAME de resultados E71: https://drive.google.com/file/d/1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf/view .
- [0130] PDF, §§2.4–3: https://arxiv.org/pdf/2009.11716 .
- [0131] PDF, eqs. (1)–(4), (11), (18): https://arxiv.org/pdf/1706.03782 .
- [0132] PDF, §§4–8 (leitura selecionada): https://arxiv.org/pdf/2203.14334 .
- [0133] PDF, §§2 e 4, eqs. (53)–(54): https://arxiv.org/pdf/1807.07079 .


---

# CP-26 — Checkpoint de pesquisa bibliográfica HRF · 2026-10-22 01:11 BRT

**Natureza:** continuação documental e auditoria matemática independente, sem execução de bancada/simulação HRF. **Estado:** [D] caderno histórico cumulativo com observações [F]/[M]/[H]/[?] explicitadas; não é validação da teoria.  
**Origem exata:** CP-25 / caderno v2.3, 254.416 bytes, SHA-256 `e44f670c4ba41068391b1cd1c8d01c3e2360fe1482ede10a37ced63b8b8edcd3`.  
**Índice de entrada:** 133 IDs, próximo 0134; reutilizada referência histórica [0075] para Casini/Huerta/Rosabal; pares duplicados preservados: 0046/0098, 0074/0120, 0077/0119, 0078/0112.  
**Ordem de consulta obedecida:** (1) Cap. 0.1 integral e arquivos Projeto/Library; (2) Drive HRF; (3) literatura primária externa.  
**Mapas de interface:** G (geometria/RT/QES), W (ondas/campos/propagação), D (dinâmica/causalidade); nesta rodada G = foco, W = interface de dressings, D = pendente. **Estratégia RUP B→A:** preservar primeiro teoremas em seus domínios; nenhum salto ontológico.

## 1. Fontes internas, leitura real e proveniência

- [D] **Research Book Cap. 0.1 v0.2 (09/10/2026)**: arquivo Drive `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I` recuperado em Markdown original de **28.951 bytes**; **leitura integral de 246 linhas**. Buscas por versão supersessora não localizaram Cap. 0.1 posterior. Preservadas RUP B→A, classes [F]/[M]/[H]/[?]/[D], três mapas G/W/D, gates, controles 2D–Delaunay–Voronoi–GMF e regra de não executar bancadas sem autorização.
- [D] Projeto/Library: `HRF_PDST_Prompt_Abertura_Novo_Chat_v0_2_PT_2026-10-10.md` (trechos relevantes; mantém Cap. 1 v0.2 e Cap. 2 v1.2 como existentes). Não declarar auditoria integral de capítulos não lidos nesta rodada.
- [D] **Novo Capítulo 3 v0.1 de 21/10/2026**, `HRF_Research_Book_Cap03_Base_Quantica_Compartilhada_e_GMFt_v0_1_PT_2026-10-21.md`, Drive `13sU7UzSRj-zaA_EmyZQZKBXfd8HkLn0f`, 31.935 bytes: nota editorial e seções relevantes consultadas; consolidação **provisória** de B31/B31R/B33/B35/B37, não prova de gravidade emergente, de fóton do Cap. 2 ou de massa eletrônica. Não substituir arquivos antigos nem misturar modelos sem dicionário.
- [D] Caderno anterior v2.3 e índice v2.5 recuperados em bytes originais do Drive: tamanhos 254.416 e 9.721 bytes; hashes de entrada conferidos antes da concatenação. O checkpoint CP-25 e todos os anteriores permanecem dentro do prefixo imutável.
- [?] E71: buscas no Drive por `E71`, `ELETRON_71`, `PACOTE_EXECUCAO`, `perfis.json`, nomes exatos de ZIP e JSON; retornaram relatórios/protocolos/LEIAME/checkpoints, **não** o ZIP `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `E71_resumo.json` nem `perfis.json`. A etiqueta histórica `H71-E=DESTILÁVEL` não é uma prova LOCC/SSR. Nenhuma simulação, reprocessamento E71 ou código de bancada executado.

## 2. Referência existente reutilizada e novas referências primárias — leitura/uso

**HRF-REF-0075 (reutilizada, sem novo ID) — Casini, Huerta e Rosabal (2014), _Remarks on entanglement entropy for gauge fields_.** Phys. Rev. D 89, 085012; arXiv:1312.1183. **Leitura:** PDF original, resumo, §§1, 3.2 e 4 selecionados; **não** prova integral replicada. **Uso:** [F] restrições gauge podem produzir centro não trivial na álgebra de região; escolha de álgebra/corte de fronteira importa; alternativas com centro trivial existem na construção de rede, relacionadas a árvores máximas/fixação parcial gauge. Os autores discutem ambiguidades locais na fronteira e universalidade relativa de certas quantidades no limite contínuo sob suas condições. **Não** se conclui que centro elétrico U(1) = operador de área gravitacional ou que toda entropia Rényi seja observável universal.

**HRF-REF-0134 — Donnelly e Giddings (2018), _Gravitational splitting at first order: Quantum information localization in gravity_.** Phys. Rev. D 98, 086006; arXiv:1805.11095. **Leitura:** PDF original, §§III–IV, eqs. (7), (17)–(23), (20)–(21) selecionadas; **não** prova integral replicada. **Uso:** [F no regime perturbativo] dressings de operadores e estados sob difeomorfismos infinitesimais, localização operacional até **primeira ordem em κ = √(32πG)**, dados externos dependentes de cargas totais de Poincaré com escolha de dressing. **Limite:** correladores de ordem κ², gravitons vestidos, estados de campos fortes e prova não perturbativa não resolvidos. **Não** demonstra dinâmica gravitacional a partir da QED₄.

**HRF-REF-0135 — Giddings (2019), _Gravitational dressing, soft charges, and perturbative gravitational splitting_.** Phys. Rev. D 100, 126001; arXiv:1903.06160v3. **Leitura:** HTML integral disponível, seções **II.2–II.4, III.3 e IV** lidas seletivamente com eqs. (9)–(16), (39)–(43), (49); **não** prova completa replicada. **Uso:** [F dentro das hipóteses perturbativas] uma escolha de dressing padrão pode tornar medidas exteriores independentes de detalhes interiores além da carga elétrica total ou cargas de Poincaré. Configurações radiativas sem fonte modificam cargas soft sem alterar a distribuição de carga. **Cautelas explícitas:** degenerescência do vácuo e estados que não são autovetores de todos os geradores; existência de estrutura de subsistemas em ordem superior/não perturbativa é aberta. **Não** confundir com teorema universal de fatorização gravitacional.

**HRF-REF-0136 — Junge, Renner, Sutter, Wilde e Winter (2018), _Universal recovery maps and approximate sufficiency of quantum relative entropy_.** Annales Henri Poincaré 19, 2955–2978; arXiv:1509.07127v3. **Leitura:** PDF original, introdução, Theorem 2.1 eqs. (17)–(19), Remark 2.2 eqs. (20)–(21), propriedades e início da prova; **não** prova integral das 24 páginas replicada. **Uso:** [F] para canal CPTP N, referência σ e `supp(ρ) ⊆ supp(σ)`, existe mapa de recuperação **universal para σ,N** (não dependente de ρ) com

`ΔD := D(ρ||σ) − D(Nρ||Nσ) ≥ −2 ln F(ρ,(R_{σ,N}∘N)(ρ))`,

com fidelidade F **não elevada ao quadrado** na convenção do artigo. A hipótese de suporte e a dependência de σ,N não podem ser descartadas. **Não** estabelece JLMS, AdS/CFT ou bulk geométrico sem um canal/dicionário holográfico físico.

## 3. Controle independente G-RECOVERY-1 — canal de desfasamento de qubit

**[F] Verificação algébrica exata de caso finito; não é simulação HRF nem reprodução da prova geral.** Fixar `ρ=|+⟩⟨+|`, `σ=I/2`, `N_t(τ)=[(1+t)/2]τ+[(1−t)/2]ZτZ`, `0≤t≤1`. Este canal CPTP é unital e autoadjunto. Para `σ=I/2`, seu Petz recovery é `R_{σ,N_t}=N_t`; rotações modulares triviais dão o mesmo mapa universal. Então

`D(ρ||σ)=ln 2`,  
`D(N_tρ||N_tσ)=ln 2−h((1+t)/2)`,  
`ΔD=h((1+t)/2)`,  
`(R∘N_t)(ρ)=(I+t² X)/2`,  
`F(ρ,(R∘N_t)(ρ))=√[(1+t²)/2]`,  
`−2ln F=−ln[(1+t²)/2]`.

Aqui `h(u)=−u ln u−(1−u) ln(1−u)`; por monotonicidade das entropias de Rényi, `h(u)≥−ln(u²+(1−u)²)` com `u=(1+t)/2`. Isso **prova a desigualdade para todo t∈[0,1] neste modelo**, sem extrapolar ao teorema geral. Cálculos numéricos de controle:

| t | ΔD (nats) | F(ρ,RNρ) | −2 ln F | folga ΔD+2lnF |
|---:|---:|---:|---:|---:|
| 0.00 | 0.693147180560 | 0.707106781187 | 0.693147180560 | 0.000000000000 |
| 0.25 | 0.661563238158 | 0.728868986856 | 0.632522558744 | 0.029040679414 |
| 0.50 | 0.562335144619 | 0.790569415042 | 0.470003629246 | 0.092331515373 |
| 0.90 | 0.198515243346 | 0.951314879522 | 0.099820335282 | 0.098694908064 |
| 1.00 | -0.000000000000 | 1.000000000000 | -0.000000000000 | 0.000000000000 |

**Status:** PASS algébrico (incluindo igualdade t=0,1), PENDING canal físico HRF e comparação quantitativa JLMS/QES. **Lição:** recuperar aproximadamente exige canal, estado de referência, suporte, mapa de recuperação e fidelidade controlada; não basta pequena distância entre estados ou coincidência isolada de entropias.

## 4. Gates de interface, fronts negativos e não inferências

**G-CENTER-CHOICE-2 [F em rede, [?] interface HRF]:** a entropia de uma região gauge depende da álgebra escolhida. Em geral, `S_alg = H(p_k)+Σ_k p_k S(ρ_k)` para álgebra finita em blocos, mas isso não fixa centro elétrico único nem área geométrica. **FAIL** inferir área gravitacional ou destilabilidade diretamente de Shannon/Rényi-2.

**G-SOFTDECOUPLE-2 [F perturbativo, [?] físico completo]:** no EM, `Q_ε=∫dΩ ε(Ω)lim_{r→∞}r² E^r` pode depender da radiação adicionada/dressing; a carga total `Q_1` permanece ligada a Gauss. A escolha do dressing padrão pode ocultar detalhes interiores de observáveis exteriores, mas não garante ausência de qualquer correlação em estados arbitrários. **PENDING** IR não perturbativo e escolha de observáveis.

**G-GRAVSPLIT-2 [F primeira ordem, [?] HRF]:** no regime de gravidade linearizada, medidas exteriores de `h_μν` a O(κ) podem ser sensíveis apenas às cargas globais após dressing padrão. Isso **não** demonstra fatorização tensorial universal, nem gravidade dinâmica emergente, nem um dicionário com RT/QES.

**G-RECOVERY-1 [F modelo finito]:** desigualdade de recuperação testada analiticamente, sem substituir G-JLMS-3 anterior: distância pequena não controla uniformemente entropia relativa na ausência de condições de suporte. Novo controle oferece caminho para **pré-registrar** erro de recuperação em um futuro canal de reconstrução.

**G-E71-RAW-7 [?]:** ZIP e JSON brutos E71 continuam ausentes. O índice `f_c=1−ΔS₂(cond)/ΔS₂(completa)` não equivale por definição a taxa de destilação LOCC/SSR, fidelidade de recuperação, área RT ou prova de massa.

**G-MASS-NEG-5 [?]:** [0075, 0134–0136] não calculam a massa do elétron de primeiros princípios. **QED₄ → gravidade dinâmica → m_e continua NÃO DEMONSTRADO**. Também abertos: massa/espín/estatística física do elétron HRF, auditoria Val Baker [0031], independência de Γ/E/Hadamard, Takeda/Sugiura e unicidade métrica, limites de HRT/QES fora de AdS.

**Mapa RUP:** G = álgebras regionais, recuperação e limite de inferências holográficas; W = dressing, campo exterior e radiação; D = dinâmica/causalidade gravitacional não derivada. **[D] Não alterar [M] para [F] por analogia; preservar todos os negativos e históricos.**

## 5. Próximo bloco prioritário — sem simulações não autorizadas

1. Auditar a construção de split de [0134–0135] versus a noção de setores de carga infravermelha [0086], [0127–0133], explicitando classes de observáveis e ordens perturbativas.
2. Confrontar escolha de álgebra de [0075] com [0118–0120] e com o código central [0115], sem identificar automaticamente centro U(1) e operador de área.
3. Examinar Theorem 2.1 de [0136] e aproximações JLMS [0124] sob suporte e fidelidade, distinguindo prova completa de controle de qubit.
4. Prosseguir busca do ZIP E71 fora da pasta Physics se acessível; nenhuma alegação de auditoria dos dados até recuperar os arquivos originais.
5. Retomar Γ/E Hadamard, métrica inversa e unicidade, Takeda/Sugiura, QED₄ com elétron vestido e dependência de parâmetro de massa; preservar gates G/W/D e RUP B→A.

## 6. Controle de integridade bibliográfica e histórico

- **Prefixo cumulativo literal:** o novo caderno concatena os **254.416 bytes originais** do caderno CP-25 v2.3, sem editar, normalizar quebras, reformatar fórmulas ou excluir texto; este checkpoint é acrescentado ao final. O histórico CP-01–CP-25, estados de leitura/uso e frentes negativas permanecem no prefixo.
- **Índice slim:** linhas originais HRF-REF-0001–0133 preservadas byte a byte, mais três novas linhas 0134–0136. **136 IDs**; 4 pares duplicados históricos preservados; **132 títulos normalizados distintos**; próximo ID **HRF-REF-0137**. Nenhum ID antigo reutilizado.
- **Não execução:** nenhum teste computacional da bancada, dinâmica numérica ou simulação física HRF executada; apenas cálculo analítico de qubit, verificado numericamente como controle aritmético.
- **Classificação da leitura:** [0075, 0134–0136] **PDF/HTML original em seções selecionadas**, não reprodução de provas completas; cálculo G-RECOVERY-1 **independentemente verificado**, não validação da interpretação física.

## 7. Fontes auditadas neste ciclo

- Capítulo 0.1 v0.2 integral: https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view
- CP-25 cumulativo original: https://drive.google.com/file/d/1Kwwm4glpG0bwZ1zWHBcIdkcMXg3iqQvZ/view
- CP-25 índice original: https://drive.google.com/file/d/1tV3K83RGhpXAyISvMzjBWipMKHHRw-4I/view
- Capítulo 3 v0.1 (21/10, consolidação provisória): https://drive.google.com/file/d/13sU7UzSRj-zaA_EmyZQZKBXfd8HkLn0f/view
- [0075] https://arxiv.org/pdf/1312.1183 ; DOI 10.1103/PhysRevD.89.085012
- [0134] https://arxiv.org/pdf/1805.11095 ; DOI 10.1103/PhysRevD.98.086006
- [0135] https://arxiv.org/html/1903.06160 ; DOI 10.1103/PhysRevD.100.126001
- [0136] https://arxiv.org/pdf/1509.07127 ; DOI 10.1007/s00023-018-0716-0


---

# CP-27 — Checkpoint de pesquisa bibliográfica HRF · 2026-10-22 13:04 BRT

**Natureza:** pesquisa documental e controles analíticos independentes; nenhuma execução, réplica ou simulação de bancada HRF. **Estatuto:** [D] checkpoint com conclusões [F]/[M]/[H]/[?] separadas. **Base imutável:** CP-26, caderno v2.4 de 267.600 bytes (SHA-256 `b9e5b253f9f66a9509d2970c4a7e2eec703713625b78b063ffd3b2d61e334dd7`) e índice v2.6 com 136 linhas. **IDs novos:** 0137–0140; próximo 0141. **Estratégia:** RUP B→A, sem pressupor êxito da reconstrução fundamental.

## 1. Fontes internas, proveniência e ordem de consulta

1. **Capítulo 0.1 v0.2, 09/10/2026, lido integralmente:** Drive `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`; texto de 247 linhas apresentado pelo conector, arquivo Markdown original de 28.951 bytes conforme controle CP-26. Busca Drive não identificou versão posterior adotada. Preservados [D] RUP B→A; classes [F] estabelecido com hipóteses, [M] modelo, [H] hipótese, [?] aberto, [D] decisão; três mapas **G=geometria/holografia, W=dinâmica da onda/excitação, D=dicionário boundary↔bulk**; distinção entre solver Maxwell 2D3V, modelos 3D históricos e boundary 2D→bulk 3D. **Correção prospectiva:** no cabeçalho do CP-26 houve uma abreviação inadequada de D como dinâmica/causalidade; manter o texto histórico intacto e aplicar aqui a definição normativa D=dicionário boundary↔bulk. Nenhuma inferência ontológica por analogia.
2. **Projeto/Library/conversação:** busca de documentos HRF localizou `HRF_Research_Book_Cap03_Base_Quantica_Compartilhada_e_GMFt_v0_1_PT_2026-10-21(1).docx` e outros materiais OLA. Consultados trechos de escopo, proveniência e limites, não a totalidade de cada documento. O Cap. 3 v0.1 é uma **consolidação provisória** B31/B31R/B33/B35/B37, não prova de dicionário holográfico, massa eletrônica, gravidade emergente ou identificação do fóton.
3. **Google Drive HRF:** consultado `HRF_Research_Book_Cap03_Base_Quantica_Compartilhada_e_GMFt_v0_1_PT_2026-10-21.md` (`13sU7UzSRj-zaA_EmyZQZKBXfd8HkLn0f`), nota editorial, resumo e prioridades; CP-26 cumulativo (`1PKkWHjzJ14MSSccSDIMHUSOMQZBm4Ri_`), índice (`1AgDD6Z-Iw5w2D2yH24F8m-iYKtkGC3PG`) e checkpoint (`1EIWkONNXslRxiqjmeDoGGCS9eq43oagZ`) recuperados em bytes originais. Prefixo e hash conferidos antes de qualquer escrita. `LEIAME_E71_resultados.md` e `LEIAME_E71.md` lidos: E71 foi historicamente executada e etiquetada `H71-E=DESTILÁVEL`, mas dados brutos não estão disponíveis nesta rodada.
4. **Literatura primária externa:** PDFs/HTML originais selecionados [0055], [0073], [0134–0136] e quatro trabalhos novos [0137–0140]. Níveis de leitura explicitados abaixo. Nenhuma prova completa desses trabalhos foi reproduzida; as contas independentes são modelos analíticos limitados.

## 2. Quatro referências novas, imutáveis, com níveis de leitura e uso

**HRF-REF-0137 — Cotler, Hayden, Penington, Salton, Swingle e Walter (2019), _Entanglement Wedge Reconstruction via Universal Recovery Channels_.** Phys. Rev. X **9**, 031011, DOI `10.1103/PhysRevX.9.031011`; arXiv:1704.05839v4. **Leitura:** artigo original, PDF pp. 1–4, especialmente eqs. (3)–(7), introdução e descrição dos apêndices; **não** prova integral dos apêndices. **Uso:** [F no domínio do teorema] canais de recuperação universal, correção aproximada em códigos holográficos e operadores de wedge com controle de erro. A aproximação da igualdade de entropias relativas não deve ser confundida com identidade algébrica exata ou reconstrução arbitrária de todos os estados de microburaco negro. Necessário especificar canal CPTP, estado de referência, código, norma de erro e hipóteses de JLMS; o artigo trata AdS/CFT, não uma boundary HRF construída a partir de Delaunay.

**HRF-REF-0138 — Kang e Kolchmeyer (2023), _Holographic Relative Entropy in Infinite-dimensional Hilbert Spaces_.** Commun. Math. Phys., DOI `10.1007/s00220-022-04627-z`; arXiv:1811.05482v2 (versão arXiv 2019). **Leitura:** HTML original, introdução, Theorem 1.1, Remark 1.2, Theorem 1.3 e §6.2; **não** reprodução das provas das §§4–5. **Uso:** [F condicional] com isometria `u:H_code→H_phys`, álgebras de von Neumann `M_code,M_phys`, comutantes, densidade de vetores cíclicos/separadores e preservação dessa propriedade na imagem, a reconstrução simultânea de álgebra e comutante é equivalente à igualdade de entropias relativas de Araki **em ambas as álgebras e comutantes** para estados especificados. O teorema não produz sozinho o wedge, o mapa u ou uma dualidade física; a aproximação não é o conteúdo do teorema exato. **Não** usar mera coincidência de entropias escalares como substituto de todas as hipóteses.

**HRF-REF-0139 — Antony J. Speranza (2018), _Local phase space and edge modes for diffeomorphism-invariant theories_.** JHEP **02** (2018) 021, DOI `10.1007/JHEP02(2018)021`; arXiv:1706.05061v2. **Leitura:** HTML original, resumo, §§3–6.1 e discussão selecionada sobre ambiguidade JKM e condições de contorno; **não** prova completa. **Uso:** [F sob escolhas de espaço de fase] construção estendida de variáveis de borda para manter invariância sob difeomorfismos com fronteira; álgebra de simetria superficial e possíveis extensões centrais quando translações normais são permitidas por condições de contorno. **Limite:** campo de borda auxiliar e carga de Noether não equivalem automaticamente a novo grau de liberdade físico, área RT, entropia de matéria ou observável universal de um GMFt.

**HRF-REF-0140 — Aldo Riello (2021), _Symplectic reduction of Yang-Mills theory with boundaries: from superselection sectors to edge modes, and back_.** SciPost Phys. **10**, 125, DOI `10.21468/SciPostPhys.10.6.125`; arXiv:2010.15894v3. **Leitura:** HTML original, resumo, §§4, 5.4–5.9 e 6 selecionadas; **não** prova integral. **Uso:** [F dentro da construção apresentada; interpretação contestável] uma estrutura simplética reduzida é canônica dentro de setores de superseleção de fluxo elétrico, sem introduzir variáveis de borda adicionais; ao unir setores podem ser usadas extensões por edge modes. Riello **argumenta**, não prova universalmente, que certas extensões são ambíguas se não representam um sistema físico na interface. Contrasta com [0073] Donnelly–Freidel e [0139] Speranza: **diferentes escolhas de espaço de fase e de observáveis**, não contradição lógica imediata.

**Fontes antigas reutilizadas sem IDs novos:** [0055] Tjoa–Gray _Modest holography and bulk reconstruction in asymptotically flat spacetimes_ (Phys. Rev. D 106, 025021, 2022; arXiv:2204.13133v3), PDF original §§II–IV, eqs. (1)–(8), (46)–(58) selecionadas; [0073] Donnelly–Freidel _Local subsystems in gauge theory and gravity_ (2016), resumo e partes relevantes já auditadas anteriormente; [0136] Junge et al. teorema de recuperação revisitado, sem nova prova geral; [0134–0135] splitting gravitacional de primeira ordem, contexto, não extrapolado.

## 3. Controle independente G-ALGCHOICE-3 — mesma preparação, álgebras diferentes

**[F] Cálculo algébrico finito exato; não é simulação HRF.** Tomar `H=C²`, `|+⟩=(|0⟩+|1⟩)/√2`, `ρ=|+⟩⟨+|`. Para álgebra total `M_full=M₂(C)`, a entropia de von Neumann do estado puro é `S(ρ|M_full)=0`. Para a subálgebra diagonal `M_diag=span{I,Z}≅C⊕C`, o estado restrito tem probabilidades `(1/2,1/2)` e `S(ρ|M_diag)=ln2≈0,693147180560`. O estado físico global não foi alterado; alterou-se a **álgebra de observáveis**. Logo uma entropia regional não é determinada apenas pelo vetor de estado, sem especificar a álgebra/restrição.

**Status:** PASS algébrico; PENDING seleção física da álgebra regional em gauge/gravity. **Não** identificar esse `ln2` com entropia destilável, área de horizonte ou `f_c` da E71. A estrutura real de teorias gauge inclui lei de Gauss, centro, gluing e estados físicos; o exemplo não os implementa.

## 4. Controle independente G-HADAMARD-2 — teste plano da fórmula métrica e limite da interface Γ/E

**[F] Verificação simbólica exata em Minkowski 3+1, para campo escalar livre massless, separação espacial não nula e limite formal de coincidência.** Na assinatura `η=diag(-1,+1,+1,+1)` e longe da singularidade de cone de luz, o correlador de Wightman do vácuo satisfaz

`W(x,x') = [4π² η_{αβ}(x−x')^α(x−x')^β]^{-1}` (prescrição `i0` implícita),

`W(x,x')^{-1}=4π² η_{αβ}Δx^αΔx^β`, de modo que

`∂_μ∂_{ν'} W(x,x')^{-1} = −8π² η_{μν}` e

`g_{μν}(x)=−(1/8π²) lim_{x'→x} ∂_μ∂_{ν'}[W(x,x')^{-1}]=η_{μν}`.

Isso reproduz a eq. (51) de Tjoa–Gray [0055] e a singularidade Hadamard `W~U/(8π²σ_+)` com `σ≈(1/2)g_{αβ}Δx^αΔx^β`. **Status:** PASS da identidade local no caso plano, **NÃO** prova de reconstrução holográfica independente, unicidade métrica global ou QED₄. O procedimento com `W` **já conhecido no bulk** não constitui, por si, inversão de dados da fronteira.

**G-ΓE-2 — gate negativo de independência:** [0055] eqs. (47), (50), (57)–(58) exigem projeção `Γ:Sol_R(M)→Sol_R(I⁺)` compatível com a forma simplética, além do propagador causal `E=E⁻−E⁺` da equação de Klein–Gordon `P=□_g−m²−ξR`. O próprio `E` e a projeção `Γ(Ef)` dependem da geometria/causalidade do bulk que se pretende reconstruir. Os autores identificam `E` como gargalo clássico, não alegam reconstrução arbitrária de qualquer espaço-tempo apenas de `I⁺`. Para o HRF, **FAIL/PENDING como derivação independente** enquanto Γ, E e o mapa de smearing forem fornecidos por uma métrica de entrada sem teste adversarial. Uma demonstração genuína requer observáveis boundary especificados sem usar a métrica-alvo, prova de injetividade/identificabilidade e recuperação em exemplos não triviais. O controle plano valida **consistência**, não ausência de circularidade física.

## 5. Controle independente G-ASYM-MULTI-1 — carga global não fixa multipolos locais

**[F] Eletrostática clássica fora de fonte localizada.** Para uma distribuição de cargas com total `Q` e dipolo longitudinal `p`, o potencial assintótico é

`Φ(r,θ)=Q/(4πε₀r)+p cosθ/(4πε₀r²)+O(r⁻³)`;

`E_r=Q/(4πε₀r²)+2p cosθ/(4πε₀r³)+O(r⁻⁴)`.

Portanto `lim_{r→∞}r²E_r=Q/(4πε₀)` independe de `p`, mas `δE_r=2δp cosθ/(4πε₀r³)+O(r⁻⁴)` pode distinguir distribuições com mesmo `Q` em raio finito. **PASS** do cálculo de multipolos; **não** é teorema de splitting gravitacional ou prova de que cargas soft angulares sejam todas iguais em estados radiativos/dressings diferentes. O controle ilustra por que dados globais/assintóticos limitados não garantem recuperação completa de estrutura interior, e por que a ordem perturbativa de [0134–0135] importa.

## 6. Gates, frentes negativas e reconciliação de pressupostos

- **G-RECOVERY-2 [F teorema condicional, [?] HRF]:** [0137] oferece canais de recuperação **aproximada** com controle por perda de entropia relativa; [0138] é equivalência **exata** em álgebras de von Neumann infinitodimensionais com condições cíclicas/separadoras e reconstrução dos comutantes. Não confundir um com o outro. Não há ainda canal CPTP físico `N_HRF`, isometria `u_HRF`, wedge definido e comparação quantitativa de erros para HRF-OLA/B31–B37/E71.
- **G-EDGE-3 [F condicionado, [?] físico HRF]:** [0073] e [0139] introduzem edge modes para espaço de fase estendido; [0140] constrói redução por setores de fluxo sem edge modes extras e problematiza sua interpretação física. **PENDING** critério operacional de interface e definição do centro em cada região. Não transformar variável auxiliar em entidade física ou área RT sem dicionário.
- **G-ALGCHOICE-3 PASS** apenas para restrição de estado a subálgebra finita; **G-HADAMARD-2 PASS** apenas para a fórmula local plana; **G-ΓE-2 PENDING/FAIL** como demonstração de métrica independente; **G-ASYM-MULTI-1 PASS** apenas eletrostática clássica.
- **G-E71-RAW-8 [?]:** buscados no Drive por nome exato e filtros MIME ZIP/JSON: `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `E71_resumo.json`, `perfis.json`. Nenhum arquivo bruto recuperado; verificações em `/mnt/data` também não localizaram esses arquivos. O LEIAME declara execução histórica autorizada em 14/10, com rótulo de avaliador `H71-E=DESTILÁVEL`, **não** prova de destilabilidade LOCC/SSR. Nenhuma réplica, código de avaliador ou simulação executados nesta rodada.
- **G-MASS-NEG-6 [?]:** [0137–0140] e [0055] não fornecem derivação independente de `m_e`, spin 1/2, estatística de Fermi, gravidade dinâmica da QED₄ ou uma dualidade HRF boundary↔bulk. Frentes negativas mantidas: `QED₄→gravidade dinâmica→m_e`, Val Baker [0031] (auditoria histórica não refeita), Γ/E/Hadamard e unicidade métrica, Takeda/Sugiura prova completa, recuperação aproximada JLMS/QES, infrapartículas Buchholz versus dressings perturbativos, setores gauge físicos versus centros auxiliares, E71 brutos ausentes.

## 7. Próximos passos, sem autorização de simulações

1. Confrontar prova completa de [0137] para operadores correlacionados com Theorem 1.1 de [0138] e limites de suporte/referência [0136], mantendo regimes exato/aproximado distintos.
2. Auditar as escolhas de gluing, gauge e superfície de corte [0073,0139,0140], com exemplo físico Gauss de rede antes de identificar centro ou área.
3. Formular protocolo **somente documental/analítico** de independência para `Γ/E`: quais dados boundary podem ser fixados sem assumir `g`? Qual par de métricas adversariais poderia compartilhar dados limitados? Reexaminar provas Takeda/Sugiura e reconstrução métrica sem novos testes numéricos.
4. Buscar o pacote E71 em proveniência externa/arquivos de origem se disponível; até então marcar **NOT RECOVERED** e não validar decisões operacionais.
5. Manter RUP B→A, classes [F]/[M]/[H]/[?]/[D], mapas G/W/D e separação de leituras **abstract / selected original full text / independent algebra / full proof**. Não executar simulações sem autorização explícita.

## 8. Integridade cumulativa, histórico e fontes

- **Preservação literal:** o novo caderno é o arquivo v2.4 CP-26 de **267.600 bytes inalterados**, seguido de separador e deste CP-27 integral. Todos os checkpoints CP-01–CP-26, fórmulas, estados de leitura/uso, frentes negativas e histórico permanecem no prefixo. **Nunca sobrescrever** versões anteriores.
- **Índice slim:** 136 linhas anteriores preservadas literalmente e quatro linhas 0137–0140 acrescentadas, apenas `HRF-REF-#### -> título`. Quatro pares históricos de título duplicado [0046/0098], [0074/0120], [0077/0119], [0078/0112] preservados. Total **140 IDs**, **136 títulos normalizados distintos**, próximo **HRF-REF-0141**. `HRF-PEND` permanece aberto para fontes incompletas, sem alocar IDs por inferência.
- **Fontes internas:** Cap.0.1 https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view ; Cap.3 v0.1 https://drive.google.com/file/d/13sU7UzSRj-zaA_EmyZQZKBXfd8HkLn0f/view ; CP-26 cumulativo https://drive.google.com/file/d/1PKkWHjzJ14MSSccSDIMHUSOMQZBm4Ri_/view ; índice CP-26 https://drive.google.com/file/d/1AgDD6Z-Iw5w2D2yH24F8m-iYKtkGC3PG/view ; LEIAME E71 resultados https://drive.google.com/file/d/1KjmOJvXga8az7gqg4LN6nMvjaY8NVpbf/view .
- **Primárias:** [0137] https://journals.aps.org/prx/pdf/10.1103/PhysRevX.9.031011 ; [0138] https://arxiv.org/html/1811.05482v2 ; [0139] https://arxiv.org/html/1706.05061v2 ; [0140] https://arxiv.org/html/2010.15894v3 ; [0055] https://arxiv.org/pdf/2204.13133 ; [0073] https://arxiv.org/abs/1601.04744 .
- **Não execução:** somente cálculos simbólicos e aritméticos, sem bancada, reprocessamento, geração de dados ou simulação física HRF.


---

# HRF — Checkpoint de pesquisa bibliográfica CP-28

**Data/hora:** 2026-10-23_0105_BRT (America/Sao_Paulo)  
**Programa:** Holographic Reconstruction Framework — RUP B→A  
**Frentes:** recuperação algébrica G/D; centros gauge e gluing; informação lógica distribuída e DIO/GMFt; controles negativos QED₄/métrica.  
**Estatuto:** auditoria documental e cálculos algébricos exatos. **Nenhuma simulação HRF, reexecução de bancada ou produção de dados físicos.**

## 1. Ordem de consulta e proveniência

1. **Primeiro, leitura integral do Capítulo 0.1 v0.2** `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, metadados 28.951 bytes. Busca de títulos não encontrou substituto posterior para o Cap. 0.1; existem cópias v0.2. Mantidos RUP B→A, [F]/[M]/[H]/[?]/[D], mapas **G** geometria/holografia, **W** onda/dinâmica e **D** dicionário boundary↔bulk; resultados numéricos não são evidência empírica nem prova de matéria ou gravitação.
2. **Arquivos do Projeto/conversação:** caderno cumulativo CP-27 v2.5, 283.655 bytes, SHA-256 `9f38dcccc039aa53ca713bc8947c467f167a2360444f4311977d426c68f19c66`; índice v2.7, 10.392 bytes, SHA-256 `e088eb9e04f19e6f299fd2d469bbdda91f984a84da461a671676ab7c730e4629`; `HRF_Tabela_Auditoria_Bibliografica_CP27_2026-10-22.md` (triagem, não certificação de leitura); CP-27 e demais checkpoints no prefixo histórico. Hashes locais conferidos.
3. **Google Drive HRF:** confirmei a pasta de destino pelo **ID imutável** `1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9`. **Mudança de caminho detectada:** ela agora aparece sob `/Google Drive/Arquivado/My-Scientific-Library-2/00-Inbox/Physics/` porque a biblioteca `My-Scientific-Library-2` está dentro de `Arquivado`, e não diretamente na raiz. O ID da pasta é o mesmo. Consultei o Capítulo 3 **v0.3 de 22/10**, ID `1jE3HDVpuoBt5QHZfo-E54dBHxhOc1d9R`, que sucede v0.2.1, e a nota `HRF_PD_Nota_Integracao_DIO_GMFt_Dicionarios_Holograficos_v0_1_PT_2026-10-22.md`, ID `1qME30Vk0rVC8ejYQwI1wOGt4TPC8JWrw`. A nova formulação DIO/GMFt e assinatura inicial é [D/H], não resultado validado.
4. **Literatura primária:** artigos originais [0141–0143] consultados em seções relevantes de texto completo (incluindo enunciados/hipóteses, mas **sem reprodução integral das provas**); [0144] verificado **somente por catálogos bibliográficos**, sem leitura do livro. Reexaminados trechos selecionados de [0137], [0138] e [0140]. Não atribuir status de prova integral a nenhuma dessas leituras.

## 2. Quatro novas referências imutáveis e níveis de leitura

- **HRF-REF-0141 [F — teorema condicional, leitura: seções do original + Theorem 1, não prova integral].** Chen, Penington, Salton, *Entanglement Wedge Reconstruction using the Petz Map*, JHEP 01 (2020) 168, arXiv:1902.02844. Texto primário https://arxiv.org/html/1902.02844 . O Teorema 1 parte da **existência prévia** de um decodificador `D'` com erro uniforme `<δ` no código de dimensão finita `d_code`; o mapa Petz com referência maximamente misturada tem erro de norma traço limitado por `d_code sqrt(8δ)`. Não é afirmação universal sem código, isometria, canal, álgebra, referência e controle de dimensão.
- **HRF-REF-0142 [F — construção de Maxwell condicionada, leitura: §§4–5 do original, não prova integral].** Riello, *Edge modes without edge modes* (2021), arXiv:2104.10182, https://arxiv.org/html/2104.10182v1 . Em Maxwell, a forma simplética global não é soma ingênua das regionais; a correção de colagem pode ser reconstruída funcionalmente do *mismatch* dos campos radiativos regionais. A superseleção do fluxo depende do domínio causal e da álgebra regional. **Não** significa que todas as variáveis de borda sejam fictícias ou que uma formulação estendida seja inválida; há informação física relacional na colagem.
- **HRF-REF-0143 [F — código QSS estabelecido, leitura: exemplo ((2,3)), Prop. 6, teoremas de não clonagem e trechos de prova, não prova integral].** Cleve, Gottesman, Lo, *How to share a quantum secret*, Phys. Rev. Lett. 83, 648 (1999), arXiv:quant-ph/9901025, https://arxiv.org/abs/quant-ph/9901025 . Exemplo exato de informação quântica lógica acessível por quaisquer duas partes, mas não por uma parte isolada. **Não** deriva matéria, identidade ontológica DIO, GMFt ou dualidade gravitacional.
- **HRF-REF-0144 [F — referência bibliográfica normalizada, leitura: somente metadados].** C. W. Helstrom, *Quantum Detection and Estimation Theory*, Academic Press (1976), ISBN 9780123400505; catálogo https://ndlsearch.ndl.go.jp/en/books/R100000136-I1971712334760958512 . A desigualdade de discriminação abaixo foi **derivada independentemente para duas matrizes 2×2**, não extraída de leitura do livro.

**Controle de duplicações:** confrontados os 140 títulos do índice v2.7; os quatro novos títulos não aparecem nele. Preservados os pares históricos [0046/0098], [0074/0120], [0077/0119], [0078/0112]. Total após este ciclo: **144 IDs**, **140 títulos normalizados distintos**; próximo **HRF-REF-0145**. Referências incompletas permanecem `HRF-PEND` sem ID.

## 3. Gate G-PETZ-DIM-1 — a dimensão do código limita o erro recuperável

**[F] Enunciado condicional auditado [0141], Theorem 1.** Se para todos os estados do código existe `D'` com `||D'∘N(ρ)-ρ_a||_1<δ`, então o Petz indicado pelo artigo satisfaz

`||P_(τ,N)∘N(ρ)|_a−ρ_a||_1 ≤ d_code sqrt(8δ)`.

Para exigir tolerância-alvo `ε` em norma traço basta impor

`δ ≤ ε²/(8 d_code²)`.

Com `ε=0,1`: para `d_code=2`, `δ≤0,0003125`; para `d_code=100`, `δ≤0,000000125`. **PASS aritmético e de rearranjo**, mas o limite é **suficiente, não necessário**, e não demonstra que qualquer `N_HRF` cumpra a hipótese. Não transferir erro pequeno de um toy code de dimensão fixa a uma família de códigos de dimensão crescente sem controlar `d_code` e o estado de referência.

**[?] G-RECOVERY-3:** [0137] canal twirled Petz para recuperação aproximada; [0141] Petz sem twirling em código finito com hipótese de decoder prévio; [0138] equivalência exata para álgebras de von Neumann infinitodimensionais exigindo condições de vetores cíclicos/separadores e **igualdades em álgebra e comutante**. Os três enunciados têm quantificadores e regimes diferentes. Nenhum, sozinho, fornece `J_HRF`, `M_A`, `M_a`, `M'_A`, `M'_a`, `σ`, `N` e erros físicos para DIO/GMFt ou QED₄.

## 4. Gate G-CENTER-RECOVERY-1 — recuperar o centro não recupera a álgebra completa

**[M] Modelo algébrico finito com cálculo exato, sem simulação física.** Defina uma isometria de cópia de base `V|0>=|00>`, `V|1>=|11>` e o canal regional `N(ρ)=Tr_B[VρV†]=Δ(ρ)`, em que `Δ` elimina as coerências fora da diagonal. A álgebra diagonal `M_diag=span{I,Z}` (centro da própria álgebra comutativa) é recuperável exatamente, pois `Tr(ZΔρ)=Tr(Zρ)`. A álgebra completa `M_2` **não** é recuperável: `ρ_+=|+><+|` e `ρ_-=|-><-|` têm `Δρ_+=Δρ_-=I/2`, embora `Tr(Xρ_+)=+1` e `Tr(Xρ_-)=-1`. Um único decodificador regional não pode reconstruir ambos.

Com referência `σ=I/2`, a fórmula Petz dá `P_(σ,N)=Δ`, pois `N(σ)=σ` e `N*=Δ`. Para `ρ_+`, `D(ρ_+||σ)=ln2`, `D(Nρ_+||Nσ)=0`, perda `ln2`; fidelidade com o recuperado `F(ρ_+,I/2)=1/sqrt2`, portanto `-2lnF=ln2`: **saturação exata** do limite universal. **PASS** para a álgebra e entropia do modelo; **FAIL** para inferir reconstrução de `X` a partir da informação central `Z`.

**Implicação [H/?] para o HRF:** uma etiqueta DIO, fluxo de Gauss ou setor de borda distinguível não assegura acesso às coerências e aos operadores lógicos completos. Nem o centro é, por si, uma área RT, nem `N` é um dicionário holográfico validado.

## 5. Gate G-QSS-3 — três qutrits, acesso distribuído e ausência de cópia

**[F] Código conhecido [0143], com verificação algébrica própria [M].** Use os vetores lógicos normalizados

`|0_L>=(|000>+|111>+|222>)/sqrt3`,  
`|1_L>=(|012>+|120>+|201>)/sqrt3`,  
`|2_L>=(|021>+|102>+|210>)/sqrt3`.

Para cada um dos três sítios `s` e `i,j∈{0,1,2}`, o traço parcial exato nos outros dois sítios é

`Tr_(outros 2)(|i_L><j_L|)=δ_ij I_3/3`.

**Verificação independente:** enumerados os 27 pares `(s,i,j)` e todas as entradas 3×3 usando aritmética racional exata; **PASS em todos**, sem amostragem, integração temporal ou simulação. Portanto, para `|ψ_L>=α|0_L>+β|1_L>+γ|2_L>`, a densidade de **qualquer único qutrit** é `I_3/3`, independente de `α,β,γ`. Pela condição de correção de apagamento (Prop. 6 de [0143]), **qualquer par** pode reconstruir o estado lógico completo. O limite de não clonagem `n<2k` impede dois conjuntos autorizados disjuntos para segredo arbitrário; em `((2,3))`, dois pares autorizados necessariamente compartilham um qutrit.

**G-DIO-QSS-1 [?]:** o Cap. 3 v0.3 formula [H] uma DIO distribuída com assinatura física inicial única e manifestação GMFt dependente de reconstrução dinâmica. O código QSS ilustra **inacessibilidade local da informação lógica**, mas não fornece assinatura única por indivíduo, lei de formação, Hamiltoniano da base, mecanismo de manifestação, energia, causalidade, métrica, nem prova de que um GMFt surge quando um decoder é aplicado. A distinção entre *decodificar informação* e *constituir uma manifestação física* permanece obrigatória.

## 6. Gate G-SIGNATURE-1 — assinatura distinta não é leitura perfeita

**[F] Discriminação de estados quânticos; [M] conta 2×2 independente.** Para estados equiprováveis `|ψ_0>=|0>` e `|ψ_1>=cosθ|0>+sinθ|1>`, `0<θ<π/2`, ambos são diferentes, mas têm sobreposição `cosθ>0`. A diferença das matrizes densidade tem autovalores `±sinθ`, de modo que o limite ótimo de discriminação em uma cópia é

`P_acerto=(1+sinθ)/2 < 1`.

Para `θ=π/6`, `P_acerto=0,75`, **não 1**. **PASS** da álgebra, **não** experimento. O postulado de assinatura inicial única no Cap. 3 v0.3 não implica ortogonalidade, distinguibilidade perfeita por um observador local, rastreamento sem perturbação ou número de série de partícula idêntica. Referência [0144] apenas normalizada, não lida integralmente.

## 7. Gate G-EDGE-GLUING-4 — região, fluxo e dados compartilhados

**[F condicionado à teoria de Maxwell e às hipóteses de [0142]].** Riello distingue dois problemas: (i) reconstruir campos globais a partir dos campos radiativos de `R⁺` e `R⁻`, e (ii) reconstruir a **forma simplética** global. A não aditividade `Ω_red^Σ ≠ Ω_red^+ + Ω_red^-` é real, mas não obriga acrescentar um grau de liberdade fundamental independente: o termo de gluing pode ser função não local do desajuste dos campos radiativos na interface. O fluxo `f` fixado em uma região torna-se variável dinâmica no sistema reunido. **PENDING** extensão a teorias gauge não abelianas, bordas gravitacionais, álgebras locais físicas e E71; não identificar o fluxo de borda com uma superfície RT.

**Confronto [0139]/[0140]/[0142]:** espaço de fase estendido e redução por setores são descrições com escolhas diferentes; não concluir que modos de borda são sempre fictícios ou sempre entidades materiais. O contrato de costura HRF requer especificar álgebra, fluxo, restrições de Gauss, referência, gluing, simetria e observáveis recuperáveis.

## 8. Frentes negativas preservadas, estado dos arquivos e próxima investigação

- **G-E71-RAW-9 [?/NOT RECOVERED]:** repetidas buscas Drive por `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `E71_resumo.json`, `perfis.json`, filtro MIME ZIP, além de `/mnt/data`; não recuperados. O `LEIAME_E71_resultados.md` e relatórios textuais permanecem evidência de execução histórica e rótulo `H71-E=DESTILÁVEL` do avaliador, **não** validação independente de LOCC/SSR. **Nenhuma execução ou reprocessamento.**
- **G-ΓE-3 [?/PENDING]:** nenhum novo dado de fronteira independente da métrica-alvo foi obtido; a reconstrução Hadamard de [0055] segue sendo verificação local condicionada a `Γ/E` e geometria fornecida. Não houve prova de unicidade de métrica nem resolução dos resultados Takeda/Sugiura.
- **G-IR-2 [?/PENDING]:** estados vestidos perturbativos [0121–0123] versus teorema de infrapartículas [0086] ainda exigem análise rigorosa de representações e limites IR.
- **G-MASS-NEG-7 [?/PENDING]:** nenhuma das fontes [0141–0144] fornece mecanismo `QED₄ → gravidade dinâmica → m_e`, nem deriva spin 1/2, estatística fermiônica ou carga do elétron de DIO/GMFt. Massa nos modelos QED conhecidos continua parâmetro de entrada. Val Baker [0031] permanece sem auditoria completa.
- **[D] Sem novos resultados físicos:** os cálculos deste CP são controles de álgebra de informação quântica, não simulações nem provas de holografia física HRF. Manter o estatuto histórico de B31–B37 e E71 sem promoção retroativa.

**Próximo bloco prioritário:** (1) comparar rigorosamente [0137]/[0141] e [0138] para erro, referência, suporte e comutantes; (2) formalizar um contrato de teste falsificável DIO→GMFt com operações físicas distintas de decoder, usando [0143]; (3) auditar gluing [0140]/[0142] e centros de Gauss sem confundir edge mode com ontologia; (4) buscar E71 brutos pela origem; (5) continuar a frente Γ/E e QED₄→gravidade→m_e. **Nenhuma simulação sem autorização explícita.**

## 9. Integridade, índice e fontes

- **Prefixo obrigatório:** preservar literalmente os **283.655 bytes** do caderno CP-27 v2.5, com todos os checkpoints CP-01–CP-27, fórmulas, níveis de leitura/uso, frentes negativas e histórico. Este checkpoint CP-28 é apenso sem reescrever o prefixo. Não alterar nenhum arquivo antigo.
- **Índice slim:** conservar literalmente as 140 linhas CP-27, acrescentar apenas `HRF-REF-0141` a `HRF-REF-0144`; nenhum comentário ou DOI no arquivo slim. Total 144 linhas; quatro pares históricos duplicados preservados; próximo `0145`.
- **Fontes internas:** Cap0.1 https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view ; Cap3 v0.3 https://drive.google.com/file/d/1jE3HDVpuoBt5QHZfo-E54dBHxhOc1d9R/view ; nota PD https://drive.google.com/file/d/1qME30Vk0rVC8ejYQwI1wOGt4TPC8JWrw/view ; caderno CP27 https://drive.google.com/file/d/1VzrsayQ6LrLK-FbI3dyqv7PDIL75GBXZ/view ; índice CP27 https://drive.google.com/file/d/1u_QhT4Tc_cRBN230dLsASQRQEoenLHRG/view .
- **Primárias:** [0137] https://journals.aps.org/prx/abstract/10.1103/PhysRevX.9.031011 ; [0138] https://arxiv.org/html/1811.05482v2 ; [0139] https://arxiv.org/html/1706.05061v2 ; [0140] https://arxiv.org/html/2010.15894v3 ; [0141] https://arxiv.org/html/1902.02844 ; [0142] https://arxiv.org/html/2104.10182v1 ; [0143] https://arxiv.org/abs/quant-ph/9901025 ; [0144] https://ndlsearch.ndl.go.jp/en/books/R100000136-I1971712334760958512 .
- **Sem prova integral auditada:** leituras de seções originais, equações de teoremas e controles algébricos próprios foram separados explicitamente de uma auditoria completa de prova, de um experimento e de uma hipótese HRF.


---

# HRF — Checkpoint bibliográfico CP-29 — 2026-10-23 13:05 BRT

**Projeto:** Holographic Reconstruction Framework (HRF) — *Holographic Reconstruction of Physics*  
**Natureza:** revisão bibliográfica crítica, verificação algébrica independente e atualização cumulativa; **nenhuma simulação física executada**.  
**Status epistemológico:** [F] teoremas da literatura em seus domínios; [M] controles matemáticos calculados; [H] interpretação candidata DIO/GMFt; [?] interfaces não demonstradas; [D] organização e priorização.  
**Diretriz:** RUP B → A, sem promover a hipótese de unidade ontológica a resultado. Mapas **G** (geometria/holografia), **W** (onda/dinâmica) e **D** (dicionário boundary↔bulk) permanecem separados.

## 1. Ordem das fontes e proveniência efetivamente consultada

1. **Primeira leitura obrigatória, concluída:** conteúdo integral de `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md`, Drive ID `1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I`, https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view . Busca nominal por versões `Cap0_1_Diretrizes` não identificou sucessora; há cópias da v0.2. Preservadas as regras RUP, [F]/[M]/[H]/[?]/[D], não ontologização da malha, contratos B0–B5 e não execução sem autorização.
2. **Arquivos da conversa/Projeto:** conferidos os registros CP-27/CP-28 e anexos visíveis na conversa, bem como a solicitação anterior de ZIP e auditoria; nenhum novo protocolo ou autorização de simulação. Não foi encontrado anexo de Projeto que substitua a versão Cap0.1.
3. **Google Drive HRF:** caderno cumulativo CP-28 v2.6 recuperado **em bytes brutos** (298.960 bytes, SHA-256 `513dcd26bb326852856a4746d06fa73fd40c5183e591169d1f474701facff7bb`); índice slim v2.8 recuperado (10.609 bytes, SHA-256 `a7fa8afbcf523675586c329729f943d5f0fe7e7cbc5daab5cb3371cf676ac07b`). Consultados também Cap3 v0.3, `HRF_PD_Nota_Integracao_DIO_GMFt_Dicionarios_Holograficos_v0_1_PT_2026-10-22.md` e `HRF_OLA_Ponte_Matematica_Fisica_Estabelecida_v0_1_PT_2026-10-22.md`. O Cap3 v0.3 mantém a assinatura inicial única de DIO e a manifestação GMFt como [H], sem Hamiltoniano/mecanismo validado. A nota PD diferencia explicitamente decoder lógico de manifestação física.
4. **Literatura externa primária:** lidas seções selecionadas do texto original [0145] (teorema 9, corolário 10, aplicação a fluxo de informação), [0146] (teorema 3.3, corolário 3.4 e seção de álgebras), [0147] (teorema 1, canal complementar e métrica de fidelidade). Reexaminados resumos originais [0138] Kang–Kolchmeyer e [0141] Chen–Penington–Salton para comparar os quantificadores. **Não** se reivindica auditoria integral das demonstrações dos artigos.

## 2. Novas referências normalizadas — IDs imutáveis

- **HRF-REF-0145:** Bény, Kempf e Kribs (2007), *Quantum Error Correction of Observables*, *Physical Review A* **76**, 042303; DOI `10.1103/PhysRevA.76.042303`; https://arxiv.org/abs/0705.1574 ; texto original, teorema 9/corolário 10 e aplicação de álgebras com centros examinados. **Uso HRF:** condições explícitas de corrigibilidade de subálgebras regionais, não prova holográfica.
- **HRF-REF-0146:** Bény, Kempf e Kribs (2008, preprint), *Quantum error correction on infinite-dimensional Hilbert spaces*; https://arxiv.org/abs/0811.0421 ; texto original, teorema 3.3/corolário 3.4 e seção de álgebras de von Neumann examinados. **Uso HRF:** alerta contra extrapolar uma fatorização de qubits para álgebras infinitodimensionais, inclusive fatores não tipo I.
- **HRF-REF-0147:** Bény e Oreshkov (2010), *General conditions for approximate quantum error correction and near-optimal recovery channels*, *Physical Review Letters* **104**, 120501; DOI `10.1103/PhysRevLett.104.120501`; https://arxiv.org/abs/0907.5391 ; texto original, teorema 1 e condições de fidelidade de emaranhamento *worst-case* examinados. **Uso HRF:** distingue correção aproximada com métrica e ambiente explícitos de correção exata de álgebra.

**Sem duplicação:** a inspeção literal do índice CP-28 de 144 linhas não encontrou esses três títulos. Os pares históricos duplicados `[0046/0098]`, `[0074/0120]`, `[0077/0119]`, `[0078/0112]` são preservados sem renumeração. Total após CP-29: **147 IDs**, **143 títulos normalizados distintos**; próximo `HRF-REF-0148`.

## 3. G-OAQEC-KRAUS-1 — gate algébrico exato de corrigibilidade

**[F] Critério da fonte [0145], teorema 9:** para um código suportado em `P`, a álgebra `A ⊂ L(PH)` é exatamente corrigível para o canal `N(ρ)=Σ_a K_a ρ K_a†` se e somente se

`[P K_a† K_b P, X]=0` para todo `X∈A` e todos `a,b`.

**[M] Controle próprio com canal de desfasamento** (não é simulação HRF): para `0≤t≤1`, defina `K_0=√[(1+t)/2] I`, `K_1=√[(1−t)/2] Z`, `P=I`. Então

`K_0†K_1=(√(1−t²)/2) Z` e `K_0†K_0`, `K_1†K_1` são múltiplos de `I`.

Para **todo** `0≤t<1`, a álgebra máxima exatamente corrigível é

`A_corr = {X:[X,Z]=0}=span{I,Z}`.

A coerência `X` não é exatamente corrigível porque `[X,Z]≠0`; `N_t(X)=tX`. Para `t=1`, `K_1=0`, o canal é identidade e a álgebra máxima salta para `M₂(C)`. **PASS analítico exato** por cálculo de comutadores 2×2; nenhum dado experimental. A descontinuidade entre corrigibilidade **exata** e erro **aproximado** quando `t→1⁻` deve ser registrada.

**Limite físico [?/PENDING]:** o `Z` deste toy model não é automaticamente fluxo elétrico regional, carga de Gauss, centro de álgebra gauge ou área RT/QES. Para fazer a ponte DIO/GMFt, definir canal físico, álgebra regional e setor de superseleção antes de aplicar o critério.

## 4. G-APPROX-TRACE-1 — erro minimax de recuperação calculado exatamente

**[M] Prova independente em dimensão 2:** defina distância de traço `T(ρ,σ)=½||ρ−σ||₁` e erro máximo de recuperação `ε*(t)=inf_R sup_ρ T(ρ,R∘N_t(ρ))`, com `R` percorrendo canais CPTP sobre o qubit. Para os estados ortogonais `ρ_±=|±><±|`,

`T(ρ_+,ρ_-)=1`, mas `T(N_tρ_+,N_tρ_-)=t`.

Por contratibilidade da distância de traço sob `R` e desigualdade triangular, se o erro máximo for `ε`,

`1 ≤ T(ρ_+,RN_tρ_+) + T(RN_tρ_+,RN_tρ_-) + T(RN_tρ_-,ρ_-) ≤ 2ε+t`,

portanto `ε ≥ (1−t)/2`. A recuperação identidade `R=id` alcança esse valor: no vetor de Bloch, `N_t` multiplica as componentes `x,y` por `t` e mantém `z`, logo `sup_ρ T(ρ,N_tρ)=(1−t)/2`. Conclui-se **exatamente**

`ε*(t)=(1−t)/2`, `0≤t≤1`.

| `t` | `ε*(t)` em distância de traço | Álgebra exatamente corrigível |
|---:|---:|---|
| `0` | `0,5` | `span{I,Z}` |
| `0,5` | `0,25` | `span{I,Z}` |
| `0,9` | `0,05` | `span{I,Z}` |
| `0,99` | `0,005` | `span{I,Z}` |
| `1` | `0` | `M₂(C)` |

**PASS analítico e aritmético**, confirmado por álgebra simbólica 2×2. **Cuidado:** [0147] define erro por **pior fidelidade de emaranhamento**, não pela distância de traço minimax aqui escolhida; valores e fatores não podem ser transportados sem desigualdades de conversão e hipóteses adicionais. O bound `d_code√(8δ)` de [0141] é outra garantia condicional, não a igualdade acima.

## 5. G-COMPLEMENT-LEAK-1 — a informação do ambiente e o centro

**[M] Dilatação de Stinespring do mesmo canal:** `V|ψ>=a|ψ>|0_E>+b Z|ψ>|1_E>`, com `a=√[(1+t)/2]`, `b=√[(1−t)/2]`. Para entradas `|0>` e `|1>`, os estados puros ambientais são `|e_0>=a|0_E>+b|1_E>` e `|e_1>=a|0_E>−b|1_E>`. Portanto

`<e_0|e_1>=a²−b²=t` e `T(|e_0><e_0|,|e_1><e_1|)=√(1−t²)`.

Para `t=0`, o ambiente distingue perfeitamente o rótulo `Z`; para `t→1`, sua distinguibilidade tende a zero. O mesmo `Z` é observável acessível no sistema e pode ser copiado como **informação comutativa**; o par de coerências `X,Y` não pode ser copiado simultaneamente como informação quântica arbitrária. Isso concorda com o argumento de [0145], seção de fluxo de informação, de que a informação perfeitamente duplicada entre canais complementares está contida no **centro comutativo** da álgebra recuperável.

**G-DIO-IDENTITY-2 [?]:** um identificador clássico de setor ou assinatura distinguível não é um estado quântico lógico completo. O postulado de assinatura inicial única do Cap3 v0.3 não implica ortogonalidade, nem permite afirmar que uma manifestação GMFt possa ser produzida em duas regiões independentes por simples duplicação do identificador. Para uma manifestação física, exigir Hamiltoniano, energia, causalidade, observável e mecanismo independente de decoder.

## 6. G-INFINITE-ALG-1 — limites de extensão do toy code

**[F] Fonte [0146], teorema 3.3/corolário 3.4:** a condição `[P,K_i†K_j]=0` para efeitos projetivos e o comutante dos produtos de Kraus caracterizam a álgebra de observáveis nítidos corrigíveis, com construção de canal de recuperação sob as hipóteses matemáticas do trabalho. O artigo também constrói exemplos infinitodimensionais que não se reduzem a um fator de Hilbert finito tipo I.

**[?] Contrato HRF ainda ausente:** identificar uma álgebra `M_A`, seu comutante `M'_A`, domínio, representação, estado fiel/cíclico-separador quando requerido, canal `N`, mapa lógico `J` e erro. A igualdade de entropia relativa do teorema [0138] exige **ambos** os lados da reconstrução; a correção exata de `span{I,Z}` no qubit não demonstra igualdade JLMS nem reconstrução do wedge. Uma subálgebra regional com centro não é automaticamente uma fatorização tensorial.

## 7. G-DIO-GMFt-INTERFACE-2 — teste falsificável mínimo, NÃO EXECUTADO

**[D] Pré-registro analítico sugerido, sem rodar bancada:** (i) escolher uma única álgebra de base e um código lógico `A_D`; (ii) especificar observáveis regionais `A_R`, `A_R'`, canal de acesso `N_R` e erros em métrica fixa; (iii) calcular comutantes de produtos de Kraus e recuperar a subálgebra autorizada; (iv) **separadamente** definir dinâmica `H_B`, intervenção física local e operador de manifestação `O_GMFt` cuja resposta seja prevista sem inserir o resultado na definição; (v) medir/derivar balanço energético e exclusão de clones; (vi) usar controles com assinatura trocada, estímulo sem DIO e código com mesma recuperação lógica mas sem mecanismo material.

**Gate crítico:** PASS de correção de observáveis `[F/M]` não é PASS de `DIO→GMFt` `[H/?]`. Se `O_GMFt` for apenas a saída do decoder renomeada, o gate de emergência física é **FAIL por circularidade**. A nova frente é **D** (dicionário/identificação de operadores) e uma possível **W** (dinâmica de manifestação) a especificar; não confundir com **G** (geometria).

## 8. Frentes negativas, integridade e próxima rodada

- **E71 RAW [?/NOT FOUND]:** buscas novas por nome exato `HRF_ELETRON_71_PACOTE_EXECUCAO_2026-10-14_1147-clau.zip`, `E71_resumo.json`, `perfis.json` e busca `E71` filtrada por `application/zip` não recuperaram os dados brutos. A busca por `perfis.json` encontrou somente menções textuais (`LEIAME_E71_resultados.md`, relatório E71 e checkpoints). O rótulo histórico `H71-E=DESTILÁVEL` continua **não** sendo prova independente LOCC/SSR.
- **G-ΓE-3 [?/PENDING]:** nenhuma entrada de boundary independente da geometria foi obtida; o mapa Hadamard `Γ/E` de [0055] continua condicional, sem unicidade métrica estabelecida.
- **G-IR-2 [?/PENDING]:** compatibilidade rigorosa entre polos de propagadores vestidos [0121–0123] e o infrapartícula de Buchholz [0086] continua aberta.
- **G-MASS-NEG-8 [?/PENDING]:** as fontes [0145–0147] não derivam massa eletrônica, gravidade dinâmica, spin `1/2` ou estatística fermiônica a partir de DIO/GMFt. A cadeia `QED₄ → gravidade dinâmica → m_e` permanece sem mecanismo. Auditoria de Val Baker [0031] ainda pendente.
- **Sem execução:** nenhuma simulação, evolução dinâmica ou reprocessamento dos brutos E71 foi autorizado ou realizado. Controles deste CP são provas e contas finitas independentes.

**Próximo bloco:** formalizar OAQEC [0145–0146] para uma álgebra regional gauge real, com projetores de fluxo e Gauss; confrontar métricas de erro [0147]/[0141]/[0137], hipóteses exatas [0138] e dependência dimensional; auditar reconstrução Γ/E não circular; recuperar E71 na origem; auditar fontes sobre massa e infrapartículas.

**Integridade do caderno:** conservar os **298.960 bytes exatos** de CP-28 v2.6 como prefixo literal; apor somente este CP-29, sem corrigir retroativamente erros ou apagar frentes negativas. **Índice:** manter as 144 linhas originais sem alteração e apor somente [0145]–[0147]. Nenhum DOI, comentário, estado de leitura ou duplicata removida no índice slim.

**Fontes primárias:** [0145] https://arxiv.org/abs/0705.1574 ; [0146] https://arxiv.org/abs/0811.0421 ; [0147] https://arxiv.org/html/0907.5391v4 ; [0138] https://arxiv.org/abs/1811.05482 ; [0141] https://arxiv.org/abs/1902.02844 . **Fontes HRF:** Cap0.1 https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view ; Cap3 v0.3 https://drive.google.com/file/d/1jE3HDVpuoBt5QHZfo-E54dBHxhOc1d9R/view ; PD https://drive.google.com/file/d/1qME30Vk0rVC8ejYQwI1wOGt4TPC8JWrw/view ; CP-28 https://drive.google.com/file/d/1euXBBneV7Lp5mao_70kARDONviC-9_qU/view .
