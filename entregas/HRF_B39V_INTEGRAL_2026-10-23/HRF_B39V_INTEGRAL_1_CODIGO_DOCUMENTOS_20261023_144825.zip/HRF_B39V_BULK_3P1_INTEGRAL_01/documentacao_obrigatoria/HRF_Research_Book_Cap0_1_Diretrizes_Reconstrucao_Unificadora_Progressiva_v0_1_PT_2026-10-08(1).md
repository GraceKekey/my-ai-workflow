# Capítulo 0.1 — Diretrizes de Reconstrução Unificadora Progressiva

**Framework:** Holographic Reconstruction Framework (HRF)  
**Programa:** *Holographic Reconstruction of Physics*  
**Versão:** v0.1  
**Data:** 8 de outubro de 2026  
**Posição no livro:** Research Book — Capítulo 0.1 (fundamentos metodológicos)  
**Tipo:** diretriz metodológica transversal / capítulo de orientação do Projeto  
**Estatuto:** [D] orientação estratégica aprovada pelo pesquisador; não é resultado de validação física.

## 0.1.1 — Decisão estratégica central

**[D] Começar pela opção B para investigar progressivamente a opção A.**

- **B — arquitetura integradora:** reunir partes relevantes da física estabelecida, preservar seus domínios de validade, estabelecer interfaces matemáticas e identificar as lacunas reais.
- **A — reconstrução a partir de fundamento comum:** investigar se essas partes podem ser derivadas, em regimes e limites apropriados, de uma estrutura física mais geral, eventualmente pré-geométrica.
- **Trajetória B → A:** a integração é o método de trabalho imediato; a unidade fundamental é uma meta de pesquisa, **não uma premissa demonstrada nem um destino garantido**.

Nome de trabalho para essa estratégia: **Reconstrução Unificadora Progressiva (RUP)**. RUP designa uma metodologia de pesquisa **dentro do HRF**, não uma renomeação do framework nem uma teoria física adicional.

## 0.1.2 — Princípio de integração física

> O HRF deve preservar e reutilizar resultados estabelecidos da física sempre que forem matematicamente compatíveis. Sua investigação original deve concentrar-se nas interfaces não demonstradas, nos mecanismos ausentes e na reconstrução coerente de uma descrição física integrada.

**[D] Não exigir originalidade de cada componente.** Um resultado que possui explicação satisfatória na física existente pode ser incorporado e referenciado, desde que suas hipóteses e limites sejam respeitados. A eventual contribuição própria do HRF pode residir nas correspondências, derivações comuns, mecanismos de conexão e previsões da arquitetura integrada.

**[D] Não confundir justaposição com unificação.** Usar equações de duas teorias lado a lado não demonstra que derivem de um mesmo sistema físico. A interface deve estabelecer o mapa relevante de estados, observáveis, simetrias, dinâmica e condições de validade.

## 0.1.3 — Regras práticas permanentes

1. **Consultar a documentação do HRF antes de reconstruir o modelo.** Priorizar os arquivos anexados ao Projeto; recorrer à biblioteca HRF no Google Drive se necessário e à literatura externa quando o problema exigir.
2. **Reaproveitar a física conhecida.** Não gastar recursos tentando redescobrir leis já estabelecidas; verificar, sim, sua aplicação à bancada específica.
3. **Separar componentes e interfaces.** Para cada ligação entre modelos, registrar entrada, saída, hipóteses, espaço de estados, operadores, observáveis, simetrias, leis de conservação e limites.
4. **Localizar exatamente o mecanismo faltante.** Uma lacuna não deve ser preenchida por vocabulário (“holografia”, “emergência”, “confinamento”) sem equações.
5. **Buscar reduções controladas.** Quando duas descrições compartilham um setor, tentar construir equivalência, limite efetivo ou mapeamento parcial; não exigir identidade total sem fundamento.
6. **Executar primeiro análises econômicas.** Preferir provas analíticas, análise dimensional, correspondência espectral, reprocessamento arquivado e controles pequenos antes de grandes simulações.
7. **Testar principalmente as costuras.** Os testes novos devem avaliar se a interface preserva propriedades e produz consequências não inseridas por definição.
8. **Preservar falhas e alternativas.** Resultados negativos, aproximações insuficientes e interfaces incompatíveis devem permanecer no registro.
9. **Não impor teleologia.** Se não houver redução a uma base única, manter uma arquitetura efetiva integradora, sem declarar a meta fundamental alcançada.
10. **Consolidar proveniência.** Registrar versões de documentos, protocolos, códigos, parâmetros e distinção entre decisões históricas e correntes.

## 0.1.4 — Classificação epistemológica HRF

- **[F]** resultado físico ou matemático estabelecido, com domínio de validade explicitado;
- **[M]** resultado de modelo matemático, cálculo ou simulação do HRF;
- **[H]** hipótese de conexão ou mecanismo ainda não demonstrado;
- **[?]** questão aberta, incluindo robustez ou incompatibilidade não resolvida;
- **[D]** decisão metodológica ou editorial.

Regras: **[M] não implica evidência empírica; aproximação formal não implica identidade física; imagem reconstruída não implica partícula; êxito numérico de uma peça não valida sua conexão com as demais.**

## 0.1.5 — Critérios mínimos para aceitar uma “costura”

Para ligar dois setores teóricos, documentar, quando aplicável:

| Critério | Pergunta de auditoria |
|---|---|
| Graus de liberdade | O que existe em cada descrição? Quais são físicos, redundantes ou efetivos? |
| Espaços de estados | Há mapa entre estados clássicos/quânticos? É invertível, aproximado ou restrito? |
| Dinâmica | Hamiltonianos/ações/equações correspondem em que limite? |
| Simetrias e gauge | Quais invariâncias e restrições são preservadas? |
| Observáveis | Energias, correlações, entropias e fluxos têm definições comparáveis? |
| Conservação e causalidade | O mapa respeita os balanços, limites causais e condições de contorno? |
| Escalas e parâmetros | Há constantes, cortes, regularizadores ou dados ajustados ad hoc? |
| Quantização | A equivalência clássica sobrevive ao nível quântico? |
| Testabilidade | Que resultado separaria a conexão proposta de uma simples analogia? |
| Proveniência | Quais arquivos, versões e execuções sustentam cada afirmação? |

Uma interface pode receber estatuto de **correspondência parcial** sem ser promovida a equivalência integral. Se alguma propriedade ainda não foi estudada, registrar **PENDING/NOT_TESTED**, não PASS.

## 0.1.6 — Aplicação imediata aos programas atuais

### 6.1 CAP2 — modo fotônico relacional

**[M]** O Capítulo 2 documenta um setor relacional de conexões orientadas \(U_{nm}=e^{ia_{nm}}\), laços, gauge e operador discreto *curl–curl*, com resultados de bancada no domínio indicado pelos relatórios. **[?]** Sua correspondência integral com implementações posteriores e a recuperação física completa devem ser avaliadas por gates próprios.

### 6.2 E-67 — excitação gaussiana e reconstrução operacional

**[M]** O E-67 registra respostas entrópicas de um estado gaussiano apertado em campo escalar Z, com classificações históricas H67 = SIM — regime não linear, H67-N = NORMALIZÁVEL e H67-Z = PROPORCIONAL, estritamente segundo critérios operacionais; VL falhou em \(w=7\), fecho dessa largura não foi medido e não houve evolução temporal nem refinamento espacial.

**[D]** Explicações convencionais de teoria gaussiana, entropia e escala podem ser incorporadas. Não é obrigatório demonstrar novidade física em cada característica do E-67. Entretanto, para reivindicar *bulk* físico, modo material ou partícula, continuam necessárias as definições e validações independentes correspondentes.

**[H] Ponte prioritária:** testar matematicamente se o campo Z corresponde ao setor livre fora do plano \(A_z\) de uma conexão tridimensional U(1) reduzida a 2D, preservando estrutura canônica, operador, energia, gauge residual, espectro e álgebra de observáveis. Uma equivalência perturbativa parcial não deve ser confundida com equivalência completa, especialmente em setores globais ou compactos.

### 6.3 CAP3 — confinamento dinâmico

**[M]** As bancadas clássicas intermediárias demonstraram aspectos de propagação e transporte, mas não certificaram confinamento fotônico dinâmico completo; a bancada Yee 2D3V apresentou falha de convergência espacial da cavidade e não executou a fase longa. **[D]** Resolver convergência e gate CAP2 antes de atribuir identidade fotônica ao campo confinado.

**[?]** Confinamento de energia clássica não implica alteração entrópica, partícula quântica ou normalizabilidade holográfica. A ligação posterior requer Hamiltoniano quantizado, estados, covariâncias (ou métodos não gaussianos), observáveis e regras de reconstrução justificadas.

### 6.4 Meta maior de matéria e espaço-tempo

**[H]** Investigar se uma arquitetura relacional comum pode recuperar, em limites apropriados, campos, geometria, ondas, estados ligados e matéria. **[?]** Ainda não estão derivados do mesmo mecanismo carga eletrônica, spin 1/2, estatística fermiônica, massa do elétron, gravitação emergente ou uma dualidade holográfica física geral. Esses itens não devem ser inferidos a partir de formas visuais no bulk.

## 0.1.7 — Priorização e economia científica

Prioridade padrão:

1. **Auditoria documental e matemática da interface.**
2. **Reanálise dos dados existentes e prova em modelos mínimos.**
3. **Testes pequenos de correspondência entre operadores e observáveis.**
4. **Controles adversariais, refinamento e convergência.**
5. **Simulações extensas de dinâmica acoplada, somente após gates anteriores.**

A prioridade imediata sugerida para o ciclo E-67/CAP2/CAP3 é a **derivação de correspondência Z ↔ A_z**, como investigação analítica de interface. O controle adversarial gaussiano E67-68 continua disponível para testar interpretações holográficas fortes, mas não é condição para aproveitar os resultados matemáticos conhecidos do E-67 como ferramenta descritiva.

## 0.1.8 — Como avaliar progresso em direção à opção A

Uma integração B aproxima o HRF da reconstrução A somente quando **reduz pressupostos independentes** ou **deriva relações antes introduzidas separadamente**, mantendo ou ampliando o poder explicativo.

Indicadores de progresso:

- mapa explícito de equivalência ou redução entre setores antes distintos;
- parâmetros que deixam de ser escolhidos independentemente e passam a ser derivados;
- simetrias ou leis de conservação recuperadas da formulação mais geral;
- observáveis quantitativos reproduzidos sem ajuste posterior específico para cada caso;
- previsões e limites de validade verificáveis;
- identificação inequívoca dos problemas ainda não resolvidos.

A redução ontológica a uma realidade fundamental única é **objetivo de longo prazo [H]**, não critério para declarar sucesso de toda bancada intermediária.

## 0.1.9 — Orientação para pesquisadores e chats do Projeto

Ao iniciar uma nova análise HRF:

1. Identificar a pergunta e o setor do projeto.
2. Consultar primeiro os documentos pertinentes anexados diretamente ao Projeto e usar o esqueleto como mapa estrutural.
3. Recuperar a fonte especializada ou o Drive apenas se necessário.
4. Declarar quais leis já conhecidas podem ser incorporadas e quais conexões permanecem hipóteses.
5. Propor primeiramente a menor derivação ou experimento capaz de testar a **interface** desejada.
6. Reportar resultados positivos, negativos, não medidos e não executados com a classificação [F]/[M]/[H]/[?]/[D].
7. Não apresentar analogias, nomenclaturas ou diagramas como derivação física.
8. Manter o nome atual **Holographic Reconstruction Framework (HRF)**. Conservar PRFE, C1–C5, C5A/C5B e PGFE apenas para documentação histórica e proveniência quando pertinente; na formulação corrente usar **sistema físico / subsistema físico**, sem introduzir PGFE como ente fundamental.

## 0.1.10 — Síntese da diretriz

> **Começar com B e trabalhar em direção a A.** Integrar de maneira rigorosa as ferramentas da física conhecida; demonstrar as interfaces; acrescentar apenas os mecanismos necessários; investigar se a integração pode ser progressivamente reconstruída a partir de fundamentos comuns, sem presumir antecipadamente que essa redução seja possível ou única.

**Esta diretriz orienta o programa; não altera retroativamente os relatórios históricos nem transforma hipóteses em resultados.**

## 0.1.11 — Referências documentais internas

- `HRF_Esqueleto_Research_Book_v0_1_PT.md` — estrutura geral, classes epistemológicas, objetivos e proveniência.
- `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_1_PT_2026-10-05.md` — estrutura do modo fotônico relacional.
- `RELATORIO_E67_FINAL_v0_2.md` — resultados históricos do E-67.
- `RELATORIO_AUDITORIA_POST_E67_v0_1.md` — reprodução do pós-processamento e limites de auditoria.
- `RELATORIO_CIENTIFICO_CAP2_v0_2.md` — resultados e falhas da bancada Yee 2D3V.

**Nota de proveniência:** as diretrizes das seções 1–3, 5, 7–10 são consolidação metodológica da decisão do pesquisador neste diálogo. Não são apresentadas como extraídas de experimentos.
