# A base quântica compartilhada e a emergência das organizações físicas

Caderno completo de pesquisa · Versão 0.2 · 22 de outubro de 2026

HRF-OLA \| Consolidação provisória \| \[F\] Física estabelecida · \[M\]
Modelo · \[H\] Hipótese · \[?\] Aberto · \[D\] Decisão

# Sumário

- Nota editorial e estatuto

- Resumo científico

- 1\. Alcance, método RUP e abertura ontológica

- 2\. Dicionário conceitual e nomenclatura

- 3\. Evolução histórica e versões arquiteturais

- 4\. Arquitetura física mínima

- 5\. Base relacional, Quantum Graphity e mudança para onipresença

- 6\. Emaranhamento, informação e reconstrução holográfica

- 7\. Resposta modal e seletividade

- 8\. Identidade, topologia, espectro e o GMFt sombreado

- 9\. Interface com Capítulo 2, geometria e o antigo Capítulo 3

- 10\. Banco de evidências B31 — B37

- 11\. Quadro comparativo e tensões não resolvidas

- 12\. Programa de formalização e testes futuros, não executados

- 13\. Definições matemáticas propostas e riscos

- 14\. Bibliografia e proveniência

- 15\. Conclusão e decisões mantidas em aberto

# Nota editorial e estatuto

\[D\] Este volume é a proposta de reformulação do Capítulo 3, aprovada
em conversa em 21/10/2026. A expressão oral “capítulo 13” no pedido
final é interpretada contextual e provisoriamente como Capítulo 3, que
foi discutido e aceito imediatamente antes. Não houve autorização para
substituir irreversivelmente os arquivos antigos.

Título de trabalho: \*A base quântica compartilhada e a emergência das
organizações físicas\*.

Estatuto: caderno completo de consolidação da pesquisa disponível,
versão 0.1, não uma formulação fisicamente validada. Esta edição integra
resultados B31, B31R, B33, B35 e B37; notas OLA de 20–21/10; Capítulo
0.1 RUP; esqueleto do Research Book; e o histórico do Capítulo 3. Não
integra resultados futuros, nem presume que a bibliografia externa
esteja exaustivamente auditada. \[M\] designa apenas resultado interno
de modelo ou simulação. \[F\] significa física ou matemática
estabelecida em condições especificadas. \[H\] hipótese própria. \[?\]
lacuna. \[D\] decisão.

O Capítulo 2 continua dedicado à \*\*onda fotônica livre\*\*, sem
reivindicar que a onda da B31/B31R seja automaticamente o fóton do
Capítulo 2. O Capítulo 4 mantém a agenda de estados ligados e massa
emergente; o Capítulo 5, o elétron. A designação histórica de Capítulo 3
como \*Dynamical Microstructure\* permanece rastreável, incluindo
arquivos e modelos de espuma mecânica, que não são apagados por esta
reorganização.

## Atualização editorial v0.2 — DIO e GMFt \[D/H\]

Esta v0.2 consolida integralmente o Capítulo 3 v0.1 de 21/10/2026 e
incorpora a Nota HRF-OLA — Identidade Relacional Distribuída v0.2, de
22/10/2026. Os resultados e números das bancadas B31–B37 não foram
recalculados nem reclassificados. Não substitui os protocolos e
relatórios primários.

Decisão terminológica corrente proposta: DIO (Distributed Informational
Organization) designa uma organização informacional distribuída
candidata a preservar a identidade na base quântica compartilhada; GMFt
designa a manifestação local associada à DIO. No texto herdado da v0.1,
ocorrências de “GMFt” que denotam organização persistente antes dessa
separação são usos históricos. Sua leitura na nova arquitetura requer
mapear explicitamente se o referente é DIO, GMFt ou um vértice efetivo.

DIO é hipótese de organização, não entidade fundamental demonstrada nem
subsistema ontológico adicional à base. A nova redação não afirma
emergência já derivada de partículas, métrica, causalidade, fótons,
massa ou holografia completa. O novo vocabulário não altera a
proveniência de GMF, Quantum Graphity, SYK ou PGFE histórico.

# Resumo científico

A Hipótese Ola (HRF-OLA) investiga se organizações físicas persistentes
— \*\*GMFt\*\*, operacionalmente representáveis por vértices em grafos
efetivos — pertencem a uma \*\*base quântica compartilhada\*\*, de tal
maneira que relações, respostas seletivas e manifestações observáveis
derivem da dinâmica e da informação disponível na base, sem postular
ligações fundamentais diretas entre todos os GMFt. Um GMFt pode estar
presente mas \*\*sombreado\*\* num conjunto de observáveis, enquanto a
base permanece dinâmica. Relações aparentes entre A e C não exigem
transmissão por B, ainda que causalidade e propagação continuem
restritas pelo Hamiltoniano e pela estrutura de observáveis.

A arquitetura incorpora, como conjectura independente, a ideia histórica
de informação quântica distribuída no lado \*\*R′\*\* e recuperável
parcial ou coletivamente no lado \*\*R\*\*. Não está decidido se R e R′
representam duas boundaries fisicamente distintas ou descrições
complementares. A nova possibilidade de identificar a relação GMFt–base
com emaranhamento entre uma subálgebra e seu complemento é igualmente
conjectural; emaranhamento, resposta e recuperação quântica são
operações distintas.

Resultados numéricos anteriores apoiam propriedades de modelos
especializados: B31/B31R investigaram álgebras de células e relações e
propagação entrópica sobre rede triangular fixa; B33 encontrou
assinatura e espalhamento por vórtice compacto; B35 estudou seleção e
sombreado em grafos; B37 comparou base livre onipresente com SYK e
testou persistência espectral durante apagar/religar. Nenhum desses
resultados, isoladamente, prova a totalidade da hipótese holográfica,
uma ontologia de variáveis ocultas ou um mapa físico R′→R.

# 1. Alcance, método RUP e abertura ontológica

\[D\] RUP: começar pela integração rigorosa da física estabelecida (B)
antes de procurar uma redução a fundamento comum (A). Interfaces
requerem mapas explícitos de espaços de estados, operadores, dinâmica,
simetrias, causalidade e escalas. As tentativas malsucedidas permanecem
registradas. Não se infere equivalência física de igualdade numérica
parcial.

\[D\] Abertura ontológica: não pressupor completude ontológica da
mecânica quântica. Admitir investigar variáveis ocultas, dinâmicas
determinísticas e estruturas não verificáveis imediatamente, sem
confundir liberdade especulativa com refutação de leis demonstradas.
Bell e Kochen–Specker impõem restrições às combinações específicas de
hipóteses, não proíbem toda ontologia com variáveis ocultas. O HRF
permanece obrigado a recuperar, em regimes correspondentes, os dados de
física estabelecida.

\[?\] A hipótese de que superposição possa codificar ignorância de
variáveis mais profundas não está demonstrada. Também não há derivação
HRF do espectro quântico, da regra de Born ou da estrutura
relativística. O valor da hipótese pode residir numa arquitetura
matemática, mesmo antes de existir um teste empírico viável.

# 2. Dicionário conceitual e nomenclatura

Base quântica compartilhada: todo sistema quântico global cuja dinâmica
e estado comportam organizações persistentes; no HRF-OLA corrente pode
ser modelada por graus de liberdade relacionais, matrizes aleatórias ou
interações SYK, sem exigir espaço geométrico fundamental.

GMFt: organização física persistente e individualizável da base,
representada por um vértice de um grafo efetivo; documentos de 21/10
também experimentam a decisão mais forte “GMFt = vértice do grafo QG”.
Essas versões não devem ser tratadas como ontologicamente equivalentes
sem explicitar qual grafo é microscópico e qual é efetivo.

GMF histórico: vértice ou grau de liberdade da triangulação Delaunay no
HRF-FM/B31/B33. Não é sinônimo de GMFt. PGFE permanece nomenclatura
histórica, não ente fundamental da formulação corrente.

Sombreado: organização presente sem manifestação no canal considerado.
Distinguem-se no modelo de relações carregado (carga líquida não nula),
atravessado (relações excitadas incidentes mas carga resultante nula) e
totalmente sombreado (relações incidentes desligadas). Estes são
critérios diferentes; uma sombra operacional em resposta pode não
equivaler a ausência de excitações em todas as relações.

Ausente: inexistência da organização naquele recorte de estado. Para
distinguir sombreado e ausente, é necessário observável físico ou
testemunha dinâmica e não apenas rótulo de vértice.

Manifestação: resposta observável de organização a excitação, medição ou
operação de recuperação; não é automaticamente o produto de um decoder
quântico.

Ola: alteração coletiva da base com assinatura de
propagação/correlações/entropia, sujeita à escolha do observável. Não se
identifica com transporte instantâneo de sinal nem com o fóton físico
sem mapa.

R e R′: nomes da hipótese histórica de informação
concentrada/recuperável versus informação distribuída; permanecem em
aberto duas boundaries físicas ou descrições distintas de um estado. Não
confundir automaticamente com R e complemento R̄ no formalismo padrão.

## 2.1. Vocabulário corrente: base, DIO, GMFt e manifestação \[D/H\]

Base quântica compartilhada: sistema físico global ao qual se atribuem
estado, álgebra de observáveis e dinâmica. O termo “compartilhada” não
estabelece que a base seja um espaço geométrico, uma CFT, ou um
substrato ontológico comprovado.

DIO — Distributed Informational Organization (Organização Informacional
Distribuída) \[H\]: padrão físico candidato de
informação/correlações/algebra de observáveis da base, possivelmente com
assinatura historicamente estabilizada e sem suporte espacial único
obrigatório. O critério para individualizar uma DIO sem rotulagem
externa ainda não foi definido.

GMFt \[H\]: manifestação física local ou contextual de uma DIO, se
existir um mecanismo dinâmico capaz de produzi-la. GMFt não designa
automaticamente um nó microscópico, partícula elementar, fóton ou grau
fundamental. “Local” pode significar subálgebra/região operacional antes
de uma métrica emergente.

Sombreado reconstruível \[H\]: DIO cuja informação lógica permanece
recuperável por operação autorizada, embora o GMFt correspondente não
esteja manifesto no canal avaliado. Inacessibilidade em um teste isolado
não implica ausência, e memória residual não equivale a DIO presente.

Nota de proveniência: na redação herdada das seções seguintes, GMFt era
usado em sentido amplo de organização persistente. Essa definição antiga
não deve ser reinterpretada retroativamente como resultado de
reconstrução DIO→GMFt.

# 3. Evolução histórica e versões arquiteturais

20/10 – Documento inaugural: base comum, organizações persistentes,
analogia do estádio/ola, topologia candidata, separação entre
individuação e holografia, programa OLA-0 a OLA-5 não executado na
ocasião.

20/10 – Nota de vértices sombreados: GMFt representado por vértice;
organização pode existir sem manifestação; relações efetivas podem ser
mediadas pela base e não passar obrigatoriamente por vértices
intermediários. Modelo binário A_ij^ef = a_i a_j C_ij é só ferramenta
operacional.

20/10 – Nota R/R′: informação já codificada e dispersa na base;
recuperação parcial, seletiva, eventualmente vinculada a manifestações
de um GMFt em R. Indefinição persistente da interpretação física dos
lados.

21/10, 11h49 – Nota QG: preferência histórica pela base em graus das
\*relações\* e GMFt como vértices; três estados
carregado/atravessado/sombreado; problema da identidade do vértice sem
graus próprios.

21/10, 14h24 – Esboço B37: revisão posterior: a base não deve depender
de junções que obriguem interações a atravessar GMFt intermediários.
Escolhe estudar modelos onipresentes livre/GOE e interagente/SYK; GMFt
como organização da própria base; “relé” como seletividade, mantendo o
vínculo de base. A decisão posterior tem precedência operacional nesse
ponto, mas a QG inicial permanece como proveniência e caso comparativo.

21/10 – Diretriz ontológica: admitir incompletude da descrição quântica
e hipóteses sobre variáveis ocultas, mantendo disciplina matemática e
empírica.

21/10 – B37 concluída: dados de modelos onipresentes fornecem separação
operacional L/SYK, sem concluir holografia R/R′. A arquitetura aqui
permanece plural em modelos de referência, não uma teoria única fechada.

## 3.1. A formulação DIO/GMFt surgiu após as bancadas históricas \[D\]

A nota de 22/10/2026 acrescentou cinco hipóteses explícitas: H-OLA-IRD
(identidade relacional distribuída), H-OLA-HR (história relacional),
H-OLA-RE (revelação por estímulo), H-OLA-SR (sombreado reconstruível) e
H-OLA-ML (possibilidade de manifestações em diferentes regiões). É uma
ampliação conceitual posterior às bancadas B31–B37, não uma inferência
numérica já testada nelas.

A analogia da chamada telefônica ilustra a diferença entre
endereço/registro de identidade e manifestação. A ligação seletiva pode
revelar uma organização inacessível no escuro, mas silêncio não prova
ausência, e a resposta pode criar uma organização em vez de revelar
informação anterior. A analogia não é lei física.

# 4. Arquitetura física mínima

\[H\] Seja \\\mathcal A\_{\partial}\\ uma álgebra global de observáveis
da base, com estado \\\omega\\ e automorfismos temporais \\\alpha_t\\ em
contexto suficientemente bem definido. Cada organização candidata \\i\\
é identificada por uma família de observáveis efetivos \\\mathcal
A_i\subseteq\mathcal A\_{\partial}\\, um conjunto de marcas de
persistência e possíveis canais de manifestação \\M_i^{(k)}\\.

O conjunto de vértices \\V=\\v_i\\\\ etiqueta organizações \*\*sem lhes
adicionar automaticamente espaços de Hilbert físicos\*\*. Um grafo
observacional \\G\_\mathrm{ef}(t;k)\\ pode depender do canal \\k\\,
limiares de resposta e do estado global. Não é a geometria espacial.

No caso simples de fatorização \\\mathcal H=\mathcal H_i\otimes\mathcal
H\_{\bar i}\\, \\\rho_i=\mathrm{Tr}\_{\bar i}\rho\\ e
\\S_i=-\mathrm{Tr}(\rho_i\ln\rho_i)\\. Em gauge ou teoria algébrica de
campos, usar subálgebras e estados restritos em lugar da fatorização
ingênua. Emaranhamento da organização com o restante pode ser
persistente em canais de manifestação desligados.

O Hamiltoniano total é único, \\H\_\partial\\. A escrita \\H_B+\sum_i
H_i+\sum\_{i,\alpha} g\_{i\alpha} O_i B\_\alpha\\ é uma decomposição
\*\*operacional\*\*, não derivação da ontologia. Sem controlar a
decomposição, existe risco de dupla contagem da base e dos GMFt.

A ausência de resposta em um canal \\k\\ será declarada quando
\\\|\Delta\langle M_i^{(k)}\rangle\|\le\epsilon_k\\ no intervalo e nos
controles prescritos. Isso não implica inexistência, desenrolamento de
todas as ligações ou ausência de qualquer correlação.

## 4.1. Arquitetura mínima da nova hipótese \[H/?\]

A arquitetura proposta separa três objetos: (i) a base quântica
compartilhada B com estado ω e dinâmica α_t; (ii) uma DIO_i
caracterizada por uma família de observáveis/correlações e assinatura
candidata I_i; (iii) uma manifestação contextual GMFt\_(i,A)(t), cuja
produção requer uma operação física M\_(A,t) ainda não definida.

Relação esquemática (NÃO derivada): GMFt\_(i,A)(t) = M\_(A,t)\[DIO_i\].
A notação não permite contar DIO como sistema independente da base,
inserir energia sem fonte, transportar informação acima do limite causal
ou materializar uma partícula por mera leitura de entropia.

A assinatura candidata I_i poderia depender da história dinâmica de
relações H_i(t0:t) e do estado global ω(t). É indispensável identificar
portadores físicos dessa história e um testemunho anterior ao estímulo,
evitando definir identidade por um número de etiqueta.

Hipótese de terceira via: manifestações A e C podem ser expressões
diferentes da mesma DIO distribuída, sem viagem de um objeto localizado
e sem cópias independentes do mesmo estado quântico. A equivalência de
padrões é distinta de continuidade lógica, que por sua vez não decide
sozinha identidade ontológica.

# 5. Base relacional, Quantum Graphity e mudança para onipresença

\[F\] A Quantum Graphity explora grafos cujas ligações são graus de
liberdade e cuja conectividade pode participar da dinâmica. A versão
histórica do HRF-OLA tomou os vértices como GMFt e os estados das
relações como base. O documento de 11h49 usa valores
\\m_e\in\\-1,0,+1\\\\ e carga de extremidade \\Q_v=\sum\_{e\ni v}m_e\\,
com regras de carga, cordas e movimentos de ativação. Não se deve
confundir um vértice abstrato com defeito topológico.

\[D\] A nota posterior B37 rejeita exigir que a dinâmica da base seja
conduzida de junção em junção por vértices GMFt. Modelos de acoplamentos
de alcance global são empregados como laboratórios alternativos, não
como equivalências provadas com QG. Em muitos sistemas all-to-all
existem tempos de resposta, espectros e limites causais próprios; “sem
caminho via GMFt” não é sinônimo de comunicação instantânea.

\[?\] Em uma boundary holográfica genuína ainda seria preciso recuperar
dinâmica local/causal no setor de bulk pretendido. SYK é um candidato em
regimes AdS₂/JT, não AdS₄/CFT₃. Não supor que uma base de relações sem
geometria já seja uma CFT de dimensão espacial 2.

# 6. Emaranhamento, informação e reconstrução holográfica

\[F\] Para estado global puro bipartido, a entropia reduzida mede
emaranhamento. Para estados globais mistos, a mistura local não mede
isoladamente o emaranhamento. Correlações e resposta dinâmica são
propriedades distintas. Em modelos holográficos válidos, RT/HRT/QES liga
entropias apropriadas a superfícies geométricas extremas; não transforma
qualquer aresta de grafo em área do bulk.

\[H\] A relação GMFt–base poderia ser o emaranhamento entre \\\mathcal
A_i\\ e \\\mathcal A\_\partial\setminus \mathcal A_i\\, com a ressalva
algébrica de que o complemento não é sempre uma fatoração tensorial.
Emaranhamento \*\*não\*\* explica sozinho a ativação seletiva, e não
produz canal de sinal superluminal.

\[H\] A hipótese antiga R/R′ toma informação de um setor lógico
codificada de forma dispersa e recuperável por uma coleção adequada de
observáveis: um mapa de codificação \\V:\mathcal H_L\to\mathcal
H\_{R'}\\ e um canal de recuperação \\\mathcal R_A\\ podem satisfazer
\\\mathcal R_A(\mathrm{Tr}\_{\bar A}\[V\rho_L V^\dagger\])=\rho_L\\, sob
condições de código. Isso é \*\*exemplo de código\*\*, não mecanismo HRF
já construído.

\[H\] A reconstrução parcial poderia permitir o acesso a certos
observáveis lógicos de manifestação: \\O_i^{(+)}\\, \\O_i^{(-)}\\ e
outros. O “giro à direita/esquerda” é analogia de canal, não pressuposto
de pequena hélice física. Um GMFt poderia apresentar acesso a um
subconjunto, a ambos ou a nenhum. Caso nenhum observável da família seja
reconstruído \*\*ou\*\* apresente resposta, classificar o GMFt como
sombreado \*\*naquela família\*\*, mantendo explícita a diferença entre
\*reconstruibilidade em princípio\*, \*recuperação efetiva\* e
\*expectativa não nula\*.

\[?\] A informação ser codificada em R′ não implica que exista
transferência causal para R; se R e R′ forem boundaries físicas
separadas, deve-se especificar canal ou operação conjunta autorizada. Se
forem descrições do mesmo sistema, construir um mapa de operadores sem
violar não-clonagem. A frase “toda informação do universo em R′” é
hipótese maximalista que exige corte, capacidade e definição da álgebra.

# 7. Resposta modal e seletividade

Se \\f\_\alpha(t)\\ perturba um modo da base, a resposta linear de um
observável candidato \\M_i\\ é, em hipóteses de equilíbrio/causalidade
de Kubo,

\\\delta\langle
M_i(t)\rangle=\sum\_\alpha\int\_{-\infty}^{t}\chi\_{i\alpha}(t,t')
f\_\alpha(t')dt'.\\

Uma susceptibilidade pode ser escrita com comutador apropriado,
\\\chi\_{i\alpha}(t,t')\propto
(i/\hbar)\Theta(t-t')\langle\[B\_\alpha(t'),M_i(t)\]\rangle\\, com
convenção de sinais consistente. Dois GMFt distintos podem responder ao
mesmo modo, enquanto um terceiro não responde. Não há obrigação de a
resposta seguir caminhos por vértices intermediários.

A susceptibilidade depende do estado, das simetrias, dos operadores e do
espectro. No modelo operacional B37, \\\Omega_i\\ representa sintonia
espectral e \\g_i\\, intensidade ou prontidão de acoplamento. Nem
\\\Omega_i\\ nem \\g_i\\ demonstram recuperação de informação codificada
em um código quântico.

\[?\] Construir um discriminador entre seletividade de ressonância
convencional e seletividade de \*\*reconstrução informacional\*\*. Um
teste válido exigirá codificar informação lógica, definir conjuntos
autorizados de observáveis e medir fidelidade de recuperação, mantendo
controles espectrais idênticos.

## 7.1. Revelação por estímulo seletivo \[H\]

Definir antes do teste um estímulo físico f_α(t) e um observável
M\_(i,k) em canal k. A resposta controlada, quando a teoria de Kubo é
válida, pode ser expressa por δ⟨M\_(i,k)(t)⟩ = Σ_α ∫\_(−∞)^t
χ\_(i,k;α)(t,t′) f_α(t′) dt′. Isto é resposta quântica convencional; só
constitui evidência de DIO quando existir testemunha prévia independente
de identidade.

Separar quatro casos adversariais: (a) manifestação preexistente ativa;
(b) DIO com GMFt não manifesto mas recuperável; (c) memória ou padrão
residual após extinção da organização; (d) ausência de resposta por
canal desacoplado ou detector insuficiente. Proibir concluir “ausente” a
partir de um único não-toque.

# 8. Identidade, topologia, espectro e o GMFt sombreado

\[?\] A identidade persistente exige um critério não circular.
Conservação de carga \\\[H,Q\]=0\\ não basta para proteção topológica
nem para individualização de um objeto. Um vórtice XY, um setor
topológico de anyons, um estado ligado fora da banda e um modo escuro
são mecanismos diferentes.

Na B33, um vórtice é uma configuração definida por enrolamento ao redor
de plaqueta e não é o mesmo que um nó microscópico da triangulação. A
melhor interface provisória seria representar \*\*a organização
vorticial\*\* por vértice de um grafo \*\*efetivo de organizações\*\*,
não identificar cada nó Delaunay com um vórtice.

Na arquitetura QG estrita, um vértice com todas as relações desligadas e
sem grau interno pode ser indistinguível de um rótulo inoperante num
retrato congelado. Na arquitetura onipresente posterior, um sombreado
pode ter marcas espectrais, flutuações ou estado reduzido distinguível
de ausência. A diferença precisa ser definida por medidas e comparações
de mesma dimensionalidade, sem pressupor a resposta.

Proposta de marcadores de identidade: (i) fidelidade de estado reduzido
antes/depois de ciclo de apagamento e religamento; (ii) persistência de
setores de superseleção ou cargas; (iii) estabilidade espectral separada
por gap; (iv) testemunhas de correlação com a base; (v) invariância sob
mudanças físicas admissíveis de representação. Nenhum marcador isolado
equivale a identidade ontológica absoluta.

## 8.1. Identidade distribuída, continuidade e reconstrução em vários locais \[H/?\]

H-OLA-IRD: a identidade candidata é associada a informação relacional
distribuída da base, não automaticamente a um único suporte espacial.
H-OLA-HR: a assinatura pode resultar de história de interações.
H-OLA-RE: intervenção seletiva pode revelar uma assinatura anterior.
H-OLA-SR: manifestação local ausente com informação lógica recuperável.
H-OLA-ML: subálgebras diferentes podem suportar representações ou
reconstruções alternativas.

Em teoria de correção de erros quânticos, a isometria de codificação V:
H_L → H_B e a recuperação R_A(Tr\_(Ā)(V ρ_L V†)) ≈ ρ_L fornecem um
referencial matemático conhecido \[F\], em domínios com fatorização
justificada. Em teorias gauge ou álgebras de operadores, usar restrições
de estados a subálgebras em vez de traço parcial ingênuo.

Reconstruir o mesmo operador lógico em regiões autorizadas não equivale
a produzir dois corpos simultâneos. Uma DIO só poderá ser interpretada
como entidade física individualizável mediante assinatura independente,
persistência, observáveis e dinâmica que discriminem DIO única, DIOs
equivalentes e registros extintos.

Testar a diferença entre reidentificação física, recuperação
informacional, ressonância seletiva e fabricação de nova instância.
Dados entrópicos isolados ou fidelidade de decoder elevada não provam
materialização física.

# 9. Interface com Capítulo 2, geometria e o antigo Capítulo 3

\[D\] O Capítulo 2 usa conexões orientadas U(1), laços, operador
discreto curl–curl e contratos de polarização para sua onda livre. As
ondas gaussianas B31/B31R e B33 usam outros graus de liberdade e não são
automaticamente o mesmo setor. A correção exigiria equivalência de
álgebra canônica, Hamiltoniano, simetrias de gauge, dispersão, energia,
polarização e propagação.

\[D\] O histórico Capítulo 3 \*Dynamical Microstructure\* incluía
malhas, deformação, cavidades, mecânica de espuma e estudo do
confinamento. Pacote
\`HRF_CAP3_GAMMA_BOHR_MECANICA_v0_3_2026-10-09.zip\` foi localizado e
permanece importante para proveniência. A nova redação não reivindica
que a microestrutura tenha sido derivada da base GMFt. A antiga agenda
pode permanecer em apêndice histórico, ou ser reacomodada posteriormente
por decisão editorial específica.

\[?\] Não existe aqui dicionário que transforme emaranhamento em métrica
geral, grafo all-to-all em boundary 2D ou organização de GMFt em
partícula material do bulk. A holografia exige modelos de referência
conhecidos, dimensões compatíveis e reconstrução explícita de operadores
e geometria.

# 10. Banco de evidências B31 — B37

Cada bancada deve ser lida segundo seu protocolo congelado, distinguindo
“apoio dentro do modelo” de evidência física externa. Esta seção resume
os relatórios entregues e não substitui as tabelas originais nem suas
auditorias.

B31 \[M\] — campo livre em rede: H-par global INCONCLUSIVA; B31a
INCONCLUSIVO devido controle de tamanho; B31b DUAL_EXATO no espectro não
nulo; B31c GAP_QUEBRA_CHM; B31d CONFIRMADA para passagem de excitação.
Igualdade de espectros de MᵀM e MMᵀ é algebricamente esperada e não
demonstra dualidade de campos fundamental.

B31R \[M\] — álgebras de células/relações e ola celular: H-par APOIADA
nos critérios próprios; B31aR LOCAL_CHM; B31e SEPARA; B31f1 EMERGE;
B31f2 OLA_CELULAR. Expoentes de informação mútua no intervalo ajustado:
cerca de −2,04/−2,08 células e −6,08 a −6,22 relações; picos propagam a
cerca de 0,936–0,938 em unidades da bancada, próximos à velocidade de
grupo. Os graus de liberdade são sítios em malha triangular fixa e dual
Voronoi, não GMFt topológicos demonstrados. A localidade modular é
aproximada e dependente dos controles.

B33 \[M\] — vórtice compacto e gap: B33a1 LOCALIZADO, relações APARECE;
B33a3 OLA_ESPALHADA; B33b1 LOG_PLACENTA; B33b2 PERSISTENTE; GMFt-vórtice
APOIADO no critério da bancada; B33c1 11 vezes SEPARACAO_ENFRAQUECE, um
caso INSUFICIENTE; B33c2 OLA_SOBREVIVE; gap global MISTO. Incremento de
entropia no núcleo ~36%; decaimento espacial aproximado d^-2,78; energia
vorticial logarítmica com razão da inclinação para πρ_s ~0,995. Evolução
de vórtice no ensaio de persistência é clássica, enquanto entropia usa
aproximação gaussiana sobre fundo clássico. Não é demonstração de
GMFt=um nó microscópico.

B35 \[M\] — grafos QG com junções: G1 EXATA_SO_COM_DEGENERESCENCIA; G2
INDEPENDENCIA_SO_NO_COMPLETO; G2b ESCURO_DISTINGUIVEL_DO_AUSENTE; G3
ORDEM_POR_DISTANCIA_DE_GRAFO; G4 sombreado dinâmico APOIADO. Escalas de
κ em janela protocolar ~κ^-2 para τ, ~κ^4 para diferença virtual. Esses
resultados são pertinentes ao modelo com junções, posteriormente
rejeitado como base fundamental obrigatória da Ola. Não devem ser
transferidos sem cálculo ao modelo onipresente.

B37 \[M\] — base onipresente livre L versus SYK S: L SUSTENTADA, S
CUSTO, L×S SEPARACAO, Q11 IDENTIDADE_POR_LACUNA; controle N28
CONSISTENTE. Base L mostrou seletividade por código (contrastes medianos
~35–48 segundo M/código); base SYK mostrou NAO_SELETIVA e classificação
térmica no regime observado. Organizações fora da banda preservam muito
melhor marcas após religamento do que organizações dentro da banda nos
controles exemplares. Expoentes de tamanho reprocessados anteriormente:
δ ~M^-0,320, marca espectral X ~M^-0,005, marca entrópica regularizada
~M^-1,049. Não confundir seleção por código energético com recuperação
de código lógico holográfico. A rodada já teve explorações prévias, não
é experimento cego.

Regra: “APOIADA”, “EMERGE”, “SUSTENTADA” e “IDENTIDADE_POR_LACUNA” são
os nomes dos gates internos de cada bancada, não alegações universais
sobre a natureza.

# 11. Quadro comparativo e tensões não resolvidas

\| Tensão \| Versões em disputa \| Estatuto \|

\|---\|---\|---\|

\| GMFt igual a quê? \| vértice literal QG vs organização representada
por vértice efetivo \| \[?\] requer mapa \|

\| Base onde? \| relações QG com junções vs graus onipresentes GOE/SYK
\| \[D\] preferência posterior pelo segundo como teste; não equivalência
\|

\| Sombra significa? \| todas relações desligadas vs ausência de
resposta no canal \| \[?\] especificar observável \|

\| Identidade \| vórtice topológico vs estado ligado fora da banda vs
estado reduzido estável \| \[?\] mecanismos não equivalentes \|

\| R/R′ \| boundaries físicas vs descrições complementares \| \[?\] não
decidido \|

\| Emaranhamento = vínculo? \| correlação estrutural vs canal dinâmico
\| \[?\] não suficiente \|

\| Ativação \| ressonância modal vs reconstrução lógica parcial \| \[?\]
discriminador ausente \|

\| Geometria \| grafo efetivo vs bulk gravitacional \| \[?\] mapa
inexistente \|

\| Causalidade \| sem GMFt intermediário vs instantaneidade \| \[F\] não
equivalentes \|

\| Determinismo \| variáveis ocultas vs formulação quântica atual \|
\[H\] ontologia não construída \|

A hipótese não precisa de resposta imediata a cada item, mas uma versão
publicável deve evitar afirmar simultaneamente proposições que tenham
significado matemático incompatível.

# 12. Programa de formalização e testes futuros, não executados

Etapa OLA-C3-0 — catálogo de graus de liberdade. Escolher um único
modelo de referência e escrever a álgebra global, os graus efetivos
atribuídos a organizações e o mapa sem dupla contagem. Definir de forma
inequívoca presença/ausência/sombra.

Etapa OLA-C3-1 — emaranhamento sem manifestação. Procurar estados de uma
única base em que subálgebra de B permaneça correlacionada/emaranhada
com o complemento mas uma família de respostas locais seja nula.
Controles: estado produto, excitado, misto, canal desacoplado, mudança
de observável, perturbações locais/globais.

Etapa OLA-C3-2 — seletividade e reconstrução. Introduzir codificação
lógica explícita V e conjuntos autorizados A_i. Medir fidelidades de
reconstrução de operadores distintos e comparar, com o MESMO espectro e
acoplamentos, a resposta de GMFt A/B/C. Falha em distinguir as
interpretações deve ser reportada.

Etapa OLA-C3-3 — identidade sombreada. Ciclo
sombra→reacoplamento→observação, com fidelidade reduzida, correlações e
um eventual invariante. Separar sombra operacional de desligamento total
do setor.

Etapa OLA-C3-4 — R/R′. Comparar duas realizações: (i) regiões/descrições
de mesmo sistema; (ii) dois setores físicos com recurso de
emaranhamento, mas sem transmissão antes de fornecer canal dinâmico.
Verificar não-clonagem, causalidade e domínios de decodificação.

Etapa OLA-C3-5 — correlação e geometria. Procurar se padrões de
reconstrução definem distância ou vizinhança efetiva; exigir critério
independente de métrica e controle adversarial com redes aleatórias sem
bulk físico.

Etapa OLA-C3-6 — interface campos/matéria. Só após gates anteriores:
comparar modo ola com setor fotônico CAP2 e identificação material do
CAP4/CAP5. Não inferir massa, spin ou carga de gráficos de entropia.

Governança: este caderno não autoriza automaticamente código, novas
bancadas, protocolos ou decisões ontológicas adicionais.

## 12.1. Bancadas propostas para DIO→GMFt — NÃO EXECUTADAS \[D/?\]

C3-DIO-0: escolher UM Hamiltoniano de referência da base e uma álgebra
observacional, com definição prévia de assinatura/identidade
independente de rótulos e sem dupla contagem DIO+base. Congelar casos
ativo, sombreado, extinto com memória e padrão reprodutível.

C3-DIO-1: construir intervenção seletiva com controles de canal
desligado, fonte nula, ruído e falsos positivos; demonstrar em leitura
anterior ao estímulo qual informação já estava presente e qual foi
criada pela intervenção.

C3-DIO-2: propor um código lógico explícito e medir, em diferentes
subálgebras, recuperação de observáveis/fidelidade, sensibilidade à
troca do suporte, energia, dinâmica e não clonagem; comparar com
ressonância sem código.

C3-DIO-3: apenas depois definir, se possível, M\_(A,t) como canal físico
de manifestação; verificar causalidade, conservação e critérios
independentes de presença material; distinguir mudança de local, mera
reexpressão de operador e nova entidade.

Critérios de gate: PASS somente dentro do toy model com grandezas bem
definidas; FAIL se o resultado depender de rotulagem arbitrária, mudança
do Hamiltoniano entre controles ou se a assinatura prévia não
discriminar memória residual; INCONCLUSIVE se os observáveis não puderem
decidir. Nenhum gate novo foi executado.

# 13. Definições matemáticas propostas e riscos

Definição candidata 1 (organização): dado \\(\mathcal
A\_\partial,\omega,\alpha_t)\\, um GMFt operacional é uma classe de
famílias \\\\O_i^{(a)}\\\\ com propriedade de reconhecimento persistente
durante janela \\T\\ e classe de perturbações \\\mathcal P\\. Deve-se
evitar definir reconhecimento em termos do rótulo \\i\\, sob pena de
tautologia.

Definição candidata 2 (sombra): para uma família prescrita de
intervenções \\\mathcal F\\ e leituras \\\mathcal M\\, a organização
\\i\\ é \\(\epsilon,T)\\-sombreada se todas as respostas controladas
estudadas forem inferiores a \\\epsilon\\ durante \\T\\, enquanto um
teste independente de presença/identidade for positivo. Sem teste
independente, “sombreado diferente de ausente” é apenas notação.

Definição candidata 3 (grafo de influência): \\A\_{ij}^{(k)}=1\\ se uma
susceptibilidade \\\|\chi\_{j\leftarrow i}^{(k)}\|\\ ultrapassa limiar
previamente fixado, com direção temporal e canal especificados. Uma
aresta mede influência ou resposta, não adjacência física presumida.

Definição candidata 4 (reconstruibilidade): um operador lógico \\O_L\\ é
\\\epsilon\\-reconstruível em A se existe \\O_A\in\mathcal A(A)\\ cuja
ação no subespaço de código aproxima \\O_L\\ com erro \\\epsilon\\ numa
norma bem declarada. Reconstruibilidade não implica valor esperado,
transferência nem manifestação automática.

Riscos: fatorização ilegítima de teorias gauge; escolha ad hoc de
limiares; dupla contagem; diferença de dimensão entre ensaios
ausente/presente; falso positivo de dualidade espectral; extrapolação de
N finito SYK; distinguir modo sombrio de vazio; identificação de grafo
all-to-all com causalidade emergente; transformar decisões históricas em
postulados atuais.

# 14. Bibliografia e proveniência

Fontes primárias internas consultadas nesta edição:

\-
\`HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_1_PT_2026-10-08(1).md\`
— método obrigatório.

\- \`HRF_Esqueleto_Research_Book_v0_1_PT-1.md\` — arquitetura do livro.

\- \`HRF_Research_Book_Cap01_Esqueleto_v0_1_PT_2026-10-05-1.md\` e
\`HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_1_PT_2026-10-05
(1).md\` — interfaces editoriais.

\-
\`HRF_OLA_Nota_Provisoria_GMFt_Vertices_Sombreados_Base_Compartilhada_v0_1_PT_2026-10-20.md\`.

\-
\`HRF_OLA_Nota_Arquitetura_R_Rlinha_Reconstrucao_Seletiva_GMFt_v0_1_PT_2026-10-20.md\`.

\- \`HRF OLA Nota Arquitetura Base QG Relacoes v0 1 PT 2026-10-21
1149-clau.pdf\`.

\-
\`HRF_OLA_Esboco_B37_Base_Onipresente_v0_1_PT_2026-10-21_1424-clau.md\`.

\-
\`HRF_Diretriz_Abertura_Ontologica_Variaveis_Ocultas_v0_1_PT_2026-10-21.md\`.

\- Relatórios \`RELATORIO_CIENTIFICO_B31.md\`,
\`RELATORIO_CIENTIFICO_B31R.md\`,
\`HRF_B33_Relatorio_PT_2026-10-21_0002-clau.md\`,
\`HRF_B35_RELATORIO_2026-10-21_125048.md\`,
\`HRF_B37_RELATORIO_2026-10-21_165612.md\`, extraídos dos cinco pacotes
ZIP anexados ao Projeto.

\- \`HRF_CAP3_GAMMA_BOHR_MECANICA_v0_3_2026-10-09.zip\` — proveniência
do antigo Capítulo 3.

Bibliografia científica de contexto, sem alegar auditoria bibliográfica
exaustiva: J. Maldacena (1998), \*The Large N Limit of Superconformal
Field Theories and Supergravity\*, hep-th/9711200; S. Ryu e T.
Takayanagi (2006), Phys. Rev. Lett. 96, 181602; A. Almheiri, X. Dong e
D. Harlow (2015), JHEP 04, 163, arXiv:1411.7041; D. Harlow (2017/2018),
\*TASI Lectures on the Emergence of Bulk Physics in AdS/CFT\* (PDF no
Projeto); T. Konopka, F. Markopoulou e L. Smolin (2006), \*Quantum
Graphity\*, hep-th/0611197; T. Konopka, F. Markopoulou e S. Severini
(2008), Phys. Rev. D 77, 104029; S. Sachdev e J. Ye (1993), Phys. Rev.
Lett. 70, 3339; J. Maldacena e D. Stanford (2016), Phys. Rev. D 94,
106002; J. S. Bell (1964), \*On the Einstein Podolsky Rosen Paradox\*;
S. Kochen e E. Specker (1967), \*The Problem of Hidden Variables in
Quantum Mechanics\*.

Limites de proveniência: esta consolidação lê os relatórios completos
preservados nos ZIPs e as notas disponíveis; ela não reexecuta solvers
nem revê todos os checkpoints individualmente. Os números resumidos
reproduzem registros das bancadas e auditorias já relatadas, não novas
medidas feitas para este capítulo. Documentos externos que não estejam
anexados não foram sujeitos a nova pesquisa exaustiva.

## 14.1. Fontes acrescidas à v0.2 \[D\]

HRF_OLA_Nota_Hipoteses_Identidade_Relacional_Distribuida_v0_1_PT_2026-10-22.md
— nota inicial de história, estímulo e identidade; preservada para
proveniência.

HRF_OLA_Nota_Hipoteses_Identidade_Relacional_Distribuida_v0_2_PT_2026-10-22.md
— fonte imediata desta revisão: decisão DIO/GMFt e
H-OLA-IRD/HR/RE/SR/ML.

Esta edição é uma integração documental e editorial, não uma nova
auditoria independente da literatura, códigos ou dados B31–B37.

# 15. Conclusão e decisões mantidas em aberto

O capítulo estabelece um \*\*programa coerente de investigação\*\*, não
uma teoria fechada. A base compartilhada pode sustentar organizações
reconhecíveis, respostas seletivas e correlações; os modelos B31–B37
demonstram partes desse vocabulário sob hipóteses diferentes, mas não
derivam uma ontologia única. Um GMFt sombreado pode ser postuladamente
persistente, porém sua identidade precisa de testemunha operacional
independente.

\[D\] Não decidir neste volume se R e R′ são boundaries distintas ou
duas descrições; não impor topologia como única fonte de identidade; não
escolher antecipadamente variáveis ocultas específicas; não atribuir às
oscilações estatísticas o estatuto de fótons ou partículas; não
identificar modelo SYK finito com holografia geral.

\[?\] Prioridade 1: demonstrar num modelo comum a coexistência de (a)
organização presente com identidade reconhecível, (b) emaranhamento com
base, (c) canal sombreado, (d) resposta seletiva e (e) recuperação de
informação lógica parcial, sem inserir essas propriedades por rótulo.

\[?\] Prioridade 2: construir dicionário entre representações de grafos,
campos e geometria. \[?\] Prioridade 3: obter uma previsão que distinga
a reconstrução informacional HRF-OLA de ressonância comum, correções
espectrais e códigos holográficos já conhecidos.

## 15.1. Síntese da atualização DIO/GMFt e decisões em aberto \[H/?/D\]

Hipótese atual: a identidade candidata pertence à organização
informacional distribuída DIO; localização e resposta pertencem à
manifestação contextual GMFt. Uma mesma DIO pode, em princípio, admitir
manifestações distintas sem postular transporte da própria identidade
como objeto localizado. O mecanismo de manifestação não foi construído.

Questões centrais: como distinguir DIO preservada de simples memória
histórica; quais operadores permitem atribuir GMFt_i,A e GMFt_i,C à
mesma DIO; como garantir que a intervenção não constituiu novo objeto;
quais limites de causalidade, energia, informação quântica e gauge
regulam as manifestações?

Decisão editorial: preservar integralmente números e rótulos históricos
B31–B37 e o Capítulo 3 v0.1; esta versão 0.2 é derivada e sujeita a
auditoria. Não executar nem declarar aprovação de novos testes.

Este documento é uma versão integral de consolidação científica do
Capítulo 3 para leitura e revisão; a integração editorial definitiva ao
Research Book depende de aprovação e auditoria posterior de consistência
com capítulos vigentes.

## Registro v0.1 → v0.2 \[D\]

\(1\) DIO adotado provisoriamente para organização informacional
distribuída; (2) GMFt reservado para manifestação local; (3) sombreado
descrito por reconstruibilidade, com controles de memória residual e
canal inacessível; (4) história relacional e estímulo seletivo
formalizados como hipóteses; (5) manifestações em mais de uma região não
equivalem a clonagem; (6) novas bancadas C3-DIO propostas e NÃO
EXECUTADAS.
