# Protocolo integral congelado antes de execução

## Objetivo

[D] Construir e testar extensões prescritas de B39V para três coordenadas espaciais e evolução temporal, separadas das referências de reconstrução AdS4. Seguir RUP B→A e distinguir G, W e D. Novas execuções autorizadas explicitamente depois do prompt inicial. Não alterar resultados históricos.

## Hipóteses

[F] Campo escalar covariante sobre métrica Lorentziana prescrita satisfaz (Box_g-m²)φ=J. O símbolo principal define os cones; em Minkowski a frente tem c=1 e a velocidade de grupo depende de massa e frequência. [M] FEM P1 e RK4 convergem em casos suaves controlados. [H] A extensão da superfície histórica pode conservar algumas assinaturas, mas 3D permite diluição e trajetórias adicionais; não pressupor amplitudes ou limiares equivalentes. [?] DIO, CFT dual e gravidade dinâmica não são definidos por esta dinâmica clássica.

## Parâmetros e protocolo

[D] config/gates.json fixa todos os limiares. smoke: duas rotações planas, 468 casas, t=90 (funcionamento apenas). standard: os 20 casos históricos G/T/M, t=460, mais seis controles (massa 0, massa 1.2, frequência 2.2, Neumann, dt/2 e fonte harmônica). high_resolution: mesmo catálogo e domínio, grade 415×415×81, admissão prévia de memória limitada a 16 GiB. Um bloqueio por memória é um resultado de planejamento; não representa simulação executada ou teste numérico aprovado. Standard não substitui alta resolução.

A fonte pulsada sin² atua por 60 unidades; standard deixa 400 unidades para evolução posterior. O controle harmônico permanece ligado intencionalmente. Parâmetros históricos de frequência, massa, G, amortecimento, largura em xy e razão da rede são preservados numericamente. Largura transversal 3 e espessura de extensão 15 são novas escolhas de modelo, identificadas. Caixa retangular e volume diferem do disco histórico. Acoplamento recíproco de osciladores e rede harmônica estacionária calculada no novo operador, sem reutilizar solução 2D como se fosse 3D.

## Método e medidas

[D] Estrutura Hamiltoniana: p é momento integrado; M_i=∫sqrt(γ)/N λ_i, K=∫N sqrt(γ)(γ^ij∂iλ∂jλ+m²λλ), potencial de massa concentrado; B=M^-1∫sqrt(γ)/N λ β·∇λ. qdot=M^-1p+Bq, pdot=-Kq-Bᵀp+F-G Cᵀx. A equação de oscilador é xddot+γ_R xdot+Ω_c²x=-G Cq. Energia H=(pM^-1p+qKq)/2+pBq+Σ(v²+Ω_c²x²)/2+G xCq. Fonte implementa J=-F perfil, portanto a carga fraca no momento é +∫N sqrt(γ)F perfil. Shift testado por identidade energética independente; cenários históricos usam β=0.

P1 tetraédrico em malha estruturada com seis tetraedros por cubo; massa concentrada e RK4 de ordem temporal quatro. Ordem espacial esperada dois em soluções suaves, certificada apenas nos controles de convergência. Geometria histórica interpolada por triângulos é apenas por partes suave; não se presume a mesma ordem ali. Receptores amostrados trilinearmente; adjunto do mesmo operador no acoplamento garante reciprocidade discreta.

Conexão/curvatura por diferenças centrais da métrica. Testar R_AdS=-12/L² e T efetivo de vácuo com Λ=-3/L²; métrica prescrita genérica não satisfaz automaticamente equações de matéria. Geodésicas com solve_ivp. Fronteiras Dirichlet, Neumann ou esponja mais Dirichlet exterior. Esponja não é PML perfeita; reflexões precisam ser comparadas. Energia é Hamiltoniana total, não proxy φ²+p². Fluxo Euleriano final é diagnóstico vetorial médio, não luminosidade superficial integrada.

## Decisões e controles

[D] Testes de software incluem falsos candidatos, entradas inválidas, ramos PASS/FAIL/INCONCLUSIVE/BLOCKED e retomada. Ordem espacial ≥1.5 e temporal ≥3.5; deriva energética estática ≤1e-6; erro de curvatura AdS ≤1e-4; fuga exterior relativa L2 ≤0.02 na região r>2.5 para suporte inicial r<1 após t=.5. Este último é limiar de discretização, não prova de suporte causal exato. KG contínuo e cones são checados separadamente.

RT: referência radial de duas amplitudes com faixas de treino e teste disjuntas; reproduzir controle de vácuo e holdout ≤.02, erro de parâmetros ≤.03 segundo avaliador histórico preservado. HKLL: seis modos normalizáveis AdS4 com 80 amostras boundary e 37 bulk retidas; posto 6, condição <1e6, erro de reconstrução/correlador <1e-9 e resíduo KG <1e-4. O campo bulk retido não entra no ajuste. AdS é dado de entrada, não reconstruído pelo HKLL.

Novo dicionário recebido durante implementação, antes do freeze: testar m²L²=Δ(Δ−3); kernel euclidiano Δ=2/m²=-2, normalização integral e resíduo KG; solução regular φ=z exp(-kz)J para resposta GKPW A=-kJ e derivada de W renormalizado; FG g2 e traço de T em dados algébricos; representação lógica Z e controle negativo X no código de repetição. Fórmulas gerais não fornecem estados HRF, CFT3 ou isometria física. O kernel euclidiano não é renomeado HKLL lorentziano.

## Limites e arquivos

[?] Transferência exige fonte resolvida com ≥3 células por σ e ≥12 por comprimento de onda, convergência espacial/temporal e independência de contorno, além de erros de chegada ≤5%, resposta ≤10% e fração seletiva ≤2%. Falta de certificação → INCONCLUSIVE, falha quantitativa certificada → FAIL. Não ajustar limiar com resultados novos. Nenhum PASS numérico valida ontologia. HRT/QES sem solver/estado variacional definidos → BLOCKED. Interface HRF: BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY. Leia os documentos auxiliares e o manifesto congelado.
