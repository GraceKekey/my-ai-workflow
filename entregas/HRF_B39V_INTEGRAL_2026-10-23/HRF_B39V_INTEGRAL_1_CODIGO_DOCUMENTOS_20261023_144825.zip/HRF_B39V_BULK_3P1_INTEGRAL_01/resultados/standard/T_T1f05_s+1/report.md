# T_T1f05_s+1

[M] EXECUTED, 468 receptores, 4600 passos.

[D] Gate INCONCLUSIVE: malha não certifica transferência histórica.

[?] Chegada do campo, leitura seletiva e relé são colunas distintas. DIO permanece BLOCKED.
