# C_half_dt

[M] EXECUTED, 468 receptores, 9200 passos.

[D] Gate INCONCLUSIVE: malha não certifica transferência histórica.

[?] Chegada do campo, leitura seletiva e relé são colunas distintas. DIO permanece BLOCKED.
