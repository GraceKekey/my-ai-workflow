# Fontes e proveniência

[D] Documentos do usuário preservados integralmente em documentacao_obrigatoria/: Cap0_1 v0.1 (08/10), Cap03 v0.2 (22/10), Caderno v2.7 CP29 e Dicionário AdS/CFT v0.1 (23/10). O caderno menciona versões posteriores dos capítulos; a presente rodada usa os arquivos efetivamente fornecidos. Não se afirma auditoria independente das provas dos artigos citados.

[F] RT: Ryu–Takayanagi, PRL96 181602, doi:10.1103/PhysRevLett.96.181602. HRT: Hubeny–Rangamani–Takayanagi, JHEP2007 062, doi:10.1088/1126-6708/2007/07/062. HKLL: Hamilton–Kabat–Lifschytz–Lowe, PRD74 066009, doi:10.1103/PhysRevD.74.066009. GKPW: hep-th/9802109 e hep-th/9802150. FG: de Haro–Solodukhin–Skenderis, hep-th/0002230. FLM: doi:10.1007/JHEP11(2013)074. JLMS: doi:10.1007/JHEP06(2016)004. Condições e escopo estão explicitados nos documentos fornecidos. Nenhum novo ID HRF-REF foi atribuído.

[M] Fontes computacionais anteriores em historico/B39V, bulk_anterior, holo01, holo02 com identificações e manifestos originais. Dados históricos são evidência do modelo original e não resultados novos do volume. Os relatórios negativos e o bug do protótipo HOLO02 são preservados. Código novo em hrf_integral/ não substitui essas versões.
