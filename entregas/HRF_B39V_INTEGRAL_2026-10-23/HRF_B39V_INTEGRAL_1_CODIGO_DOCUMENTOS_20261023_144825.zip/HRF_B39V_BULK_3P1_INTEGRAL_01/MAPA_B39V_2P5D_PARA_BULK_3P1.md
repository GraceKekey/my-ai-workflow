# Mapa histórico → candidato volumétrico

[D] Os códigos em historico/ são cópias identificadas, não novas versões dos resultados. `history.audit` gera correspondencia.csv. As 468 casas originais são exatamente preservadas em (x,y,0); a coordenada z passa a ser direção transversal, não altura h da superfície. Receptores volumétricos adicionais são aceitos como quaisquer pontos no domínio da classe System.

[M] Extensão candidata: H(x,y,z)=h_hist(x,y) exp[-z²/(2·15²)], γ_ij=δ_ij+∂iH∂jH. Na fatia z=0 o bloco xy reproduz a métrica induzida original por partes e a direção z é adicional. h é resolvido pelo código histórico idêntico com todos os GMFt antigos e idades de sementes 44/45, depois interpolado linearmente. Fora do disco histórico h=0, extensão explícita que não carrega interpretação física; a caixa é maior que o disco. O gradiente é por partes constante e não é apropriado a inferir curvatura pontual suave em interfaces.

[D] N=1+φ h/|hmin| mantém o lapso da fatia original. Ω_c=N_casa Ω e Ω_f=N_origem Ω apenas nos casos de relógio próprio. Os cenários e sementes são os históricos G12/T6/M2. M refina a grade xy pelo fator 1.25 da razão .75/.60; isso não é resolução absoluta histórica.

[M] Dipolo fraco em xy recebe perfil gaussiano transversal com σ_z=3, e normalização de massa discreta. Quantidade dimensional de força em 2D não é identificada com a de 3D. A razão euclidiana rede/mensagem 500 é conservada na nova discretização; o campo estacionário da rede é resolvido no operador 3D. Regras b39_rele.py preservadas. Os limiares são recalculados unicamente das observações históricas pelo algoritmo original, congelando-os para a nova rodada, e são diagnósticos. A calibração geométrica de janelas da superfície não é assumida válida no volume.

[?] Propagação fora da fatia e diluição volumétrica podem alterar amplitudes, focalização e sombra. A transferência exige controle contínuo, não igualdade por construção. DIO/GMFt físico e observáveis de uma CFT não são definidos por casas ou lâmpadas.
