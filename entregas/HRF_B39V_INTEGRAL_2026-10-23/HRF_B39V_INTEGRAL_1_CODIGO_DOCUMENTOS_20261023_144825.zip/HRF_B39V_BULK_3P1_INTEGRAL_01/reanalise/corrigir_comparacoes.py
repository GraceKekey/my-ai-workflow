from pathlib import Path
import sys,json,shutil,unittest,csv,hashlib
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import numpy as np
from hrf_integral.io import atomic_json,digest
root=Path(__file__).resolve().parents[1];here=Path(__file__).resolve().parent

def ratio(peaks,reference):
 p=np.asarray(peaks,float);ref=np.asarray(reference,float)
 return np.divide(p,ref,out=np.full(p.shape,np.nan),where=ref>0)

class Regression(unittest.TestCase):
 def test_weak_self_comparison(self):np.testing.assert_array_equal(ratio([1e-80,1e-20],[1e-80,1e-20]),[1,1])
 def test_zero_reference_undefined(self):self.assertTrue(np.isnan(ratio([0,1],[0,0])).all())
 def test_actual_shadow_threshold(self):np.testing.assert_allclose(ratio([1e-80,.2],[2e-80,1]),[.5,.2])

if __name__=='__main__':
 for line in (here/'hashes_reanalise.txt').read_text().splitlines():
  sha,name=line.split('  ',1)
  if digest(here/name)!=sha:raise RuntimeError('REANALYSIS_HASH_MISMATCH')
 result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Regression))
 atomic_json(here/'testes.json',dict(tests=result.testsRun,status='PASS_SOFTWARE' if result.wasSuccessful() else 'FAIL',scope='postexecution descriptive-observable bugfix; scientific preregistration untouched'))
 if not result.wasSuccessful():raise SystemExit(1)
 for preset in ('smoke','standard','high_resolution'):
  d=root/'resultados'/preset;file=d/'execution.json';e=json.loads(file.read_text());original=here/'originais'/preset;original.mkdir(parents=True,exist_ok=True)
  for f in ('execution.json','comparisons.json'):
   if not (original/f).exists():shutil.copy2(d/f,original/f)
  base=next((c for c in e['cases'] if c['id']=='G_P_s+1' and c['status']=='EXECUTED'),None)
  if base is not None:
   for case in e['cases']:
    if case['status']!='EXECUTED':continue
    a=ratio(case['receiver_peak'],base['receiver_peak']);valid=np.isfinite(a)
    metrics=dict(shadow_vs_flat=int(np.sum(a[valid]<.25)),focus_peak_ratio=float(np.max(a[valid])) if valid.any() else None,median_peak_ratio=float(np.median(a[valid])) if valid.any() else None,reference_zero_undefined=int(np.sum(~valid)))
    case.update(metrics)
    for row in e['comparison']['comparisons']:
     if row['id']==case['id']:row.update(metrics)
   e['comparison']['analysis_note']='Descriptive ratios corrected post-execution; see reanalise/ERRATA.md and original preserved reports'
   atomic_json(d/'execution.json',e);atomic_json(d/'comparisons.json',e['comparison'])
 with (root/'resultados/CORRESPONDENCIA_FINAL.csv').open('w',newline='') as f:
  w=csv.writer(f);w.writerow(['parameter','historical','new_standard','scope'])
  for row in [('houses',468,468,'identical xy; new z=0'),('W0',1.6,1.6,'same number; different spatial domain'),('OM',1.85,1.85,'except explicit frequency/clock controls'),('G',.05,.05,'same number; classical reciprocal 3D sampling'),('SIG_FONTE_xy',1.5,1.5,'standard coarse under-resolves source'),('SIG_FONTE_z','not defined',3,'new model choice'),('DT',.1,.1,'dt/2 control and stability guard explicit'),('AMOSTRA',.5,1,'new traces subsampled; not equivalent readout certification'),('grid_xy',.75,310/42,'coarse'),('threshold','per-case historical calibration','same historical per-case values','not one global threshold'),('GMFt_DIO','hypothesis','BLOCKED','classical houses not distributed quantum identities')]:w.writerow(row)
 print('Descriptive comparisons corrected; scientific verdicts unchanged.')
