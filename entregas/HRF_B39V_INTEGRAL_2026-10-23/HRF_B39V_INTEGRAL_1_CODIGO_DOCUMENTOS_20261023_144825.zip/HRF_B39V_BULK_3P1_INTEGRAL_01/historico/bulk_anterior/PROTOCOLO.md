# PROTOCOLO — HRF-B39V-BULK-3P1-01 [D/H/?]
Versão 0.1 · 22/10/2026 · ESTADO: NÃO EXECUTADO

## Pergunta
A dinâmica, geometrias de vale, atrasos, focalização e disparos da B39V, originalmente superfície espacial 2D deformada em R³, podem surgir de uma descrição bulk espacial 3D / espaço-tempo 3+1 derivada holograficamente de uma boundary 2+1?

## Princípio RUP
B (holografia AdS4/CFT3 estabelecida em domínio controlado) → A (modelo relacional HRF). Nenhum acerto do modelo prescrito é prova de holografia. Não identificar altura h da B39V com coordenada radial z de AdS; exigir mapa explícito.

## Estágios, sequência e barreiras
- G0: auditagem / extração da B39V original com hashes, mesmos parâmetros e observáveis; integração exata do código original NÃO IMPLEMENTADA neste pacote.
- G1: extensão geométrica controlada da B39V para métrica 3+1, especificando relação entre h(x,y), métrica 3D g_ij(x,y,z), lapse N e fontes; baseline fornecido com perfil escolhido, não derivado.
- G2: propagação KG 3+1, extração de tempos de chegada, fluxos, espectro, foco/sombra, rotação/paridade; runner simplificado para resposta de campo incluído, relé B39V exato ainda por portar.
- G3: dicionário holográfico em modelo AdS4/CFT3 genuíno: entropias RT/HRT para regiões boundary, operadores O, tensor energia-momento T_μν e reconstrução HKLL; NÃO IMPLEMENTADO. Caso QFT candidata não holográfica: BLOCKED, não inventar dual.
- G4: resolver problemas inversos com métricas reconstruídas de dados boundary que não incluam h/tempos-alvo como parâmetros de treino. TESTE CEGO.
- G5: comparar observáveis B39V vs previsões bulk sob mapa de comparação explícito de mesma dimensão e observador; baseline, nível de geometria e tempo adequados.
- G6: robustez: malha, ruído, defeitos, novos ângulos/frequências, inversões de paridade, novas condições de fonte, consistência causal e RT/HRT.
- G7: interface Capítulo 3: somente após G3/G4, investigar assinatura DIO e manifestação GMFt; não igualar receptor a DIO.

## Gates
PASS_BASELINE_NUMERICAL: estabilidade e convergência do modelo 3D prescritos.
PASS_HOLOGRAPHIC_DICTIONARY: demonstração de dualidade e identificação da álgebra/campo/subespaço de código.
PASS_BULK_RECONSTRUCTION: recuperação de grandezas métricas e respostas fora da amostra.
FAIL: saída só alcançada com parâmetros B39V alimentados em cada caso, inconsistência causal ou de dimensionalidade.
INCONCLUSIVE: degenerescência, gauge não resolvido, ou observável incompatível.
Não confundir `PASS_BASELINE_NUMERICAL` com `PASS_BULK_RECONSTRUCTION`.

## Restrições físicas
Para campo escalar covariante: □_g φ - m²φ = J, não se obter causalidade de velocidades de grupo; testar características do PDE e condições de contorno. Controle de energia e reflexões artificiais nas bordas. O benchmark com Dirichlet admite reflexões.
RT/HRT relacionam entropias boundary a áreas bulk em dualidades apropriadas; em rede gaussiana genérica não há garantia de dual gravitacional.
