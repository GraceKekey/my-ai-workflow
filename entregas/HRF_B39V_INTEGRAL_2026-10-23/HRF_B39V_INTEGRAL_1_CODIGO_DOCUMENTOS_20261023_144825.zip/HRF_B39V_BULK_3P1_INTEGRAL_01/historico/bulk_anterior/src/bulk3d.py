"""B39V bulk 3+1: baseline numerical extension, NOT a holographic derivation.
3D spatial scalar Klein-Gordon on prescribed static metric
ds²=(L/z)²[-N(x,y,z)²dt²+dx²+dy²+dz²] for ads4_probe.
For flat_probe, conformal factor 1. Dirichlet field boundaries.
"""
import argparse, json, pathlib, hashlib, platform
import numpy as np

def validate_config(cfg):
    for key in ("nx", "ny", "nz", "steps", "store_every"):
        if isinstance(cfg[key], bool) or not isinstance(cfg[key], int):
            raise ValueError(f"{key} must be an integer")
    if min(cfg[k] for k in ("nx", "ny", "nz")) < 7:
        raise ValueError("grid too small")
    if cfg["steps"] < 1 or cfg["store_every"] < 1:
        raise ValueError("steps and store_every must be positive")
    for key in ("lx", "ly", "zmin", "zmax", "dt", "mass", "omega",
                "source_sigma", "source_amp", "source_x", "source_y", "source_z", "lapse_strength"):
        if not np.isfinite(cfg[key]):
            raise ValueError(f"{key} must be finite")
    if min(cfg[k] for k in ("lx", "ly", "dt", "source_sigma")) <= 0:
        raise ValueError("lengths, dt and source_sigma must be positive")
    if cfg["zmax"] <= cfg["zmin"] or cfg["mass"] < 0:
        raise ValueError("invalid z range or negative mass")
    if cfg["geometry"] not in ("ads4_probe", "flat_probe"):
        raise ValueError("unknown geometry")
    if cfg["geometry"] == "ads4_probe" and cfg["zmin"] <= 0:
        raise ValueError("AdS domain must have zmin > 0")
    if not cfg["receiver_locations"]:
        raise ValueError("at least one receiver is required")
    for r in cfg["receiver_locations"]:
        if len(r) != 3 or not np.isfinite(r).all():
            raise ValueError("receivers require three finite coordinates")
        if not (-cfg["lx"]/2 <= r[0] <= cfg["lx"]/2 and
                -cfg["ly"]/2 <= r[1] <= cfg["ly"]/2 and cfg["zmin"] <= r[2] <= cfg["zmax"]):
            raise ValueError("receiver outside the simulated domain")
    for v in cfg["valleys"]:
        if not all(np.isfinite(v[k]) for k in ("x", "y", "depth", "width", "zwidth")):
            raise ValueError("valley parameters must be finite")
        if min(v["width"], v["zwidth"]) <= 0:
            raise ValueError("valley widths must be positive")


def run(cfg, out):
    validate_config(cfg)
    nx,ny,nz=[cfg[k] for k in ("nx","ny","nz")]
    if min(nx,ny,nz)<7: raise ValueError("grid too small")
    lx,ly=cfg["lx"],cfg["ly"]
    xs=np.linspace(-lx/2,lx/2,nx)
    ys=np.linspace(-ly/2,ly/2,ny)
    zs=np.linspace(cfg["zmin"],cfg["zmax"],nz)
    dx,dy,dz=xs[1]-xs[0],ys[1]-ys[0],zs[1]-zs[0]
    X,Y,Z=np.meshgrid(xs,ys,zs,indexing="ij")
    if cfg["geometry"]=="ads4_probe":
        c=1/Z   # L=1
    elif cfg["geometry"]=="flat_probe":
        c=np.ones_like(Z)
    else: raise ValueError("unknown geometry")
    valley=np.zeros_like(Z)
    for v in cfg["valleys"]:
        valley+=v["depth"]*np.exp(-((X-v["x"])**2+(Y-v["y"])**2)/(2*v["width"]**2)-(Z-cfg["source_z"])**2/(2*v["zwidth"]**2))
    N=1-cfg["lapse_strength"]*valley
    if np.min(N)<=0: raise ValueError("nonpositive lapse")
    # PDE from d'Alembertian: u_tt = (N / c^2) div(N*c^2 grad u) - (N*c*m)^2 u
    # For metric g=c² diag(-N²,1,1,1), sqrt(-g)=c^4 N and sqrt(-g)g^ij=N c² delta_ij
    # Thus u_tt = N/c² div(N c² grad u) -(N c m)² u
    coef=N*c*c
    def axisflux(u,axis,h):
        # centered face flux with zero boundary derivative only at outermost nodes;
        # Dirichlet enforced on field at every update.
        a=np.swapaxes(u,axis,0); q=np.swapaxes(coef,axis,0)
        flux=.5*(q[1:]+q[:-1])*(a[1:]-a[:-1])/h
        div=np.zeros_like(a)
        div[1:-1]=(flux[1:]-flux[:-1])/h
        return np.swapaxes(div,0,axis)
    # Bound on the spectral radius of the Dirichlet spatial operator, including
    # the mass term. Gershgorin applies to this mass-weighted positive operator.
    diagonal = np.zeros_like(coef)
    for axis, h in ((0, dx), (1, dy), (2, dz)):
        q = np.swapaxes(coef, axis, 0)
        d = np.swapaxes(diagonal, axis, 0)
        faces = .5*(q[1:] + q[:-1]) / h**2
        d[1:-1] += faces[1:] + faces[:-1]
    spatial_diag = (N/(c*c))*diagonal
    omega_squared_bound = float(np.max((2*spatial_diag + (N*c*cfg["mass"])**2)[1:-1,1:-1,1:-1]))
    # Source shape is constant in time; preserve the original ramp and cutoff.
    g=np.exp(-((X-cfg["source_x"])**2+(Y-cfg["source_y"])**2+(Z-cfg["source_z"])**2)/(2*cfg["source_sigma"]**2))
    def rhs(u,t):
        div=axisflux(u,0,dx)+axisflux(u,1,dy)+axisflux(u,2,dz)
        # time-windowed sinusoidal source
        drive=cfg["source_amp"]*g*np.sin(cfg["omega"]*t)*np.sin(min(t,8)/8*np.pi/2)**2 if t<8 else 0*g
        a=(N/(c*c))*div-(N*c*cfg["mass"])**2*u+drive
        a[[0,-1],:,:]=0;a[:,[0,-1],:]=0;a[:,:,[0,-1]]=0
        return a
    dt=cfg["dt"]
    # Conservative CFL heuristic for explicit scheme in conformal metric; local speed N.
    if dt>=.4*min(dx,dy,dz)/np.max(N): raise ValueError("dt exceeds conservative CFL bound")
    if dt*np.sqrt(omega_squared_bound) >= 2.0:
        raise ValueError("dt exceeds wave-plus-mass Verlet stability bound")
    u=np.zeros((nx,ny,nz));v=np.zeros_like(u)
    receivers=[tuple(np.unravel_index(np.argmin((X-r[0])**2+(Y-r[1])**2+(Z-r[2])**2),X.shape)) for r in cfg["receiver_locations"]]
    observations=[]
    def observe(k):
        observations.append({"t":k*dt,"values":[float(u[idx]) for idx in receivers],
                             "energy_proxy":float(np.sum(u*u+v*v)*dx*dy*dz)})
    observe(0)
    # velocity Verlet explicit wave-equation integrator. Computational benchmark only.
    a=rhs(u,0.)
    for k in range(1,cfg["steps"]+1):
        un=u+dt*v+.5*dt*dt*a
        un[[0,-1],:,:]=0;un[:,[0,-1],:]=0;un[:,:,[0,-1]]=0
        an=rhs(un,k*dt)
        v=v+.5*dt*(a+an);u=un;a=an
        if not np.isfinite(u).all() or not np.isfinite(v).all():
            raise FloatingPointError(f"nonfinite field or velocity at step {k}")
        if k%cfg["store_every"]==0 or k==cfg["steps"]: observe(k)
    out.mkdir(parents=True,exist_ok=True)
    result={"status":"NUMERICAL_PROBE_ONLY_NOT_HOLOGRAPHIC",
       "metric":"(1/z)^2[-N^2 dt^2+dx^2+dy^2+dz^2] or flat conformal metric",
       "geometry":cfg["geometry"],"grid":[nx,ny,nz],"receivers":cfg["receiver_locations"],
       "receiver_grid_indices":[list(map(int,idx)) for idx in receivers],
       "receiver_actual_locations":[[float(xs[i]),float(ys[j]),float(zs[k])] for i,j,k in receivers],
       "configuration":cfg,"python":platform.python_version(),"numpy":np.__version__,
       "executed_source_sha256":hashlib.sha256(pathlib.Path(__file__).read_bytes()).hexdigest(),
       "numerical_diagnostics":{"lapse_min":float(N.min()),"lapse_max":float(N.max()),
          "omega_squared_upper_bound":omega_squared_bound,
          "dt_omega_upper_bound":float(dt*np.sqrt(omega_squared_bound)),
          "verlet_stability_limit":2.0,"all_states_finite":True,"final_time":cfg["steps"]*dt,
          "source_cutoff_time":8.0,"source_completed":cfg["steps"]*dt>=8.0},
       "energy_proxy_definition":"Integral of u^2+v^2; not the conserved KG energy",
       "source_definition":"Coordinate acceleration drive; not a separately normalized covariant J",
       "observations":observations,"gates":{"holographic_dictionary":"BLOCKED","RT_HRT":"NOT_IMPLEMENTED",
       "HKLL":"NOT_IMPLEMENTED","B39V_exact_reproduction":"NOT_TESTED",
       "bulk_pde":"COMPUTED"}}
    (out/"observables.json").write_text(json.dumps(result,indent=2))
    (out/"RELATORIO.md").write_text("# Resultado preliminar\n\nModelo numérico 3D de campo escalar em uma métrica PRESCRITA.\n\nNão é reconstrução holográfica física, nem reprodução validada da B39V.\n\n")
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument("--config",default="config/benchmark.json");p.add_argument("--output",default="results")
    a=p.parse_args()
    run(json.loads(pathlib.Path(a.config).read_text()),pathlib.Path(a.output))
if __name__=="__main__":main()
