# Resultado preliminar

Modelo numérico 3D de campo escalar em uma métrica PRESCRITA.

Não é reconstrução holográfica física, nem reprodução validada da B39V.

