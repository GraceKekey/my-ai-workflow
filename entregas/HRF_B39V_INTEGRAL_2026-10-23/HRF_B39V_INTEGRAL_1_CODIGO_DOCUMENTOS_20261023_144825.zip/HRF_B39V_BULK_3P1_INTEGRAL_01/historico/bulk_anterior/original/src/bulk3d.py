"""B39V bulk 3+1: baseline numerical extension, NOT a holographic derivation.
3D spatial scalar Klein-Gordon on prescribed static metric
ds²=(L/z)²[-N(x,y,z)²dt²+dx²+dy²+dz²] for ads4_probe.
For flat_probe, conformal factor 1. Dirichlet field boundaries.
"""
import argparse, json, pathlib, hashlib
import numpy as np

def run(cfg, out):
    nx,ny,nz=[cfg[k] for k in ("nx","ny","nz")]
    if min(nx,ny,nz)<7: raise ValueError("grid too small")
    lx,ly=cfg["lx"],cfg["ly"]
    xs=np.linspace(-lx/2,lx/2,nx)
    ys=np.linspace(-ly/2,ly/2,ny)
    zs=np.linspace(cfg["zmin"],cfg["zmax"],nz)
    dx,dy,dz=xs[1]-xs[0],ys[1]-ys[0],zs[1]-zs[0]
    X,Y,Z=np.meshgrid(xs,ys,zs,indexing="ij")
    if cfg["geometry"]=="ads4_probe":
        c=1/Z   # L=1
    elif cfg["geometry"]=="flat_probe":
        c=np.ones_like(Z)
    else: raise ValueError("unknown geometry")
    valley=np.zeros_like(Z)
    for v in cfg["valleys"]:
        valley+=v["depth"]*np.exp(-((X-v["x"])**2+(Y-v["y"])**2)/(2*v["width"]**2)-(Z-cfg["source_z"])**2/(2*v["zwidth"]**2))
    N=1-cfg["lapse_strength"]*valley
    if np.min(N)<=0: raise ValueError("nonpositive lapse")
    # PDE from d'Alembertian: u_tt = (N / c^2) div(N*c^2 grad u) - (N*c*m)^2 u
    # For metric g=c² diag(-N²,1,1,1), sqrt(-g)=c^4 N and sqrt(-g)g^ij=N c² delta_ij
    # Thus u_tt = N/c² div(N c² grad u) -(N c m)² u
    coef=N*c*c
    def axisflux(u,axis,h):
        # centered face flux with zero boundary derivative only at outermost nodes;
        # Dirichlet enforced on field at every update.
        a=np.swapaxes(u,axis,0); q=np.swapaxes(coef,axis,0)
        flux=.5*(q[1:]+q[:-1])*(a[1:]-a[:-1])/h
        div=np.zeros_like(a)
        div[1:-1]=(flux[1:]-flux[:-1])/h
        return np.swapaxes(div,0,axis)
    def rhs(u,t):
        div=axisflux(u,0,dx)+axisflux(u,1,dy)+axisflux(u,2,dz)
        g=np.exp(-((X-cfg["source_x"])**2+(Y-cfg["source_y"])**2+(Z-cfg["source_z"])**2)/(2*cfg["source_sigma"]**2))
        # time-windowed sinusoidal source
        drive=cfg["source_amp"]*g*np.sin(cfg["omega"]*t)*np.sin(min(t,8)/8*np.pi/2)**2 if t<8 else 0*g
        a=(N/(c*c))*div-(N*c*cfg["mass"])**2*u+drive
        a[[0,-1],:,:]=0;a[:,[0,-1],:]=0;a[:,:,[0,-1]]=0
        return a
    dt=cfg["dt"]
    # Conservative CFL heuristic for explicit scheme in conformal metric; local speed N.
    if dt>=.4*min(dx,dy,dz)/np.max(N): raise ValueError("dt exceeds conservative CFL bound")
    u=np.zeros((nx,ny,nz));v=np.zeros_like(u)
    receivers=[tuple(np.unravel_index(np.argmin((X-r[0])**2+(Y-r[1])**2+(Z-r[2])**2),X.shape)) for r in cfg["receiver_locations"]]
    observations=[]
    def observe(k):
        observations.append({"t":k*dt,"values":[float(u[idx]) for idx in receivers],
                             "energy_proxy":float(np.sum(u*u+v*v)*dx*dy*dz)})
    observe(0)
    # velocity Verlet explicit wave-equation integrator. Computational benchmark only.
    a=rhs(u,0.)
    for k in range(1,cfg["steps"]+1):
        un=u+dt*v+.5*dt*dt*a
        un[[0,-1],:,:]=0;un[:,[0,-1],:]=0;un[:,:,[0,-1]]=0
        an=rhs(un,k*dt)
        v=v+.5*dt*(a+an);u=un;a=an
        if k%cfg["store_every"]==0: observe(k)
    out.mkdir(parents=True,exist_ok=True)
    result={"status":"NUMERICAL_PROBE_ONLY_NOT_HOLOGRAPHIC",
       "metric":"(1/z)^2[-N^2 dt^2+dx^2+dy^2+dz^2] or flat conformal metric",
       "geometry":cfg["geometry"],"grid":[nx,ny,nz],"receivers":cfg["receiver_locations"],
       "observations":observations,"gates":{"holographic_dictionary":"BLOCKED","RT_HRT":"NOT_IMPLEMENTED",
       "HKLL":"NOT_IMPLEMENTED","B39V_exact_reproduction":"NOT_TESTED",
       "bulk_pde":"COMPUTED"}}
    (out/"observables.json").write_text(json.dumps(result,indent=2))
    (out/"RELATORIO.md").write_text("# Resultado preliminar\n\nModelo numérico 3D de campo escalar em uma métrica PRESCRITA.\n\nNão é reconstrução holográfica física, nem reprodução validada da B39V.\n\n")
    return result

def main():
    p=argparse.ArgumentParser();p.add_argument("--config",default="config/benchmark.json");p.add_argument("--output",default="results")
    a=p.parse_args()
    run(json.loads(pathlib.Path(a.config).read_text()),pathlib.Path(a.output))
if __name__=="__main__":main()
