# Mapa B39V→bulk

| Elemento B39V | Extensão de benchmark | Alvo holográfico |
|---|---|---|
| Membrana 2,5D h(x,y) | 3D (x,y,z), perfil de lapse prescrito | métrica 3D + lapse inferidos da boundary |
| Fonte dipolo girante s± | benchmark fonte escalar simples, SEM dipolo | operador O, kernel HKLL, fonte com paridade |
| KG na superfície, lacuna 1.6 | KG volumétrico m=1.6 parametrizado | massa/dimensão m²L²=Δ(Δ-3), sujeito a estabilidade BF |
| Frequência 1.85 | drive senoidal 1.85 | dados espectrais boundary com mapa calibrado |
| 468 relés e disparos | 4 receptores-amostra, sem relé | portar relé original e extrair observáveis completos |
| Foco, sombra, atrasos, quiralidade | amplitude amostral | previsões fora de treino no bulk |
| T1/T1R | lapso prescrito | métrica temporal inferida de informação dinâmica |

ALERTA: diferenças importantes constam explicitamente. O presente benchmark 3D NÃO é uma porta integral nem reproduz a B39V quantitativamente; os estágios de porta exata estão documentados mas ainda requerem implementação.
