"""Controles independentes: solução semidiscreta de referência, fronteiras e estabilidade."""
import copy,importlib.util,json,pathlib,tempfile,unittest
import numpy as np
from scipy.integrate import solve_ivp
from scipy.sparse import diags,eye,kron
P=pathlib.Path(__file__).resolve().parents[1]
spec=importlib.util.spec_from_file_location('bulk',P/'src/bulk3d.py');B=importlib.util.module_from_spec(spec);spec.loader.exec_module(B)
CFG=json.loads((P/'config/benchmark.json').read_text())
def simulate(c):
 with tempfile.TemporaryDirectory()as d:return B.run(c,pathlib.Path(d))
class Tests(unittest.TestCase):
 def test_configuracao_invalida(self):
  for key,val in [('store_every',0),('steps',0),('dt',float('nan')),('zmin',0),('source_sigma',0),('nx',7.5)]:
   c=copy.deepcopy(CFG);c[key]=val
   with self.subTest(key=key),self.assertRaises(ValueError):simulate(c)
 def test_receptor_fora(self):
  c=copy.deepcopy(CFG);c['receiver_locations']=[[999,0,3]]
  with self.assertRaisesRegex(ValueError,'receiver outside'):simulate(c)
 def test_estabilidade_com_massa(self):
  c=copy.deepcopy(CFG);c['mass']=300
  with self.assertRaisesRegex(ValueError,'wave-plus-mass'):simulate(c)
 def test_saida_final_sem_multiplo(self):
  c=copy.deepcopy(CFG);c.update(steps=21,store_every=20)
  r=simulate(c);self.assertEqual(r['observations'][-1]['t'],.315)
 def test_referencia_independente_e_convergencia(self):
  c=copy.deepcopy(CFG);c.update(nx=7,ny=7,nz=7,lx=6.,ly=6.,zmin=1.,zmax=7.,geometry='flat_probe',valleys=[],lapse_strength=0.,dt=.02,steps=100,store_every=1,receiver_locations=[[1,0,3],[-1,0,3],[3,0,3]])
  r=simulate(c);fine=copy.deepcopy(c);fine.update(dt=.01,steps=200,store_every=2);rf=simulate(fine)
  # Independent sparse Kronecker Dirichlet Laplacian, interior 5^3 grid.
  T=diags([-np.ones(4),2*np.ones(5),-np.ones(4)],[-1,0,1]);I=eye(5)
  K=kron(kron(T,I),I)+kron(kron(I,T),I)+kron(kron(I,I),T)+eye(125)*c['mass']**2
  X,Y,Z=np.meshgrid(np.arange(-2,3),np.arange(-2,3),np.arange(2,7),indexing='ij')
  g=np.exp(-((X-c['source_x'])**2+(Y-c['source_y'])**2+(Z-c['source_z'])**2)/(2*c['source_sigma']**2)).ravel()
  def rhs(t,y):return np.concatenate([y[125:],-K@y[:125]+c['source_amp']*g*np.sin(c['omega']*t)*np.sin(t*np.pi/16)**2])
  times=np.array([o['t']for o in r['observations']]);sol=solve_ivp(rhs,[0,2],np.zeros(250),method='DOP853',rtol=1e-12,atol=1e-14,t_eval=times);self.assertTrue(sol.success)
  idx=np.ravel_multi_index((3,2,1),(5,5,5));ref=sol.y[idx]
  coarse=np.array([o['values'][0]for o in r['observations']]);f=np.array([o['values'][0]for o in rf['observations']])
  ec=float(np.max(abs(coarse-ref)));ef=float(np.max(abs(f-ref)))
  self.assertLess(ef,ec/3.2);self.assertLess(ef,1e-3*float(np.max(abs(ref))))
  self.assertLess(max(abs(o['values'][0]-o['values'][1])for o in r['observations']),1e-14)
  self.assertEqual(max(abs(o['values'][2])for o in r['observations']),0.)
  print(json.dumps(dict(referencia='DOP853 e Laplaciano Kronecker independentes',erro_dt_002=ec,erro_dt_001=ef,razao_erros=ec/ef)))
 def test_benchmark_preserva_dinamica_original(self):
  sp=importlib.util.spec_from_file_location('original',P/'original/src/bulk3d.py');o=importlib.util.module_from_spec(sp);sp.loader.exec_module(o)
  with tempfile.TemporaryDirectory()as d:r0=o.run(CFG,pathlib.Path(d))
  r1=simulate(CFG)
  self.assertEqual(r0['observations'],r1['observations'])
if __name__=='__main__':unittest.main(verbosity=2)
