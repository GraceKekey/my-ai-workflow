# HRF — B39V transferida ao bulk 3+1 | PRÉ-REGISTRO, NÃO EXECUTADO

Objetivo: transportar os mesmos tipos de fonte, vale, propagação e receptores da B39V para uma grade volumétrica 3D com tempo, e então testar se algum dicionário holográfico permite obter esta dinâmica a partir de uma boundary 2+1. NÃO é simples prova automática da dualidade.

## Conteúdo
- `referencia/`: protocolo e códigos históricos originais selecionados da B39V; não alterados.
- `src/bulk3d.py`: baseline operacional de Klein–Gordon em 3D sobre métrica 3+1 prescrita (AdS em coordenadas Poincaré ou plana); **não implementa HKLL, RT nem HRT**.
- `config/benchmark.json`: demonstração reduzida de custo baixo; **não reproduz os parâmetros completos da B39V**.
- `PROTOCOLO.md`: estágios congelados para a transferência real.
- `MAPA_DE_DADOS.md`: correspondência entre experimentos e observáveis.

## Ambiente e execução EXTERNA (somente após autorização)
```bash
pip install -r requirements.txt
python src/bulk3d.py --config config/benchmark.json --output results
```
Resultados gerados pelo programa externo: `results/observables.json` e `results/RELATORIO.md`.

## Atenção
O código acima é uma extensão 3D **baseline**, não uma realização holográfica.
Não declarar bulk emergente até construir dicionário 2+1→3+1 e demonstrar previsões independentes de entropia/correladores.
