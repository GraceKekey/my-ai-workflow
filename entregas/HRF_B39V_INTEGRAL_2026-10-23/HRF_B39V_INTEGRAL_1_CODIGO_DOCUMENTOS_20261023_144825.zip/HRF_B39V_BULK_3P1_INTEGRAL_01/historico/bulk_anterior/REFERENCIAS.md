# Fontes
- Capítulo 0.1 HRF, RUP v0.1, 08/10/2026.
- Capítulo 3 HRF v0.2, 22/10/2026 (DIO/GMFt).
- B39V protocolo e relatório originais incorporados em referencia/.
- Ryu & Takayanagi, Phys Rev Lett 96, 181602 (2006).
- Hubeny, Rangamani & Takayanagi, JHEP 07 (2007) 062.
- Hamilton, Kabat, Lifschytz & Lowe, Phys Rev D 74, 066009 (2006).
- Jokela et al., Bulk metric reconstruction from entanglement data via minimal surface area variations (2025).
- Caderno de Pesquisa Bibliográfica HRF v0.9 CP-10 (Google Drive).
