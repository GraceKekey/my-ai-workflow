import pathlib,json,hashlib,zipfile,datetime,platform,csv,re
from zoneinfo import ZoneInfo
import numpy,scipy,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=pathlib.Path(__file__).resolve().parents[1];r=json.loads((P/'results/observables.json').read_text());stamp=datetime.datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%d_%H%M%S')
checks=[]
for line in(P/'SHA256_MANIFEST.txt').read_text().splitlines():
 if not re.match(r'^[0-9a-f]{64}\s',line):continue
 h,n=line.split(None,1);n=n.strip();now=hashlib.sha256((P/n).read_bytes()).hexdigest();checks.append(dict(arquivo=n,sha256_original=h,sha256_executado=now,inalterado=h==now))
assert [x['arquivo']for x in checks if not x['inalterado']]==['src/bulk3d.py']
assert hashlib.sha256((P/'original/src/bulk3d.py').read_bytes()).hexdigest()==next(x['sha256_original']for x in checks if x['arquivo']=='src/bulk3d.py')
(P/'auditoria/hashes_revisao.json').write_text(json.dumps(checks,indent=2))
(P/'auditoria/ambiente.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=numpy.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,plataforma=platform.platform(),threads=1,install_exit_code=0,execucao_exit_code=0,testes_aprovados=6),indent=2))
with(P/'results/receptores.csv').open('w',newline='')as f:
 w=csv.writer(f);w.writerow(['tempo','receptor_1','receptor_2','receptor_3','receptor_4','proxy_nao_energia_KG']);w.writerows([[o['t'],*o['values'],o['energy_proxy']]for o in r['observations']])
fig,ax=plt.subplots(figsize=(7,4),layout='constrained')
for j in range(4):ax.plot([o['t']for o in r['observations']],[o['values'][j]for o in r['observations']],'-o',ms=3,label='Receptor '+str(j+1))
ax.set(xlabel='Tempo de coordenada',ylabel='Campo escalar amostrado',title='Baseline AdS prescrito: janela inicial t ≤ 3,6');ax.ticklabel_format(axis='y',style='sci',scilimits=(0,0));ax.legend();ax.grid(alpha=.25);fig.savefig(P/'results/receptores.png',dpi=160);plt.close(fig)
report=P/f'HRF_B39V_BULK_3P1_RELATORIO_{stamp}.md'
report.write_text(f'''# HRF-B39V-BULK-3P1 — Revisão e execução

Data: {stamp}, America/Sao_Paulo. Autor HRF: Mario José do Canto Filho, MD. Revisão e execução: Codex.

## Objetivo e escopo
[M] Executar o baseline KG volumétrico em uma métrica 3+1 prescrita, após revisão do código e correção de defeitos autorizada pelo usuário. Este pacote não implementa holografia, RT/HRT, HKLL ou uma reprodução integral da B39V.

## Revisão anterior à execução
[D] O usuário autorizou revisar, corrigir e reexecutar em caso de erro. O índice 3D do operador de fluxo foi conferido e a PDE concorda com a métrica declarada: u_tt = N/c² div(Nc² grad u) − (Ncm)²u, com c=1/z e L=1. A força implementada é um drive de aceleração de coordenada; não há normalização independente de uma fonte covariante J.
[M] Foram corrigidas lacunas de software, sem alterar parâmetros ou PDE: validação de entradas e receptores fora do domínio; limite de estabilidade que inclui o termo de massa; detecção de estados não finitos; armazenamento obrigatório do instante final; coordenadas reais dos receptores, configuração e hash da fonte executada na saída. A gaussiana espacial da fonte passou a ser pré-calculada, sem mudança de valores. energy_proxy foi identificado explicitamente como integral de u²+v², não energia KG conservada.
[D] Preservados: original/src/bulk3d.py, ZIP de entrada, manifesto inicial e todas as referências históricas. A única alteração entre os 15 arquivos do manifesto é src/bulk3d.py. Patch em auditoria/alteracoes.patch; hashes antigo/novo em auditoria/hashes_revisao.json.

## Testes
[M] Seis testes aprovados: entradas inválidas, receptor fora do domínio, instabilidade de massa que o CFL antigo não rejeitava, instante final fora da cadência, referência numérica independente/convergência e regressão do benchmark original.
[M] O controle independente usa malha plana Dirichlet 5³ interior, Laplaciano por produtos de Kronecker e DOP853, contra o Verlet revisado. Erros máximos: 1,30770e−7 (dt=0,02) e 3,26869e−8 (dt=0,01), razão 4,00067. Simetria dos receptores ±x e valor zero na fronteira passaram. Esse teste confirma convergência temporal no problema semidiscreto plano; não certifica convergência espacial da geometria AdS com vale.
[M] O teste de regressão obteve igualdade exata das 13 observações entre código original e revisado para a configuração fornecida. As correções não mudaram as curvas desse benchmark. Logs em auditoria/testes_log.txt e testes reproduzíveis em testes/testar_bulk3d.py.

## Execução e parâmetros
[D] requirements.txt atendido e execução revisada concluída, ambos exit 0. Comando: python -I src/bulk3d.py --config config/benchmark.json --output results. Nenhuma falha de execução exigiu nova correção. Python {platform.python_version()}, NumPy {numpy.__version__}, SciPy {scipy.__version__}; BLAS/OMP/MKL limitados a uma thread.
[M] Configuração original: 25×25×17, AdS4 probe, dt=0,015, 240 passos, 13 observações, quatro receptores, massa 1,6 e frequência 1,85. Parâmetros físicos e configuração preservados.

## Resultados
[D] Classe do programa: **NUMERICAL_PROBE_ONLY_NOT_HOLOGRAPHIC**. bulk_pde=COMPUTED, holographic_dictionary=BLOCKED, RT_HRT/HKLL=NOT_IMPLEMENTED e B39V_exact_reproduction=NOT_TESTED.
[M] Todos os estados permaneceram finitos. Lapso mínimo 0,99521223. dt·ω_limite=0,0648767, abaixo de 2 para o critério de Verlet. Valores finais dos receptores: {r['observations'][-1]['values']}.
[M] Coordenadas reais na grade: {r['receiver_actual_locations']}. Os pedidos em z=3 e z=6 foram amostrados em z=3,25 e z=6,25; isso agora consta explicitamente na saída.

## Limitações e interpretação
[?] A janela termina em t=3,6, enquanto a fonte é cortada em t=8. Não foi estendida a duração nem mudado seu envelope: o código original usa uma rampa sin² e corte abrupto. Não há análise de chegada após o pulso, de foco/sombra, de disparos, energia conservada, reflexões ou convergência espacial neste benchmark. A gaussiana tem caudas não compactas; amplitudes pequenas precoces não são uma medida de velocidade de frente causal.
[D] Não foi atribuído PASS_BASELINE_NUMERICAL do protocolo: a convergência temporal foi controlada em um problema de referência, mas a convergência espacial e os demais controles da configuração física permanecem por demonstrar. Status COMPUTED não certifica esses testes ausentes.
[H] A geometria foi introduzida, não reconstruída. Os resultados não estabelecem bulk emergente, dualidade AdS/CFT, reprodução quantitativa da B39V ou DIO/GMFt.

## Entrega
Pacote autocontido com entrada e fonte originais, código revisado, testes, patch, documentação, configuração, observáveis JSON/CSV/PNG, relatórios, logs, ambiente e manifestos. STATUS.json e documentos históricos com NÃO EXECUTADO foram preservados; os resultados desta tentativa estão em results/ e neste relatório.
''')
(P/'RESULTADOS_LEIA_PRIMEIRO.md').write_text(f'# Revisão e execução — bulk 3+1\n\nExecução concluída; seis testes aprovados.\n\nRelatório: {report.name}\n\nMétrica prescrita; não é reconstrução holográfica. Janela original até t=3,6 preservada.\n')
files=[p for p in sorted(P.rglob('*'))if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256_RESULTADOS.txt']
(P/'MANIFEST_SHA256_RESULTADOS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(P).as_posix()+'\n'for p in files))
archive=pathlib.Path('/workspace')/f'HRF_B39V_BULK_3P1_REVISADO_RESULTADOS_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts:z.write(p,pathlib.Path('HRF_B39V_BULK_3P1_RESULTADOS')/p.relative_to(P))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
r=dict(archive=str(archive),report=str(report),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)
pathlib.Path('/workspace/HRF_B39V_BULK_3P1_ENTREGA_LOCAL.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))
