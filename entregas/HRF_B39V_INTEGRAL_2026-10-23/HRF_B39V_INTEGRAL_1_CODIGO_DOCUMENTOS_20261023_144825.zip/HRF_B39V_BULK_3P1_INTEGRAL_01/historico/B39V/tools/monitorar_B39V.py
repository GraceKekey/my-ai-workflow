import pathlib,datetime,json
P=pathlib.Path(__file__).resolve().parents[1]
print(datetime.datetime.now(datetime.timezone.utc).isoformat(timespec='seconds'))
for name in ['G1','G2','T','M']:
 f=P/'auditoria'/('execucao_'+name+'.txt');s=f.read_text().splitlines()if f.exists()else[]
 print(name,s[-1]if s else 'iniciado')
files=list((P/'resultados').glob('*.npz'));print('Checkpoints',len(files),'/20; bytes',sum(f.stat().st_size for f in files))
