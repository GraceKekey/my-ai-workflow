import os,pathlib,time,datetime,json,subprocess
P=pathlib.Path(__file__).resolve().parents[1];py='/workspace/my-ai-workflow/.venv/bin/python3'
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TZ='America/Sao_Paulo')
t0=time.time();jobs={};handles=[]
for name,part,lote in [('G1','G','1/2'),('G2','G','2/2'),('T','T','1/1'),('M','M','1/1')]:
 f=(P/'auditoria'/('execucao_'+name+'.txt')).open('w');handles.append(f)
 jobs[name]=subprocess.Popen([py,'-I','src/rodar_B39V.py','--modo','completo','--parte',part,'--lote',lote],cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT)
 if name=='G1':
  while not(P/'resultados/config_B39V.json').exists():
   if jobs[name].poll()is not None:raise RuntimeError('G1 terminou antes de configurar')
   time.sleep(.1)
 print('iniciada',name,flush=True)
statuses={}
while len(statuses)<4:
 for name,p in jobs.items():
  if name not in statuses and p.poll()is not None:statuses[name]=p.returncode;print('terminou',name,'exit',p.returncode,flush=True)
 time.sleep(1)
for f in handles:f.close()
r=dict(inicio_utc=datetime.datetime.fromtimestamp(t0,datetime.timezone.utc).isoformat(),fim_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tempo_parede_s=time.time()-t0,exit_codes=statuses,threads=1,processos=4,cpu_quota=pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),memoria_limite=pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip())
(P/'auditoria/execucao_resumo.json').write_text(json.dumps(r,indent=2));assert all(v==0 for v in statuses.values()),statuses
