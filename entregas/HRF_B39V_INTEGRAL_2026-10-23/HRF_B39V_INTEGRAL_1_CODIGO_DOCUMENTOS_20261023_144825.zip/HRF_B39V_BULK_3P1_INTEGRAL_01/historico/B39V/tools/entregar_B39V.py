"""Organiza a entrega após avaliação congelada; sem novas simulações."""
import pathlib,json,datetime,zipfile,hashlib,csv,sys,platform
from zoneinfo import ZoneInfo
import numpy as np,scipy,matplotlib
P=pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0,str(P/'src'));import b39v_config as C
r=json.loads((P/'resultados/avaliacao_B39V.json').read_text());m=r['medidas'];cl=r['classes'];cfg=json.loads((P/'resultados/config_B39V.json').read_text());assert cfg['modo']=='completo'
expected={x['nome']for x in C.rodadas('completo')};actual={x.stem for x in(P/'resultados').glob('*.npz')};assert actual==expected and len(actual)==20
meta=[]
for name in sorted(expected):
 x=json.loads((P/'resultados'/(name+'.json')).read_text());meta.append(x)
 with np.load(P/'resultados'/(name+'.npz'),allow_pickle=False)as z:
  assert z['X'].shape==z['Pm'].shape and len(z['ts'])==z['X'].shape[0]
  assert np.isfinite(z['X']).all()and np.isfinite(z['Pm']).all()
  assert len(z['casas'])==468 and z['ts'][-1]>=459.9
(P/'auditoria/cobertura.json').write_text(json.dumps(dict(esperados=20,obtidos=20,G=12,T=6,M=2,casas=468,arrays_finitos=True,nomes='EXATOS'),indent=2))
(P/'auditoria/versoes.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,plataforma=platform.platform()),indent=2))
(P/'tabelas').mkdir(exist_ok=True)
def table(name,rows):
 with(P/'tabelas'/name).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
px=[]
for k,v in r['previsto'].items():
 if isinstance(v,dict):
  for kk,vv in v.items():
   obt=cl.get(k,{}).get(kk)if isinstance(cl.get(k),dict)else None;px.append(dict(teste=k+'.'+kk,previsto=vv,obtido=obt,confere=obt==vv))
 else:px.append(dict(teste=k,previsto=v,obtido=cl.get(k),confere=cl.get(k)==v))
table('previsto_x_obtido.csv',px)
rows=[]
for name,o in m['rodadas'].items():
 rows.append(dict(rodada=name,chegada=cl.get('chegada',{}).get(name),disparo=cl.get('disparo',{}).get(name),frente=cl.get('frente',{}).get(name),ola=cl.get('ola',{}).get(name),inversoes_chegada=o['inv_chegada'],inversoes_disparo=o['inv_geo'],kendall_chegada=o['kendall_chegada'],kendall_disparo=o['kendall_geo'],dispararam=o['dispararam'],casas=o['H'],atraso_ref=o.get('atraso_ref'),previsto_ref=o.get('previsto_ref'),inclinacao=o.get('inclinacao'),correlacao=o.get('correlacao'),margem_frente=o['frente_global'],margem_ola=o['ola_global'],rede_sobre_limiar=o['rede_sobre_limiar']))
table('medidas_por_rodada.csv',rows)
table('execucao_por_rodada.csv',[dict(rodada=x['nome'],parte=x['parte'],segundos=x['segundos'],vertices=x['n'],casas=x['H'],profundidade=x['prof'],omega_max=x['omega_max'],dt_omega=x['omega_max']*.1)for x in meta])
stamp=datetime.datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%d_%H%M%S')
summary={k:cl.get(k)for k in ['GLOBAL','CHEGADA','DISPARO','GEOMETRIA','dose','malha','relogio','vermelho','cidade','rede']}
summary.update(previsoes_conferem=sum(x['confere']for x in px),previsoes_total=len(px))
(P/'auditoria/decisoes_resumo.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
lines=['# HRF B39V — Relatório da execução completa',f'\n{stamp}, America/Sao_Paulo. Autor HRF: Mario José do Canto Filho, MD. Desenho/pré-registro: Claude. Execução: Codex.','\n## Objetivo','[M] Medir chegada e disparo de casas com relés iguais em uma membrana curva 2,5D, com uma fonte central, peso/dose, segundo vale, cidade leve, lapso e relógios próprios.','\n## Hipóteses','[M/H] Previsões congeladas: o vale atrasa sem alterar a ordem de chegada; atraso explicado pelo caminho extra; efeito de dose, lente/sombra, quiralidade com espelho, aceleração com lapso e desvio para o vermelho com relógios próprios. A tabela abaixo preserva todas as previsões e divergências.','[M] Explorações anteriores informaram regras e parâmetros. Algumas configurações de referência já eram conhecidas; as configurações decisivas são as novas especificadas no protocolo. Não é um teste inteiramente cego.','\n## Parâmetros','[M] Disco R=155; malha a=0,75 e controle a=0,60; 468 casas; α=6/12/18, sementes da cidade 44/45, φ=0,03/0,05/0,08. Vinte rodadas (G12, T6, M2). Fonte saca-rolha, pulso 60, tempo total 460, RK4 dt=0,1, amostra 0,5. Demais valores no protocolo e resultados/config_B39V.json.','\n## Protocolo','[D] Execução autorizada pelo pedido “Oi pode rodar por favor”. SHA-256 conferidos antes/depois. Testes iniciais: 155 ramos e 14 peças aprovados. Executor original, Python isolado e uma thread BLAS/OMP/MKL por processo; G em lotes 1/2 e 2/2, T e M em paralelo, opção prevista no LEIAME. Código, sementes, parâmetros e tolerâncias permaneceram intactos.','[M] Checkpoints NPZ atômicos, metadados JSON e avaliação pelo avaliador congelado. Figura gerada por src/figura_B39V.py original. tools/ supervisiona e organiza a entrega, sem modificar decisões.','\n## Medidas','[M] Chegada por meia subida da mensagem, disparo pelo limiar comum com rede, inversões/Kendall, margens globais e por faixa, atraso e caminho extra, dose, foco/sombra, espelho, cidade, lapso, vermelho e controle de malha. Chegada e disparo são medidas distintas.','\n## Resultados','```json',json.dumps(summary,ensure_ascii=False,indent=2),'```','\n| Item | Previsto | Obtido | Confere |','|---|---|---|---|']
lines += [f"| {x['teste']} | {x['previsto']} | {x['obtido']} | {'sim'if x['confere']else'NÃO'} |"for x in px]
lines+=['\n[M] Medidas detalhadas por rodada em tabelas/medidas_por_rodada.csv e resultados/avaliacao_B39V.json. Figura original em resultados/figura_B39V.png.','\n## Controles','[M] Cobertura: 20/20 NPZ e metadados, 468 casas por rodada, tempo final 460 e arrays finitos. Hashes e testes em auditoria/. A fumaça original foi preservada e não substituiu resultados desta rodada.','\n[M] Execução, ambiente e tempo:', '```json',(P/'auditoria/execucao_resumo.json').read_text(),'```','\n[M] Controle de malha:', '```json',json.dumps(m.get('malha'),ensure_ascii=False,indent=2),'```','\n[M] Relógio e cidade:', '```json',json.dumps({k:m.get(k)for k in ['relogio','cidade','quiral']},ensure_ascii=False,indent=2),'```','\n## Interpretação','[D] O resultado principal foi VALE_ATRASA_SEM_TROCAR_A_ORDEM, com CHEGADA=MESMA_SEQUENCIA_EM_TODAS e DISPARO=TROCA_SO_NA_SOMBRA. Isso preserva a ordem da chegada, não garante que todas as casas disparem na mesma sequência. Em cada caso V2, 466 de 468 casas dispararam; houve 6 inversões em V2n s=−1 e 7 em cada sentido de V2o, classificadas como trocas na sombra.', '[M] Em r≈100, os atrasos das doses α=6/12/18 foram 3,3372 / 12,8586 / 27,6307, contra caminhos extras/v de 2,9848 / 11,3773 / 23,8838. Na malha fina, a dose 18 deu 26,1036: redução de 5,53%, dentro da tolerância pré-registrada de 15%; a inclinação atraso/caminho caiu de 1,08590 para 1,02796. Isso mostra correção numérica material, sem determinar o limite contínuo.', '[M] As lentes deram foco 2,70–3,19 e sombra 0,20–0,22. As cidades leves acrescentaram atrasos medianos de 0,6425 e 0,6808. Para φ=0,03/0,05/0,08, o lapso T1 antecipou a chegada em 3,3033/5,0530/7,0665 frente a V1; relógios próprios T1R atrasaram em 6,7256/10,3705/15,0724 frente a T1, com Spearman sinal/altura abaixo de −0,998. Esses efeitos pertencem ao modelo de lapso e de sintonia escolhido.', '[D] As decisões são as saídas literais do avaliador congelado. Divergências são relatadas sem modificar os critérios. GLOBAL considera chegada, explicação geométrica e malha; a ordem de disparo é uma decisão separada.','[M] A membrana tem espaço e vizinhos: este é um teste geométrico paralelo, não a base onipresente sem junções. O atraso é um análogo de caminho em uma superfície estática; não constitui teste de relatividade geral. O lapso foi acrescentado como hipótese do modelo. O relé é a única não linearidade, posta à mão.','[?] Há dispersão da malha, erro da geodésica por calor e absorção imperfeita da borda. Uma fonte, um pulso, uma portadora, casas iguais e sem carga sobre a rede. Nenhuma geometria ou dinâmica gravitacional é derivada. [H] A interpretação HRF permanece condicionada a esses limites.','\n## Arquivos','Entrega autocontida com entrada original, código/protocolo/fumaça intactos, 20 NPZ e metadados, avaliação, figura, tabelas, logs, versões, máquina e manifestos SHA-256.']
report=P/f'HRF_B39V_RELATORIO_{stamp}.md';report.write_text('\n'.join(lines)+'\n')
(P/'LEIA_PRIMEIRO_RESULTADOS.md').write_text(f'# B39V — Resultados completos\n\nRelatório: {report.name}\n\n'+json.dumps(summary,ensure_ascii=False,indent=2)+'\n\nResultados desta rodada: resultados/. Fumaça e entrada original são antecedentes.\n')
files=[p for p in sorted(P.rglob('*'))if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256_RESULTADOS.txt']
(P/'MANIFEST_SHA256_RESULTADOS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(P).as_posix()+'\n'for p in files))
archive=pathlib.Path('/workspace')/f'HRF_B39V_RESULTADOS_COMPLETOS_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts:z.write(p,pathlib.Path('HRF_B39V_RESULTADOS')/p.relative_to(P))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
receipt=dict(archive=str(archive),report=str(report),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)
pathlib.Path('/workspace/HRF_B39V_ENTREGA_LOCAL.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
