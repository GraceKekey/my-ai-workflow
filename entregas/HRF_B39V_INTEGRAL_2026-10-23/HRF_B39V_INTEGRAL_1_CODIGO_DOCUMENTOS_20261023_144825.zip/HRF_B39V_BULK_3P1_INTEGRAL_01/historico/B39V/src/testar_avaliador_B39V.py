"""B39V — teste do avaliador: todos os ramos de todas as regras (dados sintéticos) e ponta a ponta na fumaça.
Uso: python -I src/testar_avaliador_B39V.py <pasta_da_fumaca>   → termina com "TODOS OS N RAMOS CONFEREM"."""
import copy, json, os, sys
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import avaliar_B39V as AV
import b39v_config as C

ramos = []


def ramo(nome, obtido, esperado):
    ok = obtido == esperado
    ramos.append(ok)
    if not ok:
        print(f'[FALHA] {nome}: obtido {obtido}, esperado {esperado}')


# ---------------------------------------------------------------- regras isoladas
o_bom = dict(dispararam=10, H=10, inv_geo=0, kendall_geo=0.98, inv_chegada=0, kendall_chegada=0.98, frente_global=3.0,
             faixas=[dict(ola=2.0), dict(ola=2.0), dict(ola=2.0)], atraso_ref=12.0, previsto_ref=11.0,
             inclinacao=1.1, correlacao=0.98, foco=2.0, sombra=0.4, rede_sobre_limiar=0.02)
ramo('ordem INSUFICIENTE', AV.classe_ordem(None), 'INSUFICIENTE')
ramo('ordem POUCAS_DISPARAM', AV.classe_ordem({**o_bom, 'dispararam': 8}), 'POUCAS_DISPARAM')
ramo('ordem 90% disparam basta', AV.classe_ordem({**o_bom, 'dispararam': 9}), 'MESMA_SEQUENCIA')
ramo('ordem MESMA', AV.classe_ordem(o_bom), 'MESMA_SEQUENCIA')
ramo('ordem ALTERADA (inversão)', AV.classe_ordem({**o_bom, 'inv_geo': 1}), 'SEQUENCIA_ALTERADA')
ramo('ordem ALTERADA (Kendall)', AV.classe_ordem({**o_bom, 'kendall_geo': 0.89}), 'SEQUENCIA_ALTERADA')
ramo('ordem Kendall no corte', AV.classe_ordem({**o_bom, 'kendall_geo': 0.90}), 'MESMA_SEQUENCIA')

ramo('chegada INSUFICIENTE', AV.classe_chegada(None), 'INSUFICIENTE')
ramo('chegada MESMA', AV.classe_chegada(o_bom), 'MESMA_SEQUENCIA')
ramo('chegada ALTERADA (inversão)', AV.classe_chegada({**o_bom, 'inv_chegada': 1}), 'SEQUENCIA_ALTERADA')
ramo('chegada ALTERADA (Kendall)', AV.classe_chegada({**o_bom, 'kendall_chegada': 0.89}), 'SEQUENCIA_ALTERADA')
ramo('disparo INSUFICIENTE', AV.classe_disparo(None), 'INSUFICIENTE')
ramo('disparo MESMA', AV.classe_disparo(o_bom), 'MESMA_SEQUENCIA')
ramo('disparo POUCAS', AV.classe_disparo({**o_bom, 'dispararam': 5}), 'POUCAS_DISPARAM')
ramo('disparo TROCA_NA_SOMBRA', AV.classe_disparo({**o_bom, 'inv_geo': 3, 'inv_na_sombra': 3}), 'TROCA_NA_SOMBRA')
ramo('disparo troca fora da sombra', AV.classe_disparo({**o_bom, 'inv_geo': 3, 'inv_na_sombra': 2}), 'SEQUENCIA_ALTERADA')
ramo('disparo troca sem lente', AV.classe_disparo({**o_bom, 'inv_geo': 3}), 'SEQUENCIA_ALTERADA')
ramo('disparo sombra com Kendall baixo', AV.classe_disparo({**o_bom, 'inv_geo': 3, 'inv_na_sombra': 3,
     'kendall_geo': 0.89}), 'SEQUENCIA_ALTERADA')
ramo('atraso INSUFICIENTE (None)', AV.classe_atraso(None), 'INSUFICIENTE')
ramo('atraso INSUFICIENTE (sem medida)', AV.classe_atraso({'x': 1}), 'INSUFICIENTE')
ramo('atraso SEM_ATRASO', AV.classe_atraso({**o_bom, 'atraso_ref': 0.5}), 'SEM_ATRASO')
ramo('atraso SEM_ATRASO negativo', AV.classe_atraso({**o_bom, 'atraso_ref': -0.9}), 'SEM_ATRASO')
ramo('atraso GEOMETRICO', AV.classe_atraso(o_bom), 'ATRASO_GEOMETRICO')
ramo('atraso inclinação no corte de cima', AV.classe_atraso({**o_bom, 'inclinacao': 1.3}), 'ATRASO_GEOMETRICO')
ramo('atraso inclinação alta', AV.classe_atraso({**o_bom, 'inclinacao': 1.31}), 'ATRASO_NAO_GEOMETRICO')
ramo('atraso inclinação baixa', AV.classe_atraso({**o_bom, 'inclinacao': 0.79}), 'ATRASO_NAO_GEOMETRICO')
ramo('atraso correlação baixa', AV.classe_atraso({**o_bom, 'correlacao': 0.89}), 'ATRASO_NAO_GEOMETRICO')
ramo('atraso sem inclinação', AV.classe_atraso({**o_bom, 'inclinacao': None}), 'ATRASO_NAO_GEOMETRICO')

d6, d12, d18 = ({'atraso_ref': a, 'previsto_ref': p} for a, p in ((6.0, 5.5), (12.0, 11.0), (18.0, 16.0)))
ramo('dose INSUFICIENTE', AV.classe_dose(None, d12, d18), 'INSUFICIENTE')
ramo('dose INSUFICIENTE (sem medida)', AV.classe_dose({'x': 1}, d12, d18), 'INSUFICIENTE')
ramo('dose GEOMETRICA', AV.classe_dose(d6, d12, d18), 'DOSE_GEOMETRICA')
ramo('dose fora (razão alta)', AV.classe_dose({'atraso_ref': 9.0, 'previsto_ref': 5.0}, d12, d18),
     'DOSE_MONOTONA_FORA_DA_GEOMETRIA')
ramo('dose fora (previsto ≤ 0)', AV.classe_dose({'atraso_ref': 6.0, 'previsto_ref': 0.0}, d12, d18),
     'DOSE_MONOTONA_FORA_DA_GEOMETRIA')
ramo('dose SEM_DOSE', AV.classe_dose(d12, d6, d18), 'SEM_DOSE')

ramo('lente INSUFICIENTE', AV.classe_lente({'x': 1}), 'INSUFICIENTE')
ramo('lente LENTE', AV.classe_lente({'foco': 1.5, 'sombra': 0.67}), 'LENTE')
ramo('lente SEM_LENTE', AV.classe_lente({'foco': 1.2, 'sombra': 0.85}), 'SEM_LENTE')
ramo('lente PARCIAL (só foco)', AV.classe_lente({'foco': 2.0, 'sombra': 0.9}), 'LENTE_PARCIAL')
ramo('lente PARCIAL (só sombra)', AV.classe_lente({'foco': 1.1, 'sombra': 0.5}), 'LENTE_PARCIAL')

ramo('quiral INSUFICIENTE', AV.classe_quiral(None), 'INSUFICIENTE')
ramo('quiral AQUIRAL', AV.classe_quiral({'dev_mesma_casa': 0.05, 'erro_espelho': 0.5}), 'AQUIRAL')
ramo('quiral QUIRAL_ESPELHO', AV.classe_quiral({'dev_mesma_casa': 0.2, 'erro_espelho': 0.03}), 'QUIRAL_ESPELHO')
ramo('quiral PARCIAL (espelho ruim)', AV.classe_quiral({'dev_mesma_casa': 0.5, 'erro_espelho': 0.031}), 'PARCIAL')
ramo('quiral PARCIAL (intermediário)', AV.classe_quiral({'dev_mesma_casa': 0.1, 'erro_espelho': 0.0}), 'PARCIAL')

phis = [0.03, 0.05, 0.08]
rel = lambda a, b, c: {'03': {'T1_menos_V1': a}, '05': {'T1_menos_V1': b}, '08': {'T1_menos_V1': c}}
ramo('relógio INSUFICIENTE', AV.classe_relogio({'03': {}}, phis), 'INSUFICIENTE')
ramo('relógio ACELERA', AV.classe_relogio(rel(-1, -2, -3), phis), 'RELOGIO_ACELERA_A_ONDA')
ramo('relógio ATRASA', AV.classe_relogio(rel(1, 2, 3), phis), 'RELOGIO_ATRASA_A_ONDA')
ramo('relógio MISTO (não monótono)', AV.classe_relogio(rel(-1, -3, -2), phis), 'RELOGIO_MISTO')
ramo('relógio MISTO (sinais)', AV.classe_relogio(rel(1, -2, -3), phis), 'RELOGIO_MISTO')
ver = lambda d, s: {k: {'T1R_menos_T1': x, 'spearman_sinal_altura': y} for k, x, y in zip(('03', '05', '08'), d, s)}
ramo('vermelho INSUFICIENTE', AV.classe_vermelho({'03': {}}, phis), 'INSUFICIENTE')
ramo('vermelho DESVIO', AV.classe_vermelho(ver((1, 2, 3), (-0.6, -0.7, -0.5)), phis), 'DESVIO_PARA_O_VERMELHO')
ramo('vermelho SO_NO_SINAL', AV.classe_vermelho(ver((1, 3, 2), (-0.6, -0.7, -0.8)), phis), 'VERMELHO_SO_NO_SINAL')
ramo('vermelho SEM_DESVIO', AV.classe_vermelho(ver((1, 2, 3), (-0.6, -0.4, -0.8)), phis), 'SEM_DESVIO_CLARO')

ramo('ola INSUFICIENTE', AV.classe_ola(None), 'INSUFICIENTE')
ramo('ola LIMPA', AV.classe_ola(o_bom), 'OLA_LIMPA_POR_FAIXAS')
ramo('ola PARCIAL', AV.classe_ola({'faixas': [dict(ola=2.0), dict(ola=0.9), dict(ola=1.0)]}), 'OLA_PARCIAL')
ramo('ola SEM_OLA', AV.classe_ola({'faixas': [dict(ola=1.0), dict(ola=0.9)]}), 'SEM_OLA')
ramo('frente INSUFICIENTE', AV.classe_frente(None), 'INSUFICIENTE')
ramo('frente COMPLETA', AV.classe_frente(o_bom), 'FRENTE_COMPLETA')
ramo('frente INCOMPLETA', AV.classe_frente({**o_bom, 'frente_global': 1.0}), 'FRENTE_INCOMPLETA')

# ---------------------------------------------------------------- classificar (globais)
nomes = [r['nome'] for r in C.rodadas('completo')]


def med_base():
    rod = {}
    for n in nomes:
        o = copy.deepcopy(o_bom)
        if n in ('G_P_s+1', 'G_P_s-1', 'M_P_s+1'):
            o.update(atraso_ref=0.1, previsto_ref=0.0, inclinacao=None, correlacao=None)
        rod[n] = o
    rod['G_V1a6_s+1'].update(atraso_ref=6.0, previsto_ref=5.5)
    rod['G_V1a18_s+1'].update(atraso_ref=18.0, previsto_ref=16.0)
    rod['M_V1a18_s+1'].update(atraso_ref=18.5, previsto_ref=16.0)
    rod['G_V2n_s-1'].update(inv_geo=2, inv_na_sombra=2)
    for n in ('G_V2n_s+1', 'G_V2n_s-1', 'G_V2o_s+1', 'G_V2o_s-1'):
        rod[n].update(frente_global=0.9, faixas=[dict(ola=5.0), dict(ola=2.0), dict(ola=0.9)])
    return dict(esperadas=list(nomes), rodadas=rod,
                quiral={'P': dict(dev_mesma_casa=0.01, erro_espelho=0.01), 'V1a12': dict(dev_mesma_casa=0.01, erro_espelho=0.01),
                        'V2n': dict(dev_mesma_casa=0.5, erro_espelho=0.01), 'V2o': dict(dev_mesma_casa=0.4, erro_espelho=0.01)},
                relogio={k: {'T1_menos_V1': a, 'T1R_menos_T1': b, 'spearman_sinal_altura': -0.8}
                         for k, a, b in (('03', -2.0, 3.0), ('05', -4.0, 6.0), ('08', -6.0, 10.0))},
                cidade={'44': 0.5, '45': -0.3}, malha={'razao_atraso': 18.5 / 18.0})


m0 = med_base(); c0 = AV.classificar(m0)
for k, v in AV.PREVISTO.items():
    if isinstance(v, dict):
        for kk, vv in v.items():
            ramo(f'base {k}.{kk}', c0[k][kk], vv)
    else:
        ramo(f'base {k}', c0[k], v)


def var(f, chave, esperado, sub=None):
    m = med_base(); f(m); c = AV.classificar(m)
    ob = c[chave] if sub is None else c[chave][sub]
    ramo(f'classificar {chave}{"." + sub if sub else ""} → {esperado}', ob, esperado)


var(lambda m: [m['rodadas'].pop(n) for n in nomes[:8]], 'GLOBAL', 'INSUFICIENTE')
var(lambda m: m['rodadas'].pop('G_P_s+1'), 'GLOBAL', 'INSUFICIENTE')
var(lambda m: m['rodadas'].pop('G_V3s44_s+1'), 'CHEGADA', 'INSUFICIENTE')
var(lambda m: m['rodadas'].pop('G_V3s44_s+1'), 'DISPARO', 'INSUFICIENTE')
var(lambda m: m['rodadas'].pop('G_V3s44_s+1'), 'GLOBAL', 'INSUFICIENTE')
var(lambda m: m['rodadas']['T_T1Rf08_s+1'].update(inv_chegada=1), 'CHEGADA', 'MESMA_SEQUENCIA_SO_NA_GEOMETRIA')
var(lambda m: m['rodadas']['T_T1Rf08_s+1'].update(inv_chegada=1), 'GLOBAL', 'VALE_ATRASA_SEM_TROCAR_A_ORDEM')
var(lambda m: m['rodadas']['G_V2n_s+1'].update(inv_chegada=3), 'CHEGADA', 'SEQUENCIA_QUEBRADA')
var(lambda m: m['rodadas']['G_V2n_s+1'].update(inv_chegada=3), 'GLOBAL', 'VALE_TROCA_A_ORDEM')
var(lambda m: m['rodadas']['G_V2n_s-1'].update(inv_geo=0), 'DISPARO', 'MESMA_SEQUENCIA_EM_TODAS')
var(lambda m: m['rodadas']['G_V1a12_s+1'].update(inv_geo=1), 'DISPARO', 'SEQUENCIA_QUEBRADA')
var(lambda m: m['rodadas']['G_V1a12_s+1'].update(inv_geo=1, inv_na_sombra=1), 'DISPARO', 'SEQUENCIA_QUEBRADA')
var(lambda m: m['rodadas']['T_T1Rf08_s+1'].update(dispararam=5), 'DISPARO', 'SEQUENCIA_QUEBRADA')
var(lambda m: m['rodadas']['G_V2o_s-1'].update(inclinacao=2.0), 'GEOMETRIA', 'ATRASO_NAO_EXPLICADO')
var(lambda m: m['rodadas']['G_V2o_s-1'].update(inclinacao=2.0), 'GLOBAL', 'PARCIAL')
var(lambda m: m['rodadas']['G_P_s-1'].update(atraso_ref=3.0), 'GEOMETRIA', 'ATRASO_NAO_EXPLICADO')
var(lambda m: m['rodadas']['G_V1a6_s+1'].update(atraso_ref=13.0), 'GEOMETRIA', 'ATRASO_NAO_EXPLICADO')
var(lambda m: m['rodadas']['G_V1a6_s+1'].pop('atraso_ref'), 'GEOMETRIA', 'INSUFICIENTE')
var(lambda m: m.update(malha={'razao_atraso': 1.2}), 'malha', 'MALHA_INCONSISTENTE')
var(lambda m: m.update(malha={'razao_atraso': 1.2}), 'GLOBAL', 'PARCIAL')
var(lambda m: m['rodadas']['M_V1a18_s+1'].update(inv_chegada=2), 'malha', 'MALHA_INCONSISTENTE')
var(lambda m: m['rodadas']['M_P_s+1'].update(kendall_chegada=0.5), 'malha', 'MALHA_INCONSISTENTE')
var(lambda m: m['rodadas']['M_P_s+1'].update(dispararam=8), 'malha', 'MALHA_CONSISTENTE')
var(lambda m: m.pop('malha'), 'malha', 'INSUFICIENTE')
var(lambda m: m.update(malha={'razao_atraso': 0.86}), 'malha', 'MALHA_CONSISTENTE')
var(lambda m: m.update(cidade={'44': 0.5}), 'cidade', 'INSUFICIENTE')
var(lambda m: m.update(cidade={'44': 2.5, '45': 0.0}), 'cidade', 'CIDADE_MUDA')
var(lambda m: m['rodadas']['G_V3s45_s+1'].update(inv_chegada=1), 'cidade', 'CIDADE_MUDA')
var(lambda m: m['rodadas']['G_V3s45_s+1'].update(inv_geo=1), 'cidade', 'CIDADE_LEVE_SO_SOMA')
var(lambda m: m['rodadas']['G_V2n_s-1'].update(rede_sobre_limiar=0.1), 'rede', 'REDE_DISPARA')
var(lambda m: m['rodadas']['T_T1Rf08_s+1'].update(rede_sobre_limiar=0.3), 'rede', 'REDE_NAO_DISPARA')
var(lambda m: m['quiral'].pop('V2o'), 'quiral', 'INSUFICIENTE', 'V2o')
var(lambda m: m['rodadas']['G_V2o_s+1'].update(foco=1.0, sombra=1.0), 'lente', 'SEM_LENTE', 'G_V2o_s+1')
var(lambda m: m['rodadas']['G_V1a12_s+1'].update(atraso_ref=0.2), 'atraso', 'SEM_ATRASO', 'G_V1a12_s+1')

# ---------------------------------------------------------------- ponta a ponta na fumaça
pasta = sys.argv[1] if len(sys.argv) > 1 else 'fumaca'
if os.path.exists(os.path.join(pasta, 'config_B39V.json')):
    med = AV.medir(pasta); cl = AV.classificar(med)
    ramo('fumaça: todas as rodadas presentes', len(med['presentes']), len(med['esperadas']))
    ramo('fumaça: classificação sem INSUFICIENTE global', cl['GLOBAL'] != 'INSUFICIENTE', True)
    arq = os.path.join(pasta, 'avaliacao_B39V.json')
    if os.path.exists(arq):
        gravado = json.load(open(arq))['classes']
        ramo('fumaça: avaliação gravada = refeita', json.dumps(gravado, sort_keys=True, default=float),
             json.dumps(json.loads(json.dumps(cl, default=float)), sort_keys=True, default=float))
    else:
        ramo('fumaça: avaliação gravada existe', False, True)
else:
    ramo('fumaça presente', False, True)

if all(ramos):
    print(f'TODOS OS {len(ramos)} RAMOS CONFEREM')
else:
    print(f'{ramos.count(False)} DE {len(ramos)} RAMOS FALHARAM')
