"""B39V — executor. Uso:
    python -I src/rodar_B39V.py --modo fumaca|completo --parte G|T|M|todas [--saida pasta] [--lote i/n]
Cada rodada grava um checkpoint .npz atômico (e um .json curto) em <saida>/; relançar retoma (pula as prontas).
--lote i/n divide a lista da parte em n lotes (para rodar em paralelo): i = 1..n."""
import argparse, hashlib, json, os, sys, time
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import b39v_config as C
import b39v_membrana as MB
import b39v_dinamica as DN

MODULOS = ['b39v_config.py', 'b39v_membrana.py', 'b39v_dinamica.py', 'b39_rele.py', 'rodar_B39V.py',
           'avaliar_B39V.py']


def sha(f):
    return hashlib.sha256(open(os.path.join(AQUI, f), 'rb').read()).hexdigest()


def montar(rod, p):
    R, a = p['R'], rod['a']
    P, T = MB.disco(R, a)
    casas = MB.casas_grade(p['PASSO_CASAS'], p['RMIN'], p['RMAX'])
    cv = MB.vertice_mais_proximo(P, casas)
    gm = list(rod['gmft']); idades = None
    if rod['semente'] is not None:
        extra, idades = C.casas_v3(casas, rod['semente'], p['ALFA_CASA'], p['SIG_CASA'])
        gm = gm + extra
    h = MB.altura(P, T, R, a, gm)
    V = np.column_stack([P, h])
    L, A = MB.cotan(V, T)
    fonte = int(np.argmin(np.hypot(P[:, 0], P[:, 1])))
    N = None; Omc = np.full(len(casas), C.OM); Om_f = C.OM
    if rod['phi'] > 0:
        N = 1.0 + rod['phi'] * h / abs(h.min())
        if rod['proprio']:                      # relógios próprios: fonte e casas sintonizadas em N(x)·Ω
            Omc = N[cv] * C.OM; Om_f = N[fonte] * C.OM
    base = DN.Base(P, h, L, A, R, p['RABS'], C.DMAX, cv, C.W0, C.G, C.GAM_R, Omc, N=N)
    return dict(P=P, T=T, h=h, V=V, L=L, A=A, casas=casas, cv=cv, fonte=fonte, base=base, Om_f=Om_f, idades=idades)


def uma(rod, p, saida):
    alvo = os.path.join(saida, rod['nome'] + '.npz')
    if os.path.exists(alvo):
        return None
    t0 = time.time()
    m = montar(rod, p)
    b = m['base']
    dgeo = MB.geodesica(m['V'], m['T'], m['L'], m['A'], m['fonte'])
    P1, P2 = b.fonte(0.0, 0.0, C.SIG_FONTE)
    nmsg = C.F0 * np.sqrt(np.sum(P1 ** 2) + np.sum(P2 ** 2))
    rho_r = C.RAZAO_REDE * nmsg / np.sqrt(np.sum(m['A'] ** 2))
    Xr_b, Xr_h = b.rede(C.OM_R)
    fotos = C.FOTOS if rod['nome'] in C.COM_FOTOS else ()
    ts, X, Pm, snaps = b.rodar(P1, P2, rod['s'], m['Om_f'], C.F0, C.DUR, p['TTOT'], C.DT, C.AMOSTRA, fotos=fotos)
    extra = {}
    if fotos:
        extra = dict(fotos=np.array(sorted(snaps)), snaps=np.array([snaps[k] for k in sorted(snaps)]), h=m['h'])
    tmp = alvo + '.tmp.npz'
    np.savez_compressed(tmp, ts=ts, X=X, Pm=Pm, casas=m['casas'], cv=m['cv'], pos_v=m['P'][m['cv']], h_casas=m['h'][m['cv']],
                        dgeo_casas=dgeo[m['cv']], Xr_h=Xr_h, rho_r=rho_r, Omc=b.Omc, Om_f=m['Om_f'],
                        N_casas=b.N[m['cv']], idades=(m['idades'] if m['idades'] is not None else np.zeros(0)),
                        **extra)
    os.replace(tmp, alvo)
    info = dict(nome=rod['nome'], parte=rod['parte'], s=rod['s'], a=rod['a'], gmft=rod['gmft'], semente=rod['semente'],
                phi=rod['phi'], proprio=rod['proprio'], n=int(b.n), H=int(b.H), prof=float(m['h'].min()),
                omega_max=b.omega_max(), Om_f=float(m['Om_f']), rho_r=float(rho_r),
                rede_base_mediana=float(np.median(np.abs(Xr_b)) * rho_r), segundos=time.time() - t0)
    tmpj = os.path.join(saida, rod['nome'] + '.json.tmp')
    json.dump(info, open(tmpj, 'w'), indent=1); os.replace(tmpj, os.path.join(saida, rod['nome'] + '.json'))
    return info


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--modo', required=True, choices=['fumaca', 'completo'])
    ap.add_argument('--parte', default='todas', choices=['G', 'T', 'M', 'todas'])
    ap.add_argument('--saida', default=None)
    ap.add_argument('--lote', default='1/1')
    a = ap.parse_args()
    p = C.MODOS[a.modo]
    saida = a.saida or ('fumaca' if a.modo == 'fumaca' else 'resultados')
    os.makedirs(saida, exist_ok=True)
    cfg = dict(modo=a.modo, parametros=p, fisica=dict(W0=C.W0, OM=C.OM, OM_R=C.OM_R, RAZAO_REDE=C.RAZAO_REDE,
               GAM_R=C.GAM_R, G=C.G, F0=C.F0, SIG_FONTE=C.SIG_FONTE, DUR=C.DUR, DT=C.DT, AMOSTRA=C.AMOSTRA,
               DMAX=C.DMAX), sha256={f: sha(f) for f in MODULOS if os.path.exists(os.path.join(AQUI, f))},
               numpy=np.__version__)
    cj = os.path.join(saida, 'config_B39V.json')
    if not os.path.exists(cj):
        json.dump(cfg, open(cj, 'w'), indent=1)
    lista = [r for r in C.rodadas(a.modo) if a.parte == 'todas' or r['parte'] == a.parte]
    i, n = (int(x) for x in a.lote.split('/'))
    lista = lista[i - 1::n]
    for rod in lista:
        info = uma(rod, p, saida)
        if info is None:
            print(rod['nome'], 'já pronta', flush=True)
        else:
            print(json.dumps({k: (round(v, 4) if isinstance(v, float) else v) for k, v in info.items() if k != 'gmft'}),
                  flush=True)


if __name__ == '__main__':
    main()
