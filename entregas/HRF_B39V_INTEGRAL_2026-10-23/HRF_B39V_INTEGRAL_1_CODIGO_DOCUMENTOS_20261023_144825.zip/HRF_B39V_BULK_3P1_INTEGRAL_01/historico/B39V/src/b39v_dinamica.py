"""B39V — a base na membrana (Klein–Gordon na superfície), as casas e a rede sempre ligada.

Base (c = 1), com lapso N(x) (bloco T; no bloco G, N ≡ 1):
    (A/N) ü = −L_N u − N W0² A u − (A/N) D u̇ − G S q + F(t),
    L_N = cotangentes com peso N̄ (média dos dois vértices) em cada aresta.
Isso é ü = N ∇·(N ∇u) − N² W0² u: relação de dispersão local ω² = N²(k² + W0²) e velocidade de grupo
v_g = N √(1 − N² W0²/ω²).
Casas (receptores): q̈_k = −Ω_k² q_k − γ_R q̇_k − G u_{v_k}.
Rede sempre ligada: Re[ρ_r A e^{iΩ_r t}] uniforme por área; estado estacionário exato por solução esparsa.
Mensagem: dipolo girante no GMFt mais antigo, F = F0 env(t) [P1 cos Ω_f t + s P2 sin Ω_f t] = F0 env Re[(P1 − i s P2)
e^{iΩ_f t}], P1 = A ∂_x g, P2 = A ∂_y g (g gaussiana de largura σ_f), env = sin²(π t/dur) em [0, dur].
Integração RK4 com passo dt; casas amostradas a cada 'amostra'."""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl


class Base:
    def __init__(self, P, h, L, A, R, Rabs, Dmax, casas_v, W0, G, gam_R, Om_casas, N=None):
        n = len(P)
        self.n = n; self.P = P; self.h = h; self.A = A
        self.W0, self.G, self.gam_R = W0, G, gam_R
        r = np.hypot(P[:, 0], P[:, 1])
        D = np.zeros(n); m = r > Rabs
        D[m] = Dmax * ((r[m] - Rabs) / (R - Rabs)) ** 2
        self.D = D
        self.N = np.ones(n) if N is None else np.asarray(N, dtype=float)
        if np.allclose(self.N, 1.0):
            LN = L
        else:
            Lc = L.tocoo(); off = Lc.row != Lc.col
            w = -Lc.data[off] * 0.5 * (self.N[Lc.row[off]] + self.N[Lc.col[off]])
            Wm = sp.coo_matrix((w, (Lc.row[off], Lc.col[off])), shape=(n, n)).tocsr()
            LN = (sp.diags(np.asarray(Wm.sum(1)).ravel()) - Wm).tocsr()
        self.LN = LN
        self.Minv = self.N / A
        self.K = (LN + sp.diags(self.N * W0 ** 2 * A)).tocsr()
        self.cv = np.asarray(casas_v)
        self.H = len(self.cv)
        self.Omc = np.asarray(Om_casas, dtype=float)
        self.S = sp.coo_matrix((np.ones(self.H), (self.cv, np.arange(self.H))), shape=(n, self.H)).tocsr()

    def acel(self, u, v, q, w, F):
        au = self.Minv * (-(self.K @ u) - self.G * (self.S @ q) + F) - self.D * v
        aq = -self.Omc ** 2 * q - self.gam_R * w - self.G * u[self.cv]
        return au, aq

    def rede(self, Om_r):
        """amplitude complexa estacionária (base, casas) sob Re[A e^{iΩ_r t}] por unidade de ρ_r."""
        n, H = self.n, self.H
        Mb = sp.diags(1.0 / self.Minv)
        Kbb = self.K - Om_r ** 2 * Mb + 1j * Om_r * sp.diags(self.D / self.Minv)
        Khh = sp.diags(self.Omc ** 2 - Om_r ** 2 + 1j * Om_r * self.gam_R)
        Kbh = self.G * self.S
        M = sp.bmat([[Kbb, Kbh], [Kbh.T, Khh]]).tocsc()
        f = np.concatenate([self.A, np.zeros(H)]).astype(complex)
        X = spl.spsolve(M, f)
        return X[:n], X[n:]

    def fonte(self, x0, y0, sig):
        dx = self.P[:, 0] - x0; dy = self.P[:, 1] - y0
        g = np.exp(-(dx ** 2 + dy ** 2) / (2 * sig ** 2))
        P1 = self.A * (-dx / sig ** 2) * g; P2 = self.A * (-dy / sig ** 2) * g
        nrm = np.sqrt(np.sum(P1 ** 2 / self.A) + np.sum(P2 ** 2 / self.A))
        return P1 / nrm, P2 / nrm

    def rodar(self, P1, P2, s, Om_f, F0, dur, Ttot, dt, amostra, fotos=()):
        n, H = self.n, self.H
        u = np.zeros(n); v = np.zeros(n); q = np.zeros(H); w = np.zeros(H)
        nst = int(round(Ttot / dt)); pa = int(round(amostra / dt))
        ts = [0.0]; X = [q.copy()]; Pm = [w.copy()]; snaps = {}
        fotos = sorted(fotos); ifo = 0
        Z = np.zeros(n)

        def forca(t):
            x = t / dur
            if not (0.0 < x < 1.0):
                return Z
            return F0 * np.sin(np.pi * x) ** 2 * (P1 * np.cos(Om_f * t) + s * P2 * np.sin(Om_f * t))

        for it in range(nst):
            t = it * dt
            F1 = forca(t); F2 = forca(t + 0.5 * dt); F3 = forca(t + dt)
            a1u, a1q = self.acel(u, v, q, w, F1)
            u2 = u + 0.5 * dt * v; v2 = v + 0.5 * dt * a1u; q2 = q + 0.5 * dt * w; w2 = w + 0.5 * dt * a1q
            a2u, a2q = self.acel(u2, v2, q2, w2, F2)
            u3 = u + 0.5 * dt * v2; v3 = v + 0.5 * dt * a2u; q3 = q + 0.5 * dt * w2; w3 = w + 0.5 * dt * a2q
            a3u, a3q = self.acel(u3, v3, q3, w3, F2)
            u4 = u + dt * v3; v4 = v + dt * a3u; q4 = q + dt * w3; w4 = w + dt * a3q
            a4u, a4q = self.acel(u4, v4, q4, w4, F3)
            u = u + dt / 6 * (v + 2 * v2 + 2 * v3 + v4)
            v = v + dt / 6 * (a1u + 2 * a2u + 2 * a3u + a4u)
            q = q + dt / 6 * (w + 2 * w2 + 2 * w3 + w4)
            w = w + dt / 6 * (a1q + 2 * a2q + 2 * a3q + a4q)
            tt = (it + 1) * dt
            if (it + 1) % pa == 0:
                ts.append(tt); X.append(q.copy()); Pm.append(w.copy())
            while ifo < len(fotos) and tt >= fotos[ifo] - 1e-9:
                snaps[fotos[ifo]] = (0.5 * (v ** 2 + Om_f ** 2 * u ** 2)).astype(np.float32); ifo += 1
        return np.array(ts), np.array(X), np.array(Pm), snaps

    def energia(self, u, v):
        """energia da base (sem lapso: ½ vᵀ M v + ½ uᵀ K u)."""
        return float(0.5 * np.sum(v ** 2 / self.Minv) + 0.5 * u @ (self.K @ u))

    def omega_max(self):
        """limite superior (Gershgorin) da maior frequência da base: RK4 é estável se ω_max·dt < 2,8."""
        Mh = sp.diags(np.sqrt(self.Minv))
        Kt = (Mh @ self.K @ Mh).tocsr()
        return float(np.sqrt(np.max(np.asarray(abs(Kt).sum(1)).ravel())))


def vg(N, W0, Om):
    """velocidade de grupo local (contínuo)."""
    x = 1 - N ** 2 * W0 ** 2 / Om ** 2
    return N * np.sqrt(np.maximum(x, 0.0))
