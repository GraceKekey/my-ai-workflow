"""B39V — conferência das peças. Uso: python -I src/conferir_pecas_B39V.py <pasta_da_fumaca>
Termina com "TODAS AS N PEÇAS CONFEREM" ou lista as que falharam."""
import hashlib, os, sys
import numpy as np
import scipy.sparse as sp
from scipy.special import exp1

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import b39v_membrana as MB
import b39v_dinamica as DN
import b39v_config as C
import b39_rele as RL

SHA_RELE_B39 = '67bcaabd578a0110260b1ca6882f7b256c3881aee4d8bcf8aec5f5a807e564cf'
res = []


def conf(nome, ok, valor):
    res.append((nome, bool(ok), valor))
    print(f'[{"OK" if ok else "FALHA"}] {nome}: {valor}', flush=True)


def espelho(P, eixo):
    chave = {(int(round(x * 1e4)), int(round(y * 1e4))): i for i, (x, y) in enumerate(P)}
    if eixo == 'y':
        return np.array([chave.get((int(round(x * 1e4)), int(round(-y * 1e4))), -1) for x, y in P])
    return np.array([chave.get((int(round(-x * 1e4)), int(round(y * 1e4))), -1) for x, y in P])


def main():
    pasta = sys.argv[1] if len(sys.argv) > 1 else 'fumaca'
    # 1. relé da B39 sem mudança
    h = hashlib.sha256(open(os.path.join(AQUI, 'b39_rele.py'), 'rb').read()).hexdigest()
    conf('relé idêntico ao da B39 (SHA-256)', h == SHA_RELE_B39, h[:16])
    # 2. malha plana: área, simetria de L, soma das linhas, espelhos
    R, a = 40.0, 0.75
    P, T = MB.disco(R, a)
    L, A = MB.cotan(np.column_stack([P, np.zeros(len(P))]), T)
    err_area = abs(A.sum() / (np.pi * R ** 2) - 1)
    conf('área do disco (erro relativo)', err_area < 0.02, f'{err_area:.4f}')
    conf('L simétrica e linhas somando zero', abs(L - L.T).max() < 1e-12 and abs(L.sum(1)).max() < 1e-10,
         f'{abs(L - L.T).max():.1e}, {abs(L.sum(1)).max():.1e}')
    my, mx = espelho(P, 'y'), espelho(P, 'x')
    conf('malha simétrica nos espelhos y→−y e x→−x', (my >= 0).all() and (mx >= 0).all(),
         f'faltam {(my < 0).sum()} e {(mx < 0).sum()}')
    cs = MB.casas_grade(8.0, 6.0, 30.0); cv = MB.vertice_mais_proximo(P, cs)
    cvy = MB.vertice_mais_proximo(P, cs * [1, -1]); cvx = MB.vertice_mais_proximo(P, cs * [-1, 1])
    fora_y = cs[:, 1] != 0; fora_x = cs[:, 0] != 0            # casas sobre o próprio eixo ficam de fora
    nd = int(np.sum((my[cv] != cvy) & fora_y) + np.sum((mx[cv] != cvx) & fora_x))
    conf('casas fora do eixo caem no vértice espelhado', nd == 0, f'{nd} diferenças')
    # 3. altura (Poisson) × solução analítica de uma carga gaussiana no disco com h = 0 na borda
    al, sg = 4.0, 3.0
    hh = MB.altura(P, T, R, a, [(0.0, 0.0, al, sg)])
    r = np.hypot(P[:, 0], P[:, 1]); rr = np.maximum(r, 1e-9)
    han = al * (np.log(rr / R) + 0.5 * exp1(rr ** 2 / (2 * sg ** 2)) - 0.5 * exp1(R ** 2 / (2 * sg ** 2)))
    han[r < 1e-9] = al * (np.log(np.sqrt(2) * sg / R) - 0.5 * np.euler_gamma - 0.5 * exp1(R ** 2 / (2 * sg ** 2)))
    e = np.max(np.abs(hh - han)) / abs(han.min())
    conf('altura do lençol × solução analítica (erro/profundidade)', e < 0.01, f'{e:.4f}')
    # 4. distância geodésica (calor): plano × euclidiana; vale × integral radial
    V0 = np.column_stack([P, np.zeros(len(P))]); f0 = int(np.argmin(r))
    d0 = MB.geodesica(V0, T, L, A, f0); m = (r > 8) & (r < 0.8 * R)
    e0 = np.mean(np.abs(d0[m] - r[m]) / r[m])
    conf('distância na superfície, plano (erro relativo médio)', e0 < 0.015, f'{e0:.4f}')
    V1 = np.column_stack([P, hh]); L1, A1 = MB.cotan(V1, T)
    d1 = MB.geodesica(V1, T, L1, A1, f0)
    rg = np.linspace(0, R, 4001); hg = al * (np.log(np.maximum(rg, 1e-9) / R) + 0.5 * exp1(np.maximum(rg, 1e-9) ** 2 / (2 * sg ** 2)))
    hp = np.gradient(hg, rg); hp[0] = 0.0
    s = np.concatenate([[0], np.cumsum(0.5 * (np.sqrt(1 + hp[1:] ** 2) + np.sqrt(1 + hp[:-1] ** 2)) * np.diff(rg))])
    e1_ = np.mean(np.abs((d1[m] - d0[m]) - (np.interp(r[m], rg, s) - r[m])))
    conf('caminho extra no vale × integral radial (erro absoluto médio)', e1_ < 0.3, f'{e1_:.3f}')
    # 5. energia conservada sem amortecimento (RK4), com casas acopladas
    b = DN.Base(P, hh, L1, A1, R, R + 1.0, 0.0, cv, C.W0, C.G, 0.0, np.full(len(cv), C.OM))
    P1, P2 = b.fonte(0.0, 0.0, 4.0)                            # pacote na banda da mensagem (largura 4)
    u = 0.01 * P1 / A1; v = np.zeros_like(u); q = np.zeros(len(cv)); w = np.zeros(len(cv))
    def en(u, v, q, w):
        return b.energia(u, v) + 0.5 * np.sum(w ** 2 + b.Omc ** 2 * q ** 2) + C.G * np.sum(q * u[cv])
    E0 = en(u, v, q, w); dt = C.DT; Z = np.zeros_like(u)
    for _ in range(300):
        a1u, a1q = b.acel(u, v, q, w, Z)
        u2 = u + .5 * dt * v; v2 = v + .5 * dt * a1u; q2 = q + .5 * dt * w; w2 = w + .5 * dt * a1q
        a2u, a2q = b.acel(u2, v2, q2, w2, Z)
        u3 = u + .5 * dt * v2; v3 = v + .5 * dt * a2u; q3 = q + .5 * dt * w2; w3 = w + .5 * dt * a2q
        a3u, a3q = b.acel(u3, v3, q3, w3, Z)
        u4 = u + dt * v3; v4 = v + dt * a3u; q4 = q + dt * w3; w4 = w + dt * a3q
        a4u, a4q = b.acel(u4, v4, q4, w4, Z)
        u, v, q, w = (u + dt / 6 * (v + 2 * v2 + 2 * v3 + v4), v + dt / 6 * (a1u + 2 * a2u + 2 * a3u + a4u),
                      q + dt / 6 * (w + 2 * w2 + 2 * w3 + w4), w + dt / 6 * (a1q + 2 * a2q + 2 * a3q + a4q))
    dE = abs(en(u, v, q, w) / E0 - 1)
    conf('energia conservada sem perdas (30 unidades de tempo)', dE < 1e-4, f'{dE:.1e}')
    # 6. rede estacionária × integração RK4 a partir do estado estacionário
    bD = DN.Base(P, hh, L1, A1, R, R - 6.0, C.DMAX, cv, C.W0, C.G, C.GAM_R, np.full(len(cv), C.OM))
    Xb, Xh = bD.rede(C.OM_R)
    u = np.real(Xb); v = np.real(1j * C.OM_R * Xb); q = np.real(Xh); w = np.real(1j * C.OM_R * Xh)
    t = 0.0
    for _ in range(200):
        F = lambda tt: bD.A * np.cos(C.OM_R * tt)
        a1u, a1q = bD.acel(u, v, q, w, F(t))
        u2 = u + .5 * dt * v; v2 = v + .5 * dt * a1u; q2 = q + .5 * dt * w; w2 = w + .5 * dt * a1q
        a2u, a2q = bD.acel(u2, v2, q2, w2, F(t + .5 * dt))
        u3 = u + .5 * dt * v2; v3 = v + .5 * dt * a2u; q3 = q + .5 * dt * w2; w3 = w + .5 * dt * a2q
        a3u, a3q = bD.acel(u3, v3, q3, w3, F(t + .5 * dt))
        u4 = u + dt * v3; v4 = v + dt * a3u; q4 = q + dt * w3; w4 = w + dt * a3q
        a4u, a4q = bD.acel(u4, v4, q4, w4, F(t + dt))
        u, v, q, w = (u + dt / 6 * (v + 2 * v2 + 2 * v3 + v4), v + dt / 6 * (a1u + 2 * a2u + 2 * a3u + a4u),
                      q + dt / 6 * (w + 2 * w2 + 2 * w3 + w4), w + dt / 6 * (a1q + 2 * a2q + 2 * a3q + a4q))
        t += dt
    an = np.real(Xh * np.exp(1j * C.OM_R * t))
    e_r = np.max(np.abs(q - an)) / np.max(np.abs(Xh))
    conf('rede estacionária × RK4 (casas, 20 unidades de tempo)', e_r < 1e-4, f'{e_r:.1e}')
    # 7. fonte em saca-rolha: P1 ⟂ P2, mesma norma; espelho y→−y: P1 par, P2 ímpar
    bF = DN.Base(P, np.zeros(len(P)), L, A, R, R - 6.0, C.DMAX, cv, C.W0, C.G, C.GAM_R, np.full(len(cv), C.OM))
    Q1, Q2 = bF.fonte(0.0, 0.0, C.SIG_FONTE)
    orto = abs(Q1 @ (Q2 / A)) / np.sqrt((Q1 @ (Q1 / A)) * (Q2 @ (Q2 / A)))
    par = np.max(np.abs(Q1[my] - Q1)) / np.max(np.abs(Q1)); impar = np.max(np.abs(Q2[my] + Q2)) / np.max(np.abs(Q2))
    conf('dipolo girante: P1 ⟂ P2 e espelho (P1 par, P2 ímpar)', orto < 1e-10 and par < 1e-10 and impar < 1e-10,
         f'{orto:.1e}, {par:.1e}, {impar:.1e}')
    # 8. lapso constante: L_N = n0·L
    n0 = 0.9
    bN = DN.Base(P, np.zeros(len(P)), L, A, R, R - 6.0, C.DMAX, cv, C.W0, C.G, C.GAM_R, np.full(len(cv), C.OM),
                 N=np.full(len(P), n0))
    eN = abs(bN.LN - n0 * L).max()
    conf('lapso constante dá L_N = N·L', eN < 1e-12, f'{eN:.1e}')
    # 9. velocidade de grupo: lapso ≡ 1 ⇒ contínuo v_g(1) ≈ 0,50; poço baixa a lacuna e acelera
    v1 = DN.vg(1.0, C.W0, C.OM); v9 = DN.vg(0.95, C.W0, C.OM)
    conf('v_g contínuo: 0,50 no plano e maior no poço (N = 0,95)', abs(v1 - 0.502) < 0.002 and v9 > v1,
         f'{v1:.4f}, {v9:.4f}')
    # 10. margem > 1 ⇔ acerto = 1 (rodadas da fumaça, janelas do avaliador)
    import avaliar_B39V as AV
    import json
    arqs = sorted(f for f in os.listdir(pasta) if f.endswith('.npz')) if os.path.isdir(pasta) else []
    if 'G_P_s+1.npz' in arqs:
        cfg = json.load(open(os.path.join(pasta, 'config_B39V.json'))); p = cfg['parametros']
        Pr = AV.ler(os.path.join(pasta, 'G_P_s+1.npz'))
        t0, vv = AV.lei(Pr['dg'], Pr['t50']); tp0, vp = AV.lei(Pr['dg'], Pr['tpk'])
        ruins = 0; n = 0
        for f in arqs:
            c = AV.ler(os.path.join(pasta, f)); H = c['R'].shape[1]
            tst = tp0 + c['dg'] / vp; Dl = p['PASSO_OLA'] / vp
            ini = {k: tst[k] - Dl / 2 for k in range(H)}; fim = {k: tst[k] + Dl / 2 for k in range(H)}
            pos = {k: tst[k] + Dl for k in range(H)}; ordem = [int(k) for k in np.argsort(tst)]
            mm = RL.medidas(c['ts'], c['R'], ordem, ini, fim, pos, Dl)
            for modo in ('trava', 'solta'):
                n += 1
                if (mm['margem_' + modo] > 1) != (mm['acerto_' + modo] == 1.0):
                    ruins += 1
        conf('margem > 1 ⇔ acerto = 1 (fumaça, trava e solta)', ruins == 0, f'{n - ruins}/{n} rodadas')
    else:
        conf('margem > 1 ⇔ acerto = 1 (fumaça, trava e solta)', False, 'fumaça ausente')
    nok = sum(1 for _, ok, _ in res if ok)
    if nok == len(res):
        print(f'TODAS AS {len(res)} PEÇAS CONFEREM')
    else:
        print(f'{len(res) - nok} DE {len(res)} PEÇAS FALHARAM')


if __name__ == '__main__':
    main()
