"""B39V — parâmetros congelados e lista de rodadas (modos 'completo' e 'fumaca')."""
import numpy as np

# ---------------------------------------------------------------- física (iguais nos dois modos)
W0 = 1.6               # lacuna da base (como W0c da linha C da B39)
OM = 1.85              # portadora da mensagem e sintonia das casas (como Ω_c da linha C)
OM_R = 1.0             # frequência da rede sempre ligada (abaixo da lacuna)
RAZAO_REDE = 500.0     # |força da rede| / |força da mensagem| (normas euclidianas), como na B39 (A/F0 = 10/0,02)
GAM_R = 0.10           # amortecimento da bobina (receptor)
G = 0.05               # acoplamento casa–base
F0 = 0.02              # força da mensagem
SIG_FONTE = 1.5        # largura do dipolo girante
DUR = 60.0             # duração do pulso sin²
DT = 0.1
AMOSTRA = 0.5
DMAX = 0.5             # amortecimento máximo da borda absorvente (rampa quadrática)
FOTOS = (60.0, 120.0, 180.0, 240.0, 300.0)
COM_FOTOS = ('G_P_s+1', 'G_V1a12_s+1', 'G_V2n_s+1', 'G_V2o_s+1')

MODOS = {
    'completo': dict(R=155.0, RABS=135.0, A=0.75, A_FINA=0.60, PASSO_CASAS=10.0, RMIN=12.0, RMAX=122.0,
                     TTOT=460.0, FAIXAS=((12.0, 45.0), (45.0, 85.0), (85.0, 123.0)), R_REF=100.0, PASSO_OLA=35.0,
                     VELHO=(0.0, 0.0, 12.0, 8.0), DOSE=(6.0, 12.0, 18.0),
                     V2n=(0.0, 55.0, 6.0, 5.0), V2o=(-45.0, 0.0, 8.0, 6.0),
                     ALFA_CASA=0.025, SIG_CASA=2.5, SEMENTES_V3=(44, 45), PHI=(0.03, 0.05, 0.08)),
    'fumaca': dict(R=80.0, RABS=65.0, A=0.90, A_FINA=0.75, PASSO_CASAS=8.0, RMIN=10.0, RMAX=56.0,
                   TTOT=250.0, FAIXAS=((10.0, 25.0), (25.0, 40.0), (40.0, 57.0)), R_REF=45.0, PASSO_OLA=35.0,
                   VELHO=(0.0, 0.0, 6.0, 4.0), DOSE=(3.0, 6.0, 9.0),
                   V2n=(0.0, 27.0, 3.0, 2.5), V2o=(-22.0, 0.0, 4.0, 3.0),
                   ALFA_CASA=0.0125, SIG_CASA=1.5, SEMENTES_V3=(44, 45), PHI=(0.03, 0.05, 0.08)),
}


def rodadas(modo):
    """lista de dicionários {nome, parte, paisagem, s, a, ...}."""
    p = MODOS[modo]
    x0, y0, al, sg = p['VELHO']
    out = []

    def add(nome, parte, gm, s, a, semente=None, phi=0.0, proprio=False):
        out.append(dict(nome=nome, parte=parte, gmft=gm, s=s, a=a, semente=semente, phi=phi, proprio=proprio))

    A, AF = p['A'], p['A_FINA']
    add('G_P_s+1', 'G', [], 1, A); add('G_P_s-1', 'G', [], -1, A)
    for d in p['DOSE']:
        tag = f'G_V1a{int(round(d * (12.0 / p["DOSE"][1])))}'      # rótulo pela dose relativa (6, 12, 18)
        gm = [(x0, y0, d, sg)]
        if abs(d - al) < 1e-12:
            add(tag + '_s+1', 'G', gm, 1, A); add(tag + '_s-1', 'G', gm, -1, A)
        else:
            add(tag + '_s+1', 'G', gm, 1, A)
    for k in ('V2n', 'V2o'):
        gm = [(x0, y0, al, sg), p[k]]
        add(f'G_{k}_s+1', 'G', gm, 1, A); add(f'G_{k}_s-1', 'G', gm, -1, A)
    for sem in p['SEMENTES_V3']:
        add(f'G_V3s{sem}_s+1', 'G', [(x0, y0, al, sg)], 1, A, semente=sem)
    for f in p['PHI']:
        add(f'T_T1f{int(round(100 * f)):02d}_s+1', 'T', [(x0, y0, al, sg)], 1, A, phi=f, proprio=False)
        add(f'T_T1Rf{int(round(100 * f)):02d}_s+1', 'T', [(x0, y0, al, sg)], 1, A, phi=f, proprio=True)
    add('M_P_s+1', 'M', [], 1, AF)
    add('M_V1a18_s+1', 'M', [(x0, y0, p['DOSE'][2], sg)], 1, AF)
    return out


def casas_v3(casas, semente, alfa_casa, sig_casa):
    rng = np.random.default_rng(semente)
    idades = rng.uniform(0.0, 1.0, len(casas))
    return [(x, y, alfa_casa * i, sig_casa) for (x, y), i in zip(casas, idades)], idades
