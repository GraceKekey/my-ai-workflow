"""B39V — figura. Uso: python -I src/figura_B39V.py <pasta> <saida.png>
Precisa dos checkpoints e de <pasta>/avaliacao_B39V.json (rode antes o avaliador)."""
import json, os, sys
import numpy as np
AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import avaliar_B39V as AV
import b39v_membrana as MB
import b39_rele as RL
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.tri as mtri
from matplotlib.colors import LogNorm

plt.rcParams.update({'font.size': 8.5, 'axes.titlesize': 9.5, 'axes.titleweight': 'bold',
                     'axes.spines.top': False, 'axes.spines.right': False})
COR = {'G_P': '#8a8a8a', 'G_V1a6': '#9ec5f0', 'G_V1a12': '#2a78d6', 'G_V1a18': '#123f78', 'G_V2n': '#eb6834',
       'G_V2o': '#1baf7a', 'T1': '#6250d6', 'T1R': '#e34948'}


def main():
    pasta, saida = sys.argv[1], sys.argv[2]
    av = json.load(open(os.path.join(pasta, 'avaliacao_B39V.json')))
    med = av['medidas']; cfg = json.load(open(os.path.join(pasta, 'config_B39V.json'))); p = cfg['parametros']
    cal = med['calibracao']
    C = {}
    for n in med['presentes']:
        C[n] = AV.ler(os.path.join(pasta, n + '.npz'))
    fig = plt.figure(figsize=(15.5, 15.5)); gs = fig.add_gridspec(3, 3, hspace=0.33, wspace=0.27)
    # (a) perfis do lençol (corte y = 0; V2n no corte x = 0)
    ax = fig.add_subplot(gs[0, 0])
    R, a = p['R'], p['A']; P, T = MB.disco(R, a)
    x0, y0, al, sg = p['VELHO']
    for tag, gm, eixo in (('G_V1a6', [(x0, y0, p['DOSE'][0], sg)], 'x'), ('G_V1a12', [(x0, y0, al, sg)], 'x'),
                          ('G_V1a18', [(x0, y0, p['DOSE'][2], sg)], 'x'), ('G_V2n', [(x0, y0, al, sg), p['V2n']], 'y'),
                          ('G_V2o', [(x0, y0, al, sg), p['V2o']], 'x')):
        h = MB.altura(P, T, R, a, [tuple(g) for g in gm])
        m = np.abs(P[:, 1 if eixo == 'x' else 0]) < 0.4 * a
        c = P[m, 0 if eixo == 'x' else 1]; o = np.argsort(c)
        ax.plot(c[o], h[m][o], color=COR[tag], lw=1.8, label=tag[2:] + (' (corte x = 0)' if eixo == 'y' else ''))
    ax.axhline(0, color=COR['G_P'], ls='--', lw=1, label='plano')
    ax.axvspan(p['RABS'], R, color='#e2e2df', alpha=0.6); ax.axvspan(-R, -p['RABS'], color='#e2e2df', alpha=0.6)
    ax.set_xlabel('posição no corte'); ax.set_ylabel('altura do lençol'); ax.legend(frameon=False, fontsize=7.5)
    ax.set_title('(a) as paisagens (lençol visto de lado)')
    # (b, c) chegada × distância
    for j, (ch, rot) in enumerate((('r', 'distância vista de cima'), ('dg', 'distância ao longo da superfície'))):
        ax = fig.add_subplot(gs[0, 1 + j])
        for tag in ('G_V1a18', 'G_V2n', 'G_P'):
            n = tag + '_s+1'
            if n in C:
                ax.scatter(C[n][ch], C[n]['t50'], s=6, color=COR[tag], alpha=0.6, linewidths=0, label=tag[2:])
        xx = np.linspace(0, p['RMAX'] + 5, 10)
        ax.plot(xx, cal['t0'] + xx / cal['v'], 'k--', lw=0.9, label=f"lei do plano ({cal['t0']:.1f} + d/{cal['v']:.3f})")
        ax.set_xlabel(rot); ax.set_ylabel('chegada (meia subida da leitura)'); ax.legend(frameon=False, markerscale=3)
        ax.set_title('(b) chegada × distância vista de cima' if j == 0 else '(c) chegada × distância na superfície')
    # (d) atraso de cada casa × caminho extra/v
    ax = fig.add_subplot(gs[1, 0])
    mx = 0
    for tag in ('G_V1a6', 'G_V1a12', 'G_V1a18', 'G_V2n', 'G_V2o'):
        n = tag + '_s+1'
        if n in C and 'G_P_s+1' in C:
            dt = C[n]['t50'] - C['G_P_s+1']['t50']; dd = (C[n]['dg'] - C['G_P_s+1']['dg']) / cal['v']
            ax.scatter(dd, dt, s=5, color=COR[tag], alpha=0.6, linewidths=0,
                       label=f"{tag[2:]}: incl. {med['rodadas'][n].get('inclinacao', float('nan')):.2f}")
            mx = max(mx, dd.max(), dt.max())
    ax.plot([0, mx], [0, mx], 'k--', lw=0.9, label='atraso = caminho extra / v')
    ax.set_xlabel('caminho extra na superfície ÷ v (previsão geométrica)'); ax.set_ylabel('atraso medido (casa a casa)')
    ax.legend(frameon=False, markerscale=3, fontsize=7.5); ax.set_title('(d) o atraso é o caminho mais longo')
    # (e, f) a ola em dois instantes (V2n): energia da mensagem e lâmpadas acesas (relé que solta, limiar global)
    for j, (n, tt) in enumerate((('G_V1a12_s+1', 180.0), ('G_V2n_s+1', 180.0))):
        ax = fig.add_subplot(gs[1, 1 + j])
        arq = os.path.join(pasta, n + '.npz')
        if n not in C or 'snaps' not in np.load(arq).files:
            ax.set_axis_off(); continue
        d = np.load(arq); fotos = list(d['fotos']); tt = min(fotos, key=lambda x: abs(x - tt))
        e = np.maximum(d['snaps'][fotos.index(tt)].astype(float), 1e-16)
        tri = mtri.Triangulation(P[:, 0], P[:, 1], T)
        rP = np.hypot(P[:, 0], P[:, 1]); vmax = np.percentile(e[rP > 0.2 * R], 99.8)
        im = ax.tripcolor(tri, e, shading='gouraud', cmap='magma', norm=LogNorm(vmin=vmax * 1e-3, vmax=vmax),
                          rasterized=True)
        ax.tricontour(tri, d['h'], levels=8, colors='w', linewidths=0.4, alpha=0.6)
        c = C[n]; H = c['R'].shape[1]
        tst = cal['tp0'] + c['dg'] / cal['vp']; Dl = p['PASSO_OLA'] / cal['vp']
        mg = RL.margens(c['ts'], c['R'], {k: tst[k] - Dl / 2 for k in range(H)}, {k: tst[k] + Dl / 2 for k in range(H)},
                        {k: tst[k] + Dl for k in range(H)}, list(range(H)))
        rs = RL.rele(c['ts'], c['R'], mg['theta_solta'], 'solta'); it = int(np.argmin(np.abs(c['ts'] - tt)))
        ac = rs[it] > 0.5
        ax.scatter(c['casas'][~ac, 0], c['casas'][~ac, 1], s=4, c='#4a5568', alpha=0.7)
        ax.scatter(c['casas'][ac, 0], c['casas'][ac, 1], s=13, c='#fde047', edgecolors='k', linewidths=0.3)
        ax.set_aspect('equal'); ax.set_xlim(-p['RABS'], p['RABS']); ax.set_ylim(-p['RABS'], p['RABS'])
        ax.set_title(f'({"ef"[j]}) a ola em t = {tt:.0f} — {n[2:-4]} ({ac.sum()} acesas)')
        if j == 1:
            cb = plt.colorbar(im, ax=ax, shrink=0.8); cb.set_label('energia da mensagem na base (log)')
    # (g) lente
    ax = fig.add_subplot(gs[2, 0])
    if 'G_V2n_s+1' in C and 'G_V1a12_s+1' in C:
        cs = C['G_V2n_s+1']['casas']; lv = np.log2(C['G_V2n_s+1']['Rmax'] / C['G_V1a12_s+1']['Rmax']); vm = np.abs(lv).max()
        sc = ax.scatter(cs[:, 0], cs[:, 1], c=lv, s=18, cmap='PuOr_r', vmin=-vm, vmax=vm)
        cb = plt.colorbar(sc, ax=ax, shrink=0.8); cb.set_label('log₂ (sinal dois vales ÷ um vale)')
        ax.plot(*p['V2n'][:2], 'v', color='k'); ax.plot(0, 0, '*', color='k', ms=9)
        ax.set_aspect('equal')
    ax.set_title('(g) o segundo vale como lente (V2n)')
    # (h) quiralidade: mesma casa, s=+1 ÷ s=−1
    ax = fig.add_subplot(gs[2, 1])
    if 'G_V2n_s+1' in C and 'G_V2n_s-1' in C:
        cs = C['G_V2n_s+1']['casas']; lv = np.log2(C['G_V2n_s+1']['Rmax'] / C['G_V2n_s-1']['Rmax']); vm = np.abs(lv).max()
        sc = ax.scatter(cs[:, 0], cs[:, 1], c=lv, s=18, cmap='RdBu_r', vmin=-vm, vmax=vm)
        cb = plt.colorbar(sc, ax=ax, shrink=0.8); cb.set_label('log₂ (sinal s = +1 ÷ s = −1)')
        ax.plot(*p['V2n'][:2], 'v', color='k'); ax.plot(0, 0, '*', color='k', ms=9); ax.set_aspect('equal')
    ax.set_title('(h) o sentido do saca-rolha com dois vales (V2n)')
    # (i) relógio
    ax = fig.add_subplot(gs[2, 2])
    mk = {'03': 'o', '05': 's', '08': '^'}
    for tag in ('03', '05', '08'):
        a_, b_ = C.get(f'T_T1f{tag}_s+1'), C.get(f'T_T1Rf{tag}_s+1'); v1 = C.get('G_V1a12_s+1')
        if a_ is not None and v1 is not None:
            ax.scatter(v1['r'], a_['t50'] - v1['t50'], s=5, marker=mk[tag], color=COR['T1'], alpha=0.5, linewidths=0,
                       label=f'T1 − V1 (φ = 0,{tag})')
        if a_ is not None and b_ is not None:
            ax.scatter(v1['r'], b_['t50'] - a_['t50'], s=5, marker=mk[tag], color=COR['T1R'], alpha=0.5, linewidths=0,
                       label=f'T1R − T1 (φ = 0,{tag})')
    ax.axhline(0, color='#52514e', lw=0.7); ax.set_xlabel('distância vista de cima')
    ax.set_ylabel('diferença de chegada')
    ax.legend(frameon=False, fontsize=7, markerscale=2, ncol=3, loc='upper center', bbox_to_anchor=(0.5, -0.13))
    ax.set_title('(i) o relógio lento no poço')
    fig.suptitle(f"HRF — B39V · o vale 2,5D · modo {cfg['modo']}", fontsize=12, fontweight='bold')
    fig.savefig(saida, dpi=120, bbox_inches='tight')
    print('ok', saida)


if __name__ == '__main__':
    main()
