"""B39V — a membrana 2,5D (o lençol de borracha).

Malha triangular regular num disco de raio R (espaçamento projetado a).
Altura h(x, y) do lençol: T Δh = ρ (carga dos GMFt antigos), h = 0 na borda, T = 1,
    ρ = Σ_j m_j N(x − x_j; σ_j),  m_j = 2π α_j   (longe do GMFt, h ≈ α_j ln r).
Superfície z = h(x, y). Laplace–Beltrami pelos cotangentes em 3D (L positiva semidefinida = −Δ·área) e massa
concentrada (área de vértice = 1/3 das áreas dos triângulos vizinhos).
Distância geodésica pelo método do calor (Crane, Weischedel & Wardetzky 2013)."""
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl


def disco(R, a):
    """vértices (n × 2) e triângulos (m × 3) de uma rede triangular regular no disco de raio R."""
    nj = int(np.ceil(R / (a * np.sqrt(3) / 2))) + 2          # linhas em y (espaçadas de a·√3/2)
    ni = int(np.ceil(R / a + nj / 2)) + 2                       # colunas, com o deslocamento de meia célula por linha
    I, J = np.meshgrid(np.arange(-ni, ni + 1), np.arange(-nj, nj + 1), indexing='ij')
    x = a * (I + 0.5 * J); y = a * (np.sqrt(3) / 2) * J
    dentro = x ** 2 + y ** 2 <= R ** 2
    idx = -np.ones(I.shape, dtype=np.int64)
    idx[dentro] = np.arange(dentro.sum())
    P = np.stack([x[dentro], y[dentro]], 1)
    a00 = idx[:-1, :-1]; a10 = idx[1:, :-1]; a01 = idx[:-1, 1:]; a11 = idx[1:, 1:]
    t1 = np.stack([a00, a10, a01], -1).reshape(-1, 3)
    t2 = np.stack([a10, a11, a01], -1).reshape(-1, 3)
    T = np.concatenate([t1, t2])
    T = T[(T >= 0).all(1)]
    return P, T


def _cot(V, o, p, q):
    u = V[p] - V[o]; w = V[q] - V[o]
    return np.einsum('ij,ij->i', u, w) / np.linalg.norm(np.cross(u, w), axis=1)


def cotan(V, T):
    """L (esparsa, positiva semidefinida) e áreas de vértice A, para vértices V (n × 3)."""
    n = len(V)
    i, j, k = T[:, 0], T[:, 1], T[:, 2]
    ci, cj, ck = _cot(V, i, j, k), _cot(V, j, k, i), _cot(V, k, i, j)
    area = 0.5 * np.linalg.norm(np.cross(V[j] - V[i], V[k] - V[i]), axis=1)
    rows = np.concatenate([j, k, k, i, i, j]); cols = np.concatenate([k, j, i, k, j, i])
    w = 0.5 * np.concatenate([ci, ci, cj, cj, ck, ck])
    W = sp.coo_matrix((w, (rows, cols)), shape=(n, n)).tocsr()
    L = sp.diags(np.asarray(W.sum(1)).ravel()) - W
    A = np.bincount(np.concatenate([i, j, k]), weights=np.concatenate([area, area, area]) / 3.0, minlength=n)
    return L.tocsr(), A


def borda(P, R, a):
    return np.nonzero(np.hypot(P[:, 0], P[:, 1]) > R - 0.75 * a)[0]


def altura(P, T, R, a, gmft):
    """gmft: lista de (x, y, α, σ). Resolve Δh = ρ com h = 0 na borda."""
    n = len(P)
    if not gmft:
        return np.zeros(n)
    L, A = cotan(np.column_stack([P, np.zeros(n)]), T)
    rho = np.zeros(n)
    for (x0, y0, al, s) in gmft:
        r2 = (P[:, 0] - x0) ** 2 + (P[:, 1] - y0) ** 2
        rho += 2 * np.pi * al * np.exp(-r2 / (2 * s ** 2)) / (2 * np.pi * s ** 2)
    livre = np.setdiff1d(np.arange(n), borda(P, R, a))
    h = np.zeros(n)
    h[livre] = spl.spsolve(L[livre][:, livre].tocsc(), -A[livre] * rho[livre])
    return h


def geodesica(V, T, L, A, fonte):
    """distância ao longo da superfície a partir do vértice 'fonte' (método do calor, t = (aresta média)²)."""
    n = len(V)
    i, j, k = T[:, 0], T[:, 1], T[:, 2]
    e = np.concatenate([np.linalg.norm(V[j] - V[i], axis=1), np.linalg.norm(V[k] - V[j], axis=1),
                        np.linalg.norm(V[i] - V[k], axis=1)])
    t = np.mean(e) ** 2
    d = np.zeros(n); d[fonte] = 1.0
    u = spl.spsolve((sp.diags(A) + t * L).tocsc(), d)
    Nrm = np.cross(V[j] - V[i], V[k] - V[i]); a2 = np.linalg.norm(Nrm, axis=1); Nn = Nrm / a2[:, None]
    g = (u[i][:, None] * np.cross(Nn, V[k] - V[j]) + u[j][:, None] * np.cross(Nn, V[i] - V[k])
         + u[k][:, None] * np.cross(Nn, V[j] - V[i])) / a2[:, None]
    X = -g / np.maximum(np.linalg.norm(g, axis=1), 1e-300)[:, None]
    ci, cj, ck = _cot(V, i, j, k), _cot(V, j, k, i), _cot(V, k, i, j)
    div = np.zeros(n)
    for (o, p, q, cp, cq) in ((i, j, k, ck, cj), (j, k, i, ci, ck), (k, i, j, cj, ci)):
        e1 = V[p] - V[o]; e2 = V[q] - V[o]
        np.add.at(div, o, 0.5 * (cp * np.einsum('ij,ij->i', e1, X) + cq * np.einsum('ij,ij->i', e2, X)))
    phi = spl.spsolve((L + 1e-10 * sp.diags(A)).tocsc(), div)
    phi = phi - phi[fonte]
    if np.median(phi) < 0:
        phi = -phi
    return phi


def casas_grade(passo, rmin, rmax):
    """grade quadrada simétrica (contém a origem), casas com rmin ≤ r ≤ rmax."""
    m = int(np.floor(rmax / passo))
    g = passo * np.arange(-m, m + 1)
    X, Y = np.meshgrid(g, g); X = X.ravel(); Y = Y.ravel()
    r = np.hypot(X, Y); ok = (r >= rmin) & (r <= rmax)
    return np.column_stack([X[ok], Y[ok]])


def vertice_mais_proximo(P, pts):
    """vértice mais próximo de cada ponto. Empates (pontos a meio caminho entre vértices) são desfeitos pela menor
    |x| e depois pela menor |y|, regra que respeita os espelhos x→−x e y→−y (fora dos pontos sobre o próprio eixo)."""
    from scipy.spatial import cKDTree
    d, idx = cKDTree(P).query(pts, k=6)
    out = np.empty(len(pts), dtype=np.int64)
    for n in range(len(pts)):
        cand = idx[n][d[n] <= d[n][0] + 1e-9]
        if len(cand) == 1:
            out[n] = cand[0]; continue
        chave = sorted(cand, key=lambda i: (round(abs(P[i, 0]), 9), round(abs(P[i, 1]), 9), -P[i, 0], -P[i, 1]))
        out[n] = chave[0]
    return out
