"""B39V — avaliador congelado. Uso: python -I src/avaliar_B39V.py <pasta>
Lê os checkpoints de <pasta>, mede cada rodada (medir), classifica (classificar) e grava <pasta>/avaliacao_B39V.json.
As regras estão no protocolo (§7); os limiares estão abaixo."""
import json, os, sys
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import b39_rele as RL

# ---------------------------------------------------------------- limiares congelados
INV_DIST = 10.0          # inversão: casa mais distante (por > 10, na superfície) dispara antes
KENDALL_MIN = 0.90       # ordem (chegada ou disparo) × distância na superfície (só grosseiro; o teste é a inversão)
DISPARO_MIN = 0.9        # fração mínima de casas que disparam para julgar a ordem
INCL_MIN, INCL_MAX = 0.8, 1.3   # inclinação atraso × caminho extra/v
CORR_MIN = 0.9           # correlação atraso × caminho extra/v
SEM_ATRASO = 1.0         # |atraso de referência| abaixo disso: sem atraso
DOSE_MIN, DOSE_MAX = 0.8, 1.4   # atraso medido / previsto (geométrico) na distância de referência
FOCO, SOMBRA = 1.5, 0.67 # lente: razão de sinal atrás do segundo vale
SOMBRA_CASA = 0.8        # casa na sombra: sinal < 0,8 do sinal com um vale só
LIMPO_MIN, LIMPO_MAX = 0.8, 1.25
AQUIRAL_DEV = 0.05       # |sinal(s=+1)/sinal(s=−1) − 1| máximo na mesma casa
QUIRAL_DEV = 0.20
ESPELHO_ERR = 0.03       # erro máximo da imagem no espelho
CIDADE_DT = 2.0          # |atraso mediano da cidade com idades − um vale|
VERMELHO_SPEARMAN = -0.5 # Spearman (sinal T1R/T1 × altura da casa)
MALHA_TOL = 0.15         # |atraso(malha fina)/atraso(malha 0,75) − 1|
REDE_MAX = 0.1           # leitura só da rede / limiar
FALTA_MAX = 1.0 / 3.0


# ---------------------------------------------------------------- medidas
def t_meia(ts, x):
    """primeiro instante (interpolado) em que x atinge metade do seu máximo."""
    m = 0.5 * x.max()
    i = int(np.argmax(x >= m))
    if i == 0:
        return float(ts[0])
    f = (m - x[i - 1]) / (x[i] - x[i - 1])
    return float(ts[i - 1] + f * (ts[i] - ts[i - 1]))


def ler(arq):
    d = np.load(arq)
    ts, X, Pm = d['ts'], d['X'], d['Pm']
    R = RL.leitura(ts, X, Pm, d['Omc'], Xr=d['Xr_h'], A=float(d['rho_r']), Om_r=1.0)
    Rm = RL.leitura(ts, X, Pm, d['Omc'])
    R0 = RL.leitura(ts, np.zeros_like(X), np.zeros_like(Pm), d['Omc'], Xr=d['Xr_h'], A=float(d['rho_r']), Om_r=1.0)
    casas = d['casas']
    return dict(ts=ts, R=R, Rm=Rm, R0max=float(R0.max()), casas=casas, pos_v=d['pos_v'],
                r=np.hypot(casas[:, 0], casas[:, 1]),
                dg=d['dgeo_casas'], h=d['h_casas'], Rmax=Rm.max(0),
                t50=np.array([t_meia(ts, Rm[:, k]) for k in range(Rm.shape[1])]),
                tpk=ts[np.argmax(Rm, 0)])


def lei(dg, t):
    co = np.polyfit(dg, t, 1)
    return float(co[1]), float(1.0 / co[0])


def kendall(a, b):
    from scipy.stats import kendalltau
    return float(kendalltau(a, b).correlation)


def spearman(a, b):
    from scipy.stats import spearmanr
    return float(spearmanr(a, b).correlation)


def medir_rodada(c, cal, p):
    ts, R = c['ts'], c['R']; H = R.shape[1]
    tst = cal['tp0'] + c['dg'] / cal['vp']; Dl = p['PASSO_OLA'] / cal['vp']
    ini = {k: tst[k] - Dl / 2 for k in range(H)}; fim = {k: tst[k] + Dl / 2 for k in range(H)}
    pos = {k: tst[k] + Dl for k in range(H)}
    ordem = [int(k) for k in np.argsort(tst)]
    out = {}
    mg = RL.margens(ts, R, ini, fim, pos, ordem)
    out['frente_global'] = mg['margem_trava']; out['ola_global'] = mg['margem_solta']
    fx = []
    for (a, b) in p['FAIXAS']:
        sel = [k for k in ordem if a <= c['r'][k] < b]
        m = RL.margens(ts, R, ini, fim, pos, sel)
        fx.append(dict(faixa=[a, b], n=len(sel), frente=m['margem_trava'], ola=m['margem_solta']))
    out['faixas'] = fx
    th = mg['theta_trava']
    r = RL.rele(ts, R, th, 'trava')
    tf = np.array([ts[np.argmax(r[:, k] > 0.5)] if r[:, k].max() > 0.5 else np.nan for k in range(H)])
    ok = ~np.isnan(tf)
    out['dispararam'] = int(ok.sum()); out['H'] = H
    out['kendall_geo'] = kendall(tf[ok], c['dg'][ok]); out['kendall_proj'] = kendall(tf[ok], c['r'][ok])
    ii = np.nonzero(ok)[0]
    for nome, dist in (('inv_geo', c['dg']), ('inv_proj', c['r'])):
        dd = dist[ii]; tt = tf[ii]
        out[nome] = int(np.sum((dd[None, :] - dd[:, None] > INV_DIST) & (tt[None, :] < tt[:, None])))
    # ordem da chegada: meia subida da leitura de cada casa (cada uma na sua própria escala)
    t5 = c['t50']; dg = c['dg']
    out['kendall_chegada'] = kendall(t5, dg)
    out['inv_chegada'] = int(np.sum((dg[None, :] - dg[:, None] > INV_DIST) & (t5[None, :] < t5[:, None])))
    pares = np.argwhere((dg[ii][None, :] - dg[ii][:, None] > INV_DIST) & (tf[ii][None, :] < tf[ii][:, None]))
    out['_pares_inv'] = [[int(ii[a]), int(ii[b])] for a, b in pares]      # (mais perto que disparou depois, mais longe)
    out['_nao_disparam'] = [int(k) for k in np.nonzero(~ok)[0]]
    out['rede_sobre_limiar'] = c['R0max'] / th
    out['_tf'] = tf.tolist()
    return out


def medir(pasta):
    cfg = json.load(open(os.path.join(pasta, 'config_B39V.json')))
    p = cfg['parametros']
    sys.path.insert(0, AQUI)
    import b39v_config as C
    nomes = [r['nome'] for r in C.rodadas(cfg['modo'])]
    C_ = {}
    for n in nomes:
        f = os.path.join(pasta, n + '.npz')
        if os.path.exists(f):
            C_[n] = ler(f)
    med = {'modo': cfg['modo'], 'esperadas': nomes, 'presentes': sorted(C_), 'rodadas': {}}
    if 'G_P_s+1' not in C_:
        return med
    P = C_['G_P_s+1']
    t0, v = lei(P['dg'], P['t50']); tp0, vp = lei(P['dg'], P['tpk'])
    cal = dict(t0=t0, v=v, tp0=tp0, vp=vp); med['calibracao'] = cal
    for n, c in C_.items():
        o = medir_rodada(c, cal, p)
        ref = C_.get('G_P_s-1' if (n.endswith('s-1') and n != 'G_P_s-1') else 'G_P_s+1')
        if n.startswith('M_'):
            ref = C_.get('M_P_s+1')
        if ref is not None and len(ref['t50']) == len(c['t50']):
            dt = c['t50'] - ref['t50']; dd = (c['dg'] - ref['dg']) / v
            if np.std(dd) > 1e-9 and np.std(dt) > 1e-9:
                co = np.polyfit(dd, dt, 1); o['inclinacao'] = float(co[0]); o['correlacao'] = float(np.corrcoef(dd, dt)[0, 1])
            else:
                o['inclinacao'] = None; o['correlacao'] = None
            sel = np.abs(c['r'] - p['R_REF']) <= 5.0
            o['atraso_ref'] = float(np.median(dt[sel])); o['previsto_ref'] = float(np.median(dd[sel]))
            o['atraso_mediano'] = float(np.median(dt))
        med['rodadas'][n] = o
    # lente: V2 × V1a12, atrás do segundo vale
    for k in ('V2n', 'V2o'):
        x2, y2 = p[k][0], p[k][1]; r2 = np.hypot(x2, y2); ang2 = np.arctan2(y2, x2)
        for s in ('+1', '-1'):
            a, b = C_.get(f'G_{k}_s{s}'), C_.get(f'G_V1a12_s{s}')
            if a is None or b is None:
                continue
            ang = np.arctan2(a['casas'][:, 1], a['casas'][:, 0])
            dang = np.abs((ang - ang2 + np.pi) % (2 * np.pi) - np.pi)
            atras = (a['r'] > r2 + 15.0) & (dang <= np.pi / 4)
            rat = a['Rmax'] / b['Rmax']
            o = med['rodadas'][f'G_{k}_s{s}']
            o['foco'] = float(rat[atras].max()); o['sombra'] = float(rat[atras].min()); o['n_atras'] = int(atras.sum())
            o['inv_na_sombra'] = int(sum(1 for i, j in o['_pares_inv'] if rat[i] < SOMBRA_CASA))
            o['nao_disparam_na_sombra'] = int(sum(1 for i in o['_nao_disparam'] if rat[i] < SOMBRA_CASA))
    # quiralidade e espelho
    eixos = {'P': 'y', 'V1a12': 'y', 'V2n': 'x', 'V2o': 'y'}
    med['quiral'] = {}
    for k, e in eixos.items():
        a, b = C_.get(f'G_{k}_s+1'), C_.get(f'G_{k}_s-1')
        if a is None or b is None:
            continue
        pv = a['pos_v']                                   # o par no espelho é a casa cujo vértice é o espelhado
        chave = {(int(round(x * 1e4)), int(round(y * 1e4))): i for i, (x, y) in enumerate(pv)}
        mir = np.array([chave.get((int(round(x * 1e4)), int(round(-y * 1e4))) if e == 'y'
                                  else (int(round(-x * 1e4)), int(round(y * 1e4))), -1) for x, y in pv])
        okm = mir >= 0
        med['quiral'][k] = dict(dev_mesma_casa=float(np.max(np.abs(a['Rmax'] / b['Rmax'] - 1))),
                                erro_espelho=float(np.max(np.abs(a['Rmax'][okm] / b['Rmax'][mir[okm]] - 1))),
                                pares=int(okm.sum()))
    # relógio
    med['relogio'] = {}
    V1 = C_.get('G_V1a12_s+1')
    for f in p['PHI']:
        tag = f'{int(round(100 * f)):02d}'
        a, b = C_.get(f'T_T1f{tag}_s+1'), C_.get(f'T_T1Rf{tag}_s+1')
        o = {}
        sel = np.abs(P['r'] - p['R_REF']) <= 5.0
        if a is not None and V1 is not None:
            o['T1_menos_V1'] = float(np.median((a['t50'] - V1['t50'])[sel]))
        if a is not None and b is not None:
            o['T1R_menos_T1'] = float(np.median((b['t50'] - a['t50'])[sel]))
            o['spearman_sinal_altura'] = spearman(b['Rmax'] / a['Rmax'], b['h'])
        med['relogio'][tag] = o
    # cidade com idades
    med['cidade'] = {}
    for s_ in p['SEMENTES_V3']:
        a = C_.get(f'G_V3s{s_}_s+1')
        if a is not None and V1 is not None:
            med['cidade'][str(s_)] = float(np.median(a['t50'] - V1['t50']))
    # malha
    a, b = C_.get('M_V1a18_s+1'), C_.get('G_V1a18_s+1')
    if a is not None and b is not None and 'atraso_ref' in med['rodadas'].get('M_V1a18_s+1', {}) \
            and 'atraso_ref' in med['rodadas'].get('G_V1a18_s+1', {}):
        med['malha'] = dict(razao_atraso=med['rodadas']['M_V1a18_s+1']['atraso_ref'] /
                            med['rodadas']['G_V1a18_s+1']['atraso_ref'])
    return med


# ---------------------------------------------------------------- regras
def classe_ordem(o):
    """a ordem é julgada entre as casas que disparam (limiar comum do meio); a sombra de uma lente pode deixar
    casas sem disparar, o que fica na classe da frente."""
    if o is None:
        return 'INSUFICIENTE'
    if o['dispararam'] < DISPARO_MIN * o['H']:
        return 'POUCAS_DISPARAM'
    return 'MESMA_SEQUENCIA' if (o['inv_geo'] == 0 and o['kendall_geo'] >= KENDALL_MIN) else 'SEQUENCIA_ALTERADA'


def classe_chegada(o):
    if o is None:
        return 'INSUFICIENTE'
    return 'MESMA_SEQUENCIA' if (o['inv_chegada'] == 0 and o['kendall_chegada'] >= KENDALL_MIN) else 'SEQUENCIA_ALTERADA'


def classe_disparo(o):
    """relés iguais (limiar comum do meio). Em V2, inversões em que a casa atrasada está na sombra da lente e casas
    que não disparam na sombra são TROCA_NA_SOMBRA."""
    if o is None:
        return 'INSUFICIENTE'
    c = classe_ordem(o)
    if c != 'SEQUENCIA_ALTERADA':
        return c
    if 'inv_na_sombra' in o and o['inv_geo'] > 0 and o['inv_na_sombra'] == o['inv_geo'] and o['kendall_geo'] >= KENDALL_MIN:
        return 'TROCA_NA_SOMBRA'
    return 'SEQUENCIA_ALTERADA'


def classe_atraso(o):
    if o is None or 'atraso_ref' not in o:
        return 'INSUFICIENTE'
    if abs(o['atraso_ref']) < SEM_ATRASO:
        return 'SEM_ATRASO'
    if o.get('inclinacao') is not None and INCL_MIN <= o['inclinacao'] <= INCL_MAX and o['correlacao'] >= CORR_MIN:
        return 'ATRASO_GEOMETRICO'
    return 'ATRASO_NAO_GEOMETRICO'


def classe_dose(r6, r12, r18):
    if None in (r6, r12, r18) or any('atraso_ref' not in x for x in (r6, r12, r18)):
        return 'INSUFICIENTE'
    a = [x['atraso_ref'] for x in (r6, r12, r18)]
    q = [x['atraso_ref'] / x['previsto_ref'] if x['previsto_ref'] > 0 else np.inf for x in (r6, r12, r18)]
    if a[0] < a[1] < a[2] and all(DOSE_MIN <= z <= DOSE_MAX for z in q):
        return 'DOSE_GEOMETRICA'
    if a[0] < a[1] < a[2]:
        return 'DOSE_MONOTONA_FORA_DA_GEOMETRIA'
    return 'SEM_DOSE'


def classe_lente(o):
    if o is None or 'foco' not in o:
        return 'INSUFICIENTE'
    if o['foco'] >= FOCO and o['sombra'] <= SOMBRA:
        return 'LENTE'
    if o['foco'] <= LIMPO_MAX and o['sombra'] >= LIMPO_MIN:
        return 'SEM_LENTE'
    return 'LENTE_PARCIAL'


def classe_quiral(q):
    if q is None:
        return 'INSUFICIENTE'
    if q['dev_mesma_casa'] <= AQUIRAL_DEV:
        return 'AQUIRAL'
    if q['dev_mesma_casa'] >= QUIRAL_DEV and q['erro_espelho'] <= ESPELHO_ERR:
        return 'QUIRAL_ESPELHO'
    return 'PARCIAL'


def classe_relogio(rel, phis):
    v = [rel.get(f'{int(round(100 * f)):02d}', {}).get('T1_menos_V1') for f in phis]
    if any(x is None for x in v):
        return 'INSUFICIENTE'
    if all(x < 0 for x in v) and v[0] > v[1] > v[2]:
        return 'RELOGIO_ACELERA_A_ONDA'
    if all(x > 0 for x in v) and v[0] < v[1] < v[2]:
        return 'RELOGIO_ATRASA_A_ONDA'
    return 'RELOGIO_MISTO'


def classe_vermelho(rel, phis):
    z = [rel.get(f'{int(round(100 * f)):02d}', {}) for f in phis]
    if any('T1R_menos_T1' not in x for x in z):
        return 'INSUFICIENTE'
    d = [x['T1R_menos_T1'] for x in z]; sp_ = [x['spearman_sinal_altura'] for x in z]
    if all(x > 0 for x in d) and d[0] < d[1] < d[2] and all(x <= VERMELHO_SPEARMAN for x in sp_):
        return 'DESVIO_PARA_O_VERMELHO'
    if all(x <= VERMELHO_SPEARMAN for x in sp_):
        return 'VERMELHO_SO_NO_SINAL'
    return 'SEM_DESVIO_CLARO'


def classe_ola(o):
    if o is None:
        return 'INSUFICIENTE'
    n = sum(1 for f in o['faixas'] if f['ola'] > 1)
    if n == len(o['faixas']):
        return 'OLA_LIMPA_POR_FAIXAS'
    return 'OLA_PARCIAL' if n > 0 else 'SEM_OLA'


def classe_frente(o):
    if o is None:
        return 'INSUFICIENTE'
    return 'FRENTE_COMPLETA' if o['frente_global'] > 1 else 'FRENTE_INCOMPLETA'


def classificar(med):
    rod = med.get('rodadas', {})
    esp = med.get('esperadas', [])
    falta = 1 - len([n for n in esp if n in rod]) / max(len(esp), 1)
    cl = {'falta': falta}
    if falta > FALTA_MAX or 'G_P_s+1' not in rod:
        cl['GLOBAL'] = 'INSUFICIENTE'
        return cl
    g = lambda n: rod.get(n)
    cl['ordem'] = {n: classe_ordem(g(n)) for n in esp}
    cl['chegada'] = {n: classe_chegada(g(n)) for n in esp}
    cl['disparo'] = {n: classe_disparo(g(n)) for n in esp}
    cl['frente'] = {n: classe_frente(g(n)) for n in esp}
    cl['ola'] = {n: classe_ola(g(n)) for n in esp}
    vales = [n for n in esp if n.startswith(('G_V', 'M_V'))]
    cl['atraso'] = {n: classe_atraso(g(n)) for n in vales}
    cl['atraso']['G_P_s-1'] = classe_atraso(g('G_P_s-1'))
    cl['dose'] = classe_dose(g('G_V1a6_s+1'), g('G_V1a12_s+1'), g('G_V1a18_s+1'))
    cl['lente'] = {n: classe_lente(g(n)) for n in esp if n.startswith('G_V2')}
    cl['quiral'] = {k: classe_quiral(med.get('quiral', {}).get(k)) for k in ('P', 'V1a12', 'V2n', 'V2o')}
    phis = [0.03, 0.05, 0.08]
    cl['relogio'] = classe_relogio(med.get('relogio', {}), phis)
    cl['vermelho'] = classe_vermelho(med.get('relogio', {}), phis)
    cid = med.get('cidade', {})
    cl['cidade'] = ('INSUFICIENTE' if len(cid) < 2 else
                    'CIDADE_LEVE_SO_SOMA' if all(abs(x) <= CIDADE_DT for x in cid.values())
                    and all(cl['chegada'].get(f'G_V3s{k}_s+1') == 'MESMA_SEQUENCIA' for k in cid) else 'CIDADE_MUDA')
    mal = med.get('malha')
    cl['malha'] = ('INSUFICIENTE' if mal is None else
                   'MALHA_CONSISTENTE' if abs(mal['razao_atraso'] - 1) <= MALHA_TOL
                   and cl['chegada'].get('M_V1a18_s+1') == cl['chegada'].get('G_V1a18_s+1')
                   and cl['chegada'].get('M_P_s+1') == cl['chegada'].get('G_P_s+1') else 'MALHA_INCONSISTENTE')
    redes = [o['rede_sobre_limiar'] for n, o in rod.items() if n.startswith('G_')]   # bloco T: só descrição
    cl['rede'] = 'REDE_NAO_DISPARA' if all(x < REDE_MAX for x in redes) else 'REDE_DISPARA'
    # globais
    gt = [n for n in esp if n.startswith(('G_', 'T_'))]
    ch = [cl['chegada'][n] for n in gt]
    if any(x == 'INSUFICIENTE' for x in ch):
        cl['CHEGADA'] = 'INSUFICIENTE'
    elif all(x == 'MESMA_SEQUENCIA' for x in ch):
        cl['CHEGADA'] = 'MESMA_SEQUENCIA_EM_TODAS'
    elif all(cl['chegada'][n] == 'MESMA_SEQUENCIA' for n in gt if n.startswith('G_')):
        cl['CHEGADA'] = 'MESMA_SEQUENCIA_SO_NA_GEOMETRIA'
    else:
        cl['CHEGADA'] = 'SEQUENCIA_QUEBRADA'
    dp = {n: cl['disparo'][n] for n in gt}
    if any(x == 'INSUFICIENTE' for x in dp.values()):
        cl['DISPARO'] = 'INSUFICIENTE'
    elif all(x == 'MESMA_SEQUENCIA' for x in dp.values()):
        cl['DISPARO'] = 'MESMA_SEQUENCIA_EM_TODAS'
    elif all(x == 'MESMA_SEQUENCIA' or (x == 'TROCA_NA_SOMBRA' and n.startswith('G_V2')) for n, x in dp.items()):
        cl['DISPARO'] = 'TROCA_SO_NA_SOMBRA'
    else:
        cl['DISPARO'] = 'SEQUENCIA_QUEBRADA'
    at = [cl['atraso'][n] for n in vales if n.startswith('G_')]
    if any(x == 'INSUFICIENTE' for x in at) or cl['dose'] == 'INSUFICIENTE':
        cl['GEOMETRIA'] = 'INSUFICIENTE'
    elif all(x == 'ATRASO_GEOMETRICO' for x in at) and cl['dose'] == 'DOSE_GEOMETRICA' \
            and cl['atraso']['G_P_s-1'] == 'SEM_ATRASO':
        cl['GEOMETRIA'] = 'ATRASO_DE_CAMINHO'
    else:
        cl['GEOMETRIA'] = 'ATRASO_NAO_EXPLICADO'
    if cl['CHEGADA'] == 'INSUFICIENTE' or cl['GEOMETRIA'] == 'INSUFICIENTE':
        cl['GLOBAL'] = 'INSUFICIENTE'
    elif cl['CHEGADA'] in ('MESMA_SEQUENCIA_EM_TODAS', 'MESMA_SEQUENCIA_SO_NA_GEOMETRIA') \
            and cl['GEOMETRIA'] == 'ATRASO_DE_CAMINHO' and cl['malha'] == 'MALHA_CONSISTENTE':
        cl['GLOBAL'] = 'VALE_ATRASA_SEM_TROCAR_A_ORDEM'
    elif cl['CHEGADA'] == 'SEQUENCIA_QUEBRADA':
        cl['GLOBAL'] = 'VALE_TROCA_A_ORDEM'
    else:
        cl['GLOBAL'] = 'PARCIAL'
    return cl


PREVISTO = {
    'GLOBAL': 'VALE_ATRASA_SEM_TROCAR_A_ORDEM', 'CHEGADA': 'MESMA_SEQUENCIA_EM_TODAS', 'DISPARO': 'TROCA_SO_NA_SOMBRA',
    'GEOMETRIA': 'ATRASO_DE_CAMINHO', 'dose': 'DOSE_GEOMETRICA', 'malha': 'MALHA_CONSISTENTE',
    'relogio': 'RELOGIO_ACELERA_A_ONDA', 'vermelho': 'DESVIO_PARA_O_VERMELHO', 'cidade': 'CIDADE_LEVE_SO_SOMA',
    'rede': 'REDE_NAO_DISPARA',
    'quiral': {'P': 'AQUIRAL', 'V1a12': 'AQUIRAL', 'V2n': 'QUIRAL_ESPELHO', 'V2o': 'QUIRAL_ESPELHO'},
    'lente': {'G_V2n_s+1': 'LENTE', 'G_V2n_s-1': 'LENTE', 'G_V2o_s+1': 'LENTE', 'G_V2o_s-1': 'LENTE'},
}
_V2 = ('G_V2n_s+1', 'G_V2n_s-1', 'G_V2o_s+1', 'G_V2o_s-1')
_TODAS = ['G_P_s+1', 'G_P_s-1', 'G_V1a6_s+1', 'G_V1a12_s+1', 'G_V1a12_s-1', 'G_V1a18_s+1', *_V2, 'G_V3s44_s+1',
          'G_V3s45_s+1', 'T_T1f03_s+1', 'T_T1Rf03_s+1', 'T_T1f05_s+1', 'T_T1Rf05_s+1', 'T_T1f08_s+1', 'T_T1Rf08_s+1',
          'M_P_s+1', 'M_V1a18_s+1']
PREVISTO['frente'] = {n: ('FRENTE_INCOMPLETA' if n in _V2 else 'FRENTE_COMPLETA') for n in _TODAS}
PREVISTO['ola'] = {n: ('OLA_PARCIAL' if n in _V2 else 'OLA_LIMPA_POR_FAIXAS') for n in _TODAS}


def main():
    pasta = sys.argv[1]
    med = medir(pasta)
    cl = classificar(med)
    for n in list(med.get('rodadas', {})):
        for k in [k for k in med['rodadas'][n] if k.startswith('_')]:
            med['rodadas'][n].pop(k)
    json.dump({'medidas': med, 'classes': cl, 'previsto': PREVISTO}, open(os.path.join(pasta, 'avaliacao_B39V.json'), 'w'),
              indent=1, default=float)
    print('falta', round(cl.get('falta', 1), 3))
    for k, v in PREVISTO.items():
        if isinstance(v, dict):
            for kk, vv in v.items():
                ob = cl.get(k, {}).get(kk, '—') if isinstance(cl.get(k), dict) else '—'
                print(f'{k}.{kk}: previsto {vv} · obtido {ob} · {"CONFERE" if ob == vv else "DIFERE"}')
        else:
            ob = cl.get(k, '—')
            print(f'{k}: previsto {v} · obtido {ob} · {"CONFERE" if ob == v else "DIFERE"}')
    for k in ('chegada', 'disparo', 'frente', 'ola', 'atraso', 'lente'):
        print(k, cl.get(k))


if __name__ == '__main__':
    main()
