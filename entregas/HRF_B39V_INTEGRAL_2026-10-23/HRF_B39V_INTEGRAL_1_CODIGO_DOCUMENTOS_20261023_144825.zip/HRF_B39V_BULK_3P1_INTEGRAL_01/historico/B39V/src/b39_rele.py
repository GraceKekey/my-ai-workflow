"""B39 — receptor, relé e lâmpada (comuns à base livre L e à linha C).

Receptor da casa k: oscilador sintonizado em Ω_k, ligado à base pela fiação da casa, com amortecimento próprio
(a bobina do relé). Ele sente a rede (portadora Ω_r, sempre ligada) e a mensagem.
Leitura do relé: o relé lê a BANDA da casa — demodula o receptor na própria frequência e alisa com a inércia T_R:
    z = √(Ω/2) x + i p/√(2Ω),   w = z e^{iΩt},   w̄(t_i) = a w̄(t_{i−1}) + (1 − a) w(t_i),  a = e^{−Δ/T_R},
    R(t) = |w̄(t)|².
A rede está ligada desde sempre: w̄(0) é o valor estacionário exato do filtro sob a portadora (sem transiente).
Relé que TRAVA: fecha na primeira vez em que R ≥ θ e não abre mais.
Relé que SOLTA: fecha quando R ≥ θ e abre quando R < HIST·θ (histerese de relé real).
Lâmpada: ligada à rede pelo relé; a luz vem da rede. Brilho normalizado b = |a|², ȧ = (γ_L/2)(r − a): b = 1 é o
brilho pleno que a rede dá a qualquer casa (rede ideal: a tensão não cai com a carga).
Margem (sem limiar escolhido): para cada casa h, com janela própria,
    pre_h  = máx R_h antes do início da janela,   pico_h = máx R_h até o fim da janela,
    pos_h  = máx R_h depois do prazo de soltura;
    margem_trava = mín_h pico_h / máx_h pre_h,   margem_solta = mín_h pico_h / máx(máx_h pre_h, máx_h pos_h / HIST).
margem > 1 ⇔ existe um limiar comum (relés idênticos) que faz a onda perfeita."""
import numpy as np

T_R = 20.0
HIST = 0.5
GAM_LAMP = 0.2


def leitura(ts, X, P, Om, Xr=None, A=0.0, Om_r=1.0, F_rel=1.0):
    """R (nt × H). X, P: parte da mensagem; Xr: amplitude complexa da rede em cada receptor (por unidade de A)."""
    Om = np.asarray(Om, dtype=float)
    x = F_rel * X; p = F_rel * P
    dlt = ts[1] - ts[0]; a = np.exp(-dlt / T_R)
    w0 = np.zeros(len(Om), dtype=complex)
    if Xr is not None and A != 0.0:
        e = np.exp(1j * Om_r * ts[:, None])
        x = x + A * np.real(Xr[None, :] * e)
        p = p + A * np.real(1j * Om_r * Xr[None, :] * e)
        cm = A * Xr * (Om - Om_r) / (2 * np.sqrt(2 * Om))           # termo e^{i(Ω+Ω_r)t}
        cn = A * np.conj(Xr) * (Om + Om_r) / (2 * np.sqrt(2 * Om))  # termo e^{i(Ω−Ω_r)t}
        for c, nu in ((cm, Om + Om_r), (cn, Om - Om_r)):
            w0 = w0 + c * (1 - a) / (1 - a * np.exp(-1j * nu * dlt))
    z = np.sqrt(Om / 2) * x + 1j * p / np.sqrt(2 * Om)
    w = z * np.exp(1j * Om[None, :] * ts[:, None])
    wb = np.empty_like(w); wb[0] = w0
    for i in range(1, len(ts)):
        wb[i] = a * wb[i - 1] + (1 - a) * w[i]
    return np.abs(wb) ** 2


def margens(ts, R, ini, fim, pos, casas):
    """ini, fim, pos: dicionários por casa (início da janela, fim da janela, prazo de soltura); casas: as que contam."""
    pre = np.array([R[ts < ini[h], h].max() if np.any(ts < ini[h]) else R[0, h] for h in casas])
    pk = np.array([R[ts <= fim[h], h].max() for h in casas])
    po = np.array([R[ts >= pos[h], h].max() if np.any(ts >= pos[h]) else 0.0 for h in casas])
    den_t = max(pre.max(), 1e-300); den_s = max(pre.max(), po.max() / HIST, 1e-300)
    return {'margem_trava': float(pk.min() / den_t), 'margem_solta': float(pk.min() / den_s),
            'theta_trava': float(np.sqrt(pk.min() * den_t)), 'theta_solta': float(np.sqrt(pk.min() * den_s)),
            'pre': pre.tolist(), 'pico': pk.tolist(), 'pos': po.tolist()}


def rele(ts, R, theta, modo):
    """estado r (nt × H) do relé, 0/1."""
    r = np.zeros_like(R)
    for h in range(R.shape[1]):
        if modo == 'trava':
            i = np.argmax(R[:, h] >= theta)
            if R[i, h] >= theta:
                r[i:, h] = 1.0
        else:
            on = False
            for i in range(len(ts)):
                if not on and R[i, h] >= theta:
                    on = True
                elif on and R[i, h] < HIST * theta:
                    on = False
                r[i, h] = 1.0 if on else 0.0
    return r


def lampada(ts, r):
    """brilho normalizado b (nt × H)."""
    a = np.exp(-0.5 * GAM_LAMP * (ts[1] - ts[0]))
    amp = np.zeros_like(r)
    for i in range(1, len(ts)):
        amp[i] = a * amp[i - 1] + (1 - a) * r[i]
    return amp ** 2


def disparos(ts, r):
    """instante de fechamento (primeiro) e intervalos ligados de cada casa."""
    out = []
    for h in range(r.shape[1]):
        d = np.diff(np.concatenate([[0.0], r[:, h], [0.0]]))
        liga = np.nonzero(d > 0)[0]; desl = np.nonzero(d < 0)[0]
        out.append([(float(ts[a]), float(ts[min(b, len(ts) - 1)])) for a, b in zip(liga, desl)])
    return out


def medidas(ts, R, ordem, ini, fim, pos, tau_ref):
    """margens + onda no limiar do meio da janela (descritivo): acertos, intervalo, lâmpadas simultâneas.
    ordem: casas na ordem em que são chamadas (só as que contam)."""
    m = margens(ts, R, ini, fim, pos, ordem)
    out = dict(m)
    for modo in ('trava', 'solta'):
        th = m['theta_' + modo]
        r = rele(ts, R, th, modo)
        iv = disparos(ts, r)
        ok = []
        for h in ordem:
            if not iv[h]:
                ok.append(False); continue
            if modo == 'trava':
                ok.append(ini[h] <= iv[h][0][0] <= fim[h])
            else:                                   # todos os trechos ligados dentro de [início, prazo de soltura]
                ok.append(ini[h] <= iv[h][0][0] <= fim[h] and all(ini[h] <= a and b <= pos[h] for a, b in iv[h]))
        out['acerto_' + modo] = float(np.mean(ok))
        out['intervalos_' + modo] = iv
        if modo == 'solta':
            out['cintilacao'] = int(sum(max(len(iv[h]) - 1, 0) for h in ordem))
        b = lampada(ts, r)
        out['luz_' + modo] = (b.sum(0) * (ts[1] - ts[0])).tolist()
        if modo == 'trava':
            tf = [iv[h][0][0] if iv[h] else None for h in ordem]
            if all(t is not None for t in tf):
                out['intervalo_rel'] = float(np.median(np.diff(tf)) / tau_ref)
            out['t_fecha'] = [iv[h][0][0] if iv[h] else None for h in range(R.shape[1])]
        else:
            jan = (ts >= ini[ordem[0]]) & (ts <= fim[ordem[-1]])
            out['simultaneas'] = float(np.mean((b[jan] > 0.5).sum(1)))
    return out
