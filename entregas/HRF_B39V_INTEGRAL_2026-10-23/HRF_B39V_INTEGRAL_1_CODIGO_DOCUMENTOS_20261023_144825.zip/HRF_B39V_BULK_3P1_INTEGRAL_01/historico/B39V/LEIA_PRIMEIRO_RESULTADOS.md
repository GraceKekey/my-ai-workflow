# B39V — Resultados completos

Relatório: HRF_B39V_RELATORIO_2026-10-22_200841.md

{
  "GLOBAL": "VALE_ATRASA_SEM_TROCAR_A_ORDEM",
  "CHEGADA": "MESMA_SEQUENCIA_EM_TODAS",
  "DISPARO": "TROCA_SO_NA_SOMBRA",
  "GEOMETRIA": "ATRASO_DE_CAMINHO",
  "dose": "DOSE_GEOMETRICA",
  "malha": "MALHA_CONSISTENTE",
  "relogio": "RELOGIO_ACELERA_A_ONDA",
  "vermelho": "DESVIO_PARA_O_VERMELHO",
  "cidade": "CIDADE_LEVE_SO_SOMA",
  "rede": "REDE_NAO_DISPARA",
  "previsoes_conferem": 58,
  "previsoes_total": 58
}

Resultados desta rodada: resultados/. Fumaça e entrada original são antecedentes.
