# HRF B39V — O vale 2,5D: a ola que sai do GMFt mais antigo num lençol de borracha
## Geometria (bloco G) e relógio lento (bloco T); relés iguais; chegada, disparo, atraso, lente, quiralidade e desvio para o vermelho — protocolo pré-registrado

**Data:** 22 de outubro de 2026 (America/Sao_Paulo) — Claude (`-clau`) · variante da B39 (os ímpares ≥ 43 estão com os
outros chats)
**Autoria:** Mario José do Canto Filho, MD · desenho, código e fumaça: Claude
**Decisões de Mario que fixam esta bancada (22/10):**
- 17h32 — o pedido: "vamos fazer um teste paralelo, imaginando um campo 2,5D, onde os GMFs mais antigos seriam mais
  pesados e afundariam a rede, né, fazendo um vale, e daí seria deles que partiria o sinal e se iria indo em direção
  distal a ele, para a gente ver se todos disparariam na mesma sequência e como ficaria a ola."
- Depois da exploração (nota v0.1, 18h23), quatro escolhas:
  - como o vale age: **os dois, em blocos** — só geometria (o lençol de borracha) e também relógio lento;
  - de onde parte o sinal: **só do GMFt mais antigo**;
  - as casas (GMFt mais novos) também pesam: **sim, leves, como bloco**;
  - a diluição em 2D: **relés iguais, com a ola medida por faixas de distância**.

**Nada roda sem "pode rodar".**
**Vertente:** HRF-OLA. Antecedentes: B39 (pré-registro 21/10, 20h40; relatório 22/10, 12h10); nota da exploração do
vale v0.2 (22/10).

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 0. Arquitetura usada [D, 22/10]

| Termo | Nesta bancada |
|---|---|
| **base** | Membrana 2D sempre ligada, **com espaço** (vizinhos): um disco triangulado de raio R. É um teste paralelo da fase geométrica; não substitui a base onipresente da decisão (2) de 21/10. |
| **lençol** | A altura h(x, y) da membrana sob o peso dos GMFt: T Δh = ρ, h = 0 na borda (o lençol de borracha). Peso = idade. |
| **onda na base** | Klein–Gordon na superfície curva: lacuna W0 = 1,6 e portadora Ω = 1,85, as mesmas da linha C da B39. |
| **GMFt mais antigo** | O mais pesado, no fundo do vale (centro). É a **fonte**: um dipolo girante (saca-rolha, sentido s = ±1). |
| **casas** | GMFt mais novos: receptores sintonizados em Ω, numa grade de passo 10, com o relé da B39 (`b39_rele.py`, sem mudança). No bloco G as casas não pesam, exceto na cidade com idades (V3), em que pesam pouco. |
| **rede** | Portadora Ω_r = 1,0 uniforme por área, abaixo da lacuna, ligada desde sempre (estado estacionário exato). A força da rede é 500 vezes a da mensagem, a mesma razão da B39. |
| **relógio lento (bloco T)** | Lapso N(x) = 1 + φ h(x)/\|h_mín\|: o tempo próprio anda mais devagar no poço. A onda obedece a ü = N ∇·(N ∇u) − N² W0² u. |
| **relógios próprios (T1R)** | A fonte e cada casa ficam sintonizadas na sua frequência própria N(x)·Ω. O sinal sai do fundo mais grave: é o **desvio para o vermelho**. Em T1, todos ficam sintonizados em Ω (tempo de coordenada), e só a velocidade muda. |
| **chegada** | Instante em que a leitura de cada casa (só a mensagem) atinge metade do seu próprio máximo. |
| **disparo** | Instante em que o relé que trava fecha, com o **mesmo limiar para todas as casas** (relés iguais). |
| **frente / ola** | Relé que trava / relé que solta (B39). |
| **margem** | > 1 ⇔ existe um limiar comum que faz a onda perfeita (B39). Medida no conjunto das casas e em três faixas de distância. |
| **atraso** | Chegada no vale − chegada no plano, casa a casa. |
| **caminho extra** | Distância ao longo da superfície no vale − distância no plano, casa a casa (método do calor). |

## 1. Objetivo

Com o sinal partindo do GMFt mais antigo, no fundo do vale, medir:
- **Q1, a sequência:** a ola **chega** às casas na ordem da distância? Os relés iguais **disparam** nessa ordem?
- **Q2, o atraso:** o vale atrasa a ola? O atraso de cada casa é o caminho mais longo ao longo do lençol (o análogo do
  atraso de Shapiro)?
- **Q3, a dose:** o atraso cresce com o peso do GMFt antigo como prevê a geometria?
- **Q4, a lente:** um segundo GMFt antigo concentra o sinal atrás dele e faz sombra dos lados?
- **Q5, o saca-rolha:** o sentido de giro importa? Com dois vales, os dois sentidos são imagens no espelho?
- **Q6, a cidade com idades:** quando todas as casas pesam um pouco, a sequência e o atraso mudam?
- **Q7, o relógio lento:** se o poço também atrasa o relógio, a ola chega mais cedo ou mais tarde que no vale só
  geométrico?
- **Q8, o desvio para o vermelho:** com relógios próprios, a ola chega mais tarde, e as casas mais altas ouvem pior?
- **Q9, a ola:** com relés iguais, a frente e a ola são limpas em cada faixa de distância?
- **Controles:** malha mais fina; os dois sentidos do saca-rolha; a rede sozinha.

## 2. Modelo [M]

- **Malha:** rede triangular regular no disco de raio R, espaçamento projetado a. A malha é simétrica nos espelhos
  x → −x e y → −y.
- **Lençol:** ρ = Σ_j 2π α_j N(x − x_j; σ_j) (gaussiana normalizada); T Δh = ρ com T = 1 e h = 0 na borda. Longe de
  cada GMFt, h ≈ α_j ln r. Resolvido pelos cotangentes na malha plana.
- **Superfície:** z = h(x, y). Laplace–Beltrami pelos cotangentes em 3D (L), massa concentrada (área de vértice A).
- **Base:** (A/N) ü = −L_N u − N W0² A u − (A/N) D u̇ − G S q + F(t).
  - L_N: cotangentes com o lapso médio de cada aresta; no bloco G, N ≡ 1.
  - D: borda absorvente, D = 0,5 ((r − R_abs)/(R − R_abs))² para r > R_abs.
- **Casas:** q̈_k = −Ω_k² q_k − γ_R q̇_k − G u_{v_k}, com γ_R = 0,1 e G = 0,05. Cada casa fica no vértice mais
  próximo do seu ponto da grade; empates são desfeitos de modo simétrico nos espelhos.
- **Rede:** força Re[ρ_r A e^{iΩ_r t}], com Ω_r = 1,0 e ρ_r tal que |força da rede| = 500 |força da mensagem|.
  Estado estacionário exato por solução esparsa (base + casas).
- **Mensagem:** F = F0 sin²(π t/60) [P1 cos Ω_f t + s P2 sin Ω_f t] em [0, 60], com F0 = 0,02, P1 = A ∂_x g e
  P2 = A ∂_y g (g gaussiana de largura 1,5 no centro). Ω_f = Ω, exceto em T1R (Ω_f = N(0)·Ω).
- **Integração:** RK4 com dt = 0,1; casas amostradas a cada 0,5.
- **Leitura e relé:** os da B39 (demodulação na frequência da casa, inércia T_R = 20, histerese ½). A leitura do relé
  inclui a rede. A chegada usa a leitura só da mensagem.
- **Distância ao longo da superfície:** método do calor (Crane et al. 2013), a partir do vértice da fonte.

## 3. Hipóteses (pré-registradas) e o que já se sabe

### 3.1 O que a exploração mostrou (nota v0.2; §9)

A exploração usou a mesma física com outra grade de casas (assimétrica) e sem o desempate simétrico.
- **Configurações já vistas:** plano; um vale (α = 12); dois vales com o segundo GMFt em (50, 0); cidade com idades
  (semente 43); relógio lento com φ = 0,05 (T1 e T1R).
- **As configurações desta rodada que repetem essas:** plano, V1 α = 12 e T com φ = 0,05. Elas servem de referência;
  o resultado delas já é praticamente conhecido.
- **As decisivas são novas:**
  - doses α = 6 e 18;
  - segundo GMFt em (0, 55) (V2n) e em (−45, 0) (V2o);
  - cidade com idades nas sementes 44 e 45;
  - relógio lento com φ = 0,03 e 0,08;
  - malha fina no vale α = 18.

Números da exploração (malha 0,75, disco corrigido):

| | plano | um vale | dois vales (s = +1 / −1) | cidade | T1 | T1R |
|---|---|---|---|---|---|---|
| Inversões de chegada (Δd > 10) | 0 | 0 | 0 / 0 | 0 | 0 | 0 |
| Kendall chegada × distância na superfície | 0,997 | 0,994 | 0,992 / 0,992 | 0,994 | 0,993 | 0,993 |
| Inversões de disparo (relés iguais) | 0 | 0 | 0 / 4 (todas com uma casa na sombra) | 0 | 0 | 0 |
| Casas que não dispararam | 0 | 0 | 2 / 2 (na sombra) | 0 | 0 | 0 |
| Atraso × caminho extra/v: inclinação; correlação | — | 1,08; 0,987 | 1,11; 0,982 | 1,08; 0,989 | — | — |
| Atraso em r ≈ 100 (previsto) | 0 | 12,8 (11,4) | 16,1 (13,9) | 13,6 (12,1) | 7,8 | 18,2 |
| Frente: margem global | 3,5 | 3,5 | 0,90 / 0,70 | 3,6 | 2,6 | 2,9 |
| Ola: margem por faixa (12–45, 45–85, 85–123) | 8,0; 6,2; 3,5 | 8,0; 6,4; 3,5 | 7,6; 3,0; 0,9 / 7,7; 2,6; 0,7 | 8,1; 6,4; 3,6 | 6,3; 4,5; 2,6 | 5,2; 5,4; 4,6 |
| Lente (foco; sombra) | — | — | 2,5; 0,33 | — | — | — |
| s = +1 ÷ s = −1 na mesma casa | 0,993–1,008 | — | 0,62–1,62 | — | — | — |
| Leitura da rede ÷ limiar | 0,05 | 0,05 | 0,06 | 0,05 | 0,08 | 0,16 |

Relógio: T1 − V1 em r ≈ 100 = −5,0; T1R − T1 = +10,3; Spearman (sinal T1R/T1 × altura da casa) = −0,999.

Malha 0,6 (P e V1, α = 12): atraso de V1 em r ≈ 100 = 12,2 (contra 12,8 na malha 0,75); inclinação 1,02 e correlação
0,992 (contra 1,08 e 0,987). Parte do excesso sobre a previsão geométrica é numérica e cai com o refinamento.

### 3.2 Previsões

| Item | Previsto | Por quê |
|---|---|---|
| CHEGADA (global) | MESMA_SEQUENCIA_EM_TODAS | a frente de onda segue a distância ao longo do lençol; nenhuma inversão na exploração |
| DISPARO (global) | TROCA_SO_NA_SOMBRA | relés iguais: casas na sombra da lente disparam tarde ou não disparam (V2, s = −1) |
| GEOMETRIA | ATRASO_DE_CAMINHO | inclinação 1,08–1,11 e correlação ≥ 0,98 na exploração |
| dose | DOSE_GEOMETRICA | α = 6, 12, 18: atraso previsto em r ≈ 100 ≈ 4, 12, 26 |
| lente (V2n, V2o, s = ±1) | LENTE | foco 2,5 e sombra 0,33 na exploração |
| quiral P, V1a12 | AQUIRAL | fonte e paisagem simétricas por rotação |
| quiral V2n, V2o | QUIRAL_ESPELHO | a lente quebra a simetria; o espelho a devolve |
| cidade | CIDADE_LEVE_SO_SOMA | +0,5 de atraso na exploração |
| relógio | RELOGIO_ACELERA_A_ONDA | perto da lacuna, o poço baixa a lacuna local e a onda acelera (−5,0 em φ = 0,05) |
| vermelho | DESVIO_PARA_O_VERMELHO | a voz grave anda mais devagar e as casas altas ficam desafinadas |
| malha | MALHA_CONSISTENTE | atraso de V1 (α = 12) em r ≈ 100: 12,8 na malha 0,75 e 12,2 na 0,6 (−5%) |
| rede | REDE_NAO_DISPARA | ≤ 0,064 do limiar no bloco G |
| frente | COMPLETA em todas, exceto V2n e V2o (INCOMPLETA) | a sombra da lente derruba a margem global (0,70–0,90) |
| ola | LIMPA_POR_FAIXAS em todas, exceto V2n e V2o (PARCIAL) | a faixa distante fica na sombra |
| GLOBAL | VALE_ATRASA_SEM_TROCAR_A_ORDEM | — |

**Itens no limite (risco declarado):**
- **DISPARO:** na exploração, só uma das duas rodadas de dois vales teve troca (4 pares, todos com a mesma casa na
  sombra). Se nenhuma das quatro rodadas novas tiver troca, o resultado será MESMA_SEQUENCIA_EM_TODAS.
- **Lente em V2o** (segundo GMFt a 45 do centro, mais pesado): a sombra pode ficar mais fraca que 0,67 se o foco cair
  fora da cidade.
- **Dose α = 18:** a inclinação máxima é 1,18; a malha 0,75 resolve pior a encosta. A razão atraso/previsto pode
  passar de 1,4. A malha fina é o controle.
- **Frente e ola em V2:** dependem de onde cai a sombra; a classe pode ser COMPLETA/LIMPA se a sombra cair entre as
  casas.

## 4. Parâmetros (rodada `completo`)

| Grupo | Valores |
|---|---|
| Disco | R = 155, borda absorvente de 135 a 155, malha a = 0,75 (≈ 155 mil vértices); malha fina 0,6 (≈ 242 mil) |
| Casas | grade simétrica de passo 10, 12 ≤ r ≤ 122 (468 casas) |
| GMFt antigo | (0, 0), σ = 8; α = 12 (referência); dose α = 6, 12, 18 |
| Segundo GMFt antigo | V2n: (0, 55), α = 6, σ = 5 · V2o: (−45, 0), α = 8, σ = 6 |
| Cidade com idades | V1 (α = 12) + cada casa com α = 0,025 × idade, σ = 2,5; idades U(0, 1), sementes 44 e 45 |
| Relógio | φ = 0,03; 0,05; 0,08 em V1 (α = 12); T1 e T1R |
| Tempo | pulso de 60; rodada de 460; dt = 0,1; amostra 0,5 |
| Janelas | centro previsto t*_k = t_p0 + d_k/v_p (lei do pico ajustada no plano, distância ao longo da superfície); fechamento t* ± Δ/2; soltura até t* + Δ; Δ = 35/v_p |
| Faixas | 12–45, 45–85, 85–123 |
| Distância de referência | r = 100 ± 5 |

Rodadas (20): G_P (s = ±1), G_V1a12 (s = ±1), G_V1a6, G_V1a18, G_V2n (s = ±1), G_V2o (s = ±1), G_V3s44, G_V3s45,
T_T1f03/05/08, T_T1Rf03/05/08, M_P e M_V1a18 (malha 0,6). Sem sinal indicado, s = +1.

## 5. Protocolo

1. `python -I src/testar_avaliador_B39V.py fumaca` deve terminar com "TODOS OS 155 RAMOS CONFEREM".
2. `python -I src/conferir_pecas_B39V.py fumaca` deve terminar com "TODAS AS 14 PEÇAS CONFEREM".
3. `python -I src/rodar_B39V.py --modo completo --parte todas` grava em `resultados/`.
   - As partes G, T e M podem rodar em paralelo, e cada parte pode ser dividida em lotes (`--lote 1/2`, `--lote 2/2`).
   - Cada rodada gera um checkpoint `.npz` atômico e um `.json` curto; relançar retoma do ponto em que parou.
   - `config_B39V.json` registra os parâmetros e os SHA-256 dos módulos.
4. `python -I src/avaliar_B39V.py resultados` grava `resultados/avaliacao_B39V.json` e imprime previsto × obtido.
5. `python -I src/figura_B39V.py resultados resultados/figura_B39V.png`.
6. Nenhum parâmetro, limiar ou semente muda depois do "pode rodar". Leituras extras vão para uma seção pós-hoc.

## 6. Medidas

- **Calibração (na rodada G_P_s+1):** lei da chegada t50 = t0 + d/v e lei do pico t_pico = t_p0 + d/v_p, ajustadas
  por mínimos quadrados com a distância ao longo da superfície (no plano, a distância comum).
- **Por rodada:**
  - margens globais e por faixa (frente e ola), nas janelas da §4;
  - disparo de cada casa com o relé que trava no limiar do meio global, θ = √(mín pico × máx pré);
  - Kendall do disparo × distância na superfície e inversões (pares em que a casa mais distante por mais de 10 dispara
    antes);
  - Kendall da chegada × distância na superfície e inversões da chegada;
  - leitura máxima só da rede ÷ θ.
- **Atraso (rodadas com vale):**
  - Δt_k = t50_k − t50_k(plano, mesmo sentido; malha fina contra o plano da malha fina);
  - caminho extra Δd_k/v;
  - inclinação e correlação da reta Δt × Δd/v;
  - atraso e previsto na distância de referência (medianas).
- **Lente (V2n, V2o):** razão de sinal (só mensagem) V2 ÷ V1a12, no mesmo sentido, nas casas atrás do segundo GMFt
  (r > r_2 + 15 e direção a menos de 45° da dele).
  - foco = máximo; sombra = mínimo;
  - inversões de disparo e casas sem disparo **na sombra** (razão < 0,8).
- **Quiralidade:** máx \|sinal(s = +1)/sinal(s = −1) − 1\| na mesma casa.
  - Espelho: o mesmo com a casa espelhada, no espelho que contém a fonte e o segundo GMFt (y → −y em P, V1a12 e V2o;
    x → −x em V2n).
  - Só entram pares cujos vértices são espelhados exatamente.
- **Relógio:** em r ≈ 100, mediana de t50(T1) − t50(V1a12) e de t50(T1R) − t50(T1); Spearman entre a razão de sinal
  T1R/T1 e a altura da casa.
- **Cidade:** mediana de t50(V3) − t50(V1a12).
- **Malha:** atraso de referência de M_V1a18 ÷ o de G_V1a18.

## 7. Regras de decisão (congeladas; `src/avaliar_B39V.py`; testadas em 155 ramos)

**Gerais.** Se faltar mais de 1/3 das rodadas, ou faltar G_P_s+1, GLOBAL = INSUFICIENTE. Toda regra trata a falta de
dados como INSUFICIENTE.

| Regra | Classes |
|---|---|
| chegada (por rodada) | **MESMA_SEQUENCIA** inversões de chegada = 0 e Kendall ≥ 0,90 · **SEQUENCIA_ALTERADA** |
| disparo (por rodada) | **POUCAS_DISPARAM** < 90% das casas disparam · **MESMA_SEQUENCIA** inversões = 0 e Kendall ≥ 0,90 · **TROCA_NA_SOMBRA** todas as inversões têm a casa atrasada na sombra (só onde há lente) e Kendall ≥ 0,90 · **SEQUENCIA_ALTERADA** |
| CHEGADA (global, G e T) | **MESMA_SEQUENCIA_EM_TODAS** · **MESMA_SEQUENCIA_SO_NA_GEOMETRIA** (só o bloco T falha) · **SEQUENCIA_QUEBRADA** |
| DISPARO (global, G e T) | **MESMA_SEQUENCIA_EM_TODAS** · **TROCA_SO_NA_SOMBRA** (só V2 com TROCA_NA_SOMBRA) · **SEQUENCIA_QUEBRADA** |
| atraso (rodadas com vale) | **SEM_ATRASO** \|atraso de referência\| < 1 · **ATRASO_GEOMETRICO** inclinação em [0,8; 1,3] e correlação ≥ 0,9 · **ATRASO_NAO_GEOMETRICO** |
| dose | **DOSE_GEOMETRICA** atraso(6) < atraso(12) < atraso(18) e cada atraso/previsto em [0,8; 1,4] · **DOSE_MONOTONA_FORA_DA_GEOMETRIA** · **SEM_DOSE** |
| GEOMETRIA | **ATRASO_DE_CAMINHO** todas as rodadas G com vale ATRASO_GEOMETRICO, dose DOSE_GEOMETRICA e G_P_s-1 SEM_ATRASO · **ATRASO_NAO_EXPLICADO** |
| lente | **LENTE** foco ≥ 1,5 e sombra ≤ 0,67 · **SEM_LENTE** foco ≤ 1,25 e sombra ≥ 0,8 · **LENTE_PARCIAL** |
| quiral | **AQUIRAL** desvio na mesma casa ≤ 0,05 · **QUIRAL_ESPELHO** desvio ≥ 0,2 e erro do espelho ≤ 0,03 · **PARCIAL** |
| relógio | **RELOGIO_ACELERA_A_ONDA** T1 − V1 < 0 nas três φ e mais negativo com φ maior · **RELOGIO_ATRASA_A_ONDA** (o oposto) · **RELOGIO_MISTO** |
| vermelho | **DESVIO_PARA_O_VERMELHO** T1R − T1 > 0 nas três φ, crescente com φ, e Spearman ≤ −0,5 nas três · **VERMELHO_SO_NO_SINAL** só o Spearman · **SEM_DESVIO_CLARO** |
| cidade | **CIDADE_LEVE_SO_SOMA** \|t50(V3) − t50(V1)\| mediano ≤ 2 e chegada MESMA_SEQUENCIA nas duas sementes · **CIDADE_MUDA** |
| frente (por rodada) | **FRENTE_COMPLETA** margem global > 1 · **FRENTE_INCOMPLETA** |
| ola (por rodada) | **OLA_LIMPA_POR_FAIXAS** margem da ola > 1 nas três faixas · **OLA_PARCIAL** em uma ou duas · **SEM_OLA** |
| malha | **MALHA_CONSISTENTE** \|razão dos atrasos − 1\| ≤ 0,15 e mesma classe de chegada em M_P × G_P e M_V1a18 × G_V1a18 · **MALHA_INCONSISTENTE** |
| rede | **REDE_NAO_DISPARA** leitura da rede < 0,1 θ em todas as rodadas G (bloco T só descrito) · **REDE_DISPARA** |
| **GLOBAL** | **VALE_ATRASA_SEM_TROCAR_A_ORDEM:** CHEGADA mesma (em todas ou só na geometria), GEOMETRIA ATRASO_DE_CAMINHO e malha consistente · **VALE_TROCA_A_ORDEM:** CHEGADA SEQUENCIA_QUEBRADA · **PARCIAL** |

## 8. Controles, conferências e tempo

- **Conferência das peças** (`src/conferir_pecas_B39V.py`, 14 itens):
  - relé idêntico ao da B39 (SHA-256);
  - área do disco (erro 1,8% numa malha pequena de raio 40);
  - L simétrica com linhas somando zero;
  - malha simétrica nos dois espelhos, e casas fora do eixo caindo no vértice espelhado;
  - altura do lençol × solução analítica de uma carga gaussiana (erro 0,55% da profundidade);
  - distância ao longo da superfície: no plano, erro relativo médio de 0,7%; no vale, caminho extra × integral radial
    com erro médio de 0,03;
  - energia conservada sem perdas, por RK4 (7,9 × 10⁻⁵ em 30 unidades de tempo);
  - rede estacionária × RK4 (10⁻⁵);
  - dipolo girante: P1 ⟂ P2, P1 par e P2 ímpar no espelho (exatos);
  - lapso constante dá L_N = N·L;
  - v_g contínuo de 0,502 no plano e maior no poço;
  - margem > 1 ⇔ acerto = 1 em 40/40 rodadas da fumaça.
- **Controles dentro da rodada:**
  - o plano (calibração e referência do atraso);
  - os dois sentidos do saca-rolha (P, V1a12, V2n, V2o);
  - a leitura só da rede;
  - a leitura só da mensagem (chegada) e com a rede (disparo);
  - a malha fina (P e V1a18);
  - três doses e três φ.
- **Custos** (1 núcleo por processo, medidos nesta máquina):
  - malha 0,75 (155 mil vértices): ≈ 70–100 s por rodada;
  - malha 0,6 (242 mil vértices): ≈ 120 s por rodada, com pico de memória de 1,3 GB;
  - as 20 rodadas em sequência: ≈ 30 min. Com as partes G, T e M em paralelo (3 núcleos, ≥ 4 GB): ≈ 15 min;
  - fumaça: 252 s de CPU somados (6–30 s por rodada).

## 9. O que foi tentado e mudado antes de congelar

1. **Exploração v0.1 com disco cortado (defeito meu).** A malha cobria só |y| ≤ 136, dentro da borda absorvente.
   - Nas direções ±y, a onda batia nessa borda e voltava: um segundo pico de até 65% nas casas distantes.
   - Corrigida a malha, as rodadas foram refeitas (v0.2).
   - A conclusão da v0.1 de que "a ola não sai limpa em 2D" vinha desse eco e de janelas curtas; foi retirada.
2. **Cidade com idades pesada (descartada).** Com cada casa pesando até α = 1,5, as casas juntas afundaram a cidade
   num prato de profundidade 328, que a malha não resolve. As casas ficaram 60 vezes mais leves (decisão de Mario:
   "leves").
3. **Força da rede.** Com a base oscilando com amplitude ≈ 1 (ρ_r = 1,56), a rede cobria a mensagem nas casas
   distantes (a mensagem se dilui em 2D). Passou à razão da B39: força da rede = 500 × força da mensagem.
4. **Chegada pela mensagem.** A ondulação da rede desloca a meia subida das casas fracas em até 7 unidades. A chegada
   passou a usar a leitura só da mensagem, interpolada entre as amostras; o relé continua lendo com a rede.
5. **Janelas.**
   - Primeiro, centradas na meia subida prevista, com passo 25 (Δ ≈ 53). A ola falhava na faixa distante.
   - Perto da lacuna, o pulso alarga com a distância: a largura a meia altura da leitura vai de 36 (r = 20) a 48
     (r = 120).
   - Passaram a ser centradas no pico previsto (como a linha C da B39), com Δ = 35/v_p ≈ 77, maior que a largura da
     leitura a 1/4 do pico (55–67).
   - Escolha feita no plano da exploração corrigida (ola por faixa 8,0; 6,2; 3,5).
6. **Ordem: chegada e disparo separados.**
   - Com dois vales, a sombra da lente deixa casas fracas sem disparar e, em s = −1, uma casa na sombra disparou depois
     de quatro casas mais distantes.
   - A onda chegou na ordem; o disparo é que trocou. Por isso:
     - chegada e disparo viraram regras separadas;
     - a ordem do disparo é julgada entre as casas que disparam (≥ 90%);
     - a troca causada por casa na sombra tem classe própria.
7. **Atraso.** Primeiro, comparavam-se os resíduos da chegada com a distância vista de cima e ao longo da superfície.
   Trocou-se pela reta casa a casa, atraso × caminho extra/v (inclinação e correlação), que é mais direta.
8. **Grade de casas simétrica** (a da exploração ia de −122 a 118) e **desempate simétrico** do vértice mais próximo,
   para o teste do espelho por casa.
9. **Regra da rede só no bloco G.** Em T1R as casas altas ficam desafinadas, o limiar desce e a rede chega a 0,16 do
   limiar (0,42 na fumaça com φ = 0,08). A pergunta da regra é se a rede atrapalha o telecomando geométrico.
10. **Bloco T por sinais e ordem, não por valores.** A previsão por raios (WKB), em r ≈ 100, errou em magnitude:
    - T1: −8,2 previsto, −5,0 medido;
    - T1R: +26,6 sobre V1 previsto, +18,2 medido.
    A casa sintonizada ouve a parte do espectro do pulso perto da sua sintonia, que anda mais depressa que a portadora
    desviada.
11. **Kendall mínimo 0,90** (antes 0,95) depois da fumaça (FUMACA_B39V.md). Cidade e malha passaram a usar a classe
    da chegada.
12. **Diagnóstico da maior frequência.** O cálculo por autovalor (eigsh) levava minutos na malha grande e foi trocado
    por um limite de Gershgorin, instantâneo e conservador: ω_max·dt ≤ 0,43 (malha 0,75) e 0,52 (malha 0,6), contra
    2,8 de estabilidade do RK4. A fumaça foi refeita com o código final.
13. **Testes de tempo no modo `completo`.** Duas rodadas foram executadas só para medir tempo e memória: G_P_s+1 e
    M_V1a18_s+1. Os arquivos foram apagados sem análise; só o tempo, a memória e os metadados impressos (vértices,
    profundidade, ω_max) foram lidos.

Explorações (fora do pré-registro):
- v0.1 com o disco cortado (`v01_malha_cortada/`);
- v0.2 com o disco corrigido: P (s = ±1), V1 α = 12, V2 com o segundo GMFt em (50, 0) (s = ±1), V3 semente 43, T1 e
  T1R com φ = 0,05, e malha 0,6 em P e V1.
- Nenhuma delas usou as configurações decisivas desta rodada (doses 6 e 18, V2n, V2o, sementes 44 e 45, φ = 0,03 e
  0,08, V1a18 na malha fina).

## 10. Leitura prevista de cada resultado [H]

- **CHEGADA = MESMA_SEQUENCIA_EM_TODAS (previsto).** O peso dos GMFt antigos deforma o caminho, mas não a ordem.
  - A ola continua saindo do mais antigo para fora, e cada casa é alcançada na ordem da sua distância **ao longo do
    lençol**.
  - Para a Ola: a sequência de ativação é fixada pela geometria da base, isto é, pela distância relacional, não pela
    vista de cima.
- **GEOMETRIA = ATRASO_DE_CAMINHO e DOSE_GEOMETRICA (previsto).** O tempo que a ola leva é a distância medida no
  próprio lençol: a base curva funciona como uma régua de tempos, e um GMFt mais pesado afunda mais e atrasa mais. É o
  análogo do atraso de Shapiro no lençol de borracha.
- **LENTE e DISPARO = TROCA_SO_NA_SOMBRA (previsto).** Um segundo GMFt antigo concentra o sinal atrás dele e faz
  sombra dos lados. Com relés iguais, as casas na sombra disparam tarde ou não disparam.
  - Na geometria, essa é a única forma de trocar a sequência.
  - Analogia: um bloqueio parcial de condução. O impulso chega, mas a célula com o limiar mais difícil de atingir
    dispara tarde ou não dispara.
- **QUIRAL_ESPELHO com dois vales, AQUIRAL com um (previsto).** O sentido de giro importa quando a paisagem não tem
  simetria de rotação, e os dois sentidos são imagens no espelho.
- **RELOGIO_ACELERA_A_ONDA (previsto).** Com o relógio lento no poço, uma onda com massa (perto da lacuna) cai como
  uma pedra e anda mais rápido no fundo. A luz faria o contrário. O "tempo" do vale depende de que tipo de excitação o
  atravessa.
- **DESVIO_PARA_O_VERMELHO (previsto).** Com relógios próprios, o sinal do fundo sai mais grave, anda mais devagar e é
  ouvido pior pelas casas mais altas. A casa "ouve a profundidade" de onde o sinal veio.
- **Se a CHEGADA quebrar:** a geometria troca a ordem da ola, e a sequência deixa de ser uma propriedade da distância
  relacional.
- **Se a GEOMETRIA falhar:** o atraso tem outra origem (dispersão na encosta, reflexão parcial, malha), e a analogia do
  lençol não basta.

## 11. Limites

- **Toy model linear.** O relé (limiar) é a única não linearidade, posta à mão.
- **Com espaço.** A membrana tem vizinhos. É a fase geométrica, paralela à decisão (2); não substitui a base
  onipresente sem junções.
- **Lençol de borracha.** É uma curvatura por mergulho (z = h), estática; os GMFt não se movem e a onda não deforma o
  lençol.
  - Não é relatividade geral: lá a curvatura é intrínseca e inclui o tempo.
  - O bloco T acrescenta só um lapso simples, proporcional à profundidade.
- **Numérica.**
  - Malha P1 com dispersão numérica (inclinação 1,08–1,11 em vez de 1).
  - A distância ao longo da superfície vem do método do calor (erro ≈ 1%).
  - A borda absorve, mas não perfeitamente (≤ 7,6% de leitura tardia).
- **Uma fonte, um pulso, uma portadora.** Casas iguais, sem carga sobre a rede.

## 12. Arquivos do pré-registro

- `src/b39v_config.py` — parâmetros congelados e lista de rodadas.
- `src/b39v_membrana.py` — malha, lençol, cotangentes, distância ao longo da superfície, casas.
- `src/b39v_dinamica.py` — base com lapso, casas, rede, fonte, RK4.
- `src/b39_rele.py` — relé da B39, sem mudança.
- `src/rodar_B39V.py` — executor.
- `src/avaliar_B39V.py` — avaliador congelado (§7).
- `src/testar_avaliador_B39V.py` — teste sintético e de ponta a ponta (155 ramos).
- `src/conferir_pecas_B39V.py` — conferência das peças (14 itens).
- `src/figura_B39V.py` — figura.
- `fumaca/` — checkpoints, avaliação, figura, logs e saídas dos testes.
- `FUMACA_B39V.md`, `LEIAME_B39V.md` e o arquivo de hashes SHA-256.

## Referências

- I. I. Shapiro, Phys. Rev. Lett. 13, 789 (1964) (atraso de Shapiro; aqui só como análogo).
- U. Pinkall, K. Polthier, Exp. Math. 2, 15 (1993); M. Meyer et al., *Visualization and Mathematics III* (2003)
  (Laplace–Beltrami pelos cotangentes).
- K. Crane, C. Weischedel, M. Wardetzky, ACM Trans. Graph. 32, 152 (2013) (distância geodésica pelo calor).
- IEC 62054-11:2004 (telecomando por sinais sobrepostos à rede), como na B39.
