# LEIAME — B39V (pré-registro)

**Mario José do Canto Filho, MD · Claude (`-clau`) · 22/10/2026**

## O que é
Variante da B39 com a rede como um **lençol de borracha 2,5D**.
- O GMFt mais antigo (o mais pesado) afunda a rede e faz um vale. O sinal sai dele, em saca-rolha, e sobe para fora.
- As casas são GMFt mais novos, com o relé da B39 (`src/b39_rele.py`, idêntico ao da B39).

A bancada pergunta:
- se a ola **chega** e se os relés iguais **disparam** na ordem da distância;
- se o atraso do vale é o caminho mais longo ao longo do lençol, e se cresce com o peso;
- se um segundo GMFt antigo age como lente;
- se o sentido do saca-rolha importa;
- o que muda quando a cidade inteira pesa um pouco;
- o que acontece se o poço também atrasar o relógio (só a velocidade, ou com relógios próprios e desvio para o
  vermelho).

O protocolo está em `HRF_B39V_PROTOCOLO_2026-10-22_1944-clau.md` e a fumaça em `FUMACA_B39V.md`. **Rodar só depois do
"pode rodar".**

## Como rodar
Requer Python ≥ 3.9, NumPy, SciPy e Matplotlib (só para a figura).
```
python -I src/testar_avaliador_B39V.py fumaca           # deve terminar com "TODOS OS 155 RAMOS CONFEREM"
python -I src/conferir_pecas_B39V.py fumaca             # deve terminar com "TODAS AS 14 PEÇAS CONFEREM"
python -I src/rodar_B39V.py --modo completo --parte todas
python -I src/avaliar_B39V.py resultados                # grava resultados/avaliacao_B39V.json e imprime previsto × obtido
python -I src/figura_B39V.py resultados resultados/figura_B39V.png
```
- Para rodar em paralelo, use as partes `G`, `T` e `M` em processos separados. Também dá para dividir uma parte em
  lotes: `--parte G --lote 1/2` e `--parte G --lote 2/2`.
- Cada rodada grava um checkpoint `.npz` atômico. Se a execução cair, relançar retoma.
- **Não mudar** parâmetros, sementes nem limiares.

## Quanto custa
| Execução | Tempo | Memória |
|---|---|---|
| Em sequência (1 núcleo) | ≈ 30 min | ≤ 1,3 GB |
| Partes G, T e M em paralelo (3 núcleos) | ≈ 15 min | ≥ 4 GB no total |

Medido nesta máquina: ≈ 70–100 s por rodada na malha 0,75 e ≈ 120 s na malha 0,6 (pico de 1,3 GB).

## Arquivos
- `src/b39v_config.py` — parâmetros congelados e a lista das 20 rodadas (modos `completo` e `fumaca`).
- `src/b39v_membrana.py` — malha, lençol (Poisson), cotangentes, distância ao longo da superfície (calor), grade de
  casas.
- `src/b39v_dinamica.py` — Klein–Gordon na superfície com lapso, casas, rede estacionária, fonte em saca-rolha, RK4.
- `src/b39_rele.py` — leitura, relés e margens da B39 (sem mudança; SHA-256 igual ao do pré-registro da B39).
- `src/rodar_B39V.py` — executor.
- `src/avaliar_B39V.py` — avaliador congelado (protocolo §7).
- `src/testar_avaliador_B39V.py` — teste de todos os ramos e de ponta a ponta na fumaça.
- `src/conferir_pecas_B39V.py` — conferência das peças (14 itens).
- `src/figura_B39V.py` — figura.
- `fumaca/` — checkpoints, avaliação, figura, logs e saídas dos testes.
- `HRF_B39V_hashes_antes_da_execucao_2026-10-22_1944-clau.txt` — SHA-256 de tudo acima.
