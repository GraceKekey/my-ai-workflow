# FUMAÇA — B39V

**Mario José do Canto Filho, MD · Claude (`-clau`) · 22/10/2026**

## O que foi rodado
O modo `fumaca` usa a mesma física e o mesmo código da rodada `completo`, numa cidade menor:

| | fumaça | completo |
|---|---|---|
| Disco | R = 80, borda de 65 a 80 | R = 155, borda de 135 a 155 |
| Malha | a = 0,9 (28 663 vértices); fina 0,75 (41 287) | a = 0,75 (≈ 155 mil); fina 0,6 (≈ 242 mil) |
| Casas | passo 8, 10 ≤ r ≤ 56 (144) | passo 10, 12 ≤ r ≤ 122 (≈ 460) |
| GMFt antigo | σ = 4; doses α = 3, 6, 9 | σ = 8; doses α = 6, 12, 18 |
| Segundo GMFt | V2n (0, 27), α = 3, σ = 2,5 · V2o (−22, 0), α = 4, σ = 3 | V2n (0, 55), α = 6, σ = 5 · V2o (−45, 0), α = 8, σ = 6 |
| Cidade com idades | α_casa = 0,0125 × idade, σ = 1,5 | α_casa = 0,025 × idade, σ = 2,5 |
| Faixas; referência | 10–25, 25–40, 40–57; r = 45 | 12–45, 45–85, 85–123; r = 100 |
| Tempo | 250 | 460 |

As 20 rodadas da lista foram executadas (`fumaca/*.npz`) com o código final, em dois lotes paralelos: 252 s de CPU
somados (6–30 s cada).

## Testes
- `testar_avaliador_B39V.py fumaca`: **TODOS OS 155 RAMOS CONFEREM**, incluindo "avaliação gravada = refeita" na
  fumaça.
- `conferir_pecas_B39V.py fumaca`: **TODAS AS 14 PEÇAS CONFEREM**. Entre elas: margem > 1 ⇔ acerto = 1 em 40/40
  rodadas (trava e solta).

## Resultado da fumaça (sem valor de decisão)

| Rodada | chegada (inv; Kendall) | disparo (inv; Kendall) | frente | ola por faixa | inclinação; correlação | atraso/previsto em r ≈ 45 | rede/θ |
|---|---|---|---|---|---|---|---|
| G_P_s+1 | 0; 0,976 | 0; 0,946 | 9,4 | 8,6; 8,7; 7,0 | — | 0,0/0,0 | 0,11 |
| G_P_s-1 | 0; 0,976 | 0; 0,943 | 9,4 | 8,6; 8,7; 7,0 | — | 0,0/0,0 | 0,11 |
| G_V1a6_s+1 | 0; 0,977 | 0; 0,937 | 9,8 | 8,4; 8,6; 6,9 | 1,21; 0,981 | 1,8/1,5 | 0,11 |
| G_V1a12_s+1 | 0; 0,973 | 0; 0,943 | 9,6 | 8,4; 8,5; 6,4 | 1,21; 0,979 | 7,1/5,8 | 0,11 |
| G_V1a12_s-1 | 0; 0,974 | 0; 0,944 | 9,6 | 8,4; 8,5; 6,4 | 1,21; 0,979 | 7,1/5,8 | 0,11 |
| G_V1a18_s+1 | 0; 0,970 | 0; 0,942 | 10,1 | 6,9; 7,4; 5,7 | 1,21; 0,977 | 15,3/12,2 | 0,13 |
| G_V2n_s+1 | 0; 0,980 | 0; 0,951 | 6,2 | 8,2; 7,2; 4,5 | 1,18; 0,979 | 8,5/7,0 | 0,13 |
| G_V2n_s-1 | 0; 0,984 | 0; 0,949 | 6,4 | 7,9; 7,5; 3,8 | 1,18; 0,979 | 8,5/7,0 | 0,12 |
| G_V2o_s+1 | 0; 0,988 | 0; 0,955 | 4,5 | 7,6; 5,6; 3,1 | 1,17; 0,982 | 9,8/7,9 | 0,14 |
| G_V2o_s-1 | 0; 0,987 | 0; 0,954 | 4,5 | 7,6; 5,6; 3,1 | 1,17; 0,982 | 9,8/7,9 | 0,14 |
| G_V3s44_s+1 | 0; 0,989 | 0; 0,949 | 9,8 | 8,4; 8,5; 6,4 | 1,20; 0,980 | 7,2/5,9 | 0,12 |
| G_V3s45_s+1 | 0; 0,990 | 0; 0,943 | 9,9 | 8,4; 8,5; 6,4 | 1,20; 0,980 | 7,2/5,9 | 0,12 |
| T_T1f03_s+1 | 0; 0,973 | 0; 0,950 | 8,0 | 7,1; 7,3; 5,7 | — | — | 0,14 |
| T_T1Rf03_s+1 | 0; 0,973 | 0; 0,944 | 8,4 | 6,5; 7,5; 5,5 | — | — | 0,17 |
| T_T1f05_s+1 | 0; 0,973 | 0; 0,942 | 7,0 | 5,9; 6,3; 5,0 | — | — | 0,17 |
| T_T1Rf05_s+1 | 0; 0,974 | 0; 0,944 | 5,5 | 5,1; 6,3; 4,4 | — | — | 0,22 |
| T_T1f08_s+1 | 0; 0,969 | 0; 0,942 | 5,7 | 4,6; 4,7; 4,1 | — | — | 0,24 |
| T_T1Rf08_s+1 | 0; 0,973 | 0; 0,934 | 2,5 | 3,5; 3,9; 2,3 | — | — | 0,42 |
| M_P_s+1 | 0; 0,973 | 0; 0,949 | 7,1 | 8,6; 9,0; 7,1 | — | 0,0/0,0 | 0,09 |
| M_V1a18_s+1 | 0; 0,963 | 0; 0,954 | 7,4 | 7,5; 7,6; 6,0 | 1,13; 0,986 | 14,3/12,2 | 0,11 |

**Outras medidas:**
- **Lente:** V2n com foco 1,88 e sombra 0,59; V2o com foco 2,18 e sombra 0,42.
- **Quiralidade:** desvio na mesma casa de 0,003 (P), 0,022 (V1a12), 0,44 (V2n) e 0,54 (V2o). Erro do espelho
  ≤ 0,002; nos pares exatos, 10⁻¹⁴.
- **Relógio, φ = 0,03 / 0,05 / 0,08:**
  - T1 − V1 = −1,7 / −2,6 / −3,5;
  - T1R − T1 = +3,4 / +4,9 / +6,4;
  - Spearman (sinal × altura) ≈ −0,996.
- **Cidade:** +0,10 e +0,09 de atraso mediano.
- **Malha:** razão dos atrasos 0,94.

**Classes da fumaça:**
- GLOBAL VALE_ATRASA_SEM_TROCAR_A_ORDEM; CHEGADA MESMA_SEQUENCIA_EM_TODAS; GEOMETRIA ATRASO_DE_CAMINHO;
- dose DOSE_GEOMETRICA; lente LENTE nas quatro; quiral como previsto;
- relógio RELOGIO_ACELERA_A_ONDA; vermelho DESVIO_PARA_O_VERMELHO; cidade CIDADE_LEVE_SO_SOMA; malha
  MALHA_CONSISTENTE.

**O que difere da previsão para o `completo`, e por quê (efeito de escala da fumaça):**
- **DISPARO = MESMA_SEQUENCIA_EM_TODAS** (previsto TROCA_SO_NA_SOMBRA); **frente e ola de V2 completas e limpas**
  (previstas INCOMPLETA e PARCIAL).
  - Na cidade pequena a sombra da lente é mais rasa (0,42–0,59, contra 0,33 na exploração do `completo`), e nenhuma
    casa fica abaixo do limiar comum.
- **rede = REDE_DISPARA:** a leitura da rede chega a 0,09–0,14 do limiar no bloco G (0,42 em T1R, φ = 0,08).
  - A razão rede/mensagem é fixada em norma de força (500), e no disco pequeno isso dá uma rede mais forte por unidade
    de área.
  - No `completo` (exploração), o bloco G ficou em 0,05–0,06.

## Ajustes feitos depois da fumaça (antes de congelar)
- **Kendall mínimo de 0,95 para 0,90** (chegada e disparo):
  - na fumaça, o Kendall do disparo ficou em 0,934–0,955 sem nenhuma inversão;
  - os pares quase à mesma distância, com disparos amostrados a cada 0,5 e a ondulação da rede, baixam o Kendall sem
    trocar a ordem;
  - o teste da sequência é a inversão (Δd > 10); o Kendall fica só como verificação grosseira.
- **Cidade e malha** passaram a usar a classe da **chegada**, não a do disparo.
- **A figura** teve a legenda do painel do relógio movida para baixo.
- **O diagnóstico ω_max** passou a ser o limite de Gershgorin (o autovalor levava minutos na malha grande), e a fumaça
  foi refeita com o código final. As classes e medidas da fumaça ficaram iguais às da primeira passagem.
