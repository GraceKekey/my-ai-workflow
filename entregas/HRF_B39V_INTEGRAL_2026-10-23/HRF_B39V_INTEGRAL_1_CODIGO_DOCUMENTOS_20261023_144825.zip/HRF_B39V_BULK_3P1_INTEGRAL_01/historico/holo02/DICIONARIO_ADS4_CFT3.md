# Dicionário AdS4/CFT3 — referencial, não inferido do HRF
| Boundary d=3 | Bulk AdS_{d+1}=AdS4 | Aplicabilidade |
|---|---|---|
| Fonte escalar \(J(x)\), operador primário \(\mathcal O\) | campo escalar \(\phi(z,x)\), \(\phi \sim z^{3-\Delta}J+z^\Delta\langle\mathcal O\rangle\) (esquemático, normalização/quantização adequadas) | AdS/CFT com quantização e renormalização fixadas |
| Dimensão \(\Delta\) | \(m^2L^2=\Delta(\Delta-3)\) | escalar no limite assintótico AdS4 |
| \(S(A)\) | \(\mathrm{Area}(\gamma_A)/(4G_N)\), mais correções | RT estático; HRT dinâmico |
| \(T_{\mu\nu}\) e fonte métrica \(g^{(0)}_{\mu\nu}\) | coeficientes assintóticos da métrica em expansão FG | renormalização holográfica; normalização depende da teoria |
| operador \(\mathcal O(x)\) | \(\phi(X)=\int K(X|x)\mathcal O(x)+...\) | HKLL perturbativo e domínio reconstruível |
| algebras autorizadas | entanglement wedge reconstruction | subespaço código adequado, JLMS / correção quântica |

**Portão lógico**: inserir uma rede quântica arbitrária como boundary não garante AdS/CFT, nem CFT, nem large N ou gravidade clássica. B39V representa superfície 2D deformada embutida em 3D, NÃO o radial holográfico. O presente pacote mede propriedades quânticas necessárias ou compatibilidades fracas.
