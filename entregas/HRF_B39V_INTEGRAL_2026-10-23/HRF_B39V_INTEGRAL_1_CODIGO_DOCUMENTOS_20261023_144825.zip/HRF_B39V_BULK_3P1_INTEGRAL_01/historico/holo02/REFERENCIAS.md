# Bibliografia prioritária (já rastreada no caderno HRF CP-10)
Caderno do HRF: https://docs.google.com/document/d/1mssktGZZ51_ZB3L5unrq2CISVBLc2AV0BRIWRXgcglQ/edit
- Maldacena, Large N Limit, Adv Theor Math Phys (1998), arXiv:hep-th/9711200.
- Ryu & Takayanagi, Phys Rev Lett 96 (2006) 181602, DOI 10.1103/PhysRevLett.96.181602.
- Hubeny, Rangamani & Takayanagi, JHEP 07 (2007) 062, arXiv:0705.0016.
- Hamilton, Kabat, Lifschytz & Lowe, Phys Rev D 74 (2006) 066009, DOI 10.1103/PhysRevD.74.066009.
- Almheiri, Dong & Harlow, JHEP 04 (2015) 163, arXiv:1411.7041.
- Faulkner, Lewkowycz & Maldacena, JHEP 11 (2013) 074, arXiv:1307.2892.
- Jokela et al., Bulk metric reconstruction from entanglement data via minimal surface area variations, JHEP 2025.
- Harlow, TASI Lectures on the Emergence of Bulk Physics in AdS/CFT, arXiv:1802.01040.
- HRF Research Book Capítulo 0.1 RUP e Capítulo 3 v0.2 (fontes de governança local).
