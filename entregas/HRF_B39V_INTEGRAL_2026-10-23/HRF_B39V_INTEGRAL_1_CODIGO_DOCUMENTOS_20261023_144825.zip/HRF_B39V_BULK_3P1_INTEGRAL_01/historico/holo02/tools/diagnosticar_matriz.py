"""Inspeção algébrica da matriz; não executa uma bancada corrigida."""
import pathlib,json,numpy as np
from scipy.linalg import eigh
P=pathlib.Path(__file__).resolve().parents[1];c=json.loads((P/'config/benchmark.json').read_text());nx,ny=c['Nx'],c['Ny'];n=nx*ny;k=c['kappa'];mass=c['mass']
K=np.eye(n)*(mass*mass+4*k)
for x in range(nx):
 for y in range(ny):
  i=x*ny+y
  for xx,yy in [((x+1)%nx,y),((x-1)%nx,y),(x,(y+1)%ny),(x,(y-1)%ny)]:K[i,xx]-=k
r=dict(scope='Diagnóstico da matriz original, sem alterar ou reexecutar o benchmark',n=n,erro_simetria_max=float(np.abs(K-K.T).max()),menor_autovalor_interpretacao_lower_triangular_scipy_eigh=float(eigh(K,eigvals_only=True).min()),menor_autovalor_parte_simetrica=float(np.linalg.eigvalsh((K+K.T)/2).min()),indice_usado='xx',indice_vizinho_exigido_pela_convencao='xx*ny+yy',observacao='scipy.linalg.eigh pressupõe simetria e usa um triângulo por padrão; o código original não verifica K=K.T')
(P/'auditoria/diagnostico_matriz.json').write_text(json.dumps(r,ensure_ascii=False,indent=2));print(json.dumps(r))
