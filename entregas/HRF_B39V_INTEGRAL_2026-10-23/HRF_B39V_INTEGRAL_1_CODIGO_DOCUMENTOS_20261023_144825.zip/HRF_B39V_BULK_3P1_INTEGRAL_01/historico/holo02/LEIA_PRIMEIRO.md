# HRF-HOLO-B39V-02 — Boundary quântica 2+1 / dicionário condicional AdS4/CFT3
**Versão:** 0.1 | **Data:** 2026-10-22 | **Estatuto:** NÃO EXECUTADO, PRÉ-REGISTRO

Este pacote implementa a primeira bancada quântica 2+1 da série B39V: campo escalar harmônico quantizado em rede 2D (modelo exploratório não holográfico), entropias von Neumann de regiões, correlações de dois pontos, teste de forma de faixa e comparação adversarial com formas compatíveis com RT AdS4/CFT3. O código não afirma construir uma CFT3 holográfica nem um bulk físico. Referência 01A sintética anterior: PASS_SYNTHETIC_ONLY; 01B permanece BLOCKED_NO_DICTIONARY.

## Rodar fora deste chat
Python >=3.10, numpy >=1.24, scipy >=1.10.
```bash
python -m pip install -r requirements.txt
python -m hrf_boundary.run --config config/benchmark.json --output results
```
Resultados são escritos somente ao executar o comando, em pasta externa. Nenhum resultado pré-computado foi incluído.

## Critérios e governança
Leia `PROTOCOLO_CIENTIFICO.md` antes de executar. Os nomes PASS somente qualificam o modelo e seus testes matemáticos. Nenhum resultado de B39V ou geometria embutida entra no ajuste. Não usar entropia gaussiana comum como se fosse RT automaticamente.
