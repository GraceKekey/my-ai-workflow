# Protocolo pré-registrado — HRF-HOLO-B39V-02
Data 2026-10-22; revisão 0.1; NÃO EXECUTADO. Continuação de 01A, mantendo hashes/proveniência separada.

## Pergunta científica
[F] Existe dicionário holográfico AdS4/CFT3 para teorias adequadas: fontes e valores esperados de operadores, dicionário massa-dimensão, RT/HRT, HKLL perturbativo e reconstrução de wedge, e tensor energia-momento / coeficientes assintóticos da métrica, dentro de seus limites. [H] Uma teoria de base HRF poderia admitir um dicionário semelhante. [M] Este ensaio mede apenas se um campo escalar harmônico quântico de rede 2D exibe estrutura entrópica/correlacional compatível com necessárias, NÃO suficientes, formas de um CFT3.

## O que é implementado e o que não é
IMPLEMENTADO: Hamiltoniano H=(1/2)p^Tp+(1/2)q^T K q, K=(m²+4κ)I-κ somatório vizinhos periódicos 2D; covariâncias do estado fundamental X=K^{-1/2}/2, P=K^{1/2}/2; entropia de von Neumann das sub-regiões por espectro simplético de sqrt(X_A)P_A sqrt(X_A); informação mútua de regiões disjuntas; dispersão teórica de modo baixo; ajuste de forma S(w)=a-b[1/w+1/(Nx-w)] e controle de área S(w)=a no toro, com holdouts. O ansatz de faixa periodizada é apenas diagnóstico, não é fórmula RT exata para toro.
NÃO IMPLEMENTADO: CFT3 de grande N e espectro esparso; dual gravitacional semiclassico; RT a partir deste estado; HKLL numérico, HRT ou campo bulk; métrica completa; DIO→GMFt; confronto quantitativo com B39V.

## Dados e análise
Malha Nx=18, Ny=6, κ=1 e massa reguladora m=0.35; faixas ao longo de x envolvendo todos os y, larguras 2,3,4,5,6,7; treino 2,4,6; teste 3,5,7; regiões disjuntas A e B para I(A:B). As escalas numéricas são arbitrárias e não parâmetros físicos HRF inferidos.

## Gates com interpretação congelada
G0 INTEGRITY: manifesto SHA256, parâmetros arquivados e todas dependências disponíveis.
G1 QUANTUM: simetria de X,P, positividade do espectro simplético ν>=1/2-1e-8 e S>=-1e-8. Se falhar FAIL_NUMERIC.
G2 PURE_STATE: S(A)=S(complemento) dentro de 1e-7 no estado puro global. Se falhar FAIL_NUMERIC.
G3 MI: informação mútua I(A:B)>=-1e-7. Se falhar FAIL_NUMERIC.
G4 STRIP_DIAGNOSTIC: guardar RMS dos holdouts tanto forma inversa quanto área constante; improvement >0 é indicador de forma, não PASS_HOLOGRAPHY. Qualquer ajuste mal condicionado -> INCONCLUSIVE.
G5 HOLOGRAPHIC_DICTIONARY: obrigatório grande N e controle de setor gravitacional, operadores, simetrias, dimensões, correções quânticas e teste independente de dados. Este modelo simples: NOT_ESTABLISHED.
G6 BULK_RECONSTRUCTION: RT/HRT/HKLL aplicados com condições verificadas e métricas não introduzidas artificialmente: NOT_EXECUTED.
G7 B39V: mapa dinâmico e causal sem vazamento do vale: NOT_EXECUTED.
G8 DIO_GMFt: testemunha pré-estímulo e código lógico: NOT_EXECUTED.

## Controle adversarial
Massa reguladora não nula introduz escala: comparar m=0.2,0.35,0.6 como análise de robustez EXTERNA opcional e declarada, não declarar limite conforme com m=0.35. Toro finito tem dois bordos de entanglement: S(w)=S(Nx-w). Área transversal Ny fixa. Lei de área não basta para dual holográfico. Para AdS4/CFT3 genuína, forma de faixa no plano infinito contém termo universal ∝ -Ly/w, além da divergência UV; o modelo finite torus não é esse limite.
Confrontar controles de ajustamento e métricas apenas em rodada posterior, sem ajustar vales B39V em datasets iniciais.

## Dados permitidos para a série
01A foi inversão sintética exata do próprio ansatz; permanece PASS_SYNTHETIC_ONLY. B39V membrana 2.5D clássica não é a boundary deste ensaio. Correspondência física entre elas permanece H e exige mapa de observáveis (G geometria, W propagação, D dicionário).
