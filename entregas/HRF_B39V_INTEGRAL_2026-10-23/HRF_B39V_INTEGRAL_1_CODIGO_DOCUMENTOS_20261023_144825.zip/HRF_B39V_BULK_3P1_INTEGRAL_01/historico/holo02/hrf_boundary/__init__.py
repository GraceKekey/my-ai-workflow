"""HRF-HOLO-B39V-02: boundary gaussian model, NOT a holographic dual."""
