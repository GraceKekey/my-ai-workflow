"""External-only execution. No results distributed with archive.
Run: python -m hrf_boundary.run --config config/benchmark.json --output results
"""
from __future__ import annotations
import argparse,json,datetime,hashlib
from pathlib import Path
import numpy as np
from scipy.linalg import eigh

def harmonic_covariances(nx:int,ny:int,kappa:float,mass:float):
    n=nx*ny
    if nx<8 or ny<3 or mass<=0 or kappa<=0: raise ValueError('Invalid dimensions/coupling/IR regulator')
    K=np.eye(n)*(mass*mass+4*kappa)
    for x in range(nx):
        for y in range(ny):
            i=x*ny+y
            for xx,yy in [((x+1)%nx,y),((x-1)%nx,y),(x,(y+1)%ny),(x,(y-1)%ny)]:
                K[i,xx]-=kappa
    lam,U=eigh(K,check_finite=True)
    if lam.min()<=0: raise ValueError('K non positive')
    X=(U*(0.5/np.sqrt(lam)))@U.T
    P=(U*(0.5*np.sqrt(lam)))@U.T
    return X,P,lam

def entropy(X,P,indices):
    inds=np.array(sorted(set(indices)),dtype=int)
    if len(inds)==0:return 0.0,0.5
    XA=X[np.ix_(inds,inds)]; PA=P[np.ix_(inds,inds)]
    eig,V=eigh(XA)
    if eig.min()<=0: raise ValueError('X_A not positive')
    SX=(V*np.sqrt(eig))@V.T
    mu=eigh(SX@PA@SX,eigvals_only=True)
    if mu.min() < 0.25-1e-8: raise ValueError('Unphysical symplectic eigenvalue')
    nu=np.sqrt(np.maximum(mu,0.25))
    aa=np.maximum(nu-0.5,0.)
    S=np.sum((aa+1)*np.log1p(aa)-np.where(aa>0,aa*np.log(np.maximum(aa,1e-300)),0.))
    return float(S),float(nu.min())

def strip(nx,ny,w,start=0):
    return [(x%nx)*ny+y for x in range(start,start+w) for y in range(ny)]

def fit_holdout(widths,values,nx,tr,te):
    # finite-torus inverse-width diagnostic only; not the RT strip formula on a plane
    ws=np.array(widths,dtype=float); v=np.array(values,float)
    f=1/ws+1/(nx-ws)
    A=np.column_stack([np.ones(len(ws)), -f])
    ids=[widths.index(w) for w in tr]; jds=[widths.index(w) for w in te]
    params=np.linalg.lstsq(A[ids],v[ids],rcond=None)[0]
    predictions=A@params
    const=float(np.mean(v[ids]))
    rmse=lambda p:float(np.sqrt(np.mean((p[jds]-v[jds])**2)))
    return {'fit_offset':float(params[0]),'fit_inverse_coefficient':float(params[1]),'holdout_rmse_inverse':rmse(predictions),'holdout_rmse_area_only':rmse(np.full(len(v),const)),'fit_rank':int(np.linalg.matrix_rank(A[ids])),'interpretation':'only a functional-form diagnostic on a finite periodic lattice; no holographic inference'}

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',required=True);ap.add_argument('--output',required=True)
    arg=ap.parse_args(); cf=Path(arg.config);c=json.loads(cf.read_text());out=Path(arg.output);out.mkdir(parents=True,exist_ok=True)
    nx=int(c['Nx']);ny=int(c['Ny'])
    X,P,spectrum=harmonic_covariances(nx,ny,float(c['kappa']),float(c['mass']))
    widths=list(map(int,c['strip_widths']));S=[];sympl=[]
    for w in widths:
        val,minimum=entropy(X,P,strip(nx,ny,w));S.append(val);sympl.append(minimum)
    a=strip(nx,ny,int(widths[0])); complement=sorted(set(range(nx*ny))-set(a))
    SA,_=entropy(X,P,a); SC,_=entropy(X,P,complement)
    ia=[x*ny+y for x in c['mi_a_x'] for y in range(ny)]
    ib=[x*ny+y for x in c['mi_b_x'] for y in range(ny)]
    s1,_=entropy(X,P,ia);s2,_=entropy(X,P,ib);sab,_=entropy(X,P,ia+ib)
    mi=s1+s2-sab
    tf=fit_holdout(widths,S,nx,c['train_widths'],c['test_widths'])
    tol=float(c['check_tolerance'])
    gates={'G1_QUANTUM':'PASS_NUMERIC' if min(sympl)>=0.5-1e-8 and min(S)>=-tol else 'FAIL_NUMERIC',
           'G2_PURE_STATE':'PASS_NUMERIC' if abs(SA-SC)<tol else 'FAIL_NUMERIC',
           'G3_MUTUAL_INFO':'PASS_NUMERIC' if mi>=-tol else 'FAIL_NUMERIC',
           'G4_STRIP':'DIAGNOSTIC_ONLY',
           'G5_HOLOGRAPHIC_DICTIONARY':'NOT_ESTABLISHED',
           'G6_BULK_RECONSTRUCTION':'NOT_EXECUTED',
           'G7_B39V':'NOT_EXECUTED',
           'G8_DIO_GMFt':'NOT_EXECUTED'}
    data={'project':'HRF','bench':'HRF-HOLO-B39V-02','timestamp_UTC':datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'configuration':c,'source_config_sha256':hashlib.sha256(cf.read_bytes()).hexdigest(),
          'spectrum_min_K':float(spectrum.min()),'entropies':dict(zip(map(str,widths),S)),
          'min_symplectic_eigenvalues':dict(zip(map(str,widths),sympl)),
          'purity_absolute_entropy_difference':abs(SA-SC),'mutual_information':mi,
          'shape_fit':tf,'gates':gates,'disclaimer':'Gaussian finite lattice is not demonstrated holographic CFT3. No emergent bulk or B39V reconstruction.'}
    (out/'resultados.json').write_text(json.dumps(data,indent=2,ensure_ascii=False))
    (out/'RESUMO.md').write_text('# HRF-HOLO-B39V-02 — resultado externo\n\n'+
        '\n'.join(f'- **{k}**: {v}' for k,v in gates.items())+'\n\n'+
        'Não interpretar a forma funcional de entropia como prova de dualidade AdS/CFT.\n')
    print(json.dumps({'result_path':str(out/'resultados.json'),'gates':gates},indent=2))
if __name__=='__main__':main()
