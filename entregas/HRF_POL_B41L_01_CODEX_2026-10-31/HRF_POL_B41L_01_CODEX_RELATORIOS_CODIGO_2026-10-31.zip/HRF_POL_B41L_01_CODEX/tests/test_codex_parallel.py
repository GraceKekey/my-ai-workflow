"""Controles algébricos do novo escalonador, sem novas integrações físicas."""
import importlib.util
from pathlib import Path
import unittest

spec=importlib.util.spec_from_file_location('codex_parallel',Path(__file__).resolve().parents[1]/'scripts/rodar_codex_parallel.py')
parallel=importlib.util.module_from_spec(spec);spec.loader.exec_module(parallel)

class ParallelTests(unittest.TestCase):
    def test_complete_partition_exact(self):
        c=parallel.config('completo');groups=parallel.groups(c)
        ids=[x['case_id'] for _,xs in groups for x in xs]
        self.assertEqual(len(groups),30);self.assertEqual(len(ids),2400)
        self.assertEqual(len(set(ids)),2400)

    def test_storage_contains_actual_arrays(self):
        bound=parallel.storage_bound(387,943,9)
        raw=388*448+10*(16*943+8)+320
        self.assertGreaterEqual(bound,raw)
        self.assertGreater(parallel.storage_bound(774,943,9),bound)

    def test_resource_admission_can_reject(self):
        plan={'groups':[{'RAM_bound_bytes':5_268_435_456,'cases':[{'disk_bytes':2**20,'blocked':None}]}]}
        self.assertEqual(parallel.admission(plan,4,30*2**30,32*2**30)['status'],'ADMITTED')
        self.assertEqual(parallel.admission(plan,4,30*2**30,8*2**30)['status'],'BLOCKED_RESOURCES')
        self.assertEqual(parallel.admission(plan,4,2**30,32*2**30)['status'],'BLOCKED_RESOURCES')

    def test_no_run_without_explicit_confirmation(self):
        with self.assertRaises(PermissionError):parallel.run(Path('/nonexistent'),4,False)

    def test_limits_still_block_even_when_resources_fit(self):
        plan={'groups':[{'RAM_bound_bytes':1,'cases':[{'disk_bytes':1,'blocked':'max_frames'}]}]}
        self.assertEqual(parallel.admission(plan,1,30*2**30,32*2**30)['status'],'BLOCKED_RESOURCES')

if __name__=='__main__':unittest.main()
