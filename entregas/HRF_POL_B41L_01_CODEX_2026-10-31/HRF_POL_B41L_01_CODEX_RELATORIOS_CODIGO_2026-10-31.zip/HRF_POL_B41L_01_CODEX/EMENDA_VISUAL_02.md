# Revisão 0.1.2 — correção exclusiva de visualização, 30/10/2026

[D] A inspeção do PNG de Stokes da revisão 0.1.1 encontrou uma linha sem marcadores com um único ponto por estado. Os eixos apareciam, mas o ponto não era visível. A revisão 0.1.1 publicada permanece intacta; seus arquivos originais e os dados medidos foram preservados.

[D] O novo scripts/renderizar_stokes.py lê os evaluation.json e desenha marcadores em todas as janelas disponíveis. O launcher scripts/pol.py aplica essa finalização depois do gerador original. O notebook usa o mesmo comando. Não há ajuste de fase, integração, alteração de fasores ou reavaliação de gates nessa etapa.

[D] Todos os dez arquivos de src/, todas as configurações científicas, as seis execuções de fumaça, os selos COMPLETED e toda a dependência B41L permanecem byte a byte idênticos à versão 0.1.1. Assim, a identidade numérica dos checkpoints permanece a mesma. O launcher e o novo renderizador são congelados separadamente no manifesto. A versão anterior do launcher, notebook e manifestos foi preservada em auditoria/pre_visual_02/.

[D] As figuras corrigidas estão em resultados/figuras_fumaca_v0_1_2/. As figuras 0.1.1 continuam em seu diretório anterior. Nenhuma simulação foi executada para essa correção. G3 continua FAIL; G7 continua PENDING.
