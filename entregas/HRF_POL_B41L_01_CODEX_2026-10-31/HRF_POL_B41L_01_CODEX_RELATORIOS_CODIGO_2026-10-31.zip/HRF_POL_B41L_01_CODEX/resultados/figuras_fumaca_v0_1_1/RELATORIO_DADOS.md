# Relatório gerado dos dados disponíveis

**[M] SMOKE_ONLY**. Fumaça não é rodada científica completa.

| Gate | Estado |
|---|---|
|G0|PASS|
|G1|PENDING|
|G2|PASS|
|G3|FAIL|
|G4|PENDING|
|G5|PENDING|
|G6|PENDING|
|G7|PENDING|

[?] Os P01–P05 originais não foram disponibilizados. Nenhum PASS Jones é transferido ao setor relacional. Os resultados históricos B1/B41/B41H/B41L permanecem intactos.

[D] Valores por caso e falhas completas em casos.csv; dados de campo/cochain e metadados nos diretórios de caso.
