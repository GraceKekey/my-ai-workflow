# PROMPT PARA CODEX — HRF-POL-B41L-01

## 1. Missão

Você atuará como pesquisador computacional em física teórica, especializado em eletrodinâmica, teoria de gauge em redes, óptica e simulações científicas reproduzíveis.

Crie uma nova bancada científica para o **Holographic Reconstruction Framework (HRF)**, denominada:

**HRF-POL-B41L-01 — Polarização completa da onda fotônica relacional sobre a B41L.**

Sua finalidade é verificar se a dinâmica relacional U(1)/Wilson utilizada no Capítulo 2 do HRF consegue reproduzir a propagação e as propriedades observáveis de polarizações lineares, circulares e elípticas, comparadas com o controle Maxwell/Jones/Stokes.

Não basta executar fórmulas de Jones e obter PASS. O teste principal exige que os observáveis sejam calculados a partir da evolução efetiva dos campos da B41L.

O trabalho deve seguir o método **Reconstrução Unificadora Progressiva (RUP), B → A**, distinguindo:

- [F] Física e matemática estabelecidas.
- [M] Resultados numéricos e modelos.
- [H] Hipóteses ainda não demonstradas.
- [?] Questões abertas.
- [D] Decisões metodológicas.

Não declarar comprovação da existência física dos GMFs, origem do fóton, holografia ou unificação fundamental.

## 2. Fontes obrigatórias

Antes de escrever código, leia efetivamente os documentos especializados:

**Diretriz metodológica — leitura integral obrigatória**

HRF Research Book, Capítulo 0.1 v0.2:

https://drive.google.com/file/d/1ORdJioQTaZL8Wfg_LasZyDu1maQ4Tn2I/view

**Capítulo fotônico atual de referência**

Research Book, Capítulo 2 v1.5:

https://drive.google.com/file/d/1oiEC8C3dbLFBM-B1eU0cPpTDhjz2I9t0/view

**B41L — código, pré-registro e resultados**

https://drive.google.com/drive/folders/1f8jPlNv-HahobWKewACoY7ukIVHfV6fN

Pacote de resultados completos:

https://drive.google.com/file/d/1Inb8MaIvSL40cmBoxKZaeNHzoxPBJtV9/view

Localize também o controle anterior `HRF-POL-01`, nos pacotes `HRF_3_Bancadas.zip` e `HRF_3_Execucoes.zip`, quando fornecidos.

Caso não tenha acesso às fontes, identifique exatamente os arquivos ausentes e solicite seu fornecimento. Nunca substitua a dinâmica B41L por um solver fictício, simplificado ou independente sem declarar que o gate relacional ficou NOT_EXECUTED.

## 3. Estado científico que deve ser preservado

A B41L teve três variantes:

- **V0:** lançamento original.
- **V1:** lançamento limpo, removendo a parte longitudinal espúria.
- **V1E:** V1 com estimador espectral adicionalmente limpo.

Resultados documentados:

| Conjunto | V1 |
|---|---|
| B1 | Fechado, P1 = 10/10 |
| B41 | Fechado com ressalva, P1 = 9/10; P4 falhou |
| Novas sementes | Fechado com ressalva, P1 = 9/10; P4 falhou |

Em V1E, o P5 falhou nos três conjuntos. O coeficiente de dispersão mudou significativamente, e a comparação de frequência dinâmica não favoreceu o estimador limpo nos 90 casos examinados.

**Decisão para esta nova bancada:** utilizar V1 como configuração principal e manter V0 como controle pareado. V1E não será usado como calibração principal.

Não modificar, sobrescrever ou reclassificar os resultados históricos da B1, B41, B41H ou B41L.

## 4. Pergunta científica

A dinâmica relacional da B41L, com lançamento livre de carga espúria, consegue transportar estados de polarização arbitrários preservando seus observáveis físicos, no domínio em que Maxwell prevê propagação livre sem alteração da polarização?

Investigar separadamente:

1. Preparação inicial do estado.
2. Evolução temporal do campo.
3. Extração dos observáveis físicos.
4. Conservação e propagação da polarização.
5. Convergência com refinamento da malha.
6. Correspondência com o controle Maxwell.

Não presumir que a correspondência será bem-sucedida.

## 5. Modelo e estados iniciais

Reutilize as malhas tridimensionais Delaunay, os operadores discretos, as matrizes de Whitney, o Hamiltoniano, o integrador e a limpeza da B41L.

A conexão relacional deve continuar sendo representada por seus graus de liberdade originais, e não substituída diretamente por um vetor de Jones.

Reutilize a projeção transversal e a limpeza do lançamento da B41L. Para a velocidade inicial, a forma operacional de referência é:

\[
v_T=v_0-d_0\lambda,
\]

com

\[
d_0^TM_1d_0\lambda=d_0^TM_1v_0.
\]

Verifique como esse procedimento aparece efetivamente no código original e respeite suas condições de contorno e a formulação em momento canônico quando aplicável.

Construa, no mínimo, os estados:

| Estado | Jones normalizado |
|---|---|
| Linear horizontal | (1, 0) |
| Linear vertical | (0, 1) |
| Linear diagonal | (1, 1)/√2 |
| Linear antidiagonal | (1, −1)/√2 |
| Circular positiva | (1, +i)/√2 |
| Circular negativa | (1, −i)/√2 |
| Elíptica positiva | (√3, +i)/2 |
| Elíptica negativa | (√3, −i)/2 |

Jones é a referência para preparar e comparar amplitudes, não uma prova de que o campo relacional as transporta corretamente.

Verifique que a superposição de modos e a preparação do estado sejam compatíveis com a dinâmica efetivamente implementada. Não imponha a conservação da polarização por renormalização posterior.

Inclua controles com campo nulo, reversão da direção de propagação, troca de helicidade e fase relativa alterada.

## 6. Observáveis físicos

Defina uma base transversal ortonormal para cada direção de propagação e estabeleça explicitamente a convenção de fase, orientação e helicidade.

Calcule os quatro parâmetros de Stokes:

\[
S_0=|E_1|^2+|E_2|^2
\]

\[
S_1=|E_1|^2-|E_2|^2
\]

\[
S_2=2\operatorname{Re}(E_1^*E_2)
\]

\[
S_3=2\operatorname{Im}(E_1^*E_2)
\]

Na convenção acima, o estado (1,+i)/√2 possui S3 positivo.

Os valores devem ser extraídos de amplitudes complexas reconstruídas das séries físicas da B41L, e não simplesmente dos coeficientes iniciais utilizados no lançamento.

Especifique e valide o mapa entre as variáveis de aresta e os componentes físicos transversais do campo. Utilize, conforme apropriado, a estrutura Whitney e os operadores gauge-invariantes disponíveis.

O mapa de observáveis deve ser testado contra alterações puramente de gauge. Caso não seja possível construir uma extração confiável, registrar **GATE_OBSERVAVEIS = PENDING**, sem fabricar um PASS.

Medir também:

- Intensidade normalizada e evolução de S0.
- Grau de polarização e pureza.
- Helícidade e sua possível mistura.
- Fase relativa entre componentes.
- Resíduo da lei de Gauss.
- Energia total e sua deriva temporal.
- Dispersão e diferença de fase entre modos, sem recalibrar o parâmetro ξ.
- Dependência das medidas com a direção de propagação.

## 7. Gates e critérios

Antes de qualquer rodada física, elaborar `PREREGISTRO_HRF_POL_B41L_01.md`, com valores numéricos de tolerância, métodos de extração, sementes e hipóteses.

Utilizar como referência inicial os limites do protocolo POL-01 anterior, mas revisar sua aplicabilidade ao novo observável relacional e congelar as decisões **antes de observar os resultados da rodada principal**.

Criar gates independentes:

**G0 — Integridade e proveniência**

Validar SHA-256 dos códigos B41L, versão das dependências, arquivos de entrada e fidelidade das rotinas reutilizadas.

**G1 — Maxwell/Jones/Stokes**

Reproduzir o controle ideal já validado, preservando os critérios originais P01–P05. Esse gate não aprova o HRF.

**G2 — Preparação e gauge**

Verificar resíduo da lei de Gauss, carga espúria e pureza inicial para cada estado, em V0 e V1.

**G3 — Observáveis físicos**

Demonstrar que a extração do campo transversal, dos fasores e dos Stokes é definida, estável e invariante sob gauge no domínio estudado.

**G4 — Propagação e conservação**

Comparar Stokes ao longo da evolução e investigar intensidade, energia, fase e mistura de helicidade, considerando resolução espectral e efeitos de contorno.

**G5 — Robustez numérica**

Testar pelo menos três refinamentos, sementes independentes e mais de uma orientação espacial. Medir taxas de falha e intervalos de confiança, sem descartar sementes desfavoráveis.

**G6 — Comparação Maxwell × B41L**

Comparar os mesmos estados físicos e os observáveis correspondentes, separando diferenças físicas, efeitos de discretização e erros de preparação.

**G7 — Veredito científico**

Usar PASS, FAIL, PENDING ou NOT_EXECUTED por gate. Nenhum gate deverá receber PASS se sua dependência essencial falhou.

Não alterar tolerâncias após observar a rodada completa. Se aparecer um erro de código, preservar a versão original, documentar a correção em versão nova e fazer nova execução identificada.

## 8. Controles adversariais

Implementar verificações capazes de detectar falsos resultados positivos:

- Lançamento V0 versus V1, nas mesmas malhas e sementes.
- Aplicação de transformação de gauge que não deve alterar Stokes físicos.
- Troca de helicidade.
- Polarização linear sem circularidade artificial.
- Estados elípticos com diferentes amplitudes e fases.
- Rotação da orientação espacial do feixe.
- Refinamento da malha e análise de convergência.
- Campo nulo, com classificação adequada quando S0 = 0.
- Controle não unitário artificial apenas no benchmark Jones, demonstrando que o avaliador detecta perda.
- Uma perturbação controlada no mapa de observáveis, para assegurar que o gate de correspondência possa reprovar uma implementação incorreta.

Não usar um resultado do controle Maxwell como substituto de uma medida da dinâmica HRF.

## 9. Execução no Google Colab

Crie um notebook executável:

`HRF_POL_B41L_01_Colab.ipynb`

Com células organizadas nesta sequência:

1. Apresentação e estado epistemológico.
2. Montagem do Google Drive.
3. Localização ou upload do ZIP completo da B41L.
4. Verificação de integridade e extração.
5. Instalação das dependências, preferencialmente reproduzindo o ambiente auditado da B41L (Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1), quando compatível com o Colab. Registrar divergências e nunca afirmar reprodutibilidade binária entre ambientes diferentes sem conferir.
6. Testes unitários de infraestrutura.
7. Controle independente Maxwell/Jones.
8. Extração do solver relacional e testes de observáveis.
9. Fumaça com malhas pequenas.
10. Avaliação da fumaça e verificação dos gates.
11. Execução principal, controlada por `CONFIRMO_COMPLETA = False`, alterável pelo usuário.
12. Avaliação científica.
13. Gráficos, tabelas e relatório.
14. Compactação dos resultados.
15. Cópia para o Google Drive e links para download.

A versão completa deve permitir reinício após interrupção do Colab, utilizando checkpoints por semente, estado, malha e gate.

Utilize controle de RAM e paralelização conservadora. Não presumir que GPU acelera os operadores SciPy existentes.

O notebook deve funcionar com o ZIP enviado manualmente caso a pasta compartilhada não esteja montada no caminho esperado do Google Drive.

## 10. Estrutura do pacote

Entregue uma pasta nova, sem modificar a B41L:

`HRF_POL_B41L_01/`

Incluindo:

- `LEIA_ME_PRIMEIRO.md`
- `PREREGISTRO_HRF_POL_B41L_01.md`
- `HRF_POL_B41L_01_Colab.ipynb`
- `requirements.txt`
- `src/` — módulos de preparação, extração, evolução, controles e avaliação
- `tests/` — testes unitários e adversariais
- `configs/` — parâmetros, sementes e limites congelados
- `resultados/` — inicialmente vazio ou contendo apenas resultados de fumaça claramente identificados
- `auditoria/` — hashes, dependências e proveniência
- `RELATORIO_MODELO.md` — contratos de estados, operadores, observáveis e limites físicos
- `RELATORIO_EXECUCAO.md` — modelo de relatório que só deve receber resultados físicos após a execução
- `MANIFESTO_SHA256.txt`

Produza também um arquivo ZIP de distribuição.

O código deve permitir executar somente os testes unitários, somente os controles convencionais, somente a fumaça ou a rodada completa.

## 11. Procedimento obrigatório do Codex

Trabalhe em sequência:

**Fase 1 — Auditoria**

Ler os arquivos originais, identificar funções reutilizáveis da B41L e documentar a interface proposta. Conferir especialmente `b41l_limpeza.py`, `b41l_bloco_b.py`, `b41l_comum.py` e os módulos originais utilizados na evolução.

**Fase 2 — Pré-registro**

Registrar hipóteses, critérios, parâmetros, controles, tolerâncias e limitações antes da execução. Não alterar documentos históricos.

**Fase 3 — Implementação**

Criar os módulos Python, o adaptador para B41L, os observáveis e o notebook Colab.

**Fase 4 — Validação técnica**

Executar compilação, testes unitários, controles analíticos e, se o ambiente permitir, uma fumaça pequena. Corrigir defeitos de infraestrutura com proveniência.

**Fase 5 — Entrega**

Entregar arquivos e relatório do que foi realmente testado. Não executar a rodada científica completa sem o acionamento explícito no Colab.

## 12. Critério de sucesso

A bancada só poderá declarar sucesso no **transporte relacional de polarização** se os observáveis forem produzidos pela dinâmica B41L real, com os gates físicos e numéricos aprovados conforme o pré-registro.

Um PASS no controle Jones/Stokes, isoladamente, não é suficiente.

Não declarar derivação de fóton individual, origem de U(1), holografia ou PHOTON-CLOSURE-F.

Se o resultado for FAIL, PENDING ou INCONCLUSIVO, preservar os dados e identificar precisamente o motivo.

**Entregável final:** uma bancada científica reproduzível e auditável, com notebook pronto para Google Colab, ZIP, pré-registro, documentação e verificadores independentes, destinada à primeira avaliação sistemática da polarização completa sobre a B41L.

Toda a documentação científica e os relatórios devem ser escritos em português brasileiro.
