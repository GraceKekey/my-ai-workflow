# Revisão0.1.1 — emenda técnica anterior à rodada completa,30/10/2026

[D] A primeira fumaça (6casos em resultados/fumaca/) e o código anterior foram preservados. Nenhum arquivo B41L congelado ou resultado histórico foi alterado. Os limiares, sementes e duração não mudam.

1. Gauss dinâmico passa a medir ||d0T pi(t)-d0T pi(0)||, e não apenas diferença das normas, que poderia ocultar rotação do vetor de carga. A preparação usa a norma inicial de pi no denominador.
2. Quando a duração efetivamente integrada por arredondamento de passos não comporta todas as janelas requeridas, G3 recebe PENDING (amostragem insuficiente), em vez de FAIL. Isso não converte falha em aprovação; G4/G6 continuam PENDING. Nenhuma janela foi encurtada e nenhuma tolerância foi afrouxada.
3. Acrescentados diagnósticos descritivos de frequências de fase dos campos físicos, diferença entre componentes e omega/|k|. Não entram na preparação nem reajustam omega ou xi.
4. Orçamento de RAM conservador aumentado para5MB por nó +256MiB; rodada completa verifica também admissão da família antes de executar. Nenhuma malha física foi reduzida para caber.

[D] A nova fumaça identificada será gravada em resultados/fumaca_v0_1_1/. O PASS de software não certifica transporte de polarização. G1 original permanece PENDING pela ausência dos P01–P05 de POL-01; não há um gate global positivo.
