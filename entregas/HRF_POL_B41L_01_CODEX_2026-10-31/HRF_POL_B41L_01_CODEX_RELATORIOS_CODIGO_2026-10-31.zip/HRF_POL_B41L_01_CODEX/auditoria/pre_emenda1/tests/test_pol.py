"""[F/M] Álgebra, controles adversariais e referência pequena do kernel ORIGINAL."""
from pathlib import Path
import sys,unittest,tempfile,json
from unittest.mock import patch
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from common import ROOT,verify_dependency,atomic_npz,atomic_json,sha
from stokes import STATES,stokes,fit_windows,distance
from controls import run_controls
from dependency import context,prepare,original_step,modules
from observable import Observer
from planning import config,plan,cases

class Algebra(unittest.TestCase):
 def test_original_43_hashes(self):self.assertEqual(len(verify_dependency()),43)
 def test_circular_sign(self):self.assertAlmostEqual(stokes(STATES['C+'])['s'][2],1);self.assertAlmostEqual(stokes(STATES['C-'])['s'][2],-1)
 def test_elliptical(self):self.assertTrue(np.allclose(stokes(STATES['E+'])['s'],[.5,0,np.sqrt(3)/2]))
 def test_global_phase(self):self.assertLess(distance(stokes(STATES['E+']),stokes(np.exp(1j*.7)*STATES['E+'])),1e-14)
 def test_null_has_no_polarization(self):self.assertIsNone(stokes([0,0])['s'])
 def test_incoherent_mixture_is_not_forced_pure(self):self.assertLess(stokes([[1,0],[0,1]])['degree'],1e-14)
 def test_loss_detected_without_renormalization(self):self.assertAlmostEqual(stokes(.5*STATES['H'])['S'][0],.25)
 def test_lockin_reads_evolved_signal_not_input_labels(self):
  t=np.linspace(0,30,1201);J=np.array([.8,.6j]);z=np.broadcast_to(np.exp(-1j*t)[:,None,None]*J[None,None,:],(len(t),8,2));out=fit_windows(t,z,1,np.ones(8));self.assertTrue(out);self.assertLess(distance(out[0],stokes(J)),1e-12)
 def test_short_window_pending(self):self.assertEqual(fit_windows(np.arange(3.),np.zeros((3,8,2)),1,np.ones(8)),[])
 def test_wrong_map_rejected(self):self.assertGreater(distance(stokes(STATES['C+']),stokes(np.conj(STATES['C+']))),1.9)
 def test_ordinary_new_controls_do_not_certify_old_P01(self):
  with tempfile.TemporaryDirectory() as td:
   r=run_controls(Path(td)/'controls.json');self.assertEqual(r['diagnostic_status'],'PASS');self.assertEqual(r['G1'],'PENDING')
 def test_plan_no_mesh(self):
  with tempfile.TemporaryDirectory() as td,patch('dependency.context',side_effect=AssertionError('mesh created')):self.assertEqual(plan(config('completo'),td)['cases'],2400)
 def test_full_requires_colab_confirmation_before_context(self):
  from runner import run
  with tempfile.TemporaryDirectory() as td,patch('runner.verify_freeze'),patch('runner.context',side_effect=AssertionError('mesh created')):
   with self.assertRaises(PermissionError):run(config('completo'),td,False)
 def test_completion_seal_detects_corruption(self):
  from runner import valid_completion
  with tempfile.TemporaryDirectory() as td:
   p=Path(td);(p/'data').write_bytes(b'ok');atomic_json(p/'COMPLETED.json',dict(run_id='T',files={'data':sha(p/'data')}));self.assertTrue(valid_completion(p,'T'));(p/'data').write_bytes(b'bad')
   with self.assertRaises(ValueError):valid_completion(p,'T')
 def test_atomic_npz(self):
  with tempfile.TemporaryDirectory() as td:
   p=Path(td)/'a.npz';atomic_npz(p,q=np.arange(4));self.assertTrue(np.array_equal(np.load(p)['q'],np.arange(4)))

class FrozenPhysicsReference(unittest.TestCase):
 @classmethod
 def setUpClass(cls):cls.ctx=context(41910001,[4],4)
 def test_whitney_reconstructs_constant_physical_E(self):
  c=self.ctx;C=c['C'];v=C.vet_aresta@np.array([.3,-.4,.2]);obs=Observer(c,np.array([0,0,1.]),np.eye(3)[0],np.eye(3)[1]);E,B=obs.fields(np.zeros(C.E),v)
  self.assertLess(np.max(abs(E+np.array([.3,-.4,.2]))),1e-10)
 def test_initial_phasor_comes_from_fields(self):
  q,v,p=prepare(self.ctx,[0,0,1],STATES['C+'],'V1',.001);o=Observer(self.ctx,p['k'],p['ea'],p['eb']);s=stokes(o.initial_phasor(q,v,p['omega']),o.weights);self.assertGreater(s['s'][2],.8)
 def test_gauge_q_does_not_change_fields(self):
  q,v,p=prepare(self.ctx,[0,0,1],STATES['E+'],'V1',.001);o=Observer(self.ctx,p['k'],p['ea'],p['eb']);g=o.gauge_test(q,v);self.assertLess(max(g['E_relative'],g['B_relative']),1e-8)
 def test_original_cleaning_gauss(self):
  q,v,p=prepare(self.ctx,[0,0,1],STATES['H'],'V1',.001);self.assertLess(p['cleaning']['res_transversal'],1e-8)
 def test_change_direction_preserves_right_handed_basis(self):
  q,v,p=prepare(self.ctx,[0,0,-1],STATES['C+'],'V1',.001);self.assertTrue(np.allclose(np.cross(p['ea'],p['eb']),p['k']/np.linalg.norm(p['k'])))
 def test_deliberately_wrong_potential_map_fails_gauge(self):
  class Wrong(Observer):
   def fields(self,q,v):
    E,B=super().fields(q,v);bad=self.ctx['PC'].campos_tet(self.ctx['C'],1j*q,1.)[0].real
    return E+.1*bad,B
  q,v,p=prepare(self.ctx,[0,0,1],STATES['C+'],'V1',.001);wrong=Wrong(self.ctx,p['k'],p['ea'],p['eb']);self.assertGreater(wrong.gauge_test(q,v)['E_relative'],1e-8)
 def test_checkpoint_resume_has_identical_numeric_arrays(self):
  from runner import run_case
  c=config('fumaca');c.update(grid_order=[4],periods=.15,checkpoint_steps=2);x=next(cases(c));x['n']=4;x['variant']='V1';native=original_step()[0];calls=[]
  def interrupted(q,v,a,dt,lu,K):
   calls.append(1)
   if len(calls)==5:raise KeyboardInterrupt('interrupcao tecnica controlada')
   return native(q,v,a,dt,lu,K)
  with tempfile.TemporaryDirectory() as td:
   root=Path(td)
   with patch('runner.original_step',return_value=(interrupted,'TECHNICAL_TEST')):
    with self.assertRaises(KeyboardInterrupt):run_case(c,x,root/'resume',self.ctx)
   run_case(c,x,root/'resume',self.ctx);run_case(c,x,root/'fresh',self.ctx)
   with np.load(root/'resume'/x['case_id']/'fields.npz') as a,np.load(root/'fresh'/x['case_id']/'fields.npz') as b:
    for k in a.files:self.assertTrue(np.array_equal(a[k],b[k]),k)
 def test_extracted_kernel_matches_frozen_conservation_samples(self):
  # Small reference only: 64 nodes, T=.4. No complete scientific preset.
  c=self.ctx;C=c['C'];M=c['M1'];K=c['K'];B,LZ,BB,PC,CC=modules();T=.4
  old=BB.conservacao(C,M,K,T,32,False);step,_=original_step();Q=C.onda_aresta(PC.kvec((0,0,1)),np.array([1,-1j,0]));q=Q.real.copy();v,_=c['cleaner'].limpar(np.linalg.norm(PC.kvec((0,0,1)))*Q.imag);a=-c['lu'].solve(K@q);dt=c['dt_original'];ns=round(T/dt);H0=.5*v@(M@v)+.5*q@(K@q);measured=[]
  for i in range(ns+1):
   if i%max(1,ns//40)==0:measured.append((.5*v@(M@v)+.5*q@(K@q))/H0-1)
   if i<ns:q,v,a=step(q,v,a,dt,c['lu'],K)
  self.assertTrue(np.array_equal(np.asarray(measured),np.array(old['V1']['serie'])[:,1]))
