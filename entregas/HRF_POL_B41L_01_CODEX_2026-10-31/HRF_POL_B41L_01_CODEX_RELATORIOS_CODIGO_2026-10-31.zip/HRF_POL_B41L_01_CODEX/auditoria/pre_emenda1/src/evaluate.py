"""[D/M] Gates sem promoção de controle Jones a resultado relacional."""
import json
from pathlib import Path
import numpy as np
from common import ROOT,clean,verify_dependency,verify_freeze
from stokes import stokes,distance,fit_windows,STATES

def criteria():return json.loads((ROOT/'configs/criterios.json').read_text())
def analyze(data,case,metadata,g):
 t=data['times'];signals=data['electric_regions'];w=data['region_volumes'];omega=metadata['omega']
 target=stokes(STATES[case['state']]);null=target['s'] is None
 windows=fit_windows(t,signals[:,:,:2],omega,w,3.)
 initial=stokes(data['initial_phasor'],w)
 gauge=metadata['gauge'];energy=data['energy'];gauss=data['gauss_abs'];scale=max(float(np.max(data['pi_norm'])),1e-25)
 gauss0=float(gauss[0]/scale);gauss_variation=float(np.max(abs(gauss-gauss[0]))/scale)
 driftE=float(np.max(abs(energy-energy[0]))/max(abs(energy[0]),1e-25))
 # Shape of initial phases is measured from q/v; never copied from target Jones.
 prep=distance(initial,target)
 output=dict(case=case,source='actual B41L edge evolution, Whitney fields',initial=initial,windows=windows,
  gauss0=gauss0,gauss_variation=gauss_variation,energy_drift=driftE,conventions=metadata['conventions'],G1='PENDING',
  reason_G1='POL-01/P01-P05 originals not supplied; independent new Jones diagnostics only')
 if null:
  valid=float(np.max(abs(signals)))<=1e-20 and np.max(abs(energy))<=1e-24
  output.update(G2='PASS' if valid else 'FAIL',G3='PASS' if valid else 'FAIL',G4='PASS' if valid else 'FAIL',G6='PASS' if valid else 'FAIL',classification='UNDEFINED_ZERO_INTENSITY',no_polarization_claim=True)
  return clean(output)
 resolved=[r for r in windows if r['fit_status']=='RESOLVED' and r['s'] is not None]
 G2=gauss0<=g['gauss_max'] and prep is not None and prep<=g['preparation_stokes_max'] and initial['degree']>=g['initial_degree_min']
 output['G2']='PASS' if G2 else 'FAIL'
 if not resolved:output.update(G3='PENDING',G4='PENDING',G6='PENDING',reason='nenhuma janela temporal resolvida');return clean(output)
 sensitivity=0.
 for cycle in g['phase_window_cycles']:
  alt=fit_windows(t,signals[:,:,:2],omega,w,cycle)
  # Compare simultaneous window centers; interpolate measured normalized Stokes, no renormalization of fields.
  alt=[r for r in alt if r['s'] is not None]
  if not alt:sensitivity=np.inf;continue
  tt=np.array([(r['t_start']+r['t_end'])/2 for r in alt]);ss=np.array([r['s'] for r in alt])
  for r in resolved:
   mid=(r['t_start']+r['t_end'])/2
   if tt[0]<=mid<=tt[-1]:sensitivity=max(sensitivity,float(np.linalg.norm(np.array([np.interp(mid,tt,ss[:,i]) for i in range(3)])-r['s'])))
 longitudinal=float(np.sum(abs(signals[:,:,2])**2*w[None])/max(np.sum(abs(signals)**2*w[None,:,None]),1e-25))
 map_good=max(gauge['E_relative'],gauge['B_relative'])<=g['gauge_max'] and max(r['residual'] for r in resolved)<=g['fit_residual_max'] and sensitivity<=g['window_sensitivity_max'] and longitudinal<=g['longitudinal_fraction_max']
 S=np.array([r['S'] for r in resolved]);ss=np.array([r['s'] for r in resolved]);degrees=np.array([r['degree'] for r in resolved])
 driftS=float(np.max(np.linalg.norm(ss-ss[0],axis=1)));distance_ref=float(np.max(np.linalg.norm(ss-target['s'],axis=1)))
 driftI=float(np.max(abs(S[:,0]/S[0,0]-1)));driftD=float(np.max(abs(degrees-degrees[0])))
 phases=[r['relative_phase'] for r in resolved];phase_drift=None
 if all(p is not None for p in phases):phase_drift=float(np.max(abs(np.unwrap(phases)-phases[0])))
 phasegood=phase_drift is None or phase_drift<=g['relative_phase_drift_max']
 propagation=driftS<=g['stokes_drift_max'] and driftI<=g['intensity_drift_max'] and driftD<=g['degree_change_max'] and driftE<=g['energy_drift_max'] and gauss_variation<=g['gauss_max'] and phasegood
 output.update(G3='PASS' if map_good else 'FAIL',G4=('PASS' if propagation else 'FAIL') if map_good else 'PENDING',
  G6=('PASS' if distance_ref<=g['maxwell_stokes_max'] else 'FAIL') if map_good and G2 and propagation else 'PENDING',
  stokes_drift=driftS,maxwell_stokes_error=distance_ref,intensity_drift=driftI,degree_change=driftD,relative_phase_drift=phase_drift,
  window_sensitivity=sensitivity,longitudinal_power_fraction=longitudinal,
  helicity_convention='S3/S0 operacional, nao spin quantico; sinal referido a (ea,eb,k)',
  opposite_helicity_fraction=((1-np.sign(target['s'][2])*ss[:,2])/2 if abs(target['s'][2])>.999 else None))
 return clean(output)

def aggregate(folder,c,g):
 from planning import cases
 from scipy.stats import beta
 verify_dependency();verify_freeze()
 expected=list(cases(c));rows=[];missing=[]
 for x in expected:
  p=Path(folder)/x['case_id']/'evaluation.json'
  if not p.exists():missing.append(x['case_id'])
  else:
   from runner import valid_completion,identity
   if not valid_completion(p.parent,identity(c,x)):missing.append(x['case_id'])
   else:rows.append(json.loads(p.read_text()))
 primary=[r for r in rows if r['case']['variant']=='V1' and r['case']['dt_scale']==1.]
 overall={k:('NOT_EXECUTED' if not rows else 'PENDING') for k in ('G2','G3','G4','G5','G6','G7')}
 # Rates per seed, not correlated state/window counts as independent trials.
 rates=[]
 for n in c['grid_order']:
  valid=[r for r in primary if r['case']['n']==n];bad=[]
  for seed in c['seeds']:
   rs=[r for r in valid if r['case']['seed']==seed]
   count=len(c['directions'])*len(c['states'])
   if len(rs)==count:bad.append(any(any(r[k]!='PASS' for k in ('G2','G3','G4','G6')) for r in rs))
  if bad:
   f=sum(bad);N=len(bad);lo=0 if f==0 else beta.ppf(.025,f,N-f+1);hi=1 if f==N else beta.ppf(.975,f+1,N-f)
   rates.append(dict(n=n,seeds=N,failures=f,Clopper_Pearson95=[float(lo),float(hi)]))
 spatial_order=None;temporal=[];temporal_intensity=[]
 if not missing and primary:
  for k in ('G2','G3','G4','G6'):overall[k]='PASS' if all(r[k]=='PASS' for r in primary if r['case']['n']==max(c['grid_order'])) else ('FAIL' if any(r[k]=='FAIL' for r in primary if r['case']['n']==max(c['grid_order'])) else 'PENDING')
  errors=[]
  for n in c['grid_order']:
   e=[r.get('maxwell_stokes_error') for r in primary if r['case']['n']==n and r['case']['state']!='nulo']
   if e and all(v is not None for v in e):errors.append(float(np.sqrt(np.mean(np.array(e)**2))))
  if len(errors)>=3 and all(e>0 for e in errors):spatial_order=float(np.polyfit(np.log(4/np.array(c['grid_order'])),np.log(errors),1)[0])
  for r in rows:
   if r['case']['variant']!='V1' or r['case']['dt_scale']!=.5:continue
   key={k:v for k,v in r['case'].items() if k not in ('case_id','dt_scale')}
   coarse=next((a for a in primary if all(a['case'][k]==v for k,v in key.items())),None)
   if coarse and r['windows'] and coarse['windows']:
    sa=[w['s'] for w in r['windows'] if w['s'] is not None];sb=[w['s'] for w in coarse['windows'] if w['s'] is not None]
    if sa and sb:
     temporal.append(float(np.linalg.norm(np.asarray(sa).mean(0)-np.asarray(sb).mean(0))))
     ia=np.mean([w['S'][0] for w in r['windows'] if w['s'] is not None]);ib=np.mean([w['S'][0] for w in coarse['windows'] if w['s'] is not None]);temporal_intensity.append(float(abs(ia/ib-1)))
  fine_rate=next((r for r in rates if r['n']==max(c['grid_order'])),None)
  sufficient=spatial_order is not None and spatial_order>=g['spatial_order_min'] and fine_rate and fine_rate['Clopper_Pearson95'][1]<=g['failure_rate_upper_max'] and temporal and max(temporal)<=g['temporal_stokes_max'] and max(temporal_intensity)<=g['temporal_intensity_max']
  overall['G5']='PASS' if sufficient else ('FAIL' if c['id']=='completo' else 'PENDING')
 # G1 cannot pass without original P01-P05. No positive global verdict can bypass it.
 overall['G7']='PENDING' if rows else 'NOT_EXECUTED'
 return dict(status='NOT_EXECUTED' if not rows else ('SMOKE_ONLY' if c['id']=='fumaca' else 'EVALUATED'),G0='PASS',G1='PENDING',**overall,
  expected=len(expected),completed=len(rows),missing=missing,seed_failure_rates=rates,spatial_order=spatial_order,temporal_stokes_differences=temporal,temporal_intensity_relative_differences=temporal_intensity,
  scientific_success=False,reason='P01-P05 original indisponivel; G7 nao pode receber PASS',historical_verdicts_unchanged=True)
