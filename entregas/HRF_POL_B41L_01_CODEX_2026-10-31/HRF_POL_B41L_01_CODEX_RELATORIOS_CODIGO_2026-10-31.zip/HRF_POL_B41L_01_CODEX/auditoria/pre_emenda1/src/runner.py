"""[M] Evolução real B41L, com kernel congelado e checkpoints por caso."""
from pathlib import Path
import json,math,time,os,sys,platform,importlib.metadata
from datetime import datetime,timezone
import numpy as np
from common import ROOT,atomic_json,atomic_npz,sha,code_hash,verify_dependency,verify_freeze
from dependency import context,prepare,original_step
from observable import Observer
from stokes import STATES
from evaluate import analyze,criteria,aggregate
from planning import cases

def identity(c,x):
 return __import__('hashlib').sha256(json.dumps(dict(config=c,case=x,code_sha=code_hash()),sort_keys=True).encode()).hexdigest()
def valid_completion(folder,rid):
 p=folder/'COMPLETED.json'
 if not p.exists():return False
 seal=json.loads(p.read_text())
 if seal['run_id']!=rid:raise ValueError('saída pertence a outra versão')
 for name,h in seal['files'].items():
  if sha(folder/name)!=h:raise ValueError('arquivo concluído corrompido: '+name)
 return True

def run_case(c,x,out,ctx):
 folder=Path(out)/x['case_id'];folder.mkdir(parents=True,exist_ok=True);rid=identity(c,x)
 if valid_completion(folder,rid):return json.loads((folder/'evaluation.json').read_text())
 meta_path=folder/'run.json'
 if meta_path.exists() and json.loads(meta_path.read_text())['run_id']!=rid:raise ValueError('Use outra pasta após mudar código/configuração')
 q,v,prep=prepare(ctx,x['direction'],STATES[x['state']],x['variant'],c['amplitude']);C=ctx['C'];K=ctx['K'];M=ctx['M1']
 dt=float(ctx['dt_original']*x['dt_scale']);T=c['periods']*2*np.pi/prep['omega'];steps=round(T/dt)
 if steps+1>c['limits']['max_frames']:raise MemoryError('BLOCKED_RESOURCES: número de frames excede teto, sem downsampling silencioso')
 if steps*C.E*300>c['limits']['max_operations_per_case']:raise MemoryError('BLOCKED_RESOURCES: operações excedem teto')
 observer=Observer(ctx,prep['k'],prep['ea'],prep['eb']);initial_phasor=observer.initial_phasor(q,v,prep['omega']);gauge=observer.gauge_test(q,v)
 step,kernel_hash=original_step();start=0;frames=[];snapshots=[];snapshot_times=[];snapshot_stride=max(1,steps//(c['raw_snapshot_target']-1))
 a=-ctx['lu'].solve(K@q);cp=folder/'checkpoint.npz'
 metadata=dict(status='RUNNING',run_id=rid,case=x,dt=dt,steps=steps,target_T=T,actual_T=steps*dt,omega=float(prep['omega']),k=prep['k'],ea=prep['ea'],eb=prep['eb'],gauge=gauge,
  original_kernel_AST_sha256=kernel_hash,nodes=C.N,edges=C.E,tetrahedra=C.T,conventions='exp(+ik.x-iwt); base LZ.base_transversal, ea x eb = kh; E=-Wv; H não significa eixo x global',
  timestamp_UTC=datetime.now(timezone.utc).isoformat(),code_sha256=code_hash(),environment=dict(python=sys.version,numpy=np.__version__,scipy=importlib.metadata.version('scipy'),platform=platform.platform()),
  max_initial_face_circulation=float(np.max(abs(C.d1@q))),dynamics='frozen quadratic Wilson limit M1 qdd=-Kq; no nonlinear cosine run')
 atomic_json(meta_path,metadata)
 if cp.exists():
  with np.load(cp,allow_pickle=False) as z:
   if str(z['run_id'])!=rid:raise ValueError('checkpoint de outra versão')
   q=z['q'].copy();v=z['v'].copy();a=z['a'].copy();start=int(z['next_step']);snapshots=list(z['snapshots']);snapshot_times=list(z['snapshot_times'])
   frames=[(float(z['times'][i]),z['electric_regions'][i].copy(),float(z['energy'][i]),float(z['gauss_abs'][i]),float(z['pi_norm'][i]),z['momentum'][i].copy()) for i in range(len(z['times']))]
 def arrays():
  return dict(times=np.array([f[0] for f in frames]),electric_regions=np.array([f[1] for f in frames]),energy=np.array([f[2] for f in frames]),gauss_abs=np.array([f[3] for f in frames]),pi_norm=np.array([f[4] for f in frames]),momentum=np.array([f[5] for f in frames]),region_volumes=observer.weights,initial_phasor=initial_phasor,
   snapshots=np.asarray(snapshots),snapshot_times=np.array(snapshot_times))
 try:
  for i in range(start,steps+1):
   electric,H,gauss,pnorm,P=observer.sample(q,v);frames.append((i*dt,electric,H,gauss,pnorm,P))
   if i%snapshot_stride==0 or i==steps:snapshots.append(np.stack([q,v]));snapshot_times.append(i*dt)
   if i==steps:break
   q,v,a=step(q,v,a,dt,ctx['lu'],K)
   if not np.isfinite(q).all() or not np.isfinite(v).all():raise FloatingPointError('estado não finito')
   if (i+1)%c['checkpoint_steps']==0:atomic_npz(cp,run_id=rid,q=q,v=v,a=a,next_step=i+1,**arrays())
  data=arrays();atomic_npz(folder/'fields.npz',**data)
  evaluation=analyze(data,x,metadata,criteria());atomic_json(folder/'evaluation.json',evaluation)
  metadata.update(status='COMPLETED',completed_UTC=datetime.now(timezone.utc).isoformat());atomic_json(meta_path,metadata)
  atomic_json(folder/'COMPLETED.json',dict(status='COMPLETED',run_id=rid,files={n:sha(folder/n) for n in ('run.json','fields.npz','evaluation.json')}));cp.unlink(missing_ok=True)
  return evaluation
 except BaseException as exc:
  metadata.update(status='INTERRUPTED' if isinstance(exc,(KeyboardInterrupt,SystemExit)) else 'FAILED',error=type(exc).__name__+': '+str(exc));atomic_json(meta_path,metadata);raise

def run(c,out,full_confirmed=False,case_id=None):
 verify_dependency();verify_freeze()
 if c['id']=='completo':
  import importlib.util
  colab=bool(os.environ.get('COLAB_RELEASE_TAG'))
  try:colab=colab or importlib.util.find_spec('google.colab') is not None
  except ModuleNotFoundError:pass
  if not full_confirmed or not colab:raise PermissionError('Rodada completa somente após CONFIRMO_COMPLETA=True no Colab')
 out=Path(out);out.mkdir(parents=True,exist_ok=True);ctx=None;key=None;done=[]
 from planning import plan
 selected=[x for x in cases(c) if case_id is None or x['case_id']==case_id]
 if not selected:raise ValueError('caso inexistente')
 for x in selected:
  # Check per-case memory/disk before building a mesh. The family may be run in independent sessions.
  predicted=plan(c,out)
  memory=2_000_000*x['n']**3+256*2**20
  import shutil
  if memory>c['limits']['memory_bytes'] or predicted['case_output_bound_bytes']+c['limits']['reserve_disk_bytes']>shutil.disk_usage(out).free:raise MemoryError('BLOCKED_RESOURCES antes da malha')
  try:
   from common import available_memory
   if memory>available_memory():raise MemoryError('BLOCKED_RESOURCES: RAM livre insuficiente')
  except ImportError:pass
  nextkey=(x['seed'],x['n'])
  if nextkey!=key:
   if ctx is not None:del ctx
   ctx=context(x['seed'],c['grid_order'],x['n']);key=nextkey
  result=run_case(c,x,out,ctx);done.append(x['case_id']);print(x['case_id'],result['G2'],result['G3'],result['G4'],flush=True)
 atomic_json(out/'summary.json',aggregate(out,c,criteria()));verify_dependency()
 return done
