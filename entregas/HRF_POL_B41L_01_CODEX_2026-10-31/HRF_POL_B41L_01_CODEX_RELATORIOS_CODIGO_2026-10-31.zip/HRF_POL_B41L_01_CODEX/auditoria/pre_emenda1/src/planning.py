"""[D] Planejamento sem malha nem importação do solver."""
from pathlib import Path
import json,shutil
from common import ROOT

def config(name):
 p=Path(name)
 if not p.is_file():p=ROOT/'configs'/f'{name}.json'
 c=json.loads(p.read_text())
 if c['status']!='NOT_EXECUTED':raise ValueError('estado do preset deve permanecer NOT_EXECUTED')
 if not all(3<=n<=30 for n in c['grid_order']):raise ValueError('malhas fora do plano')
 return c

def cases(c):
 for seed in c['seeds']:
  for n in c['grid_order']:
   for direction in c['directions']:
    for state in c['states']:
     for variant in c['variants']:
      scales=[1.,.5] if c['temporal_refinement'] and n==max(c['grid_order']) else [1.]
      for scale in scales:
       label=''.join(str(v).replace('-','m') for v in direction)
       yield dict(seed=seed,n=n,direction=direction,state=state,variant=variant,dt_scale=scale,
        case_id=f's{seed}_n{n}_k{label}_{state.replace("+","p").replace("-","m")}_{variant}_dt{str(scale).replace(".","p")}')

def plan(c,output):
 count=sum(1 for _ in cases(c));n=max(c['grid_order']);memory=2_000_000*n**3+256*2**20
 # Bound uses maximum frame admission rather than an uncalibrated wall-time promise.
 disk_case=c['limits']['max_frames']*(8*3*16+8*8)+1200*n**3+2**20
 disk=count*disk_case;probe=Path(output).resolve()
 while not probe.exists():probe=probe.parent
 reasons=[]
 if memory>c['limits']['memory_bytes']:reasons.append('RAM estimada acima do teto')
 if disk>c['limits']['disk_bytes']:reasons.append('disco da familia acima do teto')
 if disk+c['limits']['reserve_disk_bytes']>shutil.disk_usage(probe).free:reasons.append('disco livre real insuficiente para a familia inteira')
 return dict(status='BLOCKED_RESOURCES' if reasons else 'PLANNED_NOT_EXECUTED',cases=count,peak_RAM_bytes=memory,
  uncompressed_output_bound_bytes=disk,case_output_bound_bytes=disk_case,reasons=reasons,workers=1,
  CPU_seconds=None,CPU_note='sem extrapolacao de tempo; solve esparso depende da malha e das lascas',new_integrations=0)
