# Emenda de execução Codex 0.1.3 — antes da rodada completa

[D] Mario autorizou explicitamente nesta conversa a execução completa neste servidor Codex, simultaneamente em quatro CPUs. Essa autorização substitui a restrição operacional anterior de executar somente após confirmação no Colab. A cópia distribuída anteriormente permanece preservada em /workspace/HRF_POL_B41L_01 e no ZIP 0.1.2. Esta nova cópia é independente.

[D] Nenhum arquivo em src/, nenhuma configuração científica e nenhum arquivo da dependência B41L foi alterado. As malhas, as sementes, os 2.400 casos, o passo temporal, os controles, os limites científicos e as tolerâncias são os mesmos. O novo scripts/rodar_codex_parallel.py usa run_case e context originais do adaptador congelado, sem fingir que o ambiente é Colab. A entrada anterior continua com sua proteção própria.

[D] Quatro processos Python independentes, cada qual com BLAS/OMP/MKL/NUMEXPR limitados a uma thread. Cada grupo semente/malha é exclusivo de um processo, preservando a construção histórica da malha e reutilizando suas fatorações. Sementes/grupos são distribuídos por custo previsto. Os arquivos de casos têm a mesma identidade e os mesmos selos da versão numérica anterior. Não há escrita concorrente no mesmo caso.

[D] A RAM do servidor não é aumentada: o escalonador admite quatro processos somente se houver memória livre para quatro estimativas conservadoras de pico e reserva de 2 GiB. A cota observada é 32 GiB. O orçamento por maior malha é 5.268.435.456 bytes. O novo escalonador não aumenta essa cota.

[D] A estimativa anterior de disco multiplicava o máximo admissível de 40.961 frames por todos os casos. O novo plan monta as malhas e calcula seus dt, dimensões e número exato de passos, sem evoluir o campo. Faz a admissão com o tamanho real dos arrays, um fator 1,25, mais 1 MiB por caso para metadados, espaço para checkpoints atômicos simultâneos e reserva adicional de 4 GiB. A compressão permanece sem perda e todos os dados científicos previstos são gravados. Nenhum downsampling ou remoção de caso foi introduzido.

[D] O plano e seus hashes são registrados antes das integrações. Falhas de infraestrutura ficam registradas; casos que não completarem continuam ausentes na avaliação. Um FAIL científico não é tratado como falha do processo e não é corrigido por ajuste de tolerância. Checkpoints são retomados somente com identidade e integridade compatíveis.

[?] O G3 da fumaça anterior continua FAIL e o POL-01 original permanece ausente. A rodada completa medirá o desempenho nos refinamentos pré-registrados. G1 continua PENDING e G7 não poderá receber PASS enquanto faltar essa dependência. Nenhum veredito histórico é reclassificado.

```bash
python -I scripts/rodar_codex_parallel.py plan --workers 4 --output resultados/completo_codex
python -I scripts/rodar_codex_parallel.py run --workers 4 --output resultados/completo_codex --executar --confirmo-codex
```
