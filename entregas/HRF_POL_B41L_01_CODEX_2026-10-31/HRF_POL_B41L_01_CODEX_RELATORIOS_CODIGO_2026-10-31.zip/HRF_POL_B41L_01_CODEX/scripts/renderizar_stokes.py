"""[M] Correção visual: todos os pontos medidos aparecem, inclusive janela única.

Somente leitura de evaluation.json. Nenhuma evolução, reavaliação ou mudança de gate.
"""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

def render_stokes(folder, output):
    folder, output = Path(folder), Path(output)
    rows = [json.loads(p.read_text()) for p in sorted(folder.glob('*/evaluation.json'))]
    selected = [r for r in rows if r['case']['variant']=='V1' and r['case']['state']!='nulo'][:8]
    fig, axs = plt.subplots(2,2,figsize=(12,8))
    points = {}
    for row in selected:
        windows = [w for w in row['windows'] if w['s'] is not None]
        if not windows:
            continue
        t = np.array([(w['t_start']+w['t_end'])/2 for w in windows])
        values = np.array([w['s'] for w in windows])
        label = row['case']['case_id']
        points[label] = len(t)
        for i in range(3):
            axs.flat[i].plot(t,values[:,i],'o-',markersize=5,label=label)
        S0 = np.array([w['S'][0] for w in windows])
        axs.flat[3].plot(t,S0/S0[0],'o-',markersize=5,label=label)
    for ax, name in zip(axs.flat,['S1/S0','S2/S0','S3/S0','S0/S0(primeira janela)']):
        ax.set(xlabel='t B41L (centro da janela)',ylabel=name)
        ax.grid(alpha=.3)
    if points:
        axs[0,0].legend(fontsize=5)
    fig.suptitle('[M] Stokes medidos; pontos mostram janelas; fumaça não certifica física')
    fig.tight_layout()
    output.mkdir(parents=True,exist_ok=True)
    fig.savefig(output/'01_stokes.png',dpi=140)
    plt.close(fig)
    (output/'correcao_visual.json').write_text(json.dumps(dict(status='VISUAL_ONLY',points_per_case=points,PDE_runs=0,gates_changed=False),indent=2)+'\n')
    return points
