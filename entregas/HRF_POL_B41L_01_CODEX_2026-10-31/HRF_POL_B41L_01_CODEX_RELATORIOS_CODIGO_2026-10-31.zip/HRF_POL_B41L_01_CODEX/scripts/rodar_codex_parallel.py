"""Execução Codex autorizada: processos independentes, dinâmica B41L inalterada.

Sem integração em importação ou em plan. run exige duas opções explícitas.
O entrypoint Colab anterior e todos os src/configs permanecem congelados.
"""
import os
import sys
from pathlib import Path
for _name in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS', 'NUMEXPR_NUM_THREADS'):
    os.environ[_name] = '1'
sys.dont_write_bytecode = True
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))

import argparse
import concurrent.futures as cf
import contextlib
from datetime import datetime, timezone
import hashlib
import json
import math
import multiprocessing as mp
import shutil
import time
import traceback

from common import atomic_json, code_hash, sha, verify_dependency, verify_freeze, available_memory
from planning import config, cases

def utc():
    return datetime.now(timezone.utc).isoformat()

def signature():
    return dict(numerical_code_sha256=code_hash(), configuration_sha256=sha(ROOT/'configs/completo.json'),
                criteria_sha256=sha(ROOT/'configs/criterios.json'),
                orchestrator_sha256=sha(__file__), freeze_sha256=sha(ROOT/'HASHES_PREREGISTRO.txt'))

def groups(c):
    result = {}
    for x in cases(c):
        result.setdefault((x['seed'], x['n']), []).append(x)
    return [(key, xs) for key, xs in sorted(result.items())]

def storage_bound(steps, edges, target):
    if steps < 1 or edges < 1 or target < 2:
        raise ValueError('dimensões inválidas')
    stride = max(1, steps // (target-1))
    snapshots = steps // stride + 1 + int(steps % stride != 0)
    # Actual arrays: t,E_regions,H,Gauss,pi_norm,P,delta_Gauss plus q/v snapshots.
    raw = (steps+1)*448 + snapshots*(16*edges+8) + 320
    # Conservative lossless ZIP overhead and <=1 MiB for case JSON/NPZ headers.
    return math.ceil(raw * 1.25) + 2**20

def inspect_group(payload):
    c, key, xs = payload
    from dependency import context
    import numpy as np
    started = time.monotonic()
    ctx = context(key[0], c['grid_order'], key[1])
    C = ctx['C']
    bounds = []
    for x in xs:
        omega = float(np.linalg.norm(ctx['PC'].kvec(x['direction'])))
        steps = round((c['periods']*2*math.pi/omega)/(ctx['dt_original']*x['dt_scale']))
        reason = None
        if steps+1 > c['limits']['max_frames']:
            reason = 'max_frames'
        if steps*C.E*300 > c['limits']['max_operations_per_case']:
            reason = 'max_operations_per_case'
        bounds.append(dict(case_id=x['case_id'], steps=steps,
                           disk_bytes=storage_bound(steps,C.E,c['raw_snapshot_target']), blocked=reason))
    return dict(seed=key[0], n=key[1], nodes=C.N, edges=C.E, tetrahedra=C.T,
                dt_original=float(ctx['dt_original']), cases=bounds,
                preparation_seconds=time.monotonic()-started,
                RAM_bound_bytes=5_000_000*key[1]**3+256*2**20,
                work_weight=sum(b['steps']*C.E for b in bounds))

def admission(plan, workers, free_disk, free_ram):
    if workers < 1 or workers > 4:
        raise ValueError('de 1 a 4 processos')
    ram = workers*max(g['RAM_bound_bytes'] for g in plan['groups']) + 2*2**30
    # Include simultaneous old/new atomic checkpoints, temporary fields, metadata and archive reserve.
    peak_disk = (sum(b['disk_bytes'] for g in plan['groups'] for b in g['cases'])
                 + 4*workers*max(b['disk_bytes'] for g in plan['groups'] for b in g['cases'])
                 + 4*2**30)
    reasons = []
    if ram > free_ram:
        reasons.append('RAM livre insuficiente para os processos e reserva de 2 GiB')
    if peak_disk > free_disk:
        reasons.append('disco livre insuficiente para bound pelas malhas reais e reserva de 4 GiB')
    blocked = [b for g in plan['groups'] for b in g['cases'] if b['blocked']]
    if blocked:
        reasons.append('casos excedem limites científicos congelados')
    return dict(status='BLOCKED_RESOURCES' if reasons else 'ADMITTED', workers=workers,
                RAM_total_bound_bytes=ram, disk_total_bound_bytes=peak_disk,
                free_RAM_bytes=free_ram, free_disk_bytes=free_disk, reasons=reasons,
                cases_exceeding_limits=blocked)

def make_plan(out, workers):
    verify_dependency(); verify_freeze()
    c = config('completo')
    out.mkdir(parents=True, exist_ok=True)
    payloads = [(c, key, xs) for key, xs in groups(c)]
    with cf.ProcessPoolExecutor(max_workers=workers, mp_context=mp.get_context('spawn')) as pool:
        inspected = list(pool.map(inspect_group, payloads))
    result = dict(status='PREPARED_NOT_INTEGRATED', created_UTC=utc(), signature=signature(),
                  expected=sum(len(g['cases']) for g in inspected), groups=inspected, new_integrations=0)
    result['admission'] = admission(result, workers, shutil.disk_usage(out).free, available_memory())
    atomic_json(out/'plan_codex.json', result)
    atomic_json(out/'plan_codex.sha256.json', dict(sha256=sha(out/'plan_codex.json')))
    print(json.dumps(dict(plan=str(out/'plan_codex.json'), expected=result['expected'], **result['admission'])), flush=True)
    return result

def load_plan(out, workers):
    p = out/'plan_codex.json'
    expected = json.loads((out/'plan_codex.sha256.json').read_text())['sha256']
    if sha(p) != expected:
        raise ValueError('plano de recursos alterado')
    result = json.loads(p.read_text())
    if result['signature'] != signature():
        raise ValueError('plano pertence a outra versão; refazer admissão em pasta nova')
    result['admission'] = admission(result, workers, shutil.disk_usage(out).free, available_memory())
    if result['admission']['status'] != 'ADMITTED':
        raise MemoryError(json.dumps(result['admission']))
    return result

def execute_group(payload):
    c, key, xs, output = payload
    out = Path(output); progress = out/'progresso'/f'{key[0]}_{key[1]}.json'
    log = out/'logs'/f'{key[0]}_{key[1]}.log'; log.parent.mkdir(exist_ok=True)
    from runner import run_case, identity, valid_completion
    from dependency import context
    done = []; errors = []; ctx = None; started = time.monotonic()
    with log.open('a', buffering=1) as stream, contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
        verify_dependency(); verify_freeze()
        for x in xs:
            try:
                if valid_completion(out/x['case_id'], identity(c,x)):
                    done.append(x['case_id'])
                else:
                    if ctx is None:
                        ctx = context(key[0],c['grid_order'],key[1])
                    result = run_case(c,x,out,ctx)
                    done.append(x['case_id'])
                    print(utc(),x['case_id'],result['G2'],result['G3'],result['G4'],flush=True)
            except Exception as error:
                record = dict(case_id=x['case_id'], type=type(error).__name__, error=str(error), timestamp_UTC=utc(), traceback=traceback.format_exc())
                atomic_json(out/x['case_id']/'erro_infraestrutura.json',record)
                errors.append(record)
                print(json.dumps(record),flush=True)
            atomic_json(progress,dict(seed=key[0],n=key[1],pid=os.getpid(),completed=len(done),expected=len(xs),
                         errors=len(errors),status='RUNNING',last_case=x['case_id'],timestamp_UTC=utc()))
        verify_dependency(); verify_freeze()
    result = dict(seed=key[0],n=key[1],completed=len(done),expected=len(xs),errors=errors,
                  seconds=time.monotonic()-started,status='COMPLETED' if not errors else 'COMPLETED_WITH_ERRORS')
    atomic_json(progress,{**result,'pid':os.getpid(),'timestamp_UTC':utc()})
    return result

def progress_snapshot(out, started, workers):
    records = [json.loads(p.read_text()) for p in (out/'progresso').glob('*.json')]
    completed = sum(r['completed'] for r in records)
    elapsed = time.monotonic()-started
    result = dict(status='RUNNING',timestamp_UTC=utc(),completed=completed,expected=2400,workers=workers,
                  elapsed_seconds=elapsed,errors=sum(len(r['errors']) if isinstance(r['errors'],list) else r['errors'] for r in records))
    if completed:
        result['linear_eta_seconds'] = elapsed*(2400-completed)/completed
    atomic_json(out/'RUN_STATUS.json',result)
    return result

def run(out, workers, confirmed):
    if not confirmed:
        raise PermissionError('Exige --executar --confirmo-codex; nenhum solver iniciado')
    verify_dependency(); verify_freeze()
    plan = load_plan(out,workers)
    c = config('completo')
    keys = {(key[0],key[1]):xs for key,xs in groups(c)}
    ordered = sorted(plan['groups'], key=lambda g:g['work_weight'],reverse=True)
    payloads = [(c,(g['seed'],g['n']),keys[(g['seed'],g['n'])],str(out)) for g in ordered]
    (out/'progresso').mkdir(exist_ok=True)
    atomic_json(out/'AUTORIZACAO_EXECUCAO.json',dict(timestamp_UTC=utc(),user_request='Ok, então ajuste para rodar aí mesmo no codex, só ajuste a RAM e rode, consegue rodar simultâneo nos quatro CPUs, por favor?',workers=workers,signature=signature(),Colab_requirement_superseded_by_explicit_user_request=True,scientific_criteria_unchanged=True))
    started=time.monotonic(); results=[]
    with cf.ProcessPoolExecutor(max_workers=workers,mp_context=mp.get_context('spawn')) as pool:
        pending={pool.submit(execute_group,p):p[1] for p in payloads}
        next_print=0.
        while pending:
            done,_ = cf.wait(pending, timeout=5, return_when=cf.FIRST_COMPLETED)
            for future in done:
                key=pending.pop(future)
                try:
                    results.append(future.result())
                except Exception as error:
                    results.append(dict(seed=key[0],n=key[1],status='FAILED_GROUP',error=str(error),traceback=traceback.format_exc()))
            snapshot=progress_snapshot(out,started,workers)
            if time.monotonic()>=next_print:
                print(json.dumps(snapshot),flush=True);next_print=time.monotonic()+60
    from evaluate import aggregate,criteria
    summary=aggregate(out,c,criteria());atomic_json(out/'summary.json',summary)
    verify_dependency();verify_freeze()
    result=dict(status='COMPLETED' if summary['completed']==summary['expected'] else 'COMPLETED_WITH_MISSING_CASES',
                timestamp_UTC=utc(),elapsed_seconds=time.monotonic()-started,workers=workers,
                completed=summary['completed'],expected=summary['expected'],groups=results,signature=signature())
    atomic_json(out/'RUN_STATUS.json',result)
    print(json.dumps(result),flush=True)
    return 0 if summary['completed']==summary['expected'] else 2

def main(argv=None):
    parser=argparse.ArgumentParser()
    parser.add_argument('command',choices=['plan','run'])
    parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--workers',type=int,choices=range(1,5),default=4)
    parser.add_argument('--executar',action='store_true')
    parser.add_argument('--confirmo-codex',action='store_true')
    a=parser.parse_args(argv)
    if a.command=='plan':
        result=make_plan(a.output,a.workers)
        return 0 if result['admission']['status']=='ADMITTED' else 2
    return run(a.output,a.workers,a.executar and a.confirmo_codex)

if __name__=='__main__':
    raise SystemExit(main())
