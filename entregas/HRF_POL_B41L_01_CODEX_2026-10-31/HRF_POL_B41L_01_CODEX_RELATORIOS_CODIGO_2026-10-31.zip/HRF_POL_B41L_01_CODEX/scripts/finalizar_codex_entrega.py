"""Finalização pós-cálculo: só lê resultados; nenhuma integração ou alteração de gates."""
from pathlib import Path
import os,sys,json,time,hashlib,zipfile,io,csv,subprocess,shutil,tempfile,uuid,urllib.request,traceback
from datetime import datetime,timezone
ROOT=Path('/workspace/HRF_POL_B41L_01_CODEX');OUT=ROOT/'resultados/completo_codex'
PYTHON='/workspace/my-ai-workflow/.venv/bin/python3';REPO=Path('/workspace/my-ai-workflow')
os.environ['MPLCONFIGDIR']='/tmp/hrf-pol-mpl';os.environ['XDG_CACHE_HOME']='/tmp/hrf-pol-cache'
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
sys.path.insert(0,str(ROOT/'src'))
from common import atomic_json,sha,verify_dependency,verify_freeze

def command(args,**kw):
 return subprocess.check_output([str(s) for s in args],text=True,**kw).strip()

def remote_verify(url,path):
 h=hashlib.sha256();size=0
 with urllib.request.urlopen(url,timeout=120) as response:
  assert response.status==200
  for b in iter(lambda:response.read(2**20),b''):h.update(b);size+=len(b)
 assert size==path.stat().st_size and h.hexdigest()==sha(path)

def publish(light,report,receipt):
 folder='entregas/HRF_POL_B41L_01_CODEX_'+datetime.now(timezone.utc).strftime('%Y-%m-%d')
 branch='downloads-hrf-pol-codex-'+uuid.uuid4().hex[:12]
 with tempfile.TemporaryDirectory(prefix='pol-codex-publish-') as td:
  env=os.environ.copy();env.update(GIT_INDEX_FILE=td+'/index',GIT_AUTHOR_NAME='Codex',GIT_AUTHOR_EMAIL='codex@openai.com',GIT_COMMITTER_NAME='Codex',GIT_COMMITTER_EMAIL='codex@openai.com')
  def git(*args,input=None):return subprocess.check_output(['git','-C',str(REPO),*args],input=input,env=env).decode().strip()
  assert not git('ls-remote','origin','refs/heads/'+branch)
  git('fetch','--quiet','--no-tags','origin','HEAD');parent=git('rev-parse','FETCH_HEAD')
  workflows=git('ls-tree','-r','--name-only',parent,'.github/workflows').splitlines()
  assert set(workflows)=={'.github/workflows/calculos.yml','.github/workflows/quantum.yml'}
  for name in workflows:
   body=git('show',parent+':'+name);assert 'branches: [main]' in body and 'create:' not in body
  git('read-tree',parent)
  for p in [light,report,OUT/'summary.json',ROOT/'README_RESULTADOS_CODEX.md']:
   blob=git('hash-object','-w','--stdin',input=p.read_bytes());git('update-index','--add','--cacheinfo',f'100644,{blob},{folder}/{p.name}')
  commit=git('commit-tree',git('write-tree'),'-p',parent,'-m','HRF POL B41L01 Codex: resultados completos, codigo congelado e relatorio fiel')
  receipt.update(branch=branch,commit=commit,publication_status='PREPARED');atomic_json('/workspace/HRF_POL_B41L_01_CODEX_PUBLICACAO.json',receipt)
  git('push','origin',commit+':refs/heads/'+branch)
  base=f'https://raw.githubusercontent.com/GraceKekey/my-ai-workflow/{commit}/{folder}'
  remote_verify(base+'/'+light.name,light);remote_verify(base+'/'+report.name,report)
  receipt.update(summary_zip_url=base+'/'+light.name,report_url=base+'/'+report.name,remote_summary_SHA_verified=True)
  atomic_json('/workspace/HRF_POL_B41L_01_CODEX_PUBLICACAO.json',receipt)
  return commit

def publish_data(full,receipt,commit):
 parts=[];size=1024*2**20
 with full.open('rb') as source:
  index=1
  while True:
   first=source.read(2**20)
   if not first:break
   path=full.with_name(full.name+f'.part{index:03d}')
   assert not path.exists()
   with path.open('xb') as dest:
    dest.write(first);remaining=size-len(first)
    while remaining:
     b=source.read(min(2**20,remaining))
     if not b:break
     dest.write(b);remaining-=len(b)
   parts.append(dict(path=str(path),name=path.name,bytes=path.stat().st_size,sha256=sha(path)));index+=1
 tag='hrf-pol-b41l-01-codex-'+datetime.now(timezone.utc).strftime('%Y%m%d')+'-'+uuid.uuid4().hex[:8]
 notes=Path('/workspace/HRF_POL_B41L_01_CODEX_NOTAS_RELEASE.md')
 notes.write_text('# Dados numéricos HRF-POL-B41L-01\n\nRodada Codex encerrada. Os gates científicos estão no relatório; integridade/execução não significam sucesso físico. B41L congelada e critérios preservados. Os arquivos .part são segmentos binários do ZIP completo, não ZIPs independentes. O programa BAIXAR_DADOS_COMPLETOS.py baixa, verifica SHA-256 e recompõe o ZIP.\n')
 command(['gh','release','create',tag,'--repo','GraceKekey/my-ai-workflow','--target',commit,'--title','HRF POL B41L01 — resultados Codex','--notes-file',notes,'--prerelease'])
 receipt.update(release_tag=tag,data_parts=parts);atomic_json('/workspace/HRF_POL_B41L_01_CODEX_PUBLICACAO.json',receipt)
 base=f'https://github.com/GraceKekey/my-ai-workflow/releases/download/{tag}'
 for part in parts:
  command(['gh','release','upload',tag,part['path'],'--repo','GraceKekey/my-ai-workflow'])
  part['url']=base+'/'+part['name']
 data_manifest=full.with_name('HRF_POL_B41L_01_CODEX_DADOS_MANIFESTO.json')
 data_manifest.write_text(json.dumps(dict(archive_name=full.name,archive_sha256=sha(full),archive_bytes=full.stat().st_size,parts=parts),indent=2)+'\n')
 helper=full.with_name('BAIXAR_DADOS_COMPLETOS.py')
 helper.write_text('''from pathlib import Path
import urllib.request,hashlib,zipfile,json
INFO='''+repr(json.loads(data_manifest.read_text()))+'''
def digest(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1024*1024),b''):h.update(b)
 return h.hexdigest()
for part in INFO['parts']:
 p=Path(part['name'])
 if not p.exists() or digest(p)!=part['sha256']:
  print('Baixando',p,flush=True)
  with urllib.request.urlopen(part['url'],timeout=120) as source,p.with_suffix(p.suffix+'.tmp').open('wb') as dest:
   for b in iter(lambda:source.read(1024*1024),b''):dest.write(b)
  p.with_suffix(p.suffix+'.tmp').replace(p)
 assert p.stat().st_size==part['bytes'] and digest(p)==part['sha256']
final=Path(INFO['archive_name'])
if not final.exists():
 with final.with_suffix('.zip.tmp').open('wb') as dest:
  for part in INFO['parts']:
   with Path(part['name']).open('rb') as source:
    for b in iter(lambda:source.read(1024*1024),b''):dest.write(b)
 final.with_suffix('.zip.tmp').replace(final)
assert final.stat().st_size==INFO['archive_bytes'] and digest(final)==INFO['archive_sha256']
with zipfile.ZipFile(final) as z:assert z.testzip() is None
print('ZIP completo verificado:',final.resolve())
''')
 command(['gh','release','upload',tag,data_manifest,helper,'--repo','GraceKekey/my-ai-workflow'])
 release=json.loads(command(['gh','api',f'repos/GraceKekey/my-ai-workflow/releases/tags/{tag}']))
 assets={a['name']:a for a in release['assets']}
 for p in [Path(a['path']) for a in parts]+[data_manifest,helper]:
  asset=assets[p.name];assert asset['state']=='uploaded' and asset['size']==p.stat().st_size
  if asset.get('digest'):assert asset['digest']=='sha256:'+sha(p)
  else:remote_verify(asset['browser_download_url'],p)
 receipt.update(full_data_parts_verified=True,full_data_download_script_url=base+'/'+helper.name,full_data_manifest_url=base+'/'+data_manifest.name,release_url=release['html_url'])
 atomic_json('/workspace/HRF_POL_B41L_01_CODEX_PUBLICACAO.json',receipt)

def finalize():
 while True:
  try:
   state=json.loads((OUT/'RUN_STATUS.json').read_text())
   if state['status']!='RUNNING':break
  except (FileNotFoundError,json.JSONDecodeError):pass
  time.sleep(15)
 atomic_json(ROOT/'auditoria/FINALIZACAO_CODEX.json',dict(status='RUNNING',started_UTC=datetime.now(timezone.utc).isoformat()))
 for _ in range(25):
  if (ROOT/'auditoria/monitor_resumo_codex.json').exists():break
  time.sleep(1)
 verify_dependency();verify_freeze()
 summary=json.loads((OUT/'summary.json').read_text())
 assert state['completed']==summary['completed']
 assert summary['expected']==2400
 (ROOT/'figuras_codex').mkdir(exist_ok=True)
 command([PYTHON,'-I',ROOT/'scripts/pol.py','figures','--input',OUT,'--output',ROOT/'figuras_codex'])
 rows=[json.loads(p.read_text()) for p in sorted(OUT.glob('*/evaluation.json'))]
 with (ROOT/'resultados_codex_todos_casos.csv').open('w',newline='') as f:
  cols=['case_id','seed','n','state','variant','direction','dt_scale','G2','G3','G4','G6','gauss0','gauss_variation','energy_drift','stokes_drift','maxwell_stokes_error','intensity_drift','degree_change','window_sensitivity','longitudinal_power_fraction','max_fit_residual']
  w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
  for row in rows:
   item={k:row['case'].get(k,row.get(k)) for k in cols};item['max_fit_residual']=max((z['residual'] for z in row.get('windows',[]) if z.get('residual') is not None),default=None);w.writerow(item)
 breakdown=[]
 for n in [6,8,10]:
  for variant in ['V0','V1']:
   selected=[r for r in rows if r['case']['n']==n and r['case']['variant']==variant and r['case']['state']!='nulo' and r['case']['dt_scale']==1]
   breakdown.append(dict(n=n,variant=variant,cases=len(selected),gates={g:{v:sum(r[g]==v for r in selected) for v in ['PASS','FAIL','PENDING']} for g in ['G2','G3','G4','G6']}))
 atomic_json(ROOT/'RESUMO_RESULTADOS_CODEX.json',dict(summary=summary,breakdown=breakdown,run=state))
 elapsed=state['elapsed_seconds']/3600
 lines=['# HRF-POL-B41L-01 — relatório da rodada Codex','', '## Objetivo','', '[M] Avaliar transporte de polarização na dinâmica B41L real, usando o pré-registro e V1 como lançamento principal.','', '## Hipóteses e parâmetros','', '[D] Mesmos 2.400 casos: dez sementes, malhas 6³/8³/10³, três direções, oito polarizações mais fase alterada e nulo, V0/V1, oito períodos e refinamento temporal na maior malha. Nenhuma tolerância ou semente foi alterada.','', '## Protocolo e integridade','', '[D] Execução explicitamente autorizada pelo usuário no Codex em quatro processos, BLAS uma thread por processo. A emenda 03 altera somente o gerenciamento; os dez módulos numéricos, as configurações e a dependência B41L permanecem idênticos à distribuição 0.1.2. Os 43 hashes B41L conferiram antes e depois. Os 28 testes técnicos prévios passaram.','', '## Medidas e resultados','',f'[M] Casos concluídos: {summary["completed"]}/{summary["expected"]}. Tempo de parede: {elapsed:.3f} horas. Estado de execução: {state["status"]}.','', '| Gate | Estado |','|---|---|']
 for gate in ['G0','G1','G2','G3','G4','G5','G6','G7']:lines.append(f'| {gate} | {summary[gate]} |')
 lines+=['','[M] Gates por malha e variante abaixo excluem o nulo e usam dt_scale=1. As falhas não são descartadas. As linhas completas, incluindo controles nulos e dt/2, estão no CSV.','', '| Malha | Variante | Casos | G2 PASS | G3 PASS | G4 PASS | G6 PASS |','|---|---|---:|---:|---:|---:|---:|']
 for r in breakdown:lines.append('| '+str(r['n'])+'³ | '+r['variant']+' | '+str(r['cases'])+' | '+' | '.join(str(r['gates'][g]['PASS']) for g in ['G2','G3','G4','G6'])+' |')
 lines+=['','## Controles e convergência','', '[M] Ordem espacial medida: '+str(summary['spatial_order'])+'. Diferenças temporais e intervalos Clopper–Pearson completos no summary.json. O controle V0 preserva o lançamento original; não recebe limpeza adicional.','', '## Interpretação e limites','', '[?] G1/P01–P05 original continua PENDING porque HRF_3_Bancadas.zip / HRF_3_Execucoes.zip não foram fornecidos. G7 não pode PASS enquanto faltar essa dependência. Nenhum PASS isolado certifica todo o transporte relacional. Falhas de qualidade, conservação ou convergência permanecem no resultado congelado.','', '[F/M] O campo e os Stokes são reconstruídos da evolução real de cochains B41L, não copiados de Jones. Jones prepara/referencia os estados. O modelo usa o limite quadrático Wilson e geometria prescrita periódica; não demonstra fóton individual, origem de U(1), ħ ou holografia. Nenhum veredito histórico B1/B41/B41H/B41L foi reclassificado.','', '[D] Este relatório posterior substitui apenas a indicação de NOT_EXECUTED da nova rodada completa, não reescreve os pré-registros ou relatórios anteriores. Logs, casos, selos e campos originais estão preservados.']
 report=ROOT/'RELATORIO_FINAL_CODEX.md';report.write_text('\n'.join(lines)+'\n')
 (ROOT/'README_RESULTADOS_CODEX.md').write_text('# Resultados Codex\n\nEsta rodada foi executada após autorização explícita. Comece por RELATORIO_FINAL_CODEX.md e RESUMO_RESULTADOS_CODEX.json. Os documentos anteriores indicam o estado histórico em suas datas. A B41L e os critérios permanecem congelados.\n\nO ZIP RELATORIOS_CODIGO inclui código, relatório e metadados de todos os casos; os campos brutos completos ficam no ZIP RESULTADOS_COMPLETOS, também fornecido em partes binárias com programa de download/recomposição.\n')
 shutil.copy2(__file__,ROOT/'scripts/finalizar_codex_entrega.py')
 files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and '__pycache__' not in p.parts and p.suffix!='.pyc' and p.name not in ['MANIFESTO_SHA256.txt','FINALIZACAO_CODEX.json']]
 manifest=''.join(sha(p)+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files)
 (ROOT/'MANIFESTO_SHA256.txt').write_text(manifest)
 stamp=datetime.now(timezone.utc).strftime('%Y-%m-%d')
 full=Path('/workspace')/f'HRF_POL_B41L_01_CODEX_RESULTADOS_COMPLETOS_{stamp}.zip'
 light=Path('/workspace')/f'HRF_POL_B41L_01_CODEX_RELATORIOS_CODIGO_{stamp}.zip'
 assert not full.exists() and not light.exists()
 with zipfile.ZipFile(full,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files+[ROOT/'MANIFESTO_SHA256.txt']:z.write(p,'HRF_POL_B41L_01_CODEX/'+p.relative_to(ROOT).as_posix())
 with zipfile.ZipFile(full) as z:assert z.testzip() is None
 lightfiles=[p for p in files if not (p.name=='fields.npz' and p.is_relative_to(OUT))]
 extra={'MANIFESTO_COMPLETO_SHA256.txt':manifest.encode(),'ESCOPO_ZIP_RELATORIOS.md':b'ZIP de codigo, relatorios e metadados: os fields.npz completos estao no ZIP RESULTADOS_COMPLETOS. O manifesto padrao cobre apenas o conteudo presente; o manifesto completo registra tambem os campos externos.\n'}
 lightmanifest=''.join(sha(p)+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in lightfiles)+''.join(hashlib.sha256(v).hexdigest()+'  '+k+'\n' for k,v in extra.items())
 with zipfile.ZipFile(light,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in lightfiles:z.write(p,'HRF_POL_B41L_01_CODEX/'+p.relative_to(ROOT).as_posix())
  for name,data in extra.items():z.writestr('HRF_POL_B41L_01_CODEX/'+name,data)
  z.writestr('HRF_POL_B41L_01_CODEX/MANIFESTO_SHA256.txt',lightmanifest)
 with zipfile.ZipFile(light) as z:assert z.testzip() is None
 receipt=dict(root=str(ROOT),archive=str(full),archive_sha256=sha(full),archive_bytes=full.stat().st_size,summary_archive=str(light),summary_archive_sha256=sha(light),summary_archive_bytes=light.stat().st_size,completed=summary['completed'],expected=2400,full_wall_hours=elapsed,original_B41L_hashes_verified=43,numerical_source_unchanged=True,ZIP_CRC_verified=True)
 atomic_json('/workspace/HRF_POL_B41L_01_CODEX_ENTREGA.json',receipt)
 commit=publish(light,report,receipt)
 publish_data(full,receipt,commit)
 receipt['publication_status']='VERIFIED';atomic_json('/workspace/HRF_POL_B41L_01_CODEX_PUBLICACAO.json',receipt)
 atomic_json(ROOT/'auditoria/FINALIZACAO_CODEX.json',dict(status='COMPLETED',timestamp_UTC=datetime.now(timezone.utc).isoformat(),receipt='/workspace/HRF_POL_B41L_01_CODEX_PUBLICACAO.json'))
 print(json.dumps(receipt,indent=2),flush=True)

if __name__=='__main__':
 try:finalize()
 except BaseException as error:
  atomic_json(ROOT/'auditoria/FINALIZACAO_CODEX.json',dict(status='FAILED',error=str(error),traceback=traceback.format_exc(),timestamp_UTC=datetime.now(timezone.utc).isoformat()))
  raise
