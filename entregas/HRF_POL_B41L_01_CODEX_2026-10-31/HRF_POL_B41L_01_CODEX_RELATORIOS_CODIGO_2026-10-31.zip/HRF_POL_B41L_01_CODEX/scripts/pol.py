"""Entrada isolada, sem integração automática."""
import os,sys,tempfile
from pathlib import Path
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1';sys.dont_write_bytecode=True
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'hrf-pol-mpl'));os.environ.setdefault('XDG_CACHE_HOME',str(Path(tempfile.gettempdir())/'hrf-pol-cache'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from cli import main
if __name__=='__main__':
 result=main()
 if result==0 and len(sys.argv)>1 and sys.argv[1]=='figures':
  # The renderer is outside src: visualization never changes the numerical run identity.
  import runpy
  render=runpy.run_path(str(Path(__file__).with_name('renderizar_stokes.py')))['render_stokes']
  render(sys.argv[sys.argv.index('--input')+1],sys.argv[sys.argv.index('--output')+1])
 raise SystemExit(result)
