@echo off
python -I "%~dp0pol.py" %*
exit /b %ERRORLEVEL%
