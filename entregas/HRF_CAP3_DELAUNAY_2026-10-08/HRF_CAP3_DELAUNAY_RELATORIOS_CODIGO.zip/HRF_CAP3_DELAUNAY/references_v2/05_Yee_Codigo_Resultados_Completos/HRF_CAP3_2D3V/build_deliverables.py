"""Summarize actual completed simulations without filling unexecuted milestones."""
import json,csv,sys,platform,os
os.environ.setdefault('MPLCONFIGDIR','/tmp/hrf-matplotlib')
os.environ.setdefault('XDG_CACHE_HOME','/tmp/hrf-cache')
from pathlib import Path
import numpy as np
import scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle
from hrf_maxwell_2d3v import ROOT, PREREG, now, sha, write_json

def load(name):return json.loads((ROOT/name).read_text())
free=load('FREE_GATE_RESULTS.json');short=load('CAVITY_GATE_RESULTS.json');long=load('LONG_STAGE_STATUS.json')
paths=sorted((ROOT/'results').glob('*/summary.json'))
summaries={p.parent.name:json.loads(p.read_text()) for p in paths}
rows=[]
for label,s in summaries.items():
    meta=json.loads((ROOT/'results'/label/'metadata.json').read_text())
    rows.append(dict(case=label,measurement_tag='[M]',**meta['parameters'],energy_initial=s['energy_initial'],
                     energy_inside_initial=s['energy_inside_initial'],**s['final'],
                     max_gauss_relative=s['max_gauss_relative'],max_global_balance_error=s['max_global_balance_error'],
                     max_inside_balance_error=s['max_inside_balance_error'],late_flux_directionality=s['late_flux_directionality'],
                     late_density_variability=s['late_density_variability'],HRF_CAP2_GATE=s['HRF_CAP2_GATE'],
                     local_photonic_identity=s['local_photonic_identity']))
def csv_write(path,data):
    keys=list(dict.fromkeys(k for r in data for k in r))
    with Path(path).open('w',newline='') as f:
        w=csv.DictWriter(f,keys);w.writeheader();w.writerows(data)
csv_write(ROOT/'SUMMARY_ALL_CASES.csv',rows)
write_json(ROOT/'SUMMARY_ALL_CASES.json',dict(measurement_tag='[M]',free_gate=free['Maxwell_2D3V_GATE'],HRF_CAP2_GATE=free['PHOTON_INJECTION_GATE_HRF_CAP2'],short_gate=short['status'],long_stage=long['status'],cases=rows))
balances=[{k:r[k] for k in ['case','measurement_tag','t','energy_initial','energy_inside_initial','E_inside','E_outside','E_box','absorbed_energy',
          'global_energy_balance_error','cumulative_net_outward_flux','cumulative_outward_flux','cumulative_inward_flux',
          'interior_energy_balance_error','F_in','F_rem','max_global_balance_error','max_inside_balance_error']} for r in rows if not r['free_validation']]
csv_write(ROOT/'ENERGY_BALANCES.csv',balances)

scalar=list(csv.DictReader((ROOT/'references/milestones_long_runs.csv').open()))
comparison=[]
for angle in (45,60,75,90):
    old=next(r for r in scalar if float(r['angle'])==angle and float(r['requested_t'])==30)
    for h in (1,-1):
        label=f'cavity_a{angle}_h{h:+d}_base'
        if label not in summaries:continue
        s=summaries[label]
        comparison.append(dict(measurement_tag='[M]',angle=angle,helicity=h,scalar_actual_t=float(old['actual_t']),vector_actual_t=s['final']['t'],
                               scalar_F_rem=float(old['F_rem']),vector_F_rem=s['final']['F_rem'],
                               scalar_F_in=float(old['F_in']),vector_F_in=s['final']['F_in'],
                               scalar_transport=float(old['transport']),vector_transport=s['final']['mean_speed_flux'],
                               qualification='Different operators, vector packet and absorber; matched radius/profile/nominal widths/angle/time do not imply equivalent physical states'))
csv_write(ROOT/'SCALAR_VECTOR_COMPARISON_T30.csv',comparison)
milestones=[]
for angle in (45,60,75,90):
    for h in (1,-1):
        candidates=[(label,s) for label,s in summaries.items() if s['angle']==angle and s['helicity']==h and (label.endswith('_base') or label.startswith('long_') and s['final']['t']>499)]
        for t in (30,150,300,500):
            available=[(label,s) for label,s in candidates if s['final']['t']>=t-.01]
            if available:
                label,s=max(available,key=lambda v:v[1]['final']['t'])
                timeline=np.genfromtxt(ROOT/'results'/label/'timeline.csv',delimiter=',',names=True)
                index=int(np.argmin(abs(timeline['t']-t)));r=timeline[index]
                milestones.append(dict(angle=angle,helicity=h,requested_t=t,actual_t=float(r['t']),status='EXECUTED',F_rem=float(r['F_rem']),case=label,measurement_tag='[M]'))
            else:milestones.append(dict(angle=angle,helicity=h,requested_t=t,actual_t='',status='NOT_EXECUTED',F_rem='',case='',reason=long.get('reason','Missing run'),measurement_tag='[M]'))
csv_write(ROOT/'REQUESTED_MILESTONES_STATUS.csv',milestones)

fig,axs=plt.subplots(2,2,figsize=(11,8),layout='constrained')
for angle in (45,60,75,90):
    label=f'cavity_a{angle}_h+1_base'
    if label not in summaries:continue
    a=np.genfromtxt(ROOT/'results'/label/'timeline.csv',delimiter=',',names=True)
    for ax,metric in zip(axs.flat,['F_rem','mean_speed_flux','signed_tangential_flux','cumulative_net_outward_flux']):ax.plot(a['t'],a[metric],label=f'{angle}°')
for ax,title in zip(axs.flat,['[M] Energia inicial ainda dentro: F_rem','[M] Transporte interno\nIntegral |J_xy| / E_inside','[M] Fluxo tangencial\ncom sinal / E_inside','[M] Energia líquida que cruzou r=R']):
    ax.set(xlabel='t / (λ/c_vac)',title=title);ax.grid(alpha=.25);ax.legend()
fig.savefig(ROOT/'FIGURE_CAVITY_TIMELINES.png',dpi=150);plt.close(fig)

fig,axs=plt.subplots(1,3,figsize=(14,4),layout='constrained')
for label in ['cavity_a75_h+1_base','cavity_a75_h+1_dt_half','cavity_a75_h+1_ppw24','cavity_a75_h+1_ppw32']:
    if label not in summaries:continue
    a=np.genfromtxt(ROOT/'results'/label/'timeline.csv',delimiter=',',names=True)
    for ax,metric in zip(axs,['F_rem','mean_speed_flux','estimated_underresolved_energy_fraction']):ax.plot(a['t'],a[metric],label=label.replace('cavity_a75_h+1_',''))
for ax,title in zip(axs,['[M] Retenção','[M] Transporte','[M] Energia em região sub-resolvida\n(<10 pontos/λ local estimada)']):
    ax.set(xlabel='t / (λ/c_vac)',title=title);ax.grid(alpha=.25);ax.legend(fontsize=8)
fig.savefig(ROOT/'FIGURE_SPATIAL_TEMPORAL_CONTROLS.png',dpi=150);plt.close(fig)

labels=['cavity_a75_h+1_dt_half','cavity_a75_h+1_ppw24','cavity_a75_h+1_ppw32']
fig,axs=plt.subplots(3,4,figsize=(13,10),layout='constrained')
for i,label in enumerate(labels):
    files=sorted((ROOT/'results'/label).glob('map_t_*.npz'))
    for j,p in enumerate(files[:4]):
        with np.load(p) as d:
            ax=axs[i,j];x=d['x'];dx=float(x[1]-x[0]);u=d['energy_density'];jx=d['Jx'];jy=d['Jy'];t=float(d['t'])
            ax.imshow(u.T,origin='lower',extent=[x[0]-.5*dx,x[-1]+.5*dx,x[0]-.5*dx,x[-1]+.5*dx],cmap='magma',vmin=0,vmax=2.5)
            stride=max(1,len(x)//32);xx,yy=np.meshgrid(x,x,indexing='ij');sl=slice(None,None,stride)
            scale=max(float(np.hypot(jx,jy).max()),1e-30)/.35
            ax.quiver(xx[sl,sl],yy[sl,sl],jx[sl,sl],jy[sl,sl],color='white',angles='xy',scale_units='xy',scale=scale,width=.004)
            ax.add_patch(Circle((0,0),4,fill=False,color='cyan',ls='--'))
            ax.set(xlim=(-4.5,4.5),ylim=(-4.5,4.5),title=f'[M] PPW{[20,24,32][i]}, t={t:.3f}',xlabel='x/λ',ylabel='y/λ')
fig.savefig(ROOT/'FIGURE_DENSITY_POYNTING_REFINEMENT.png',dpi=150);plt.close(fig)

evid=[r['evidence'] for r in free['case_checks']]
def rng(key):
    vals=[r[key] for r in evid];return f'{min(vals):.6g}–{max(vals):.6g}'
fg=['# Validação livre Maxwell 2D3V [M]','',f'Gate Maxwell: **{free["Maxwell_2D3V_GATE"]}**.',f'Gate HRF-CAP2: **{free["PHOTON_INJECTION_GATE_HRF_CAP2"]}**.','',
    f'{len(evid)} casos completos; ambas as helicidades, quatro ângulos, PPW20/24/32. T=3.96; controle espacial dt=0.009, temporal independente dt=0.018/0.009/0.0045.',
    '', '| Métrica [M] | Faixa observada | Limite prévio |','|---|---:|---:|',
    f'| Erro relativo de dispersão | {rng("dispersion_relative_error")} | 0.03 |',
    f'| Erro de velocidade do envelope vs referência contínua | {rng("envelope_velocity_error")} | 0.03 |',
    f'| Erro L2 de campo vs Maxwell contínuo | {rng("continuum_field_relative_L2_error")} | 0.15 e queda com PPW |',
    f'| P/E (vácuo, c=1) | {rng("momentum_energy_ratio")} | desvio de 1 ≤0.12 |',
    f'| Fração espectral longitudinal discreta | {rng("longitudinal_fraction")} | 1e-10 |',
    f'| Máxima deriva da energia física | {rng("physical_energy_max_drift")} | 0.005 |','',
    'A dispersão angular do pacote explica P/E inferior a 1/c. A amplitude circular elétrica tem Stokes ±1 na base espectral definida, com Gauss discreto dentro da tolerância.',
    'O controle de duas polarizações usa o símbolo do curl-curl Yee e os testes independentes da ação do stencil; o setor longitudinal tem autovalor zero e é excluído por Gauss. Não representa um terceiro modo propagante.',
    '', '| Ângulo [M] | h | Erro L2 PPW20 | PPW24 | PPW32 |','|---:|---:|---:|---:|---:|']
for r in free['spatial_convergence']:fg.append(f'| {r["angle"]} | {r["helicity"]:+d} | '+ ' | '.join(f'{v:.6f}' for v in r['continuum_L2_errors'])+' |')
fg+=['','Controle temporal independente [M]: '+', '.join(f'h={r["helicity"]:+d}: razão={r["order_ratio"]:.6f}' for r in free['temporal_convergence'])+'.',
     '', 'Limites: banda do pacote, janela e malhas testadas; circularidade relativa ao K discreto, que converge ao k contínuo. A referência contínua evolui os mesmos campos iniciais amostrados. O gate não valida a formulação microscópica do HRF nem quantização.',
     'O primeiro processamento falhou ao gravar o relatório por NameError; a integração não foi classificada como falha física. Todos os arquivos foram preservados, e os 34 casos foram repetidos com a correção sem alterar os critérios.',
     '', 'Evidências completas: FREE_GATE_RESULTS.json, operator_verification.json, results/free_*/ e logs/.']
(ROOT/'FREE_VALIDATION_REPORT.md').write_text('\n'.join(fg)+'\n')

report=['# HRF CAP3-2D3V-PHOTON-FLUX-01 — relatório científico','',f'Gerado: {now()}. Modelo: `CAMPO_VETORIAL_2D3V_EXPLORATORIO`.','',
    '**Resposta física:** foi demonstrada propagação livre clássica com duas polarizações e circularidade, e medidos retenção de energia e transporte interno na cavidade durante a janela executada [M]. Não foi demonstrada uma onda fotônica HRF viajando e permanecendo confinada; não se certificou um modo quase-ligado nem identidade fotônica local [?].',
    '', '## Escopo e gates','',f'- `2D3V-MAXWELL-GATE`: **{free["Maxwell_2D3V_GATE"]}** [M].',
    f'- `PHOTON-INJECTION GATE HRF-CAP2`: **{free["PHOTON_INJECTION_GATE_HRF_CAP2"]}** [?].',
    f'- Gate da bancada curta e controles: **{short["status"]}** [M].',
    f'- Fase longa: **{long["status"]}** [D].',
    '',f'Foram concluídos {len(summaries)} casos nesta tentativa corrigida [M]. Os horários e comandos de cada caso estão em logs/. Os tempos solicitados são arredondados ao passo: o CSV registra o tempo efetivo, inclusive 30.006 no passo 0.018 e 29.997 no passo 0.009 [M].',
    'Se um controle curto falhar, a fase longa não é executada: essa regra foi fixada antes das medições, conforme a condição do prompt de só avançar com controles satisfatórios. Os marcos não executados são explicitamente marcados em REQUESTED_MILESTONES_STATUS.csv; não foram preenchidos com extrapolações.',
    '', '## Referências e contrato físico','',
    'Foram lidos as regras 2D3V de 2026-10-08, o protocolo de confinamento, o relatório e código escalar anteriores e duas versões do índice HRF. A busca adicional alcançou My-Scientific-Library, a estrutura do projeto HRF, Inbox/Physics e pastas C5A. O Capítulo 1 e referências ao Capítulo 2 foram localizados, mas o arquivo obrigatório Capítulo 2 v1.1 não foi localizado no Drive pesquisado. O índice atualizado na pasta 00-Project-Overview registra que o capítulo foi recuperado na Library do ChatGPT, em /Nova-Fisica-01/, ID libfile_230201963ef0819184bddffbe0f6c7bc, e que sua localização no Drive continua pendente. A cópia do índice em Physics permanece desatualizada. Esse registro confirma uma localização documental prévia, não uma leitura do capítulo nesta tarefa. A Library do ChatGPT não está exposta pelos conectores atuais.',
    'Mesmo com acesso ao texto, aprovar a equivalência exigiria demonstrar a correspondência entre operadores, modos e simetrias. Nenhuma equivalência U(1)/Wilson ou quantização foi presumida [?]. Fontes e inventário da busca estão em references/ e provenance.json.',
    '', '## Modelo e procedimento','',
    '[F] Maxwell sem fontes, com derivada z nula, D/B com três componentes, Gauss discreto preservado; energia u=(E.D+B.H)/2 e fluxo J=E×H. [H] epsilon_r=mu_r=1/c_local é a hipótese constitutiva de controle. Não houve força orbital ou trajetória prescrita [D].',
    'A discretização Yee usa curls adjuntos e Verlet sincronizado. O absorvedor externo é uma dissipação curl-curl positiva que preserva Gauss. O fluxo de faces respeita a continuidade semidiscreta, e seu integral de saída/reentrada é acumulado a cada passo. A implementação e suas limitações estão em README.md; os testes independentes de adjunção, continuidade e kernel estão em operator_verification.json [M].',
    'A injeção circular no setor transversal tem sigma longitudinal 0.7, transversal 0.35, k0=2pi, r0=0.75R e direção (-cos(theta),sin(theta)). R=4, caixa base=16, PPW20, dt=0.018 [D]. A frequência de referência local é 2pi*0.39 e não a frequência de uma onda no vácuo com mesma lambda [D/H].',
    '', 'Perfil histórico [D]: '+json.dumps(PREREG['historical_profile'],ensure_ascii=False)+'.',
    '', '## Validação livre','',
    f'Os {len(evid)} casos livres passaram nos critérios previamente registrados [M]. O erro L2 relativo contra evolução Maxwell contínua diminui de PPW20 para PPW24 e PPW32 em todos os ângulos/helicidades; a razão temporal foi '+', '.join(f'{r["order_ratio"]:.6f}' for r in free['temporal_convergence'])+' [M]. O relatório separado FREE_VALIDATION_REPORT.md contém tolerâncias e faixas, e o JSON guarda cada verificação.',
    '', '## Retenção e balanço energético da cavidade','',
    'Todas as entradas das tabelas seguintes são medições [M]. E_initial=1; energia fora da cavidade continua na caixa. A energia absorvida é medida separadamente do resíduo numérico.',
    '', '| Ângulo [M] | h | Tempo efetivo | F_rem | F_in | E_fora | E_absorvida | Resíduo global |','|---:|---:|---:|---:|---:|---:|---:|---:|']
for a in (45,60,75,90):
    for h in (1,-1):
        s=summaries.get(f'cavity_a{a}_h{h:+d}_base')
        if not s:continue
        r=s['final'];report.append(f'| {a} | {h:+d} | {r["t"]:.3f} | {r["F_rem"]:.6f} | {r["F_in"]:.6f} | {r["E_outside"]:.6f} | {r["absorbed_energy"]:.6f} | {r["global_energy_balance_error"]:.3g} |')
report+=['','F_rem=E_inside/E_initial mede a fração originalmente injetada que ainda está dentro. F_in=E_inside/E_box mede a distribuição da energia sobrevivente; F_in alto pode coexistir com perda de quase toda a energia inicial. ENERGY_BALANCES.csv guarda E_inside, E_outside, E_absorbed, os dois balanços e o fluxo integrado para cada caso [M].',
    '', '| Ângulo [M] | h | Saída acumulada | Reentrada acumulada | Líquido | Máximo resíduo interno |','|---:|---:|---:|---:|---:|---:|']
for a in (45,60,75,90):
    for h in (1,-1):
        s=summaries.get(f'cavity_a{a}_h{h:+d}_base')
        if not s:continue
        r=s['final'];report.append(f'| {a} | {h:+d} | {r["cumulative_outward_flux"]:.6f} | {r["cumulative_inward_flux"]:.6f} | {r["cumulative_net_outward_flux"]:.6f} | {s["max_inside_balance_error"]:.3g} |')
report+=['','## Controles e decisão da fase longa','', '| Controle [M] | Métrica | Valores | Diferença avaliada | Limite prévio | Resultado |','|---|---|---|---:|---:|---|']
for r in short.get('control_checks',[]):report.append(f'| {r["control"]} | {r["metric"]} | '+', '.join(f'{v:.6f}' for v in r['values'])+f' | {r["difference"]:.6f} | {r["limit"]} | {r["status"]} |')
report+=['','O controle espacial usa dt=0.009 fixo em PPW20/24/32; o temporal altera somente dt em PPW20. O transporte do controle é a média da integral |J_xy|/E_inside entre t≥10 e o fim. Caixa ampliada e intensidade do sponge têm controles separados. O meio uniforme c=1 e o meio uniforme c=0.39 foram executados nos quatro ângulos e nas duas helicidades [D/M].',
    '', '| Ângulo [M] | h | F_rem cavidade | F_rem uniforme c=1 | F_rem uniforme c=0.39 |','|---:|---:|---:|---:|---:|']
for a in (45,60,75,90):
    for h in (1,-1):
        labels=[f'cavity_a{a}_h{h:+d}_base',f'vacuum_a{a}_h{h:+d}',f'uniform_slow_a{a}_h{h:+d}']
        if all(label in summaries for label in labels):report.append(f'| {a} | {h:+d} | '+ ' | '.join(f'{summaries[label]["final"]["F_rem"]:.6f}' for label in labels)+' |')
report+=['','Falhas registradas [M]:']
report+=['- '+v for v in short.get('failures',[])] or ['- Nenhuma falha pelos limites de curta duração; isso não certifica resolução do núcleo nem confinamento assintótico.']
report+=['', '### Resolução do núcleo lento','',
    'A escala estimada lambda_local=c_local/c_injection tem mínimo 0.015/0.39≈0.03846. PPW20/24/32 fornecem apenas ≈0.77/0.92/1.23 pontos nessa escala [D]. O alerta local usa a frequência de injeção e não substitui análise espectral local. Na janela executada, a fração de energia na região com menos de 10 pontos por lambda estimada está nos CSV e na figura de controles [M]. Assim, não há certificação de convergência do campo no núcleo lento. Estabilidade/Gauss/balanço, por si, não demonstram exatidão espacial.',
    'Resolver essa escala com dez pontos exigiria PPW≈260 no comprimento nominal, bem além de PPW32; essa conta é um requisito geométrico estimado, não um resultado de confinamento [D].',
    '', '## Movimento, polarização e classificação','', '| Ângulo [M] | h | Transporte final | Fluxo radial com sinal | Fluxo tangencial com sinal | Stokes local médio | Cobertura válida | Fração sub-resolvida estimada |','|---:|---:|---:|---:|---:|---:|---:|---:|']
for a in (45,60,75,90):
    for h in (1,-1):
        s=summaries.get(f'cavity_a{a}_h{h:+d}_base')
        if not s:continue
        r=s['final'];report.append(f'| {a} | {h:+d} | {r["mean_speed_flux"]:.6f} | {r["signed_radial_flux"]:.6f} | {r["signed_tangential_flux"]:.6f} | {r["local_circular_stokes_mean"]:.6f} | {r["local_polarization_valid_energy_fraction"]:.6f} | {r["estimated_underresolved_energy_fraction"]:.6f} |')
report+=['','Os indicadores locais usam E+i*dE/dt/omega_ref e uma base em torno da direção instantânea do Poynting: são proxies direcionais de banda estreita, não um gate fotônico local. Mistura de sentidos e interferência podem reduzir a média com sinal mesmo quando a circularidade absoluta é alta. O indicador longitudinal elétrico local não é a restrição de Gauss em D. Os mapas NPZ armazenam essas distinções [D/M].',
    'O centro de energia e máximos são descritores de distribuição; não foram usados como trajetória de um fóton. Os mapas de u e setas de J mostram redistribuição e transporte [M], e não demonstram por si voltas coerentes ou confinamento duradouro.',
    '', '| Classe | Status |','|---|---|',
    '| A — onda viajante confinada | NÃO DEMONSTRADA: identidade local HRF e coerência confinada não certificadas [?] |',
    '| B — ricochete/refração | Mapas compatíveis com desvio/redistribuição; um ricochete completo exige seguir frentes e mudança de direção, sem certificação nesta análise [?] |',
    '| C — sloshing | Apenas flags de reversão de fluxo nos casos que atendem à regra; não equivalem a identificação fotônica [M/?] |',
    '| D — circulação parcial | Flags heurísticas em summary.json conforme fluxo tangencial médio; não inferir uma órbita individual [M/?] |',
    '| E — quase-estacionário | Depende de variabilidade e direcionalidade; não inferir confinamento a partir de uma imagem estática [M/?] |',
    '| F — fuga/retenção transitória | Há saída e reentrada medidas; a duração da retenção só é conhecida na janela executada [M/?] |',
    '| G — candidato quase-ligado | NÃO APROVADO: falta gate HRF-CAP2, identidade local e resolução/convergência completa [?] |',
    '', 'Os rótulos provisórios de movimento de cada caso estão nos summaries; não promovem candidatos a demonstrações.',
    '', '## Comparação com o solver escalar','', '| Ângulo [M] | h | F_rem escalar T≈30 | F_rem vetorial T≈30 | Transporte escalar | Transporte vetorial |','|---:|---:|---:|---:|---:|---:|']
for r in comparison:report.append(f'| {r["angle"]} | {r["helicity"]:+d} | {r["scalar_F_rem"]:.6f} | {r["vector_F_rem"]:.6f} | {r["scalar_transport"]:.6f} | {r["vector_transport"]:.6f} |')
report+=['','O raio, perfil, larguras nominais, ponto inicial, ângulos e janela são comparáveis; o pacote vetorial transversal, o operador e o sponge são diferentes. Portanto, diferenças não isolam o efeito da polarização e não provam equivalência entre os modelos [D/?].',
    'O experimento escalar anterior em T≈500 reteve aproximadamente 0.0767–0.0857 da energia inicial [M, fonte anterior]. Esses valores não são medições vetoriais e não podem preencher marcos vetoriais não executados. O escalar também apresentou sensibilidade de malha na bancada anterior [M].',
    '', '## Resultados negativos, limites e próximos testes','',
    'Todos os resultados negativos foram preservados. A primeira tentativa livre teve um NameError na escrita do relatório: 28 casos falharam na etapa de relatório, e seis terminaram após a correção aplicada ao fim do lote. Essa mistura não foi usada para o gate científico final. O lote completo foi repetido, com critérios inalterados; a tentativa original, código, logs, mapas e estado estão em failed_attempt_01_report_NameError/ [D].',
    'O problema de resolução local exige malha adaptativa/conforme, um método com erro espacial controlado ou uma bancada física replanejada e registrada antes da execução. Alterar o perfil para fazê-lo caber na malha mudaria a hipótese; não foi feito neste teste [D/?].',
    'Para certificar um fóton HRF, obter o Capítulo 2 v1.1 e sua implementação e verificar operadores, modos, simetrias e o contrato de injeção/localidade. Para testar tempos longos de forma interpretável, primeiro aprovar controles de curto prazo e demonstrar resolução na região efetivamente ocupada. Variações de raio, largura e dois pacotes permanecem posteriores à bancada principal [?].',
    'Não se conclui formação de elétron, spin 1/2, carga elétrica ou quantização. O resultado estabelecido é uma bancada intermediária de Maxwell clássico, com propagação livre validada e medições de retenção/fluxo na janela executada [M].',
    '', '## Arquivos para auditoria','',
    '- Código: hrf_maxwell_2d3v.py, yee_kernels.cpp, scripts dos lotes e README.md.',
    '- Critérios: config_preregistered.json e arquivos *_PREREGISTRATION.json.',
    '- Gates: FREE_GATE_RESULTS.json, CAVITY_GATE_RESULTS.json, LONG_STAGE_STATUS.json.',
    '- Dados: SUMMARY_ALL_CASES.csv/json, ENERGY_BALANCES.csv, comparison CSV e results/*/timeline.csv.',
    '- Mapas: results/*/map_t_*.npz; PNG individuais e figuras agregadas na raiz.',
    '- Proveniência: provenance.json, references/, logs/, MANIFEST_SHA256.json.',
    '- Preservação: failed_attempt_01_report_NameError/ integral.']
(ROOT/'RELATORIO_CIENTIFICO.md').write_text('\n'.join(report)+'\n')
prov=load('provenance.json');prov.update(deliverables_recorded=now(),matplotlib=matplotlib.__version__,
    library_found_url='https://drive.google.com/drive/folders/1xhcsUpS2qrZsEVVRNSVZuPh-74-Nd0-3',
    output_drive_folder='https://drive.google.com/drive/folders/1BWeTLfVVAF4nJgL8vcfZC2Y6TS4UA-Sq',
    references_final=[dict(file=str(p.relative_to(ROOT)),size_bytes=p.stat().st_size,sha256=sha(p)) for p in sorted((ROOT/'references').glob('*')) if p.is_file()],
    source_final=[dict(file=p.name,sha256=sha(p)) for p in sorted(ROOT.glob('*')) if p.suffix in ('.py','.cpp')])
prov['mandatory_Cap2_v11'].update(additional_search='My-Scientific-Library, HRF project structural folders, Inbox/Physics and selected C5A folders; still not located in searched Drive files',updated_project_index_url='https://drive.google.com/file/d/1s_T7JqH0lBNSY5FJoa0666_zd6W4deFm/view',reported_library_path='/Nova-Fisica-01/HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_1_PT_2026-10-05.md',reported_library_file_id='libfile_230201963ef0819184bddffbe0f6c7bc',chapter_content_read_in_this_task=False,qualification='Updated index reports previous recovery in ChatGPT Library; direct reading unavailable here. Historical Physics index is stale.')
write_json(ROOT/'provenance.json',prov)
brief=f'''HRF CAP3-2D3V-PHOTON-FLUX-01 — resultados em 2026-10-08

Modelo: CAMPO_VETORIAL_2D3V_EXPLORATORIO
Gate Maxwell: {free['Maxwell_2D3V_GATE']} [M]
Gate HRF-CAP2: {free['PHOTON_INJECTION_GATE_HRF_CAP2']} [?]
Gate curto/controles: {short['status']} [M]
Fase longa: {long['status']} [D]
Casos completos nesta tentativa corrigida: {len(summaries)} [M]

Resposta: houve propagação livre clássica validada, retenção energética e
transporte interno na janela executada [M]. Não foi demonstrada uma onda
fotônica HRF viajando e permanecendo confinada [?].

Leia RELATORIO_CIENTIFICO.md e FREE_VALIDATION_REPORT.md. Os números e os
limites estão nos CSV/JSON; tempos não executados são explicitamente marcados.
Falhas e dados da primeira tentativa foram preservados no pacote completo.

Pasta dos resultados:
https://drive.google.com/drive/folders/1BWeTLfVVAF4nJgL8vcfZC2Y6TS4UA-Sq

Os documentos foram pesquisados em My-Scientific-Library no Drive. O índice
atualizado registra o Capítulo 2 v1.1 na Library do ChatGPT, em /Nova-Fisica-01/;
ele não foi localizado no Drive e não pôde ser lido diretamente nesta sessão.
Nenhuma equivalência U(1)/Wilson nem formação de elétron foi concluída.
'''
(ROOT/'LEIA_PRIMEIRO.txt').write_text(brief)
print(f'Built report, CSV/JSON and figures for {len(summaries)} completed cases.')
