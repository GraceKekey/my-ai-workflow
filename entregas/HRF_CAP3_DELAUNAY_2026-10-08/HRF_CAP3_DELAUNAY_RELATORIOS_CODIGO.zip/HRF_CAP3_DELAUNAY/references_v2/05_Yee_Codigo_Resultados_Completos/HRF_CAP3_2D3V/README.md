# HRF CAP3-2D3V-PHOTON-FLUX-01 — bancada Maxwell intermediária

Este pacote é independente do GitHub. O nome científico da excitação é
`CAMPO_VETORIAL_2D3V_EXPLORATORIO`. Um PASS no gate de Maxwell não certifica a
dinâmica U(1)/Wilson do HRF nem quantização de um fóton individual.

## Execução

Requer Python 3.10+, NumPy, SciPy e matplotlib para figuras. As versões usadas
estão em `provenance.json`. Um compilador g++ é opcional: o kernel C++ incluído
acelera as mesmas equações; o backend NumPy implementa a dinâmica completa.
Não são necessários credenciais, acesso ao GitHub ou rede durante a execução.

```sh
python verify_operators.py
python run_free_gate.py
python run_cavity_short.py
python run_long_if_approved.py
python build_deliverables.py
```

Esses comandos criam saídas novas e recusam sobrescrever casos existentes.
Para repetir, copie o código, `config_preregistered.json` e `references/` para
uma pasta vazia. Os links do Drive nos scripts de relatório identificam esta
entrega original; ao organizar uma nova entrega, atualize seu destino separado.
O solver permite casos isolados:

```sh
python hrf_maxwell_2d3v.py --output resultado_novo --angle 75 --helicity 1 --ppw 20 --dt .018 --tmax 30 --plots
```

Use `--backend numpy` para o caminho sem compilador. O arquivo
`config_preregistered.json` contém os limites definidos antes de observar as
medições. `FREE_GATE_PREREGISTRATION.json` e `CAVITY_PREREGISTRATION.json`
registram os casos e o hash dos critérios antes de cada fase. A fase longa só
é permitida se os gates numéricos anteriores forem satisfatórios.

## Equações e discretização

[F] Evoluem D e B: Ddot = curl H, Bdot = -curl E; E = c_local D,
H = c_local B. Há duas coordenadas espaciais e três componentes de cada campo,
com derivada z nula. [H] A cavidade usa epsilon_r = mu_r = 1/c_local; essa é
uma hipótese constitutiva de impedância uniforme, sem derivação microscópica HRF.

Na rede Yee, os deslocamentos de E/D são (1/2,0), (0,1/2), (0,0), e os de
B/H são (0,1/2), (1/2,0), (1/2,1/2), em unidades da malha. C é o curl com
diferenças para frente, e C^T seu adjunto com diferenças para trás. Os passos
B de meio intervalo, D de intervalo inteiro e B de meio intervalo implementam
Verlet sincronizado. As divergências apropriadas de D e B anulam exatamente
os curls correspondentes. O símbolo K_i = 2 sin(k_i dx/2)/dx tem operador
curl-curl |K|² I - K K^T: duas polarizações transversais e um setor de restrição.

[D] A injeção Fourier tem suporte de frequência positiva na direção
(-cos(theta),sin(theta)), envelope gaussiano com sigma_long=0.7 e
sigma_trans=0.35, k0=2pi. A base transversal é p=(-K_y,K_x,0)/|K| e z;
e_h=(p+i h z)/sqrt(2), com convenção exp[i(k.x-omega.t)]. D e B respeitam
Gauss discreto. B tem a correção de eigenmodo Verlet rho=sqrt(1-dt² c0²|K|²/4)
na velocidade de injeção. Na cavidade variável, isso é uma preparação local,
não um eigenmodo global do meio. A energia física inicial é normalizada a 1.

## Energia, fluxo e absorvedor

[F] u=(E.D+B.H)/2 e J=E×H. As energias de componentes escalonadas são
distribuídas aos nós vizinhos preservando a soma. O fluxo normal usa a
interpolação de faces que satisfaz exatamente a identidade de continuidade
Maxwell semidiscreta dessa distribuição. Os mapas mostram Jx/Jy interpolados
ao centro, e Jz por campos centrados. A fronteira diagnóstica é a união de
células cujos nós satisfazem r<R, aproximando o círculo por degraus da malha.

Saída, reentrada e fluxo líquido na fronteira são integrados em **cada passo**
de tempo, e não apenas nos instantes salvos. Os CSV distinguem
F_in=E_inside/E_box e F_rem=E_inside/E_initial. O balanço global é
(E_box+E_absorbed-E_initial)/E_initial; o balanço interno é
(E_inside-E_inside_initial+fluxo_liquido_integrado)/E_initial.

[D] O sponge atua fora da cavidade, em uma caixa exterior periódica. Usa
Ddot=-C^T eta_B C E e Bdot=-C eta_E C^T H, em metades Strang, com subpassos
explícitos abaixo do limite dissipativo. Esse operador positivo preserva Gauss.
A energia removida é medida pela diferença física real de cada atualização,
com os termos quadráticos incluídos. Sua reflexão exige controles de caixa
e intensidade; não equivale a uma fronteira aberta perfeita. Ele difere do
absorvedor multiplicativo do solver escalar histórico.

A energia modificada Verlet Q=E_phys-dt² sum[c_B (C E)²] dx²/8 é armazenada
separadamente. O resíduo global é o erro sobre a energia física, nunca chamado
de absorção. `verify_operators.py` verifica adjunção, continuidade local,
símbolo Fourier e correspondência entre C++ e NumPy por caminhos independentes.

## Diagnósticos e limites

[D] A circularidade livre é o Stokes circular no setor espectral de k positivo,
relativo a K da discretização. No meio variável, o indicador local usa
E+i*dE/dt/omega_ref e a direção local do Poynting. É uma aproximação de banda
estreita; interferência, baixo fluxo ou espectro largo impedem interpretá-la
como certificação local de um fóton. Gauss usa D, não div(E), quando epsilon
varia. A cobertura energética da máscara válida está nos CSV.

A estimativa de pontos por comprimento de onda local usa
lambda_local≈2pi*c_local/omega_injection. É um alerta geométrico, não uma
medida espectral local: PPW no vácuo não é PPW na região lenta. Na região
c_min=0.015 e c_injection=0.39, lambda_local≈0.03846 e PPW20/24/32 oferecem
aproximadamente 0.77/0.92/1.23 pontos nessa escala. Isso impede uma declaração
de resolução adequada do núcleo lento, mesmo se métricas integrais forem estáveis.

[?] O Capítulo 2 v1.1 não foi localizado nos arquivos acessíveis pesquisados
da My-Scientific-Library no Drive. O índice atualizado do projeto registra que
o capítulo foi recuperado na Library do ChatGPT em /Nova-Fisica-01/, ID
libfile_230201963ef0819184bddffbe0f6c7bc, e que a localização no Drive continua
pendente. A cópia do índice em Physics está desatualizada. Esse registro
documental não permite acessar o conteúdo do capítulo nesta sessão.
O gate HRF-CAP2 permanece NOT_TESTED; não há demonstração de correspondência
com U(1), laços orientados, energia de Wilson, simetrias ou quantização.

## Arquivos e preservação

`results/` guarda todos os casos válidos, CSV, JSON, mapas NPZ e figuras PNG.
NPZ de mapas são diagnósticos derivados float32; campos evoluídos e métricas
são calculados em float64. As séries CSV não guardam cada passo, mas os
integrais da fronteira incluem todos. Não se promete um checkpoint completo
do campo em cada instante. Os campos terminais livres foram retidos para o
controle temporal independente.

`failed_attempt_01_report_NameError/` preserva integralmente a primeira
tentativa, incluindo o erro de geração de relatório e os casos negativos.
O erro foi corrigido sem mudar critérios científicos e toda a fase livre
foi repetida. O relatório distingue falha de execução de falha física.
`references/` contém as fontes efetivamente lidas e a busca da biblioteca.
`MANIFEST_SHA256.json` inventaria os arquivos da entrega e seus hashes.
Todas as conclusões e medições numéricas deste pacote são [M].
