"""Produce audited full ZIP, a small readable ZIP and lossless upload volumes."""
from pathlib import Path
import json,zipfile,hashlib,shutil
from hrf_maxwell_2d3v import ROOT,write_json,sha,now

destination=ROOT.parent/'hrf_2d3v_delivery_2026-10-08'
destination.mkdir(exist_ok=True)
full=destination/'HRF_CAP3_2D3V_RESULTADOS_COMPLETOS_2026-10-08.zip'
small=destination/'HRF_CAP3_2D3V_RELATORIOS_CODIGO_TABELAS_2026-10-08.zip'
if full.exists() or small.exists():raise FileExistsError('Refusing to overwrite existing delivery ZIPs')
def files():
    return sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256.json')
inventory=[dict(path=str(p.relative_to(ROOT)),bytes=p.stat().st_size,sha256=sha(p)) for p in files()]
write_json(ROOT/'MANIFEST_SHA256.json',dict(created=now(),measurement_tag='[M]',count=len(inventory),files=inventory,exclusions=['__pycache__','This manifest itself; its hash is recorded by delivery metadata']))
all_files=files()+[ROOT/'MANIFEST_SHA256.json']
with zipfile.ZipFile(full,'w',allowZip64=True) as z:
    for p in all_files:
        method=zipfile.ZIP_STORED if p.suffix in ('.npz','.png','.zip') else zipfile.ZIP_DEFLATED
        z.write(p,'HRF_CAP3_2D3V/'+str(p.relative_to(ROOT)),compress_type=method,compresslevel=3)
with zipfile.ZipFile(full) as z:
    bad=z.testzip()
    if bad:raise RuntimeError('CRC failed: '+bad)
with zipfile.ZipFile(small,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=3) as z:
    for p in all_files:
        if p.suffix=='.npz':continue
        z.write(p,'HRF_CAP3_2D3V/'+str(p.relative_to(ROOT)))
    for p in sorted((ROOT/'results/cavity_a75_h+1_base').glob('map_t_*.npz')):
        z.write(p,'HRF_CAP3_2D3V/'+str(p.relative_to(ROOT)))
    z.writestr('HRF_CAP3_2D3V/ESCOPO_DESTE_ZIP.txt','Este ZIP menor contém relatórios, código, critérios, tabelas, logs e figuras, inclusive falhas. Inclui mapas NPZ apenas do caso-base 75 graus h=+1. Todos os outros mapas, médias e campos livres estão no ZIP COMPLETO em volumes. O manifesto original descreve o pacote completo, não somente este resumo.\n')
if small.stat().st_size>40*1024**2:raise RuntimeError('Small ZIP exceeds conservative upload size; split it separately rather than hiding data')
metadata=dict(created=now(),archive=full.name,archive_bytes=full.stat().st_size,archive_sha256=sha(full),archive_files=len(all_files),
    manifest_sha256=sha(ROOT/'MANIFEST_SHA256.json'),summary_archive=small.name,summary_bytes=small.stat().st_size,summary_sha256=sha(small),volume_bytes=32*1024**2,volumes=[])
with full.open('rb') as source:
    index=0
    while block:=source.read(metadata['volume_bytes']):
        index+=1;p=destination/(full.name+f'.{index:03d}');p.write_bytes(block)
        metadata['volumes'].append(dict(name=p.name,bytes=len(block),sha256=hashlib.sha256(block).hexdigest()))
write_json(destination/'VOLUMES.json',metadata)
# Verify the ordered volumes reconstruct exactly the full archive byte stream.
h=hashlib.sha256()
for v in metadata['volumes']:
    with (destination/v['name']).open('rb') as f:
        for block in iter(lambda:f.read(1024**2),b''):h.update(block)
if h.hexdigest()!=metadata['archive_sha256']:raise RuntimeError('Volume concatenation verification failed')
join='''from pathlib import Path
import hashlib,json,os
root=Path(__file__).resolve().parent
m=json.loads((root/'VOLUMES.json').read_text(encoding='utf-8'))
output=root/m['archive']
if output.exists():
    raise SystemExit('O ZIP completo já existe; não vou sobrescrever: '+str(output))
temp=output.with_suffix('.zip.part')
whole=hashlib.sha256()
with temp.open('wb') as out:
    for v in m['volumes']:
        p=root/v['name']
        if not p.exists():raise SystemExit('Falta o volume: '+p.name)
        current=hashlib.sha256();size=0
        with p.open('rb') as f:
            for b in iter(lambda:f.read(1024*1024),b''):
                out.write(b);current.update(b);whole.update(b);size+=len(b)
        if current.hexdigest()!=v['sha256'] or size!=v['bytes']:
            raise SystemExit('Volume danificado: '+p.name)
        print('OK:',p.name)
if whole.hexdigest()!=m['archive_sha256']:raise SystemExit('Falha no SHA-256 do ZIP completo')
os.replace(temp,output)
print('ZIP completo criado e verificado:',output)
'''
(destination/'UNIR_RESULTADOS.py').write_text(join)
ps='''$ErrorActionPreference = 'Stop'
$taskRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$metadata = Get-Content -Raw -LiteralPath (Join-Path $taskRoot 'VOLUMES.json') | ConvertFrom-Json
$outputPath = Join-Path $taskRoot $metadata.archive
if (Test-Path -LiteralPath $outputPath) { throw 'O ZIP completo já existe. Não será sobrescrito.' }
$tempPath = $outputPath + '.part'
$outputStream = [System.IO.File]::Create($tempPath)
try {
    foreach ($volume in $metadata.volumes) {
        $partPath = Join-Path $taskRoot $volume.name
        if (!(Test-Path -LiteralPath $partPath)) { throw ('Falta o volume: ' + $volume.name) }
        $actualHash = (Get-FileHash -LiteralPath $partPath -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($actualHash -ne $volume.sha256) { throw ('Volume danificado: ' + $volume.name) }
        if ((Get-Item -LiteralPath $partPath).Length -ne $volume.bytes) { throw 'Tamanho incorreto' }
        $inputStream = [System.IO.File]::OpenRead($partPath)
        try { $inputStream.CopyTo($outputStream) } finally { $inputStream.Dispose() }
        Write-Host ('OK: ' + $volume.name)
    }
} finally { $outputStream.Dispose() }
if ((Get-FileHash -LiteralPath $tempPath -Algorithm SHA256).Hash.ToLowerInvariant() -ne $metadata.archive_sha256) { throw 'SHA-256 do ZIP completo incorreto' }
Move-Item -LiteralPath $tempPath -Destination $outputPath
Write-Host ('ZIP completo criado e verificado: ' + $outputPath)
'''
(destination/'UNIR_RESULTADOS.ps1').write_text(ps)
(destination/'UNIR_NO_WINDOWS.cmd').write_text('@echo off\r\npowershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0UNIR_RESULTADOS.ps1"\r\npause\r\n')
note=f'''PACOTE HRF CAP3-2D3V — INSTRUÇÕES DE DOWNLOAD

Para leitura rápida, baixe {small.name}.
Ele contém relatórios, código, tabelas, logs, figuras e mapas do caso-base 75° h=+1.

O ZIP completo tem {full.stat().st_size/1024**2:.1f} MiB e {len(all_files)} arquivos.
Foi dividido sem perda em {len(metadata['volumes'])} volumes devido ao limite de upload
do conector. Todos os mapas e a primeira tentativa com falha estão preservados.

Para reconstruir o ZIP completo, baixe TODOS os arquivos .zip.001 até
.zip.{len(metadata['volumes']):03d}, VOLUMES.json e os scripts UNIR para a mesma pasta.
Os volumes não são ZIPs independentes: não tente extrair cada um.

Windows: clique duas vezes em UNIR_NO_WINDOWS.cmd. Usa PowerShell já instalado.
macOS/Linux ou Windows com Python: execute python UNIR_RESULTADOS.py.
O script verifica SHA-256 dos volumes e do ZIP completo antes de concluí-lo.
Depois, extraia o ZIP completo com o gerenciador de arquivos.

SHA-256 do ZIP completo: {metadata['archive_sha256']}
Pasta no Drive: https://drive.google.com/drive/folders/1BWeTLfVVAF4nJgL8vcfZC2Y6TS4UA-Sq
As medições e conclusões numéricas são [M]. Leia o relatório para os gates e limites.
'''
(destination/'COMO_BAIXAR_E_UNIR.txt').write_text(note)
print(json.dumps({k:v for k,v in metadata.items() if k!='volumes'},indent=2));print('Volumes:',len(metadata['volumes']))
