"""Independent operator identities for the new solver; not a photon gate."""
from pathlib import Path
import json
import numpy as np
from hrf_maxwell_2d3v import Grid,EOFF,BOFF,write_json

g=Grid(ppw=20,box=4,radius=1,dt=.018,medium='uniform',sponge=False)
rng=np.random.default_rng(1042026)
e=rng.normal(size=(3,g.n,g.n))
b=rng.normal(size=e.shape)
ce=g.curl(e);ch=g.curl(b,True)
adjoint=abs(np.sum(ce*b)-np.sum(e*ch))/max(abs(np.sum(ce*b)),1e-30)
f=np.ascontiguousarray(np.concatenate([e,b]))
continuity=g.continuity(f)['relative_max']
phase=2*np.pi*(3*g.x/4+5*g.y/4)
vector=np.array([.4,-.2,.7])
wave=np.array([vector[a]*np.cos(phase+2*np.pi*(3*EOFF[a,0]+5*EOFF[a,1])*g.dx/4) for a in range(3)])
k=np.array([2*np.sin(3*np.pi*g.dx/4)/g.dx,2*np.sin(5*np.pi*g.dx/4)/g.dx,0])
curlvector=np.cross(k,vector)
expected=np.array([-curlvector[a]*np.sin(phase+2*np.pi*(3*BOFF[a,0]+5*BOFF[a,1])*g.dx/4) for a in range(3)])
symbol_error=np.linalg.norm(g.curl(wave)-expected)/np.linalg.norm(expected)
sg=Grid(ppw=20,box=4,radius=1,dt=.018,medium='uniform',sponge=True,sponge_start=1.5)
ng=Grid(ppw=20,box=4,radius=1,dt=.018,medium='uniform',sponge=True,sponge_start=1.5,backend='numpy')
state,_=sg.initial(75,1,origin=[0,0])
native=state.copy();numpy=state.copy()
nt=sg.advance(native,5);pt=ng.advance(numpy,5)
backend_error=np.linalg.norm(native-numpy)/np.linalg.norm(numpy)
flux_error=np.max(np.abs(nt-pt))
gauss=sg.gauss(native)[0]
result=dict(discrete_curl_adjoint_error=adjoint,semidiscrete_local_energy_identity_error=continuity,
            independent_fourier_symbol_error=symbol_error,native_numpy_state_error=backend_error,
            native_numpy_absorption_and_boundary_integrals_error=float(flux_error),
            gauss_after_absorbing_steps=gauss,absorbed_energy=float(nt[0]),
            meaning='Engineering checks of identities and native acceleration; NOT HRF photon validation')
write_json(Path(__file__).resolve().parent/'operator_verification.json',result)
assert adjoint<1e-12 and continuity<1e-12 and symbol_error<1e-12
assert backend_error<1e-12 and flux_error<1e-10
assert max(gauss.values())<1e-12 and nt[0]>=-1e-12
print(json.dumps(result,indent=2))
