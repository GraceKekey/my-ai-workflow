from pathlib import Path
from concurrent.futures import ThreadPoolExecutor,as_completed
import json,subprocess,sys,os,time
import numpy as np
from hrf_maxwell_2d3v import ROOT,PREREG,Grid,write_json,sha,now

RESULTS=ROOT/'results';LOGS=ROOT/'logs';LOGS.mkdir(exist_ok=True)
jobs=[]
for ppw in (20,24,32):
    for angle in (45,60,75,90):
        for helicity in (1,-1):
            jobs.append(dict(ppw=ppw,angle=angle,helicity=helicity,dt=.009))
for angle in (45,60,75,90):
    for helicity in (1,-1):
        jobs.append(dict(ppw=20,angle=angle,helicity=helicity,dt=.018))
for helicity in (1,-1):
    jobs.append(dict(ppw=20,angle=75,helicity=helicity,dt=.0045))

def name(p):
    return f"free_a{p['angle']}_h{p['helicity']:+d}_ppw{p['ppw']}_dt{p['dt']}"

def run(p):
    label=name(p);output=RESULTS/label
    cmd=[sys.executable,'-u',str(ROOT/'hrf_maxwell_2d3v.py'),'--output',str(output),'--medium','uniform','--no-sponge',
         '--free-validation','--tmax',str(PREREG['free_gate']['tmax'])]
    for key,value in p.items():cmd.extend(['--'+key,str(value)])
    env=os.environ.copy();env.update(MPLCONFIGDIR='/tmp/hrf-matplotlib',XDG_CACHE_HOME='/tmp/hrf-cache',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    start=now();wall=time.monotonic()
    print('START '+label,flush=True)
    with (LOGS/(label+'.log')).open('w') as log:
        result=subprocess.run(cmd,env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    record=dict(name=label,parameters=p,command=cmd,exit_code=result.returncode,started=start,finished=now(),wall_seconds=time.monotonic()-wall)
    write_json(LOGS/(label+'.execution.json'),record)
    print(f'DONE {label}: exit={result.returncode}',flush=True)
    return record

write_json(ROOT/'FREE_GATE_PREREGISTRATION.json',dict(time=now(),config_sha256=sha(ROOT/'config_preregistered.json'),criteria=PREREG['free_gate'],jobs=jobs))
with ThreadPoolExecutor(max_workers=3) as pool:
    records=[future.result() for future in as_completed([pool.submit(run,p) for p in jobs])]
write_json(ROOT/'free_execution.json',records)

limits=PREREG['free_gate'];checks=[];summaries={};failures=[]
for record in records:
    if record['exit_code']:
        failures.append(record['name']+': execution failure');continue
    summary=json.loads((RESULTS/record['name']/'summary.json').read_text());summaries[record['name']]=summary
    evidence=summary['free_validation'];h=record['parameters']['helicity']
    test={
        'Gauss':summary['max_gauss_relative']<=limits['gauss_relative_max'],
        'no_propagating_longitudinal':evidence['longitudinal_fraction']<=limits['longitudinal_spectral_energy_fraction_max'],
        'circular_helicity_relative_to_k':abs(evidence['spectral_circular_stokes']-h)<=limits['helicity_absolute_error_max'],
        'omega_ck':evidence['dispersion_relative_error']<=limits['dispersion_relative_error_max'],
        'P_over_E':abs(evidence['momentum_energy_ratio']-1)<=limits['momentum_energy_deviation_from_1_over_c_max'],
        'envelope':evidence['envelope_velocity_error']<=limits['envelope_velocity_error_against_continuum_reference_max'],
        'energy':evidence['physical_energy_max_drift']<=limits['physical_energy_drift_max'],
        'continuum_accuracy':evidence['continuum_field_relative_L2_error']<=limits['continuum_field_relative_L2_error_max'],
        'finite_stable':summary['numerically_finite']}
    checks.append(dict(case=record['name'],status='PASS' if all(test.values()) else 'FAIL',checks=test,evidence=evidence,
                       max_gauss_relative=summary['max_gauss_relative']))
    failures.extend(record['name']+': '+key for key,passed in test.items() if not passed)

spatial=[]
for angle in (45,60,75,90):
    for h in (1,-1):
        keys=[name(dict(ppw=ppw,angle=angle,helicity=h,dt=.009)) for ppw in (20,24,32)]
        if not all(key in summaries for key in keys):continue
        errors=[summaries[key]['free_validation']['continuum_field_relative_L2_error'] for key in keys]
        passed=errors[0]>errors[1]>errors[2]
        spatial.append(dict(angle=angle,helicity=h,ppw=[20,24,32],continuum_L2_errors=errors,errors_decrease=passed))
        if not passed:failures.append(f'Spatial error not decreasing: angle={angle}, h={h}')

temporal=[]
for h in (1,-1):
    keys=[name(dict(ppw=20,angle=75,helicity=h,dt=dt)) for dt in (.018,.009,.0045)]
    if not all(key in summaries for key in keys):continue
    states=[]
    for key in keys:
        with np.load(RESULTS/key/'free_terminal_fields.npz') as data:
            states.append(np.concatenate([data['D'],data['B']]))
    differences=[float(np.linalg.norm(states[0]-states[1])),float(np.linalg.norm(states[1]-states[2]))]
    ratio=differences[0]/max(differences[1],1e-30)
    low,high=limits['independent_time_order_ratio_range'];passed=low<=ratio<=high
    temporal.append(dict(helicity=h,dt=[.018,.009,.0045],fixed_ppw=20,field_difference_norms=differences,order_ratio=ratio,status='PASS' if passed else 'FAIL'))
    if not passed:failures.append(f'Independent temporal order failure: h={h}, ratio={ratio}')

# Independent Bloch-spectrum check for all nonzero symbols on each tested mesh.
symbols=[]
for ppw in (20,24,32):
    g=Grid(ppw=ppw,medium='uniform',sponge=False,dt=.009)
    # curl-curl = |K|^2 I - K K^T; select directions including grid extrema.
    for i,j in [(1,0),(0,1),(1,1),(3,7),(g.n//2,0),(g.n//2,g.n//2)]:
        k=g.ktilde[:,i,j];q=np.dot(k,k)
        eigenvalues=np.linalg.eigvalsh(q*np.eye(3)-np.outer(k,k))
        passed=abs(eigenvalues[0])<=limits['polarization_rank_tolerance']*q and np.allclose(eigenvalues[1:],q,rtol=limits['polarization_rank_tolerance'],atol=0)
        symbols.append(dict(ppw=ppw,mode_indices=[i,j],eigenvalues=eigenvalues.tolist(),physical_transverse_polarizations=2 if passed else None,status='PASS' if passed else 'FAIL'))
        if not passed:failures.append('Polarization rank failure')

gate=dict(bench=PREREG['bench'],evaluated=now(),criteria_sha256=sha(ROOT/'config_preregistered.json'),
          Maxwell_2D3V_GATE='PASS' if not failures and len(summaries)==len(jobs) else 'FAIL',
          PHOTON_INJECTION_GATE_HRF_CAP2='NOT_TESTED',HRF_CAP2_reason=PREREG['gate_HRF_CAP2']['reason'],
          case_checks=checks,spatial_convergence=spatial,temporal_convergence=temporal,polarization_symbols=symbols,
          operator_verification=json.loads((ROOT/'operator_verification.json').read_text()),failures=failures,
          disclaimer='PASS is restricted to the classical Maxwell discretization and tested packet band/resolutions; not U(1)/Wilson equivalence or quantum photon validation')
write_json(ROOT/'FREE_GATE_RESULTS.json',gate)
print('2D3V-MAXWELL-GATE: '+gate['Maxwell_2D3V_GATE'],flush=True)
print('PHOTON-INJECTION GATE HRF-CAP2: NOT_TESTED',flush=True)
print('Failures: '+str(failures),flush=True)
