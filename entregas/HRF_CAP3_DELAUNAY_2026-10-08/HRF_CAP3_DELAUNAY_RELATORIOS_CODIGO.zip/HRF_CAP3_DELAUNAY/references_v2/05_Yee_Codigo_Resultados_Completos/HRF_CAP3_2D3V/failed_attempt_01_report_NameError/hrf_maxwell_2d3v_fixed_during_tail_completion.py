#!/usr/bin/env python3
"""Exploratory classical Maxwell 2D3V; no HRF-CAP2 equivalence claim.

Yee spatial curls and synchronized Verlet time integration. The sponge is a
positive curl-curl dissipator, preserving the discrete Gauss constraints; it is
an artificial absorber, not a microscopic HRF medium. NumPy fallback is complete;
an optional bundled C++ kernel accelerates the same updates without network.
"""
from __future__ import annotations

import argparse
import csv
import ctypes
import hashlib
import json
import math
import os
from pathlib import Path
import platform
import shutil
import subprocess
import sys
import time
from datetime import datetime
from zoneinfo import ZoneInfo

import numpy as np
from scipy.interpolate import PchipInterpolator

ROOT = Path(__file__).resolve().parent
PREREG = json.loads((ROOT/'config_preregistered.json').read_text())
EOFF = np.array([[.5,0],[0,.5],[0,0]])
BOFF = np.array([[0,.5],[.5,0],[.5,.5]])
K0 = 2*np.pi


def now():
    return datetime.now(ZoneInfo('America/Sao_Paulo')).isoformat()


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda:f.read(1024**2), b''):
            h.update(block)
    return h.hexdigest()


def write_json(path, data):
    Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False)+'\n')


def curl_numpy(v, dx, adjoint=False):
    if adjoint:
        return np.array([(v[2]-np.roll(v[2],1,1))/dx,
                         -(v[2]-np.roll(v[2],1,0))/dx,
                         (v[1]-np.roll(v[1],1,0)-v[0]+np.roll(v[0],1,1))/dx])
    return np.array([(np.roll(v[2],-1,1)-v[2])/dx,
                     -(np.roll(v[2],-1,0)-v[2])/dx,
                     (np.roll(v[1],-1,0)-v[1]-np.roll(v[0],-1,1)+v[0])/dx])


class Grid:
    def __init__(self, ppw=20, box=16., radius=4., dt=.018, medium='cavity',
                 speed=1., sponge=True, sponge_start=6.5, sponge_eta=.045594532639052,
                 backend='auto'):
        self.ppw, self.dx, self.box, self.radius, self.dt = ppw, 1/ppw, box, radius, dt
        self.n = int(round(box*ppw))
        if abs(self.n-box*ppw)>1e-9 or self.n<32:
            raise ValueError('box*ppw must be an integer >=32')
        if not 0<dt<self.dx/math.sqrt(2):
            raise ValueError('Maxwell CFL violated')
        if radius+3*self.dx>=box/2:
            raise ValueError('Cavity must fit inside periodic box')
        if sponge and not radius+3*self.dx<sponge_start<box/2:
            raise ValueError('Sponge must be separated from the diagnostic cavity')
        self.medium, self.speed, self.sponge = medium, speed, sponge
        self.sponge_start, self.sponge_eta = sponge_start, sponge_eta
        self.coords=(np.arange(self.n)-self.n/2)*self.dx
        self.x,self.y=np.meshgrid(self.coords,self.coords,indexing='ij')
        self.r=np.hypot(self.x,self.y)
        self.mask=self.r<radius
        profile=PREREG['historical_profile']
        self.profile=PchipInterpolator(profile['r_over_R'],profile['c'])
        self.ce=np.ascontiguousarray([self.local_c(self.x+o[0]*self.dx,self.y+o[1]*self.dx) for o in EOFF])
        self.cb=np.ascontiguousarray([self.local_c(self.x+o[0]*self.dx,self.y+o[1]*self.dx) for o in BOFF])
        self.cnode=self.local_c(self.x,self.y)
        def eta(offset):
            edge=np.maximum(np.abs(self.x+offset[0]*self.dx),np.abs(self.y+offset[1]*self.dx))
            return sponge_eta*np.clip((edge-sponge_start)/(box/2-sponge_start),0,1)**2 if sponge else np.zeros_like(edge)
        self.ae=np.ascontiguousarray([eta(o) for o in EOFF])
        self.ab=np.ascontiguousarray([eta(o) for o in BOFF])
        bound=.9*self.dx**2/(4*max(sponge_eta,1e-30)*max(float(self.ce.max()),float(self.cb.max())))
        self.damp_substeps=max(1,math.ceil(.5*dt/bound)) if sponge else 1
        def edges(axis):
            ii,jj=np.where(self.mask!=np.roll(self.mask,-1,axis))
            return np.ascontiguousarray(np.stack([ii,jj,np.where(self.mask[ii,jj],1,-1)],axis=1),dtype=np.int32)
        self.ex,self.ey=edges(0),edges(1)
        k=2*np.pi*np.fft.fftfreq(self.n,d=self.dx)
        self.kx,self.ky=np.meshgrid(k,k,indexing='ij')
        self.ktilde=np.array([2*np.sin(self.kx*self.dx/2)/self.dx,
                              2*np.sin(self.ky*self.dx/2)/self.dx,np.zeros_like(self.kx)])
        self.knorm=np.linalg.norm(self.ktilde,axis=0)
        self.khat=self.ktilde/np.maximum(self.knorm,1e-30)
        self.p=np.array([-self.khat[1],self.khat[0],np.zeros_like(self.kx)])
        self.scratch=np.empty((18,self.n,self.n),dtype=np.float64)
        self.native=None
        if backend!='numpy' and shutil.which('g++'):
            source=ROOT/'yee_kernels.cpp'
            cache=Path('/tmp/hrf_yee_native')
            cache.mkdir(exist_ok=True)
            library=cache/('yee_'+sha(source)[:16]+'.so')
            if not library.exists():
                subprocess.run(['g++','-O3','-std=c++17','-shared','-fPIC',str(source),'-o',str(library)],check=True)
            self.native=ctypes.CDLL(str(library))
            ptr=np.ctypeslib.ndpointer(dtype=np.float64,flags='C_CONTIGUOUS')
            iptr=np.ctypeslib.ndpointer(dtype=np.int32,flags='C_CONTIGUOUS')
            ci,cd=ctypes.c_int,ctypes.c_double
            self.native.yee_curl.argtypes=[ptr,ptr,ci,cd,ci]
            self.native.yee_curl.restype=None
            self.native.yee_advance.argtypes=[ptr,ptr,ptr,ptr,ptr,ci,cd,cd,ci,ci,ci,iptr,ci,iptr,ci,ptr,ptr]
            self.native.yee_advance.restype=None
        elif backend=='native':
            raise RuntimeError('Requested native backend requires g++')

    def local_c(self,x,y):
        if self.medium=='uniform':
            return np.full_like(x,self.speed,dtype=np.float64)
        rr=np.hypot(x,y)/self.radius
        return np.clip(np.where(rr>=1.25,1.,self.profile(np.clip(rr,0,1.25))),.015,1.)

    def curl(self,v,adjoint=False):
        if self.native is None:
            return curl_numpy(v,self.dx,adjoint)
        v=np.ascontiguousarray(v,dtype=np.float64)
        result=np.empty_like(v)
        self.native.yee_curl(v,result,self.n,self.dx,int(adjoint))
        return result

    def dephase(self,v,offsets):
        result=np.fft.fft2(v,axes=(-2,-1))
        for a,o in enumerate(offsets):
            result[a]*=np.exp(-1j*(self.kx*o[0]+self.ky*o[1])*self.dx)
        return result

    def rephase(self,v,offsets):
        result=v.copy()
        for a,o in enumerate(offsets):
            result[a]*=np.exp(1j*(self.kx*o[0]+self.ky*o[1])*self.dx)
        return np.fft.ifft2(result,axes=(-2,-1)).real

    def initial(self,angle=75.,helicity=1,origin=None,sigma_long=.7,sigma_trans=.35):
        theta=np.radians(angle)
        direction=np.array([-np.cos(theta),np.sin(theta)])
        perpendicular=np.array([-direction[1],direction[0]])
        if origin is None:
            origin=np.array([.75*self.radius,0.])
        origin=np.asarray(origin)
        ks=direction[0]*self.kx+direction[1]*self.ky
        kp=perpendicular[0]*self.kx+perpendicular[1]*self.ky
        amplitude=np.exp(-.5*sigma_long**2*(ks-K0)**2-.5*sigma_trans**2*kp**2).astype(complex)
        amplitude*=ks>0
        amplitude*=np.exp(-1j*(self.kx*(origin[0]+self.box/2)+self.ky*(origin[1]+self.box/2)))
        polarization=self.p.astype(complex)
        polarization[2]+=1j*helicity
        dplus=polarization*amplitude/np.sqrt(2)
        c0=float(self.local_c(np.array(origin[0]),np.array(origin[1])))
        rho=np.sqrt(np.maximum(0,1-.25*self.dt**2*c0**2*self.knorm**2))
        bplus=np.cross(self.khat,dplus,axisa=0,axisb=0,axisc=0)*rho
        fields=np.ascontiguousarray(np.concatenate([self.rephase(dplus,EOFF),self.rephase(bplus,BOFF)]))
        energy=self.physical_energy(fields)
        fields/=np.sqrt(energy)
        return fields,dict(direction=direction.tolist(),origin=origin.tolist(),helicity=helicity,
                           c_injection=c0,omega_reference=c0*K0,sigma_long=sigma_long,sigma_trans=sigma_trans,
                           initialization='Fourier positive-frequency transverse circular packet; discrete Gauss-free D and B; Yee stagger phases; Verlet eigenmode rho at injection c')

    def allocate(self,e,b):
        return (e[2]+.5*(e[0]+np.roll(e[0],1,0)+e[1]+np.roll(e[1],1,1)+
                       b[0]+np.roll(b[0],1,1)+b[1]+np.roll(b[1],1,0))+
                       .25*(b[2]+np.roll(b[2],1,0)+np.roll(b[2],1,1)+np.roll(b[2],(1,1),(0,1))))

    def density_flux(self,f):
        e=self.ce*f[:3];h=self.cb*f[3:]
        u=self.allocate(.5*e*f[:3],.5*h*f[3:])
        eyx=e[1]+np.roll(e[1],-1,0)
        exy=e[0]+np.roll(e[0],-1,1)
        jx=.25*(eyx*h[2]+np.roll(eyx*h[2],1,1))-.5*(e[2]+np.roll(e[2],-1,0))*h[1]
        jy=.5*(e[2]+np.roll(e[2],-1,1))*h[0]-.25*(exy*h[2]+np.roll(exy*h[2],1,0))
        return u,jx,jy,e,h

    @staticmethod
    def center_e(e):
        return np.array([.5*(e[0]+np.roll(e[0],1,0)),.5*(e[1]+np.roll(e[1],1,1)),e[2]])

    @staticmethod
    def center_b(b):
        return np.array([.5*(b[0]+np.roll(b[0],1,1)),.5*(b[1]+np.roll(b[1],1,0)),
                         .25*(b[2]+np.roll(b[2],1,0)+np.roll(b[2],1,1)+np.roll(b[2],(1,1),(0,1)))])

    def physical_energy(self,f):
        return float(.5*np.sum(self.ce*f[:3]**2+self.cb*f[3:]**2)*self.dx**2)

    def modified_energy(self,f):
        ce=self.curl(self.ce*f[:3])
        return self.physical_energy(f)-.125*self.dt**2*float(np.sum(self.cb*ce**2)*self.dx**2)

    def boundary(self,jx,jy):
        values=np.concatenate([jx[self.ex[:,0],self.ex[:,1]]*self.ex[:,2],
                               jy[self.ey[:,0],self.ey[:,1]]*self.ey[:,2]])*self.dx
        return np.array([values.sum(),values[values>0].sum(),-values[values<0].sum()])

    def advance(self,f,count):
        totals=np.zeros(4)
        if self.native:
            self.native.yee_advance(f,self.ce,self.cb,self.ae,self.ab,self.n,self.dx,self.dt,count,
                                   int(self.sponge),self.damp_substeps,self.ex,len(self.ex),self.ey,len(self.ey),self.scratch,totals)
            return totals
        def damp_half():
            h=.5*self.dt/self.damp_substeps
            absorption=0.
            for _ in range(self.damp_substeps):
                before=self.physical_energy(f)
                dd=-h*self.curl(self.ab*self.curl(self.ce*f[:3]),True)
                db=-h*self.curl(self.ae*self.curl(self.cb*f[3:],True))
                f[:3]+=dd;f[3:]+=db
                absorption+=before-self.physical_energy(f)
            return absorption
        _,jx,jy,_,_=self.density_flux(f)
        previous=self.boundary(jx,jy)
        for _ in range(count):
            if self.sponge:totals[0]+=damp_half()
            f[3:]-=.5*self.dt*self.curl(self.ce*f[:3])
            f[:3]+=self.dt*self.curl(self.cb*f[3:],True)
            f[3:]-=.5*self.dt*self.curl(self.ce*f[:3])
            if self.sponge:totals[0]+=damp_half()
            _,jx,jy,_,_=self.density_flux(f)
            next_flux=self.boundary(jx,jy)
            totals[1:]+=.5*(previous+next_flux)*self.dt
            previous=next_flux
        return totals

    def gauss(self,f):
        d,b=f[:3],f[3:]
        dd=(d[0]-np.roll(d[0],1,0)+d[1]-np.roll(d[1],1,1))/self.dx
        db=(np.roll(b[0],-1,0)-b[0]+np.roll(b[1],-1,1)-b[1])/self.dx
        dn=max(K0*float(np.sqrt(np.sum(d*d,axis=0)).max()),1e-30)
        bn=max(K0*float(np.sqrt(np.sum(b*b,axis=0)).max()),1e-30)
        return {'gauss_D_relative':float(np.abs(dd).max()/dn),'gauss_B_relative':float(np.abs(db).max()/bn),
                'gauss_D_inside_relative':float(np.abs(dd[self.mask]).max()/dn),
                'gauss_B_inside_relative':float(np.abs(db[self.mask]).max()/bn)},dd,db

    def spectral(self,f,angle):
        d,b=self.dephase(f[:3],EOFF),self.dephase(f[3:],BOFF)
        den=float(np.sum(np.abs(d)**2+np.abs(b)**2))
        long=float(np.sum(np.abs(np.sum(self.khat*d,axis=0))**2+np.abs(np.sum(self.khat*b,axis=0))**2))
        direction=np.array([-np.cos(np.radians(angle)),np.sin(np.radians(angle))])
        positive=direction[0]*self.kx+direction[1]*self.ky>0
        ep=np.sum(self.p*d,axis=0)
        ez=d[2]
        norm=(np.abs(ep)**2+np.abs(ez)**2)[positive].sum()
        stokes=float((2*np.imag(ep.conj()*ez))[positive].sum()/max(norm,1e-30))
        return {'longitudinal_fraction':long/max(den,1e-30),'spectral_circular_stokes':stokes}

    def continuum(self,initial,t):
        # Exact continuum Maxwell evolution of the same initial sampled field.
        d,b=self.dephase(initial[:3],EOFF),self.dephase(initial[3:],BOFF)
        k=np.array([self.kx,self.ky,np.zeros_like(self.kx)])
        norm=np.linalg.norm(k,axis=0)
        khat=k/np.maximum(norm,1e-30)
        dl=khat*np.sum(khat*d,axis=0);bl=khat*np.sum(khat*b,axis=0)
        cs=np.cos(self.speed*norm*t);sn=np.sin(self.speed*norm*t)
        dt=dl+cs*(d-dl)+1j*np.cross(khat,b,axisa=0,axisb=0,axisc=0)*sn
        bt=bl+cs*(b-bl)-1j*np.cross(khat,d,axisa=0,axisb=0,axisc=0)*sn
        return np.ascontiguousarray(np.concatenate([self.rephase(dt,EOFF),self.rephase(bt,BOFF)]))

    def phase_probe(self,f,angle,helicity):
        direction=np.array([-np.cos(np.radians(angle)),np.sin(np.radians(angle))])
        i,j=np.unravel_index(np.argmin((self.kx-K0*direction[0])**2+(self.ky-K0*direction[1])**2),self.kx.shape)
        phase=np.exp(-1j*(self.kx[i,j]*self.x+self.ky[i,j]*self.y))
        coeff=np.array([np.sum(f[a]*phase)*np.exp(-1j*(self.kx[i,j]*EOFF[a,0]+self.ky[i,j]*EOFF[a,1])*self.dx) for a in range(3)])
        amplitude=(np.dot(self.p[:,i,j],coeff)-1j*helicity*coeff[2])/np.sqrt(2)
        return amplitude,float(np.hypot(self.kx[i,j],self.ky[i,j])),float(self.knorm[i,j])

    def diagnostics(self,f,omega_ref,local=True):
        u,jx,jy,e,h=self.density_flux(f)
        cx=.5*(jx+np.roll(jx,1,0));cy=.5*(jy+np.roll(jy,1,1))
        ecenter=self.center_e(e);hcenter=self.center_b(h)
        cz=np.cross(ecenter,hcenter,axisa=0,axisb=0,axisc=0)[2]
        ein=float(u[self.mask].sum()*self.dx**2)
        etot=float(u.sum()*self.dx**2)
        rr=np.maximum(self.r,self.dx/2)
        jr=(self.x*cx+self.y*cy)/rr;jt=(-self.y*cx+self.x*cy)/rr
        speed=np.hypot(cx,cy)
        metrics={'E_box':etot,'E_inside':ein,'E_outside':etot-ein,
                 'mean_speed_flux':float(speed[self.mask].sum()*self.dx**2/max(ein,1e-30)),
                 'mean_abs_radial_flux':float(np.abs(jr[self.mask]).sum()*self.dx**2/max(ein,1e-30)),
                 'mean_abs_tangential_flux':float(np.abs(jt[self.mask]).sum()*self.dx**2/max(ein,1e-30)),
                 'signed_radial_flux':float(jr[self.mask].sum()*self.dx**2/max(ein,1e-30)),
                 'signed_tangential_flux':float(jt[self.mask].sum()*self.dx**2/max(ein,1e-30)),
                 'centroid_x':float((u*self.x).sum()*self.dx**2/max(etot,1e-30)),
                 'centroid_y':float((u*self.y).sum()*self.dx**2/max(etot,1e-30)),
                 'net_Jx':float(cx.sum()*self.dx**2),'net_Jy':float(cy.sum()*self.dx**2),
                 'local_transport_cancellation':float(np.hypot(cx[self.mask].sum(),cy[self.mask].sum())/max(speed[self.mask].sum(),1e-30))}
        peak=np.unravel_index(np.argmax(u),u.shape)
        metrics.update(peak_x=float(self.x[peak]),peak_y=float(self.y[peak]))
        flux=self.boundary(jx,jy)
        metrics.update(net_outward_flux_R=float(flux[0]),outward_flux_R=float(flux[1]),inward_flux_R=float(flux[2]))
        gauss,dd,db=self.gauss(f);metrics.update(gauss)
        estimated_ppw=2*np.pi*self.cnode*self.ppw/max(omega_ref,1e-30)
        unresolved=(estimated_ppw<PREREG['short_cavity_acceptance']['minimum_points_per_local_wavelength_warning'])&self.mask
        metrics['estimated_underresolved_energy_fraction']=float(u[unresolved].sum()*self.dx**2/max(ein,1e-30))
        maps={'energy_density':u,'Jx':cx,'Jy':cy,'Jz':cz,'gauss_D':dd,'gauss_B':db,'estimated_points_per_wavelength':estimated_ppw}
        if local:
            curlh=self.curl(h,True)
            ec=ecenter+1j*self.center_e(self.ce*curlh)/max(omega_ref,1e-30)
            sv=np.array([cx,cy,cz]);norm=np.linalg.norm(sv,axis=0)
            nhat=sv/np.maximum(norm,1e-30)
            p=np.array([-cy,cx,np.zeros_like(cx)])/np.maximum(speed,1e-30)
            q=np.cross(nhat,p,axisa=0,axisb=0,axisc=0)
            ep=np.sum(p*ec,axis=0);eq=np.sum(q*ec,axis=0)
            intensity=np.abs(ep)**2+np.abs(eq)**2
            stokes=2*np.imag(ep.conj()*eq)/np.maximum(intensity,1e-30)
            long=np.abs(np.sum(nhat*ec,axis=0))**2/np.maximum(np.sum(np.abs(ec)**2,axis=0),1e-30)
            valid=(norm>.05*self.cnode*u)&(u>1e-8*max(float(u.max()),1e-30))&self.mask
            weights=u*valid;den=max(float(weights.sum()),1e-30)
            metrics.update(local_circular_stokes_mean=float(np.sum(stokes*weights)/den),
                           local_abs_circular_stokes_mean=float(np.sum(np.abs(stokes)*weights)/den),
                           local_longitudinal_E_proxy=float(np.sum(long*weights)/den),
                           local_polarization_valid_energy_fraction=float(weights.sum()*self.dx**2/max(ein,1e-30)))
            maps.update(local_circular_stokes=stokes,local_longitudinal_E_proxy=long,local_polarization_valid=valid)
        return metrics,maps

    def continuity(self,f):
        _,jx,jy,e,h=self.density_flux(f)
        dd=self.curl(h,True);db=-self.curl(e)
        du=self.allocate(e*dd,h*db)
        div=(jx-np.roll(jx,1,0)+jy-np.roll(jy,1,1))/self.dx
        residual=du+div
        scale=max(float(np.abs(du).max()+np.abs(div).max()),1e-30)
        return {'max_abs':float(np.abs(residual).max()),'relative_max':float(np.abs(residual).max()/scale),
                'meaning':'instantaneous semidiscrete Maxwell identity, excludes sponge and time discretization'}


def plot_map(path,grid,maps,t):
    import matplotlib
    matplotlib.use('Agg')
    import matplotlib.pyplot as plt
    from matplotlib.patches import Circle
    fig,ax=plt.subplots(figsize=(7,6),layout='constrained')
    im=ax.imshow(maps['energy_density'].T,origin='lower',extent=[grid.coords[0],grid.coords[-1],grid.coords[0],grid.coords[-1]])
    stride=max(1,grid.ppw//2);ix=slice(None,None,stride)
    jx,jy=maps['Jx'],maps['Jy'];scale=max(float(np.hypot(jx,jy).max()),1e-30)/.45
    ax.quiver(grid.x[ix,ix],grid.y[ix,ix],jx[ix,ix],jy[ix,ix],color='white',angles='xy',scale_units='xy',scale=scale,width=.003)
    ax.add_patch(Circle((0,0),grid.radius,fill=False,color='red',ls='--'))
    ax.set(xlim=(-1.4*grid.radius,1.4*grid.radius),ylim=(-1.4*grid.radius,1.4*grid.radius),xlabel='x / λ',ylabel='y / λ',title=f'[M] Maxwell 2D3V exploratório | t={t:.3f}')
    fig.colorbar(im,ax=ax,label='u (energia normalizada)')
    fig.savefig(path,dpi=120);plt.close(fig)


def run_case(output,angle=75.,helicity=1,ppw=20,box=16.,radius=4.,dt=.018,tmax=30.,
             medium='cavity',speed=1.,sponge=True,sponge_start=6.5,sponge_eta=.045594532639052,
             sample_interval=.18,plots=False,free_validation=False,backend='auto'):
    output=Path(output)
    if output.exists():raise FileExistsError(f'Refusing overwrite: {output}')
    started=now();wall=time.monotonic()
    grid=Grid(ppw,box,radius,dt,medium,speed,sponge,sponge_start,sponge_eta,backend)
    initial,fconfig=grid.initial(angle,helicity,origin=[0.,0.] if free_validation else None)
    fields=initial.copy()
    output.mkdir(parents=True)
    meta={'bench':PREREG['bench'],'status':PREREG['model_label'],'started':started,
          'parameters':dict(angle=angle,helicity=helicity,ppw=ppw,box=box,radius=radius,dt=dt,tmax=tmax,
                            medium=medium,speed=speed,sponge=sponge,sponge_start=sponge_start,sponge_eta=sponge_eta,
                            sample_interval=sample_interval,free_validation=free_validation),
          'initialization':fconfig,'n':grid.n,'dx':grid.dx,'backend':'C++' if grid.native else 'NumPy',
          'damping_substeps_per_halfstep':grid.damp_substeps,'config_sha256':sha(ROOT/'config_preregistered.json'),
          'python_sha256':sha(__file__),'kernels_sha256':sha(ROOT/'yee_kernels.cpp'),
          'HRF_CAP2_GATE':'NOT_TESTED','photonic_identity_local':'NOT_CERTIFIED',
          'map_arrays':'float32 derived u/Poynting/Gauss/polarization diagnostics; evolved fields float64',
          'absorber':'Ddot=-C^T eta_B C E; Bdot=-C eta_E C^T H, only in outer layer; exact measured discrete physical-energy removal; stable positive subcycling; no projection'}
    write_json(output/'metadata.json',meta)
    e0=grid.physical_energy(fields)
    metric0,_=grid.diagnostics(fields,fconfig['omega_reference'])
    ein0=metric0['E_inside'];absorbed=0.;cumulative=np.zeros(3)
    nsteps=round(tmax/dt);sample_steps=max(1,round(sample_interval/dt))
    map_times=[0.,tmax] if free_validation else [0.,10.,20.,30.,150.,300.,500.,tmax]
    map_steps={min(nsteps,round(t/dt)) for t in map_times if t<=tmax}
    sample_set=set(range(0,nsteps+1,sample_steps))|{nsteps}|map_steps
    rows=[];phase=[];times=[];continuities=[]
    uavg=np.zeros((grid.n,grid.n));u2avg=uavg.copy();jxavg=uavg.copy();jyavg=uavg.copy();jabsavg=uavg.copy();nav=0
    late_start=min(30.,tmax/3)
    def snapshot(step):
        nonlocal nav
        t=step*dt
        metrics,maps=grid.diagnostics(fields,fconfig['omega_reference'])
        metrics.update(t=t,F_in=metrics['E_inside']/max(metrics['E_box'],1e-30),F_rem=metrics['E_inside']/e0,
                       absorbed_energy=absorbed,cumulative_net_outward_flux=cumulative[0],
                       cumulative_outward_flux=cumulative[1],cumulative_inward_flux=cumulative[2],
                       global_energy_balance_error=(metrics['E_box']+absorbed-e0)/e0,
                       interior_energy_balance_error=(metrics['E_inside']-ein0+cumulative[0])/e0,
                       modified_energy=grid.modified_energy(fields))
        if not np.isfinite(list(metrics.values())).all():
            raise FloatingPointError('Non-finite metrics; preserve this output directory')
        rows.append(metrics)
        if free_validation:
            amplitude,kcontinuum,kyee=grid.phase_probe(fields,angle,helicity)
            phase.append(float(np.angle(amplitude)));times.append(t)
        if t>=late_start:
            uavg[:]+=maps['energy_density'];u2avg[:]+=maps['energy_density']**2
            jxavg[:]+=maps['Jx'];jyavg[:]+=maps['Jy'];jabsavg[:]+=np.hypot(maps['Jx'],maps['Jy']);nav+=1
        if step in map_steps:
            np.savez_compressed(output/f'map_t_{t:09.3f}.npz',t=t,x=grid.coords,y=grid.coords,
                                **{k:np.asarray(v,dtype=np.float32) for k,v in maps.items()})
            continuity=grid.continuity(fields);continuities.append(continuity)
            write_json(output/f'continuity_t_{t:09.3f}.json',continuity)
            if plots:plot_map(output/f'map_t_{t:09.3f}.png',grid,maps,t)
        return metrics
    current=0;snapshot(0)
    for step in sorted(sample_set-{0}):
        total=grid.advance(fields,step-current);absorbed+=total[0];cumulative+=total[1:]
        current=step;snapshot(step)
    with (output/'timeline.csv').open('w',newline='') as f:
        writer=csv.DictWriter(f,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)
    uavg/=max(nav,1);u2avg/=max(nav,1);jxavg/=max(nav,1);jyavg/=max(nav,1);jabsavg/=max(nav,1)
    ustd=np.sqrt(np.maximum(0,u2avg-uavg**2))
    directionality=float(np.hypot(jxavg,jyavg)[grid.mask].sum()/max(jabsavg[grid.mask].sum(),1e-30))
    variability=float(ustd[grid.mask].sum()/max(uavg[grid.mask].sum(),1e-30))
    np.savez_compressed(output/'late_time_averages.npz',x=grid.coords,y=grid.coords,t_min=late_start,n_samples=nav,
                        energy_density_mean=uavg.astype(np.float32),energy_density_std=ustd.astype(np.float32),
                        Jx_mean=jxavg.astype(np.float32),Jy_mean=jyavg.astype(np.float32),J_abs_mean=jabsavg.astype(np.float32))
    summary={'status':PREREG['model_label'],'angle':angle,'helicity':helicity,'energy_initial':e0,
             'energy_inside_initial':ein0,'final':rows[-1],'n_samples':len(rows),'n_steps':nsteps,
             'max_global_balance_error':max(abs(r['global_energy_balance_error']) for r in rows),
             'max_inside_balance_error':max(abs(r['interior_energy_balance_error']) for r in rows),
             'max_gauss_relative':max(max(r['gauss_D_relative'],r['gauss_B_relative']) for r in rows),
             'max_continuity_relative':max(c['relative_max'] for c in continuities),
             'late_flux_directionality':directionality,'late_density_variability':variability,
             'numerically_finite':True,'HRF_CAP2_GATE':'NOT_TESTED','local_photonic_identity':'NOT_CERTIFIED',
             'local_polarization_definition':'E+i*dE/dt/omega_ref; circular Stokes about instantaneous local Poynting direction; narrowband directional proxy, not a local HRF photon gate',
             'wall_seconds':time.monotonic()-wall,'finished':now()}
    flags=[]
    if rows[-1]['F_rem']<.5:flags.append('F: fuga/aprisionamento transitório [M]')
    late=rows[len(rows)//2:]
    mean_transport=float(np.mean([r['mean_speed_flux'] for r in late]))
    if mean_transport>.05:flags.append('transporte energético interno detectado [M]')
    tang=np.array([r['signed_tangential_flux'] for r in late]);tangabs=np.array([r['mean_abs_tangential_flux'] for r in late])
    if abs(tang.mean())/max(float(tangabs.mean()),1e-30)>.3 and tangabs.mean()>.05:
        flags.append('D: candidato a circulação parcial [M], flag heurística')
    threshold=.1*max(float(np.abs(tang).max()),1e-30);sign=np.sign(tang[np.abs(tang)>threshold])
    if len(sign)>1 and np.sum(sign[:-1]*sign[1:]<0)>=3:
        flags.append('C: candidato a sloshing angular [M], flag heurística')
    if directionality<.15 and variability<.25:
        flags.append('E: candidato a padrão quase-estacionário [M], flag heurística')
    flags.extend(['A: onda fotônica viajante confinada NÃO DEMONSTRADA','B: ricochete/refração requer inspeção de mapas','G: quase-ligado NÃO APROVADO'])
    summary['classification_flags']=flags
    if free_validation:
        spectral=grid.spectral(fields,angle)
        _,kcontinuum,kyee=grid.phase_probe(fields,angle,helicity)
        ref=grid.continuum(initial,current*dt)
        exactmetrics,_=grid.diagnostics(ref,fconfig['omega_reference'],local=False)
        error=np.sqrt(np.sum(grid.ce*(fields[:3]-ref[:3])**2+grid.cb*(fields[3:]-ref[3:])**2)/
                      np.sum(grid.ce*ref[:3]**2+grid.cb*ref[3:]**2))
        displacement=np.array([rows[-1]['centroid_x']-rows[0]['centroid_x'],rows[-1]['centroid_y']-rows[0]['centroid_y']])
        exactdisplacement=np.array([exactmetrics['centroid_x']-rows[0]['centroid_x'],exactmetrics['centroid_y']-rows[0]['centroid_y']])
        measured=-float(np.polyfit(times,np.unwrap(phase),1)[0])
        summary['free_validation']={**spectral,'continuum_field_relative_L2_error':float(error),
                                   'measured_omega':measured,'continuum_probe_omega':speed*kcontinuum,
                                   'Yee_Verlet_probe_omega':float(2*np.arcsin(.5*dt*speed*kyee)/dt),
                                   'dispersion_relative_error':abs(measured-speed*kcontinuum)/(speed*kcontinuum),
                                   'envelope_velocity_error':float(np.linalg.norm(displacement-exactdisplacement)/(current*dt*speed)),
                                   'envelope_velocity_observed':(displacement/(current*dt)).tolist(),
                                   'envelope_velocity_continuum_reference':(exactdisplacement/(current*dt)).tolist(),
                                   'momentum_energy_ratio':float(np.hypot(rows[-1]['net_Jx'],rows[-1]['net_Jy'])/rows[-1]['E_box']),
                                   'momentum_convention':'vacuum Abraham=Minkowski, c_vacuum=1; finite packet angular spread reduces |P|/E',
                                   'physical_energy_max_drift':max(abs(r['E_box']/e0-1) for r in rows),
                                   'modified_energy_max_drift':max(abs(r['modified_energy']/rows[0]['modified_energy']-1) for r in rows)}
        # Retain actual terminal fields for independent temporal comparisons.
        np.savez_compressed(output/'free_terminal_fields.npz',D=fields[:3],B=fields[3:],t=current*dt)
    write_json(output/'summary.json',summary)
    print(f"[M] {output.name}: T={current*dt:.3f} F_rem={rows[-1]['F_rem']:.6f} Gauss={summary['max_gauss_relative']:.3e} wall={summary['wall_seconds']:.1f}s",flush=True)
    return summary


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--angle',type=float,default=75.)
    p.add_argument('--helicity',type=int,choices=(-1,1),default=1)
    p.add_argument('--ppw',type=int,default=20)
    p.add_argument('--box',type=float,default=16.)
    p.add_argument('--radius',type=float,default=4.)
    p.add_argument('--dt',type=float,default=.018)
    p.add_argument('--tmax',type=float,default=30.)
    p.add_argument('--medium',choices=('cavity','uniform'),default='cavity')
    p.add_argument('--speed',type=float,default=1.)
    p.add_argument('--no-sponge',dest='sponge',action='store_false')
    p.add_argument('--sponge-start',type=float,default=6.5)
    p.add_argument('--sponge-eta',type=float,default=.045594532639052)
    p.add_argument('--sample-interval',type=float,default=.18)
    p.add_argument('--plots',action='store_true')
    p.add_argument('--free-validation',action='store_true')
    p.add_argument('--backend',choices=('auto','native','numpy'),default='auto')
    run_case(**vars(p.parse_args()))


if __name__=='__main__':main()
