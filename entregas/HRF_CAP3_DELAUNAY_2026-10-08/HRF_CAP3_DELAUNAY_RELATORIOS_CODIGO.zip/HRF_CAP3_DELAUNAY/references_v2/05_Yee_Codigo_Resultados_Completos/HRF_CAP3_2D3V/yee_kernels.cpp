#include <cmath>
#include <algorithm>

// E locations: (i+1/2,j), (i,j+1/2), (i,j).
// B locations: (i,j+1/2), (i+1/2,j), (i+1/2,j+1/2).
// C^T is the adjoint of C in the periodic discrete inner product.
static void curl(const double* v, double* w, int n, double invdx, bool adjoint) {
    const int m=n*n;
    for(int i=0;i<n;i++) {
        const int ip=(i+1)%n, im=(i+n-1)%n;
        for(int j=0;j<n;j++) {
            const int jp=(j+1)%n,jm=(j+n-1)%n,a=i*n+j;
            if(!adjoint) {
                w[a]=(v[2*m+i*n+jp]-v[2*m+a])*invdx;
                w[m+a]=-(v[2*m+ip*n+j]-v[2*m+a])*invdx;
                w[2*m+a]=(v[m+ip*n+j]-v[m+a]-v[i*n+jp]+v[a])*invdx;
            } else {
                w[a]=(v[2*m+a]-v[2*m+i*n+jm])*invdx;
                w[m+a]=-(v[2*m+a]-v[2*m+im*n+j])*invdx;
                w[2*m+a]=(v[m+a]-v[m+im*n+j]-v[a]+v[i*n+jm])*invdx;
            }
        }
    }
}

static double xflux(const double* f,const double* ce,const double* cb,int n,int i,int j) {
    const int m=n*n,ip=(i+1)%n,jm=(j+n-1)%n,a=i*n+j,b=ip*n+j,c=i*n+jm,d=ip*n+jm;
    auto e=[&](int k,int q){return ce[k*m+q]*f[k*m+q];};
    auto h=[&](int k,int q){return cb[k*m+q]*f[(k+3)*m+q];};
    return .25*((e(1,a)+e(1,b))*h(2,a)+(e(1,c)+e(1,d))*h(2,c))-.5*(e(2,a)+e(2,b))*h(1,a);
}
static double yflux(const double* f,const double* ce,const double* cb,int n,int i,int j) {
    const int m=n*n,im=(i+n-1)%n,jp=(j+1)%n,a=i*n+j,b=i*n+jp,c=im*n+j,d=im*n+jp;
    auto e=[&](int k,int q){return ce[k*m+q]*f[k*m+q];};
    auto h=[&](int k,int q){return cb[k*m+q]*f[(k+3)*m+q];};
    return .5*(e(2,a)+e(2,b))*h(0,a)-.25*((e(0,a)+e(0,b))*h(2,a)+(e(0,c)+e(0,d))*h(2,c));
}
static void boundary(const double* f,const double* ce,const double* cb,int n,double dx,
                     const int* ex,int nx,const int* ey,int ny,double* result) {
    result[0]=result[1]=result[2]=0;
    for(int q=0;q<nx;q++) {
        const double a=xflux(f,ce,cb,n,ex[3*q],ex[3*q+1])*ex[3*q+2]*dx;
        result[0]+=a; if(a>0)result[1]+=a;else result[2]-=a;
    }
    for(int q=0;q<ny;q++) {
        const double a=yflux(f,ce,cb,n,ey[3*q],ey[3*q+1])*ey[3*q+2]*dx;
        result[0]+=a; if(a>0)result[1]+=a;else result[2]-=a;
    }
}
static double damp(double* f,const double* ce,const double* cb,const double* ae,const double* ab,
                   double h,int substeps,int n,double invdx,double* scratch) {
    const int m=n*n,all=3*m; double absorption=0;
    double *e=scratch,*hh=scratch+all,*c_e=scratch+2*all,*c_h=scratch+3*all,
           *rhs_d=scratch+4*all,*rhs_b=scratch+5*all;
    h/=substeps;
    for(int s=0;s<substeps;s++) {
        for(int q=0;q<all;q++){e[q]=ce[q]*f[q];hh[q]=cb[q]*f[all+q];}
        curl(e,c_e,n,invdx,false);curl(hh,c_h,n,invdx,true);
        for(int q=0;q<all;q++){c_e[q]*=ab[q];c_h[q]*=ae[q];}
        curl(c_e,rhs_d,n,invdx,true);curl(c_h,rhs_b,n,invdx,false);
        for(int q=0;q<all;q++) {
            const double dd=-h*rhs_d[q],db=-h*rhs_b[q];
            absorption-=ce[q]*(f[q]*dd+.5*dd*dd)+cb[q]*(f[all+q]*db+.5*db*db);
            f[q]+=dd;f[all+q]+=db;
        }
    }
    return absorption/(invdx*invdx);
}

extern "C" {
void yee_curl(const double* v,double* w,int n,double dx,int adjoint) {curl(v,w,n,1./dx,adjoint!=0);}
void yee_boundary(const double* f,const double* ce,const double* cb,int n,double dx,
                  const int* ex,int nx,const int* ey,int ny,double* result) {
    boundary(f,ce,cb,n,dx,ex,nx,ey,ny,result);
}
void yee_advance(double* f,const double* ce,const double* cb,const double* ae,const double* ab,
                 int n,double dx,double dt,int count,int absorbing,int substeps,
                 const int* ex,int nx,const int* ey,int ny,double* scratch,double* totals) {
    const int all=3*n*n; const double invdx=1./dx;
    double *e=scratch,*hh=scratch+all,*cc=scratch+2*all;
    double previous[3],next[3]; boundary(f,ce,cb,n,dx,ex,nx,ey,ny,previous);
    for(int q=0;q<4;q++)totals[q]=0;
    for(int step=0;step<count;step++) {
        if(absorbing)totals[0]+=damp(f,ce,cb,ae,ab,.5*dt,substeps,n,invdx,scratch);
        for(int q=0;q<all;q++)e[q]=ce[q]*f[q];
        curl(e,cc,n,invdx,false);
        for(int q=0;q<all;q++)f[all+q]-=.5*dt*cc[q];
        for(int q=0;q<all;q++)hh[q]=cb[q]*f[all+q];
        curl(hh,cc,n,invdx,true);
        for(int q=0;q<all;q++)f[q]+=dt*cc[q];
        for(int q=0;q<all;q++)e[q]=ce[q]*f[q];
        curl(e,cc,n,invdx,false);
        for(int q=0;q<all;q++)f[all+q]-=.5*dt*cc[q];
        if(absorbing)totals[0]+=damp(f,ce,cb,ae,ab,.5*dt,substeps,n,invdx,scratch);
        boundary(f,ce,cb,n,dx,ex,nx,ey,ny,next);
        for(int q=0;q<3;q++)totals[q+1]+=.5*(previous[q]+next[q])*dt;
        for(int q=0;q<3;q++)previous[q]=next[q];
    }
}
}
