"""Execute the requested long bench only if both numerical stage gates pass."""
import json,subprocess,sys,os,time
from concurrent.futures import ThreadPoolExecutor,as_completed
from hrf_maxwell_2d3v import ROOT,PREREG,write_json,now,sha

free=json.loads((ROOT/'FREE_GATE_RESULTS.json').read_text())
short=json.loads((ROOT/'CAVITY_GATE_RESULTS.json').read_text())
if free['Maxwell_2D3V_GATE']!='PASS' or short['status']!='PASS':
    write_json(ROOT/'LONG_STAGE_STATUS.json',dict(status='NOT_EXECUTED',reason='Preregistered free or short numerical gate failed',free_gate=free['Maxwell_2D3V_GATE'],short_gate=short['status'],short_failures=short.get('failures',[]),requested_times=PREREG['long']['times']))
    print('Long bench stopped by preregistered numerical gate.');sys.exit(0)
jobs=[dict(angle=a,helicity=h,ppw=20,dt=.018,tmax=500) for a in (45,60,75,90) for h in (1,-1)]
# Long-time sensitivity at the intermediate milestone, when the short tests pass.
for h in (1,-1):
    jobs.extend([dict(angle=75,helicity=h,ppw=24,dt=.009,tmax=150),dict(angle=75,helicity=h,ppw=32,dt=.009,tmax=150),
                 dict(angle=75,helicity=h,ppw=20,dt=.009,tmax=150),dict(angle=75,helicity=h,ppw=20,dt=.018,tmax=150,box=20,sponge_start=7.5)])
for scale in (.5,2):jobs.append(dict(angle=75,helicity=1,ppw=20,dt=.018,tmax=150,sponge_eta=PREREG['base']['sponge_eta_max']*scale))
def name(p):return 'long_'+('_'.join(f'{k}{v}' for k,v in p.items()))
write_json(ROOT/'LONG_PREREGISTRATION.json',dict(time=now(),config_sha256=sha(ROOT/'config_preregistered.json'),jobs=jobs,rule='No promotion to converged confinement if later controls fail'))
def run(p):
    label=name(p);cmd=[sys.executable,'-u',str(ROOT/'hrf_maxwell_2d3v.py'),'--output',str(ROOT/'results'/label),'--plots']
    for k,v in p.items():cmd.extend(['--'+k.replace('_','-'),str(v)])
    env=os.environ.copy();env.update(MPLCONFIGDIR='/tmp/hrf-matplotlib',XDG_CACHE_HOME='/tmp/hrf-cache',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    start=now();wall=time.monotonic();print('START '+label,flush=True)
    with (ROOT/'logs'/(label+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT)
    rec=dict(name=label,command=cmd,parameters=p,exit_code=r.returncode,started=start,finished=now(),wall_seconds=time.monotonic()-wall)
    write_json(ROOT/'logs'/(label+'.execution.json'),rec);print(f'DONE {label}: exit={r.returncode}',flush=True);return rec
with ThreadPoolExecutor(max_workers=3) as pool:records=[f.result() for f in as_completed([pool.submit(run,p) for p in jobs])]
write_json(ROOT/'long_execution.json',records)
write_json(ROOT/'LONG_STAGE_STATUS.json',dict(status='COMPLETED' if all(r['exit_code']==0 for r in records) else 'EXECUTION_FAILURE',records=records,convergence='See independent controls; completion does not assert convergence',HRF_CAP2_GATE='NOT_TESTED'))
