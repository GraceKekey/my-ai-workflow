# HRF — Reexecução das bancadas com o modo fotônico do Capítulo 2
## ELETRON-45R / 47R / 49R / 51R / 53R — revisão fotônica controlada

**Data:** 7 de outubro de 2026  
**Framework:** Holographic Reconstruction Framework (HRF)  
**Ramo:** HRF-FM — *Fields and Matter Reconstruction*  
**Status:** toy model [M]; revisão metodológica das bancadas anteriores  

## 0. Motivo da revisão

As bancadas anteriores usaram, em parte, pacotes lineares ou perturbações genéricas do campo de gauge. Isso não é suficiente para chamá-los de fótons do HRF.

Nesta revisão, cada pacote estruturado é substituído pelo modo circular transversal do Capítulo 2:

\[
\mathbf A=g\,[\mathbf e_1\cos\theta+h\,\mathbf e_2\sin\theta],\qquad h=\pm1,
\]

com \(\mathbf e_1,\mathbf e_2\perp\mathbf n\), seguido da projeção transversal da rede. Assim, a excitação possui o **pequeno saca-rolha** da polarização/helicidade, enquanto a trajetória do envelope continua sendo uma variável dinâmica independente.

A formação da cavidade foi também refeita com quatro pacotes circulares de helicidades balanceadas \((+,-,+,-)\), preservando os demais parâmetros principais da formação anterior: \(N=28\), \(dt=0,025\), \(R_0=7,5\), \(E_{\rm form}=120\) e \(k_{\rm form}=1,2\).

> **Limite metodológico:** esta é uma implementação Cap.-2-consistente dentro da malha cúbica de ligações/curl-curl usada pela ELETRON-43. Ela corrige a natureza local do pacote (polarização circular/helicidade e setor transversal), mas ainda não transplanta toda a implementação irregular/Whitney do fechamento B1 para o solver de cavidade.

---

# 1. Portão fotônico

Foi aplicado um `PHOTON-INJECTION GATE` em fundo uniforme. Critérios: circularidade \(|\mathcal C|\ge0,90\), Gauss \(\le10^{-10}\), deriva de energia \(\le10^{-4}\) e deslocamento do centro de energia para frente.

| \(k\) | uso | \(\omega/k\) | circularidade inicial | final | PASS? |
|---:|---|---:|---:|---:|:---:|
| 0,1327 | \(\beta=0,5\) | 0,9993 | 0,193 | 0,349 | **não** |
| 0,2654 | \(\beta=1\) | 0,9971 | 0,645 | 0,872 | **não** |
| 0,4500 | probes E45 | 0,9916 | 0,973 | 0,997 | **sim** |
| 0,5309 | \(\beta=2\) | 0,9883 | 0,994 | 0,9996 | **sim** |
| 1,0617 | \(\beta=4\) | 0,9537 | ~1,000 | ~1,000 | **sim** |
| 1,2000 | formação | 0,9411 | ~1,000 | ~1,000 | **sim** |

A helicidade oposta em \(k=0,45\) também passou, com circularidade \(-0,973\to-0,997\).

### Resultado metodológico importante

O ramo \(\beta=kR=1\), usado anteriormente como identificação direta com a Compton reduzida, **não passa o portão como pacote fotônico localizado nesta caixa**.

Para a cavidade controlada,

\[
R_{0.8}=3,7675,
\qquad
k_{\beta=1}=0,2654,
\]

logo

\[
\lambda=\frac{2\pi}{k}\approx23,67,
\]

isto é, aproximadamente

\[
\lambda\approx2\pi R_{0.8}.
\]

A interpretação mais conservadora é que o pacote usado anteriormente é espacialmente curto demais para representar uma volta completa da polarização circular nessa escala. Isso **não falsifica \(\beta=1\)**; mostra que o teste precisa de uma caixa maior ou de uma descrição do fóton curvada ao longo de uma trajetória ligada.

---

# 2. Cavidade formada somente com pacotes fotônicos circulares

A formação controlada produziu:

\[
V_{0.8}=224,
\qquad
R_{0.8}=3,7675,
\]

\[
V_{\rm slow}=104,
\qquad
R_{\rm slow}=2,9173.
\]

Portanto, a cavidade profunda e a região de baixa propagação **não dependem da polarização linear antiga**: elas também aparecem quando toda a energia de formação é colocada em pacotes circulares do tipo Capítulo 2 [M].

---

# 3. ELETRON-45R — barreira para probes fotônicos verdadeiros

Os probes em \(k=0,45\) passaram no portão fotônico.

## Probes radiais entrando

| lançamento | \(r_{\min}\) cavidade | \(r_{\min}\) uniforme |
|---:|---:|---:|
| 4,5 | 3,061 | 0,458 |
| 5,5 | 2,619 | 0,495 |
| 6,5 | 2,119 | 0,675 |

Os pacotes penetram muito menos no centro que no fundo uniforme. Entretanto, dentro do horizonte testado, o raio mínimo ainda ocorre no final da execução: **não foi observado um ponto de retorno completo**.

Nos probes tangenciais, o desvio relativo passa de interno/negativo em \(r=2,5\) para aproximadamente nulo em \(r=3,5\) e claramente externo em \(r=4,5\) e \(5,5\). Em \(r=4,5\), as duas helicidades deram resultados semelhantes.

### Veredito

\[
\boxed{\text{BARREIRA / EXCLUSÃO FOTÔNICA: ROBUSTA [M]}}
\]

\[
\boxed{\text{REPULSÃO GEOMÉTRICA VERDADEIRA: AINDA NÃO DEMONSTRADA [?]}}
\]

A conclusão principal da antiga E45 sobrevive à correção fotônica.

---

# 4. ELETRON-47R — um ou dois pacotes fotônicos dentro da cavidade

O antigo \(\beta=1\) foi executado por comparação, mas **não pode ser usado como resultado fotônico**, pois falha no portão de circularidade.

A comparação fotônica válida foi refeita em \(\beta=2\), onde o pacote passa pelo gate.

Média tardia \(t=15\)–30:

| caso | \(\langle V_{0.8}\rangle\) | mudança vs cavidade drenada |
|---|---:|---:|
| sem novo campo | 98,93 | — |
| 1 pacote, \(h=+1\) | 106,67 | +7,8% |
| 1 pacote, \(h=-1\) | 107,80 | +9,0% |
| 2 co-rotantes, \((+,+)\) | 107,67 | +8,8% |
| **2 co-rotantes, \((+,-)\)** | **111,53** | **+12,7%** |
| 2 contra-rotantes, \((+,+)\) | 109,93 | +11,1% |

### O que mudou em relação à conclusão antiga

A afirmação antiga “**co-rotação é claramente a melhor configuração**” **não é robusta**.

Com pacotes Cap.-2 válidos:
- todos os casos testados sustentam mais volume que a cavidade drenada nessa janela;
- co-rotação continua podendo ajudar;
- mas o melhor caso foi co-rotante com helicidades opostas;
- o controle contra-rotante ficou muito próximo.

Logo, nesta bancada, a sustentação **não é determinada simplesmente pelo OAM orbital total**.

As helicidades \(+1\) e \(-1\) isoladas deram resultados próximos, consistente com ausência de forte seleção de mão no fundo estático.

---

# 5. ELETRON-49R — varredura de \(\beta=kR\)

A varredura direta produziu:

| \(\beta\) | status fotônico do pacote | \(\langle V_{0.8}\rangle_{15-25}\) |
|---:|:---:|---:|
| 0,5 | **gate FAIL** | 100,3 |
| 1 | **gate FAIL** | 100,3 |
| 2 | **gate PASS** | 99,7 |
| 4 | **gate PASS** | 97,7 |

A cavidade sem nova injeção, na mesma janela, ficou em aproximadamente

\[
\langle V_{0.8}\rangle_{\rm base}=102,3.
\]

Assim, entre os ramos que realmente passam pelo portão fotônico, **não apareceu uma ressonância de sustentação**. \(\beta=2\) foi menos desfavorável que \(\beta=4\), mas ambos ficaram abaixo do baseline nessa janela específica.

### Consequência

A antiga conclusão “máximo amplo próximo de \(\beta\sim2\)” deve ser enfraquecida. O novo resultado é:

\[
\boxed{\text{nenhuma ressonância fotônica válida demonstrada [M/?]}}
\]

E \(\beta=1\) permanece **não testado adequadamente como fóton localizado** nesta geometria/caixa.

---

# 6. ELETRON-51R — drenagem do campo fotônico válido

Foi usado o ramo válido \(\beta=2\). Após 15 unidades de organização, duas cópias idênticas foram criadas; numa delas o campo foi removido.

Média entre 10 e 20 após a intervenção:

\[
\langle V_{0.8}\rangle_{\rm campo}=111,64,
\]

\[
\langle V_{0.8}\rangle_{\rm drenado}=79,73.
\]

O estado com campo manteve aproximadamente

\[
\boxed{40,0\%}
\]

mais volume que a cópia drenada.

### Veredito

\[
\boxed{\text{O CAMPO FOTÔNICO INJETADO CONTRIBUI CAUSALMENTE PARA SUSTENTAR A CAVIDADE [M]}}
\]

Essa é a conclusão anterior que **sobreviveu de forma mais clara** à correção do modelo fotônico.

A drenagem continua sendo uma intervenção não Hamiltoniana: ela demonstra dependência causal operacional, não comparação entre dois estados de mesma energia.

---

# 7. ELETRON-53R — morfologia usando somente pacotes fotônicos válidos

Os campos aleatórios da E53 antiga foram retirados da análise fotônica. Foram usados somente:

- ONE_H+;
- ONE_H-;
- COROT_++;
- COROT_+-;
- COUNTER_++;
- TETRA_BAL.

Todos usam \(\beta=2\), que passa o portão fotônico.

### Resultado radial

A similaridade média entre os seis perfis radiais tardios permaneceu alta:

\[
\boxed{\langle S\rangle=0,9834}
\]

mas a dispersão do raio de pico foi

\[
\boxed{\sigma(r_{\rm peak})=0,702}
\]

acima do critério antigo de 0,60.

As classes angulares ficaram divididas igualmente:

\[
3\ \text{anisotrópicas},\qquad3\ \text{isotrópicas}.
\]

Além disso, aproximadamente 43–53% da energia de campo tardia ficou na região classificada como `far`, mostrando que uma parcela grande do campo continua escapando/ocupando a região externa.

### Veredito revisado

A frase antiga

> “convergência radial sem morfologia angular única”

fica **enfraquecida**.

O que os pacotes fotônicos válidos sustentam é:

\[
\boxed{\text{forte semelhança radial ampla, mas sem atrator morfológico demonstrado pelos critérios antigos [M]}}
\]

Não há ainda evidência de um modo fotônico preso único.

---

# 8. Convergência temporal do ramo fotônico válido

Para COROT_++ em \(\beta=2\), mantendo exatamente a mesma geometria inicial e reduzindo apenas \(dt\) pela metade:

\[
\langle V_{0.8}\rangle_{dt}=107,67,
\]

\[
\langle V_{0.8}\rangle_{dt/2}=110,88.
\]

Diferença relativa aproximada: 3,0%.

O efeito qualitativo de sustentação sobrevive à redução do passo temporal.

---

# 9. O que permanece e o que precisa ser corrigido

## Permanece [M]

1. Pacotes fotônicos circulares podem formar a cavidade no mesmo toy model.
2. A cavidade constitui uma barreira muito forte à penetração de probes fotônicos.
3. Injeção de campo fotônico válido pode aumentar a persistência/volume da cavidade.
4. Drenar esse campo reduz fortemente a sustentação do objeto.
5. Não foi encontrada uma morfologia angular universal.

## Deve ser retirado ou enfraquecido

1. **“Duas co-rotantes são necessariamente a configuração privilegiada.”** Não sustentado após a correção.
2. **“\(\beta=1\) foi testado como fóton verdadeiro.”** Falso: o pacote localizado falha no portão fotônico nesta caixa.
3. **“Existe uma ressonância em torno de \(\beta=2\).”** Não demonstrado.
4. **“A E53 demonstrou um atrator radial pelos critérios anteriores.”** Não passa mais o critério de dispersão de \(r_{\rm peak}\).

---

# 10. Consequência física mais importante

O problema de \(\beta=1\) revela exatamente a dificuldade conceitual do novo capítulo.

Se

\[
kR=1,
\]

então

\[
\lambda=\frac{2\pi}{k}=2\pi R.
\]

Isso significa que uma onda com essa escala natural não cabe como um pequeno pacote retilíneo localizado dentro de uma cavidade de raio \(R\). A hipótese fisicamente interessante passa a ser testar se a **mesma onda fotônica do Capítulo 2 pode curvar sua translação global**, ocupando uma trajetória cujo comprimento seja da ordem de uma onda completa.

Em outras palavras:

\[
\boxed{
\text{pequeno saca-rolha local}
+
\text{trajetória global ligada de comprimento }\sim2\pi R
}
\]

é agora uma hipótese mais bem motivada que simplesmente “colocar um pacote curto dentro da cavidade”.

---

# 11. Próximo teste recomendado

Construir uma caixa maior e lançar um pacote fotônico Cap.-2 que **passe o gate em \(\beta\approx1\)** antes de chegar à cavidade. Depois permitir que a dinâmica determine se o envelope:

- atravessa;
- reflete;
- é desviado;
- curva continuamente;
- completa uma volta;
- ou se transforma em estado não fotônico.

O teste deve medir simultaneamente:

\[
\mathbf R(t),\quad\hat{\mathbf k}(t),\quad h(t),\quad E(t),\quad \mathbf L_{\rm orb}(t)
\]

e revalidar a identidade fotônica após a captura.

---

# 12. Status final desta revisão

\[
\boxed{\text{E45R: barreira fotônica robusta; repulsão geométrica ainda aberta}}
\]

\[
\boxed{\text{E47R: fótons válidos podem sustentar mais a cavidade, mas co-rotação não é única}}
\]

\[
\boxed{\text{E49R: nenhuma ressonância fotônica válida demonstrada; }\beta=1\text{ exige novo desenho}}
\]

\[
\boxed{\text{E51R: sustentação causal pelo campo fotônico permanece forte [M]}}
\]

\[
\boxed{\text{E53R: similaridade radial alta, mas sem atrator morfológico fechado}}
\]

Nenhum desses resultados identifica a estrutura como elétron físico, nem demonstra spin \(1/2\), carga \(-e\), \(g\simeq2\), estatística fermiônica ou dinâmica de Dirac.

