# HRF CAP3-2D-FLUX-01 — relatório de execução

Executado nesta sessão em ambiente de nuvem, em 2026-10-08, a partir do ZIP enviado pelo usuário. O código original foi preservado. As simulações não dependem do GitHub.

## Escopo executado

- Ensaio curto: 75°, T=30, mapas PNG.
- Controle livre uniforme: 45°, 60°, 75°, 90°, T=30.
- Cavidade R=4λ: 45°, 60°, 75°, 90°, evolução contínua até T=500, mapas PNG e checkpoints nos marcos T≈30,150,300,500.
- Refinamento PPW=24: 75°, T=150, dt automático=0.015.
- Caixa ampliada: 75°, box=20λ, sponge-start=7.5λ, T=150.
- Controle temporal adicional recomendado na Etapa B: 75°, dt=0.009, T=150.
- Comparação de raios da Etapa B: R/λ=2,3,5,6, 75°, T=150, comparados à evolução R/λ=4. Mesmos PPW20, dt=0.018, box=16 e sponge-start=6.5.

As quatro execuções longas foram separadas por ângulo para usar até três processos simultâneos; cada ângulo evoluiu continuamente desde t=0. `run_battery.py`, `run_radius_controls.py` e `logs/*.execution.json` registram os comandos, horários e códigos de saída. O README não fixa ângulo e duração para a varredura de raios; foram adotados 75° e T=150 para comparação direta com os demais controles. Não foram feitas varreduras de duas zonas ou sem sponge.

## Resultados finais

| Caso | Ângulo | T efetivo | F_in | F_rem | Transporte | Erro máx. balanço |
|---|---:|---:|---:|---:|---:|---:|
| CAP3_flux_R4_long_angle_45 | 45° | 500.004 | 0.982994 | 0.076677 | 0.038033 | 5.257e-04 |
| CAP3_flux_R4_long_angle_60 | 60° | 500.004 | 0.983273 | 0.082554 | 0.042076 | 4.530e-04 |
| CAP3_flux_R4_long_angle_75 | 75° | 500.004 | 0.983267 | 0.085412 | 0.045374 | 3.850e-04 |
| CAP3_flux_R4_long_angle_90 | 90° | 500.004 | 0.983575 | 0.085738 | 0.045888 | 3.569e-04 |
| CAP3_flux_box20 | 75° | 149.994 | 0.950439 | 0.369132 | 0.063251 | 2.975e-04 |
| CAP3_flux_dt_half | 75° | 150.003 | 0.962078 | 0.375204 | 0.063073 | 7.388e-05 |
| CAP3_flux_free | 45° | 30.006 | 0.082236 | 0.000013 | 0.972772 | 2.041e-03 |
| CAP3_flux_free | 60° | 30.006 | 0.306533 | 0.000067 | 0.983079 | 2.049e-03 |
| CAP3_flux_free | 75° | 30.006 | 0.420303 | 0.000139 | 0.985230 | 2.051e-03 |
| CAP3_flux_free | 90° | 30.006 | 0.422304 | 0.000153 | 0.985656 | 2.050e-03 |
| CAP3_flux_ppw24 | 75° | 150.000 | 0.961756 | 0.431723 | 0.050325 | 1.941e-04 |
| CAP3_flux_radius_2 | 75° | 149.994 | 0.948737 | 0.146262 | 0.044209 | 5.370e-04 |
| CAP3_flux_radius_3 | 75° | 149.994 | 0.950608 | 0.245549 | 0.050765 | 4.612e-04 |
| CAP3_flux_radius_5 | 75° | 149.994 | 0.973447 | 0.463940 | 0.058715 | 2.116e-04 |
| CAP3_flux_radius_6 | 75° | 149.994 | 0.978872 | 0.538494 | 0.058308 | 1.704e-04 |
| CAP3_flux_short | 75° | 30.006 | 0.968709 | 0.871736 | 0.082040 | 1.183e-04 |

Em T≈500, a cavidade reteve entre 7.67% e 8.57% da energia inicialmente injetada. A grande redução em relação ao ensaio curto é um resultado negativo para a hipótese de retenção forte de toda a excitação. Permanece energia residual com transporte escalar; esses dados, por si só, não estabelecem estabilidade assintótica ou identidade fotônica.

`F_in=E_inside/E_box(t)` mede a fração da energia ainda presente na caixa que está no círculo. `F_rem=E_inside/E_box(0)` mede a retenção da energia inicialmente injetada. Transporte é `∫inside |J| / E_inside`, em unidades do modelo. Os valores não são medições experimentais.

## Marcos das evoluções longas

| Ângulo | T solicitado | T efetivo do mapa | F_in | F_rem | Transporte |
|---:|---:|---:|---:|---:|---:|
| 45° | 0 | 0.000 | 0.971471 | 0.971471 | 0.381402 |
| 45° | 30 | 30.006 | 0.984073 | 0.735761 | 0.069519 |
| 45° | 150 | 149.994 | 0.960188 | 0.307156 | 0.054311 |
| 45° | 300 | 300.006 | 0.973158 | 0.140889 | 0.043378 |
| 45° | 500 | 500.004 | 0.982994 | 0.076677 | 0.038033 |
| 60° | 0 | 0.000 | 0.989032 | 0.989032 | 0.376365 |
| 60° | 30 | 30.006 | 0.977682 | 0.818725 | 0.077278 |
| 60° | 150 | 149.994 | 0.960475 | 0.350063 | 0.058272 |
| 60° | 300 | 300.006 | 0.971498 | 0.156756 | 0.048956 |
| 60° | 500 | 500.004 | 0.983273 | 0.082554 | 0.042076 |
| 75° | 0 | 0.000 | 0.997632 | 0.997632 | 0.370871 |
| 75° | 30 | 30.006 | 0.968709 | 0.871736 | 0.082040 |
| 75° | 150 | 149.994 | 0.962146 | 0.375136 | 0.063016 |
| 75° | 300 | 300.006 | 0.969647 | 0.165551 | 0.053283 |
| 75° | 500 | 500.004 | 0.983267 | 0.085412 | 0.045374 |
| 90° | 0 | 0.000 | 0.999459 | 0.999459 | 0.368404 |
| 90° | 30 | 30.006 | 0.960199 | 0.888708 | 0.085509 |
| 90° | 150 | 149.994 | 0.961727 | 0.376891 | 0.063321 |
| 90° | 300 | 300.006 | 0.968799 | 0.166989 | 0.054910 |
| 90° | 500 | 500.004 | 0.983575 | 0.085738 | 0.045888 |

Os marcos acima foram recalculados dos mapas NPZ, armazenados em float32. Pequenas diferenças de arredondamento frente aos CSVs em float64 são esperadas. Os tempos efetivos decorrem do arredondamento ao passo mais próximo. Os CSVs nem sempre incluem os marcos intermediários exatos.

## Verificações numéricas

Foram verificadas 16 séries: valores finitos, tempos crescentes, energia positiva, mapas e checkpoints finitos, densidade não negativa e definição de F_rem. Casos com falhas nessas verificações: 0. O máximo resíduo relativo da identidade semidiscreta de continuidade nos snapshots foi 4.663e-15. Esse teste algébrico não verifica a precisão da integração temporal.

O hash do script histórico corresponde ao SHA256 indicado no README. O modelo de gate `NOT_TESTED` foi corretamente rejeitado pelo pós-processador. Todos os hashes de entrada e as versões das dependências estão em `execution_provenance.json`.

Comparação de controles:

- CAP3_flux_box20: ΔF_rem=-0.006004; Δtransporte=+0.000235 em relação ao mapa de referência 75°, T≈150.
- CAP3_flux_dt_half: ΔF_rem=+0.000068; Δtransporte=+0.000057 em relação ao mapa de referência 75°, T≈150.
- CAP3_flux_ppw24: ΔF_rem=+0.056587; Δtransporte=-0.012691 em relação ao mapa de referência 75°, T≈150.

O refinamento PPW24 também reduz dt automaticamente: essa comparação combina mudanças espacial e temporal. O controle dt/2 mantém a malha original. Uma comparação com um único refinamento quantifica sensibilidade, mas não estabelece ordem de convergência. A comparação de caixa altera também a região do sponge. Não demonstra independência de todas as condições de contorno.

Na varredura de raios, os envelopes permanecem com larguras fixas em unidades de λ e a injeção fica em 0.75R. Assim, variam a geometria do perfil e as larguras relativas do pacote à cavidade; a energia inicialmente dentro do círculo também pode variar. A caixa e o início do sponge permanecem fixos. Essas diferenças devem acompanhar a interpretação de qualquer tendência com R.

## Limite da interpretação

Todas as evoluções são `[M] REDUCED_SCALAR_PROXY_ONLY`. Retenção e transporte escalar não demonstram um fóton confinado. As flags nos `summary.json` são heurísticas. A identidade fotônica, helicidade e transversalidade permanecem não avaliadas.

`analyze-cap2` não foi executado: o ZIP não contém as séries temporais do solver fotônico nem um gate aprovado com SHA256 correspondente. O `gate_template_CAP2.json` permanece sem aprovação. A Etapa C depende desses dados e de diagnósticos fotônicos do solver de origem.

O `MANIFEST.json` original e o campo `run_condition` do solver contêm textos da preparação anterior à execução. Foram preservados como parte do material original; os registros desta execução estão neste relatório, em `batch_execution.json`, `radius_execution.json` e nos logs.

## Artefatos

- `comparison.png`: curvas de retenção, transporte e controles.
- `radius_comparison.png`: comparação dos cinco raios.
- `summary_all_cases.csv`: resumos finais.
- `milestones_long_runs.csv`: valores nos marcos.
- `numerical_checks.json`: verificações dos dados.
- `results/`: timelines, mapas, resumos e checkpoints.
- `logs/`: saídas das execuções longas e controles.
- `execution_provenance.json`: versões e hashes das entradas.
