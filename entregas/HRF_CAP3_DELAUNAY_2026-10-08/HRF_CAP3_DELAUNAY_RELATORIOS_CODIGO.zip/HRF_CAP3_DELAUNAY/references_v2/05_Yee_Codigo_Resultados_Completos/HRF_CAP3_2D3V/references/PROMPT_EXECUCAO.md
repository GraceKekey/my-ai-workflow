# PROMPT DE EXECUÇÃO — HRF CAP3-2D3V-PHOTON-FLUX-01

## 1. Contexto científico

Estamos desenvolvendo o **Holographic Reconstruction Framework (HRF)**, ramo HRF-FM — *Fields and Matter Reconstruction*.

A referência física obrigatória é o **Capítulo 2 — A onda fotônica livre**, v1.1, juntamente com o documento:

`HRF_CAP3_2D3V_Regras_Modo_Fotonico_Cap02_v0_1_PT_2026-10-08.md`

Consultar também:

- `HRF_CAP3_2D_FLUX_01_Protocolo_Confinamento_Dinamico_v0_1_PT_2026-10-08.md`
- `RELATORIO_EXECUCAO.md` da bancada CAP3-2D-FLUX-01.
- O código original `run_2d_large.py`, como referência de proveniência e comparação, não como substituto da dinâmica vetorial.

Usar primeiro os arquivos do Projeto HRF, depois o Google Drive do projeto, e somente quando necessário literatura externa.

**Objetivo principal:** investigar se um campo vetorial com propriedades fotônicas pode permanecer confinado numa cavidade e continuar transportando energia internamente por tempos longos.

Não exigir órbita circular.

## 2. Modelo físico obrigatório — 2D3V

Implementar uma simulação com duas dimensões espaciais `(x,y)` e três componentes vetoriais dos campos:

\[
\mathbf E=(E_x,E_y,E_z),\quad \mathbf B=(B_x,B_y,B_z)
\]

com \(\partial_z=0\).

Usar inicialmente as equações eletromagnéticas sem fontes:

\[
\partial_t\mathbf B=-\nabla\times\mathbf E
\]

\[
\partial_t\mathbf D=\nabla\times\mathbf H
\]

\[
\mathbf D=\varepsilon(x,y)\mathbf E,\quad
\mathbf B=\mu(x,y)\mathbf H
\]

Respeitar as restrições de Gauss e impedir modos longitudinais físicos espúrios.

A representação precisa permitir duas polarizações transversais e combinações circulares de helicidade \(h=\pm1\), em relação à direção local de propagação.

A pequena hélice é a rotação da polarização; não é a trajetória espacial do envelope.

**Restrição de equivalência:** Maxwell 2D3V é uma bancada intermediária. O Capítulo 2 utiliza conexão relacional U(1), laços orientados, energia de Wilson e o operador discreto curl-curl. Não declarar equivalência completa sem demonstrar a correspondência entre os operadores, os modos físicos e as simetrias.

## 3. Fase A — Validação fotônica livre

Antes de introduzir a cavidade, implementar e executar o controle livre.

Preparar um pacote vetorial localizado, com propagação inicialmente no plano XY e polarização circular.

Testar ambas as helicidades.

**PHOTON-INJECTION GATE obrigatório:**

1. Exatamente duas polarizações físicas transversais.
2. Restrições de Gauss e ausência de modo longitudinal propagante.
3. Hel icidade \(h=\pm1\), definida relativamente a \(\mathbf k\).
4. Relação \(\omega\simeq c|\mathbf k|\).
5. Relação \(P/E\simeq1/c\) no regime livre apropriado.
6. Propagação correta do envelope.
7. Conservação energética, estabilidade e convergência numérica.
8. Preservação das propriedades sob alterações de resolução.

Definir as tolerâncias antes de examinar os resultados.

Separar duas classificações: `2D3V-MAXWELL-GATE` e `PHOTON-INJECTION GATE HRF-CAP2`.

Aprovar o primeiro não implica aprovar o segundo. Se a correspondência com a dinâmica discreta do Capítulo 2 não puder ser validada, registrar o segundo como `NOT_TESTED` ou `PENDING`, nunca como `PASS`.

Se o controle vetorial livre falhar, interromper a fase de confinamento e relatar a falha.

## 4. Fase B — Cavidade 2D

Após validar a propagação livre, testar inicialmente:

| Parâmetro | Valor |
|---|---|
| Raio | \(R=4\lambda\) |
| Posição inicial | \(r_0=0,75R\) |
| Ângulos | 45°, 60°, 75°, 90° |
| Tempos | \(30,150,300,500\lambda/c\) |
| Configuração inicial | Um pacote |
| Referência | \(\lambda=1\), \(c_{\rm vácuo}=1\) |

Preservar o perfil radial histórico de velocidade, registrando seus valores e proveniência.

Como hipótese de controle, implementar \(\varepsilon_r(r)=\mu_r(r)=1/c_{\rm local}(r)\), que mantém impedância uniforme em unidades normalizadas. Explicitar que essa escolha não é uma derivação da microestrutura do HRF.

Não inserir força centrípeta, potencial orbital ou trajetória circular prescrita.

Executar primeiramente um ensaio curto, depois avançar aos tempos longos se os controles forem satisfatórios.

## 5. Fase C — Diagnóstico de energia e movimento

Calcular e armazenar:

\[
u(x,y,t)=\frac12(\mathbf E\cdot\mathbf D+\mathbf B\cdot\mathbf H)
\]

\[
\mathbf J_E(x,y,t)=\mathbf E\times\mathbf H
\]

Medir:

- Energia total inicialmente injetada.
- Energia dentro da cavidade e energia fora dela, mas ainda na caixa.
- Energia absorvida pelo sponge e resíduo numérico do balanço.
- \(F_{\rm in}(t)\) e \(F_{\rm rem}(t)\), sem confundir os denominadores.
- Fluxo radial \(J_r\), tangencial \(J_\theta\) e suas médias temporais.
- Fluxo normal integrado através da fronteira \(r=R\).
- Fluxo integrado de saída e de reentrada, separadamente.
- Centro de energia e máximos de densidade, distinguindo-os do transporte energético.
- Indicadores locais de transversalidade, polarização e helicidade durante a evolução.

Produzir mapas de densidade e vetores de fluxo nos principais marcos temporais.

Classificar os resultados como:

A. Onda viajante confinada  
B. Ricochete/refração  
C. Sloshing  
D. Circulação parcial  
E. Padrão quase-estacionário  
F. Fuga / aprisionamento transitório  
G. Candidato quase-ligado, somente se os critérios completos forem atendidos

Não exigir órbita nem inferir trajetória de um fóton individual pelo movimento de máximos de interferência.

## 6. Controles e refinamento

Comparar a bancada vetorial com o experimento escalar anterior, mantendo parâmetros físicos comparáveis, sem presumir equivalência.

Realizar controles:

- Fundo homogêneo sem cavidade.
- Fundo homogêneo com velocidade igual à velocidade local de injeção, para isolar o efeito de desaceleração.
- Refinamento espacial PPW20, 24 e 32, quando computacionalmente viável.
- Refinamento temporal independente.
- Caixa ampliada e alteração do absorvedor.
- Verificação de conservação no interior e balanço de energia que cruza a fronteira.
- Controles de helicidade positiva e negativa.

Se os resultados variarem significativamente com a resolução, não declarar convergência.

Somente depois da bancada principal considerar \(R/\lambda=2,3,5,6\), outras larguras transversais e dois pacotes simultâneos.

## 7. Resultados negativos

Preservar integralmente os resultados negativos, incluindo perda de energia, decaimento prolongado, desaparecimento do movimento, perda de identidade fotônica, ausência de confinamento e dependência do absorvedor ou da malha.

Toda conclusão numérica deve receber a marca **[M]**.

Usar também [F], [H], [?] e [D], conforme as regras do HRF.

Não chamar uma excitação vetorial genérica de fóton. Se o contrato específico do Capítulo 2 não estiver validado, utilizar `CAMPO_VETORIAL_2D3V_EXPLORATORIO`.

## 8. Entregáveis obrigatórios

Fornecer:

1. Código Python completo, independente do GitHub quando possível.
2. Arquivo de configuração com parâmetros e critérios previamente definidos.
3. Relatório de validação livre e status dos dois gates.
4. CSV e JSON com métricas temporais e resumos.
5. Mapas da densidade e do fluxo local de energia.
6. Balanço explícito entre energia confinada, energia externa, absorção e erro numérico.
7. Comparação com o CAP3 escalar anterior.
8. Relatório científico Markdown com resultados positivos, negativos, limites e próximos testes.
9. Registros de proveniência, versões, hashes e parâmetros executados.
10. ZIP completo dos resultados.

Se necessário, executar em etapas para controlar memória e tempo computacional, sem reduzir silenciosamente as exigências científicas.

Salvar os resultados também no Google Drive do projeto quando o acesso estiver disponível, sem sobrescrever arquivos anteriores.

## 9. Pergunta final obrigatória

Ao concluir, responder explicitamente:

**O modelo vetorial 2D3V demonstrou uma onda com propriedades fotônicas viajando e permanecendo confinada, ou apenas um campo eletromagnético com retenção transitória e transporte interno?**

Separar rigorosamente o que foi demonstrado do que continua como hipótese.

Não apresentar a formação de um elétron como conclusão deste teste.