import numpy as np, math, json, csv, time
from pathlib import Path
from scipy.interpolate import PchipInterpolator

OUT=Path('/mnt/data/HRF_CAP3_2D_LARGE_2026-10-08')
LAMBDA_M=2.4263102387e-12
LAM=1.0
R=4.0
R0=.75*R
ANGLES=[45,50,55,60,65,70,75,80,85,90]
PPW=20
DX=1/PPW
BOX=16.0
N=int(round(BOX/DX))
DT=0.018
TMAX=30.0
SIGL=.70
SIGT=.35
K0=2*np.pi
TRACK_R=.80
SAMPLE_DT=.18
SAMPLE_EVERY=max(1,int(round(SAMPLE_DT/DT)))

# Proxy radial c_local extracted from the historical cavity and scaled in r/R.
U=np.array([0.00,0.25,0.45,0.55,0.65,0.75,0.85,0.95,1.05,1.15,1.25,1.45,1.60])
CVAL=np.array([0.030,0.031,0.015,0.118,0.224,0.390,0.465,0.766,0.876,0.956,0.983,0.992,0.995])
CP=PchipInterpolator(U,CVAL,extrapolate=True)

coords=(np.arange(N)-N/2)*DX
X,Y=np.meshgrid(coords,coords,indexing='ij')
RAD=np.hypot(X,Y)
U2=RAD/R
C=np.where(U2>=1.25,1.0,CP(np.clip(U2,0,1.25)))
C=np.clip(C,0.015,1.0)
KAP=C*C
KXP=.5*(KAP+np.roll(KAP,-1,axis=0))
KYP=.5*(KAP+np.roll(KAP,-1,axis=1))
# Edge sponge: only outside 6.5 lambda in max-norm.
EDGE=np.maximum(np.abs(X),np.abs(Y))
DAMP=np.zeros_like(X)
M=EDGE>6.5
DAMP[M]=1.8*((EDGE[M]-6.5)/(8.0-6.5))**2


def op(q, uniform=False):
    if uniform:
        return (np.roll(q,-1,0)+np.roll(q,1,0)+np.roll(q,-1,1)+np.roll(q,1,1)-4*q)/(DX*DX)
    dxp=np.roll(q,-1,0)-q; dxm=q-np.roll(q,1,0)
    dyp=np.roll(q,-1,1)-q; dym=q-np.roll(q,1,1)
    return (KXP*dxp-np.roll(KXP,1,0)*dxm + KYP*dyp-np.roll(KYP,1,1)*dym)/(DX*DX)


def init_packet(alpha, uniform=False):
    a=np.deg2rad(alpha)
    n=np.array([-np.cos(a),np.sin(a)])
    m=np.array([-n[1],n[0]])
    x0=np.array([R0,0.0])
    rx=X-x0[0]; ry=Y-x0[1]
    s=n[0]*rx+n[1]*ry
    p=m[0]*rx+m[1]*ry
    env=np.exp(-.5*(s/SIGL)**2-.5*(p/SIGT)**2)
    ph=K0*s
    q1=env*np.cos(ph); q2=env*np.sin(ph)
    # travelling-wave derivative using local speed at injection radius.
    c0=1.0 if uniform else float(CP(R0/R))
    ds1=env*((-s/SIGL**2)*np.cos(ph)-K0*np.sin(ph))
    ds2=env*((-s/SIGL**2)*np.sin(ph)+K0*np.cos(ph))
    v1=-c0*ds1; v2=-c0*ds2
    return q1,q2,v1,v2,n


def energy_density(q1,q2,v1,v2,uniform=False):
    e=.5*(v1*v1+v2*v2)
    if uniform:
        kxp=kyp=1.0
        for q in (q1,q2):
            fx=.5/DX**2*(np.roll(q,-1,0)-q)**2
            fy=.5/DX**2*(np.roll(q,-1,1)-q)**2
            e += .5*(fx+np.roll(fx,1,0)+fy+np.roll(fy,1,1))
    else:
        for q in (q1,q2):
            fx=.5/DX**2*KXP*(np.roll(q,-1,0)-q)**2
            fy=.5/DX**2*KYP*(np.roll(q,-1,1)-q)**2
            e += .5*(fx+np.roll(fx,1,0)+fy+np.roll(fy,1,1))
    return e


def total_energy(q1,q2,v1,v2,uniform=False):
    return float(energy_density(q1,q2,v1,v2,uniform).sum())


def track_step(e,track):
    Et=float(e.sum())
    cg=np.array([(X*e).sum()/Et,(Y*e).sum()/Et])
    d2=(X-track[0])**2+(Y-track[1])**2
    m=d2<TRACK_R**2
    El=float(e[m].sum())
    if El/Et<.02:
        m=d2<(1.5*TRACK_R)**2; El=float(e[m].sum())
    if El>0:
        track=np.array([(X[m]*e[m]).sum()/El,(Y[m]*e[m]).sum()/El])
    idx=np.unravel_index(np.argmax(e),e.shape)
    peak=np.array([X[idx],Y[idx]])
    return cg,track,peak,El/Et,float(e[RAD<R].sum()/Et)


def run(alpha,uniform=False,tmax=TMAX,stop_after_exit=False):
    q1,q2,v1,v2,n=init_packet(alpha,uniform)
    a1=op(q1,uniform); a2=op(q2,uniform)
    track=np.array([R0,0.0]); rows=[]
    E0=total_energy(q1,q2,v1,v2,uniform)
    first_exit=None; exit_count=0; reentry_count=0; prev_inside=True
    max_steps=int(round(tmax/DT))
    for j in range(max_steps+1):
        if j%SAMPLE_EVERY==0:
            e=energy_density(q1,q2,v1,v2,uniform); Et=float(e.sum())
            cg,track,peak,flocal,finside=track_step(e,track)
            rt=float(np.linalg.norm(track)); inside=rt<R
            tp=j*DT
            if prev_inside and not inside:
                exit_count+=1
                if first_exit is None:first_exit=tp
            if (not prev_inside) and inside: reentry_count+=1
            prev_inside=inside
            rows.append(dict(t=tp,global_xy=cg.tolist(),track_xy=track.tolist(),peak_xy=peak.tolist(),
                             r_track=rt,r_global=float(np.linalg.norm(cg)),f_local=flocal,f_inside=finside,E=Et))
            if stop_after_exit and first_exit is not None and rt>R+1.0:
                break
        if j==max_steps: break
        v1+=.5*DT*a1; v2+=.5*DT*a2
        q1+=DT*v1; q2+=DT*v2
        # sponge only affects already far-out radiation
        fac=np.exp(-DAMP*DT)
        q1*=fac; q2*=fac; v1*=fac; v2*=fac
        a1=op(q1,uniform); a2=op(q2,uniform)
        v1+=.5*DT*a1; v2+=.5*DT*a2
    C=np.array([r['track_xy'] for r in rows]); rr=np.linalg.norm(C,axis=1)
    seg=np.linalg.norm(np.diff(C,axis=0),axis=1); path=float(seg.sum()); disp=float(np.linalg.norm(C[-1]-C[0]))
    phi=np.unwrap(np.arctan2(C[:,1],C[:,0])); dphi=np.diff(phi)
    dr=np.diff(rr); eps=.01; s=np.sign(np.where(abs(dr)<eps,0,dr)); nz=s[s!=0]
    turns=int(np.sum(nz[1:]*nz[:-1]<0)) if len(nz)>1 else 0
    summ=dict(alpha_deg=alpha,uniform=uniform,r_min=float(rr.min()),r_final=float(rr[-1]),r_max=float(rr.max()),
              path=path,displacement=disp,straightness=disp/path if path else 0.0,radial_turns=turns,
              phi_net_deg=float(np.degrees(phi[-1]-phi[0])),phi_abs_deg=float(np.degrees(np.abs(dphi).sum())),
              first_exit_time=first_exit,n_exits=exit_count,n_reentries=reentry_count,
              f_local_final=float(rows[-1]['f_local']),f_local_mean=float(np.mean([x['f_local'] for x in rows])),
              f_inside_final=float(rows[-1]['f_inside']),f_inside_mean=float(np.mean([x['f_inside'] for x in rows])),
              energy_remaining=float(rows[-1]['E']/E0),initial_direction=n.tolist(),end_xy=C[-1].tolist())
    return summ,rows


def gate_free():
    s,rows=run(0.0,uniform=True,tmax=4.0,stop_after_exit=False)
    t=np.array([r['t'] for r in rows]); C=np.array([r['track_xy'] for r in rows])
    # alpha=0 moves in -x; fit x(t)
    v=float(np.polyfit(t,C[:,0],1)[0])
    return dict(speed_abs=abs(v),straightness=s['straightness'],energy_remaining=s['energy_remaining'],rmin=s['r_min'])


def classify(s):
    if s['n_exits']>0:
        if s['n_reentries']>0:return 'SAIDA_E_REENTRADA'
        return 'SAIDA'
    if s['f_inside_final']>.70 and s['straightness']<.75:
        return 'RETENCAO_CURVA/REDISTRIBUICAO_INTERNA'
    if s['straightness']<.85:return 'CURVATURA_INTERNA'
    return 'TRAVESSIA_QUASE_RETA'


def main():
    t0=time.time()
    gate=gate_free()
    outs=[]; ctrls=[]
    for a in ANGLES:
        s,rows=run(a,uniform=False); s['classification']=classify(s); outs.append(s)
        json.dump({'summary':s,'rows':rows},open(OUT/f'ANGLE2D_{a:04.1f}.json','w'),indent=2)
        # uniform only long enough to exit + 1 lambda
        su,ru=run(a,uniform=True,tmax=12.0,stop_after_exit=True); su['classification']=classify(su); ctrls.append(su)
        json.dump({'summary':su,'rows':ru},open(OUT/f'UNIFORM2D_{a:04.1f}.json','w'),indent=2)
        print(a,s['classification'],s['r_min'],s['r_final'],s['straightness'],s['f_inside_final'], 'control_exit',su['first_exit_time'],flush=True)
    meta=dict(lambda_m=LAMBDA_M,R_lambda=R,R_m=R*LAMBDA_M,diameter_lambda=2*R,diameter_m=2*R*LAMBDA_M,
              radius_scale_vs_old=8*np.pi,ppw=PPW,dx_lambda=DX,N=N,dt=DT,tmax=TMAX,sigL=SIGL,sigT=SIGT,
              gate=gate,angles=ANGLES,profile_u=U.tolist(),profile_c=CVAL.tolist(),elapsed_s=time.time()-t0)
    json.dump({'meta':meta,'cavity':outs,'uniform':ctrls},open(OUT/'SUMMARY_2D_LARGE.json','w'),indent=2)
    fields=['alpha_deg','classification','r_min','r_final','r_max','path','straightness','radial_turns','phi_net_deg','phi_abs_deg',
            'first_exit_time','n_exits','n_reentries','f_local_final','f_local_mean','f_inside_final','f_inside_mean','energy_remaining']
    with open(OUT/'SUMMARY_2D_LARGE.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows([{k:o.get(k) for k in fields} for o in outs])
    with open(OUT/'SUMMARY_2D_UNIFORM.csv','w',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows([{k:o.get(k) for k in fields} for o in ctrls])
    print('GATE',gate,'elapsed',meta['elapsed_s'])

if __name__=='__main__': main()
