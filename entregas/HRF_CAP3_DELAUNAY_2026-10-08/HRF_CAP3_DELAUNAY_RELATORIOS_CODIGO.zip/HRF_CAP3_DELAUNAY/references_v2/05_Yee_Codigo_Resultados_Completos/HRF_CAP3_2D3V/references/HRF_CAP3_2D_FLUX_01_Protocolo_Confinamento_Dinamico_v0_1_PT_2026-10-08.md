# HRF-FM — CAP3-2D-FLUX-01

## Protocolo provisório para confinamento dinâmico e movimento interno do modo fotônico

**Framework:** Holographic Reconstruction Framework (HRF)  
**Ramo:** HRF-FM — *Fields and Matter Reconstruction*  
**Status:** protocolo conceitual/metodológico [D]/[H]  
**Data:** 8 de outubro de 2026

> **Nota editorial [D]:** a designação “Capítulo 3” permanece provisória enquanto a arquitetura do Research Book não for formalmente renumerada.

---

## 1. Objetivo central

O objetivo deste ramo **não é demonstrar uma órbita circular**.

A pergunta central passa a ser:

\[
oxed{	extbf{Pode o modo fotônico do Capítulo 2 permanecer dinamicamente confinado em uma cavidade, continuar se propagando internamente e evitar a fuga rápida?}}
\]

O fenômeno de interesse é:

\[
oxed{	ext{confinamento}+	ext{movimento interno persistente}}
\]

e não uma geometria orbital específica.

---

## 2. Objeto de entrada

Toda bancada deve começar com o modo fotônico efetivo já estabelecido no Capítulo 2:

\[
oxed{	ext{pequeno saca-rolha local}+	ext{propagação do envelope}}
\]

A hélice pequena representa polarização/helicidade local e **não** a trajetória espacial do centro de energia.

Antes da injeção, permanece obrigatório o **PHOTON-INJECTION GATE**.

O pacote deve satisfazer, em controle livre:

- transversalidade;
- helicidade \(h=\pm1\);
- ausência de longitudinal físico;
- \(\omega\simeq ck\);
- \(P/E\simeq1/c\) no regime aplicável;
- conservação numérica adequada;
- propagação do envelope compatível com o modo do Capítulo 2.

---

## 3. Geometria da bancada

Nesta fase, a dinâmica espacial será estudada **em 2D**, como um corte operacional da cavidade.

A analogia de trabalho é:

> um carrinho movendo-se sobre uma superfície com relevo, onde a cavidade modifica a trajetória sem que seja necessário impor uma pista circular.

O campo continua sendo tratado como onda; a analogia serve apenas para visualizar o movimento do envelope/fluxo de energia.

---

## 4. Cavidade

A cavidade deve ser suficientemente grande para permitir múltiplos caminhos internos.

Nesta fase, recomenda-se trabalhar com \(R_{m cav}/\lambda\) como parâmetro explícito.

Valores de referência:

\[
R_{m cav}/\lambda=2,\ 3,\ 4,\ 5,\ 6.
\]

A forma da cavidade não deve ser ajustada para produzir órbita.

---

## 5. O que deve ser rastreado

O rastreamento do movimento interno deve usar, no mínimo:

\[
\mathbf R_E(t)=(x_E(t),y_E(t)),
\]

onde \(\mathbf R_E\) é uma medida do centro/lóbulo dominante da densidade de energia.

Também registrar:

\[
r(t)=|\mathbf R_E(t)|,
\]

\[
	heta(t)=rg \mathbf R_E(t),
\]

e o comprimento acumulado da trajetória:

\[
L_{m path}(t)=\int_0^t |\dot{\mathbf R}_E(t')|\,dt'.
\]

---

## 6. Diagnóstico principal: fluxo local de energia

O diagnóstico central desta bancada será um campo de fluxo:

\[
oxed{\mathbf J_E(x,y,t)}
\]

ou equivalente definido pela dinâmica do modelo.

A finalidade é distinguir:

### (a) onda viajante confinada
A energia se desloca localmente de forma organizada.

### (b) ricochete/refração interna
O fluxo muda de direção em regiões específicas da cavidade.

### (c) sloshing
Há vai-e-vem recorrente entre regiões internas.

### (d) circulação parcial
O fluxo possui componente tangencial persistente, mas não completa órbita uniforme.

### (e) padrão quase-estacionário
A densidade oscila, mas o transporte líquido de energia é pequeno.

---

## 7. Não confundir padrão com trajetória

Se o campo se redistribuir em múltiplos lóbulos, não se deve afirmar automaticamente que “o mesmo fóton” percorreu a trajetória do lóbulo dominante.

Deve-se separar:

\[
oxed{	ext{movimento do pacote}}
\]

de:

\[
oxed{	ext{movimento de máximos de interferência}}
\]

e de:

\[
oxed{	ext{fluxo real de energia}}
\]

A interpretação principal deve seguir o fluxo local de energia, não apenas a posição de um máximo.

---

## 8. Tempo de observação

As bancadas devem ser prolongadas em múltiplas escalas:

\[
T=30,\ 150,\ 300,\ 500\;\lambda/c
\]

quando numericamente viável.

O objetivo é distinguir retenção transitória de confinamento longo.

---

## 9. Métrica de confinamento

Definir:

\[
F_{m in}(t)=rac{E(r<R_{m cav},t)}{E_{m total}(t)}
\]

e também, separadamente,

\[
F_{m rem}(t)=rac{E(r<R_{m cav},t)}{E_{m initial}}.
\]

Essas duas grandezas não devem ser confundidas.

- \(F_{m in}\): fração da energia ainda existente que permanece dentro.
- \(F_{m rem}\): fração da energia inicial que continua dentro.

---

## 10. Classificação dos movimentos

As bancadas devem abandonar a classificação binária “orbital / não orbital”.

### A — Atravessante
Entra e sai sem retenção significativa.

### B — Aprisionamento transitório
Permanece dentro por algum tempo, mas posteriormente escapa.

### C — Ricochete interno
Sofre mudanças repetidas de direção dentro da cavidade.

### D — Sloshing interno
Executa vai-e-vem persistente entre regiões internas.

### E — Circulação parcial
Apresenta componente tangencial persistente sem exigir uma órbita fechada.

### F — Quase-estacionário
Forma um padrão interno persistente com pouco transporte líquido.

### G — Quase-ligado
Mantém por longo tempo simultaneamente:
- identidade fotônica local;
- energia majoritariamente confinada;
- movimento/fluxo interno;
- ausência de confinamento artificial;
- estabilidade numérica.

---

## 11. Critério mínimo de “preso e se movendo”

Um candidato poderá ser classificado como **confinamento dinâmico [M]** se satisfizer:

1. \(F_{m in}\) permanece elevado por tempo longo;
2. o campo não é simplesmente congelado;
3. existe fluxo interno mensurável;
4. o fluxo permanece majoritariamente dentro da cavidade;
5. não há potencial orbital imposto;
6. o resultado sobrevive a refinamento numérico;
7. a identidade fotônica local continua reconhecível.

---

## 12. Identidade fotônica durante o confinamento

Além do movimento global, medir ao longo do tempo:

\[
h(t),\qquad 
abla\cdot\mathbf A,\qquad 	ext{fração transversal},
\]

e, quando possível,

\[
\omega_{m local}(t),\qquad |\mathbf k_{m local}(t)|.
\]

Se o campo perder de forma persistente o contrato fotônico, a classificação deve mudar para:

\[
oxed{	ext{estado coletivo ligado do campo}}
\]

e não “fóton preso”.

---

## 13. Ângulos de entrada

A varredura angular continua útil, mas passa a servir para mapear **regimes de movimento interno**.

Valores recomendados:

\[
45^\circ,\ 55^\circ,\ 65^\circ,\ 75^\circ,\ 85^\circ,\ 90^\circ.
\]

O objetivo não é encontrar “o ângulo orbital”, mas perguntar:

\[
oxed{	ext{qual ângulo favorece maior permanência e qual tipo de movimento interno?}}
\]

---

## 14. Largura transversal

A largura do pacote deve permanecer variável:

\[
\chi=rac{w_\perp}{\lambda}.
\]

Sugestão:

\[
\chi=0.25,\ 0.5,\ 1,\ 2.
\]

Cada valor deve passar individualmente pelo PHOTON-INJECTION GATE.

---

## 15. Uma e duas zonas fotônicas

Testar separadamente:

### Uma zona fotônica
Para compreender o mecanismo básico de confinamento.

### Duas zonas fotônicas
Para verificar:
- interferência;
- redistribuição;
- reforço ou cancelamento de fluxos;
- helicidades iguais e opostas;
- movimento coletivo.

Não assumir que duas zonas permanecem individualmente identificáveis após a interação.

---

## 16. Controles obrigatórios

Cada resultado de confinamento deve ser comparado com:

- propagação livre sem cavidade;
- cavidade com parâmetros alterados;
- resolução espacial maior;
- passo temporal menor;
- caixa maior;
- borda absorvente diferente ou ausência de absorção, quando possível.

---

## 17. Resultados negativos válidos

Devem ser preservados casos em que:

- toda a energia escapa;
- há apenas interferência estacionária;
- o campo perde identidade fotônica;
- o confinamento desaparece com refinamento;
- o efeito depende da borda da caixa;
- só existe retenção quando o potencial é artificialmente ajustado;
- o movimento interno desaparece em tempos longos.

---

## 18. Pergunta física de trabalho

A pergunta passa a ser:

\[
oxed{	extbf{Que tipo de movimento interno permite a um modo fotônico continuar se propagando sem abandonar a cavidade?}}
\]

Possíveis respostas incluem:

\[
	ext{ricochete},\quad
	ext{refração},\quad
	ext{sloshing},\quad
	ext{circulação parcial},\quad
	ext{interferência dinâmica},\quad
	ext{modo guiado},
\]

ou uma combinação desses mecanismos.

---

## 19. Regra interpretativa principal

\[
oxed{	extbf{Confinamento dinâmico não exige órbita circular.}}
\]

O critério físico relevante é:

\[
oxed{	ext{identidade fotônica local}+	ext{energia confinada}+	ext{movimento interno persistente}}
\]

---

## 20. Relação com o programa do elétron

Mesmo que um modo fotônico fique dinamicamente preso, isso **não estabelece ainda um elétron**.

Continuam abertos:

\[
m_e,\qquad Q=-e,\qquad J=rac12,\qquad g\simeq2,
\]

estatística fermiônica, estrutura relativística, antipartícula e demais observáveis.

O objetivo desta fase é apenas fechar o problema:

\[
oxed{	ext{fóton livre}ightarrow	ext{modo fotônico dinamicamente confinado}}
\]

---

**Status final:** protocolo provisório para as próximas bancadas 2D do HRF-FM.  
**Prioridade imediata:** mapas temporais de densidade e fluxo de energia para distinguir propagação confinada, sloshing, ricochete e padrões quase-estacionários.

