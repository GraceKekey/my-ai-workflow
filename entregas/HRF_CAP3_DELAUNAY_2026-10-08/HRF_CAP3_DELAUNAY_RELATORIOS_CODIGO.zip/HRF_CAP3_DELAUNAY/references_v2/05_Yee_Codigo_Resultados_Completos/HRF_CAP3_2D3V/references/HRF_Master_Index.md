# HRF — Master Index

**Arquivo:** HRF_Master_Index.md  
**Versão:** v0.1 · **Data da verificação:** 06/10/2026 (America/Sao_Paulo)  
**Projeto:** Holographic Reconstruction Framework / The Understanding Initiative  
**Função:** navegação, versões, proveniência e tarefas; não substitui capítulos, relatórios ou código.

## 1. Resultado da verificação

- **Localizado e lido:** esqueleto v0.2; Capítulo 1 v0.2 (Markdown); programa do elétron v0.1; notebook mestre C5A v1.1; adendo v1.2; auditoria C5B-QO v0.2.
- **Duplicação confirmada de conteúdo textual:** duas cópias do esqueleto v0.2, em 00-Project-Overview e 00-Inbox/Physics. Comparação das respostas integrais de texto: idênticas.
- **Versão mais recente relevante:** C5A v1.2 é composição de v1.1 + adendo §142, não um notebook integral reescrito.
- **Não localizado:** Capítulo 2 HRF v1.1 e predecessor C5A v1.0, apesar de citados em fontes lidas; capítulos completos 3–12; notebook mestre dedicado C5B; arquivos QW01/QW02/QW03 e documentos de fórmulas/critérios citados pela auditoria.
- **Não concluir ausência global:** buscas e listagens representam os itens acessíveis ao conector nesta data. Não se verificaram bytes de todos os arquivos, todas as subpastas históricas ou o interior de ZIPs.

## 2. Convenções

| Marca | Significado |
|---|---|
| [F] | Física/matemática estabelecida no domínio indicado |
| [M] | Resultado matemático/numérico de toy model ou bancada |
| [H] | Hipótese específica HRF |
| [?] | Questão aberta |
| [D] | Decisão editorial, terminológica ou metodológica |

O status documental (localizado, lido, referido, duplicado) é separado do estatuto científico. Consistência numérica não equivale a validação empírica.

**Nomenclatura corrente [D]:** sistema físico/subsistema físico; região R distinta de S_R; R/complemento na mesma boundary, L/R reservado a two-sided. PRFE e PGFE são históricos. GMF permanece termo técnico dos toy models HRF-FM; sua identificação com o sistema holográfico fundamental continua [?]. Não renomear retroativamente arquivos C5A/C5B.

## 3. Documentos de referência e precedência

| Documento | Estado e uso |
|---|---|
| [HRF_Programa_Eletron_Estado_Atual_e_Lacunas_v0_1_PT_2026-10-06.md](https://drive.google.com/file/d/19bP3zryvzahbjyfMW-k58fWPpXIP7-RT/view?usp=drivesdk) | Lido; síntese corrente do programa do elétron, não capítulo 5 completo |
| [HRF_Esqueleto_Research_Book_v0_2_PT_2026-10-06.md](https://drive.google.com/file/d/1d-6ve7xYYnbdQkUovpxEYN0csU_Ig0dm/view?usp=drivesdk) | Esqueleto corrente v0.2; cópias textuais idênticas |
| [HRF_Research_Book_Cap01_Sistema_Fisico_Holografico_Fundamental_v0_2_PT_2026-10-06.md](https://drive.google.com/file/d/1-H-CBY-lRIdsRdYo9vmLZgp6fq8G41yJ/view?usp=drivesdk) | Lido; referência conceitual corrente, em desenvolvimento |
| [HRF_Research_Book_Cap01_Sistema_Fisico_Holografico_Fundamental_v0_2_PT_2026-10-06.docx](https://docs.google.com/document/d/1XqGON3nygfBXRDYuY6qhbXfZJ_yHPev4/edit?usp=drivesdk&ouid=114819923691083378498&rtpof=true&sd=true) | Formato DOCX localizado; equivalência ao Markdown não auditada |
| [HRF_Esqueleto_Research_Book_v0_2_PT_2026-10-06.md](https://drive.google.com/file/d/12BYLRUCX7HUEW8HO3RLqc7qa2OjEl1Ce/view?usp=drivesdk) | Esqueleto corrente v0.2; cópias textuais idênticas |
| [HRF_Esqueleto_Research_Book_v0_1_PT.md](https://drive.google.com/file/d/1c0H1KqT1ebTR5ixf34x4X-7h3Ey10f2b/view?usp=drivesdk) | Histórico; substituído explicitamente pelo esqueleto v0.2 |

Em conflito, registrar a discrepância; documento especializado mais recente com decisão explícita exige atualização do esqueleto, não harmonização silenciosa. A data de upload/modificação não demonstra evolução científica.

## 4. Mapa dos capítulos

| Cap. | Título | Ramo/interface | Evidência documental |
|---|---|---|---|
| 1 | O sistema físico holográfico fundamental | Fundação / PD-ST-FM | Texto v0.2 localizado e lido |
| 2 | A onda fotônica livre | HRF-FM / C5A | v1.1 referido pelo esqueleto e Cap. 1; arquivo não localizado. Fechamento provisório [M] é declaração dessas fontes |
| 3 | Microestrutura dinâmica | HRF-FM / C5A | Previsto no esqueleto; capítulo completo não localizado |
| 4 | Estados ligados e massa emergente | HRF-FM / C5A | Previsto no esqueleto; capítulo completo não localizado |
| 5 | O programa do elétron | HRF-FM / C5A | Síntese do programa v0.1 localizada; capítulo completo não localizado |
| 6 | Dinâmica dos sistemas físicos holográficos | HRF-PD / C5B | Previsto no esqueleto; capítulo completo não localizado |
| 7 | Das relações quânticas à estrutura reconstruível | HRF-PD / C5B | Previsto no esqueleto; capítulo completo não localizado |
| 8 | Do emaranhamento à distância | HRF-ST | Previsto no esqueleto; capítulo completo não localizado |
| 9 | Emergência de dimensão e métrica | HRF-ST | Previsto no esqueleto; capítulo completo não localizado |
| 10 | Reconstrução do espaço-tempo | HRF-ST | Previsto no esqueleto; capítulo completo não localizado |
| 11 | Campos, matéria e geometria a partir de uma estrutura holográfica comum | Integração PD-ST-FM | Previsto no esqueleto; capítulo completo não localizado |
| 12 | Rumo a uma reconstrução holográfica completa | Integração PD-ST-FM | Previsto no esqueleto; capítulo completo não localizado |

## 5. Subprogramas e rastreabilidade

| Ramo | Escopo | Proveniência e materiais | Limite da associação |
|---|---|---|---|
| HRF-PD | Estado global, dinâmica/emaranhamento, identidade e reconstrução | C5B; caderno da bifurcação e auditoria C5B-QO | A geometria QO é histórico de toy model; não demonstra dinâmica holográfica fundamental |
| HRF-ST | Distância, dimensão, métrica, causalidade e espaço-tempo | Esqueleto e Cap. 1; C5B-QO como material histórico relacionado | Documento HRF-ST autônomo não localizado; microgeometria C5A não equivale automaticamente a espaço-tempo |
| HRF-FM | Gauge, fóton, microestrutura, estados ligados e matéria | C5A; notebook v1.1 + adendo; relatórios e programa do elétron | Derivação a partir de S_R permanece aberta; rotas cavidade e hopfion não fundidas |

**Mapeamento editorial provisório [D], inferido dos temas/títulos:** fóton/curl-curl/helicidade/B1–B3/B8/B10 → cap. 2; microgeometria/elasticidade/backreaction/B19/ELETRON 36 → cap. 3; massa/cavidade/ELETRON 34 e 38 → cap. 4; topologia/spin/carga/LVFS/programa elétron → cap. 5; C5B e bifurcação → cap. 6–7; geometria QO → relação histórica com cap. 8–10. Só é mapa de navegação; validação técnica de cada vínculo permanece pendente.

## 6. Correções, versões e discrepâncias

- Esqueleto v0.1: desatualizado como mapa corrente por substituição explícita v0.2; preservar histórico.
- Cap. 1 esqueleto v0.1 de 05/10: referido como substituído pelo texto v0.2; arquivo anterior não localizado.
- Notebook C5A v1.0: predecessor da v1.1; manter histórico. v1.1 isolada não incorpora o adendo v1.2.
- **Adendo §142 lido:** PHOTON-CLOSURE-E não replicada no protocolo pré-registrado (item 6 falhou em R2); registra PASS em 2/3 sementes, sem declarar fechado. O esqueleto atual chama o cap. 2 de fechado provisoriamente. Falta ler cap. 2 v1.1 e relatórios posteriores para verificar como o conflito foi resolvido; não transportar a declaração de fechamento para as bancadas históricas.
- Cap. 2: revisão terminológica para retirar PGFE como nomenclatura corrente ainda listada como tarefa no esqueleto.
- Programa elétron: fonte interna cita notebook v1.0 e cap. 2 C5A v1.0; conferir inclusão do v1.1 + adendo, sem presumir erro ou equivalência.
- Auditoria C5B-QO v0.2 usa classificações próprias [OK]/[COND]/[NR]/[CORRIGIR]/[ABERTO]. Preservar rubrica original; não converter mecanicamente em [F]/[M]. Registra R_rep≈1,183 r0 reproduzido; R_T≈4,77 r0 não reproduzido independentemente; Δz≈1,95 r0 condicionado ao matching; r0≲1 km é escala ilustrativa, não limite observacional. QW03 deve ser refeita para a nova família; limites QW02 não podem ser importados automaticamente.

## 7. Pastas verificadas e caminhos identificáveis

Caminhos abaixo começam no ancestral conhecido; não se inventa o prefixo completo de My Drive.

| Pasta | Caminho verificado/relativo | Filhos retornados |
|---|---|---|
| [Holographic-Reconstruction-Framework-HRF](https://drive.google.com/drive/folders/1INbTe-O8p3YhAKzMuKDwr0NBsCtuFR7_) | Holographic-Reconstruction-Framework-HRF | 10 |
| [Physics](https://drive.google.com/drive/folders/1LNO-IgUNzgWeeg2H99fLJUBmAWGLLqs9) | Physics | 4 |
| [00-Project-Overview](https://drive.google.com/drive/folders/1OxgAGUUVGnf1_gf1qjjY0cx17yDHE087) | Holographic-Reconstruction-Framework-HRF/00-Project-Overview | 2 |
| [Teoria-C5](https://drive.google.com/drive/folders/1_D92D3XpKS_OiYlf8I8TE2rDWcqvH_Ru) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 35 |
| [Testes-C5](https://drive.google.com/drive/folders/1sauAzosYiKYud8lJ59Qa2ltIsieX4KKB) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 88 |
| [C5A](https://drive.google.com/drive/folders/1FindwtEo-oTpW3f6RxGiLHhCIo0LWe4A) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 36 |
| [99-Archive](https://drive.google.com/drive/folders/1-fwY2IgBFfphGdoYvFHFLJFTG-ZbDaw0) | Holographic-Reconstruction-Framework-HRF/99-Archive | 0 |
| [09-Prompts-and-AI-Workflows](https://drive.google.com/drive/folders/1WhNvNdJT0CVUHpocF5vaMgIRC-02f7EX) | Holographic-Reconstruction-Framework-HRF/09-Prompts-and-AI-Workflows | 0 |
| [07-Manuscripts-and-Documents](https://drive.google.com/drive/folders/15I5Wp6-idwE5ZQh7kMdhC_wFUOD_aE5Y) | Holographic-Reconstruction-Framework-HRF/07-Manuscripts-and-Documents | 0 |
| [06-Figures-and-Diagrams](https://drive.google.com/drive/folders/1R3IFMO5-vxakt8LBlp4uRprpUm2wRa23) | Holographic-Reconstruction-Framework-HRF/06-Figures-and-Diagrams | 1 |
| [05-Data-and-Analysis](https://drive.google.com/drive/folders/1vDnmlJ5PhJG8M0eHVgBQ58L7_EZyQOh_) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis | 2 |
| [04-Research-Notebooks](https://drive.google.com/drive/folders/1R5xIV782jNKi76o3hXltDCgafnl_e2uP) | Holographic-Reconstruction-Framework-HRF/04-Research-Notebooks | 0 |
| [03-Models-and-Mechanisms](https://drive.google.com/drive/folders/1zDLMVydQNUGRgdDBxujjNG4oWSN9zUh6) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms | 5 |
| [02-Research-Questions-and-Hypotheses](https://drive.google.com/drive/folders/1t88_uTOlnamieg7Sl_fJGWBXQqPpaeGv) | Holographic-Reconstruction-Framework-HRF/02-Research-Questions-and-Hypotheses | 0 |
| [01-Literature](https://drive.google.com/drive/folders/1biyWRl0ZOyxd7haWN8_0hdEcHITbidJ7) | Holographic-Reconstruction-Framework-HRF/01-Literature | 0 |
| [C5A_B13_B15_B17_2026-10-03_0021-clau](https://drive.google.com/drive/folders/1PUK-D8z-OZEPHsTAW044yzTlsOZqaNPD) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B13_B15_B17_2026-10-03_0021-clau | 1 |
| [C5A_B13_B15_B17_2026-10-03_0319-colab](https://drive.google.com/drive/folders/11wZSunjLIN6_FUMOYk4yOf5qF1qRscAv) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B13_B15_B17_2026-10-03_0319-colab | 8 |
| [C5A_B3_birrefringencia_acumulada_2026-10-02_1558-clau](https://drive.google.com/drive/folders/1TLupoTN4ovFwVWfK5v5J_N-pKxfRH9VF) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B3_birrefringencia_acumulada_2026-10-02_1558-clau | 1 |
| [C5A_B19_2026-10-03_0907-colab](https://drive.google.com/drive/folders/1_j5ft0jvxLhDVY8EU6R7Kx9CDHmGQtZ7) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B19_2026-10-03_0907-colab | 5 |
| [C5A_B19_acoplamento_causal_2026-10-03_0610-clau](https://drive.google.com/drive/folders/1FAT63erjXCCK_3EKaqOa9pvX3oKcZjqg) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B19_acoplamento_causal_2026-10-03_0610-clau | 1 |
| [C5A_B1_photon_closure_v2_2026-10-02_0530-clau](https://drive.google.com/drive/folders/1U6dl07cAvclA9BRgURtLkwx4_nKeONqn) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B1_photon_closure_v2_2026-10-02_0530-clau | 1 |
| [C5A_B1_photon_closure_v2_2026-10-02_0530-clau_1](https://drive.google.com/drive/folders/14bF89DSvmH-yBRo9epdoMyE5vHZRu54R) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B1_photon_closure_v2_2026-10-02_0530-clau_1 | 1 |
| [C5A_B8_Lorentz_UV_isotropia_2026-10-02_1200-clau](https://drive.google.com/drive/folders/1vgoSE6pUo2w0BIp98zd0mGCp50GCuSmS) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B8_Lorentz_UV_isotropia_2026-10-02_1200-clau | 1 |
| [C5A_ELETRON_36_elasticidade_microgeometria_2026-10-03](https://drive.google.com/drive/folders/1nAZuMQYqSL__gnMP_6viBNNQf5JXhFnG) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_ELETRON_36_elasticidade_microgeometria_2026-10-03 | 1 |
| [C5A_ELETRON_34_contabilidade_massa_energia_2026-10-03](https://drive.google.com/drive/folders/17FfG61h0Sc7x6s5-XKh7YUdI8kPKEZns) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_ELETRON_34_contabilidade_massa_energia_2026-10-03 | 1 |
| [C5A_ELETRON_38_estado_orbital_autoinduzido_2026-10-03](https://drive.google.com/drive/folders/1QwIILWWNS5gDa652afIhkK04FiG0_ynH) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_ELETRON_38_estado_orbital_autoinduzido_2026-10-03 | 1 |
| [c5a_photon_closure](https://drive.google.com/drive/folders/16ebr5St_O3q10roGT0dwk8v-3KkWS60V) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/c5a_photon_closure | 8 |
| [C5A_prompts_B1_B2_B7_2026-10-01_2340-clau](https://drive.google.com/drive/folders/1A5GSrAV8QwNVb9bID4XI3oZOYXKAz1Gk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_prompts_B1_B2_B7_2026-10-01_2340-clau | 3 |
| [C5A_photon_closure_replicacao_2026-10-01_2305-clau](https://drive.google.com/drive/folders/1z5NSXxiO4w8zMQUJxKQant4USWZpUU9d) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_photon_closure_replicacao_2026-10-01_2305-clau | 10 |
| [SFI-CLAUDE-ELETRON](https://drive.google.com/drive/folders/1TkhKHygk1VDj9Ka5LcZ93JuObwCm3Dfp) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/SFI-CLAUDE-ELETRON | 3 |

00-Inbox/Physics contém as versões atuais do Cap. 1 e programa do elétron; a pasta do projeto contém o esqueleto em 00-Project-Overview. 04-Research-Notebooks e 07-Manuscripts-and-Documents retornaram vazias nesta verificação, embora notebooks existam em 03-Models-and-Mechanisms/Teoria-C5. Nenhum arquivo foi movido.

## 8. Inventário dos materiais históricos e relacionados

**Lido** só quando indicado na seção 1/6. Demais entradas foram localizadas por metadados, sem auditoria do conteúdo. Pastas são pontos de navegação, não prova de que o conteúdo esteja completo. IDs preservados permitem reconstruir caminhos mesmo quando o nome ancestral não foi resolvido.

| Arquivo/pasta | Localização identificável | Modificação informada | Tipo/status |
|---|---|---|---|
| [C5-CLAUDE-05](https://drive.google.com/drive/folders/1yVIiewMOO6Y3PinFIsnWPjwRQUgdML3D) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.707Z | Pasta localizada |
| [C5-CLAUDE-03](https://drive.google.com/drive/folders/1SGuumlTJ4qNCj81P1CCIlLVN0eWCWCyQ) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.704Z | Pasta localizada |
| [C5-CLAUDE-02](https://drive.google.com/drive/folders/1JllNrPkiGebMUmUf68uANcrl6bXmX3ls) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.701Z | Pasta localizada |
| [C5-CLAUDE-06](https://drive.google.com/drive/folders/1fh_CmFFuXaWj3GESL5z_g0-Oxj297sEV) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.700Z | Pasta localizada |
| [C5-CLAUDE-07](https://drive.google.com/drive/folders/1qzpdEbaRkZGn_wiMVPMzUiB0BcwckwMV) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.699Z | Pasta localizada |
| [C5-CLAUDE-08](https://drive.google.com/drive/folders/1r-sSD5Qy6WunTsiCWpicaJPrUJKK1WVt) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.699Z | Pasta localizada |
| [C5-CLAUDE-10](https://drive.google.com/drive/folders/1Uk3b4b2hG9bszfvrebQOBc_kGl-bxw2s) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.695Z | Pasta localizada |
| [C5-claude-01](https://drive.google.com/drive/folders/1UrO24510-glXD1YT0kg6YpsW_i0d98NF) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.690Z | Pasta localizada |
| [C5-CLAUDE-04](https://drive.google.com/drive/folders/1dMLqcc8B5JdnjM1iESmlDCWGkjrOp6Vj) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.689Z | Pasta localizada |
| [C5-CLAUDE-09](https://drive.google.com/drive/folders/1XNqdVjnj3QOZhEwJFEitdWkDYfu8WGBo) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.680Z | Pasta localizada |
| [C5A_LVFS_v01](https://drive.google.com/drive/folders/1T_NmsDhj1f894Gl17p60Zf6W4k-A-A2y) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.431Z | Pasta localizada |
| [C5A](https://drive.google.com/drive/folders/1FindwtEo-oTpW3f6RxGiLHhCIo0LWe4A) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.427Z | Pasta localizada |
| [C5A_Reorganizacao_Pesquisa_2026-10-01_2320-clau](https://drive.google.com/drive/folders/1cskwVVIUsrv-0v-OHiPu2mRAjrGmz2wt) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.405Z | Pasta localizada |
| [C5A_Reorganizacao_Pesquisa_D1_2026-10-01_2330-clau](https://drive.google.com/drive/folders/1vVbdKSpKaNmuXXNkuC7UYJ2t3wlAaK0h) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.037Z | Pasta localizada |
| [C5A_Reorganizacao_Pesquisa_2026-10-01_2320-clau (1)](https://drive.google.com/drive/folders/1Ak_2bOmsOuc0XU3T_hUl4xV6vz1WZSfc) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.036Z | Pasta localizada |
| [C5A_Reorganizacao_Pesquisa_HDL_2026-10-01_2340-clau](https://drive.google.com/drive/folders/1uIYvjY3f1ne74T8Z-xQOGXlVw9Yh4vEQ) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:50.015Z | Pasta localizada |
| [C5_pacote_chat_novo_2026-09-25_1507-clau](https://drive.google.com/drive/folders/19GXZ2c_TSbOBvkUJM6ECunZlxWOCkKcB) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:49.717Z | Pasta localizada |
| [Research_Notebook_C5A_Consolidacao_Microgeometria_Massa_v0_6_PT](https://drive.google.com/drive/folders/1Okx1M85SsPVuAaqcF0MKCKbbygjlYc50) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:21:49.709Z | Pasta localizada |
| [Teoria_C5_Caderno_Base_Bifurcacao_C5A_C5B_v0_1_PT_TUI.docx](https://docs.google.com/document/d/1fb9HcUJ3YoWkr26d012As2ow5nU8J7-v/edit?usp=drivesdk&ouid=114819923691083378498&rtpof=true&sd=true) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-05T22:01:25.000Z | application/vnd.openxmlformats-officedocument.wordprocessingml.document |
| [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_v2_0_PT_2026-10-01_2350-clau (1).md](https://drive.google.com/file/d/1m_MYSQs6VPkZnojsFl9GBYDXD2WHm4jx/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-02T02:30:14.635Z | text/markdown |
| [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_v2_0_PT_2026-10-01_2350-clau.md](https://drive.google.com/file/d/1jUQnVEewhXv4Bph8jneOo_yGEK2NzPBv/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-02T02:29:54.240Z | text/markdown |
| [C5A_Mapa_Reorganizado_da_Pesquisa_v1_0_PT_2026-10-01_2320-clau.md](https://drive.google.com/file/d/1PzLbpL55vAc2XPdm7tfdNyiF60oM2OdU/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-02T02:16:21.938Z | text/markdown |
| [C5A_Atualizacao_28_Acao_Universal_Transicao_hbar_PT.md](https://drive.google.com/file/d/1Io0nANJkAA0orZmsrkAFregDciV7B3NO/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-02T00:50:40.561Z | text/markdown |
| [C5A_Guia_Inicio_Chat_Proximas_Perguntas_PT.md](https://drive.google.com/file/d/1o2n0904ep0XTfr3llh0qufE2-M-TR845/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-02T00:50:20.483Z | text/markdown |
| [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_PT.md](https://drive.google.com/file/d/1xoFAxjvKsfsuRbwmc812ufwTTn2Tjobg/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-02T00:50:11.858Z | text/markdown |
| [C5A_Atualizacao_27_G0G_Fundo_Compensado_Backreaction_PT.md](https://drive.google.com/file/d/1aCjq_U76-TpQshqbvxeJIqxG2lNyU64F/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-01T21:50:07.875Z | text/markdown |
| [C5A_Atualizacao_26_Holonomia_Loops_Conexao_Relacional_PT.md](https://drive.google.com/file/d/1-iEbQNAcwYFm_IvzXno7IAsf3qxB8akl/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-01T21:49:56.471Z | text/markdown |
| [Master_Research_Notebook_C5A_v1_1_PT_2026-10-01_1816-clau.md](https://drive.google.com/file/d/1J_0upqihHazEWkCLXzWT9Hl0Ca3GGkyf/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-01T21:46:43.788Z | text/markdown |
| [C5A_Atualizacao_25_Vales_Hierarquicos_Foton_Eletron_PT.docx](https://docs.google.com/document/d/1YYBtwB-TcYK5ACyL3jInklJSCqK9f9tS/edit?usp=drivesdk&ouid=114819923691083378498&rtpof=true&sd=true) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-10-01T21:13:14.770Z | application/vnd.openxmlformats-officedocument.wordprocessingml.document |
| [Master_Research_Notebook_C5A_v1_0_PT.md](https://drive.google.com/file/d/1Uipmx6D6T2zitwEMB30guDhcFEiLIIt8/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-09-30T02:31:33.902Z | text/markdown |
| [Research_Notebook_C5A_Consolidacao_Microgeometria_Massa_v0_6_PT.md](https://drive.google.com/file/d/1pXT9xWRI4cM486QjnG4_K5XTxg9MqqFq/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-09-30T01:58:54.774Z | text/markdown |
| [C5A_Relativizacao_da_Microfisica_EGM_PRM_v0_1.md](https://drive.google.com/file/d/16OsvvGvmRiaEJlv_3ZgnYJFsfTYTHexB/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5 | 2026-09-30T00:04:25.402Z | text/markdown |
| [C5-CLAUDE-02](https://drive.google.com/drive/folders/1OiTepaRdsYnVVU2NOTGNYRqzCNqCwZyG) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.720Z | Pasta localizada |
| [C5-claude-01](https://drive.google.com/drive/folders/1goeC929t_G6kMehWEjB2Ted-JMY2pG2T) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.719Z | Pasta localizada |
| [C5-CLAUDE-04](https://drive.google.com/drive/folders/15W1qHRgI-DY3zpyW592J-Tjh8B6huKAX) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.707Z | Pasta localizada |
| [C5-CLAUDE-03](https://drive.google.com/drive/folders/1e8Td-KmWfy0GtHPzli9zYGdY9TQx0j2w) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.692Z | Pasta localizada |
| [C5-CLAUDE-05](https://drive.google.com/drive/folders/1btc9wSMT4FYmArx7nMbw7Wy6CwHFMXrW) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.689Z | Pasta localizada |
| [C5-CLAUDE-06](https://drive.google.com/drive/folders/1-OV5ZuL2vcBMeWDqEtacsj18ijt-c4_P) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.438Z | Pasta localizada |
| [C5-CLAUDE-07](https://drive.google.com/drive/folders/1EBPVtMmouuTYXb_LawXFXzS4CloXeD1h) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.420Z | Pasta localizada |
| [C5-CLAUDE-08](https://drive.google.com/drive/folders/1aiYbJdVdovovJbcqCDRDmOA93lp2Zb3m) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.416Z | Pasta localizada |
| [C5-CLAUDE-10](https://drive.google.com/drive/folders/11xRQ6qp3Mo59pZIYL-4Dd0q08j8ijSSP) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.051Z | Pasta localizada |
| [C5A_B13_B15_B17_2026-10-03_0021-clau](https://drive.google.com/drive/folders/1PUK-D8z-OZEPHsTAW044yzTlsOZqaNPD) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.048Z | Pasta localizada |
| [C5-CLAUDE-09](https://drive.google.com/drive/folders/1R30Ixm7k0Id8Yk6sk0ZaSjM6scPSXTee) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:53.042Z | Pasta localizada |
| [C5A_B13_B15_B17_2026-10-03_0319-colab](https://drive.google.com/drive/folders/11wZSunjLIN6_FUMOYk4yOf5qF1qRscAv) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.729Z | Pasta localizada |
| [C5A_B2_conexao_compacta_2026-10-02_0545-clau](https://drive.google.com/drive/folders/1HPWpnx_H9CSWd_9OLBj17gIOGN3s1JOB) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.716Z | Pasta localizada |
| [C5A_B3_birrefringencia_acumulada_2026-10-02_1558-clau](https://drive.google.com/drive/folders/1TLupoTN4ovFwVWfK5v5J_N-pKxfRH9VF) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.714Z | Pasta localizada |
| [C5A_B19_2026-10-03_0907-colab](https://drive.google.com/drive/folders/1_j5ft0jvxLhDVY8EU6R7Kx9CDHmGQtZ7) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.711Z | Pasta localizada |
| [C5A_B7_massa_virtual_HDL_2026-10-02_0645-clau](https://drive.google.com/drive/folders/1NZyXzofyOnCFoEXPHVqxdA5K5Ko7g3ty) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.706Z | Pasta localizada |
| [C5A_B19_acoplamento_causal_2026-10-03_0610-clau](https://drive.google.com/drive/folders/1FAT63erjXCCK_3EKaqOa9pvX3oKcZjqg) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.705Z | Pasta localizada |
| [C5A_B1_photon_closure_v2_2026-10-02_0530-clau](https://drive.google.com/drive/folders/1U6dl07cAvclA9BRgURtLkwx4_nKeONqn) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.701Z | Pasta localizada |
| [C5A_B1_photon_closure_v2_2026-10-02_0530-clau_1](https://drive.google.com/drive/folders/14bF89DSvmH-yBRo9epdoMyE5vHZRu54R) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.701Z | Pasta localizada |
| [C5A_B8_Lorentz_UV_isotropia_2026-10-02_1200-clau](https://drive.google.com/drive/folders/1vgoSE6pUo2w0BIp98zd0mGCp50GCuSmS) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.687Z | Pasta localizada |
| [C5A_ELETRON_36_elasticidade_microgeometria_2026-10-03](https://drive.google.com/drive/folders/1nAZuMQYqSL__gnMP_6viBNNQf5JXhFnG) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.419Z | Pasta localizada |
| [C5A_ELETRON_34_contabilidade_massa_energia_2026-10-03](https://drive.google.com/drive/folders/17FfG61h0Sc7x6s5-XKh7YUdI8kPKEZns) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.415Z | Pasta localizada |
| [C5A_G0B_G2B_frame_dragging_bancada](https://drive.google.com/drive/folders/11X_ep_4NB0NofJyeYO1SKr_fTxFh4qQs) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.049Z | Pasta localizada |
| [C5A_G0B_G2B_frame_dragging_bancada (1)](https://drive.google.com/drive/folders/18G2XkZW1uXPf_FA17OBDOPfscPzW03UX) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.041Z | Pasta localizada |
| [C5A_ELETRON_38_estado_orbital_autoinduzido_2026-10-03](https://drive.google.com/drive/folders/1QwIILWWNS5gDa652afIhkK04FiG0_ynH) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:52.040Z | Pasta localizada |
| [C5A_G0B_G2B_frame_dragging_bancada (2)](https://drive.google.com/drive/folders/1AoKm3VNgMzcnTQOL4NPrTXvAbOfKZnwH) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.729Z | Pasta localizada |
| [C5A_G0B_G2B_frame_dragging_bancada (3)](https://drive.google.com/drive/folders/1FMMNcWsO_W2JyKM7MKGR90HzLgxviide) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.722Z | Pasta localizada |
| [C5A_G0B_G2B_frame_dragging_bancada (5)](https://drive.google.com/drive/folders/1WKggnjrXbzHCkwcy5dbIz49PSha4ithd) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.713Z | Pasta localizada |
| [C5A_G0B_G2B_frame_dragging_bancada (4)](https://drive.google.com/drive/folders/13QcTTrpqsVd6U_EFMxBH2oe4AyiWit0T) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.705Z | Pasta localizada |
| [C5A_prompts_B1_B2_B7_2026-10-01_2340-clau](https://drive.google.com/drive/folders/1A5GSrAV8QwNVb9bID4XI3oZOYXKAz1Gk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.704Z | Pasta localizada |
| [C5A_photon_closure_replicacao_2026-10-01_2305-clau](https://drive.google.com/drive/folders/1z5NSXxiO4w8zMQUJxKQant4USWZpUU9d) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.689Z | Pasta localizada |
| [C5_testes_emaranhamento_especial_2026-09-28_1617-clau](https://drive.google.com/drive/folders/1lQ2LFsLpWS_uFI-iGowDI-1YtwXoKCE4) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.422Z | Pasta localizada |
| [C5_pacote_chat_novo_2026-09-25_1507-clau](https://drive.google.com/drive/folders/1L07FHCJeyVcuVI1UgLanDkyRJSvsYlGj) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-05T22:21:51.403Z | Pasta localizada |
| [C5B_QO_Auditoria_Completa_Funil_Terra_v0_2_PT_TUI.md](https://drive.google.com/file/d/1WfzVNa7cQkBOSRS8cJHSEXbpQDtdKScM/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-03T17:50:12.947Z | text/markdown |
| [C5A_ELETRON_22_RELATORIO.md](https://drive.google.com/file/d/1H7OrDPc9RAA-yOy_7reZQ1PVRo8dXN89/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-03T09:06:06.094Z | text/markdown |
| [C5A_ELETRON_20_RELATORIO.md](https://drive.google.com/file/d/1ly1ILNaIRXoL0fvwkwdp4YzVEOn4Pmai/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-03T09:05:50.739Z | text/markdown |
| [C5A_Colab_B19_acoplamento_causal_2026-10-03_0045-clau.ipynb](https://drive.google.com/file/d/1Y5CWUqLMDZYF1aPTshFBr_MsPQMogCRc/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-03T03:37:36.126Z | application/octet-stream |
| [C5A_Colab_B13_B15_B17_2026-10-02_2342-clau.ipynb](https://drive.google.com/file/d/1I8t68wg_6c8zZ3y-n8XqVEWmtODNDWzU/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-03T02:42:51.346Z | application/octet-stream |
| [C5A_Colab_B13_B15_B17_PT_2026-10-02_2229-clau.md](https://drive.google.com/file/d/1OXAfcpT2lJVWXif7Jjvjsc-YtZz-hNLa/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-03T01:29:53.358Z | text/markdown |
| [C5A_ELETRON_09_quatro_fotons_resumo.csv](https://drive.google.com/file/d/142VA49SyjlYWC0V26Egp6g-NjTLgV2xt/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-02T18:53:22.744Z | text/csv |
| [C5A_ELETRON_08_resumo.csv](https://drive.google.com/file/d/1TATakfoiLnC_MspoLOwAsQ4mVEmqSR9d/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-02T18:53:07.209Z | text/csv |
| [C5A_ELETRON_07C_grudadas_resumo.csv](https://drive.google.com/file/d/1j-iwOLSqitUGdUm2KUx8w9J2iJ0O4FBI/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-02T18:51:52.839Z | text/csv |
| [C5A_prompt_B10_quantizacao_rede_fase_Coulomb_2026-10-02_1150-clau.md](https://drive.google.com/file/d/1XAcgNca2Ez19QUl15LdbTpG3F7AjaJZ3/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-02T16:55:55.515Z | text/markdown |
| [C5A_prompt_B3_birrefringencia_acumulada_2026-10-02_1150-clau.md](https://drive.google.com/file/d/18k8-zL1_HckIcyJUihHgQhgQhCj2Ug6M/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-02T16:55:50.621Z | text/markdown |
| [C5A_Prompt_Mestre_Programa_Eletron_v1_PT.md](https://drive.google.com/file/d/14i_HOpP27NLaSZwIhaL3y1iqbfyvHLXK/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-02T02:12:56.860Z | text/markdown |
| [image-backreaction-C5A.png](https://drive.google.com/file/d/1ArcNOxwrvgxxFs13KwHOI5f8-bKjq6j6/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-01T20:51:43.982Z | image/png |
| [holonomia-C5A.png](https://drive.google.com/file/d/19r0zeA1P4nYov3APJurLccrqK307532h/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-10-01T20:51:01.705Z | image/png |
| [C5U_VP02_Prompt_Codex.md](https://drive.google.com/file/d/1lYuc0w5y1I_IuqCnRq2UN8QzGb8jTjHu/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-09-30T01:19:35.569Z | text/markdown |
| [Teoria_C5_Resultados_T1_a_T45_E01_E02_A01_a_A08_S01_a_S05_v0_38_PT_2026-09-27_0338-clau.docx](https://docs.google.com/document/d/1pK5M7RWM7pdIg36qvHJTkjCrM8W4aoD0/edit?usp=drivesdk&ouid=114819923691083378498&rtpof=true&sd=true) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-09-30T00:01:48.523Z | application/vnd.openxmlformats-officedocument.wordprocessingml.document |
| [C5A_testes_foton_guia.md](https://drive.google.com/file/d/1Z6hIupLCFio1oqhknO6kuZZDUNJ8sWD5/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-09-28T22:20:12.876Z | text/markdown |
| [C5A_v04.md](https://drive.google.com/file/d/1EWVYwxg3bJPlGnCy507qd3hLjY9mcqCG/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-09-28T21:57:48.598Z | text/markdown |
| [C5A-03](https://docs.google.com/document/d/17b7YWSArt-W_Xk3YvELzpf20GT2_AmeZ/edit?usp=drivesdk&ouid=114819923691083378498&rtpof=true&sd=true) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5 | 2026-09-28T21:41:27.969Z | application/vnd.openxmlformats-officedocument.wordprocessingml.document |
| [C5A_G0F_semente_quiral_2026-09-30_1115-clau](https://drive.google.com/drive/folders/1cTVh6AxoH8X73UU9rS7tesTAVHEHHjwk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-05T22:21:58.746Z | Pasta localizada |
| [C5A_Atualizacao_05_FR3D_Spin_1_2_PT](https://drive.google.com/drive/folders/1zcOs4MxH-ETue9gTvWrVETd6LmJojKl2) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-05T22:21:58.743Z | Pasta localizada |
| [C5A_Atualizacao_04_Spin_1_2_3D_Estado_PT](https://drive.google.com/drive/folders/1MCetKYEKtfz5B7p6awjw_ewTxQ3aKWh0) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-05T22:21:58.731Z | Pasta localizada |
| [Master_Research_Notebook_C5A_v1_1_PT_2026-10-01_1816-clau.md](https://drive.google.com/file/d/18HcBwHvwQ488b644m2_ZaWLrRLfLZnj4/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T21:21:45.081Z | text/markdown |
| [imagemCURLemergenteC5A.png](https://drive.google.com/file/d/1Yl62p2spqUuAfqz-weVo_f03pO1Cvc8l/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T20:55:30.618Z | image/png |
| [imagem-tapeteGMFgirando-C5A.jpg](https://drive.google.com/file/d/1RUxp2pQWDhdZdlbmet3YsM4a9ldx5AKT/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T20:54:31.043Z | image/jpeg |
| [image-microgeometria-C5A.png](https://drive.google.com/file/d/1e8Xt5SZbdJnbNs40NU8JADglpZMAgpHe/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T20:53:12.723Z | image/png |
| [C5A_Atualizacao_23_G0F_Semente_Quiral_Backreaction_PT.md](https://drive.google.com/file/d/1_0tpvjQ0Bxk0jFUXUPyGDYtTlMAWTnHQ/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T20:49:27.213Z | text/markdown |
| [C5A_Atualizacao_24_Hipotese_Fechamento_Foton_Modo_Ligado_PT.md](https://drive.google.com/file/d/1Y6xU4Xv3uZBAF8fbzaky0dIdqutPe15g/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T20:47:22.045Z | text/markdown |
| [C5A_Atualizacao_25_Vales_Hierarquicos_Foton_Eletron_PT.md](https://drive.google.com/file/d/1CJGNpe2JGz6tvdpJse0MlgN19ctDV0bV/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T20:46:38.063Z | text/markdown |
| [C5A_Atualizacao_22_Duas_Hipoteses_Quiralidade_Dupla_Helice_PT.md](https://drive.google.com/file/d/1JBQ7BeZxGQyso_sb09fIgLJLnSjrqEo0/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:11:30.083Z | text/markdown |
| [C5A_Atualizacao_21_Dupla_Helice_Fita_GMF_Loops_PT.md](https://drive.google.com/file/d/1rBsTXHDvcvHfvLwWoo4CDxTY2-DYVw98/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:11:10.135Z | text/markdown |
| [C5A_Atualizacao_20_CurlCurl_Emergente_Loops_GMF_PT.md](https://drive.google.com/file/d/1fk1OnJ2-qU4mJdUAnykgFagzpr3W3NwM/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:10:48.525Z | text/markdown |
| [C5A_Atualizacao_19_Poco_Girando_OAM_e_Proximo_Teste_Helicidade_PT.md](https://drive.google.com/file/d/190Sr8zd5rNXQyZp7JDuMdmmALJJXVYII/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:10:25.157Z | text/markdown |
| [C5A_Atualizacao_18_Tapete_GMF_Microgeometria_PT.md](https://drive.google.com/file/d/1iu0rH-Ly4X75D5PFBdv4FkgIHP0wMNEz/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:10:08.312Z | text/markdown |
| [C5A_Atualizacao_17_Microgeometria_Vales_PT.md](https://drive.google.com/file/d/1iwwKhLmtxtbIJSn0-mrnlICwXyTEcZMg/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:09:58.578Z | text/markdown |
| [C5A_Atualizacao_16_Roteiro_Fechamento_Foton_PT.md](https://drive.google.com/file/d/12iTDGY2k1bASucl0RK3mT2YKdk40Z1cY/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:09:29.596Z | text/markdown |
| [C5A_Atualizacao_15_Teste_Leve_CurlCurl_Modo_Circular_PT.md](https://drive.google.com/file/d/1O6rpkB3xcBI8E3KqTUFMSpPLBNNfCXcC/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:09:17.981Z | text/markdown |
| [C5A_Atualizacao_14_Rotacao_da_Rotacao_CurlCurl_PT.md](https://drive.google.com/file/d/1dteQ2RnhxvRFhIQBUv378SRdYiuehO7q/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:09:06.407Z | text/markdown |
| [C5A_Atualizacao_13_Helice_Pequena_Helicidade_Foton_PT.md](https://drive.google.com/file/d/1kyEFGTClEFHPCB1qqwGv2JeKpRXZ4ugU/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:08:49.380Z | text/markdown |
| [C5A_Atualizacao_12_Dupla_Escala_Helicoidal_GMF_PT.md](https://drive.google.com/file/d/1GsOy_fypZfHTFdVNwO5TqeW9ejIW9xyL/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:08:35.915Z | text/markdown |
| [C5A_Atualizacao_11_Propagacao_Sequencial_GMFs_PT.md](https://drive.google.com/file/d/106XQ41F8XXBUCp4pxfDYMNZACm8AnKEb/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:08:18.625Z | text/markdown |
| [C5A_Atualizacao_10_Onda_Nao_Linear_Controle_Fundo_Plano_PT.md](https://drive.google.com/file/d/1e2JHKgLkRTJuhaDE_BGh_aRdOIOlXThL/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:08:05.958Z | text/markdown |
| [C5A_Atualizacao_09_Microgeometria_Holografica_Antes_dos_GMFs_PT.md](https://drive.google.com/file/d/1AvhxFXfi8Uf1-mRr4z9C4j9UWemkrnUG/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:06:57.430Z | text/markdown |
| [C5A_Atualizacao_08_Programa_Ponte_GMF_PT.md](https://drive.google.com/file/d/1Xlb_vjb23n0P9Bm8OQZ4fykZw0BigYgt/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:06:40.821Z | text/markdown |
| [C5A_Atualizacao_07_Auditoria_Mar_GMF_Modelo_Efetivo_PT.md](https://drive.google.com/file/d/1PhLkDxMe8J-1aDyFdjdavkV34E2oivc0/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:06:22.748Z | text/markdown |
| [C5A_Atualizacao_06_Fechamento_FR3D_Proximo_Teste_PT.md](https://drive.google.com/file/d/1aVzbTOTZSgMjCXiwVDDzzJHqq46wphNL/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:06:05.345Z | text/markdown |
| [C5A_Atualizacao_05_FR3D_Spin_1_2_PT.md](https://drive.google.com/file/d/1vgXO2C19lwgAlChf7S3CRBM7gMwa59D4/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:05:46.633Z | text/markdown |
| [C5A_Atualizacao_04_Spin_1_2_3D_Estado_PT.md](https://drive.google.com/file/d/1OTu27SE0vWdcpiPY0g01EgNW-OxcrnIO/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:05:18.174Z | text/markdown |
| [C5A_Atualizacao_03_No_Supercondutor_Fluxo_Topologico_PT.md](https://drive.google.com/file/d/1yUvW7JbCUzwlwMDixga_xrA0wYxVdkaH/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:04:53.686Z | text/markdown |
| [C5A_Atualizacao_02_G0D_Saca_Rolha_Microgeometria_PT.md](https://drive.google.com/file/d/1bxKwTQxDzb3WqJBrV44sOM2Pw9ZSfzWF/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:04:48.258Z | text/markdown |
| [C5A_Nota_Rapida_CEM_CIN_Microgeometria_v0_1_PT.md](https://drive.google.com/file/d/1LHyrVaiZjylBMNOlAhP1AJiIq5RnNwTd/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:04:26.793Z | text/markdown |
| [C5A_CEM_CMG_Hipoteses_v0_1_PT.md](https://drive.google.com/file/d/1D31dg6jylCUfnPWKPWQ5s2eFRbirQK8o/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:03:40.136Z | text/markdown |
| [Master_Research_Notebook_C5A_v1_0_PT (1).md](https://drive.google.com/file/d/1PlFQb6fFGnb_FNG1uzsVezM5U0EWi2z5/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms/Teoria-C5/C5A | 2026-10-01T15:03:16.297Z | text/markdown |
| [Testes-C5](https://drive.google.com/drive/folders/1sauAzosYiKYud8lJ59Qa2ltIsieX4KKB) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis | 2026-10-05T22:21:46.703Z | Pasta localizada |
| [Teoria-C5](https://drive.google.com/drive/folders/1_D92D3XpKS_OiYlf8I8TE2rDWcqvH_Ru) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms | 2026-10-05T22:21:46.705Z | Pasta localizada |
| [Teoria_C5_Caderno_Base_Bifurcacao_C5A_C5B_v0_1_PT_TUI.pdf](https://drive.google.com/file/d/1T-fCK6d8kU1agm64M6WO1dPWvUZkM9P1/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/03-Models-and-Mechanisms | 2026-10-05T22:01:57.000Z | application/pdf |
| [Research_Notebook_C5A_Consolidacao_Microgeometria_Massa_v0_6_PT.md](https://drive.google.com/file/d/14xZRYgM6_KHJv4uqM24J2LeOOHvf2aVz/view?usp=drivesdk) | [pasta 1Okx1M85SsPVuAaqcF0MKCKbbygjlYc50] | 2026-09-30T04:57:38.000Z | text/markdown |
| [C5A_photon_closure_guia.md](https://drive.google.com/file/d/1-JHQigW6EQ6nCKXRZrubtmRWQBRpgijg/view?usp=drivesdk) | [pasta 1e1FhmfRQaV_uUSrIrzgdmhnRDkgwX3Nh] | 2026-10-02T02:41:36.000Z | text/markdown |
| [C5A_curl_curl_emergente_guia.md](https://drive.google.com/file/d/1Z0-tn2X7pm42-7rkq2nJY5qCW4Wsiaeg/view?usp=drivesdk) | [pasta 1CFNfuB576aRM--6h8MaQ-jSgbTAQ9c6Y] | 2026-10-01T07:47:32.000Z | text/markdown |
| [C5A_LVFS_v01.docx](https://docs.google.com/document/d/1zp94_ZreQejgCvoKcLLIZWRd9soySq7a/edit?usp=drivesdk&ouid=114819923691083378498&rtpof=true&sd=true) | [pasta 1T_NmsDhj1f894Gl17p60Zf6W4k-A-A2y] | 2026-09-29T17:07:12.000Z | application/vnd.openxmlformats-officedocument.wordprocessingml.document |
| [C5A_g0g_backreaction_guia.md](https://drive.google.com/file/d/15Ojl-ip6uG1WMscE4BuhwRK3Ltnb2ENk/view?usp=drivesdk) | [pasta 1XWCdysO9s5zzMgEvvYiXTzQ66YuqMTyZ] | 2026-10-01T21:34:00.000Z | text/markdown |
| [C5A_tapete_gmf_guia.md](https://drive.google.com/file/d/1k6VTrqVY4x7zQ4ja1QqxWoubr0Yt_T5_/view?usp=drivesdk) | [pasta 1dJLVlnZKyXcO6YKEU2B8hH2F-Ge2_pf8] | 2026-10-01T03:35:54.000Z | text/markdown |
| [C5A_holonomia_loops_guia.md](https://drive.google.com/file/d/1-vfYGmgVYapkfE14X1m-oXFySWiP1wed/view?usp=drivesdk) | [pasta 1nmyRdy65dmGwY4HgOONiJ7FRSYSKzODi] | 2026-10-01T16:43:32.000Z | text/markdown |
| [C5A_holonomia_loops_guia.md](https://drive.google.com/file/d/1KJXxhcwhbHolSv9oglo3c1ODxvb2Vrys/view?usp=drivesdk) | [pasta 1xSWcob_rSPKtcy3DtTye5OP4ltySg2df] | 2026-10-01T16:43:32.000Z | text/markdown |
| [C5A_G0F_semente_quiral_relatorio_2026-09-30_1115-clau.md](https://drive.google.com/file/d/1d6xj7x-YBBK2jO20syGSJuIYW3JRrq1O/view?usp=drivesdk) | [pasta 1cTVh6AxoH8X73UU9rS7tesTAVHEHHjwk] | 2026-09-30T14:16:38.000Z | text/markdown |
| [C5A_prompt_B8_Lorentz_UV_isotropia_2026-10-02_1150-clau.md](https://drive.google.com/file/d/1-oNNrILJnMbH2VrR9tjWZRJYFPy_v8hE/view?usp=drivesdk) | [pasta 1eayJSKy3EIdw0ZwV6VO4AUihKvOeP1gt] | 2026-10-02T14:56:38.000Z | text/markdown |
| [C5A_interferometro_drs_guia.md](https://drive.google.com/file/d/1N1TR6DPFqlTt_2LGFYGqgRXtjcPZgist/view?usp=drivesdk) | [pasta 19OMx83t7OTKjK33dUrZM53B9Z0YdWtc5] | 2026-09-29T04:57:00.000Z | text/markdown |
| [C5A_prompt_B3_birrefringencia_acumulada_2026-10-02_1150-clau.md](https://drive.google.com/file/d/1BqYDxlwy2l8d-zFxqdzyj46jIu78Q9fw/view?usp=drivesdk) | [pasta 1sMO7Eavcza8TUqDldVDrr1pXlxzvn0rs] | 2026-10-02T18:40:56.000Z | text/markdown |
| [C5A_prompt_curl_curl_emergente.md](https://drive.google.com/file/d/1_Sfv50Swcxs8Z9Nd1u3E4iEgS1603BQQ/view?usp=drivesdk) | [pasta 1CFNfuB576aRM--6h8MaQ-jSgbTAQ9c6Y] | 2026-10-01T07:47:32.000Z | text/markdown |
| [C5A_teste_spinor_guia_v2claudecode.md](https://drive.google.com/file/d/1UxTROwfzDmwyBhnRZOorftU4HsiShsKW/view?usp=drivesdk) | [pasta 19OMx83t7OTKjK33dUrZM53B9Z0YdWtc5] | 2026-09-29T04:36:52.000Z | text/markdown |
| [C5A_prompt_B1_photon_closure_v2_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1qn8YaBQStKeW_PSqLRm1azvIgV88sxl4/view?usp=drivesdk) | [pasta 16x416gUolLY6Vxxprqy0mFzD34phxrOi] | 2026-10-02T17:01:12.720Z | text/markdown |
| [C5A_prompt_B1_photon_closure_v2_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1ecHtU4vX8MJLYYBCX8gQzWoQyogKeDJY/view?usp=drivesdk) | [pasta 1ThX_KzJIK1MgTCPGBu82mN9xvGlYXsDG] | 2026-10-02T08:26:34.000Z | text/markdown |
| [C5A_prompt_B1_photon_closure_v2_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1GmDGM5hKjsqxpTlN8DMK-zuRyrHky0KS/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_prompts_B1_B2_B7_2026-10-01_2340-clau | 2026-10-02T02:35:35.953Z | text/markdown |
| [C5A_prompt_holonomia_loops.md](https://drive.google.com/file/d/1nbPDIRhjoVsDcuJCJ7dj4P6IZyFCQ4w5/view?usp=drivesdk) | [pasta 1nmyRdy65dmGwY4HgOONiJ7FRSYSKzODi] | 2026-10-01T16:43:32.000Z | text/markdown |
| [C5A_prompt_holonomia_loops.md](https://drive.google.com/file/d/1me7NaQJIyTLMNnb69DtA_mgnJJuxHmNf/view?usp=drivesdk) | [pasta 1xSWcob_rSPKtcy3DtTye5OP4ltySg2df] | 2026-10-01T16:43:32.000Z | text/markdown |
| [C5A_microgeometria_vales_guia.md](https://drive.google.com/file/d/1wbu_aiGYWoDNePERr4DkIX3E6bwSstWD/view?usp=drivesdk) | [pasta 1e23WNfBm8I5-BJf8lkQl1n9q-PAhNYDt] | 2026-09-30T23:51:00.000Z | text/markdown |
| [C5A_teste_longitudinal_guia.md](https://drive.google.com/file/d/18M4IfQwX9ZugB2_s8Geghz3QCIBLrHN4/view?usp=drivesdk) | [pasta 19OMx83t7OTKjK33dUrZM53B9Z0YdWtc5] | 2026-09-29T02:39:12.000Z | text/markdown |
| [C5A_testes_foton_guia_v2claudecode.md](https://drive.google.com/file/d/1-ibOf_fMkz2Szg82Oe3M1g88g35fsGyT/view?usp=drivesdk) | [pasta 19OMx83t7OTKjK33dUrZM53B9Z0YdWtc5] | 2026-09-29T02:39:12.000Z | text/markdown |
| [C5A_testes_foton_guia.md](https://drive.google.com/file/d/1wXeIJXgawwoR7kB8gaYAxOhgAd_5kL6E/view?usp=drivesdk) | [pasta 1HKyxmySZJk7pXlRJveCTrqpZDw-4mrRf] | 2026-09-29T01:21:50.000Z | text/markdown |
| [C5A_B1_PREREGISTRO_2026-10-01_2350-clau.md](https://drive.google.com/file/d/1GETRGRI21L5au6jUEhiAu5hwUiMJC5nJ/view?usp=drivesdk) | [pasta 16x416gUolLY6Vxxprqy0mFzD34phxrOi] | 2026-10-02T17:01:12.665Z | text/markdown |
| [C5A_B8_PREREGISTRO_2026-10-02_1153-clau.md](https://drive.google.com/file/d/131kkWxCJ3IcdJ2fI0Hee7peoCBH5f1Es/view?usp=drivesdk) | [pasta 1eayJSKy3EIdw0ZwV6VO4AUihKvOeP1gt] | 2026-10-02T14:56:38.000Z | text/markdown |
| [C5A_B1_PREREGISTRO_2026-10-01_2350-clau.md](https://drive.google.com/file/d/15gLkvGbYR6wJBFEgl-D2OJ2TVIqqdIT2/view?usp=drivesdk) | [pasta 1ThX_KzJIK1MgTCPGBu82mN9xvGlYXsDG] | 2026-10-02T02:44:28.000Z | text/markdown |
| [C5A_B1_photon_closure_v2_relatorio_2026-10-02_0530-clau.md](https://drive.google.com/file/d/1FvxIyXbZa5UtBsnj9HA7YPAbHuaVLsBp/view?usp=drivesdk) | [pasta 16x416gUolLY6Vxxprqy0mFzD34phxrOi] | 2026-10-02T17:01:12.657Z | text/markdown |
| [C5A_B7_massa_virtual_HDL_relatorio_2026-10-02_0645-clau.md](https://drive.google.com/file/d/1FcTO16DVjas8CTtel0XyKyWWFCq0D9BH/view?usp=drivesdk) | [pasta 1pELY67W2l7aCisssZ4A1Z6dfXMs50fEs] | 2026-10-02T09:34:48.000Z | text/markdown |
| [C5A_B1_photon_closure_v2_relatorio_2026-10-02_0530-clau.md](https://drive.google.com/file/d/1jITfS3V46wVTWl7TmlnaYWen6XBXb2z6/view?usp=drivesdk) | [pasta 1ThX_KzJIK1MgTCPGBu82mN9xvGlYXsDG] | 2026-10-02T08:26:28.000Z | text/markdown |
| [C5A_prompt_photon_closure.md](https://drive.google.com/file/d/1xzWY2iGS2uzbPcaGD9g2UElRbChcQq0a/view?usp=drivesdk) | [pasta 1e1FhmfRQaV_uUSrIrzgdmhnRDkgwX3Nh] | 2026-10-02T01:14:40.000Z | text/markdown |
| [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1Fh-PV-HL_kVZ97YjBI2WPVekBjfTN1DU/view?usp=drivesdk) | [pasta 18G2XkZW1uXPf_FA17OBDOPfscPzW03UX] | 2026-09-30T01:59:54.000Z | text/markdown |
| [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1jkQUhRTKNnLwJtt3-7HNCwfya1k9IMKy/view?usp=drivesdk) | [pasta 11X_ep_4NB0NofJyeYO1SKr_fTxFh4qQs] | 2026-09-30T01:59:54.000Z | text/markdown |
| [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1rfaT02nGHMV11C5dSPCJRmmzP0TAL4V9/view?usp=drivesdk) | [pasta 1FMMNcWsO_W2JyKM7MKGR90HzLgxviide] | 2026-09-30T01:59:54.000Z | text/markdown |
| [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1nEp-hDNI9Q1ual5c_ddtbYFlWURrAkDV/view?usp=drivesdk) | [pasta 13QcTTrpqsVd6U_EFMxBH2oe4AyiWit0T] | 2026-09-30T01:59:54.000Z | text/markdown |
| [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1OpuDzJ5Niqq92D4Gh8PV2nGq6EHPuxGT/view?usp=drivesdk) | [pasta 1AoKm3VNgMzcnTQOL4NPrTXvAbOfKZnwH] | 2026-09-30T01:59:54.000Z | text/markdown |
| [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1fYW2FtYRCihpdvMTyt915AunLH5PSmrC/view?usp=drivesdk) | [pasta 1WKggnjrXbzHCkwcy5dbIz49PSha4ithd] | 2026-09-30T01:59:54.000Z | text/markdown |
| [C5A_rede_gmf_guia.md](https://drive.google.com/file/d/1G6ZXk1skicX04CoygLoppKgi5AMC-Zt1/view?usp=drivesdk) | [pasta 19OMx83t7OTKjK33dUrZM53B9Z0YdWtc5] | 2026-09-29T02:39:12.000Z | text/markdown |
| [C5A_rede_gmf_guia.md](https://drive.google.com/file/d/1ZZfgz5BrOzdku6aVpEKPLmx7YS1ExbWm/view?usp=drivesdk) | [pasta 1HKyxmySZJk7pXlRJveCTrqpZDw-4mrRf] | 2026-09-29T01:27:12.000Z | text/markdown |
| [C5A_B19_acoplamento_causal_relatorio_2026-10-03_0610-clau.md](https://drive.google.com/file/d/1E7sSoT9g-2kCpz9E2-vBv5sKgEP6k6I6/view?usp=drivesdk) | [pasta 1JFRU_eORHTu0rk6Plt6ocshKPHQ13t6q] | 2026-10-03T09:10:28.000Z | text/markdown |
| [C5A_B13_B15_B17_relatorio_2026-10-03_0021-clau.md](https://drive.google.com/file/d/1AUXfx_PuxuwtDbFdIdg54aMa9asggSNl/view?usp=drivesdk) | [pasta 130REh3e6DX-PsI1mEkFV-aYqW-jX4ZT1] | 2026-10-03T03:21:44.000Z | text/markdown |
| [C5A_Colab_B13_B15_B17_PT_2026-10-02_2229-clau.md](https://drive.google.com/file/d/1UmwJYgCxVnRZ3azGitGxP31JTiY7fWno/view?usp=drivesdk) | [pasta 130REh3e6DX-PsI1mEkFV-aYqW-jX4ZT1] | 2026-10-03T03:21:44.000Z | text/markdown |
| [C5A_B2_conexao_compacta_relatorio_2026-10-02_0545-clau.md](https://drive.google.com/file/d/1ACmVuXvhH4KqivXurFy_fADsuKeypVDw/view?usp=drivesdk) | [pasta 10qmucMeoaH-70EEQke1M9bpPj0nWYD2g] | 2026-10-02T17:02:27.664Z | text/markdown |
| [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_v1_3_PT_2026-10-01_2340-clau.md](https://drive.google.com/file/d/13r0BQG8jAoOtF73aoU7ODphg8Dyd0GdB/view?usp=drivesdk) | [pasta 1uIYvjY3f1ne74T8Z-xQOGXlVw9Yh4vEQ] | 2026-10-02T02:25:04.000Z | text/markdown |
| [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_v1_2_PT_2026-10-01_2330-clau.md](https://drive.google.com/file/d/1930Cx9g_UVf2m_Os4tDTnbYuGAfta9NL/view?usp=drivesdk) | [pasta 1vVbdKSpKaNmuXXNkuC7UYJ2t3wlAaK0h] | 2026-10-02T02:19:08.000Z | text/markdown |
| [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_v1_1_PT_2026-10-01_2320-clau.md](https://drive.google.com/file/d/1R7FOkljnps0zuv3NW-6Mn37CN1VMp2Il/view?usp=drivesdk) | [pasta 1cskwVVIUsrv-0v-OHiPu2mRAjrGmz2wt] | 2026-10-02T02:14:06.000Z | text/markdown |
| [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_v1_1_PT_2026-10-01_2320-clau.md](https://drive.google.com/file/d/1GdYdW8AtEX0lkWgFIxlPOfqrHUgVApZs/view?usp=drivesdk) | [pasta 1Ak_2bOmsOuc0XU3T_hUl4xV6vz1WZSfc] | 2026-10-02T02:14:06.000Z | text/markdown |
| [C5A_Atualizacao_05_FR3D_Spin_1_2_PT.md](https://drive.google.com/file/d/1Bk8XzAlph5jre4NGt2B-LuB6xPKcf0K3/view?usp=drivesdk) | [pasta 1zcOs4MxH-ETue9gTvWrVETd6LmJojKl2] | 2026-09-30T17:59:22.000Z | text/markdown |
| [C5A_prompt_B2_conexao_compacta_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1qFP4_3x7YhRSSvMVaC-dBqna1cIzgSI0/view?usp=drivesdk) | [pasta 10qmucMeoaH-70EEQke1M9bpPj0nWYD2g] | 2026-10-02T17:02:27.704Z | text/markdown |
| [C5A_B2_PREREGISTRO_2026-10-02_0530-clau.md](https://drive.google.com/file/d/1AENm0kYUPipKiYVGcFc5K145ped3ShFR/view?usp=drivesdk) | [pasta 10qmucMeoaH-70EEQke1M9bpPj0nWYD2g] | 2026-10-02T17:02:27.723Z | text/markdown |
| [C5A_B8_Lorentz_UV_isotropia_relatorio_2026-10-02_1200-clau.md](https://drive.google.com/file/d/1EwH63mXDq9XB4zxNjvwUNTtnmht88T8d/view?usp=drivesdk) | [pasta 1eayJSKy3EIdw0ZwV6VO4AUihKvOeP1gt] | 2026-10-02T14:56:38.000Z | text/markdown |
| [C5A_B7_PREREGISTRO_2026-10-02_0608-clau.md](https://drive.google.com/file/d/1JusTzbMkxjTljhBHOzx7OcnaRgP2S-NB/view?usp=drivesdk) | [pasta 1pELY67W2l7aCisssZ4A1Z6dfXMs50fEs] | 2026-10-02T09:34:48.000Z | text/markdown |
| [C5A_prompt_B7_massa_virtual_HDL_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1EKC5ieJmoZ462EeKyLWlRLD9ChUYF52y/view?usp=drivesdk) | [pasta 1pELY67W2l7aCisssZ4A1Z6dfXMs50fEs] | 2026-10-02T09:34:48.000Z | text/markdown |
| [C5A_prompt_B2_conexao_compacta_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1xDP-1uAm3E7siZjmHTLWUhpjzTV742v9/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_prompts_B1_B2_B7_2026-10-01_2340-clau | 2026-10-02T02:35:35.970Z | text/markdown |
| [C5A_prompt_B7_massa_virtual_HDL_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1wKunXEtbs0jiPlgwop8m-jiTvfA4X8Wc/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_prompts_B1_B2_B7_2026-10-01_2340-clau | 2026-10-02T02:35:35.979Z | text/markdown |
| [Master_Research_Notebook_C5A_v1_2_adendo_PT_2026-10-01_2310-clau.md](https://drive.google.com/file/d/11OaNdq87vZpeHk6JtZzfYw6g2OVGvLyS/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_photon_closure_replicacao_2026-10-01_2305-clau | 2026-10-02T02:06:38.000Z | text/markdown |
| [C5A_photon_closure_replicacao_relatorio_2026-10-01_2305-clau.md](https://drive.google.com/file/d/16aEUypPlSrJWADv5_MZXewjfQaoKvvzd/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_photon_closure_replicacao_2026-10-01_2305-clau | 2026-10-02T02:06:02.000Z | text/markdown |
| [C5A_Prompt_G0G_Fundo_Basal_Foton_Backreaction_PT.md](https://drive.google.com/file/d/158er4buQn6O5UNHinaLT7hCt5QL2j00X/view?usp=drivesdk) | [pasta 1XWCdysO9s5zzMgEvvYiXTzQ66YuqMTyZ] | 2026-10-01T21:34:10.000Z | text/markdown |
| [C5A_Atualizacao_04_Spin_1_2_3D_Estado_PT.md](https://drive.google.com/file/d/1IrfjQNMevn99cZtWsuLy2EoElFk1izgY/view?usp=drivesdk) | [pasta 1MCetKYEKtfz5B7p6awjw_ewTxQ3aKWh0] | 2026-09-30T17:30:40.000Z | text/markdown |
| [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1bf2bbMQVygL8JEgyg1BxMcMXTXuVInPN/view?usp=drivesdk) | [pasta 18G2XkZW1uXPf_FA17OBDOPfscPzW03UX] | 2026-09-30T02:04:16.000Z | text/markdown |
| [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1xifTtgjowAnEWN7q9bn8w4Ut-vtGE8MZ/view?usp=drivesdk) | [pasta 11X_ep_4NB0NofJyeYO1SKr_fTxFh4qQs] | 2026-09-30T02:04:16.000Z | text/markdown |
| [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1Br10fJuYY6gyEe69UZ4cWWtTFAiDa1dE/view?usp=drivesdk) | [pasta 1FMMNcWsO_W2JyKM7MKGR90HzLgxviide] | 2026-09-30T02:04:16.000Z | text/markdown |
| [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1zwyzW7o7YWdmqTTu6lHk5yAxZ6nS2B55/view?usp=drivesdk) | [pasta 13QcTTrpqsVd6U_EFMxBH2oe4AyiWit0T] | 2026-09-30T02:04:16.000Z | text/markdown |
| [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1mEZWGpoAf42AXwkrF33wZa7hjFoaKHgF/view?usp=drivesdk) | [pasta 1AoKm3VNgMzcnTQOL4NPrTXvAbOfKZnwH] | 2026-09-30T02:04:16.000Z | text/markdown |
| [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/134e4H7A1QMHN-FJmRjlJhy617rlumCWJ/view?usp=drivesdk) | [pasta 1WKggnjrXbzHCkwcy5dbIz49PSha4ithd] | 2026-09-30T02:04:16.000Z | text/markdown |
| [C5A_B13_B15_B17](https://drive.google.com/drive/folders/130REh3e6DX-PsI1mEkFV-aYqW-jX4ZT1) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B13_B15_B17_2026-10-03_0021-clau | 2026-10-05T22:22:01.741Z | Pasta localizada |
| [C5A_B3_birrefringencia_acumulada](https://drive.google.com/drive/folders/1sMO7Eavcza8TUqDldVDrr1pXlxzvn0rs) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B3_birrefringencia_acumulada_2026-10-02_1558-clau | 2026-10-05T22:22:01.749Z | Pasta localizada |
| [C5A_B19](https://drive.google.com/drive/folders/1JFRU_eORHTu0rk6Plt6ocshKPHQ13t6q) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B19_acoplamento_causal_2026-10-03_0610-clau | 2026-10-05T22:22:01.740Z | Pasta localizada |
| [C5A_B1_photon_closure_v2](https://drive.google.com/drive/folders/1ThX_KzJIK1MgTCPGBu82mN9xvGlYXsDG) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B1_photon_closure_v2_2026-10-02_0530-clau | 2026-10-05T22:22:01.743Z | Pasta localizada |
| [C5A_B1_photon_closure_v2](https://drive.google.com/drive/folders/16x416gUolLY6Vxxprqy0mFzD34phxrOi) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B1_photon_closure_v2_2026-10-02_0530-clau_1 | 2026-10-05T22:22:01.746Z | Pasta localizada |
| [C5A_B8_Lorentz_UV_isotropia](https://drive.google.com/drive/folders/1eayJSKy3EIdw0ZwV6VO4AUihKvOeP1gt) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_B8_Lorentz_UV_isotropia_2026-10-02_1200-clau | 2026-10-05T22:22:01.723Z | Pasta localizada |
| [C5A_ELETRON_36_elasticidade_microgeometria](https://drive.google.com/drive/folders/1dNRRNtcgo-Fo-SW5cYTaO9u0arsCjF7c) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_ELETRON_36_elasticidade_microgeometria_2026-10-03 | 2026-10-05T22:22:00.743Z | Pasta localizada |
| [C5A_ELETRON_34_contabilidade_massa_energia](https://drive.google.com/drive/folders/1LBsCn7OwdGZAdvilbobwtbFBEjROilF3) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_ELETRON_34_contabilidade_massa_energia_2026-10-03 | 2026-10-05T22:22:00.749Z | Pasta localizada |
| [C5A_ELETRON_38_estado_orbital_autoinduzido](https://drive.google.com/drive/folders/1qXzbMQ90JjF-gdTFpOvna43vyShbjzd6) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_ELETRON_38_estado_orbital_autoinduzido_2026-10-03 | 2026-10-05T22:22:00.726Z | Pasta localizada |
| [relatorio.md](https://drive.google.com/file/d/1OLI1Z8hMt5rcNHSxEgbvHbyn_2gR1fwb/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/c5a_photon_closure | 2026-10-02T02:41:36.000Z | text/markdown |
| [verificar.py](https://drive.google.com/file/d/1OsA2PNxFI0Fnm9Spv8QRfnlIVCQ97mUJ/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/c5a_photon_closure | 2026-09-29T01:20:56.000Z | text/x-python |
| [C5A_photon_closure_replicacao_PREREGISTRO_2026-10-01_2210-clau.md](https://drive.google.com/file/d/1yKL43zxqlcQlOoWNlZfdRmnB-WpNDycn/view?usp=drivesdk) | Holographic-Reconstruction-Framework-HRF/05-Data-and-Analysis/Testes-C5/C5A_photon_closure_replicacao_2026-10-01_2305-clau | 2026-10-02T00:54:58.000Z | text/markdown |

## 9. Duplicações candidatas

Mesmo nome não prova igualdade; nenhuma cópia histórica é declarada descartável sem comparação de conteúdo/hash. Markdown/DOCX/PDF podem ser representações complementares.

| Nome | Ocorrências / links | Verificação |
|---|---|---|
| HRF_Esqueleto_Research_Book_v0_2_PT_2026-10-06.md | [HRF_Esqueleto_Research_Book_v0_2_PT_2026-10-06.md](https://drive.google.com/file/d/1d-6ve7xYYnbdQkUovpxEYN0csU_Ig0dm/view?usp=drivesdk) · [HRF_Esqueleto_Research_Book_v0_2_PT_2026-10-06.md](https://drive.google.com/file/d/12BYLRUCX7HUEW8HO3RLqc7qa2OjEl1Ce/view?usp=drivesdk) | Texto idêntico confirmado |
| Master_Research_Notebook_C5A_v1_1_PT_2026-10-01_1816-clau.md | [Master_Research_Notebook_C5A_v1_1_PT_2026-10-01_1816-clau.md](https://drive.google.com/file/d/1J_0upqihHazEWkCLXzWT9Hl0Ca3GGkyf/view?usp=drivesdk) · [Master_Research_Notebook_C5A_v1_1_PT_2026-10-01_1816-clau.md](https://drive.google.com/file/d/18HcBwHvwQ488b644m2_ZaWLrRLfLZnj4/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| Research_Notebook_C5A_Consolidacao_Microgeometria_Massa_v0_6_PT.md | [Research_Notebook_C5A_Consolidacao_Microgeometria_Massa_v0_6_PT.md](https://drive.google.com/file/d/1pXT9xWRI4cM486QjnG4_K5XTxg9MqqFq/view?usp=drivesdk) · [Research_Notebook_C5A_Consolidacao_Microgeometria_Massa_v0_6_PT.md](https://drive.google.com/file/d/14xZRYgM6_KHJv4uqM24J2LeOOHvf2aVz/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_Colab_B13_B15_B17_PT_2026-10-02_2229-clau.md | [C5A_Colab_B13_B15_B17_PT_2026-10-02_2229-clau.md](https://drive.google.com/file/d/1OXAfcpT2lJVWXif7Jjvjsc-YtZz-hNLa/view?usp=drivesdk) · [C5A_Colab_B13_B15_B17_PT_2026-10-02_2229-clau.md](https://drive.google.com/file/d/1UmwJYgCxVnRZ3azGitGxP31JTiY7fWno/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_prompt_B3_birrefringencia_acumulada_2026-10-02_1150-clau.md | [C5A_prompt_B3_birrefringencia_acumulada_2026-10-02_1150-clau.md](https://drive.google.com/file/d/18k8-zL1_HckIcyJUihHgQhgQhCj2Ug6M/view?usp=drivesdk) · [C5A_prompt_B3_birrefringencia_acumulada_2026-10-02_1150-clau.md](https://drive.google.com/file/d/1BqYDxlwy2l8d-zFxqdzyj46jIu78Q9fw/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_testes_foton_guia.md | [C5A_testes_foton_guia.md](https://drive.google.com/file/d/1Z6hIupLCFio1oqhknO6kuZZDUNJ8sWD5/view?usp=drivesdk) · [C5A_testes_foton_guia.md](https://drive.google.com/file/d/1wXeIJXgawwoR7kB8gaYAxOhgAd_5kL6E/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_Atualizacao_05_FR3D_Spin_1_2_PT.md | [C5A_Atualizacao_05_FR3D_Spin_1_2_PT.md](https://drive.google.com/file/d/1vgXO2C19lwgAlChf7S3CRBM7gMwa59D4/view?usp=drivesdk) · [C5A_Atualizacao_05_FR3D_Spin_1_2_PT.md](https://drive.google.com/file/d/1Bk8XzAlph5jre4NGt2B-LuB6xPKcf0K3/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_Atualizacao_04_Spin_1_2_3D_Estado_PT.md | [C5A_Atualizacao_04_Spin_1_2_3D_Estado_PT.md](https://drive.google.com/file/d/1OTu27SE0vWdcpiPY0g01EgNW-OxcrnIO/view?usp=drivesdk) · [C5A_Atualizacao_04_Spin_1_2_3D_Estado_PT.md](https://drive.google.com/file/d/1IrfjQNMevn99cZtWsuLy2EoElFk1izgY/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_holonomia_loops_guia.md | [C5A_holonomia_loops_guia.md](https://drive.google.com/file/d/1-vfYGmgVYapkfE14X1m-oXFySWiP1wed/view?usp=drivesdk) · [C5A_holonomia_loops_guia.md](https://drive.google.com/file/d/1KJXxhcwhbHolSv9oglo3c1ODxvb2Vrys/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_prompt_B1_photon_closure_v2_2026-10-01_2340-clau.md | [C5A_prompt_B1_photon_closure_v2_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1qn8YaBQStKeW_PSqLRm1azvIgV88sxl4/view?usp=drivesdk) · [C5A_prompt_B1_photon_closure_v2_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1ecHtU4vX8MJLYYBCX8gQzWoQyogKeDJY/view?usp=drivesdk) · [C5A_prompt_B1_photon_closure_v2_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1GmDGM5hKjsqxpTlN8DMK-zuRyrHky0KS/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_prompt_holonomia_loops.md | [C5A_prompt_holonomia_loops.md](https://drive.google.com/file/d/1nbPDIRhjoVsDcuJCJ7dj4P6IZyFCQ4w5/view?usp=drivesdk) · [C5A_prompt_holonomia_loops.md](https://drive.google.com/file/d/1me7NaQJIyTLMNnb69DtA_mgnJJuxHmNf/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_B1_PREREGISTRO_2026-10-01_2350-clau.md | [C5A_B1_PREREGISTRO_2026-10-01_2350-clau.md](https://drive.google.com/file/d/1GETRGRI21L5au6jUEhiAu5hwUiMJC5nJ/view?usp=drivesdk) · [C5A_B1_PREREGISTRO_2026-10-01_2350-clau.md](https://drive.google.com/file/d/15gLkvGbYR6wJBFEgl-D2OJ2TVIqqdIT2/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_B1_photon_closure_v2_relatorio_2026-10-02_0530-clau.md | [C5A_B1_photon_closure_v2_relatorio_2026-10-02_0530-clau.md](https://drive.google.com/file/d/1FvxIyXbZa5UtBsnj9HA7YPAbHuaVLsBp/view?usp=drivesdk) · [C5A_B1_photon_closure_v2_relatorio_2026-10-02_0530-clau.md](https://drive.google.com/file/d/1jITfS3V46wVTWl7TmlnaYWen6XBXb2z6/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md | [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1Fh-PV-HL_kVZ97YjBI2WPVekBjfTN1DU/view?usp=drivesdk) · [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1jkQUhRTKNnLwJtt3-7HNCwfya1k9IMKy/view?usp=drivesdk) · [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1rfaT02nGHMV11C5dSPCJRmmzP0TAL4V9/view?usp=drivesdk) · [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1nEp-hDNI9Q1ual5c_ddtbYFlWURrAkDV/view?usp=drivesdk) · [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1OpuDzJ5Niqq92D4Gh8PV2nGq6EHPuxGT/view?usp=drivesdk) · [C5A_prompt_G0B_G2B_frame_dragging_microgeodesicas.md](https://drive.google.com/file/d/1fYW2FtYRCihpdvMTyt915AunLH5PSmrC/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_rede_gmf_guia.md | [C5A_rede_gmf_guia.md](https://drive.google.com/file/d/1G6ZXk1skicX04CoygLoppKgi5AMC-Zt1/view?usp=drivesdk) · [C5A_rede_gmf_guia.md](https://drive.google.com/file/d/1ZZfgz5BrOzdku6aVpEKPLmx7YS1ExbWm/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_v1_1_PT_2026-10-01_2320-clau.md | [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_v1_1_PT_2026-10-01_2320-clau.md](https://drive.google.com/file/d/1R7FOkljnps0zuv3NW-6Mn37CN1VMp2Il/view?usp=drivesdk) · [C5A_Guia_Inicio_Chat_Definicoes_e_Esqueleto_Atual_v1_1_PT_2026-10-01_2320-clau.md](https://drive.google.com/file/d/1GdYdW8AtEX0lkWgFIxlPOfqrHUgVApZs/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_prompt_B2_conexao_compacta_2026-10-01_2340-clau.md | [C5A_prompt_B2_conexao_compacta_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1qFP4_3x7YhRSSvMVaC-dBqna1cIzgSI0/view?usp=drivesdk) · [C5A_prompt_B2_conexao_compacta_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1xDP-1uAm3E7siZjmHTLWUhpjzTV742v9/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_prompt_B7_massa_virtual_HDL_2026-10-01_2340-clau.md | [C5A_prompt_B7_massa_virtual_HDL_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1EKC5ieJmoZ462EeKyLWlRLD9ChUYF52y/view?usp=drivesdk) · [C5A_prompt_B7_massa_virtual_HDL_2026-10-01_2340-clau.md](https://drive.google.com/file/d/1wKunXEtbs0jiPlgwop8m-jiTvfA4X8Wc/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| C5A_G0B_G2B_frame_dragging_relatorio.md | [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1bf2bbMQVygL8JEgyg1BxMcMXTXuVInPN/view?usp=drivesdk) · [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1xifTtgjowAnEWN7q9bn8w4Ut-vtGE8MZ/view?usp=drivesdk) · [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1Br10fJuYY6gyEe69UZ4cWWtTFAiDa1dE/view?usp=drivesdk) · [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1zwyzW7o7YWdmqTTu6lHk5yAxZ6nS2B55/view?usp=drivesdk) · [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/1mEZWGpoAf42AXwkrF33wZa7hjFoaKHgF/view?usp=drivesdk) · [C5A_G0B_G2B_frame_dragging_relatorio.md](https://drive.google.com/file/d/134e4H7A1QMHN-FJmRjlJhy617rlumCWJ/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| RESUMO.json | [RESUMO.json](https://drive.google.com/file/d/1I3Vi2O8o_55Jk-mWl7oi-5aIvOeYgOgh/view?usp=drivesdk) · [RESUMO.json](https://drive.google.com/file/d/1mLmY3sH3PD8nXCv5he_yphVNm0ARXxqH/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| congelamento.json | [congelamento.json](https://drive.google.com/file/d/1LZ8oAHH-pc2GyS0_1wilFVZDAqAT43CY/view?usp=drivesdk) · [congelamento.json](https://drive.google.com/file/d/1DUWQzKy1wc8PfEwje_a1X0RqFN2mDRd_/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |
| protocolo.txt | [protocolo.txt](https://drive.google.com/file/d/1tKjSMUDDhHPALmTYLEOv8URjbIEaCb1E/view?usp=drivesdk) · [protocolo.txt](https://drive.google.com/file/d/1Qqpknn_tJMRJJWt2RrVXd_F7S9PyGwy1/view?usp=drivesdk) | Mesmo nome; equivalência não verificada |

Há também nomes com “(1)”, pastas B1 com sufixo _1 e seis pastas frame-dragging. São candidatos a duplicação; não inferir igualdade de código, sementes ou resultados.

## 10. Referidos mas não localizados / cobertura pendente

- HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_1_PT_2026-10-05.md.
- C5A_Livro_Cap02_Onda_Fotonica_Livre_v1_0_PT_2026-10-02_2111-clau.md.
- HRF_Research_Book_Cap01_Esqueleto_v0_1_PT_2026-10-05.md.
- Notebook mestre dedicado C5B; documento próprio HRF-ST de distância/dimensão.
- C5B_QO_Formulas_Imagem_Funil_Terra_v0_1_PT_TUI.docx; C5B_QO_Criterios_Geometricos_Regiao_Repulsiva_v0_1_PT_TUI.docx; QW01/QW02/QW03/Earth Constraint Battery: citados na auditoria, não localizados nas buscas feitas.
- Relatórios ELETRON 14/16/24/26/28/30/32_v2/40: citados pelo programa do elétron; não localizados por nome no conjunto inventariado. 20 e 22 localizados. Pastas 34/36/38 localizadas, mas relatórios internos ainda precisam ser resolvidos.
- “RHF — O que é um sistema físico na Mecânica Quântica Relacional? v1.1” e “Research Notebook — Mathematical Foundations of the PRFE Framework v0.1”: referências internas do Cap. 1; não resolvidas nesta auditoria.
- Subpastas C5-CLAUDE, PRFE e pacotes com pasta interna não foram percorridos integralmente. Relatórios encontrados em busca global podem ter pai ainda indicado por ID.

## 11. Tarefas editoriais e científicas

| Prioridade | Tarefa | Estado |
|---|---|---|
| P0 | Criar HRF_Master_Index.md | Concluído nesta versão; inventário verificável com lacunas explícitas |
| P0 | Recuperar Cap. 2 v1.1 e conferir fechamento versus adendo §142 e bancadas posteriores | Pendente; bloqueia conciliação técnica |
| P0 | Adotar Cap. 1 v0.2 como referência corrente | Registrado no índice; não implica revisão dos outros arquivos |
| P0 | Atualizar terminologia PGFE no Cap. 2 sem alterar resultados C5A | Pendente |
| P1 | Completar inventário C5B/QW e relatórios ELETRON citados | Parcial; auditoria e pastas históricas localizadas |
| P1 | Comparar hashes/código/resultados de duplicatas candidatas; escolher referências canônicas | Pendente; não excluir nem mover automaticamente |
| P1 | Mapear cada notebook/relatório para capítulos 3–10 com protocolo, versão, sementes, entradas, saídas e veredito | Mapa temático inicial nesta versão; validação arquivo a arquivo pendente |
| P1 | Formalizar reconstruction-minimal support; exemplos calculáveis em códigos/redes tensoriais; relatividade de R_min à álgebra-alvo | Pesquisa aberta |
| P1 | Criar documento HRF-ST de distância/dimensão | Pendente; não localizado |
| P1 | Construir ponte S_R ↔ graus efetivos HRF-FM | Pesquisa aberta |
| P1 | Definir critérios de falsificação fundacional | Pendente |
| P2 | Consolidar v1.1 + adendo como versão integral, preservando originais e resultados negativos | Proposta editorial; não executada |

## 12. Método e manutenção

Fontes: leituras atuais do Drive; buscas HRF, C5A, C5B, Cap02, Onda_Fotonica, QW, C5B_QO; filtros de nome; listagem da raiz HRF, dez pastas estruturais, Inbox/Physics, Teoria-C5/C5A, Testes-C5 e subpastas selecionadas. Buscas podem retornar correspondências de conteúdo, não apenas de título; itens irrelevantes foram excluídos. Listagem de pasta retorna no máximo 100 filhos; Testes-C5 atingiu 100 e pode ser parcial. Resultados não paginados não certificam completude do Drive.

Atualização futura: registrar data, ID, caminho, versão interna, fonte de substituição e nível de inspeção; completar lacunas antes de declarar todos os notebooks mapeados. Não apagar resultados negativos, não converter hipótese em fato e não fundir arquiteturas distintas sem demonstração.

**Registro v0.1:** primeiro índice gerado a partir do Drive; preserva nomes C5A/C5B e registra duplicação textual do esqueleto, adendo C5A v1.2 e ausência de resolução do Capítulo 2.


