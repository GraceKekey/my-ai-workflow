# HRF-FM — Regras da onda fotônica em bancada 2D3V

**Documento:** `CAP3-2D3V-PHOTON-01` · **Versão:** v0.1 · **Data:** 2026-10-08  
**Status:** especificação para teste [D/H], **não executada**.  
**Referência principal:** *HRF Research Book*, Capítulo 2 — *A onda fotônica livre*, v1.1, e protocolo `CAP3-2D-FLUX-01`.

## 1. Escopo e limite da equivalência [D]

Utilizar **duas coordenadas espaciais** `(x,y)`, mas **três componentes vetoriais** dos campos: `E=(Ex,Ey,Ez)` e `B=(Bx,By,Bz)`, com `∂z=0` (**2D3V**). Isto permite representar, para ondas com vetor de propagação no plano, as **duas polarizações transversais** e sua combinação circular. A *pequena hélice* é a rotação local da polarização; **não é** a trajetória do envelope ou uma órbita.

**Importante:** Maxwell 2D3V é um **modelo intermediário de referência**, não uma derivação automática do substrato discreto do Capítulo 2. A equivalência ao modo fotônico HRF requer testes próprios; duas ondas escalares em quadratura, isoladamente, **não** satisfazem o contrato fotônico.

## 2. Estrutura física a preservar [F/M/H]

1. **Origem do setor fotônico no Capítulo 2:** fases de ligação `U_nm = exp(i a_nm)`, laços orientados, energia de Wilson e operador discreto `d₁ᵀ M₂ d₁` (limite `curl-curl`). Não trocar silenciosamente essa origem por um laplaciano vetorial genérico. [M/H]
2. **Modos físicos:** exatamente **duas polarizações transversais**; nenhum modo longitudinal físico propagante. O setor longitudinal deve ser restrição/gauge, não uma terceira onda. [F/M]
3. **Propagação livre:** `ω ≈ c|k|` e `P/E ≈ 1/c` no regime apropriado; helicidades `h=±1`, degeneradas no fundo livre, com sentido definido em relação a **k**. [F/M]
4. **Polarização circular:** para propagação local no plano, combinar as duas direções transversais (uma no plano, perpendicular a **k**, e outra ao longo de **z**) em quadratura; não identificar automaticamente o sinal de uma quadratura com helicidade física. [F/D]
5. **Spin ≠ OAM:** helicidade local não exige rotação circular do centro de energia. [F/D]
6. **Quantização:** `ℏ`, `E=ℏω` e estrutura de Fock pertencem ao fechamento quântico do Capítulo 2; um campo clássico 2D3V não demonstra um fóton individual. [F/?]

## 3. Equações e perfil da cavidade [D/H]

Como bancada eletromagnética intermediária, usar uma evolução vetorial que preserve, na ausência de fontes,

```text
∂t B = −curl E
∂t D =  curl H
D = ε(x,y) E ; B = μ(x,y) H
∇·D = 0 ; ∇·B = 0
```

O perfil herdado de velocidade `c_local(r)` **não** determina sozinho `ε(r)` e `μ(r)`. Como **hipótese de controle** [H], testar impedância uniforme (`ε_r=μ_r=1/c_local`, em unidades com `c_vácuo=1`), além de alternativas justificadas. Isso **não equivale ainda** à conexão de Wilson do Capítulo 2. Verificar se gauge/restrições, helicidade e energia resistem à inhomogeneidade.

## 4. PHOTON-INJECTION GATE — obrigatório [D]

**Antes de cada injeção**, rodar um controle livre e registrar, com critérios e tolerâncias pré-fixados:

- transversalidade / restrições de Gauss e ausência de longitudinal propagante;
- helicidades `±1` e polarização circular, avaliadas em relação a **k**;
- dispersão `ω(k)` e razão `P/E` no regime testado;
- direção e velocidade de propagação do envelope;
- balanço de energia, estabilidade temporal e convergência espacial;
- identidade do código, parâmetros, versões e arquivos (proveniência).

Se o gate **não passar**, marcar `PHOTON-INJECTION GATE: FAIL/NOT_TESTED`; a execução poderá ser descrita como **teste vetorial exploratório**, nunca como *fóton confinado*.

## 5. Diagnósticos na cavidade [D]

Partir de `R/λ=4`, variando depois `2,3,5,6`; registrar `T=30,150,300,500 λ/c` e os ângulos previstos no protocolo. Não impor órbitas.

Medir **densidade** `u=½(E·D+B·H)` e **fluxo** `J_E=E×H`; integrar o fluxo normal pela parede `r=R`. Reportar separadamente:

- `F_in=E_dentro(t)/E_caixa(t)` e `F_rem=E_dentro(t)/E_caixa(0)`;
- energia absorvida pelo *sponge*, perdas numéricas e resíduo do balanço energético;
- fluxos radial/tangencial, médias temporais, reversões, retornos e circulação parcial;
- identidade fotônica **local** durante a evolução, quando os observáveis do modo estiverem definidos;
- controles livre, passo temporal, resolução espacial, tamanho da caixa e absorvedor.

## 6. Regra de classificação e resultados negativos [D]

Distinguir **onda viajante confinada**, **ricochete/refração**, **sloshing**, **circulação parcial** e **quase-estacionário** a partir de fluxo e energia, **não** apenas do máximo de densidade. Preservar fuga, amortecimento progressivo, padrões estacionários, falhas do gate e dependência de borda/refinamento como resultados negativos válidos.

**Proibição terminológica:** sem gate aprovado e identidade fotônica local demonstrada, escrever **“campo vetorial 2D3V”** ou **“estado coletivo do campo”**, não “fóton preso”. Mesmo um modo fotônico confinado não demonstra, por si só, um elétron.

---

**Referências internas:** `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_1_PT_2026-10-05`; `HRF_CAP3_2D_FLUX_01_Protocolo_Confinamento_Dinamico_v0_1_PT_2026-10-08`.

