"""Preregistered short cavity and control batch. No long runs on failure."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import json, subprocess, sys, os, time
import numpy as np
from hrf_maxwell_2d3v import ROOT, PREREG, write_json, sha, now

free=json.loads((ROOT/'FREE_GATE_RESULTS.json').read_text())
if free['Maxwell_2D3V_GATE']!='PASS':
    write_json(ROOT/'CAVITY_GATE_RESULTS.json',dict(status='NOT_EXECUTED',reason='Maxwell free gate failed',long_runs='NOT_EXECUTED'))
    sys.exit(0)
RESULTS=ROOT/'results'; LOGS=ROOT/'logs'; LOGS.mkdir(exist_ok=True)
jobs=[]
def add(label, **p):
    base=dict(angle=75,helicity=1,ppw=20,dt=.018,medium='cavity',box=16,sponge_start=6.5,sponge_eta=PREREG['base']['sponge_eta_max'])
    base.update(p);jobs.append(dict(label=label,parameters=base))
for a in (45,60,75,90):
    for h in (1,-1):add(f'cavity_a{a}_h{h:+d}_base',angle=a,helicity=h,plots=True)
for h in (1,-1):
    for ppw in (24,32):add(f'cavity_a75_h{h:+d}_ppw{ppw}',helicity=h,ppw=ppw,dt=.009)
    add(f'cavity_a75_h{h:+d}_dt_half',helicity=h,dt=.009)
    add(f'cavity_a75_h{h:+d}_box20',helicity=h,box=20,sponge_start=7.5)
for scale in (.5,2):add(f'cavity_a75_h+1_eta{scale}',sponge_eta=PREREG['base']['sponge_eta_max']*scale)
for medium,speed in [('vacuum',1),('uniform_slow',.39)]:
    for a in (45,60,75,90):
        for h in (1,-1):add(f'{medium}_a{a}_h{h:+d}',angle=a,helicity=h,medium='uniform',speed=speed)

write_json(ROOT/'CAVITY_PREREGISTRATION.json',dict(time=now(),config_sha256=sha(ROOT/'config_preregistered.json'),criteria=PREREG['short_cavity_acceptance'],jobs=jobs))
def run(job):
    label=job['label'];p=job['parameters'];output=RESULTS/label
    cmd=[sys.executable,'-u',str(ROOT/'hrf_maxwell_2d3v.py'),'--output',str(output),'--tmax','30']
    for key,value in p.items():
        if key=='plots':
            if value:cmd.append('--plots')
        else:cmd.extend(['--'+key.replace('_','-'),str(value)])
    env=os.environ.copy();env.update(MPLCONFIGDIR='/tmp/hrf-matplotlib',XDG_CACHE_HOME='/tmp/hrf-cache',OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1')
    start=now();wall=time.monotonic();print('START '+label,flush=True)
    with (LOGS/(label+'.log')).open('w') as log:
        result=subprocess.run(cmd,env=env,cwd=ROOT,stdout=log,stderr=subprocess.STDOUT)
    record=dict(name=label,parameters=p,command=cmd,exit_code=result.returncode,started=start,finished=now(),wall_seconds=time.monotonic()-wall)
    write_json(LOGS/(label+'.execution.json'),record)
    print(f'DONE {label}: exit={result.returncode}',flush=True);return record
with ThreadPoolExecutor(max_workers=3) as pool:
    records=[f.result() for f in as_completed([pool.submit(run,j) for j in jobs])]
write_json(ROOT/'cavity_execution.json',records)
limits=PREREG['short_cavity_acceptance'];failures=[];summaries={};case_checks=[]
for r in records:
    if r['exit_code']:
        failures.append(r['name']+': execution failure');continue
    s=json.loads((RESULTS/r['name']/'summary.json').read_text());summaries[r['name']]=s
    tests=dict(Gauss=s['max_gauss_relative']<=limits['max_gauss_relative'],
               global_balance=s['max_global_balance_error']<=limits['max_energy_balance_residual_fraction'],
               interior_balance=s['max_inside_balance_error']<=limits['max_interior_balance_residual_fraction'],
               finite_stable=s['numerically_finite'])
    case_checks.append(dict(case=r['name'],checks=tests,status='PASS' if all(tests.values()) else 'FAIL',
                           max_global_balance_error=s['max_global_balance_error'],max_inside_balance_error=s['max_inside_balance_error'],max_gauss_relative=s['max_gauss_relative']))
    failures.extend(r['name']+': '+k for k,v in tests.items() if not v)
def late_transport(label):
    a=np.genfromtxt(RESULTS/label/'timeline.csv',delimiter=',',names=True)
    return float(np.mean(a['mean_speed_flux'][a['t']>=10]))
control_checks=[]
def check(kind,names,limit,metric='F_rem',relative=False):
    if not all(k in summaries for k in names):
        failures.append(kind+': missing control');return
    values=[late_transport(k) if metric=='mean_speed_flux' else summaries[k]['final'][metric] for k in names]
    diff=max(values)-min(values)
    value=diff/max(abs(values[0]),1e-30) if relative else diff
    passed=value<=limit
    control_checks.append(dict(control=kind,cases=names,metric=metric,values=values,difference=value,limit=limit,status='PASS' if passed else 'FAIL'))
    if not passed:failures.append(f'{kind}: {metric} difference {value:.6g} exceeds {limit}')
for h in (1,-1):
    base=f'cavity_a75_h{h:+d}_base'; half=f'cavity_a75_h{h:+d}_dt_half'
    spatial=[half]+[f'cavity_a75_h{h:+d}_ppw{ppw}' for ppw in (24,32)]
    check(f'spatial h={h}',spatial,limits['max_spatial_F_rem_difference_absolute'])
    check(f'spatial transport h={h}',spatial,limits['max_spatial_transport_relative_difference'],'mean_speed_flux',True)
    check(f'temporal h={h}',[base,half],limits['max_time_F_rem_difference_absolute'])
    check(f'box h={h}',[base,f'cavity_a75_h{h:+d}_box20'],limits['max_box_F_rem_difference_absolute'])
check('sponge strength',['cavity_a75_h+1_base','cavity_a75_h+1_eta0.5','cavity_a75_h+1_eta2'],limits['max_sponge_F_rem_difference_absolute'])
status='PASS' if not failures and len(summaries)==len(jobs) else 'FAIL'
write_json(ROOT/'CAVITY_GATE_RESULTS.json',dict(status=status,evaluated=now(),criteria_sha256=sha(ROOT/'config_preregistered.json'),
    case_checks=case_checks,control_checks=control_checks,failures=failures,
    long_runs='AUTHORIZED_BY_PREDEFINED_GATES' if status=='PASS' else 'NOT_EXECUTED_PREDEFINED_SHORT_GATE_FAILURE',
    HRF_CAP2_GATE='NOT_TESTED',estimated_underresolved_energy_fraction={k:s['final']['estimated_underresolved_energy_fraction'] for k,s in summaries.items()}))
print('SHORT CAVITY AND CONTROLS GATE: '+status,flush=True);print('Failures: '+str(failures),flush=True)
