# HRF CAP3 — Dossiê AUTOCONTIDO para a bancada Delaunay
Versão 2 — 2026-10-08

Este arquivo ZIP contém efetivamente os documentos e o pacote compacto completo
com código, figuras, tabelas, logs e resultados da execução Yee 2D3V.

NENHUM DOWNLOAD DO GOOGLE DRIVE É NECESSÁRIO PARA USAR ESTE DOSSIÊ.
Links externos eventualmente presentes nos documentos são registros de proveniência,
não dependências de leitura. Os documentos originais foram preservados sem alterações.

## Leitura obrigatória
1. 01_Autoridade_HRF/ — Capítulo 2 v1.1. Fonte científica para U(1), gauge,
   laços orientados, energia Wilson, operadores e polarizações.
2. 02_Protocolos_CAP3/ — FLUX-01 e regras 2D3V, PHOTON-INJECTION GATE.
3. 03_Yee_2D3V/ — relatórios, pré-registro, gates, balanço de energia e comparação.
4. 04_Historico_CAP3_Escalar/ — histórico do redutor 2D; não valida fóton.
5. 05_Yee_Codigo_Resultados_Completos/HRF_CAP3_2D3V/ —
   código hrf_maxwell_2d3v.py e yee_kernels.cpp, scripts, relatórios adicionais,
   figuras, mapas, logs, métricas e tentativas negativas preservadas.

## Estado da evidência
2D3V-MAXWELL-GATE = PASS [M] (somente Yee livre).
PHOTON-INJECTION GATE HRF-CAP2 = NOT_TESTED [?] na execução Yee anterior.
CAVITY_SHORT_GATE = FAIL [M] por não convergência espacial.
T=150, 300 e 500 do solver vetorial = NOT_EXECUTED [D].
Essas classificações não devem ser transferidas automaticamente à Delaunay.

## Execução Delaunay
Não reconstruir o modo fotônico somente com um escalar genérico.
Derivar a redução 2D3V da conexão 3D e preservar d1*d0=0 e os modos físicos.
Começar com controle livre, depois cavidade R=4 lambda, sem exigir órbita.
Não afrouxar limites retrospectivamente para obter PASS.
Preservar resultados negativos [M].
Usar códigos e relatórios incluídos; não depender dos links externos.

## Integridade
MANIFEST_SHA256.json contém os hashes dos 13 documentos do dossiê original.
A cópia do pacote Yee foi incorporada entrada por entrada sem alterar os bytes
dos arquivos, sob 05_Yee_Codigo_Resultados_Completos/.
