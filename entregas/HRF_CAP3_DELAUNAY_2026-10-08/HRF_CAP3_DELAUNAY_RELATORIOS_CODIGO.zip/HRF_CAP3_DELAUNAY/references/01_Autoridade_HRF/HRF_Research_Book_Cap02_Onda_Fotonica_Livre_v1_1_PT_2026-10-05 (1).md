# Holographic Reconstruction of Physics
## Research Book of the Holographic Reconstruction Framework (HRF)
# Capítulo 2 — A onda fotônica livre

**Versão:** 1.1 (migração editorial para HRF; conteúdo científico do fechamento v1.0 preservado) · **Data:** 5 de outubro de 2026
**Programa:** Holographic Reconstruction Framework (HRF) / The Understanding Initiative · **ramo:** HRF-FM — Fields and Matter Reconstruction
**Proveniência histórica:** este capítulo deriva do ramo **C5A** do antigo PRFE Framework. Rótulos C5A/C5B em bancadas, arquivos e fontes históricas são mantidos para rastreabilidade.
**Base científica:** C5A — Livro de pesquisa, Capítulo 2 v1.0, fechamento provisório de 2 de outubro de 2026 — Claude (`-clau`).
**Substitui editorialmente:** a nomenclatura C5A do v1.0 deste capítulo; não altera resultados, números, critérios ou decisões científicas.
**Fontes:** Master Research Notebook v1.7 (§§11–21, 120–124, 142–168); relatórios e pacotes HOL1, B1, B3, B8, B10,
B11-luz-luz, B12-faixa (revisão 1); consolidação do fluxo par *Microestrutura inversa, B11/B12 e teto unificado*;
INVERSE-01/02, B11-Morse, B12-Morse e B14 (fluxo par; B14 auditada nesta sessão).

**Marcas:** [F] física ou matemática estabelecida · [M] resultado de toy model ou bancada · [H] hipótese específica do HRF ·
[?] questão aberta · [D] decisão editorial ou metodológica do pesquisador.

**Escolhas de redação desta versão:** ordem lógica (do substrato à observação), com o histórico em caixas curtas;
equações essenciais no corpo e detalhes em caixas técnicas; analogias médicas em notas curtas; “luz em meios e guias”
fica como caixa neste capítulo (pode ganhar capítulo próprio depois).

**Nota terminológica da migração HRF:** **GMF** é mantido como o nome técnico dos graus usados neste toy model fotônico, porque o próprio esqueleto do HRF ainda deixa em aberto a relação formal entre **PGFE, GMF e as entidades do HRF-PD**. Portanto, esta revisão **não** impõe uma substituição GMF → PGFE. Do mesmo modo, “microgeometria” é preservado quando descreve a conectividade/deformação das malhas históricas C5A; isso não equivale à reconstrução de geometria e espaço-tempo, que pertence ao programa **HRF-ST**.

**Numeração das bancadas:** ímpares neste fluxo de trabalho (B13, B15…), pares no outro (B14, B16…). As duas bancadas
antigas com número repetido são citadas com rótulo: **B11-luz-luz** e **B12-faixa** (este fluxo), **B11-Morse** e
**B12-Morse** (fluxo par).

---

## Sumário

- 2.0 Abertura: o que este capítulo afirma
- 2.1 A pergunta e o contrato do fóton livre
- 2.2 O que oscila: a relação, não o GMF
- 2.3 Da conexão à equação de onda
- 2.4 A forma da onda: o pequeno saca-rolha e a propagação reta
- 2.5 O fechamento do fóton efetivo (B1)
- 2.6 O substrato: malhas irregulares, faixa de distâncias e deformação
- 2.7 Frente às observações
- 2.8 A versão quântica
- 2.9 O que o capítulo não afirma
- 2.10 Caminhos descartados
- 2.11 Questões abertas e pontes para os capítulos seguintes
- 2.12 Registro de fechamento provisório
- Apêndice A — Bancadas e arquivos
- Apêndice B — Números de referência
- Apêndice C — Glossário do capítulo

---

## 2.0 Abertura: o que este capítulo afirma

Na arquitetura editorial do HRF, o Capítulo 1 é o lugar reservado para definir o domínio holográfico pré-geométrico e formalizar a relação entre PGFE, GMF e os demais graus fundamentais. Essa identificação ainda não está fechada. Para o setor fotônico, este Capítulo 2 do **HRF-FM** mantém o substrato técnico herdado da C5A: Graus Microestruturais Fundamentais (GMFs), cada um com um estado local, ligados aos vizinhos por uma **conexão relacional**. O capítulo mostra que, nesse substrato de toy model, existe uma onda que se comporta como a luz livre. Livre quer dizer sem fontes, sem cargas e sem curvatura.

**Afirmação central [M].** Num substrato de GMFs com conexão relacional U_nm = e^{ia_nm} e energia de Wilson, emerge
uma onda com as propriedades de Maxwell no vácuo:
- duas polarizações transversais e um modo longitudinal sem dinâmica (gauge);
- ω = ck e P = E/c no limite de comprimento de onda longo;
- helicidade ±1, degenerada no vácuo.

Depois de impor a quantização canônica, ela dá fótons com spin ±ħ e estrutura de Fock bosônica. Tudo isso é compatível
com as observações testadas: Lorentz e isotropia (LHAASO), birrefringência circular (polarização de GRB) e espalhamento
luz-luz (PVLAS e QED).

**Fronteira.** ħ é entrada, não resultado. A conexão U(1) e a energia de Wilson são postuladas. Emissão e absorção de
fótons não estão aqui, porque exigem matéria carregada.

**Quadro de estado**

| Requisito do fóton livre | Estado | Onde |
|---|---|---|
| propagação, ω = ck, P = E/c | [M] fechado | §2.3, §2.5 |
| 2 transversais + gauge | [M] fechado | §2.3 |
| helicidade ±1, degenerada | [M] fechado | §2.4, §2.5 |
| Lorentz no UV compatível | [M] sim, com √ξ·a_ρ ≲ 2,0×10⁻²⁸ m | §2.7 |
| isotropia no IR | [M] sim, a 10⁻⁶ | §2.7 |
| birrefringência do vácuo | [M] compatível no canal circular | §2.7 |
| autointeração / luz-luz | [M] 3×10⁻⁵⁵ da QED | §2.7 |
| independência da faixa de distâncias | [M] velocidade, isotropia e forma da autointeração | §2.6 |
| versão quântica (Fock, ±ħ) | [M]+[F], com ħ e quantização impostos | §2.8 |
| conexão compacta compatível | [M] sim, na fase de Coulomb | §2.8 |
| emissão/absorção de um quantum | [?] fora deste ramo | §2.11 |
| origem de ħ, U(1), α, carga | [?] fora deste ramo | §2.11 |

> **Analogia.** O sinal nervoso não é o neurônio viajando: é uma mudança passada de célula em célula. No toy model fotônico do **HRF-FM** (historicamente C5A), o que
> oscila e passa adiante não é nem o GMF (o “neurônio”) nem o seu estado interno, mas a **relação** entre vizinhos
> (a “sinapse”).

---

## 2.1 A pergunta e o contrato do fóton livre

A pergunta do capítulo: **o que uma onda precisa ter para ser chamada de fóton livre**, e o substrato técnico usado pelo **HRF-FM** neste capítulo produz
isso?

O contrato foi fixado antes dos modelos (caderno §18, §124):

1. propagação sequencial, de vizinho em vizinho, sem que os GMFs se desloquem;
2. ω = ck e P = E/c no limite de baixa energia (massa zero);
3. exatamente duas polarizações físicas, transversais;
4. um modo longitudinal sem dinâmica, isto é, uma simetria de gauge;
5. helicidade h = ±1, as duas com a mesma velocidade no vácuo;
6. spin separado de momento angular orbital (OAM);
7. Lorentz recuperado no limite de baixa energia, com desvios abaixo dos limites observacionais;
8. versão quântica com E = ħω e S = ±ħ.

Dois níveis de fechamento são distinguidos desde o início:
- **PHOTON-CLOSURE-E** (fóton efetivo): o toy model reproduz o contrato acima;
- **PHOTON-CLOSURE-F** (fóton físico): o fóton real seria derivado, incluindo ħ, U(1), emissão e absorção.

Este capítulo fecha o primeiro, não o segundo.

---

## 2.2 O que oscila: a relação, não o GMF

### 2.2.1 A primeira tentativa: o estado local

> **Histórico (caderno §§11–16).** O primeiro candidato a fóton foi um Modo Circular Transversal do estado local
> q_n: q_x = A cos(kz − ωt), q_y = ±A sin(kz − ωt). Os GMFs ficam no lugar e o padrão muda de GMF em GMF. A amplitude
> foi escolhida à mão para dar E = ħω e |S| = ħ, um defeito corrigido depois pela quantização canônica (§2.8). Numa
> cadeia, ω(k) = 2√(κ/μ)|sin(ka/2)|, com ω ≈ ck e c = a√(κ/μ) no contínuo. Um pacote circular na rede conservou energia
> a 10⁻⁹, L_z a 10⁻¹⁵, andou com a velocidade de grupo (erro 1,7×10⁻⁴) e deu L_zω/E ≈ ±1.

Esse caminho funcionava em cadeias, mas esbarrou em dois problemas: um campo vetorial genérico tem um modo
longitudinal físico (§2.3), e não havia razão microscópica para a estrutura rotacional que o elimina.

### 2.2.2 Por que o estado local não serve (HOL1, parte P2) [M]

A bancada HOL1 testou se o grau que vive nas ligações poderia ser **derivado** do estado local q_n:

- **diferença transportada** D_nm q = q_m − P_nm q_n: as diferenças se cancelam ao longo de um laço fechado e sobra
  (H_f − I)q. No espaço plano, a energia é identicamente zero; num poço, aparece um termo tipo massa (ω² independente
  de k). **Falha.**
- **projeção na ligação:** o modo longitudinal fica mole (ω_L²/ω_T² cai de 0,19 para 0,029 com o refinamento), mas
  **propaga** em resolução finita. Seria uma terceira polarização lenta, que mudaria por exemplo a lei de
  Stefan–Boltzmann. **Falha.**

### 2.2.3 Por que a conexão serve (HOL1, parte P3) [M]

O grau que funciona é uma **fase própria de cada ligação**:

\[
U_{nm}=e^{ia_{nm}},\qquad U_{mn}=U_{nm}^{-1},\qquad
H_f=\prod_{\partial f}U=e^{iC_f},\qquad
E_f=w_f\,\|H_f-1\|^2=2w_f(1-\cos C_f)\simeq w_fC_f^2 .
\]

Resultados na malha irregular (Delaunay de 216 a 5 832 GMFs):
- duas transversais com ω/ck = 1,00 ± 0,9%;
- terceiro modo com ω = 0, 100% longitudinal;
- convergência do operador na forma fraca: erro 0,0085 com pesos de Whitney em 5 832 GMFs (orientação embaralhada:
  0,74, sem convergência);
- **gauge exato também com o cosseno completo:** a energia não muda sob a_e → a_e + φ_m − φ_n (girar a fase interna de
  um GMF);
- a energia completa sobre a quadrática vale 0,9999 (|C| = 0,1), 0,997 (0,5), 0,988 (1) e 0,952 (2): o curl-curl é o
  limite de campo fraco, e o resto é autointeração (§2.7.4).

### 2.2.4 Consequência para a ontologia operacional do toy model

\[
\boxed{\text{GMF}=\{q_n\ \text{(estado local)}\}\ \cup\ \{U_{nm}\ \text{(conexão relacional entre vizinhos)}\}}
\]

**Leitura no HRF.** Esta expressão descreve o objeto operacional usado pelo ramo fotônico histórico C5A/atual HRF-FM. Ela **não** identifica, por si só, um GMF com uma PGFE nem com a entidade fundamental do HRF-PD. Essa correspondência permanece **[?]** e deve ser definida no Capítulo 1 e nas interfaces HRF-PD ↔ HRF-FM.

- A metade **geométrica** da cadeia (vizinhança, orientação dos laços, transporte, pesos) está derivada no toy model.
- A metade **dinâmica** (a conexão como grau próprio, com energia de Wilson e termo cinético ½Σ m_e ȧ_e²) é
  **postulado [H]**.
- O resultado coincide com teoria de gauge na rede e com cálculo exterior discreto [F].

> **Caixa — o que é a fase de uma ligação.** Cada GMF tem um referencial interno (uma “fase”). A fase da ligação diz
> como comparar os referenciais de dois vizinhos. Girar o referencial interno de um GMF muda as fases de todas as suas
> ligações, mas não muda nada físico: essa é a simetria de gauge. O que é físico é a volta completa num laço (a
> holonomia), que não depende dessa escolha.

---

## 2.3 Da conexão à equação de onda

### 2.3.1 Laços orientados geram o rotacional

Numa malha de GMFs (tetraedros de Delaunay), cada face triangular é um laço orientado. A circulação no laço é a soma
das fases das suas ligações, com sinal:

\[
C_f=\sum_{e\in\partial f}s_e\,a_e,\qquad E=\tfrac12\,C^{\mathsf T}M_2\,C,\qquad M_1\,\ddot a=-\,d_1^{\mathsf T}M_2\,d_1\,a .
\]

**Nenhum operador rotacional é colocado à mão.** Mesmo assim [M] (bancada do curl-curl emergente, Atualização 20):

\[
d_1^{\mathsf T}M_2\,d_1\ \longrightarrow\ \nabla\times\nabla\times\qquad(\text{forma fraca})
\]

- erro da forma fraca: 0,097 → 0,039 → 0,018 → 0,0087 (216 → 5 832 GMFs), ordem ≈ 2;
- conchas de modos com 12, 24 e 16 modos, isto é, 2 × (número de vetores k): **exatamente duas polarizações**;
- velocidade: c² = (rigidez dos laços)/(inércia das ligações); na cadeia, c = a√(κ/μ).

No contínuo, a equação é a de Maxwell no vácuo no gauge temporal:

\[
\mu\,\ddot{\mathbf A}=-\kappa a^2\,\nabla\times\nabla\times\mathbf A .
\]

### 2.3.2 O gauge vem de graça

Como d₁d₀ = 0 (o rotacional de um gradiente é zero), uma configuração a = ∇φ não tem energia nem dinâmica, e a lei de
Gauss ∇·ä = 0 se mantém sem nenhuma projeção manual. Esta é uma **identidade combinatória**: vale para qualquer posição
dos GMFs, desde que a lista de ligações e laços seja consistente. Por isso ela é um controle de código, não um teste
físico da geometria. O teste físico é o que acontece quando a conectividade muda (§2.6.4).

### 2.3.3 Controles negativos: o que não funciona

| Acoplamento | Resultado |
|---|---|
| laplaciano vetorial (κ/2)Σ\|q_{n+e} − q_n\|² | 3 modos propagantes: longitudinal físico |
| pares sem laço (isotrópico, perpendicular, central) | 3 modos propagantes |
| laços com orientação embaralhada | sem convergência, sem gauge, contagem errada |
| **laços orientados (rotacional)** | **2 transversais + 1 modo de frequência zero (gauge)** |

O setor fotônico restringe não só escalas, mas a **forma** do acoplamento: precisa ser rotacional.

### 2.3.4 Pesos geométricos

Dois conjuntos de pesos foram usados:
- **Whitney (W)**, padrão da B1 e da B8: dá c = 1 sem nenhum ajuste;
- **duais baricêntricos (D)**, usados na HOL1, B10 e B11-luz-luz: a velocidade absoluta sai 12–21% acima de c, com
  fator que varia conforme a família de malha (B12-faixa). Isso não aparecia antes porque a HOL1 normalizava o espectro D
  pela média. Os pesos D exigem uma normalização ainda não derivada; as razões usadas na B11-luz-luz não dependem disso.

> **Analogia.** A pressão arterial é medida em relação à atmosfera: somar a mesma constante em todo lugar não muda nada.
> O gauge é isso. Só as diferenças em volta de um laço contam.

---

## 2.4 A forma da onda: o pequeno saca-rolha e a propagação reta

**Imagem consolidada:**

\[
\boxed{\text{pequeno saca-rolha (polarização)}+\text{propagação média reta}}
\]

- A **hélice pequena** é a rotação da fase das ligações ao longo da propagação. É a polarização circular, ou seja, a
  helicidade. Não é a trajetória de nenhum GMF e não é o estado local q_n.
- A **propagação média é reta**: o microscópico é tortuoso (a malha é irregular; o erro ponto a ponto fica em ~0,68),
  mas o coletivo converge na forma fraca com ordem 2.
- A **hélice grande** (o centro do feixe andando em espiral) não ocorre num meio homogêneo. Aparece só em fundos
  girantes ou guias.

**Spin × OAM.** Para um fóton estruturado, L_z = ℓħ (orbital, qualquer inteiro) e S_z = sħ (spin, só ±1), com
J_z = (ℓ + s)ħ. **Hélice de fase não é spin.**

**Teste leve [F/M].** O modo circular é autovetor do rotacional: ∇×q_s = −sk q_s e ∇×∇×q_s = k² q_s. O primeiro
rotacional distingue a mão; o segundo é igual para as duas. Por isso a equação de onda tem ω = c|k| para as duas
helicidades. Numericamente, a convergência é de 2ª ordem e idêntica para s = ±1.

**Convenção.** O rótulo histórico s não é a helicidade sem dizer a direção de k: para θ = kz − ωt, s = +1 pode ser
helicidade negativa em +z.

**Cor e energia.** Cor ↔ ω, λ = 2π/k; E = ħω e p = ħk, com ħ como entrada.

> **Caixa — luz em meios e guias (não é vácuo, mas ajuda a entender).**
> - Num meio com índice n(x), o operador vira ∇×(1/n)∇×, com gauge exato (HOL1, erro 0,018). A geometria muda
>   coeficientes, não a estrutura de gauge.
> - Num fundo girante com ℓ = 0, as helicidades se separam: Δω = −hJ (~3%), com sinal vindo do giro do espaço, não da mão
>   da malha (HOL1). Na bancada do curl-curl emergente, com Ω = 0,05: ω₊ − ω₋ = −0,0986 contra −2Ω = −0,100.
> - Retroação fraca da onda sobre a microgeometria é pequena (‖δg‖/‖g⁽⁰⁾‖ ≈ 0,004) e troca de sinal com h; retroação
>   forte destrói a propagação (G0G).
> - A separação de helicidades vista na G0G e no critério P4 da B1 é efeito de **modo preso no guia**, não do vácuo
>   (B3, §2.7.3).

---

## 2.5 O fechamento do fóton efetivo (B1)

### 2.5.1 Histórico de método

> **Histórico.** A primeira rodada do PHOTON-CLOSURE declarou PASS, mas trocou critérios depois de ver os resultados.
> A replicação com critérios congelados (1º out) passou em todos os 12 critérios na R1 e falhou num deles na R2 (pureza
> de helicidade 0,981 em 10³, abaixo de 0,99). Daí veio o **princípio editorial 20**: critérios de PASS/FAIL de bancadas
> decisivas são pré-registrados com hash antes de rodar; trocas posteriores são só exploratórias.

### 2.5.2 A bancada B1 [M]

Dez sementes (20261201–20261210), critérios congelados (pré-registro de 1º out, 23h50).

| Critério | Resultado | Números |
|---|---|---|
| P1 itens internos, ≥ 9/10 sementes | passa | 9/10 |
| P2a ordem do resíduo de helicidade | passa | mediana 0,98 [0,98; 1,01] |
| P2b impureza de helicidade | passa | 3,8×10⁻³ → 4,3×10⁻⁴ → 1,1×10⁻⁴ (10³, 14³, 18³) |
| P2c deriva dinâmica em 18³ | passa | 10/10 < 0,005 |
| P3 ordem de (E² − P²c²)/E² | passa | 1,98 [1,96; 2,00] |
| P4 Δ_hel no fundo compensado | passa* | supressão 8–40× contra o controle |
| P5 Lorentz quadrático no UV | passa | 10/10 com termo linear desprezível |

\*Correção posterior (B3): o P4 mede um modo preso no guia, não o vácuo.

Também: ω/ck = 0,993 (10³) → 0,998 (20³), com desvio proporcional a (ka)², que é a dispersão de rede (§2.7.1).

\[
\boxed{\text{PHOTON-CLOSURE-E: FECHADO (toy model) [M]}}
\]

**Desvio declarado:** seis rodadas morreram por falta de memória e foram refeitas uma de cada vez, com o mesmo código e
sementes. **Auditoria independente:** hashes conferidos, avaliador reexecutado com resultado idêntico, controle de
determinismo idêntico.

---

## 2.6 O substrato: malhas irregulares, faixa de distâncias e deformação

### 2.6.1 Espaço-tempo plano e conectividade (D1)

No setor fotônico do **HRF-FM**, o espaço-tempo é tratado como plano (g_μν = η_μν, decisão histórica D1). A organização que o substrato dá ao fóton
(vizinhança, orientação dos laços) é **relacional**, não curvatura. “Microgeometria”, aqui, é um rótulo histórico da C5A e quer dizer **conectividade/deformação da malha**. Não deve ser confundida com a reconstrução de distância, métrica ou espaço-tempo do **HRF-ST**.

### 2.6.2 Escalas: o que é “a distância entre GMFs”

\[
r_{\rm GMF}\ (\text{tamanho interno, se existir})\ \neq\ a_\rho=(V/N)^{1/3}\ (\text{escala de densidade})\ \neq\ r_{nm}\
(\text{distância local})\ \neq\ \Delta x_{\rm num}\ (\text{passo numérico})
\]

As distâncias locais r_nm formam uma distribuição P(r), com uma cauda superior r_tail. O passo numérico não tem
significado físico.

### 2.6.3 Faixa fixa no tempo (D3; B12-faixa) [M]

**Decisão D3 [D]:** a distância entre GMFs vizinhos varia numa faixa, com mínimo e máximo, como as moléculas do ar para o
som. Por enquanto, a faixa é fixa no tempo (vidro, não gás).

A B12-faixa comparou cinco famílias com a mesma densidade média: Poisson (sem mínimo), núcleo duro com mínimo 0,4a, 0,6a
e 0,8a, e a malha “tremor” das bancadas anteriores (45 malhas, critérios pré-registrados).

| Malha (20³) | faixa ℓ/a_ρ | ξ médio | a_ρ,max (m) | desdobramento de polarização (menor k) |
|---|---|---|---|---|
| Poisson | 0,03 – 2,92 | 0,0112 | 1,9×10⁻²⁷ | 2,6×10⁻⁴ |
| mínimo 0,4a | 0,40 – 2,84 | 0,0103 | 2,0×10⁻²⁷ | 1,7×10⁻⁴ |
| mínimo 0,6a | 0,60 – 2,55 | 0,0088 | 2,2×10⁻²⁷ | 1,5×10⁻⁴ |
| mínimo 0,8a | 0,80 – 2,09 | 0,0056 | 2,7×10⁻²⁷ | 1,1×10⁻⁴ |
| tremor | 0,32 – 2,18 | 0,0064 | 2,5×10⁻²⁷ | **1,9×10⁻³** |

- **Velocidade e isotropia não dependem da faixa:** c = 1 a 7×10⁻⁶ e isotropia a 8×10⁻⁶ em todas.
- **A forma da autointeração não depende:** κ∥/κ⊥ = 3 em todas as 45 malhas (§2.7.4).
- **O desdobramento entre as duas polarizações depende da família:** a tremor tem ~10× mais que as malhas sem grade.
  Cai com o refinamento em todas (Poisson: 2,0×10⁻³ → 5,9×10⁻⁴ → 2,6×10⁻⁴, de 10³ a 20³).
- **O teto muda pouco** (no máximo 1,4×) e melhora quando a faixa estreita.
- **O mínimo da faixa não é limitado** por nada testado.

### 2.6.4 Faixa deformável no tempo (fluxo par: B11-Morse, B12-Morse) [M]

O fluxo par testou a versão em que as distâncias oscilam no tempo, com um potencial de Morse entre GMFs:

\[
U(r)=D\,[1-e^{-\alpha(r-a_0)}]^2,\qquad
\frac{r_{\min}}{a_0}=1-\frac{\ln(1+\sqrt u)}{\lambda},\quad
\frac{r_{\max}}{a_0}=1-\frac{\ln(1-\sqrt u)}{\lambda},
\]

com λ = αa₀ e u a fração da energia de dissociação em cada ligação. O Morse dá naturalmente r_min e r_max como
**pontos de retorno** de cada ligação para a sua energia; não são constantes universais.

- **B11-Morse:** com 20% de deformação, as distâncias exploraram ~0,71 a ~1,28 r₀, e a conectividade de Delaunay foi
  reconstruída no tempo (Jaccard mínimo ≈ 0,925). Gauge preservado (10⁻¹⁶), N + 2 modos nulos, nenhum ω² < 0.
- **B12-Morse** (4³ → 6³ → 8³, uma realização por resolução):

| | 4³ | 6³ | 8³ |
|---|---|---|---|
| ω/ck, equilíbrio | 0,9465 | 0,9786 | 0,9862 |
| desdobramento, equilíbrio | 1,04×10⁻² | 5,56×10⁻³ | 3,24×10⁻⁴ |
| ω/ck, 20% de deformação | 0,9482 | 0,9770 | 0,9854 |
| desdobramento, 20% de deformação | 1,77×10⁻² | 1,04×10⁻² | 2,01×10⁻³ |

**Leitura.** O déficit de ω/ck é a dispersão quadrática de rede já conhecida: supondo k = 2π/L, o déficit dividido por
(ka)² dá ξ ≈ 0,02 nas três resoluções, perto do valor da B8. O desdobramento cai com o refinamento mesmo sob deformação,
mas de forma irregular; com uma realização por resolução, o salto em 8³ pode ser acaso. Falta repetir com várias
realizações e pré-registro.

### 2.6.5 Qual parte da faixa controla o UV (B12-faixa, B14) [M]

Na B12-faixa, no mesmo tamanho de malha, ξ acompanha a cauda superior da faixa: ξ/(ℓ_max/a_ρ)² varia ±3% entre as
famílias e ξ/(p99/a_ρ)², cerca de ±11%. Mas ℓ_max é o maior valor de uma amostra e cresce com o tamanho da malha.

A **B14** (fluxo par) testou a causalidade: uma família RARA, com um único defeito local que aumenta ℓ_max em 24%, contra
a malha-base e uma família DIFUSA (modulação senoidal em z), com p1, média, RMS e p99 iguais a < 0,3%.

- **RARA contra a base:** ξ muda só **+0,2%** em 20³. Um único extremo não controla ξ. **ℓ_max isolado está descartado
  como variável.**
- A razão de 1,04 do relatório original (RARA/DIFUSA) vem da DIFUSA, que baixa ξ em 3,6% e varia de forma errática com a
  resolução (+6,6%, −0,8%, −3,6%). A DIFUSA não é um controle neutro.
- **Modelos treinados na B12 e testados na B14:**

| Modelo | erro no treino (B12) | erro no teste (B14) |
|---|---|---|
| ξ = C·ℓ_max² | 3,6% | 22% |
| ξ = C·p99² | 8% | 13% |
| ξ = C·⟨ℓ⁴⟩^½ | 18% | 5% |
| ξ = C·⟨ℓ²⟩ | 22% | 10% |

  Nenhum dos quatro passa nos dois testes. O ⟨ℓ⁴⟩ só acerta a B14 porque as três famílias dela têm quase o mesmo valor e a
  calibração cai por acaso nesse ponto. O p99 é o candidato menos ruim. É possível que ξ dependa de algo que não é um
  momento das distâncias (forma dos tetraedros, correlações espaciais, memória de grade).
- **Auditoria:** reproduzi a malha-base da B14 com código independente; ξ, c0, ℓ_max e p99 saíram idênticos. O código
  das famílias deformadas não veio no pacote.

**Um ponto de fundo:** um defeito único ocupa ~0,3% do volume em 20³, e ξ é uma média de volume. O teste confirma o
esperado; o resultado útil é metodológico: **a variável a reconstruir é a distribuição P(r) e suas correlações, não uma
distância máxima.**

---

## 2.7 Frente às observações

Cada propriedade que poderia denunciar a rede, o dado que a limita e a folga.

| Teste | Observação usada | Resultado | Bancada |
|---|---|---|---|
| Lorentz no UV | LHAASO, GRB 221009A: E_QG,2 > 6,9×10¹¹ GeV | √ξ·a_ρ ≲ 2,0×10⁻²⁸ m | B8, consolidação |
| isotropia no IR | — | anisotropia de c cai a 1,4×10⁻⁶ (26³) | B8, B12-faixa |
| birrefringência acumulada, canal circular | polarização do GRB 140206A (z = 2,739) | média zero; giro ~10⁻¹² rad (permitido π/2) | B3 |
| autointeração / luz-luz | PVLAS; QED (Euler–Heisenberg) | 3×10⁻⁵⁵ da QED | B11-luz-luz |

### 2.7.1 Lorentz no UV e o teto unificado (B8) [M]

A dispersão medida na malha é

\[
\frac{\omega}{ck}=1-\xi\,(k a_\rho)^2+\dots,\qquad \frac{v_g}{c}=1-3\xi\,(k a_\rho)^2+\dots
\]

Na convenção quadrática do LHAASO, v = c[1 − (3/2)(E/E_QG,2)²]. Com E = ħck:

\[
\boxed{\ a_{\rho,\max}=\frac{\hbar c}{E_{\rm QG,2}\sqrt{2\xi}}\quad\Longleftrightarrow\quad \sqrt{\xi}\,a_\rho\lesssim 2{,}0\times10^{-28}\ \text{m}\ }
\]

com E_QG,2 > 6,9×10¹¹ GeV (Cao et al. 2024, PRL 133, 071501). Esta é a **forma canônica**, adotada pelos dois fluxos.

| Caso | ξ | a_ρ,max |
|---|---|---|
| cadeia uniforme | 1/24 | 9,9×10⁻²⁸ m |
| tremor, eixo (B8, 20³, 10 sementes) | 0,0163 [0,0161; 0,0164] | 1,6×10⁻²⁷ m ≈ 10⁸ ℓ_P |
| Poisson … mínimo 0,8a (B12-faixa, 20³) | 0,0112 … 0,0056 | 1,9 … 2,7×10⁻²⁷ m |
| INVERSE-01 antigo | — | 7,6×10⁻²⁸ m (**aposentado**: convenção sem o fator 3/2) |

**Como ler.** O observável limita a **combinação** √ξ·a_ρ, não cada distância r_nm. O ξ depende da estatística da
rede (§2.6.5). O valor 1,6×10⁻²⁷ m é um teto conservador da família tremor, não a “distância máxima universal entre
GMFs”. GMFs de escala de Planck não são pressionados.

**Isotropia.** A velocidade no IR é isotrópica: a anisotropia entre 13 direções cai de 3,4×10⁻⁴ (10³) para 1,4×10⁻⁶
(26³). O UV, porém, depende da direção na malha tremor (eixos ≈ 0,017, diagonais de face ≈ 0,005, diagonais de cubo
≈ 0,001): a malha guarda memória da grade que a gera. As malhas sem grade (Poisson, núcleo duro) não têm esse problema.

**Referencial preferido [F].** Uma malha define um referencial preferido. O teto acima é o que o torna inobservável com
os dados atuais.

### 2.7.2 Birrefringência acumulada (B3) [M]

Uma luz que atravessa bilhões de anos-luz acumularia qualquer rotação sistemática do plano de polarização.

| Fonte | média zero | δ ∝ (ka)^p | Δθ ∝ L^r |
|---|---|---|---|
| malha tremor | sim | p = 4,6 | r = 0,68 |
| malha Poisson | sim | p = 3,5 | r = 0,59 |
| quiralidade compensada, tremor | sim | p = 1,8 | r = 0,41 |
| quiralidade compensada, Poisson | sim | p = 2,8 | r = 0,75 |

- Controles: atividade óptica uniforme reproduzida (δ/ξk = 0,993 em 26³, Drude–Born–Fedorov [F]); quiralidade única ~10⁴
  vezes a compensada.
- Limite: polarização do GRB 140206A em 200–400 keV, z = 2,739 (Götz et al. 2014, MNRAS 444, 2776). O teto mais
  restritivo da B3 (5,8×10⁻²³ m) é muito mais frouxo que o da B8. Abaixo do teto da B8, o giro previsto é ~10⁻¹² rad.
- Argumento robusto [F]: a média de uma densidade aleatória de sinal ± num volume V cai como (s³/V)^½ (limite central).
- **Ressalva:** a B3 mediu o **canal circular** (rotação do plano). O canal linear pode ser maior nos dados brutos e o
  desdobramento depende da família de malha (§2.6.3). O transporte completo de polarização (Stokes/Jones) está em aberto.

**Correção registrada:** microvórtices de arrasto **não** são um modelo de quiralidade do vácuo. Um vórtice localizado tem
vorticidade total nula, e rotação é pseudovetor, não pseudoescalar; o efeito de primeira ordem sobre uma onda extensa
some. O modelo adequado é uma densidade pseudoescalar compensada (“fitas de ambas as mãos”).

### 2.7.3 Autointeração e espalhamento luz-luz (B11-luz-luz) [M]

Se a conexão é compacta, o termo −C⁴/24 da energia de Wilson é uma autointeração do fóton que só existe por causa da
rede. Num campo magnético forte B₀, ela produz birrefringência magnética do vácuo:

\[
|\Delta n_{\rm rede}|=\frac{e^2a^4B_0^2}{4\hbar^2}\,\Delta\kappa,\qquad \kappa=\frac{\text{termo quártico}}{\text{termo quadrático}} .
\]

| Grandeza | Valor |
|---|---|
| Δκ (Poisson 20³) | 0,319 ± 0,004 |
| \|Δn_rede\|/Δn_QED no teto da B8 | **3×10⁻⁵⁵** |
| a em que a rede igualaria a QED | 6,8×10⁻¹⁴ m ≈ 0,18 ƛ_C |
| a máximo pela PVLAS (2σ), se a conexão for compacta | 1,2×10⁻¹³ m |

- Validação dinâmica: uma onda plana com a energia completa muda de frequência como um pêndulo, com erro de 3–6% contra a
  previsão Δω/ω = −(1/16)⟨|C|⁴⟩/⟨|C|²⟩.
- **Forma universal [M]+[F]:** κ∥/κ⊥ = 3 em todas as malhas. É forçado pela isotropia: um tensor de 4ª ordem totalmente
  simétrico e isotrópico só pode dar (B²)².
- **Assinatura oposta à da QED [M]:** na QED, n(E∥B₀) > n(E⊥B₀), na razão 7:4. Na rede de Wilson hamiltoniana, que só
  tem quártico magnético, n(E⊥B₀) > n(E∥B₀), na razão 3:1.
- Automodulação de uma onda única (ausente na QED): Δω/ω ~ 10⁻⁶⁵ no laser mais intenso já feito. Luz-luz no LHC:
  correção < 10⁻⁴⁰ da QED. Inobserváveis.
- Fontes: PVLAS, Δn = (12 ± 17)×10⁻²³ a 2,5 T (Ejlli et al. 2020, Phys. Rep. 871, 1); QED 3A_e ≈ 4,0×10⁻²⁴ T⁻²
  (CODATA 2018).

> **Analogia.** É como checar se um remédio tem efeito paradoxal em dose altíssima. O mecanismo existe, mas na dose
> real, fixada pela B8, o efeito é 10⁵⁵ vezes menor que o do “remédio de referência” (a QED). A única marca reconhecível
> seria um padrão invertido no exame (qual polarização desacelera mais), longe de qualquer sensibilidade disponível.

### 2.7.4 Leitura de conjunto

O teto mais forte é o de Lorentz (B8). Os outros testes são muito mais frouxos. A rede do setor fotônico **HRF-FM**, herdada da C5A, com a_ρ abaixo de
~10⁻²⁷ m, é observacionalmente indistinguível do vácuo de Maxwell em todos os testes feitos.

> **Analogia.** Exames de rastreio com sensibilidades diferentes. O LHAASO é o exame mais sensível e parece enxergar
> sobretudo a cauda longa da faixa. O limite inferior das distâncias não aparece em nenhum exame feito até agora.

---

## 2.8 A versão quântica

### 2.8.1 Quantização canônica da conexão (B10, parte A) [M]+[F]

Impondo [a_e, Π_e'] = iħ δ_ee' na conexão não compacta:

| Critério | tremor 6³ | tremor 8³ | Poisson 8³ | tremor 10³ |
|---|---|---|---|---|
| modos nulos = N + 2 (gauge N − 1 + 3 harmônicos do toro) | 218 = 218 | 514 = 514 | 514 = 514 | 1 002 = 1 002 |
| lei de Gauss nos modos físicos | 4×10⁻¹⁴ | 3×10⁻¹⁴ | 4×10⁻¹⁴ | 5×10⁻¹⁴ |
| ω² negativos | 0 | 0 | 0 | 0 |
| camadas (12, 24) | sim | sim | sim | sim |
| helicidade de um quantum | ±0,89 | ±0,94 | ±0,93 | **±0,96** |

O desvio de |h| = 1 cai com o refinamento (0,110 → 0,062 → 0,038).

**Leitura correta.** Depois de **impor** a quantização canônica, o espectro físico é positivo, o gauge é exato, há dois
estados de um fóton por vetor k, e a helicidade converge para ±1, isto é, S = ±ħ. Cada modo é um oscilador independente,
e a estrutura de Fock, E = ħω(n + ½), segue [F]. **Nem a estatística bosônica nem ħ são derivadas.**

> **Histórico (caderno §15).** O oscilador transversal com [q, p] = iħ já dava E₁ − E₀ = ħω e L_z = ±ħ, tirando a
> amplitude “escolhida à mão” da primeira construção.

### 2.8.2 Conexão compacta e fase de Coulomb (B10, parte B) [M]

Se a fase das ligações é um ângulo (conexão compacta, decisão D2 ainda aberta), a teoria tem duas fases: uma confinante,
com monopolos de rede condensados e sem fóton livre, e uma de Coulomb, com fóton livre.

| Rede | β_c | monopolos: β = 0,2 → β_c + 0,5 |
|---|---|---|
| cúbica 6⁴ e 8⁴ (controle) | 1,00 (literatura: 1,011, Arnold et al., hep-lat/0011058) | 0,42 → 3–4×10⁻⁴ |
| Delaunay 5³×6 e 6³×6 (malha dos GMFs) | **0,64** nos dois tamanhos | 0,34 → 2×10⁻⁴ |

- Condição sobre o substrato [H], na correspondência isotrópica β = 𝒜*/ħ: **𝒜*/ħ ≳ 0,64** se a conexão for compacta.
  A correspondência entre a rede euclidiana e o limite hamiltoniano é aproximada.
- β_c **não** é constante física universal: depende de pesos, tamanhos e realizações (uma realização em dois tamanhos).
  A B11-Morse encontrou transição perto de 0,6 também sob deformação forte (exploratório).
- O EM físico corresponde a β_EM = 1/(4πα) ≈ 10,9, fundo na fase de Coulomb. Na mesma correspondência, isso daria
  𝒜* ≈ 11 ħ e α = ħ/(4π𝒜*) [H]. **Isso não deriva α**; só troca “por que 1/137?” por “por que 𝒜* ≈ 11 ħ?”.
- D2 atualizada: conexão não compacta → nenhuma condição; compacta → exige 𝒜*/ħ ≳ 0,6, traz monopolos de rede (raros
  na fase de Coulomb) e a autointeração da §2.7.3.

### 2.8.3 Energia de ponto zero [F]

A energia de ponto zero da rede é E₀/V ≈ 17,5 ħc/a⁴ (tremor) a 18,9 ħc/a⁴ (Poisson). Com a perto do teto da B8, ela é
enorme: é o problema da constante cosmológica em versão de rede. **Estimativa [M]:** se essa energia fosse a energia
escura observada (ρ_Λ ≈ 5,3×10⁻¹⁰ J/m³), daria a ≈ 0,18 mm, contradizendo o teto do LHAASO por ~10²³. O **HRF-FM**, ao herdar este setor da C5A, herda também o
problema e não o resolve aqui: ou a energia de ponto zero não gravita, ou é cancelada por outro mecanismo.

> **Analogia.** ħ é como o valor de referência que o laboratório fornece: usamos para interpretar o exame, mas ele não
> sai do exame.

---

## 2.9 O que o capítulo não afirma

- que GMFs existem fisicamente ou constituem a ontologia fundamental completa do HRF: os resultados são de toy models;
- que GMF e PGFE são sinônimos: essa relação permanece aberta no HRF;
- que este capítulo reconstrói a geometria ou o espaço-tempo: essa tarefa pertence ao HRF-ST;
- que ħ foi derivado: entra como dado;
- que a estatística bosônica foi derivada: é reproduzida depois de impor a quantização;
- que a conexão U(1) e a energia de Wilson foram derivadas: são postuladas; por que U(1) e não SO(3) está em aberto;
- que α foi derivado: α = ħ/(4π𝒜*) só reformula a pergunta;
- que Lorentz vale exatamente no UV: há referencial preferido da rede, com efeitos abaixo dos limites;
- que a birrefringência do vácuo está fechada em todos os canais: só o circular foi testado;
- que 1,6×10⁻²⁷ m é a distância máxima entre GMFs: o limite é sobre √ξ·a_ρ;
- que ℓ_max amostral é uma escala física: a B14 descartou essa leitura;
- que β_c ≈ 0,64 é constante universal;
- que emissão e absorção estão explicadas;
- que monopolos de rede, topologia ou helicidade são carga elétrica.

---

## 2.10 Caminhos descartados

| Ramo | Lição |
|---|---|
| campo derivado do estado local q_n (HOL1 P2) | não gera fóton: energia zero no plano ou longitudinal propagante |
| acoplamento laplaciano vetorial | deixa um longitudinal físico (3 modos) |
| micro-hélice geodésica (G0, G0B, G0C) | torção uniforme é calibre; torção física em onda pp exige fonte que viola a NEC |
| saca-rolha gravitacional (G0D, G0E) | só é admissível empurrado por meio com energia; custo mínimo = energia do giro (von Laue) |
| hélice autoinduzida (G0F) | exigiria acoplamento gravitacional ~(λ/ℓ_P)² × G |
| onda com “ponta” como elétron | substituída pela captura (capítulo de matéria) |
| vórtices de arrasto como quiralidade do vácuo (B3) | vorticidade total nula: não agem em ondas extensas |
| ℓ_max amostral como escala física (B14) | um extremo isolado não muda ξ |
| teto do INVERSE-01 (7,6×10⁻²⁸ m) | convenção errada; substituído pela forma canônica |

---

## 2.11 Questões abertas e pontes para os capítulos seguintes

**Refinamentos do próprio ramo (não impedem o fechamento):**
- transporte completo de polarização (Stokes/Jones), incluindo o canal linear;
- qual propriedade da faixa controla ξ (p99, correlações espaciais, forma dos tetraedros);
- normalização dos pesos D;
- β_c com mais tamanhos, realizações e pesos geométricos;
- B12-Morse com várias realizações e pré-registro;
- faixa variando no tempo × coerência de fótons cosmológicos.

**Pertencem a outros ramos/capítulos do HRF:**
- **emissão e absorção de um quantum** → **HRF-FM, Capítulo 4 — Estados ligados e massa emergente** (captura, B4/B5; ação de transição, B6), com interface posterior ao Capítulo 5;
- **não linearidade da QED por pares virtuais** → **HRF-FM, Capítulo 5 — O programa do elétron**;
- **origem de ħ** → problema de unificação do HRF, retomado no **Capítulo 12**; historicamente ligado à hipótese da ação universal de transição (Atualização 28), enquanto a B2 não encontrou quantum de ação na
  conexão compacta clássica;
- **origem de U(1), de α e da carga** → [?], interface dos Capítulos 5, 11 e 12;
- **formulação covariante** A_μ/F_μν e Lorentz spin-1 → [?].

**Programa inverso:** partir dos observáveis e inferir a região de microestruturas compatíveis,
θ_micro = {a_ρ, P(r), r_tail, U(r), μ, conectividade, …}, com parte dos dados guardada para teste. Os limites do setor
do fóton só dão tetos (desigualdades). Para fixar valores, o programa precisa de **números positivos medidos**: α
(via 𝒜*), ħ, m_e, G e a constante cosmológica, este como teste de consistência.

---

## 2.12 Registro de fechamento provisório

\[
\boxed{\text{HRF-FM — ramo da onda fotônica livre: FECHADO PROVISORIAMENTE como toy model [M] — 2 de outubro de 2026}}
\]

**Decisão [D] (Mario, 2 out 2026):** o ramo do fóton livre é considerado provisoriamente fechado. No desenvolvimento histórico C5A, o trabalho passou ao ramo da matéria (elétron). Na organização editorial do HRF, os resultados seguintes distribuem-se principalmente entre o **Capítulo 3 — Microestrutura dinâmica**, o **Capítulo 4 — Estados ligados e massa emergente** e o **Capítulo 5 — O programa do elétron**, levando como entrada:
1. a conexão relacional U(1) com energia de Wilson e pesos de Whitney;
2. malhas sem grade, com faixa de distâncias (D3), estáticas ou deformáveis;
3. gauge preservado sob deformação;
4. a_ρ distinto de r_nm; o teto UV escrito como √ξ·a_ρ ≲ 2,0×10⁻²⁸ m;
5. ℓ_max isolado descartado como variável;
6. se a conexão for compacta, a fase de Coulomb (𝒜*/ħ ≳ 0,64) e a autointeração de rede (desprezível).

**Critérios para reabrir:**
- um resultado do ramo de matéria exigir uma conexão ou malha incompatível com as deste capítulo;
- uma observação nova apertar o teto de Lorentz a ponto de exigir ξ menor que o de qualquer família testada;
- uma medida de birrefringência do vácuo (circular ou linear) incompatível com o desdobramento previsto;
- uma assinatura de polarização tipo rede (3:1 invertido) em birrefringência magnética do vácuo.

---

## Apêndice A — Bancadas e arquivos

**Rastreabilidade histórica.** Os nomes de arquivos e bancadas com prefixo `C5A_` são mantidos deliberadamente. Eles registram a proveniência anterior à adoção do HRF e não devem ser renomeados retroativamente.

| Bancada | Pergunta | Decisão | Arquivos principais |
|---|---|---|---|
| curl-curl emergente (Atualização 20) | laços orientados geram ∇×∇×? | sim [M] | caderno §121 |
| HOL1 | de onde vem o grau das ligações? | PASS condicional: conexão própria [M] | caderno §122 |
| replicação PHOTON-CLOSURE | critérios congelados | não replicada (item 6) | `C5A_photon_closure_replicacao_*_2305-clau` |
| B1 | fóton efetivo fechado? | FECHADO [M] | `C5A_B1_PREREGISTRO_2026-10-01_2350-clau.md`, relatório e pacote `*_0530-clau` |
| G0G | fundo compensado e retroação | retroação fraca pequena [M] | caderno §152 |
| B8 | Lorentz no UV e isotropia | COMPATÍVEL [M] | `C5A_B8_PREREGISTRO_2026-10-02_1153-clau.md`, relatório `*_1200-clau` |
| B3 | birrefringência acumulada | COMPATÍVEL (canal circular) [M] | `C5A_B3_PREREGISTRO_2026-10-02_1545-clau.md`, relatório `*_1558-clau` |
| B10 | quantização; fase de Coulomb | FÓTON QUÂNTICO LIVRE OK; COMPACTA VIÁVEL [M] | `C5A_B10_PREREGISTRO_2026-10-02_1553-clau.md`, relatório `*_1621-clau` |
| B11-luz-luz | autointeração × PVLAS | COMPATÍVEL [M] | `C5A_B11_PREREGISTRO_2026-10-02_1824-clau.md`, relatório `*_1837-clau` |
| B12-faixa | faixa fixa de distâncias | FAIXA NEUTRA; pesos D sem calibração [M] | `C5A_B12_PREREGISTRO_2026-10-02_1907-clau.md`, relatório revisão 1 `*_2015-clau` |
| INVERSE-01/02 (fluxo par) | problema inverso; Morse | teto antigo aposentado; holdout de ħ negativo | consolidação do fluxo par |
| B11-Morse, B12-Morse (fluxo par) | faixa deformável no tempo | gauge preservado; fóton sobrevive [M] | relatórios do fluxo par |
| B14 (fluxo par) | ℓ_max × cauda distribuída | ℓ_max isolado descartado [M]; auditada | `C5A_B14_cauda_distribuicao_2026-10-02.zip` |

---

## Apêndice B — Números de referência

| Grandeza | Valor | Fonte |
|---|---|---|
| ξ (tremor, eixo, 20³) | 0,0163 [0,0161; 0,0164] | B8 |
| ξ médio (Poisson … mínimo 0,8a, 20³) | 0,0112 … 0,0056 | B12-faixa |
| teto canônico | √ξ·a_ρ ≲ 2,0×10⁻²⁸ m | B8, consolidação |
| E_QG,2 | > 6,9×10¹¹ GeV | LHAASO (Cao et al. 2024) |
| ordem de (E² − P²c²)/E² | 1,98 [1,96; 2,00] | B1 |
| impureza de helicidade (18³) | 1,1×10⁻⁴ (mediana) | B1 |
| anisotropia de c (26³) | 1,4×10⁻⁶ | B8 |
| giro de polarização (GRB 140206A, teto B8) | ~10⁻¹² rad | B3 |
| β_c (Delaunay; cúbica) | 0,64; 1,00 | B10 |
| β_EM = 1/(4πα) | 10,9 | [F] |
| Δκ (Poisson 20³); κ∥/κ⊥ | 0,319; 3,00 | B11-luz-luz, B12-faixa |
| \|Δn_rede\|/Δn_QED no teto | 3×10⁻⁵⁵ | B11-luz-luz |
| E₀/V | 17,5–18,9 ħc/a⁴ | B10 |
| constantes | CODATA 2018 | [F] |

**Referências externas:** Cao et al. 2024, PRL 133, 071501 (LHAASO, GRB 221009A); Götz et al. 2014, MNRAS 444, 2776
(GRB 140206A); Ejlli et al. 2020, Phys. Rep. 871, 1 (PVLAS); Arnold, Lippert, Neuhaus, Schilling, hep-lat/0011058
(QED compacta na rede); Gao, Jafferis, Wall 2017 (citado no Capítulo 1).

---

## Apêndice C — Glossário do capítulo

| Termo | Significado |
|---|---|
| HRF | Holographic Reconstruction Framework; nome guarda-chuva atual do programa |
| HRF-FM | Fields and Matter Reconstruction; ramo do HRF que herda principalmente a linha histórica C5A |
| HRF-ST | Spacetime Reconstruction; ramo separado para emergência/reconstrução de geometria e espaço-tempo |
| C5A | rótulo histórico preservado em fontes, bancadas e arquivos para rastreabilidade |
| GMF | Grau Microestrutural Fundamental; termo técnico do toy model fotônico herdado da C5A, sem equivalência ainda fixada com PGFE/HRF-PD |
| PGFE | termo reservado à ontologia pré-geométrica do HRF; sua relação formal com GMF ainda permanece aberta neste capítulo |
| q_n | estado local de um GMF |
| a_nm, U_nm = e^{ia_nm} | fase da ligação; conexão relacional entre vizinhos |
| C_f, H_f = e^{iC_f} | circulação e holonomia de um laço |
| energia de Wilson | Σ w_f (1 − cos C_f) |
| d₀, d₁ | gradiente e rotacional discretos (d₁d₀ = 0) |
| pesos W, D | Whitney; duais baricêntricos |
| a_ρ | escala de densidade, (V/N)^{1/3} |
| r_nm, P(r), r_tail | distância local, sua distribuição e a cauda superior |
| Δx_num | passo numérico, sem significado físico |
| ξ | coeficiente da correção quadrática ω/ck = 1 − ξ(ka_ρ)² |
| κ∥, κ⊥ | razão quártico/quadrático para sonda paralela e perpendicular a B₀ |
| β, β_c | acoplamento da rede compacta; valor da transição |
| fase de Coulomb | fase da conexão compacta em que existe fóton livre |
| 𝒜* | ação característica do substrato (hipótese) |
| helicidade h | projeção do spin na direção de propagação |
| OAM, ℓ | momento angular orbital |
| PHOTON-CLOSURE-E/F | fechamento do fóton efetivo / físico |
| D1, D2, D3 | espaço-tempo plano no setor do fóton; conexão compacta?; faixa de distâncias fixa no tempo |
| microgeometria (uso histórico C5A) | conectividade/deformação da malha usada nos toy models; não equivale à geometria emergente do HRF-ST |
