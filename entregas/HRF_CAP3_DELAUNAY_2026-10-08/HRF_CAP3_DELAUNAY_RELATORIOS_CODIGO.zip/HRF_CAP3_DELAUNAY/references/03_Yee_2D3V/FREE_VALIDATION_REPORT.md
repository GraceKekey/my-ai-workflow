# Validação livre Maxwell 2D3V [M]

Gate Maxwell: **PASS**.
Gate HRF-CAP2: **NOT_TESTED**.

34 casos completos; ambas as helicidades, quatro ângulos, PPW20/24/32. T=3.96; controle espacial dt=0.009, temporal independente dt=0.018/0.009/0.0045.

| Métrica [M] | Faixa observada | Limite prévio |
|---|---:|---:|
| Erro relativo de dispersão | 0.000633384–0.00397561 | 0.03 |
| Erro de velocidade do envelope vs referência contínua | 0.00251082–0.0118978 | 0.03 |
| Erro L2 de campo vs Maxwell contínuo | 0.0328405–0.11518 | 0.15 e queda com PPW |
| P/E (vácuo, c=1) | 0.94219–0.95157 | desvio de 1 ≤0.12 |
| Fração espectral longitudinal discreta | 3.11947e-31–1.25182e-30 | 1e-10 |
| Máxima deriva da energia física | 2.22045e-16–4.44089e-16 | 0.005 |

A dispersão angular do pacote explica P/E inferior a 1/c. A amplitude circular elétrica tem Stokes ±1 na base espectral definida, com Gauss discreto dentro da tolerância.
O controle de duas polarizações usa o símbolo do curl-curl Yee e os testes independentes da ação do stencil; o setor longitudinal tem autovalor zero e é excluído por Gauss. Não representa um terceiro modo propagante.

| Ângulo [M] | h | Erro L2 PPW20 | PPW24 | PPW32 |
|---:|---:|---:|---:|---:|
| 45 | +1 | 0.090792 | 0.061766 | 0.032841 |
| 45 | -1 | 0.090792 | 0.061766 | 0.032841 |
| 60 | +1 | 0.097584 | 0.066494 | 0.035511 |
| 60 | -1 | 0.097584 | 0.066494 | 0.035511 |
| 75 | +1 | 0.109701 | 0.074910 | 0.040234 |
| 75 | -1 | 0.109701 | 0.074910 | 0.040234 |
| 90 | +1 | 0.115180 | 0.078708 | 0.042355 |
| 90 | -1 | 0.115180 | 0.078708 | 0.042355 |

Controle temporal independente [M]: h=+1: razão=4.007263, h=-1: razão=4.007263.

Limites: banda do pacote, janela e malhas testadas; circularidade relativa ao K discreto, que converge ao k contínuo. A referência contínua evolui os mesmos campos iniciais amostrados. O gate não valida a formulação microscópica do HRF nem quantização.
O primeiro processamento falhou ao gravar o relatório por NameError; a integração não foi classificada como falha física. Todos os arquivos foram preservados, e os 34 casos foram repetidos com a correção sem alterar os critérios.

Evidências completas: FREE_GATE_RESULTS.json, operator_verification.json, results/free_*/ e logs/.
