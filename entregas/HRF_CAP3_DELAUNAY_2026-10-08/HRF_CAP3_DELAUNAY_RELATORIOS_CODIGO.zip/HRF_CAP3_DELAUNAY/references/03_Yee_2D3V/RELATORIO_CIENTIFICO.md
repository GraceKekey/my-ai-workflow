# HRF CAP3-2D3V-PHOTON-FLUX-01 — relatório científico

Gerado: 2026-10-08T14:51:20.431375-03:00. Modelo: `CAMPO_VETORIAL_2D3V_EXPLORATORIO`.

**Resposta física:** foi demonstrada propagação livre clássica com duas polarizações e circularidade, e medidos retenção de energia e transporte interno na cavidade durante a janela executada [M]. Não foi demonstrada uma onda fotônica HRF viajando e permanecendo confinada; não se certificou um modo quase-ligado nem identidade fotônica local [?].

## Escopo e gates

- `2D3V-MAXWELL-GATE`: **PASS** [M].
- `PHOTON-INJECTION GATE HRF-CAP2`: **NOT_TESTED** [?].
- Gate da bancada curta e controles: **FAIL** [M].
- Fase longa: **NOT_EXECUTED** [D].

Foram concluídos 68 casos nesta tentativa corrigida [M]. Os horários e comandos de cada caso estão em logs/. Os tempos solicitados são arredondados ao passo: o CSV registra o tempo efetivo, inclusive 30.006 no passo 0.018 e 29.997 no passo 0.009 [M].
Se um controle curto falhar, a fase longa não é executada: essa regra foi fixada antes das medições, conforme a condição do prompt de só avançar com controles satisfatórios. Os marcos não executados são explicitamente marcados em REQUESTED_MILESTONES_STATUS.csv; não foram preenchidos com extrapolações.

## Referências e contrato físico

Foram lidos as regras 2D3V de 2026-10-08, o protocolo de confinamento, o relatório e código escalar anteriores e duas versões do índice HRF. A busca adicional alcançou My-Scientific-Library, a estrutura do projeto HRF, Inbox/Physics e pastas C5A. O Capítulo 1 e referências ao Capítulo 2 foram localizados, mas o arquivo obrigatório Capítulo 2 v1.1 não foi localizado no Drive pesquisado. O índice atualizado na pasta 00-Project-Overview registra que o capítulo foi recuperado na Library do ChatGPT, em /Nova-Fisica-01/, ID libfile_230201963ef0819184bddffbe0f6c7bc, e que sua localização no Drive continua pendente. A cópia do índice em Physics permanece desatualizada. Esse registro confirma uma localização documental prévia, não uma leitura do capítulo nesta tarefa. A Library do ChatGPT não está exposta pelos conectores atuais.
Mesmo com acesso ao texto, aprovar a equivalência exigiria demonstrar a correspondência entre operadores, modos e simetrias. Nenhuma equivalência U(1)/Wilson ou quantização foi presumida [?]. Fontes e inventário da busca estão em references/ e provenance.json.

## Modelo e procedimento

[F] Maxwell sem fontes, com derivada z nula, D/B com três componentes, Gauss discreto preservado; energia u=(E.D+B.H)/2 e fluxo J=E×H. [H] epsilon_r=mu_r=1/c_local é a hipótese constitutiva de controle. Não houve força orbital ou trajetória prescrita [D].
A discretização Yee usa curls adjuntos e Verlet sincronizado. O absorvedor externo é uma dissipação curl-curl positiva que preserva Gauss. O fluxo de faces respeita a continuidade semidiscreta, e seu integral de saída/reentrada é acumulado a cada passo. A implementação e suas limitações estão em README.md; os testes independentes de adjunção, continuidade e kernel estão em operator_verification.json [M].
A injeção circular no setor transversal tem sigma longitudinal 0.7, transversal 0.35, k0=2pi, r0=0.75R e direção (-cos(theta),sin(theta)). R=4, caixa base=16, PPW20, dt=0.018 [D]. A frequência de referência local é 2pi*0.39 e não a frequência de uma onda no vácuo com mesma lambda [D/H].

Perfil histórico [D]: {"r_over_R": [0, 0.25, 0.45, 0.55, 0.65, 0.75, 0.85, 0.95, 1.05, 1.15, 1.25, 1.45, 1.6], "c": [0.03, 0.031, 0.015, 0.118, 0.224, 0.39, 0.465, 0.766, 0.876, 0.956, 0.983, 0.992, 0.995], "interpolation": "PCHIP; c=1 at r/R>=1.25; same clipping as supplied scalar solver"}.

## Validação livre

Os 34 casos livres passaram nos critérios previamente registrados [M]. O erro L2 relativo contra evolução Maxwell contínua diminui de PPW20 para PPW24 e PPW32 em todos os ângulos/helicidades; a razão temporal foi 4.007263, 4.007263 [M]. O relatório separado FREE_VALIDATION_REPORT.md contém tolerâncias e faixas, e o JSON guarda cada verificação.

## Retenção e balanço energético da cavidade

Todas as entradas das tabelas seguintes são medições [M]. E_initial=1; energia fora da cavidade continua na caixa. A energia absorvida é medida separadamente do resíduo numérico.

| Ângulo [M] | h | Tempo efetivo | F_rem | F_in | E_fora | E_absorvida | Resíduo global |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 45 | +1 | 30.006 | 0.792645 | 0.943302 | 0.047643 | 0.159716 | 3.83e-06 |
| 45 | -1 | 30.006 | 0.792645 | 0.943302 | 0.047643 | 0.159716 | 3.83e-06 |
| 60 | +1 | 30.006 | 0.856594 | 0.950342 | 0.044760 | 0.098638 | -8.04e-06 |
| 60 | -1 | 30.006 | 0.856594 | 0.950342 | 0.044760 | 0.098638 | -8.04e-06 |
| 75 | +1 | 30.006 | 0.892799 | 0.946818 | 0.050148 | 0.057036 | -1.77e-05 |
| 75 | -1 | 30.006 | 0.892799 | 0.946818 | 0.050148 | 0.057036 | -1.77e-05 |
| 90 | +1 | 30.006 | 0.901221 | 0.938981 | 0.058566 | 0.040200 | -1.32e-05 |
| 90 | -1 | 30.006 | 0.901221 | 0.938981 | 0.058566 | 0.040200 | -1.32e-05 |

F_rem=E_inside/E_initial mede a fração originalmente injetada que ainda está dentro. F_in=E_inside/E_box mede a distribuição da energia sobrevivente; F_in alto pode coexistir com perda de quase toda a energia inicial. ENERGY_BALANCES.csv guarda E_inside, E_outside, E_absorbed, os dois balanços e o fluxo integrado para cada caso [M].

| Ângulo [M] | h | Saída acumulada | Reentrada acumulada | Líquido | Máximo resíduo interno |
|---:|---:|---:|---:|---:|---:|
| 45 | +1 | 0.269827 | 0.083016 | 0.186811 | 0.00013 |
| 45 | -1 | 0.269827 | 0.083016 | 0.186811 | 0.00013 |
| 60 | +1 | 0.186347 | 0.050999 | 0.135348 | 8.9e-05 |
| 60 | -1 | 0.186347 | 0.050999 | 0.135348 | 8.9e-05 |
| 75 | +1 | 0.139107 | 0.034008 | 0.105100 | 6.35e-05 |
| 75 | -1 | 0.139107 | 0.034008 | 0.105100 | 6.35e-05 |
| 90 | +1 | 0.139376 | 0.041407 | 0.097970 | 5.05e-05 |
| 90 | -1 | 0.139376 | 0.041407 | 0.097970 | 5.05e-05 |

## Controles e decisão da fase longa

| Controle [M] | Métrica | Valores | Diferença avaliada | Limite prévio | Resultado |
|---|---|---|---:|---:|---|
| spatial h=1 | F_rem | 0.892935, 0.918666, 0.946302 | 0.053367 | 0.05 | FAIL |
| spatial transport h=1 | mean_speed_flux | 0.078094, 0.064259, 0.045904 | 0.412190 | 0.2 | FAIL |
| temporal h=1 | F_rem | 0.892799, 0.892935 | 0.000136 | 0.01 | PASS |
| box h=1 | F_rem | 0.892799, 0.885434 | 0.007365 | 0.05 | PASS |
| spatial h=-1 | F_rem | 0.892935, 0.918666, 0.946302 | 0.053367 | 0.05 | FAIL |
| spatial transport h=-1 | mean_speed_flux | 0.078094, 0.064259, 0.045904 | 0.412190 | 0.2 | FAIL |
| temporal h=-1 | F_rem | 0.892799, 0.892935 | 0.000136 | 0.01 | PASS |
| box h=-1 | F_rem | 0.892799, 0.885434 | 0.007365 | 0.05 | PASS |
| sponge strength | F_rem | 0.892799, 0.896893, 0.889107 | 0.007786 | 0.05 | PASS |

O controle espacial usa dt=0.009 fixo em PPW20/24/32; o temporal altera somente dt em PPW20. O transporte do controle é a média da integral |J_xy|/E_inside entre t≥10 e o fim. Caixa ampliada e intensidade do sponge têm controles separados. O meio uniforme c=1 e o meio uniforme c=0.39 foram executados nos quatro ângulos e nas duas helicidades [D/M].

| Ângulo [M] | h | F_rem cavidade | F_rem uniforme c=1 | F_rem uniforme c=0.39 |
|---:|---:|---:|---:|---:|
| 45 | +1 | 0.792645 | 0.000060 | 0.000157 |
| 45 | -1 | 0.792645 | 0.000060 | 0.000157 |
| 60 | +1 | 0.856594 | 0.000405 | 0.000877 |
| 60 | -1 | 0.856594 | 0.000405 | 0.000877 |
| 75 | +1 | 0.892799 | 0.001036 | 0.001768 |
| 75 | -1 | 0.892799 | 0.001036 | 0.001768 |
| 90 | +1 | 0.901221 | 0.001163 | 0.001501 |
| 90 | -1 | 0.901221 | 0.001163 | 0.001501 |

Falhas registradas [M]:
- spatial h=1: F_rem difference 0.0533675 exceeds 0.05
- spatial transport h=1: mean_speed_flux difference 0.41219 exceeds 0.2
- spatial h=-1: F_rem difference 0.0533675 exceeds 0.05
- spatial transport h=-1: mean_speed_flux difference 0.41219 exceeds 0.2

### Resolução do núcleo lento

A escala estimada lambda_local=c_local/c_injection tem mínimo 0.015/0.39≈0.03846. PPW20/24/32 fornecem apenas ≈0.77/0.92/1.23 pontos nessa escala [D]. O alerta local usa a frequência de injeção e não substitui análise espectral local. Na janela executada, a fração de energia na região com menos de 10 pontos por lambda estimada está nos CSV e na figura de controles [M]. Assim, não há certificação de convergência do campo no núcleo lento. Estabilidade/Gauss/balanço, por si, não demonstram exatidão espacial.
Resolver essa escala com dez pontos exigiria PPW≈260 no comprimento nominal, bem além de PPW32; essa conta é um requisito geométrico estimado, não um resultado de confinamento [D].

## Movimento, polarização e classificação

| Ângulo [M] | h | Transporte final | Fluxo radial com sinal | Fluxo tangencial com sinal | Stokes local médio | Cobertura válida | Fração sub-resolvida estimada |
|---:|---:|---:|---:|---:|---:|---:|---:|
| 45 | +1 | 0.074096 | 0.017568 | 0.003187 | 0.177623 | 0.997157 | 0.866956 |
| 45 | -1 | 0.074096 | 0.017568 | 0.003187 | -0.177623 | 0.997157 | 0.866956 |
| 60 | +1 | 0.078639 | 0.021780 | 0.003048 | 0.099362 | 0.999211 | 0.854755 |
| 60 | -1 | 0.078639 | 0.021780 | 0.003048 | -0.099362 | 0.999211 | 0.854755 |
| 75 | +1 | 0.081608 | 0.019322 | 0.002144 | -0.007695 | 0.997585 | 0.845595 |
| 75 | -1 | 0.081608 | 0.019322 | 0.002144 | 0.007695 | 0.997585 | 0.845595 |
| 90 | +1 | 0.083241 | 0.012949 | 0.001335 | -0.079018 | 0.995320 | 0.843523 |
| 90 | -1 | 0.083241 | 0.012949 | 0.001335 | 0.079018 | 0.995320 | 0.843523 |

Os indicadores locais usam E+i*dE/dt/omega_ref e uma base em torno da direção instantânea do Poynting: são proxies direcionais de banda estreita, não um gate fotônico local. Mistura de sentidos e interferência podem reduzir a média com sinal mesmo quando a circularidade absoluta é alta. O indicador longitudinal elétrico local não é a restrição de Gauss em D. Os mapas NPZ armazenam essas distinções [D/M].
O centro de energia e máximos são descritores de distribuição; não foram usados como trajetória de um fóton. Os mapas de u e setas de J mostram redistribuição e transporte [M], e não demonstram por si voltas coerentes ou confinamento duradouro.

| Classe | Status |
|---|---|
| A — onda viajante confinada | NÃO DEMONSTRADA: identidade local HRF e coerência confinada não certificadas [?] |
| B — ricochete/refração | Mapas compatíveis com desvio/redistribuição; um ricochete completo exige seguir frentes e mudança de direção, sem certificação nesta análise [?] |
| C — sloshing | Apenas flags de reversão de fluxo nos casos que atendem à regra; não equivalem a identificação fotônica [M/?] |
| D — circulação parcial | Flags heurísticas em summary.json conforme fluxo tangencial médio; não inferir uma órbita individual [M/?] |
| E — quase-estacionário | Depende de variabilidade e direcionalidade; não inferir confinamento a partir de uma imagem estática [M/?] |
| F — fuga/retenção transitória | Há saída e reentrada medidas; a duração da retenção só é conhecida na janela executada [M/?] |
| G — candidato quase-ligado | NÃO APROVADO: falta gate HRF-CAP2, identidade local e resolução/convergência completa [?] |

Os rótulos provisórios de movimento de cada caso estão nos summaries; não promovem candidatos a demonstrações.

## Comparação com o solver escalar

| Ângulo [M] | h | F_rem escalar T≈30 | F_rem vetorial T≈30 | Transporte escalar | Transporte vetorial |
|---:|---:|---:|---:|---:|---:|
| 45 | +1 | 0.735761 | 0.792645 | 0.069519 | 0.074096 |
| 45 | -1 | 0.735761 | 0.792645 | 0.069519 | 0.074096 |
| 60 | +1 | 0.818725 | 0.856594 | 0.077278 | 0.078639 |
| 60 | -1 | 0.818725 | 0.856594 | 0.077278 | 0.078639 |
| 75 | +1 | 0.871736 | 0.892799 | 0.082040 | 0.081608 |
| 75 | -1 | 0.871736 | 0.892799 | 0.082040 | 0.081608 |
| 90 | +1 | 0.888708 | 0.901221 | 0.085509 | 0.083241 |
| 90 | -1 | 0.888708 | 0.901221 | 0.085509 | 0.083241 |

O raio, perfil, larguras nominais, ponto inicial, ângulos e janela são comparáveis; o pacote vetorial transversal, o operador e o sponge são diferentes. Portanto, diferenças não isolam o efeito da polarização e não provam equivalência entre os modelos [D/?].
O experimento escalar anterior em T≈500 reteve aproximadamente 0.0767–0.0857 da energia inicial [M, fonte anterior]. Esses valores não são medições vetoriais e não podem preencher marcos vetoriais não executados. O escalar também apresentou sensibilidade de malha na bancada anterior [M].

## Resultados negativos, limites e próximos testes

Todos os resultados negativos foram preservados. A primeira tentativa livre teve um NameError na escrita do relatório: 28 casos falharam na etapa de relatório, e seis terminaram após a correção aplicada ao fim do lote. Essa mistura não foi usada para o gate científico final. O lote completo foi repetido, com critérios inalterados; a tentativa original, código, logs, mapas e estado estão em failed_attempt_01_report_NameError/ [D].
O problema de resolução local exige malha adaptativa/conforme, um método com erro espacial controlado ou uma bancada física replanejada e registrada antes da execução. Alterar o perfil para fazê-lo caber na malha mudaria a hipótese; não foi feito neste teste [D/?].
Para certificar um fóton HRF, obter o Capítulo 2 v1.1 e sua implementação e verificar operadores, modos, simetrias e o contrato de injeção/localidade. Para testar tempos longos de forma interpretável, primeiro aprovar controles de curto prazo e demonstrar resolução na região efetivamente ocupada. Variações de raio, largura e dois pacotes permanecem posteriores à bancada principal [?].
Não se conclui formação de elétron, spin 1/2, carga elétrica ou quantização. O resultado estabelecido é uma bancada intermediária de Maxwell clássico, com propagação livre validada e medições de retenção/fluxo na janela executada [M].

## Arquivos para auditoria

- Código: hrf_maxwell_2d3v.py, yee_kernels.cpp, scripts dos lotes e README.md.
- Critérios: config_preregistered.json e arquivos *_PREREGISTRATION.json.
- Gates: FREE_GATE_RESULTS.json, CAVITY_GATE_RESULTS.json, LONG_STAGE_STATUS.json.
- Dados: SUMMARY_ALL_CASES.csv/json, ENERGY_BALANCES.csv, comparison CSV e results/*/timeline.csv.
- Mapas: results/*/map_t_*.npz; PNG individuais e figuras agregadas na raiz.
- Proveniência: provenance.json, references/, logs/, MANIFEST_SHA256.json.
- Preservação: failed_attempt_01_report_NameError/ integral.
