# HRF CAP3 — Dossiê documental para a bancada 2D3V Delaunay

**Data de reunião:** 2026-10-08. Este pacote reúne cópias íntegras de fontes históricas e atuais, sem executar simulações novas. Os nomes originais dos documentos são preservados.

## Ordem de leitura

1. `01_Autoridade_HRF/`: Capítulo 2 v1.1, referência científica do modo fotônico livre, das conexões U(1), das holonomias, da energia de Wilson, dos pesos de Whitney e do operador `d1^T M2 d1`.
2. `02_Protocolos_CAP3/`: protocolo de confinamento 2D e regras 2D3V. Preservar PHOTON-INJECTION GATE, não exigir órbita, não identificar campo genérico com fóton.
3. `03_Yee_2D3V/`: relatório científico, validação livre, pré-registro e resultados de gates do controle em malha Yee.
4. `04_Historico_CAP3_Escalar/`: relatórios do modelo escalar anterior; comparação histórica, **não** validação fotônica.

## Estado do controle Yee, que NÃO deve ser transferido automaticamente à Delaunay

- `2D3V-MAXWELL-GATE = PASS [M]` **para o solver Yee livre**, não para a nova Delaunay.
- `PHOTON-INJECTION GATE HRF-CAP2 = NOT_TESTED [?]` na execução Yee anterior.
- `CAVITY_SHORT_GATE = FAIL [M]`: sensibilidade espacial (F_rem e transporte) excedeu os limiares pré-registrados.
- `T=150,300,500 = NOT_EXECUTED` para o solver Yee vetorial, respeitando o gate curto.
- O perfil histórico da cavidade atingiu c_local=0.015c; há indícios de sub-resolução do núcleo lento na malha uniforme. Preservar o perfil e testar convergência da nova discretização.
- A Delaunay deve construir ambos os setores transversais a partir de uma redução 2D consistente da conexão 3D; `a_z` não pode ser adicionado como escalar material arbitrário. Priorizar pesos Whitney e identidade `d1*d0=0`.

## Fonte dos relatórios Yee e artefatos complementares

Pasta oficial da execução: https://drive.google.com/drive/folders/1BWeTLfVVAF4nJgL8vcfZC2Y6TS4UA-Sq

ZIP original com código, tabelas e relatórios (aprox. 17 MB; não duplicado neste dossiê):
https://drive.google.com/file/d/1-MPSE2a3JjtoMgI3MrYbFNnZrMtpinfD/view

## Controle de integridade

`MANIFEST_SHA256.json` registra as assinaturas SHA256 dos documentos incorporados. Os documentos-fonte não foram reescritos.
