# HRF-FM — CAP3-2D-LONG-01
## Evolução longa do modo fotônico na cavidade 2D ampliada

**Data:** 8 de outubro de 2026  
**Status:** toy model cinemático 2D [M].  
**Cavidade:** R = 4 λ; referência λ = 2,426×10^-12 m (~511 keV).  
**Tempo:** T = 150 λ/c, cinco vezes a janela anterior.

## Objetivo
Determinar se o campo que permanecia em torno de r ≈ 2 λ estava parado ou continuava se movimentando.

## Resultado
Foram prolongados os casos 45°, 60°, 75° e 90°. Nenhum lóbulo rastreado cruzou a parede R=4 λ até T=150.

O padrão dominante não é uma órbita unidirecional. Após uma fase inicial de migração de r≈3λ para r≈2λ, o lóbulo de energia continua se deslocando principalmente como um movimento de vai-e-vem angular sobre uma faixa interna, acompanhado de pequenas oscilações radiais.

- 45°: r_final=2,026λ; variação angular acumulada ≈168°, líquida ≈11°.
- 60°: r_final=2,048λ; variação angular acumulada ≈170°, líquida ≈15°.
- 75°: r_final=2,048λ; variação angular acumulada ≈110°, líquida ≈15°.
- 90°: r_final=2,046λ; variação angular acumulada ≈151°, líquida ≈17°.

A diferença entre o ângulo acumulado e o ângulo líquido mostra que o lóbulo não gira continuamente numa direção: ele avança, recua e muda de direção no interior.

As oscilações radiais tornam-se pequenas depois de ~30 λ/c. Entre T=120 e 150, o raio fica aproximadamente entre 2,0 e 2,07 λ nos quatro casos.

## Interpretação
[M] O campo não fica estático. A estrutura temporal continua oscilando e o lóbulo de energia rastreado apresenta movimento interno recorrente.

[M] O movimento observado é melhor descrito como **vai-e-vem angular e radial numa região anular interna**, não como órbita circular.

[?] A bancada não demonstra ainda que um mesmo pacote fotônico coerente individual percorre continuamente essa trajetória. Com a evolução, o campo se redistribui em vários lóbulos e o rastreador segue o lóbulo local dominante. É necessário medir fluxo de energia e identidade fotônica local para distinguir propagação de pacote, interferência e padrão quase-estacionário.

## Cautela energética
A energia total remanescente na caixa ao final é ~0,32–0,39 da inicial, porque radiação emitida para fora alcança a região absorvente. Porém ~96% da energia que ainda permanece na caixa está dentro de R<4λ no instante final. Portanto a retenção interna do remanescente é forte, mas não é conservação integral de toda a energia inicial.

## Classificação
**RETENÇÃO CURVA / REDISTRIBUIÇÃO INTERNA [M]**  
**ÓRBITA UNIDIRECIONAL:** não observada.  
**CAMPO ESTÁTICO:** não observado.  
**MOVIMENTO INTERNO RECORRENTE:** observado no proxy do lóbulo dominante [M].
