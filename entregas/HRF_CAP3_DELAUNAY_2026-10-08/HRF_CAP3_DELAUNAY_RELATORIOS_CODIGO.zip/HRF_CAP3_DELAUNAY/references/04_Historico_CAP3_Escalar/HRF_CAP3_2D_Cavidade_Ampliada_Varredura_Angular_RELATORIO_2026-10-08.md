# HRF-FM — CAP3-2D-LARGE-01
## Varredura angular 2D em cavidade ampliada

**Data:** 8 de outubro de 2026  
**Framework:** Holographic Reconstruction Framework (HRF)  
**Status:** toy model reduzido 2D [M]; não é uma bancada 3D de fechamento fotônico.

## 1. Pergunta
A cavidade foi deliberadamente ampliada e o problema espacial reduzido a 2D, no espírito do “carrinho andando num campo de golfe”. O objetivo foi observar como o envelope de duas zonas fotônicas simétricas se move para direções iniciais de 45° a 90°, sem exigir órbita.

## 2. Escala e redução
- referência: λγ = 2.4263e-12 m (~511 keV);
- raio da cavidade: R = 4 λγ = 9.705e-12 m;
- diâmetro: 8 λγ = 1.941e-11 m;
- em relação ao antigo arranjo λ≈2πR, o raio relativo à mesma λ foi aumentado por fator 8π≈25.13;
- resolução principal: 20 pontos/λ; controle de resolução: 24 pontos/λ para 45°, 70° e 90°.

A entrada usa duas componentes em quadratura do modo circular, mas a dinâmica espacial é uma redução 2D do transporte do envelope. Portanto esta bancada não revalida helicidade/quantização após a curvatura.

## 3. Controle livre
O controle uniforme permaneceu essencialmente retilíneo (straightness≈1). A velocidade medida do rastreador foi 0.944 em unidades onde c=1, mostrando ~5.6% de erro/dispersão efetiva do redutor 2D. Por isso os números de velocidade não devem ser usados como teste de Lorentz; a geometria das trajetórias é o diagnóstico principal.

Sem cavidade, todos os ângulos saíram do círculo R=4λ: o primeiro tempo de saída variou de 5.94 (45°) a 3.06 (90°).

## 4. Resultado principal
Na cavidade ampliada, **nenhum dos dez ângulos fez o lóbulo principal sair da cavidade durante T=30 λ/c**. Em vez de seguir a corda retilínea até a parede oposta, o lóbulo foi curvado/redistribuído para uma faixa interna próxima de R/2.

| α | r_min/λ | r_final/λ | straightness | E dentro ao final / E0 | saída? |
|---:|---:|---:|---:|---:|:---:|
| 45° | 1.981 | 2.142 | 0.409 | 73.6% | não |
| 50° | 1.973 | 2.145 | 0.382 | 76.7% | não |
| 55° | 1.970 | 2.148 | 0.371 | 79.5% | não |
| 60° | 1.969 | 2.012 | 0.542 | 82.0% | não |
| 65° | 1.967 | 2.030 | 0.557 | 84.1% | não |
| 70° | 1.967 | 2.043 | 0.569 | 85.9% | não |
| 75° | 1.967 | 2.060 | 0.584 | 87.3% | não |
| 80° | 1.969 | 2.069 | 0.600 | 88.3% | não |
| 85° | 1.974 | 2.076 | 0.581 | 88.9% | não |
| 90° | 1.986 | 2.084 | 0.498 | 89.0% | não |

Os mínimos radiais ficaram extraordinariamente próximos entre si: ~1.967–1.986 λ, isto é, cerca de 0.49–0.50 R. Aos T=30, o lóbulo principal terminou em ~2.01–2.15 λ (~0.50–0.54 R).

## 5. Dependência angular
O ângulo ainda importa principalmente na **fração total de energia retida**. Medida em relação à energia inicial, a energia ainda dentro de R ao final cresceu de ~73.6% em 45° para ~89.0% em 90°. Portanto, nesta cavidade grande, direções mais tangenciais retêm mais energia, mas não produzem uma órbita circular simples.

O lóbulo rastreado carregava apenas ~32–39% da energia inicial ao final, dependendo do ângulo. Assim, o estado não é um “carrinho pontual”: parte importante da onda se redistribui difusamente pelo interior. A leitura correta é `RETENÇÃO CURVA / REDISTRIBUIÇÃO INTERNA [M]`, não órbita.

## 6. Comparação com a cavidade menor
Na varredura anterior, com cavidade pequena em relação a λ, as trajetórias eram quase cordas retas e os casos próximos do tangencial saíam cedo. Ao tornar R=4λ, a onda passa a resolver espacialmente o gradiente da cavidade: a trajetória do lóbulo curva e migra para uma faixa interna próxima de R/2. Isso é uma mudança qualitativa do toy model [M].

## 7. Controle de resolução
| α | r(T=20), 20 pt/λ | r(T=20), 24 pt/λ | f_in 20 pt/λ | f_in 24 pt/λ |
|---:|---:|---:|---:|---:|
| 45° | 2.046 | 2.008 | 79.0% | 83.4% |
| 70° | 1.974 | 1.959 | 90.6% | 93.7% |
| 90° | 2.078 | 2.007 | 96.6% | 98.2% |

A posição radial em T=20 mudou apenas ~0.8–3.4% nesses controles, e a retenção permaneceu qualitativamente igual. O rótulo exato de “curvatura” versus “retenção curva” em 90° depende do limiar descritivo, mas não a conclusão física da bancada: o pacote não faz a travessia reta do controle uniforme.

## 8. Interpretação
**[M]** A ampliação da cavidade produz uma região interna de guiamento/redistribuição que não aparecia claramente na cavidade pequena. O resultado mais robusto é a convergência dos lóbulos principais para uma faixa radial ~R/2, com forte retenção de energia.

**[?]** Ainda não sabemos se essa faixa corresponde a um modo ligado verdadeiro, a refração/atraso em um perfil radial de velocidade, ou a uma estrutura transitória de interferência. A bancada 2D não decide isso.

**[D]** Não chamar o padrão de órbita nem de elétron. Não promover o raio ~R/2 a escala física universal. Ele é resultado deste perfil ampliado e desta redução 2D.

## 9. Próximo teste sugerido
Manter a cavidade 2D grande e repetir com diferentes razões R/λ (por exemplo 2, 3, 4, 5, 6) para verificar se a faixa ~R/2 é uma propriedade do perfil adimensional ou se existe uma razão R/λ selecionada. Em paralelo, acompanhar mapas de energia para separar lóbulo coerente de energia difusa.

---
**Classificação:** resultado numérico de toy model [M], sem validação empírica.