# HRF CAP3 Delaunay — entrega autocontida

Esta entrega inclui fontes, critérios, logs, resultados novos, relatórios,
figuras e todas as referências que estavam presentes no dossiê recebido.
Nenhum repositório ou download do Drive é necessário para consultar os resultados.

Leia primeiro RELATORIO_CIENTIFICO_DELAUNAY.md, STATUS.md e results/GATES_FINAL.json.
Um resultado negativo de gate impede as fases que dependem dele; NOT_EXECUTED
não significa PASS, FAIL físico de confinamento nem resultado extrapolado.

## Organização

- src/: implementação nova Delaunay/Whitney e scripts de avaliação/relatório.
- operator_preregistration.json e wave_preregistration.json: critérios originais.
- results/: controles estruturais, tentativas livres, tempo, dispersão e borda.
- figures/: mapas e comparações produzidos a partir das medições novas.
- OPERATOR_DERIVATION.md: redução 3D produto e condições de gauge.
- references_v2/: documentos e pacote histórico Yee fornecidos, preservados.
- references/: dossiê anterior, preservado para rastreabilidade.
- MANIFEST_SHA256_DELIVERY.json: hashes desta entrega, separado dos manifestos históricos.

Os manifestos históricos Yee referenciam410 NPZ omitidos no ZIP compacto de
origem. results/dossier_v2_audit.json lista essas ausências. Elas não são
arquivos Delaunay perdidos e não são preenchidas com dados inventados.

## Leitura de campos novos

free_ppw*_terminal_maps.npz guarda E e B complexos nos três pontos de quadratura
por triângulo, com quatro colunas correspondentes aos ângulos45/60/75/90.
O setor vertical ainda está em fase igual nesses arquivos: para h=+1, rotacionar
E_z e B_x/B_y por +i; para h=-1, por -i. Energia e fluxo XY não dependem desse
sinal. A precisão dos campos evoluídos é float64; os mapas derivados são complex64.
free_density_flux_terminal.npz já contém os diagnósticos de sinal analítico
para h=+1, normalizados para energia total1. Não são dados de cavidade.

## Reproduzir sem sobrescrever tentativas

Requer Python3.12 em Linux e as versões de requirements.txt. São dependências
de runtime, não arquivos buscados em um repositório. A preparação habitual é:

```sh
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python src/reproduce.py --output ./reexecucao_nova
```

O destino precisa não existir. O programa copia as fontes, critérios e referências
para o novo diretório e executa ali, mantendo todas as tentativas desta entrega.
Ele retorna2 quando a execução termina mas o gate científico é FAIL; erros de
programa preservam seus logs e retornam o status do comando que falhou.
O código recusa sobrescrever resultados existentes.

## Limites

Esta implementação cobre a etapa estrutural e a onda livre com controles.
Não contém uma implementação validada de cavidade/refinamento adaptativo,
pois a etapa livre desta tentativa não foi aprovada. As fases posteriores
permanecem não executadas; a entrega não deve ser apresentada como fechamento
positivo de confinamento. Não há conclusão de formação de elétron ou de fóton
físico individual. A figura V2 foi consultada na conversa; o arquivo original
da figura não foi disponibilizado como anexo binário para inclusão no ZIP.
