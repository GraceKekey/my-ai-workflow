# PROMPT — HRF CAP3-2D3V-DELAUNAY-01
## Onda fotônica relacional em malha Voronoi–Delaunay

**Projeto:** Holographic Reconstruction Framework (HRF)  
**Ramo:** HRF-FM — Fields and Matter Reconstruction  
**Status:** nova bancada de pesquisa [D/H]

### 1. Objetivo

Construir e testar uma onda vetorial 2D3V sobre uma **malha irregular Voronoi–Delaunay**, preservando tanto quanto possível a estrutura fotônica do Capítulo 2 do HRF.

A pergunta física é:

**Uma onda com as duas polarizações transversais do modo fotônico do Capítulo 2 pode permanecer dinamicamente confinada numa cavidade, continuando a transportar energia internamente, sem exigir uma órbita circular?**

Este teste é complementar à bancada CAP3-2D3V baseada em malha Yee. Não substituir nem sobrescrever os resultados anteriores.

### 2. Referências obrigatórias

Consultar primeiro os documentos do Projeto HRF:

- `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_1_PT_2026-10-05`
- `HRF_CAP3_2D3V_Regras_Modo_Fotonico_Cap02_v0_1_PT_2026-10-08.md`
- `HRF_CAP3_2D_FLUX_01_Protocolo_Confinamento_Dinamico_v0_1_PT_2026-10-08.md`
- `RELATORIO_CIENTIFICO.md` e `FREE_VALIDATION_REPORT.md` da bancada CAP3-2D3V anterior.

Utilizar também a figura **HRF Visual V2 — O tapete de GMFs e o campo da espuma**, que apresenta células de Voronoi, ligações Delaunay, fases nas ligações e um campo Z nos nós.

O Capítulo 2 prevalece sobre interpretações sugeridas apenas pela ilustração. Preservar a proveniência das nomenclaturas históricas.

### 3. Estrutura da malha

Construir uma triangulação Delaunay irregular 2D e sua estrutura dual de Voronoi.

Utilizar:

- Nós para os sistemas/subsistemas físicos representados operacionalmente.
- Arestas orientadas para os graus de liberdade das conexões.
- Faces triangulares orientadas para as holonomias.
- Matrizes de incidência discretas e pesos geométricos consistentes.
- Malha inicialmente congelada, sem retroação ou mudança de conectividade.

Não presumir que a irregularidade da malha represente, por si só, a emergência da geometria física.

### 4. Dois setores do campo — 2D3V

A evolução espacial terá duas coordenadas, mas deverá preservar as duas polarizações transversais necessárias para ondas com vetor de propagação no plano.

**Setor A — Conexões no plano**

Utilizar fases próprias nas arestas orientadas:

\[
U_{nm}=\exp(i a_{nm})
\]

Construir os laços:

\[
C=d_1a
\]

e preservar o operador do Capítulo 2:

\[
M_1\ddot a=-d_1^{T}M_2d_1a.
\]

Começar pelo regime linearizado de campo fraco, sem descartar a formulação compacta de Wilson. A versão não linear poderá ser testada separadamente.

**Setor B — Componente fora do plano**

Representar \(a_z\) por graus de liberdade apropriados da conexão tridimensional reduzida, de modo que \(\partial_z=0\).

É admissível armazenar numericamente \(a_z\) nos vértices, mas seu significado deve ser o de uma componente reduzida da conexão, e não o de um novo estado escalar material independente dos nós.

Derivar seu operador e seus pesos a partir de uma redução consistente das formas discretas 3D, por exemplo com uma malha extrudada e invariância em z.

**Não acrescentar simplesmente um laplaciano escalar arbitrário como segunda polarização.**

Demonstrar que os dois setores representam os graus de liberdade transversais esperados e que não surge uma terceira polarização longitudinal física.

### 5. Gauge e pesos geométricos

Verificar explicitamente:

\[
d_1d_0=0.
\]

A transformação de gauge nas conexões do plano deve deixar invariantes as observáveis físicas.

O tratamento de \(a_z\) deve respeitar a redução tridimensional da transformação de gauge.

Priorizar massas e pesos de Whitney consistentes, conforme a referência do Capítulo 2. Não assumir que pesos duais baricêntricos oferecem a mesma velocidade de propagação sem demonstração.

Realizar testes de:

- Orientação e incidência dos triângulos.
- Identidades discretas de gauge.
- Positividade da energia.
- Espectro do operador.
- Ausência de longitudinal físico propagante.
- Estabilidade e convergência sob refinamento.

A construção deve ser revisada matematicamente antes da simulação.

### 6. Fase A — Validação da onda livre

Antes de introduzir a cavidade, construir pacotes com:

- Propagação no plano XY.
- Duas polarizações transversais.
- Estados de helicidade \(h=+1\) e \(h=-1\).
- Envelope localizado.
- Direções iniciais 45°, 60°, 75° e 90°.

Verificar:

1. Duas polarizações físicas, sem modo longitudinal propagante.
2. Restrições de gauge e Gauss.
3. Hel icidade relativa ao vetor de propagação.
4. Dispersão \(\omega\simeq c|k|\).
5. Propagação correta do envelope.
6. Relação energia–momento no regime aplicável.
7. Conservação energética e convergência espacial.
8. Comportamento comparável ao Capítulo 2 e ao controle livre Yee.

Aplicar o **PHOTON-INJECTION GATE**.

Distinguir `GATE_DELAUNAY_FREE`, `GATE_MAXWELL_EQUIVALENCE` e `GATE_HRF_CAP2`.

Aprovar um deles não aprova automaticamente os demais.

Caso não seja possível demonstrar a correspondência entre operadores, modos e simetrias do Capítulo 2, registrar `HRF_CAP2: PENDING/NOT_TESTED`.

### 7. Fase B — Cavidade

Somente depois de superar os controles livres, introduzir a cavidade:

- Raio inicial \(R=4\lambda\).
- Posição de injeção \(r_0=0,75R\).
- Ângulos 45°, 60°, 75° e 90°.
- Uma zona fotônica inicial.
- Ambas as helicidades.
- Primeira janela \(T=30\lambda/c\).

Preservar o perfil radial histórico, inclusive o mínimo \(c_{\rm local}=0,015c\).

A modificação dos pesos constitutivos para representar a cavidade deve ser explicitamente derivada ou identificada como hipótese [H]. Não presumir que o perfil escalar anterior seja automaticamente equivalente a uma mudança da conectividade Delaunay.

Não impor movimento orbital, força centrípeta ou trajetória predeterminada.

### 8. Refinamento espacial

O CAP3-2D3V anterior apresentou falha de convergência espacial na cavidade.

Portanto:

**Priorizar refinamento local da malha Delaunay nas regiões fisicamente sub-resolvidas.**

Requisitos:

- Preservar a geometria e o perfil físico da cavidade.
- Estimar comprimentos de onda locais por fase/espectro, sempre que possível.
- Refinar os elementos com insuficiente resolução local.
- Reconstruir operadores, orientações e matrizes de massa após o refinamento.
- Preservar gauge e continuidade energética nas interfaces.
- Comparar no mínimo três resoluções efetivas, com critérios pré-registrados.
- Controlar separadamente erro temporal, erro espacial e efeitos de contorno.

Não considerar a malha convergida apenas porque Gauss ou o balanço global de energia apresentam resíduos pequenos.

Se o refinamento adaptativo comprometer a estrutura gauge, avaliar uma discretização FEEC/Whitney alternativa e explicar a decisão.

Não modificar artificialmente o núcleo lento para obter aprovação.

### 9. Fase C — Energia e movimento interno

Reconstruir os campos físicos a partir das variáveis discretas, quando matematicamente justificado.

Calcular:

\[
u=\frac12(\mathbf E\cdot\mathbf D+\mathbf B\cdot\mathbf H)
\]

\[
\mathbf J_E=\mathbf E\times\mathbf H.
\]

Verificar também a continuidade energética na própria formulação discreta, sem assumir que o Poynting interpolado seja automaticamente o fluxo exato entre elementos.

Registrar:

- Energia inicial, interna e externa.
- Energia absorvida pela borda.
- Resíduo do balanço global.
- \(F_{\rm in}\) e \(F_{\rm rem}\).
- Fluxo radial e tangencial.
- Energia que sai e retorna através de \(r=R\).
- Transporte líquido e magnitude total do transporte.
- Evolução local da polarização/helicidade.
- Mapas de densidade e vetores de fluxo.

Distinguir onda viajante, ricochete/refração, sloshing, circulação parcial, quase-estacionariedade e fuga.

Não identificar máximos móveis de interferência com a trajetória de um fóton individual.

### 10. Fase D — Comparação e testes longos

Comparar os resultados do modelo Delaunay com a bancada Yee anterior, documentando diferenças de operadores, condições iniciais e constitutivas.

Apenas após aprovação dos critérios de convergência e conservação, avançar para:

\[
T=150,\ 300,\ 500\lambda/c.
\]

Não transportar números do solver Yee ou escalar para marcos não executados no solver Delaunay.

Se os controles falharem, interromper a fase longa e preservar os resultados negativos.

### 11. Entregáveis

Produzir código completo, configuração pré-registrada, verificações do operador, relatório dos gates, CSV/JSON de diagnósticos, mapas de fluxo/densidade, comparação com Yee, relatório científico e arquivos de proveniência com hashes.

Preservar todas as tentativas malsucedidas.

Classificar resultados numéricos como [M], hipóteses como [H], decisões como [D] e questões abertas como [?].

Salvar cópias no Google Drive do projeto sem sobrescrever arquivos existentes.

### 12. Pergunta final

Responder explicitamente:

**A estrutura Voronoi–Delaunay com conexões orientadas e componente \(a_z\) reproduz as duas polarizações fotônicas previstas pelo Capítulo 2? E, caso reproduza, essa onda apresenta confinamento dinâmico com transporte interno de energia que sobreviva aos controles de resolução e tempo?**

Não concluir formação de elétron ou fóton físico individual a partir desta bancada.