"""Reproduce all executed stages in a new directory, preserving old attempts."""
import argparse
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]

if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',required=True)
    target=Path(parser.parse_args().output).resolve()
    if target.exists():raise FileExistsError('Destination must not exist')
    if target.is_relative_to(ROOT/'src') or ROOT.is_relative_to(target):
        raise ValueError('Choose a distinct output directory')
    target.mkdir(parents=True)
    shutil.copytree(ROOT/'src',target/'src',ignore=shutil.ignore_patterns('__pycache__'))
    for name in ('operator_preregistration.json','wave_preregistration.json','requirements.txt','OPERATOR_DERIVATION.md','LEIA_PRIMEIRO_ENTREGA.md'):
        shutil.copy2(ROOT/name,target/name)
    shutil.copytree(ROOT/'references_v2',target/'references_v2')
    shutil.copytree(ROOT/'references',target/'references')
    (target/'results').mkdir()
    shutil.copy2(ROOT/'results'/'dossier_v2_audit.json',target/'results'/'dossier_v2_audit.json')
    environment=os.environ.copy()
    environment.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLBACKEND='Agg',MPLCONFIGDIR=str(target/'.matplotlib-cache'))
    for name in ('verify_operators.py','free_benchmark.py','time_controls.py','plane_wave_controls.py','dispersion_controls.py','boundary_control.py','time_failure_diagnosis.py','evaluate_free.py','resource_plan.py','build_report.py'):
        with (target/'results'/f'rerun_{name}.log').open('w') as log:
            result=subprocess.run([sys.executable,'-u',str(target/'src'/name)],cwd=target,env=environment,stdout=log,stderr=subprocess.STDOUT)
        print(name,'exit',result.returncode,flush=True)
        if result.returncode:raise SystemExit(result.returncode)
    gate=json.loads((target/'results/GATES_FINAL.json').read_text())
    print('Completed executed stages. Scientific gate:',gate['GATE_DELAUNAY_FREE'])
    raise SystemExit(2 if gate['GATE_DELAUNAY_FREE']=='FAIL' else 0)
