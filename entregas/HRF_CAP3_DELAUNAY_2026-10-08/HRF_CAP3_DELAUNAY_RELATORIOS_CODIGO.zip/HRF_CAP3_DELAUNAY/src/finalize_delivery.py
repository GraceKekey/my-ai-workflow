"""Package present inputs and generated results with independently checked hashes."""
import hashlib
import json
from pathlib import Path
import zipfile
from datetime import datetime
from zoneinfo import ZoneInfo
from free_benchmark import ROOT,write


def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda:f.read(1024*1024),b''): h.update(chunk)
    return h.hexdigest()


if __name__=='__main__':
    gates=json.loads((ROOT/'results/GATES_FINAL.json').read_text())
    failed=[]
    if gates['failed_cases']:failed.append('original box12 exterior-margin control')
    if not gates['independent_temporal_control']['passed']:failed.append('independent full-field temporal order ratio')
    if not gates['dispersion_control']['passed']:failed.append('time-domain packet frequency probes')
    gates['failed_required_controls']=failed
    write(ROOT/'results/GATES_FINAL.json',gates)
    prov=json.loads((ROOT/'PROVENANCE.json').read_text())
    prov['delivery_finalized']=datetime.now(ZoneInfo('America/Sao_Paulo')).isoformat()
    prov['code_and_configuration_hashes']={str(p.relative_to(ROOT)):digest(p) for p in sorted(list((ROOT/'src').glob('*.py'))+list(ROOT.glob('*preregistration.json')))}
    write(ROOT/'PROVENANCE.json',prov)
    manifest_path=ROOT/'MANIFEST_SHA256_DELIVERY.json'
    excluded={'.matplotlib-cache','.cache','__pycache__'}
    files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and p!=manifest_path and not any(s in excluded for s in p.relative_to(ROOT).parts)]
    entries=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':digest(p)} for p in files]
    write(manifest_path,{'scope':'All present files in this delivery except this manifest; cache files omitted. Historical manifests can list files absent from the supplied compact source package; see dossier_v2_audit.json.','files':entries})
    output=ROOT.parent/'HRF_CAP3_DELAUNAY_RESULTADOS_AUTOCONTIDOS_2026-10-08.zip'
    if output.exists():raise FileExistsError(output)
    with zipfile.ZipFile(output,'w',allowZip64=True) as z:
        for p in files+[manifest_path]:
            method=zipfile.ZIP_STORED if p.suffix in ('.npz','.png','.zip') else zipfile.ZIP_DEFLATED
            z.write(p,'HRF_CAP3_DELAUNAY/'+str(p.relative_to(ROOT)),compress_type=method)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        for entry in entries:
            archive_name='HRF_CAP3_DELAUNAY/'+entry['path']
            h=hashlib.sha256()
            with z.open(archive_name) as f:
                for chunk in iter(lambda:f.read(1024*1024),b''):h.update(chunk)
            assert h.hexdigest()==entry['sha256'],archive_name
        for name in ('RELATORIO_CIENTIFICO_DELAUNAY.md','LEIA_PRIMEIRO_ENTREGA.md','results/GATES_FINAL.json','src/reproduce.py'):
            assert 'HRF_CAP3_DELAUNAY/'+name in z.namelist()
    print(json.dumps({'file':str(output),'bytes':output.stat().st_size,'files':len(files)+1,'sha256':digest(output),'CRC_and_all_delivery_hashes_verified':True},indent=2),flush=True)
