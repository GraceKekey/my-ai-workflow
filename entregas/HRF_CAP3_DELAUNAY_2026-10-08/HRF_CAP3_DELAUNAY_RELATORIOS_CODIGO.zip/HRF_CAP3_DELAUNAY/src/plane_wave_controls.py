"""Whitney Rayleigh quotient consistency for both transverse plane-wave sectors.

This is a weak-operator consistency check, not a time-domain dispersion curve.
"""
import json
import numpy as np
from free_benchmark import mesh,write,ROOT


def measure(m,angle):
    theta=np.radians(angle)
    k=2*np.pi*np.array([-np.cos(theta),np.sin(theta)])
    pol=np.array([-k[1],k[0]])/np.linalg.norm(k)
    p=m['p']; edge=m['edges']; delta=p[edge[:,1]]-p[edge[:,0]]
    mid=(p[edge[:,1]]+p[edge[:,0]])/2
    kd=delta@k
    a=(delta@pol)*np.exp(1j*(mid@k))*np.sinc(kd/(2*np.pi))
    z=np.exp(1j*(p@k))
    wa=np.sqrt(np.real(np.vdot(a,m['ka']@a)/np.vdot(a,m['m1']@a)))
    wz=np.sqrt(np.real(np.vdot(z,m['kz']@z)/np.vdot(z,m['m0']@z)))
    return {'angle':angle,'omega_A_Rayleigh':float(wa),'omega_B_Rayleigh':float(wz),
            'relative_error_A':float(abs(wa/(2*np.pi)-1)),
            'relative_error_B':float(abs(wz/(2*np.pi)-1)),
            'relative_sector_split':float(abs(wa-wz)/(2*np.pi)),
            'note':'natural-boundary plane wave is not an exact global eigenmode; Rayleigh consistency only'}


if __name__=='__main__':
    cfg=json.loads((ROOT/'wave_preregistration.json').read_text())
    out=ROOT/'results'/'plane_wave_controls.json'
    if out.exists(): raise FileExistsError(out)
    runs=[]
    for ppw in cfg['ppw']:
        m=mesh(ppw,cfg['box'],cfg['seed'])
        runs.append({'ppw':ppw,'cases':[measure(m,a) for a in cfg['angles']]})
        print('DONE',ppw,flush=True)
    write(out,{'runs':runs,'classification':'weak consistency, not full dispersion gate'})
