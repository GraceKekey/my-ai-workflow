"""Diagnose the failed exterior-margin test without changing the original gate."""
import json
from free_benchmark import ROOT,run,write

if __name__=='__main__':
    cfg=json.loads((ROOT/'wave_preregistration.json').read_text())
    cfg.update(box=16.0)
    cfg['purpose']='Independent larger-box diagnosis; does not replace or relax original box12 acceptance'
    out=ROOT/'results'/'boundary_box16'
    out.mkdir(exist_ok=False)
    write(out/'preregistration_copy.json',cfg)
    run(20,cfg,out)
