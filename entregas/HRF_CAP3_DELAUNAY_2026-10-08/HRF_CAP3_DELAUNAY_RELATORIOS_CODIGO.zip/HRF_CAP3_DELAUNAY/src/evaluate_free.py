"""Evaluate the preregistered free wave attempt; never borrow Yee results."""
import json
from pathlib import Path
import numpy as np
from scipy.spatial import Delaunay
from free_benchmark import Reference, write

ROOT=Path(__file__).resolve().parents[1]


def spectral_helicity(points,faces,values,box,angles,n=512):
    # E is sampled at three exact degree-two triangle quadrature points.
    # Whitney E is affine, so recover its vertex values without smoothing.
    qb=np.array([[2/3,1/6,1/6],[1/6,2/3,1/6],[1/6,1/6,2/3]])
    vertex_values=np.einsum('iq,fqdh->fidh',np.linalg.inv(qb),values)
    triangulation=Delaunay(points)
    ax=np.arange(n)*box/n-box/2
    x,y=np.meshgrid(ax,ax)
    sample=np.column_stack((x.ravel(),y.ravel()))
    ti=triangulation.find_simplex(sample)
    assert np.all(ti>=0)
    # Rebuilt Delaunay has same deterministic simplex order for these points;
    # map by sorted vertex triples instead of assuming the order.
    mapping={tuple(sorted(f)):i for i,f in enumerate(faces)}
    source=np.array([mapping[tuple(sorted(f))] for f in triangulation.simplices])
    si=source[ti]
    pt=points[faces[si]]
    b=np.linalg.solve(np.transpose(np.concatenate((np.ones((len(si),3,1)),pt),axis=2),(0,2,1)),np.column_stack((np.ones(len(si)),sample))[:,:,None])[:,:,0]
    e=np.einsum('si,sidh->sdh',b,vertex_values[si]).reshape(n,n,3,4)
    coeff=np.fft.fft2(e,axes=(0,1))
    k=2*np.pi*np.fft.fftfreq(n,d=box/n)
    kx,ky=np.meshgrid(k,k); kn=np.hypot(kx,ky); kn[0,0]=1
    ep=(-ky[:,:,None]*coeff[:,:,0]+kx[:,:,None]*coeff[:,:,1])/kn[:,:,None]
    ez=1j*coeff[:,:,2]  # h=+1; the opposite is an exact sign change.
    longitudinal=(kx[:,:,None]*coeff[:,:,0]+ky[:,:,None]*coeff[:,:,1])/kn[:,:,None]
    result=[]
    for j,angle in enumerate(angles):
        theta=np.radians(angle)
        support=-np.cos(theta)*kx+np.sin(theta)*ky>0
        norm=np.sum(abs(ep[:,:,j][support])**2+abs(ez[:,:,j][support])**2)
        stokes=2*np.imag(np.vdot(ep[:,:,j][support],ez[:,:,j][support]))/norm
        result.append({'angle':angle,'h_plus':float(stokes),'h_minus':float(-stokes),
                       'helicity_absolute_error':float(abs(1-stokes)),
                       'continuum_longitudinal_fraction_diagnostic':float(np.sum(abs(longitudinal[:,:,j][support])**2)/norm),
                       'longitudinal_note':'continuum FFT diagnostic of reconstructed E; not the discrete Gauss constraint'})
    return result


def evaluate():
    cfg=json.loads((ROOT/'wave_preregistration.json').read_text())
    out=ROOT/'results'/'free_attempt_01'
    runs=[]
    for ppw in cfg['ppw']:
        run=json.loads((out/f'free_ppw{ppw}.json').read_text())
        with np.load(out/f'free_ppw{ppw}_terminal_maps.npz') as z:
            helicity=spectral_helicity(z['points'],z['faces'],z['E'],cfg['box'],cfg['angles'])
            bary=np.array([[2/3,1/6,1/6],[1/6,2/3,1/6],[1/6,1/6,2/3]])
            q=np.einsum('qi,fid->fqd',bary,z['points'][z['faces']])
            ref=Reference(cfg['box'],cfg['angles'])
            er=ref.sample(q.reshape(-1,2),cfg['tmax'],'E').reshape(z['E'].shape)
            overlap=np.sum(z['area'][:,None,None,None]*np.conj(er)*z['E'],axis=(0,1,2))
            phase_deviation=np.abs(np.angle(overlap))/(2*np.pi*cfg['tmax'])
        tl=run['timeline']; initial=tl[0]; final=tl[-1]
        energy=np.array([t['energy'] for t in tl])
        drift=np.max(abs(energy/energy[0]-1),axis=0)
        gauss=np.max([t['gauss_relative'] for t in tl],axis=0)
        velocity=(np.array(final['centroid'])-np.array(initial['centroid']))/cfg['tmax']
        # Compare velocity to the same finite-band continuum packet, not to
        # exactly c in the nominal direction. Narrow packets have angular spread.
        qbase=Reference(cfg['box'],cfg['angles'])
        n=512; axis=qbase.axis; xx,yy=np.meshgrid(axis,axis)
        continuum_cent=[]
        for time in (0,cfg['tmax']):
            ee=qbase.fields(time,'E'); bb=qbase.fields(time,'B')
            uu=.5*np.sum(abs(ee)**2+abs(bb)**2,axis=1)
            continuum_cent.append(np.stack((np.sum(uu*xx,axis=(1,2))/np.sum(uu,axis=(1,2)),np.sum(uu*yy,axis=(1,2))/np.sum(uu,axis=(1,2)))))
        vref=(continuum_cent[1]-continuum_cent[0])/cfg['tmax']
        velocity_error=np.linalg.norm(velocity-vref,axis=0)
        cases=[]
        for j,angle in enumerate(cfg['angles']):
            checks={
                'gauss':bool(gauss[j]<=cfg['gauss_max']),
                'energy':bool(drift[j]<=cfg['energy_drift_max']),
                'terminal_field_L2':bool(final['field_L2_error'][j]<=cfg['field_L2_error_max']),
                'envelope_velocity':bool(velocity_error[j]<=cfg['velocity_error_max']),
                'momentum_energy':bool(abs(final['momentum_over_energy'][j]-1)<=cfg['momentum_ratio_error_max']),
                'boundary_control':bool(max(t['boundary_energy_fraction'][j] for t in tl)<=cfg['boundary_energy_fraction_max']),
                'helicity':bool(helicity[j]['helicity_absolute_error']<=cfg['helicity_error_max']),
            }
            for h in cfg['helicities']:
                cases.append({'angle':angle,'helicity':h,'energy_drift':float(drift[j]),'max_gauss_relative':float(gauss[j]),'field_L2_error':final['field_L2_error'][j],
                              'velocity_error':float(velocity_error[j]),'momentum_over_energy':final['momentum_over_energy'][j],
                              'reconstructed_spectral_helicity':h*helicity[j]['h_plus'],
                              'packet_phase_frequency_deviation_diagnostic':float(phase_deviation[j]),
                              'checks':checks,'passed_executed_checks':all(checks.values())})
        runs.append({'ppw':ppw,'cases':cases,'helicity_diagnostics':helicity,'elapsed_seconds':run['elapsed_seconds']})
    decreasing=[]
    for j in range(8):
        errors=[r['cases'][j]['field_L2_error'] for r in runs]
        decreasing.append({'angle':runs[0]['cases'][j]['angle'],'helicity':runs[0]['cases'][j]['helicity'],'errors':errors,'passed':bool(np.all(np.diff(errors)<0))})
    failed=[{'ppw':r['ppw'],'angle':c['angle'],'helicity':c['helicity'],'failed_checks':[k for k,v in c['checks'].items() if not v]} for r in runs for c in r['cases'] if not c['passed_executed_checks']]
    result={'runs':runs,'spatial_comparison':decreasing,'failed_cases':failed,
            'GATE_DELAUNAY_FREE':'FAIL' if failed or not all(d['passed'] for d in decreasing) else 'PENDING',
            'GATE_MAXWELL_EQUIVALENCE':'PENDING','GATE_HRF_CAP2':'PENDING',
            'notes':'h=-1 differs only by the sign of the vertical sector; same dynamics, energies and XY flux. Both helicities reconstructed from sector linearity, not 48 independent integrations. Packet phase deviation is not a completed omega(k) dispersion test.',
            'uncompleted_required_controls':['independent dt refinement','plane-wave dispersion omega(k)','full HRF mode/symmetry equivalence'],
            'cavity':'NOT_EXECUTED: free injection gate has not passed',
            'long_stages':{str(t):'NOT_EXECUTED: prior gates have not passed' for t in (150,300,500)}}
    write(out/'FREE_GATE_RESULTS.json',result)
    print(json.dumps({'gate':result['GATE_DELAUNAY_FREE'],'failed_cases':failed,'spatial_comparison':decreasing},indent=2))


if __name__=='__main__': evaluate()
