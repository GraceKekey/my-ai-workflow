"""Time-domain Fourier/Galerkin phase probes of both reduced wave sectors."""
import json
import numpy as np
from scipy.sparse.linalg import splu
from free_benchmark import ROOT,mesh,Reference,initial,write


def run(ppw,cfg):
    m=mesh(ppw,cfg['box'],cfg['seed'])
    a,z,v,vz=initial(m,Reference(cfg['box'],cfg['angles']))
    dt=cfg['dt'];steps=100
    p=m['p'];edges=m['edges']; delta=p[edges[:,1]]-p[edges[:,0]]
    mid=(p[edges[:,0]]+p[edges[:,1]])/2
    pa=[];pz=[];ks=[]
    for angle in cfg['angles']:
        theta=np.radians(angle)
        # Probe an actual Fourier bin, as in the historical Yee phase probe.
        k=2*np.pi/cfg['box']*np.round(cfg['box']*np.array([-np.cos(theta),np.sin(theta)]))
        pol=np.array([-k[1],k[0]])/np.linalg.norm(k)
        pa.append((delta@pol)*np.exp(1j*(mid@k))*np.sinc((delta@k)/(2*np.pi)))
        pz.append(np.exp(1j*(p@k)));ks.append(float(np.linalg.norm(k)))
    pa=np.stack(pa,axis=1);pz=np.stack(pz,axis=1)
    def pack(x):return np.column_stack((x.real,x.imag))
    def unpack(x):return x[:,:4]+1j*x[:,4:]
    a,z,v,vz=[pack(x) for x in (a,z,v,vz)]
    m1,m0,ka,kz=m['m1'],m['m0'],m['ka'],m['kz']
    lu1=splu((m1+dt*dt/4*ka).tocsc());lu0=splu((m0+dt*dt/4*kz).tocsc())
    probes=[]
    for step in range(steps+1):
        if step%10==0:
            cp=-np.sum(np.conj(pa)*(m1@unpack(v)),axis=0)
            cz=-np.sum(np.conj(pz)*(m0@unpack(vz)),axis=0)
            probes.append((step*dt,cp,cz))
        if step<steps:
            nv=lu1.solve((m1-dt*dt/4*ka)@v-dt*ka@a)
            nz=lu0.solve((m0-dt*dt/4*kz)@vz-dt*kz@z)
            a+=dt/2*(v+nv);z+=dt/2*(vz+nz);v,vz=nv,nz
    t=np.array([p[0] for p in probes])
    cp=np.array([p[1] for p in probes]);cz=np.array([p[2] for p in probes])
    cases=[]
    for i,angle in enumerate(cfg['angles']):
        wp=-float(np.polyfit(t,np.unwrap(np.angle(cp[:,i])),1)[0])
        wz=-float(np.polyfit(t,np.unwrap(np.angle(cz[:,i])),1)[0])
        cases.append({'angle':angle,'k_bin_magnitude':ks[i],'omega_A_phase':wp,'omega_B_phase':wz,
                      'relative_error_A':abs(wp/ks[i]-1),'relative_error_B':abs(wz/ks[i]-1),
                      'relative_sector_split':abs(wp-wz)/ks[i],
                      'passed':bool(max(abs(wp/ks[i]-1),abs(wz/ks[i]-1))<=cfg['dispersion_error_max'])})
    return {'ppw':ppw,'probe_time_window':[0,steps*dt],'cases':cases,
            'phase_A':np.unwrap(np.angle(cp),axis=0).tolist(),
            'phase_B':np.unwrap(np.angle(cz),axis=0).tolist(),'times':t.tolist()}


if __name__=='__main__':
    cfg=json.loads((ROOT/'wave_preregistration.json').read_text())
    out=ROOT/'results'/'dispersion_phase_controls.json'
    if out.exists():raise FileExistsError(out)
    write(ROOT/'results'/'dispersion_phase_preregistration.json',dict(cfg,probe_steps=100,probe_interval_steps=10,probe_definition='Galerkin plane-wave projection at nearest Fourier bin; phases unwrapped before linear fit'))
    runs=[]
    for ppw in cfg['ppw']:
        runs.append(run(ppw,cfg));print('DONE phase',ppw,flush=True)
    write(out,{'runs':runs,'passed':all(c['passed'] for r in runs for c in r['cases']),
               'limit':'finite packet frequency probes, not a complete eigenmode dispersion surface'})
