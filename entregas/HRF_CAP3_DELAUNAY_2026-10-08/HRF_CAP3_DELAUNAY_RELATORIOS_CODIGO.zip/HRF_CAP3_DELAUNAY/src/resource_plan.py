"""Preserve historical cavity profile and estimate unresolved local scales.

No mesh is generated here and no cavity simulation is claimed.
"""
import csv
import json
import numpy as np
from scipy.interpolate import PchipInterpolator
from free_benchmark import ROOT,write

cfg=json.loads((ROOT/'references_v2/03_Yee_2D3V/config_preregistered.json').read_text())
profile=cfg['historical_profile']
pchip=PchipInterpolator(profile['r_over_R'],profile['c'])
R=4.; cin=.39
r=np.linspace(0,R*1.6,3201)
c=np.clip(np.where(r/R>=1.25,1.,pchip(np.clip(r/R,0,1.25))),.015,1.)
local_lambda=c/cin
targets=[10,14,20]
counts={}
for ppw in targets:
    h=local_lambda/ppw
    # Equilateral covering estimate, not actual adaptive mesh cardinality.
    counts[str(ppw)]=float(np.trapezoid(2*np.pi*r*2/(np.sqrt(3)*h*h),r))
out=ROOT/'results'/'cavity_resource_plan.json'
if out.exists(): raise FileExistsError(out)
write(out,{'classification':'[D] geometric estimate; not measured spectral wavelength',
           'radius':R,'injection_c':cin,'historical_c_min':float(c.min()),
           'estimated_min_lambda':float(local_lambda.min()),
           'minimum_local_ppw_targets':targets,'estimated_vertices_inside_r6_4':counts,
           'cavity_status':'NOT_EXECUTED unless free gate passes',
           'mesh_generation':'NOT_EXECUTED','adaptive_convergence':'NOT_TESTED',
           'constitutive_hypothesis':'[H] epsilon=mu=1/c_local; not geometry emergence',
           'notes':'Element lengths do not guarantee phase/spectrum resolution. Natural square free boundary cannot be reused as an open cavity absorber without validation. Do not modify slow core.'})
with (ROOT/'results'/'historical_profile_resolution.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['r','r_over_R','c_local','estimated_lambda_local','h_10','h_14','h_20'])
    w.writerows(zip(r,r/R,c,local_lambda,local_lambda/10,local_lambda/14,local_lambda/20))
print(json.dumps(json.loads(out.read_text()),indent=2))
