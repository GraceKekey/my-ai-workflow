"""Independent dt refinement with fixed spatial mesh and unchanged injection."""
import json
from pathlib import Path
from free_benchmark import run, write

ROOT=Path(__file__).resolve().parents[1]
if __name__=='__main__':
    cfg=json.loads((ROOT/'wave_preregistration.json').read_text())
    for dt in (.018,.0045):
        config=dict(cfg,dt=dt)
        out=ROOT/'results'/f'temporal_dt{dt}'
        out.mkdir(exist_ok=False)
        write(out/'preregistration_copy.json',config)
        run(20,config,out)
