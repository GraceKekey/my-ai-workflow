"""Independent sparse Whitney wave benchmark against a continuum FFT packet.

Natural exterior boundary is tested by boundary energy; this is not a periodic
Yee reproduction. Complex analytic signals are used to define polarization.
"""
import json
import time
import hashlib
from pathlib import Path
import numpy as np
from scipy.spatial import Delaunay
from scipy.sparse import coo_matrix, diags
from scipy.sparse.linalg import splu
from scipy.interpolate import RegularGridInterpolator

ROOT = Path(__file__).resolve().parents[1]


def write(path, data):
    path.write_text(json.dumps(data, indent=2, allow_nan=False)+'\n')


def mesh(ppw, box, seed):
    n = round(box*ppw)+1
    ax = np.linspace(-box/2, box/2, n)
    x,y=np.meshgrid(ax,ax)
    p=np.column_stack((x.ravel(),y.ravel()))
    mask=np.all(np.abs(p)<box/2-1e-9,axis=1)
    p[mask]+=np.random.default_rng(seed).uniform(-.18,.18,(mask.sum(),2))/ppw
    tri=Delaunay(p)
    f=tri.simplices.copy()
    pt=p[f]
    det=(pt[:,1,0]-pt[:,0,0])*(pt[:,2,1]-pt[:,0,1])-(pt[:,1,1]-pt[:,0,1])*(pt[:,2,0]-pt[:,0,0])
    neg=det<0
    f[neg]=f[neg][:,[0,2,1]]
    pt=p[f]
    area=np.abs(det)/2
    # Gradients of affine barycentric coordinates.
    g=np.empty((len(f),3,2))
    for i,j,k in ((0,1,2),(1,2,0),(2,0,1)):
        g[:,i,0]=(pt[:,j,1]-pt[:,k,1])/(2*area)
        g[:,i,1]=(pt[:,k,0]-pt[:,j,0])/(2*area)
    local=np.stack((f[:,[0,1]],f[:,[1,2]],f[:,[2,0]]),axis=1)
    sorted_local=np.sort(local,axis=2)
    edges, inv=np.unique(sorted_local.reshape(-1,2),axis=0,return_inverse=True)
    ei=inv.reshape(-1,3)
    signs=np.where(local[:,:,0]<local[:,:,1],1.,-1.)
    nf,nv,ne=len(f),len(p),len(edges)
    d0=coo_matrix((np.tile([-1.,1.],ne),(np.repeat(np.arange(ne),2),edges.ravel())),shape=(ne,nv)).tocsr()
    d1=coo_matrix((signs.ravel(),(np.repeat(np.arange(nf),3),ei.ravel())),shape=(nf,ne)).tocsr()
    b=(np.ones((3,3))+np.eye(3))/12
    lm=np.zeros((nf,3,3))
    pairs=((0,1),(1,2),(2,0))
    for u,(i,j) in enumerate(pairs):
        for v,(k,l) in enumerate(pairs):
            lm[:,u,v]=area*signs[:,u]*signs[:,v]*(b[i,k]*np.sum(g[:,j]*g[:,l],axis=1)-b[i,l]*np.sum(g[:,j]*g[:,k],axis=1)-b[j,k]*np.sum(g[:,i]*g[:,l],axis=1)+b[j,l]*np.sum(g[:,i]*g[:,k],axis=1))
    rows=np.repeat(ei,3,axis=1).ravel()
    cols=np.tile(ei,(1,3)).ravel()
    m1=coo_matrix((lm.ravel(),(rows,cols)),shape=(ne,ne)).tocsc()
    rows0=np.repeat(f,3,axis=1).ravel(); cols0=np.tile(f,(1,3)).ravel()
    m0=coo_matrix(((area[:,None,None]*b).ravel(),(rows0,cols0)),shape=(nv,nv)).tocsc()
    kz=coo_matrix((np.einsum('fid,fjd->fij',g,g).ravel()*np.repeat(area,9),(rows0,cols0)),shape=(nv,nv)).tocsc()
    ka=(d1.T@diags(1/area)@d1).tocsc()
    return dict(p=p,f=f,edges=edges,ei=ei,signs=signs,g=g,area=area,m1=m1,m0=m0,ka=ka,kz=kz,d0=d0,d1=d1,tri=tri)


class Reference:
    def __init__(self,box,angles,n=512):
        self.box,self.n=box,n
        ax=np.arange(n)*box/n-box/2
        self.axis=ax
        k=2*np.pi*np.fft.fftfreq(n,d=box/n)
        kx,ky=np.meshgrid(k,k)
        self.k=np.stack((kx,ky))
        self.w=np.hypot(kx,ky)
        self.w[0,0]=1
        self.polar=np.stack((-ky/self.w,kx/self.w))
        self.coeff=[]
        for angle in angles:
            theta=np.radians(angle); d=np.array([-np.cos(theta),np.sin(theta)])
            ks=d[0]*kx+d[1]*ky; kp=-d[1]*kx+d[0]*ky
            amp=np.exp(-.5*.7**2*(ks-2*np.pi)**2-.5*.35**2*kp**2)*(ks>0)
            amp*=np.cos(np.pi*(np.indices(amp.shape).sum(axis=0)))
            # Shift the centered packet from index zero to physical origin.
            self.coeff.append(np.concatenate((self.polar, np.ones((1,n,n))),axis=0)*amp[None])
        self.coeff=np.stack(self.coeff)

    def fields(self,t,kind='A'):
        coeff=self.coeff*np.exp(-1j*self.w*t)[None,None]
        if kind=='A': coeff=coeff/(1j*self.w)[None,None]
        elif kind=='V': coeff=-coeff
        elif kind=='B':
            kx,ky=self.k
            coeff=np.stack((ky[None]*coeff[:,2],-kx[None]*coeff[:,2],kx[None]*coeff[:,1]-ky[None]*coeff[:,0]),axis=1)/self.w[None,None]
        elif kind!='E': raise ValueError(kind)
        return np.fft.ifft2(coeff,axes=(-2,-1))

    def sample(self,points,t,kind):
        field=self.fields(t,kind)
        # FFT reference is periodic; all requested positions remain in the box.
        result=[]
        for a in field:
            comps=[]
            for c in a:
                pad=np.pad(c,((0,1),(0,1)),mode='wrap')
                ax=np.r_[self.axis,self.box/2]
                interp=RegularGridInterpolator((ax,ax),pad,bounds_error=True)
                comps.append(interp(points[:,[1,0]]))
            result.append(np.stack(comps,axis=1))
        return np.stack(result,axis=2)  # points, components, angle


def initial(m,ref):
    edges=m['edges']; p=m['p']
    delta=p[edges[:,1]]-p[edges[:,0]]
    middle=(p[edges[:,1]]+p[edges[:,0]])/2
    out=[]
    for kind in ('A','V'):
        samples1=ref.sample(middle-delta/(2*np.sqrt(3)),0,kind)
        samples2=ref.sample(middle+delta/(2*np.sqrt(3)),0,kind)
        a=np.einsum('ed,edh->eh',delta,.5*(samples1[:,:2]+samples2[:,:2]))
        z=ref.sample(p,0,kind)[:,2]
        # Remove only the initial electric Gauss residual in the natural-box
        # physical space. Retain initial gauge coordinate; curvature is invariant.
        if kind=='V':
            scalar=(m['d0'].T@m['m1']@m['d0']).tocsc()
            rhs=m['d0'].T@(m['m1']@a)
            lu=splu(scalar[1:,1:])
            phi=np.zeros((len(p),a.shape[1]),dtype=complex)
            phi[1:]=lu.solve(rhs[1:].real)+1j*lu.solve(rhs[1:].imag)
            a-=m['d0']@phi
        out.extend((a,z))
    return out  # a,z,v,vz


def reconstruct(m,a,z,v,vz):
    bary=np.array([[2/3,1/6,1/6],[1/6,2/3,1/6],[1/6,1/6,2/3]])
    g=m['g']; f=m['f']; ei=m['ei']; signs=m['signs']
    nf,nh=len(f),a.shape[1]
    e=np.zeros((nf,3,3,nh),dtype=complex)
    for l,(i,j) in enumerate(((0,1),(1,2),(2,0))):
        basis=bary[:,i][None,:,None]*g[:,j,None,:]-bary[:,j][None,:,None]*g[:,i,None,:]
        e[:,:,:2]-=basis[:,:,:,None]*(signs[:,l,None]*v[ei[:,l]])[:,None,None,:]
    e[:,:,2]=-np.einsum('qi,fih->fqh',bary,vz[f])
    grad=np.einsum('fid,fih->fdh',g,z[f])
    b=np.empty_like(e)
    b[:,:,0]=grad[:,1,None,:]; b[:,:,1]=-grad[:,0,None,:]
    b[:,:,2]=(m['d1']@a/m['area'][:,None])[:,None,:]
    return e,b,bary


def diag(m,ref,a,z,v,vz,t):
    e,b,bary=reconstruct(m,a,z,v,vz)
    u=.5*np.sum(abs(e)**2+abs(b)**2,axis=2)
    area=m['area'][:,None,None]/3
    energy=np.sum(area*u,axis=(0,1))
    flux=np.real(np.cross(e,np.conj(b),axisa=2,axisb=2,axisc=2))
    momentum=np.sum(area[:,:,None,:]*flux,axis=(0,1))
    q=np.einsum('qi,fid->fqd',bary,m['p'][m['f']])
    cent=np.sum(area[:,:,None,:]*u[:,:,None,:]*q[:,:,:,None],axis=(0,1))/energy
    er=ref.sample(q.reshape(-1,2),t,'E').reshape(e.shape)
    br=ref.sample(q.reshape(-1,2),t,'B').reshape(b.shape)
    error=np.sqrt(np.sum(area*np.sum(abs(e-er)**2+abs(b-br)**2,axis=2),axis=(0,1))/np.sum(area*np.sum(abs(er)**2+abs(br)**2,axis=2),axis=(0,1)))
    boundary=np.max(abs(q),axis=2)>ref.box/2-1
    edge_fraction=np.sum(area*u*boundary[:,:,None],axis=(0,1))/energy
    mv=m['m1']@v
    gauss=np.linalg.norm(m['d0'].T@mv,axis=0)/np.maximum(np.linalg.norm(mv,axis=0),1e-30)
    return dict(time=t,energy=energy.tolist(),momentum_over_energy=(np.linalg.norm(momentum,axis=0)/energy).tolist(),centroid=cent.tolist(),field_L2_error=error.tolist(),boundary_energy_fraction=edge_fraction.tolist(),gauss_relative=gauss.tolist())


def run(ppw,config,out):
    began=time.monotonic()
    m=mesh(ppw,config['box'],config['seed'])
    print('MESH',ppw,len(m['p']),len(m['edges']),flush=True)
    ref=Reference(config['box'],config['angles'])
    a,z,v,vz=initial(m,ref)
    before=diag(m,ref,a,z,v,vz,0)
    dt=config['dt']; steps=round(config['tmax']/dt)
    # Real sparse factors; pack real and imaginary columns per solve.
    def pack(c): return np.column_stack((c.real,c.imag))
    def unpack(c): return c[:,:4]+1j*c[:,4:]
    state=[pack(c) for c in (a,z,v,vz)]
    m1,m0,ka,kz=m['m1'],m['m0'],m['ka'],m['kz']
    lu1=splu((m1+dt*dt/4*ka).tocsc())
    lu0=splu((m0+dt*dt/4*kz).tocsc())
    print('FACTORED',ppw,'seconds',round(time.monotonic()-began,2),flush=True)
    timeline=[before]
    for step in range(1,steps+1):
        a,z,v,vz=state
        newv=lu1.solve((m1-dt*dt/4*ka)@v-dt*(ka@a))
        newvz=lu0.solve((m0-dt*dt/4*kz)@vz-dt*(kz@z))
        state=[a+dt/2*(v+newv),z+dt/2*(vz+newvz),newv,newvz]
        if step%100==0 or step==steps:
            values=[unpack(c) for c in state]
            d=diag(m,ref,*values,step*dt)
            timeline.append(d)
            print('STEP',ppw,step,'L2',d['field_L2_error'],'Gauss',d['gauss_relative'],flush=True)
    write(out/f'free_ppw{ppw}.json',dict(ppw=ppw,vertices=len(m['p']),edges=len(m['edges']),elapsed_seconds=time.monotonic()-began,timeline=timeline))
    values=[unpack(c) for c in state]
    e,b,bary=reconstruct(m,*values)
    np.savez_compressed(out/f'free_ppw{ppw}_terminal_maps.npz',points=m['p'],faces=m['f'],E=e.astype(np.complex64),B=b.astype(np.complex64),area=m['area'],angles=config['angles'])
    # Complex fields combine planar and vertical components with +i h below.
    # The independent evolutions above used unit equal-phase sectors; errors
    # and energy are unchanged by the vertical phase rotation, but cross-sector
    # polarization needs its own spectral diagnostic before a PASS claim.


if __name__=='__main__':
    path=ROOT/'wave_preregistration.json'
    config=json.loads(path.read_text())
    out=ROOT/'results'/'free_attempt_01'
    out.mkdir(exist_ok=False)
    write(out/'preregistration_copy.json',config)
    for ppw in config['ppw']:
        run(ppw,config,out)
