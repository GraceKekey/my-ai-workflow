"""Structural Whitney checks only; no photon-injection or cavity claim."""
import hashlib
import json
from pathlib import Path

import numpy as np
from scipy.linalg import eigh
from scipy.spatial import Delaunay, Voronoi


def assemble(n, seed=20261008):
    rng = np.random.default_rng(seed)
    axis = np.linspace(0, 1, n)
    points = np.array([(x, y) for y in axis for x in axis])
    interior = np.all((points > 0) & (points < 1), axis=1)
    points[interior] += rng.uniform(-0.22, 0.22, (interior.sum(), 2)) / (n - 1)
    faces = Delaunay(points).simplices.copy()
    for f in faces:
        p = points[f]
        determinant = np.linalg.det(np.array([p[1] - p[0], p[2] - p[0]]))
        if determinant < 0:
            f[1], f[2] = f[2], f[1]
    edges = sorted({tuple(sorted((int(f[i]), int(f[(i+1) % 3]))))
                    for f in faces for i in range(3)})
    lookup = {e: j for j, e in enumerate(edges)}
    nv, ne, nf = len(points), len(edges), len(faces)
    d0, d1 = np.zeros((ne, nv)), np.zeros((nf, ne))
    m0, m1 = np.zeros((nv, nv)), np.zeros((ne, ne))
    kz, areas = np.zeros((nv, nv)), []
    for e, (i, j) in enumerate(edges):
        d0[e, i], d0[e, j] = -1, 1
    for t, f in enumerate(faces):
        p = points[f]
        area = np.linalg.det(np.array([p[1]-p[0], p[2]-p[0]])) / 2
        assert area > 0
        areas.append(area)
        gradients = np.linalg.inv(np.column_stack((np.ones(3), p)))[1:, :].T
        barycentric_integrals = area * (np.ones((3, 3)) + np.eye(3)) / 12
        m0[np.ix_(f, f)] += barycentric_integrals
        kz[np.ix_(f, f)] += area * gradients @ gradients.T
        local = []
        for i, j in ((0, 1), (1, 2), (2, 0)):
            edge = tuple(sorted((int(f[i]), int(f[j]))))
            e = lookup[edge]
            sign = 1 if f[i] < f[j] else -1
            d1[t, e] = sign
            local.append((e, sign, i, j))
        for e, sign_e, i, j in local:
            for g, sign_g, k, l in local:
                value = (barycentric_integrals[i, k] * (gradients[j] @ gradients[l])
                         - barycentric_integrals[i, l] * (gradients[j] @ gradients[k])
                         - barycentric_integrals[j, k] * (gradients[i] @ gradients[l])
                         + barycentric_integrals[j, l] * (gradients[i] @ gradients[k]))
                m1[e, g] += sign_e * sign_g * value
    m2 = np.diag(1 / np.array(areas))
    ka = d1.T @ m2 @ d1
    # The unbounded exterior Voronoi cells are retained as geometry metadata.
    dual = Voronoi(points)
    return points, faces, d0, d1, m0, m1, m2, kz, ka, dual


def relative(a, b):
    return float(np.linalg.norm(a-b) / max(np.linalg.norm(b), 1e-30))


def verify(n):
    points, faces, d0, d1, m0, m1, m2, kz, ka, dual = assemble(n)
    rng = np.random.default_rng(67)
    a, phi = rng.normal(size=m1.shape[0]), rng.normal(size=m0.shape[0])
    eig_a, vectors = eigh(ka, m1)
    eig_z = eigh(kz, m0, eigvals_only=True)
    threshold = 1e-9 * max(eig_a.max(), eig_z.max())
    active = eig_a > threshold
    # Only positive-frequency modes: Gauss is an initial constraint, not an
    # automatic consequence of gauge invariance for arbitrary initial velocity.
    v = vectors[:, active] @ rng.normal(size=active.sum())
    gauss = np.linalg.norm(d0.T @ m1 @ v) / np.linalg.norm(m1 @ v)
    signs = rng.choice([-1., 1.], size=len(a))
    reversed_d1 = d1 * signs[None, :]
    reversed_k = reversed_d1.T @ m2 @ reversed_d1
    orientation_error = relative(reversed_k, signs[:, None] * ka * signs[None, :])
    # Analytic semidiscrete modal evolution verifies the assembled Hamiltonian,
    # not the accuracy or stability of a future time-stepping implementation.
    omega = np.sqrt(eig_a[active])
    coeff = rng.normal(size=active.sum())
    time = 0.137
    at = vectors[:, active] @ (coeff * np.cos(omega*time))
    vt = vectors[:, active] @ (-omega * coeff * np.sin(omega*time))
    e0 = 0.5 * np.sum(eig_a[active] * coeff**2)
    et = 0.5 * (vt @ m1 @ vt + at @ ka @ at)
    observed_kernel = int((np.abs(eig_a) <= threshold).sum())
    result = {
        'n_axis': n, 'vertices': len(points), 'edges': len(a), 'faces': len(faces),
        'min_mass0_eigenvalue': float(eigh(m0, eigvals_only=True).min()),
        'min_mass1_eigenvalue': float(eigh(m1, eigvals_only=True).min()),
        'min_mass2_diagonal': float(m2.diagonal().min()),
        'min_generalized_eigenvalue_A': float(eig_a.min()),
        'min_generalized_eigenvalue_B': float(eig_z.min()),
        'incidence_identity_max': float(np.abs(d1 @ d0).max()),
        'gradient_energy_kernel_relative': float(np.linalg.norm(ka @ d0) / np.linalg.norm(ka)),
        'gauge_curvature_relative': relative(d1 @ (a+d0 @ phi), d1 @ a),
        'wilson_gauge_absolute_error': float(abs(np.sum(1-np.cos(d1 @ a)) - np.sum(1-np.cos(d1 @ (a+d0 @ phi))))),
        'sector_B_reduced_whitney_stiffness_relative': relative(kz, d0.T @ m1 @ d0),
        'gauss_positive_modes_relative': float(gauss),
        'kernel_A_observed': observed_kernel, 'kernel_A_expected_disk': len(points)-1,
        'kernel_B_observed': int((np.abs(eig_z) <= threshold).sum()),
        'orientation_covariance_relative': orientation_error,
        'analytic_semidiscrete_energy_drift': float(abs(et-e0)/e0),
        'voronoi_vertices': len(dual.vertices),
        'boundary': 'natural variational boundary on unit square; not open-space injection',
    }
    checks = {
        'positive_masses': min(result['min_mass0_eigenvalue'], result['min_mass1_eigenvalue'], result['min_mass2_diagonal']) > 0,
        'positive_semidefinite_stiffness': min(eig_a.min(), eig_z.min()) > -threshold,
        'incidence': result['incidence_identity_max'] == 0,
        'gauge': result['gauge_curvature_relative'] < 1e-12 and result['wilson_gauge_absolute_error'] < 1e-10,
        'extrusion_reduction': result['sector_B_reduced_whitney_stiffness_relative'] < 1e-12,
        'kernel': observed_kernel == len(points)-1 and result['kernel_B_observed'] == 1,
        'gauss': gauss < 1e-10,
        'orientation': orientation_error < 1e-12,
        'modal_energy': result['analytic_semidiscrete_energy_drift'] < 1e-12,
    }
    checks = {key: bool(value) for key, value in checks.items()}
    result['checks'], result['passed'] = checks, all(checks.values())
    return result


if __name__ == '__main__':
    root = Path(__file__).resolve().parents[1]
    config = root / 'operator_preregistration.json'
    prereg = json.loads(config.read_text())
    results = [verify(n) for n in prereg['n_axis']]
    report = {'classification': '[M] structural operator checks only',
              'preregistration_sha256': hashlib.sha256(config.read_bytes()).hexdigest(),
              'runs': results, 'passed': all(r['passed'] for r in results),
              'GATE_DELAUNAY_FREE': 'NOT_TESTED',
              'GATE_MAXWELL_EQUIVALENCE': 'NOT_TESTED', 'GATE_HRF_CAP2': 'PENDING',
              'cavity': 'NOT_EXECUTED', 'long_stage': 'NOT_EXECUTED'}
    out = root / 'results' / 'operator_verification.json'
    if out.exists():
        raise FileExistsError('Preserve existing attempts; choose a new output path')
    out.write_text(json.dumps(report, indent=2)+'\n')
    print(json.dumps(report, indent=2))
    raise SystemExit(0 if report['passed'] else 1)
