"""Diagnose time-scale resolution without overwriting failed acceptance tests."""
import json
import numpy as np
from scipy.sparse.linalg import splu
from free_benchmark import ROOT,mesh,write


def midpoint_ratio(omega,dt=.018,T=3.96):
    phases=[2*round(T/h)*np.arctan(omega*h/2) for h in (dt,dt/2,dt/4)]
    signals=np.exp(1j*np.array(phases))
    ratio=abs(signals[0]-signals[1])/abs(signals[1]-signals[2])
    return float(ratio)


if __name__=='__main__':
    out=ROOT/'results/time_failure_diagnosis.json'
    if out.exists():raise FileExistsError(out)
    cfg=json.loads((ROOT/'wave_preregistration.json').read_text())
    m=mesh(20,cfg['box'],cfg['seed'])
    rng=np.random.default_rng(73)
    measurements=[]
    for sector,kk,mm in [('A',m['ka'],m['m1']),('B',m['kz'],m['m0'])]:
        lu=splu(mm)
        x=rng.normal(size=mm.shape[0]);x/=np.linalg.norm(x)
        for _ in range(40):
            x=lu.solve(kk@x);x/=np.linalg.norm(x)
        lam=float(x@(kk@x)/(x@(mm@x)))
        omega=float(np.sqrt(lam))
        measurements.append({'sector':sector,'power_iteration_estimated_high_frequency':omega,
                             'dt_omega_at_018':.018*omega,'dt_omega_at_009':.009*omega,'dt_omega_at_0045':.0045*omega,
                             'note':'Power estimate, not a certified spectral upper bound or energy-weighted spectrum.'})
    examples=[{'omega':w,'midpoint_time_order_ratio':midpoint_ratio(w)} for w in (2*np.pi,40.,80.,160.,320.)]
    # Independently check the one-mode step against its closed-form rotation.
    w=2*np.pi;h=.018;q,v=1.,0.
    for _ in range(220):
        newv=((1-h*h*w*w/4)*v-h*w*w*q)/(1+h*h*w*w/4)
        q+=h*(v+newv)/2;v=newv
    phase=440*np.arctan(w*h/2)
    reference=np.array([np.cos(phase),-w*np.sin(phase)])
    error=float(np.linalg.norm(np.array([q,v])-reference))
    write(out,{'classification':'[M] numerical diagnosis; original acceptance remains FAIL',
               'high_frequency_estimates':measurements,'closed_form_modal_examples':examples,
               'one_mode_algorithm_vs_closed_form_absolute_error':error,
               'interpretation':'The midpoint algorithm is second order for resolved individual modes. The full-field convergence test is not in an established temporal asymptotic regime; high-frequency mesh branches are a plausible source. A complete energy-weighted spectral attribution has not been measured, so this does not explain every part of the failed ratio or approve the gate.',
               'next_required_test':'Smaller time steps at fixed spatial mesh, with full-field order test and initial modal-spectrum control; preregister before new acceptance attempt.'})
    print(json.dumps(json.loads(out.read_text()),indent=2))
