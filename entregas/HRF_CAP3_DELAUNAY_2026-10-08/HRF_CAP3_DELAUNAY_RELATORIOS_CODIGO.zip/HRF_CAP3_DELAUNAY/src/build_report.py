"""Build reports and figures from measured files, without filling unrun stages."""
import csv
import json
import os
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(__file__).resolve().parents[1]/'.matplotlib-cache'))
os.environ.setdefault('XDG_CACHE_HOME',str(Path(__file__).resolve().parents[1]/'.cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from free_benchmark import ROOT,write


def temporal():
    base=ROOT/'results'/'free_attempt_01'
    paths=[ROOT/'results'/'temporal_dt0.018',base,ROOT/'results'/'temporal_dt0.0045']
    arrays=[]
    for p in paths:
        with np.load(p/'free_ppw20_terminal_maps.npz') as f:
            arrays.append((f['E'].astype(np.complex128),f['B'].astype(np.complex128)))
            area=f['area'][:,None,None,None]
    diffs=[]
    for i,j in ((0,1),(1,2)):
        diffs.append(np.sqrt(np.sum(area*(abs(arrays[i][0]-arrays[j][0])**2+abs(arrays[i][1]-arrays[j][1])**2),axis=(0,1,2))))
    ratio=diffs[0]/diffs[1]
    result={'dt':[.018,.009,.0045],'ratios':ratio.tolist(),'differences':[d.tolist() for d in diffs],
            'passed':bool(np.all((ratio>=2.5)&(ratio<=6.0))),
            'fixed_mesh_ppw':20,'same_seed_and_initial_conditions':True,
            'note':'Compared derived complex64 terminal fields in double precision; result includes storage error.'}
    write(ROOT/'results'/'TEMPORAL_GATE_RESULTS.json',result)
    return result


def build():
    gate=json.loads((ROOT/'results/free_attempt_01/FREE_GATE_RESULTS.json').read_text())
    time=temporal()
    dispersion=json.loads((ROOT/'results/dispersion_phase_controls.json').read_text())
    boundary=json.loads((ROOT/'results/boundary_box16/free_ppw20.json').read_text())
    bfinal=boundary['timeline'][-1]
    cfg=json.loads((ROOT/'wave_preregistration.json').read_text())
    gate['independent_temporal_control']=time
    gate['dispersion_control']=dispersion
    gate['larger_box_diagnosis']={'box':16,'ppw':20,'terminal_boundary_energy_fraction':bfinal['boundary_energy_fraction'],'terminal_L2':bfinal['field_L2_error'],
                                 'scope':'Diagnosis only; does not replace original pre-registered box12 gate or establish finest-mesh boundary convergence.'}
    gate['uncompleted_required_controls']=['full HRF mode/symmetry equivalence','boundary-converged full-resolution free suite after box12 failure','full-field temporal acceptance after failed ratio']
    gate['GATE_MAXWELL_EQUIVALENCE']='PENDING: failed full boundary-controlled free gate'
    gate['failed_required_controls']=[]
    if gate['failed_cases']:
        gate['failed_required_controls'].append('original box12 exterior-margin control')
    if not time['passed']:
        gate['failed_required_controls'].append('independent full-field temporal order ratio')
    if not dispersion['passed']:
        gate['failed_required_controls'].append('time-domain packet frequency probes')
    if not time['passed'] or not dispersion['passed']:
        gate['GATE_DELAUNAY_FREE']='FAIL'
    write(ROOT/'results/GATES_FINAL.json',gate)
    plots=ROOT/'figures';plots.mkdir(exist_ok=True)
    with (ROOT/'results/FREE_CASES.csv').open('w',newline='') as f:
        w=csv.writer(f)
        w.writerow(['ppw','angle','helicity','field_L2','energy_drift','Gauss','velocity_error','P_over_E','spectral_helicity','executed_checks_passed'])
        for run in gate['runs']:
            for c in run['cases']:
                w.writerow([run['ppw'],c['angle'],c['helicity'],c['field_L2_error'],c['energy_drift'],c['max_gauss_relative'],c['velocity_error'],c['momentum_over_energy'],c['reconstructed_spectral_helicity'],c['passed_executed_checks']])
    with (ROOT/'results/TIMELINES.csv').open('w',newline='') as f:
        w=csv.writer(f);w.writerow(['ppw','time','angle','energy','field_L2','Gauss','P_over_E','x_centroid','y_centroid','boundary_energy_fraction'])
        for ppw in cfg['ppw']:
            data=json.loads((ROOT/f'results/free_attempt_01/free_ppw{ppw}.json').read_text())
            for d in data['timeline']:
                for i,angle in enumerate(cfg['angles']):
                    w.writerow([ppw,d['time'],angle,d['energy'][i],d['field_L2_error'][i],d['gauss_relative'][i],d['momentum_over_energy'][i],d['centroid'][0][i],d['centroid'][1][i],d['boundary_energy_fraction'][i]])
    fig,axs=plt.subplots(1,2,figsize=(10,4))
    for j,angle in enumerate(cfg['angles']):
        axs[0].plot(cfg['ppw'],[r['cases'][j*2]['field_L2_error'] for r in gate['runs']],'-o',label=f'{angle}°')
    axs[0].axhline(.15,color='k',ls='--',label='limite 0,15')
    axs[0].set(xlabel='Pontos nominais por λ',ylabel='Erro relativo L2',title='Controle espacial livre');axs[0].legend()
    for ppw in cfg['ppw']:
        data=json.loads((ROOT/f'results/free_attempt_01/free_ppw{ppw}.json').read_text())
        axs[1].plot(cfg['angles'],data['timeline'][-1]['boundary_energy_fraction'],'-o',label=f'caixa12 PPW{ppw}')
    axs[1].plot(cfg['angles'],bfinal['boundary_energy_fraction'],'--o',label='caixa16 PPW20')
    axs[1].axhline(.005,color='k',ls='--');axs[1].set(xlabel='Ângulo (graus)',ylabel='Fração na faixa exterior',title='Controle de margem de borda');axs[1].legend()
    fig.tight_layout();fig.savefig(plots/'convergencia_e_borda.png',dpi=160);plt.close(fig)
    with np.load(ROOT/'results/free_attempt_01/free_ppw32_terminal_maps.npz') as f:
        points=f['points'];faces=f['faces'];e=f['E'].copy();b=f['B'].copy();area=f['area']
        e[:,:,2]*=1j;b[:,:,:2]*=1j
        centroid=points[faces].mean(axis=1)
        u=.5*np.mean(np.sum(abs(e)**2+abs(b)**2,axis=2),axis=1)
        flux=np.mean(np.real(np.cross(e,np.conj(b),axisa=2,axisb=2,axisc=2)),axis=1)
        total=np.sum(area[:,None]*u,axis=0)
        for j,angle in enumerate(cfg['angles']):
            fig,ax=plt.subplots(figsize=(6,6))
            im=ax.tripcolor(points[:,0],points[:,1],faces,facecolors=u[:,j]/total[j],shading='flat',cmap='magma',rasterized=True)
            sel=np.arange(0,len(faces),max(1,len(faces)//900))
            mag=np.linalg.norm(flux[sel,:2,j],axis=1);keep=mag>.02*mag.max();sel=sel[keep]
            ax.quiver(centroid[sel,0],centroid[sel,1],flux[sel,0,j]/total[j],flux[sel,1,j]/total[j],color='cyan',scale=4,width=.002)
            ax.set(xlim=(-6,6),ylim=(-6,6),aspect='equal',xlabel='x/λ',ylabel='y/λ',title=f'Onda livre Delaunay · {angle}° · t=3,96 · h=+1')
            fig.colorbar(im,ax=ax,label='Densidade normalizada de energia (sinal analítico)')
            fig.tight_layout();fig.savefig(plots/f'livre_densidade_fluxo_a{angle}.png',dpi=160);plt.close(fig)
        np.savez_compressed(ROOT/'results/free_density_flux_terminal.npz',centroids=centroid,area=area,density=u/total,flux=flux/total[None,None,:],angles=cfg['angles'],time=cfg['tmax'],helicity=1,
                            note='Analytic-signal quadratic diagnostics; h=-1 reverses vertical-sector sign and leaves XY flux and density unchanged. Not cavity results.')
    maxgauss=max(c['max_gauss_relative'] for r in gate['runs'] for c in r['cases'])
    maxdrift=max(c['energy_drift'] for r in gate['runs'] for c in r['cases'])
    table=['| PPW | Erro L2 final, faixa | Helicidade absoluta, faixa |','|---|---|---|']
    for r in gate['runs']:
        errs=[c['field_L2_error'] for c in r['cases']];hs=[abs(c['reconstructed_spectral_helicity']) for c in r['cases']]
        table.append(f"| {r['ppw']} | {min(errs):.6f}–{max(errs):.6f} | {min(hs):.6f}–{max(hs):.6f} |")
    report=f'''# HRF CAP3-2D3V-DELAUNAY-01 — relatório científico

## Resposta à pergunta

[M] A redução Whitney produto preserva os dois setores transversais esperados e o kernel de gradientes, com identidade discreta de gauge. As ondas livres medidas têm helicidades opostas reconstruídas espectralmente, propagação do envelope e erros de campo decrescentes nas três resoluções.
[?] Isso não constitui aprovação completa da correspondência com o Capítulo 2: **GATE_HRF_CAP2: PENDING**. A equivalência com a tetraedrização histórica 3D, quantização e contrato físico completo não foi demonstrada.
[M/D] **GATE_DELAUNAY_FREE: {gate['GATE_DELAUNAY_FREE']}** nesta tentativa pré-registrada: o controle temporal de campo completo falhou; o controle conservador da faixa exterior também falha nos ângulos listados em GATES_FINAL.json. A caixa maior diagnostica o efeito de borda, mas não substitui retrospectivamente a aprovação da suíte original nem resolve o controle temporal.
[?] Não há resultado Delaunay de confinamento dinâmico ou transporte interno de cavidade. Cavidade T=30 e fases T=150/300/500: **NOT_EXECUTED**, por dependência do gate livre. Nada aqui estabelece elétron ou fóton individual.

## Modelo e execução

[D] Malhas Delaunay de pontos de uma grade com deslocamento irregular, semente 20261008, conectividade congelada, caixa livre de lado12, condições naturais exteriores. A irregularidade não é interpretada como emergência da geometria. O dual Voronoi não define as massas. Massas Whitney consistentes exatas e rigidez de curvatura; redução extrudada por unidade de comprimento em z. Derivação em OPERATOR_DERIVATION.md.
[D] Ambos os setores são evoluídos com midpoint implícito, dt=0,009, até T=3,96 λ/c. A referência contínua é um pacote Fourier transversal de frequência positiva, σ_long=0,7 e σ_trans=0,35, com quatro direções. A conexão planar é integrada nas arestas, az é amostrado nos vértices, e a velocidade inicial é projetada para Gauss. Essa inicialização e a borda diferem da Yee e são declaradas, não alegadas como reprodução idêntica.
[D] Sinais analíticos complexos dos setores são evoluídos independentemente. Para h=+1 e h=-1, multiplica-se o setor vertical por +i e -i. Pela linearidade, as duas helicidades compartilham energia, erro de campo e fluxo XY; não se alegam duas integrações independentes quando se usa essa identidade. Os arquivos guardam os setores não rotacionados e o código aplica a quadratura nos diagnósticos. A amplitude FFT é arbitrária; os balanços são relativos à energia inicial medida, não à energia de um quantum. Os mapas de apresentação são normalizados para energia total1.

## Medidas [M]

{chr(10).join(table)}

Máximo resíduo de Gauss: {maxgauss:.6g}. Máxima deriva da energia quadrática do sinal analítico: {maxdrift:.6g}. O método midpoint conserva a energia quadrática até erro de solução; isso não garante exatidão espacial ou temporal. A ordem temporal independente usa dt=0,018/0,009/0,0045 na mesma malha: razões {time['ratios']}, passou={time['passed']}. O critério era2,5–6; permanece FAIL. O diagnóstico de modos individuais e escala espectral está em time_failure_diagnosis.json, sem substituir o teste de campo completo. [H/?] Modos de alta frequência da malha podem contribuir para um regime temporal ainda não assintótico; sua contribuição energética exata não foi medida, logo essa causa não é afirmada como demonstrada.

Os probes temporais de dispersão dos dois setores passaram={dispersion['passed']}, com seus valores, limites e fases em dispersion_phase_controls.json. São probes de frequência de pacote em bins Fourier, não uma superfície completa de dispersão do espectro da malha irregular. O controle Rayleigh independente está em plane_wave_controls.json.

O diagnóstico FFT longitudinal do E interpolado não é a lei discreta de Gauss nem prova de uma terceira polarização física. A ausência de modo gradiente propagante usa o kernel do operador e a restrição inicial. A reconstrução/interpolação introduz resíduos contínuos de campo mesmo com Gauss discreto conservado.

## Borda e resultado negativo

[D] O limite prévio foi 0,005 da energia na faixa de largura1 junto ao exterior; trata-se de um teste conservador de margem, não uma medição de energia já refletida ou absorvida. [M] Na caixa16/PPW20, as frações finais foram {bfinal['boundary_energy_fraction']}. A redução dessa ocupação localiza uma dependência do desenho da caixa. Não concluir que a discretização Delaunay não pode produzir ondas livres. O PASS de outros controles não anula o FAIL pré-registrado da tentativa caixa12.
[?] Para continuar: registrar e validar uma suíte livre com passos temporais menores e controle do espectro modal inicial, além de caixa maior nas três resoluções e convergência separada de borda e da referência espectral, antes da cavidade. Não afrouxar os limites para transformar os resultados desta tentativa em PASS.

## Cavidade, comparação Yee e refinamento

[H] O perfil histórico c_min=0,015 e hipótese ε=μ=1/c_local foram preservados em referências e no planejamento. [D] O arquivo cavity_resource_plan.json estima a resolução local a partir de c_local/0,39, sem alegar medição de fase na cavidade. A estimativa de cobertura exige aproximadamente 456 mil, 894 mil e 1,82 milhão de vértices na região r≤6,4 para os alvos locais10/14/20; nenhuma dessas malhas foi gerada. Refinamento adaptativo e continuidade energética entre regiões não foram testados nesta rodada.
[M, fonte histórica] Yee livre: PASS; Yee curto: FAIL de convergência espacial; Yee longo: NOT_EXECUTED. A comparação atual usa relatórios e dados fornecidos; nenhuma tabela histórica foi renomeada como medição Delaunay. A nova bancada difere em elementos, massas, integrador, preparação e borda. Não há comparação de retenção de cavidade nova com Yee, pois não houve execução Delaunay de cavidade.

## Proveniência, falhas e limites

[D] Os13 documentos do dossiê e843 arquivos históricos tiveram hashes verificados. O pacote compacto omite410 NPZ listados no manifesto histórico; isso limita reanálise dos campos Yee, mas código, CSV/JSON e figuras presentes são preservados. Não são dependências externas necessárias para ler esta entrega.
[D] A primeira tentativa estrutural falhou na gravação de um booleano NumPy; fonte e registro da falha permanecem em results/failed_attempt_01. A correção não alterou critérios ou operadores. A tentativa livre caixa12 com FAIL e seus campos/logs está preservada; a caixa16 é um controle separado. Nenhum resultado negativo foi apagado.
[?] Correspondência histórica completa HRF, cavidade, refinamento adaptativo, absorvedor de cavidade, balanço local de cavidade, identidade local e tempos longos continuam não executados/não aprovados. Este ZIP documenta uma tentativa livre com interrupção condicionada, não o fechamento positivo de todas as fases pedidas.
'''
    (ROOT/'RELATORIO_CIENTIFICO_DELAUNAY.md').write_text(report)
    (ROOT/'STATUS.md').write_text(f"# Estado final da tentativa\n\nGate livre: {gate['GATE_DELAUNAY_FREE']}. Equivalência Maxwell: PENDING. HRF Cap2: PENDING. Cavidade e tempos longos: NOT_EXECUTED por dependência do gate livre. Consulte RELATORIO_CIENTIFICO_DELAUNAY.md e results/GATES_FINAL.json.\n")
    print('REPORT BUILT',gate['GATE_DELAUNAY_FREE'],flush=True)


if __name__=='__main__':build()
