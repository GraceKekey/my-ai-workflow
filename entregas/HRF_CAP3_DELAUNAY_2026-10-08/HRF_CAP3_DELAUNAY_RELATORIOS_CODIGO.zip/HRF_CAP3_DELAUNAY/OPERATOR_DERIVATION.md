# CAP3 Delaunay — revisão matemática inicial [D]

## Redução 3D que define o segundo setor

[F] Considere o produto de um complexo triangular com um intervalo periódico
em z, de comprimento Lz, com métrica euclidiana produto. Restrinja o espaço de
formas Whitney à invariância em z. Escreva a conexão como
A = a_parallel + az dz. As arestas horizontais carregam integrais da conexão;
az nos vértices parametriza a conexão vertical por unidade de comprimento.
Não é um estado material adicional dos nós.

As funções de base são Whitney 1-formas horizontais e lambda_i dz verticais.
O produto interno 3D separa os setores porque dz é ortogonal ao plano.
Por unidade de comprimento em z, a energia cinética reduzida é
1/2 adot^T M1 adot + 1/2 azdot^T M0 azdot.
A curvatura é d_xy a_parallel + d_xy az wedge dz; sua energia é
1/2 (d1 a)^T M2 (d1 a) + 1/2 az^T Kz az,
com Kz_ij = integral grad(lambda_i).grad(lambda_j) dArea.
Assim M1 addot = -d1^T M2 d1 a e M0 azddot = -Kz az.
O código verifica Kz = d0^T M1 d0: a rigidez não é um laplaciano acrescentado
arbitrariamente, mas a redução produto da energia da curvatura 3D.

[D] Isto usa elementos prismáticos produto, não afirma identidade numérica com
uma tetraedrização 3D histórica específica que não foi fornecida.

## Gauge, Gauss e polarizações

[F] Para gauge periódico e independente de z, a -> a+d0 phi e az permanece
invariante. d1 d0=0. Transformações phi proporcionais a z não são periódicas
e não pertencem a esse espaço reduzido. O modo az constante tem curvatura
nula; sua interpretação global depende da topologia, não é onda longitudinal.

[F] Em gauge temporal, Gauss é d0^T M1 adot=0 como condição inicial; a dinâmica
conserva esse valor. Um gradiente com velocidade não nula não é automaticamente
um estado físico admissível. Gauge exato sozinho não prova injeção transversal.

[F] No símbolo contínuo com k no plano, k cross (k cross A), com o sinal da
rigidez, tem autovalores 0, |k|², |k|²: a_parallel perpendicular a k e az são
as duas direções transversais. Gradientes pertencem ao kernel do setor A.
A contagem de modos globais numa caixa com borda não prova degenerescência
por vetor k nem pureza de helicidade numa malha irregular.

## Massas exatas

[F] M0_T = Area/12 (I+11^T). M1 é a integral exata dos produtos de
lambda_i grad lambda_j - lambda_j grad lambda_i, com sinais das arestas.
M2_T=1/Area para graus de liberdade que são integrais das 2-formas.
As massas são consistentes, não aproximadas por pesos duais baricêntricos.
O Voronoi dual é geometria auxiliar; células exteriores ilimitadas não
são substituídas silenciosamente por células fechadas.

## Cavidade e limite da revisão

[H] epsilon=mu=1/c_local implica massas cinéticas ponderadas por epsilon e
rigidez por 1/mu, em ambos os setores da redução. É hipótese constitutiva,
não emergência da conectividade. O perfil histórico deve ser preservado,
inclusive o mínimo 0.015. A configuração Yee especifica PCHIP e um corte
c=1 em r/R>=1.25; o código original é necessário para auditar o corte e
as demais condições numéricas sem inferir detalhes não documentados.

[?] Testes estruturais não aprovam dispersão, envelope, energia-momento,
helicidade, convergência de ondas, fluxo local, absorção ou confinamento.
Nenhuma fase de cavidade ou longa deve começar antes do gate livre completo.
