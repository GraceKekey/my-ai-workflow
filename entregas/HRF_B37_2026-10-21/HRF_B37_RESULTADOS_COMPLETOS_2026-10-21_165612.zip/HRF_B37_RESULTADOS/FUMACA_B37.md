# FUMAÇA — B37 (a base onipresente: seleção, independência, sombreado, fila e identidade numa base livre e numa base SYK)

**Data:** 21 de outubro de 2026 (America/Sao_Paulo) · Claude (`-clau`)
**Ambiente:** Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1, 2 núcleos, 8 GB.
**Para quê:** conferir o código, dimensionar tolerâncias e estimar memória e tempo.
**Como:**
1. Antes do código definitivo houve explorações, com scripts fora do pré-registro e sementes fora da rodada (§3).
2. Depois veio a fumaça com o código congelado: `python -I src/rodar_B37.py --modo fumaca --parte todas --saida fumaca`.
   - L com M = 200 e 400 (2 sementes; "decisão" em M = 400);
   - S20 com N = 16 e S24 com N = 20 (1 semente cada, bateria completa);
   - S28 só com o dimensionamento de N = 28 (construção, Krylov, 20 passos).
3. Por fim, a conferência das peças (`src/conferir_pecas_B37.py`) e o teste do avaliador.

**Aviso:** os números abaixo antecipam o desfecho provável (protocolo §3).

## 1. Peças conferidas (`fumaca/conferencia_pecas.txt`)

| Teste | Resultado |
|---|---|
| Majoranas (N = 8): máx \|{χ_a, χ_b} − δ_ab\| | 2,2×10⁻¹⁶ |
| SYK N = 16: H hermitiano; O_k hermitianos; Tr O_k²/dim | 0; 0; 1,000000 e 1,000000 |
| SYK N = 16: [H, paridade] e [O_k, paridade] | 0 e 0 |
| SYK N = 16: E₀ no espaço inteiro × setores (denso) × setores (Krylov) | −2,647241496254 nos três |
| SYK N = 16: n_B depois de c_B† | 1,000000000000 |
| SYK N = 16: r = 0 → ocupações do vácuo dos GMFt | 0 exato |
| SYK N = 16: drive no código 1 com dt = 0,1 × 0,05 | Δn iguais em 6×10⁻⁶ |
| SYK: suavização ETH × média direta | 3,5×10⁻¹⁵ |
| L M = 400: menor autovalor de K; banda da base em ω | 2,011; [1,418; 2,439] |
| L M = 400: menor √(⟨x²⟩⟨p²⟩) local | 0,500272 (≥ ½) |
| L M = 400: platô exato × média de n(t) em [0; 3 000] (A; C) | 0,0074 × 0,0069; 0,0101 × 0,0112 (a média finita ainda tem *speckle*) |
| L: fidelidade gaussiana consigo mesma; coerente \|α\|² = 1 × vácuo | 1; e⁻¹ exato |
| L M = 400: T4 com ε = 0 (R_off, F_off, S_off − S₀) | 1; 0,99998 (grade de 1° na fase); 0 |
| L: B desacoplado gira livre | erro 0 |
| L: Γ_F (g = 0,1) para B, A e D | 0,0660; 0,0826; 0 |
| Teste do avaliador | **110 ramos, todos ok** (inclui ponta a ponta com perturbações e o caminho da bateria T1 num SYK com N = 12) |

## 2. Fumaça com o código congelado (`fumaca/avaliacao_B37.json`)

| Item | Previsto (rodada) | Fumaça | Comentário |
|---|---|---|---|
| L-T1 | SELETIVA | SELETIVA (c₁ = 55, c₂ = 55; M = 400) | — |
| L-T2 | INDEPENDENTE | INDEPENDENTE (δ = 0,022; efeito médio 0,010 ± 0,012) | — |
| L-T2 escala | DILUI_RAIZ | CRESCE (só M = 200 → 400, 2 sementes) | dois pontos pequenos; ver §3.5 |
| L-T3 | DISTINGUIVEL | DISTINGUIVEL (\|ΔX\|_F = 9,6×10⁻⁴) | — |
| L-T3 escala | MARCA_ONIPRESENTE | MARCA_ONIPRESENTE (2,00; 0,02; −0,79) | — |
| L-T4 regra | REGRA_DE_OURO | REGRA_DE_OURO (1,91; Γ/Γ_F = 0,95) | — |
| L-T5 | SEM_FILA | SEM_FILA (expoentes 1,98; 1,99; 1,98) | — |
| L-T6 | REGRA_DE_OURO | FORA_DA_REGRA (inclinação 2,43) | em M = 400, Γ(0,03) ≈ 2 espaçamentos; em M = 1 600 as explorações deram 1,92 e 2,07 |
| L-T6 platô | RAPIDEZ_NAO_QUANTIDADE | QUANTIDADE_VARIA (platô 0,011 → 0,016) | mesmo efeito de M pequeno; em M = 1 600, 0,0067 → 0,0060 |
| L global | SUSTENTADA | SUSTENTADA | robustez M = 200 × 400: T1, T2, T3 e T5 iguais |
| S-T1 | NAO_SELETIVA | NAO_SELETIVA nos dois (σ₂ = 0,59 em N = 16; 0,32 em N = 20) | — |
| S-T7 | TERMICA | INSUFICIENTE (N = 16) / TERMICA (N = 20; \|ln ρ_diag/ρ_ETH\| = 0,03 e 0,05) | N = 16 tem poucos autoestados vizinhos; esperado |
| S-T3 | DISTINGUIVEL | DISTINGUIVEL (0,32 e 0,20) | — |
| S-T6 | CRESCENTE | CRESCENTE (q = 1,98 e 1,78) | — |
| S-T2 | — | DEPENDENTE (0,65 e 0,32) | sem previsão de classe |
| L × S T2 | ACOPLAMENTO_MAIOR_NA_INTERAGENTE | idem (razão 15) | — |
| S global | CUSTO | INSUFICIENTE (por causa do N = 16) | em N = 20: CUSTO |
| controle N = 28 | CONSISTENTE | NAO_SE_APLICA (só dimensionamento) | — |
| L × S | SEPARACAO | INSUFICIENTE (segue o S global) | — |
| Q11 | IDENTIDADE_POR_LACUNA | IDENTIDADE_POR_LACUNA (com N = 20 e com N = 16) | — |

**T4 na fumaça:**

| Modelo | Marca | Valores |
|---|---|---|
| L (M = 400) | B: R_off / R_on | ε = 0: 1,00 / 0,10 · 0,01: 0,74 / 0,07 · 0,03: 0,14 / 0,05 · 0,1: 0,02 / 0,02 |
| L (M = 400) | D: R_off | ≥ 0,988 em todo ε; R_on ≥ 0,987 |
| S (N = 20) | B: R_off / R_on | r = 0: 1,00 / 0,21 · 0,03: 0,95 / 0,20 · 0,1: 0,52 / 0,16 · 0,3: 0,15 / 0,15 · 1: 0,19 / 0,19 (R_∞ = 0,21; termalizada) |
| S (N = 20) | D: R_off | ≥ 0,958; R_on ≥ 0,96 |

**Controles:**
- L: todos desacoplados → máx n = 0.
- S: r = 0 → máx \|Δn\| ≈ 10⁻⁴⁴.
- Sinal fora: CONTROLE_OK no L. No S, ρ(fora) ≈ 1,4–1,6: com mais energia, B passa A e C, como a camada microcanônica de
  1,6 prevê.
- Normas: \|norma − 1\| ≤ 5×10⁻¹⁵.
## 3. Exploração antes do congelamento (decide parâmetros, limiares e previsões)

Sementes e tamanhos **fora** da rodada. Scripts de exploração guardados na sessão, fora do pré-registro.

### 3.1 S, N = 20 (sementes 11–14) e N = 24 (semente 21): razão ρ = Δn_B/Δn_AC

| N, semente | lacuna | ρ_mc 0,4 / 0,8 / 1,6 | código 1: fim (s = +1; −1) · diagonal | código 2: fim (s = +1; −1) · diagonal | injeção filtrada c1 · c2 |
|---|---|---|---|---|---|
| 20, 11 | 0,0059 | 0,15 / 0,34 / 1,66 | 0,17; 0,23 · 0,24; 0,22 | 0,28; 0,47 · 0,37; 0,36 | 0,16; 0,14 · 0,33; 0,32 |
| 20, 12 | 0,0037 | 0,20 / 0,37 / 1,54 | 0,28; 0,31 · 0,26; 0,24 | 0,35; 0,39 · 0,37; 0,40 | 0,20; 0,20 · 0,34; 0,37 |
| 20, 13 | 0,0046 | 0,13 / 0,28 / 1,48 | 0,23; 0,22 · 0,19; 0,18 | 0,34; 0,31 · 0,31; 0,30 | 0,14; 0,16 · 0,26; 0,26 |
| 20, 14 | 0,0186 | 0,18 / 0,40 / 1,50 | 0,23; 0,43 · 0,28; 0,28 | 0,51; 0,29 · 0,39; 0,42 | 0,21; 0,20 · 0,35; 0,37 |
| 24, 21 | 0,0034 | 0,17 / 0,28 / 1,19 | 0,29; 0,24 · 0,22; 0,21 | 0,29; 0,41 · 0,31; 0,32 | 0,19; 0,17 · 0,27; 0,27 |

**Leitura.**
- Com o código de B (código 2), ρ fica entre 0,28 e 0,51: B acende 2 a 3,5 vezes menos que A e C.
- ρ sobe com a energia da camada e segue a média microcanônica, também na injeção filtrada.
- A referência canônica foi descartada: em β ≈ 9–16 dava ocupações abaixo das do vácuo.

### 3.2 S, T2, T3 e T4 (N = 20)

- **T2:** δ (média de A e C, fim do drive) = 0,11; 0,47; 0,24; 0,07 (sementes 11 e 12, dois sentidos).
- **T3:** máx |Δ⟨O⟩| = 0,11 e 0,31, com |⟨O⟩| ≈ 0,22.
- **T4, marca em B** (R_off em T_off = 200, sementes 11–14):

  | r | R_off | R_∞ |
  |---|---|---|
  | 0 | 1 (exato) | — |
  | 0,03 | 0,92 / 0,98 / 0,97 / 0,97 | 0,83 / 0,94 / 0,94 / 0,95 |
  | 0,1 | 0,42 / 0,78 / 0,72 / 0,73 | — |
  | 0,3 | 0,06 / 0,24 / 0,27 / 0,19 | — |
  | 1 | 0,22 / 0,25 | 0,22 / 0,26 (termalizada) |

- Γ_B em r = 0,03; 0,1; 0,3: (3,1; 9,4; 44)×10⁻³ na semente 11. A inclinação fica entre 0,7 e 1,7, porque Γ/espaçamento é
  pequeno nesses N. Por isso não se classifica.
- **D** guarda a marca: R_off(r = 1) = 0,966 e 0,958; R_on ≈ 0,96. **B** ao religar: R_on ≈ 0,17–0,32 para todo r.
- **Passo:** dt = 0,1; 0,05 e 0,025 dão Δn iguais em 10⁻⁴ (semente 11).

### 3.3 L, sementes 100–102 (M = 400, 800, 1 600), 5 e 6 (M = 1 600)

| M | contraste c₁: mínimo / mediana | δ_T2 mediana (máximo) | \|ΔX\|_F (g_B = 0,1) | ΔS_região (g_B = 0,1) |
|---|---|---|---|---|
| 400 | 8,6 / 37 | 0,034 (0,20) | 9,7×10⁻⁴ | 4,1×10⁻⁴ |
| 800 | 39 / 50 | 0,034 (0,075) | 9,3×10⁻⁴ | 1,7×10⁻⁴ |
| 1 600 | 19 / 27 | 0,030 (0,039) | 9,4×10⁻⁴ | 9,1×10⁻⁵ |

Nessa exploração os contrastes vinham da média tardia; a rodada usa o platô exato. A exploração ainda sorteava perfis
novos para cada sentido.

- **M = 1 600, sementes 5 e 6:**
  - platôs de A, C ≈ 0,003–0,004 e de B ≈ 10⁻⁴ (código 1); de B ≈ 0,0035 e de A, C ≈ 10⁻⁴ (código 2);
  - T2: δ de A e C = −1,1%, +1,8%, −3,9% e −12%;
  - T3: \|ΔX\|_F = 9,1×10⁻⁶, 8,2×10⁻⁵ e 9,2×10⁻⁴ em g_B = 0,01, 0,03 e 0,1 (inclinação 2,0).
- **T4 (B):**
  - ε = 0: R_off = 1, R_on = 0,07;
  - ε = 0,01: R_off = 0,71 e 0,76;
  - ε = 0,03: 0,02 e 0,08;
  - ε = 0,1: ≤ 0,004.
  - Γ/Γ_F = 1,27 e 1,05 (ε = 0,01); 1,09 e 0,94 (0,03); 1,06 e 1,08 (0,1).
- **T4 (D):** R_off ≥ 0,989 e R_on ≥ 0,985 em todo ε.
- **T6 (Γ_A/Γ_F em g = 0,02; 0,03; 0,05; 0,1; 0,2):**
  - semente 5: 0,78; 1,26; 1,10; 1,14; 0,83;
  - semente 6: 0,90; 1,01; 1,08; 1,10; 0,81.
  - O platô de A vale 0,0067; 0,0068; 0,0060; 0,0026 e 0,0009: fixo enquanto Γ < 2Δ e caindo depois.
- **T5 (crescimento inicial):**
  - expoente de n − n(0) em t ≤ 2: 1,97–2,01 para A, B e C; 1,78–1,92 para D (M = 400 e 1 600);
  - os tempos t₁₀ variavam de 0,75 a 50 por causa do *speckle* e foram abandonados como critério.

### 3.4 Dimensionamento de N = 28 (semente 3701, depois com setores)

| Medida | Valor |
|---|---|
| construção | 4,1 s |
| nnz de H | 17 907 712 |
| Krylov no espaço inteiro | 29 s |
| espaço inteiro | 1,6 s por passo, pico 2,5 GB |
| setor de 8 192 (fumaça, semente 3792) | 0,74 s por passo, pico 1,9 GB |
| 4 rodadas de 800 passos | ≈ 40 min |

### 3.5 L-T2 no platô exato (sementes 91 000+, depois da troca da medida)

| M | 200 | 400 | 800 | 1 600 | 3 200 |
|---|---|---|---|---|---|
| sementes | 6 | 6 | 6 | 6 | 3 |
| δ mediana | 0,047 | 0,017 | 0,022 | 0,0095 | 0,015 |
| δ média | 0,098 | 0,034 | 0,025 | 0,014 | 0,017 |
| efeito médio com sinal | 0,03 ± 0,05 | 0,009 ± 0,015 | −0,001 ± 0,009 | 0,002 ± 0,005 | 0,006 ± 0,007 |

Queda fraca, inclinação ≈ −0,3 a −0,4. Levou à previsão DILUI_RAIZ e aos limiares 0,25 e 0,75 (protocolo §9, item 5).
O efeito médio é zero dentro do erro.

## 4. Tempo e memória (rodada `completo`, 2 núcleos)

| Parte | Medido nas explorações e na fumaça | Estimativa para a rodada |
|---|---|---|
| L | M = 400: 1,4 s; M = 1 600: ≈ 15 s; M = 3 200: ≈ 2 min por semente | ≈ 20 min, < 1 GB |
| S20 | N = 20: 53 s por semente (fumaça, com T6 nos dois sentidos) | ≈ 6 min |
| S24 | setor de 2 048: diagonalização em 12 s; drive em 38 s por rodada (14 rodadas e ~18 diagonalizações) | ≈ 13 min por semente; ≈ 40 min |
| S28 | 0,73 s por passo (setor de 8 192), pico de 1,9 GB | 4 × 800 passos ≈ 40 min, mais Krylov ≈ 1 min |

Em sequência, ≈ 1,7 h. Em paralelo (`--parte`), ≈ 45 min, com memória total ≤ 4 GB.
