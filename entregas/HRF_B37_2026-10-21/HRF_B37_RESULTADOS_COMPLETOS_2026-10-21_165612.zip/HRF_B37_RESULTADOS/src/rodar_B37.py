"""B37 — executor. Uso:
    python rodar_B37.py --modo fumaca|completo --parte L|S20|S24|S28|todas [--saida PASTA]
Cada (parte, tamanho, semente) grava um checkpoint JSON atômico em PASTA; checkpoints existentes são pulados
(retomada). config_B37.json registra os parâmetros e os SHA-256 dos módulos usados."""
import argparse, hashlib, json, os, sys, time, platform, resource
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import b37_livre as L
import b37_syk as S

CONFIG = {
    'completo': {
        'L': {'M': [400, 800, 1600, 3200], 'n_sementes': 8, 'M_decisao': 1600, 'M_controle': 800, 'base_semente': 37500},
        'S20': {'N': 20, 'sementes': [3731, 3732, 3733, 3734, 3735, 3736], 'bateria': 'completa'},
        'S24': {'N': 24, 'sementes': [3741, 3742, 3743], 'bateria': 'completa'},
        'S28': {'N': 28, 'sementes': [3751], 'bateria': 'T1'},
    },
    'fumaca': {
        'L': {'M': [200, 400], 'n_sementes': 2, 'M_decisao': 400, 'M_controle': 200, 'base_semente': 37000},
        'S20': {'N': 16, 'sementes': [3790], 'bateria': 'completa'},
        'S24': {'N': 20, 'sementes': [3791], 'bateria': 'completa'},
        'S28': {'N': 28, 'sementes': [3792], 'bateria': 'dimensionamento'},
    },
}
L_TS = np.linspace(0.0, 300.0, 1201)
L_T_OFF, L_T_ON = 400.0, 40.0
L_TS_OFF = np.linspace(0.0, L_T_OFF, 1601)
L_EPS = [0.0, 0.01, 0.03, 0.1]
L_GA = [0.02, 0.03, 0.05, 0.1, 0.2]
L_TS_MARCA = np.linspace(0.0, 2000.0, 8001)
S_TS_T4 = np.linspace(0.0, S.T_OFF, 201)


def sha(p):
    return hashlib.sha256(open(p, 'rb').read()).hexdigest()


def grava(caminho, obj):
    tmp = caminho + '.tmp'
    with open(tmp, 'w') as f:
        json.dump(obj, f, default=lambda o: o.tolist() if hasattr(o, 'tolist') else float(o))
    os.replace(tmp, caminho)


def mem_gb():
    return resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1e6


def semente_L(base, iM, k):
    return base + 100 * iM + k


def rodar_L(cfg, saida, log):
    for iM, M in enumerate(cfg['M']):
        for k in range(cfg['n_sementes']):
            sd = semente_L(cfg['base_semente'], iM, k)
            cam = os.path.join(saida, 'L_M%d_s%d.json' % (M, sd))
            if os.path.exists(cam):
                log('pulado %s' % cam); continue
            t0 = time.time()
            base = L.Base(M, sd)
            rec = {'parte': 'L', 'M': M, 'semente': sd}
            rec['T1'] = L.T1_T2_T5(base, L_TS)
            rec['T3'] = L.T3(base)
            rec['T4'] = L.T4(base, L_EPS, L_T_OFF, L_T_ON, L_TS_OFF)
            rec['T6'] = L.T6(base, L_GA, L_TS_MARCA)
            rec['tempo_s'] = time.time() - t0; rec['mem_gb'] = mem_gb()
            grava(cam, rec)
            log('L M=%d semente=%d: %.1f s, %.2f GB' % (M, sd, rec['tempo_s'], rec['mem_gb']))


def prepara(m, Om, r, denso):
    H = m.H(Om, r); gs = S.fundamental(m, H, denso); gs['H'] = H
    return gs


def resumo_gs(gs):
    return {'p': gs['p'], 'E0': gs['E0'], 'gap': gs['gap']}


def rodar_S(nome, cfg, saida, log):
    N = cfg['N']
    for sd in cfg['sementes']:
        cam = os.path.join(saida, '%s_N%d_s%d.json' % (nome, N, sd))
        if os.path.exists(cam):
            log('pulado %s' % cam); continue
        t0 = time.time()
        m = S.SYK(N, sd)
        rec = {'parte': 'S', 'rotulo': nome, 'N': N, 'semente': sd, 'bateria': cfg['bateria'],
               't_construcao_s': time.time() - t0}
        if cfg['bateria'] == 'dimensionamento':
            gs = prepara(m, S.OM, [1, 1, 1, 1], False)
            p = gs['p']; Hs = m.setor(gs['H'], p); nb = m.nb(p)
            O1, O2 = m.setor(m.O[0], p), m.setor(m.O[1], p)
            t1 = time.time()
            ts, ns, nrm, E, _ = S.evoluir_drive(Hs, O1, O2, nb, gs['psi'], S.CODIGO[1], S.F_DRIVE, 1, T_tot=2.0, amostras=10)
            rec.update({'gs': resumo_gs(gs), 'nnz': int(gs['H'].nnz), 'dim_setor': int(Hs.shape[0]),
                        's_por_passo': (time.time() - t1) / 20.0, 'norma_20_passos': nrm})
        else:
            denso = cfg['bateria'] == 'completa'
            gs = prepara(m, S.OM, [1, 1, 1, 1], denso)
            rec['gs'] = resumo_gs(gs)
            if denso:
                nb = m.nb(gs['p']); nd = S.n_diag(gs['V'], nb); n0 = S.ocup(nb, gs['psi'])
                rec['n0'] = n0.tolist()
                rec['mc'] = {}
                for w in (S.CODIGO[1], S.CODIGO[2], S.W_FORA):
                    dn, k = S.microcanonico(gs['E'], nd, n0, w, S.LARG_MC)
                    rec['mc']['%g' % w] = {'dn': None if dn is None else dn.tolist(), 'estados': k}
            rec['T1'] = [S.rodada_drive(m, gs, S.CODIGO[c], s, denso) | {'codigo': c}
                         for c in (1, 2) for s in (1, -1)]
            log('%s N=%d semente=%d: T1 pronto (%.0f s)' % (nome, N, sd, time.time() - t0))
            if denso:
                rec['fora'] = S.rodada_drive(m, gs, S.W_FORA, 1, True)
                rec['inj'] = [S.injecao_filtrada(m, gs, S.CODIGO[c], s) | {'codigo': c} for c in (1, 2) for s in (1, -1)]
                g0 = prepara(m, S.OM, [0, 0, 0, 0], denso)
                r0 = S.rodada_drive(m, g0, S.CODIGO[1], 1, False)
                rec['controle_r0'] = {'max_abs_dn': float(np.max(np.abs(np.array(r0['curva'])))), 'gs': resumo_gs(g0)}
                gd = prepara(m, [S.OM[0], 0.0, S.OM[2], S.OM[3]], [1, 1, 1, 1], denso)
                rec['T2'] = {'gs': resumo_gs(gd), 'rodadas': [S.rodada_drive(m, gd, S.CODIGO[1], s, False) for s in (1, -1)]}
                rec['T3'] = {'org': S.obs_vacuo(m, gs), 'diss': S.obs_vacuo(m, gd)}
                rec['T4'] = {'B': S.marca(m, gs, 1, S.R_T4, S_TS_T4), 'D': S.marca(m, gs, 3, S.R_T4, S_TS_T4),
                             'ts': S_TS_T4.tolist()}
                rec['T6'] = []
                for rA in S.R_T6:
                    g6 = prepara(m, S.OM, [rA, 1, 1, 1], denso)
                    for s in (1, -1):
                        q = S.rodada_drive(m, g6, S.CODIGO[1], s, False)
                        rec['T6'].append({'rA': rA, 'sentido': s, 'gs': resumo_gs(g6), 'dn_fim': q['dn_fim'],
                                          'dn_tardio': q['dn_tardio'], 'norma': q['norma']})
        rec['tempo_s'] = time.time() - t0; rec['mem_gb'] = mem_gb()
        grava(cam, rec)
        log('%s N=%d semente=%d: %.0f s, %.2f GB' % (nome, N, sd, rec['tempo_s'], rec['mem_gb']))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--modo', choices=['fumaca', 'completo'], required=True)
    ap.add_argument('--parte', choices=['L', 'S20', 'S24', 'S28', 'todas'], default='todas')
    ap.add_argument('--saida', default=None)
    a = ap.parse_args()
    saida = a.saida or os.path.join(os.path.dirname(AQUI), 'resultados' if a.modo == 'completo' else 'fumaca')
    os.makedirs(saida, exist_ok=True)
    cfg = CONFIG[a.modo]
    logf = open(os.path.join(saida, 'log_%s.txt' % a.parte), 'a')

    def log(msg):
        linha = time.strftime('%Y-%m-%d %H:%M:%S ') + msg
        print(linha, flush=True); logf.write(linha + '\n'); logf.flush()

    cam = os.path.join(saida, 'config_B37.json')
    if not os.path.exists(cam):
        grava(cam, {'modo': a.modo, 'config': cfg, 'python': sys.version, 'numpy': np.__version__,
                    'plataforma': platform.platform(),
                    'sha256': {f: sha(os.path.join(AQUI, f)) for f in ('b37_livre.py', 'b37_syk.py', 'rodar_B37.py')},
                    'L': {'W0': L.W0, 'LAM': L.LAM, 'G': L.G, 'SINT': L.SINT, 'CODIGO': L.CODIGO, 'W_FORA': L.W_FORA,
                          'DELTA': L.DELTA, 'REGIAO': L.REGIAO, 'T_OFF': L_T_OFF, 'T_ON': L_T_ON, 'EPS': L_EPS,
                          'GA': L_GA, 'ts': [0, 300, 1201], 'ts_off': [0, L_T_OFF, 1601], 'ts_marca': [0, 2000, 8001]},
                    'S': {'J0': S.J0, 'OM': S.OM, 'CODIGO': S.CODIGO, 'W_FORA': S.W_FORA, 'F': S.F_DRIVE, 'T_D': S.T_D,
                          'T_TOT': S.T_TOT, 'DT': S.DT, 'JAN_FIM': S.JAN_FIM, 'JAN_TARDIA': S.JAN_TARDIA,
                          'R_T4': S.R_T4, 'T_OFF': S.T_OFF, 'T_ON': S.T_ON, 'R_T6': S.R_T6,
                          'SIGMA_FILTRO': S.SIGMA_FILTRO, 'LARG_MC': S.LARG_MC}})
    partes = ['L', 'S20', 'S24', 'S28'] if a.parte == 'todas' else [a.parte]
    for p in partes:
        log('início %s (%s)' % (p, a.modo))
        if p == 'L':
            rodar_L(cfg['L'], saida, log)
        else:
            rodar_S(p, cfg[p], saida, log)
        log('fim %s' % p)


if __name__ == '__main__':
    main()
