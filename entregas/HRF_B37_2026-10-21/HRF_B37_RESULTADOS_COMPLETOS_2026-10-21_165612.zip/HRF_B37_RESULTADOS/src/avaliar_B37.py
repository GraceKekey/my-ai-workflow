"""B37 — avaliador. Uso: python avaliar_B37.py PASTA_RESULTADOS [--modo completo|fumaca]
Lê os checkpoints, aplica as regras congeladas no protocolo (§8) e grava PASTA/avaliacao_B37.json.
As funções classe_* recebem números simples (testadas em testar_avaliador_B37.py); extrair_* lê os checkpoints."""
import glob, json, os, sys
import numpy as np

# ---------------------------------------------------------------- limiares congelados
L_SEL, L_PAR = 10.0, 3.0            # L-T1: contrastes medianos
IND, DEP = 0.10, 0.30               # T2 (L e S): variação relativa mediana
DIL_A, DIL_B = 0.25, -0.75          # L-T2: inclinação de log δ em log M
T3_DIST_L, T3_INDIST_L = 1e-6, 1e-9  # L-T3: |ΔX|_F (base inteira)
T3_DIST_S, T3_INDIST_S = 1e-3, 1e-8  # S-T3: máx |Δ⟨O⟩|
POT2 = (1.6, 2.4)                   # inclinações "∝ g²" (Lamb, regra de ouro)
GLOBAL_M = 0.2                      # L-T3: |inclinação| de |ΔX|_F em M
LOCAL_M = (-1.3, -0.7)              # L-T3: inclinação de ΔS_região em M
FERMI = (0.8, 1.25)                 # Γ/Γ_Fermi em g = 0,1
PRES, PERD = 0.9, 0.5               # T4: marca retida
DS_TOL = 0.05                       # T4 L: |ΔS| (nats) no critério (ii)
FID_MIN = 0.9                       # T4 L: fidelidade (com fase livre) no critério (ii)
SEMFILA, FILA = (1.7, 2.3), 3.0     # L-T5: expoente do crescimento inicial
S_SEL = 1.5                         # S-T1
S_TERM = np.log(1.5)                # S-T7: |ln(ρ_diag/ρ_ETH)|
MIN_VALIDAS = 2.0 / 3.0             # fração mínima de amostras válidas
DN_MIN = 1e-4                       # S: ativação mínima para formar razões
EPS_N = 1e-5                        # S: piso dos denominadores
GAP_MIN = 1e-8                      # S: fundamental não degenerado
NORMA_TOL = 1e-8                    # S: deriva de norma
CTRL_L, CTRL_S = 1e-12, 1e-10       # controles com acoplamento desligado
VIZ_MIN = 5                         # S-T7: média (pesada pela população) de vizinhos na suavização ETH
PLATO_EST = (0.67, 1.5)             # L-T6: platô(0,05)/platô(0,02)
G_REF = 0.1
G_AJ_MIN = 0.03                     # L-T6: menor g no ajuste (g = 0,02 só relatado)
RAZAO_T6 = 1.5                      # S-T6: Δn_A(r=1)/Δn_A(r=0,3)
ACOPLA = 3.0                        # L×S T2: δ_S/δ_L


def med(x):
    x = [v for v in x if v is not None and np.isfinite(v)]
    return float(np.median(x)) if x else None


def incl(xs, ys):
    """inclinação log–log; None se faltar ponto ou houver valor ≤ 0."""
    if any(y is None or not np.isfinite(y) or y <= 0 for y in ys) or len(xs) < 2:
        return None
    return float(np.polyfit(np.log(xs), np.log(ys), 1)[0])


def dentro(x, ab):
    return x is not None and ab[0] <= x <= ab[1]


def spearman(x, y):
    from scipy.stats import rankdata
    if any(v is None for v in y) or len(x) < 3:
        return None
    rx, ry = rankdata(x), rankdata(y)
    if np.std(rx) == 0 or np.std(ry) == 0:
        return 0.0
    return float(np.corrcoef(rx, ry)[0, 1])


# ---------------------------------------------------------------- classes (números simples)
def classe_L_T1(c1, c2, n_esperado):
    """c1: contrastes min(A,C)/B no código 1 (um por semente); c2: B/max(A,C) no código 2."""
    v1 = [x for x in c1 if x is not None and np.isfinite(x)]; v2 = [x for x in c2 if x is not None and np.isfinite(x)]
    if n_esperado == 0 or min(len(v1), len(v2)) < MIN_VALIDAS * n_esperado:
        return 'INSUFICIENTE', None, None
    m1, m2 = med(v1), med(v2)
    if m1 >= L_SEL and m2 >= L_SEL:
        return 'SELETIVA', m1, m2
    if m1 >= L_PAR and m2 >= L_PAR:
        return 'PARCIAL', m1, m2
    return 'NAO_SELETIVA', m1, m2


def classe_T2(deltas, n_esperado):
    v = [x for x in deltas if x is not None and np.isfinite(x)]
    if n_esperado == 0 or len(v) < MIN_VALIDAS * n_esperado:
        return 'INSUFICIENTE', None
    m = med(v)
    if m <= IND:
        return 'INDEPENDENTE', m
    if m > DEP:
        return 'DEPENDENTE', m
    return 'INTERMEDIARIA', m


def classe_diluicao(Ms, meds):
    """inclinação s de log(mediana de δ) em log M: CRESCE s > 0,25 · NAO_DILUI |s| ≤ 0,25 ·
    DILUI_RAIZ −0,75 ≤ s < −0,25 (≈ M^−½) · DILUI_1_M s < −0,75."""
    s = incl(Ms, meds)
    if s is None:
        return 'INSUFICIENTE', None
    if s > DIL_A:
        return 'CRESCE', s
    if s >= -DIL_A:
        return 'NAO_DILUI', s
    if s >= DIL_B:
        return 'DILUI_RAIZ', s
    return 'DILUI_1_M', s


def classe_T3(valor, lim_dist, lim_indist):
    if valor is None or not np.isfinite(valor):
        return 'INSUFICIENTE'
    if valor >= lim_dist:
        return 'DISTINGUIVEL'
    if valor <= lim_indist:
        return 'INDISTINGUIVEL'
    return 'INSUFICIENTE'


def classe_L_T3_escala(gBs, dXg, Ms, dXM, dSM):
    """LAMB (∝ g²), GLOBAL (|ΔX|_F não cai com M), LOCAL (ΔS da região cai ~ 1/M) → MARCA_ONIPRESENTE se os três."""
    a, b, c = incl(gBs, dXg), incl(Ms, dXM), incl(Ms, dSM)
    if a is None or b is None or c is None:
        return 'INSUFICIENTE', a, b, c
    lamb, glob_, loc = dentro(a, POT2), abs(b) <= GLOBAL_M, dentro(c, LOCAL_M)
    if lamb and glob_ and loc:
        return 'MARCA_ONIPRESENTE', a, b, c
    if lamb:
        return 'LAMB_SEM_ONIPRESENCA', a, b, c
    return 'FORA_DE_LAMB', a, b, c


def classe_marca(R):
    if R is None or not np.isfinite(R):
        return 'INSUFICIENTE'
    if R >= PRES:
        return 'PRESERVADA'
    if R < PERD:
        return 'PERDIDA'
    return 'DEGRADADA'


def classe_ii(R, F, dS):
    """critério (ii) no modelo L: marca, estado reduzido (fidelidade com fase livre) e emaranhamento com a base."""
    if any(v is None or not np.isfinite(v) for v in (R, F, dS)):
        return 'INSUFICIENTE'
    if R >= PRES and F >= FID_MIN and abs(dS) <= DS_TOL:
        return 'PRESERVADA'
    if R < PERD:
        return 'PERDIDA'
    return 'DEGRADADA'


def classe_regra_de_ouro(gs, Gams, razao_ref):
    s = incl(gs, Gams)
    if s is None or razao_ref is None or not np.isfinite(razao_ref):
        return 'INSUFICIENTE', s
    if dentro(s, POT2) and dentro(razao_ref, FERMI):
        return 'REGRA_DE_OURO', s
    return 'FORA_DA_REGRA', s


def classe_L_T5(incl_A, incl_B, incl_C):
    ms = [med(incl_A), med(incl_B), med(incl_C)]
    if any(m is None for m in ms):
        return 'INSUFICIENTE', ms
    if all(dentro(m, SEMFILA) for m in ms):
        return 'SEM_FILA', ms
    if any(m >= FILA for m in ms):
        return 'COM_FILA', ms
    return 'INDEFINIDA', ms


def classe_plato(p002, p005, p02):
    if any(v is None or not np.isfinite(v) or v <= 0 for v in (p002, p005, p02)):
        return 'INSUFICIENTE'
    est = PLATO_EST[0] <= p005 / p002 <= PLATO_EST[1]
    sat = p02 < 0.5 * p005
    if est and sat:
        return 'RAPIDEZ_NAO_QUANTIDADE'
    if est:
        return 'QUANTIDADE_ESTAVEL_SEM_SATURACAO'
    return 'QUANTIDADE_VARIA'


def classe_S_T1(dn1, dn2, n_esperado):
    """dn1, dn2: listas de (Δn_B, Δn_AC) no fim do drive, códigos 1 e 2."""
    s1 = [ac / max(b, EPS_N) for b, ac in dn1 if ac is not None and b is not None and ac > DN_MIN]
    s2 = [b / max(ac, EPS_N) for b, ac in dn2 if ac is not None and b is not None and max(ac, b) > DN_MIN]
    if n_esperado == 0 or min(len(s1), len(s2)) < MIN_VALIDAS * n_esperado:
        return 'INSUFICIENTE', None, None
    m1, m2 = med(s1), med(s2)
    if m1 >= S_SEL and m2 >= S_SEL:
        return 'SELETIVA', m1, m2
    if m2 <= 1.0 / S_SEL:
        return 'NAO_SELETIVA', m1, m2
    return 'INDEFINIDA', m1, m2


def classe_S_T7(r1, r2, rho2_diag, n_esperado):
    """r1, r2: listas de ρ_diag/ρ_ETH (códigos 1 e 2); rho2_diag: ρ_diag do código 2."""
    v1 = [x for x in r1 if x is not None and np.isfinite(x) and x > 0]
    v2 = [x for x in r2 if x is not None and np.isfinite(x) and x > 0]
    if n_esperado == 0 or min(len(v1), len(v2)) < MIN_VALIDAS * n_esperado:
        return 'INSUFICIENTE', None, None
    l1, l2 = med([abs(np.log(x)) for x in v1]), med([abs(np.log(x)) for x in v2])
    if l1 <= S_TERM and l2 <= S_TERM:
        return 'TERMICA', l1, l2
    m2 = med(v2); b2 = med(rho2_diag)
    if m2 is not None and m2 >= 1.5 and b2 is not None and b2 >= 1.0:
        return 'MEMORIA', l1, l2
    return 'INTERMEDIARIO', l1, l2


def classe_S_T6(dn_baixo, dn_alto):
    """Δn_A (mediana, fim do drive, código 1) com prontidão r_A = 0,3 (baixo) e r_A = 1 (alto)."""
    if dn_baixo is None or dn_alto is None or not np.isfinite(dn_baixo) or not np.isfinite(dn_alto):
        return 'INSUFICIENTE', None
    if dn_baixo <= DN_MIN and dn_alto <= DN_MIN:
        return 'INSUFICIENTE', None
    q = dn_alto / max(dn_baixo, EPS_N)
    if q >= RAZAO_T6:
        return 'CRESCENTE', q
    if q <= 1.0 / RAZAO_T6:
        return 'DECRESCENTE', q
    return 'INDEFINIDA', q


def classe_LxS_T2(dL, dS):
    if dL is None or any(x is None for x in dS) or not dS:
        return 'INSUFICIENTE', None
    q = min(dS) / max(dL, 1e-12)
    return ('ACOPLAMENTO_MAIOR_NA_INTERAGENTE' if q >= ACOPLA else 'SEMELHANTE'), q


def classe_global_L(t1, t2, t3, t5):
    if t1 == 'INSUFICIENTE':
        return 'INSUFICIENTE'
    if t1 == 'NAO_SELETIVA':
        return 'NAO_SUSTENTADA'
    if t1 == 'SELETIVA' and t2 == 'INDEPENDENTE' and t3 == 'DISTINGUIVEL' and t5 == 'SEM_FILA':
        return 'SUSTENTADA'
    return 'PARCIAL'


def classe_global_S_N(t1, t7):
    if t1 == 'INSUFICIENTE' or t7 == 'INSUFICIENTE':
        return 'INSUFICIENTE'
    if t1 == 'SELETIVA':
        return 'CODIGO'
    if t1 == 'NAO_SELETIVA' and t7 == 'TERMICA':
        return 'CUSTO'
    return 'MISTA'


def classe_global_S(por_N):
    v = list(por_N.values())
    if not v or any(x == 'INSUFICIENTE' for x in v):
        return 'INSUFICIENTE'
    return v[0] if all(x == v[0] for x in v) else 'MISTA'


def classe_controle_N(t1_ctrl, t1_ref):
    if t1_ctrl in (None, 'INSUFICIENTE') or t1_ref in (None, 'INSUFICIENTE'):
        return 'INSUFICIENTE'
    return 'CONSISTENTE' if t1_ctrl == t1_ref else 'INCONSISTENTE'


def classe_LxS(gL, t1L, gS):
    if 'INSUFICIENTE' in (gL, t1L, gS):
        return 'INSUFICIENTE'
    if t1L == 'SELETIVA' and gS == 'CUSTO':
        return 'SEPARACAO'
    if (t1L == 'SELETIVA' and gS == 'CODIGO') or (t1L == 'NAO_SELETIVA' and gS == 'CUSTO'):
        return 'IGUAIS'
    return 'MISTA'


def classe_Q11(L, S):
    """L e S: dicts com 'D_off', 'D_on' (listas de classes por ε ou r), 'B_zero', 'B_cheio' (classes) e 'B_on' (lista)."""
    try:
        todos = [L['B_zero'], L['B_cheio'], S['B_zero'], S['B_cheio']] + L['D_off'] + L['D_on'] + S['D_off'] + S['D_on'] + L['B_on'] + S['B_on']
    except (KeyError, TypeError):
        return 'INSUFICIENTE'
    if any(c in (None, 'INSUFICIENTE') for c in todos):
        return 'INSUFICIENTE'
    ok = lambda X: (all(c == 'PRESERVADA' for c in X['D_off'] + X['D_on']) and X['B_zero'] == 'PRESERVADA'
                    and X['B_cheio'] == 'PERDIDA' and all(c == 'PERDIDA' for c in X['B_on']))
    if ok(L) and ok(S):
        return 'IDENTIDADE_POR_LACUNA'
    if L['D_cheio'] == 'PERDIDA' and S['D_cheio'] == 'PERDIDA':
        return 'SEM_PORTADOR'
    return 'MISTA'


# ---------------------------------------------------------------- extração dos checkpoints
def carregar(pasta):
    recs = []
    for f in sorted(glob.glob(os.path.join(pasta, '*_s*.json'))):
        recs.append(json.load(open(f)))
    cfg = json.load(open(os.path.join(pasta, 'config_B37.json')))
    return recs, cfg


def casos(rec, cod, s=None):
    return [c for c in rec['T1']['casos'] if c['codigo'] == cod and (s is None or c['sentido'] == s)]


def avaliar_L(recs, cfgL):
    out = {}
    Ms = cfgL['M']; nS = cfgL['n_sementes']
    porM = {M: [r for r in recs if r['parte'] == 'L' and r['M'] == M] for M in Ms}
    controle_ok = all(c.get('controle_desacoplado_max', 0.0) <= CTRL_L for rs in porM.values() for r in rs
                      for c in r['T1']['casos'] if c['codigo'] == '1')

    def por_M(M):
        rs = porM[M]; o = {}
        c1, c2, dl, ia, ib, ic = [], [], [], [], [], []
        for r in rs:
            p1 = np.mean([c['plato'] for c in casos(r, '1')], axis=0)     # média sobre os dois sentidos
            p2 = np.mean([c['plato'] for c in casos(r, '2')], axis=0)
            c1.append(min(p1[0], p1[2]) / p1[1] if p1[1] > 0 else None)
            c2.append(p2[1] / max(p2[0], p2[2]) if max(p2[0], p2[2]) > 0 else None)
            pa = np.mean([c['plato_B_ausente'] for c in casos(r, '1')], axis=0)
            for j in (0, 2):
                dl.append(abs(pa[j] - p1[j]) / p1[j] if p1[j] > 0 else None)
            for c in casos(r, '1') + casos(r, '2'):
                ia.append(c['inclinacao_inicial'][0]); ib.append(c['inclinacao_inicial'][1]); ic.append(c['inclinacao_inicial'][2])
        o['T1'] = classe_L_T1(c1, c2, nS)
        o['T2'] = classe_T2(dl, 2 * nS)
        dsist = [((np.mean([c['plato_B_ausente'] for c in casos(r, '1')], axis=0)[j] -
                   np.mean([c['plato'] for c in casos(r, '1')], axis=0)[j]) /
                  np.mean([c['plato'] for c in casos(r, '1')], axis=0)[j]) for r in rs for j in (0, 2)]
        o['T2_sistematico'] = (float(np.mean(dsist)), float(np.std(dsist) / np.sqrt(max(len(dsist), 1)))) if dsist else (None, None)
        o['T2_mediana'] = o['T2'][1]
        dX = {gB: med([q['dX_F'] for r in rs for q in r['T3'] if q['gB'] == gB]) for gB in (0.01, 0.03, 0.1)}
        dS = med([q['dS_reg'] for r in rs for q in r['T3'] if q['gB'] == G_REF])
        o['T3_dX'] = dX; o['T3_dS'] = dS
        o['T3'] = classe_T3(dX[G_REF], T3_DIST_L, T3_INDIST_L) if len(rs) >= MIN_VALIDAS * nS else 'INSUFICIENTE'
        o['T5'] = classe_L_T5(ia, ib, ic) if len(rs) >= MIN_VALIDAS * nS else ('INSUFICIENTE', None)
        fora = [max(np.mean([c['plato'] for c in casos(r, 'fora')], axis=0)[:3]) for r in rs]
        o['controle_fora'] = ('CONTROLE_OK' if fora and med(fora) <= 0.1 * med([min(np.mean([c['plato'] for c in casos(r, '1')], axis=0)[[0, 2]]) for r in rs])
                              else 'CONTROLE_FALHA') if rs else 'INSUFICIENTE'
        # T4
        t4 = {}
        for nome in ('B', 'D'):
            for eps in sorted(set(q['eps'] for r in rs for q in r['T4'])):
                qs = [q for r in rs for q in r['T4'] if q['nome'] == nome and q['eps'] == eps]
                R_off, R_on = med([q['R_off'] for q in qs]), med([q['R_on'] for q in qs])
                F_off = med([q['F_off'] for q in qs]); dS_ = med([q['S_off'] - q['S0'] for q in qs])
                t4['%s_%g' % (nome, eps)] = {'R_off': R_off, 'R_on': R_on, 'F_off': F_off, 'dS_off': dS_,
                                              'Gamma': med([q['Gamma'] for q in qs]), 'Gamma_Fermi': qs[0]['Gamma_Fermi'] if qs else None,
                                              'classe_off_ii': classe_ii(R_off, F_off, dS_), 'classe_on': classe_marca(R_on),
                                              'n': len(qs)}
        o['T4'] = t4
        epsB = [e for e in (0.01, 0.03, 0.1) if 'B_%g' % e in t4]
        GB = [t4['B_%g' % e]['Gamma'] for e in epsB]
        rr = (t4['B_%g' % G_REF]['Gamma'] / t4['B_%g' % G_REF]['Gamma_Fermi']) if ('B_%g' % G_REF in t4 and t4['B_%g' % G_REF]['Gamma']) else None
        o['T4_regra'] = classe_regra_de_ouro(epsB, GB, rr) + (rr,)
        # T6
        gAs = sorted(set(q['gA'] for r in rs for q in r['T6']))
        GA = {g: med([q['Gamma'] for r in rs for q in r['T6'] if q['gA'] == g]) for g in gAs}
        PA = {g: med([q['plato_A'] for r in rs for q in r['T6'] if q['gA'] == g]) for g in gAs}
        GF = {g: [q['Gamma_Fermi'] for r in rs for q in r['T6'] if q['gA'] == g][0] for g in gAs}
        fit = [g for g in gAs if G_AJ_MIN <= g <= G_REF]
        rr6 = GA[G_REF] / GF[G_REF] if G_REF in GA and GA[G_REF] else None
        o['T6'] = classe_regra_de_ouro(fit, [GA[g] for g in fit], rr6) + (rr6,)
        o['T6_plato'] = classe_plato(PA.get(0.02), PA.get(0.05), PA.get(0.2))
        o['T6_valores'] = {'Gamma': GA, 'plato_A': PA, 'Gamma_Fermi': GF}
        o['n_sementes'] = len(rs)
        return o

    for M in Ms:
        out['M%d' % M] = por_M(M)
    Md, Mc = cfgL['M_decisao'], cfgL['M_controle']
    d = out['M%d' % Md]
    out['T2_diluicao'] = classe_diluicao(Ms, [out['M%d' % M]['T2_mediana'] for M in Ms])
    out['T3_escala'] = classe_L_T3_escala([0.01, 0.03, 0.1], [d['T3_dX'][g] for g in (0.01, 0.03, 0.1)], Ms,
                                         [out['M%d' % M]['T3_dX'][G_REF] for M in Ms], [out['M%d' % M]['T3_dS'] for M in Ms])
    t5 = d['T5'][0]
    out['global'] = classe_global_L(d['T1'][0] if controle_ok else 'INSUFICIENTE', d['T2'][0], d['T3'], t5)
    c = out['M%d' % Mc]
    out['robustez_controle_M'] = {k: (d[k][0] if isinstance(d[k], tuple) else d[k]) == (c[k][0] if isinstance(c[k], tuple) else c[k])
                                  for k in ('T1', 'T2', 'T3', 'T5')}
    out['controle_desacoplado_ok'] = controle_ok
    t4 = d['T4']; epsL = sorted(set(float(k.split('_')[1]) for k in t4 if k.startswith('B_')))
    out['Q11'] = {'D_off': [t4['D_%g' % e]['classe_off_ii'] for e in epsL], 'D_on': [t4['D_%g' % e]['classe_on'] for e in epsL],
                  'B_zero': t4['B_0']['classe_off_ii'] if 'B_0' in t4 else None,
                  'B_cheio': t4['B_%g' % G_REF]['classe_off_ii'] if 'B_%g' % G_REF in t4 else None,
                  'D_cheio': t4['D_%g' % G_REF]['classe_off_ii'] if 'D_%g' % G_REF in t4 else None,
                  'B_on': [t4['B_%g' % e]['classe_on'] for e in epsL]}
    return out


def rho(dn):
    ac = 0.5 * (dn[0] + dn[2])
    return dn[1] / ac if ac > DN_MIN else None


def avaliar_S_N(recs, rotulo, n_sem):
    rs = [r for r in recs if r['parte'] == 'S' and r.get('rotulo') == rotulo]
    o = {'n_sementes': len(rs)}
    if rs and rs[0]['bateria'] == 'dimensionamento':
        o.update({'T1': ('NAO_SE_APLICA', None, None), 'T7': ('NAO_SE_APLICA', None, None), 'global': 'NAO_SE_APLICA',
                  'dimensionamento': {k: rs[0].get(k) for k in ('s_por_passo', 'nnz', 'dim_setor', 'norma_20_passos', 'mem_gb', 'gs')}})
        return o
    if not rs:
        o.update({'T1': ('INSUFICIENTE', None, None), 'T7': ('INSUFICIENTE', None, None), 'global': 'INSUFICIENTE'})
        return o
    validos = [r for r in rs if r['gs']['gap'] >= GAP_MIN and all(abs(q['norma'] - 1) <= NORMA_TOL for q in r['T1'])
               and r.get('controle_r0', {'max_abs_dn': 0.0})['max_abs_dn'] <= CTRL_S]
    o['sementes_validas'] = len(validos)
    nexp = 2 * n_sem
    dn = lambda q, jan: q['dn_' + jan]
    par = lambda q, jan: (dn(q, jan)[1], 0.5 * (dn(q, jan)[0] + dn(q, jan)[2]))
    T1c = lambda c: [q for r in validos for q in r['T1'] if q['codigo'] == c]
    o['T1'] = classe_S_T1([par(q, 'fim') for q in T1c(1)], [par(q, 'fim') for q in T1c(2)], nexp)
    o['T1_tardio'] = classe_S_T1([par(q, 'tardio') for q in T1c(1)], [par(q, 'tardio') for q in T1c(2)], nexp)
    if rs[0]['bateria'] != 'completa':
        o['T7'] = ('NAO_SE_APLICA', None, None)
        o['global'] = 'NAO_SE_APLICA'
        return o

    def razao_eth(q):
        if q.get('eth_vizinhos_medio', 0) < VIZ_MIN:
            return None
        a, b = rho(q['dn_diagonal']), rho(q['dn_eth'])
        return a / b if (a is not None and b is not None and b > 0) else None
    o['T7'] = classe_S_T7([razao_eth(q) for q in T1c(1)], [razao_eth(q) for q in T1c(2)],
                          [rho(q['dn_diagonal']) for q in T1c(2)], nexp)
    o['rho'] = {'fim_c1': med([rho(q['dn_fim']) for q in T1c(1)]), 'fim_c2': med([rho(q['dn_fim']) for q in T1c(2)]),
                'diag_c1': med([rho(q['dn_diagonal']) for q in T1c(1)]), 'diag_c2': med([rho(q['dn_diagonal']) for q in T1c(2)]),
                'eth_c1': med([rho(q['dn_eth']) for q in T1c(1)]), 'eth_c2': med([rho(q['dn_eth']) for q in T1c(2)]),
                'mc_0.4': med([rho(r['mc']['0.4']['dn']) for r in validos if r['mc']['0.4']['dn']]),
                'mc_0.8': med([rho(r['mc']['0.8']['dn']) for r in validos if r['mc']['0.8']['dn']]),
                'mc_1.6': med([rho(r['mc']['1.6']['dn']) for r in validos if r['mc']['1.6']['dn']]),
                'inj_c1': med([rho(q['dn_diag']) for r in validos for q in r['inj'] if q['codigo'] == 1 and q['dn_diag']]),
                'inj_c2': med([rho(q['dn_diag']) for r in validos for q in r['inj'] if q['codigo'] == 2 and q['dn_diag']]),
                'fora': med([rho(r['fora']['dn_fim']) for r in validos])}
    # T2
    dl = []
    for r in validos:
        if r['T2']['gs']['gap'] < GAP_MIN:
            continue
        for q in r['T1']:
            if q['codigo'] != 1:
                continue
            qd = [x for x in r['T2']['rodadas'] if x['sentido'] == q['sentido']][0]
            ac = 0.5 * (q['dn_fim'][0] + q['dn_fim'][2]); acd = 0.5 * (qd['dn_fim'][0] + qd['dn_fim'][2])
            dl.append(abs(acd - ac) / ac if ac > DN_MIN else None)
    o['T2'] = classe_T2(dl, nexp)
    o['T3_valor'] = med([float(np.max(np.abs(np.array(r['T3']['org']) - np.array(r['T3']['diss'])))) for r in validos])
    o['T3'] = classe_T3(o['T3_valor'], T3_DIST_S, T3_INDIST_S) if len(validos) >= MIN_VALIDAS * n_sem else 'INSUFICIENTE'
    t4 = {}
    for nome in ('B', 'D'):
        for k, rv in enumerate(validos[0]['T4'][nome] if validos else []):
            rr = rv['r']
            qs = [r['T4'][nome][k] for r in validos]
            t4['%s_%g' % (nome, rr)] = {'R_off': med([q['R_off'] for q in qs]), 'R_on': med([q['R_on'] for q in qs]),
                                        'R_inf': med([q['R_inf'] for q in qs]), 'Gamma': med([q['Gamma'] for q in qs]),
                                        'classe_off': classe_marca(med([q['R_off'] for q in qs])),
                                        'classe_on': classe_marca(med([q['R_on'] for q in qs]))}
    o['T4'] = t4
    rB = sorted(float(k.split('_')[1]) for k in t4 if k.startswith('B_'))
    o['T4_B_monotona'] = spearman(rB, [t4['B_%g' % r]['R_off'] for r in rB])
    o['T4_B_termalizada'] = (abs(t4['B_1']['R_off'] - t4['B_1']['R_inf']) <= 0.1 and t4['B_1']['R_inf'] < PRES) if 'B_1' in t4 else None
    t6 = {}
    for rA in sorted(set(q['rA'] for r in validos for q in r['T6'])):
        t6[rA] = med([q['dn_fim'][0] for r in validos for q in r['T6'] if q['rA'] == rA])
    t6[1.0] = med([q['dn_fim'][0] for q in T1c(1)])
    o['T6'] = classe_S_T6(t6.get(min(t6)) if t6 else None, t6.get(1.0)) + ({str(k): v for k, v in t6.items()},)
    o['global'] = classe_global_S_N(o['T1'][0], o['T7'][0])
    o['Q11'] = {'D_off': [t4['D_%g' % r]['classe_off'] for r in rB], 'D_on': [t4['D_%g' % r]['classe_on'] for r in rB],
                'B_zero': t4['B_0']['classe_off'] if 'B_0' in t4 else None, 'B_cheio': t4['B_1']['classe_off'] if 'B_1' in t4 else None,
                'D_cheio': t4['D_1']['classe_off'] if 'D_1' in t4 else None, 'B_on': [t4['B_%g' % r]['classe_on'] for r in rB]}
    return o


PREVISOES = {
    'L.global': 'SUSTENTADA', 'L.T1': 'SELETIVA', 'L.T2': 'INDEPENDENTE', 'L.T2_diluicao': 'DILUI_RAIZ', 'L.T3': 'DISTINGUIVEL',
    'L.T3_escala': 'MARCA_ONIPRESENTE', 'L.T4_regra': 'REGRA_DE_OURO', 'L.T5': 'SEM_FILA', 'L.T6': 'REGRA_DE_OURO',
    'L.T6_plato': 'RAPIDEZ_NAO_QUANTIDADE',
    'S.global': 'CUSTO', 'S.T1': 'NAO_SELETIVA', 'S.T7': 'TERMICA', 'S.T3': 'DISTINGUIVEL', 'S.T6': 'CRESCENTE',
    'S.controle_N28': 'CONSISTENTE', 'LxS': 'SEPARACAO', 'LxS_T2': 'ACOPLAMENTO_MAIOR_NA_INTERAGENTE',
    'Q11': 'IDENTIDADE_POR_LACUNA',
}


def avaliar(pasta):
    recs, cfg = carregar(pasta)
    return avaliar_recs(recs, cfg)


def avaliar_recs(recs, cfg):
    C = cfg['config']
    res = {'modo': cfg['modo']}
    res['L'] = avaliar_L(recs, C['L'])
    res['S'] = {}
    for rot in ('S20', 'S24', 'S28'):
        res['S'][rot] = avaliar_S_N(recs, rot, len(C[rot]['sementes']))
    decisao = {rot: res['S'][rot]['global'] for rot in ('S20', 'S24')}
    res['S']['global'] = classe_global_S(decisao)
    t1_28 = res['S']['S28']['T1'][0] if C['S28']['bateria'] == 'T1' else None
    res['S']['controle_N28'] = classe_controle_N(t1_28, res['S']['S24']['T1'][0]) if t1_28 is not None else 'NAO_SE_APLICA'
    Ld = res['L']['M%d' % C['L']['M_decisao']]
    res['LxS'] = classe_LxS(res['L']['global'], Ld['T1'][0], res['S']['global'])
    res['LxS_T2'] = classe_LxS_T2(Ld['T2'][1], [res['S'][r].get('T2', (None, None))[1] for r in ('S20', 'S24')])
    res['Q11'] = classe_Q11(res['L']['Q11'], res['S']['S24'].get('Q11')) if 'Q11' in res['S']['S24'] else 'INSUFICIENTE'
    res['Q11_N20'] = classe_Q11(res['L']['Q11'], res['S']['S20'].get('Q11')) if 'Q11' in res['S']['S20'] else 'INSUFICIENTE'
    obt = {'L.global': res['L']['global'], 'L.T1': Ld['T1'][0], 'L.T2': Ld['T2'][0], 'L.T2_diluicao': res['L']['T2_diluicao'][0],
           'L.T3': Ld['T3'], 'L.T3_escala': res['L']['T3_escala'][0], 'L.T4_regra': Ld['T4_regra'][0], 'L.T5': Ld['T5'][0],
           'L.T6': Ld['T6'][0], 'L.T6_plato': Ld['T6_plato'],
           'S.global': res['S']['global'],
           'S.T1': '/'.join(res['S'][r]['T1'][0] for r in ('S20', 'S24')),
           'S.T7': '/'.join(res['S'][r]['T7'][0] for r in ('S20', 'S24')),
           'S.T3': '/'.join(res['S'][r].get('T3', 'INSUFICIENTE') for r in ('S20', 'S24')),
           'S.T6': '/'.join(res['S'][r].get('T6', ('INSUFICIENTE',))[0] for r in ('S20', 'S24')),
           'S.controle_N28': res['S']['controle_N28'], 'LxS': res['LxS'], 'LxS_T2': res['LxS_T2'][0], 'Q11': res['Q11']}
    res['previsto_x_obtido'] = {k: {'previsto': PREVISOES[k], 'obtido': obt[k],
                                    'confere': all(x == PREVISOES[k] for x in obt[k].split('/'))} for k in PREVISOES}
    return res


def main():
    pasta = sys.argv[1]
    res = avaliar(pasta)
    json.dump(res, open(os.path.join(pasta, 'avaliacao_B37.json'), 'w'), indent=1, default=lambda o: o.tolist() if hasattr(o, 'tolist') else str(o))
    print('B37 — avaliação (%s)\n' % res['modo'])
    for k, v in res['previsto_x_obtido'].items():
        print('  %-16s previsto %-24s obtido %-30s %s' % (k, v['previsto'], v['obtido'], 'confere' if v['confere'] else 'NÃO confere'))


if __name__ == '__main__':
    main()
