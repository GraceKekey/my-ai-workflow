"""B37 — teste sintético do avaliador: todos os ramos de todas as classes, mais testes de ponta a ponta sobre a fumaça
(com perturbações que forçam INSUFICIENTE) e o caminho da bateria 'T1' (controle N = 28) num SYK minúsculo.
Uso: python testar_avaliador_B37.py PASTA_FUMACA"""
import copy, json, os, sys, tempfile
import numpy as np

AQUI = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, AQUI)
import avaliar_B37 as A

N_OK = 0


def confere(nome, obtido, esperado):
    global N_OK
    ob = obtido[0] if isinstance(obtido, tuple) else obtido
    if ob != esperado:
        raise AssertionError('%s: obtido %r, esperado %r' % (nome, obtido, esperado))
    N_OK += 1
    print('  ok  %-58s %s' % (nome, esperado))


def ramos():
    print('— classes')
    confere('L-T1 seletiva', A.classe_L_T1([20] * 5, [15] * 5, 5), 'SELETIVA')
    confere('L-T1 parcial', A.classe_L_T1([20] * 5, [5] * 5, 5), 'PARCIAL')
    confere('L-T1 não seletiva', A.classe_L_T1([2] * 5, [50] * 5, 5), 'NAO_SELETIVA')
    confere('L-T1 poucas válidas', A.classe_L_T1([20, None, np.nan, None, None], [15] * 5, 5), 'INSUFICIENTE')
    confere('L-T1 sem sementes', A.classe_L_T1([], [], 0), 'INSUFICIENTE')
    confere('T2 independente (limite 0,10)', A.classe_T2([0.10] * 4, 4), 'INDEPENDENTE')
    confere('T2 intermediária (limite 0,30)', A.classe_T2([0.30] * 4, 4), 'INTERMEDIARIA')
    confere('T2 dependente', A.classe_T2([0.5] * 4, 4), 'DEPENDENTE')
    confere('T2 insuficiente', A.classe_T2([0.05, None, None, None], 4), 'INSUFICIENTE')
    Ms = [400, 800, 1600, 3200]
    confere('L-T2 não dilui', A.classe_diluicao(Ms, [0.03] * 4), 'NAO_DILUI')
    confere('L-T2 cresce', A.classe_diluicao(Ms, [0.03 * (M / 400) for M in Ms]), 'CRESCE')
    confere('L-T2 dilui como 1/M', A.classe_diluicao(Ms, [0.03 * 400 / M for M in Ms]), 'DILUI_1_M')
    confere('L-T2 dilui como M^−½', A.classe_diluicao(Ms, [0.03 * (400 / M) ** 0.5 for M in Ms]), 'DILUI_RAIZ')
    confere('L-T2 limite −0,25 (raiz)', A.classe_diluicao([1, 2], [1.0, 2 ** -0.2500001]), 'DILUI_RAIZ')
    confere('L-T2 diluição insuficiente', A.classe_diluicao(Ms, [0.03, None, 0.03, 0.03]), 'INSUFICIENTE')
    confere('L-T3 distinguível', A.classe_T3(1e-3, A.T3_DIST_L, A.T3_INDIST_L), 'DISTINGUIVEL')
    confere('L-T3 indistinguível', A.classe_T3(1e-12, A.T3_DIST_L, A.T3_INDIST_L), 'INDISTINGUIVEL')
    confere('L-T3 zona cinzenta', A.classe_T3(1e-8, A.T3_DIST_L, A.T3_INDIST_L), 'INSUFICIENTE')
    confere('L-T3 nan', A.classe_T3(np.nan, A.T3_DIST_L, A.T3_INDIST_L), 'INSUFICIENTE')
    confere('S-T3 distinguível', A.classe_T3(0.2, A.T3_DIST_S, A.T3_INDIST_S), 'DISTINGUIVEL')
    confere('S-T3 indistinguível', A.classe_T3(1e-12, A.T3_DIST_S, A.T3_INDIST_S), 'INDISTINGUIVEL')
    confere('S-T3 zona cinzenta', A.classe_T3(1e-5, A.T3_DIST_S, A.T3_INDIST_S), 'INSUFICIENTE')
    gB = [0.01, 0.03, 0.1]
    dXg = [9e-4 * (g / 0.1) ** 2 for g in gB]
    confere('L-T3 marca onipresente', A.classe_L_T3_escala(gB, dXg, Ms, [9e-4] * 4, [4e-4 * 400 / M for M in Ms]), 'MARCA_ONIPRESENTE')
    confere('L-T3 Lamb, global diluindo', A.classe_L_T3_escala(gB, dXg, Ms, [9e-4 * 400 / M for M in Ms], [4e-4 * 400 / M for M in Ms]), 'LAMB_SEM_ONIPRESENCA')
    confere('L-T3 Lamb, local constante', A.classe_L_T3_escala(gB, dXg, Ms, [9e-4] * 4, [4e-4] * 4), 'LAMB_SEM_ONIPRESENCA')
    confere('L-T3 fora de Lamb', A.classe_L_T3_escala(gB, [9e-4 * (g / 0.1) for g in gB], Ms, [9e-4] * 4, [4e-4 * 400 / M for M in Ms]), 'FORA_DE_LAMB')
    confere('L-T3 escala insuficiente', A.classe_L_T3_escala(gB, [None, 1, 2], Ms, [9e-4] * 4, [1] * 4), 'INSUFICIENTE')
    confere('marca preservada (limite 0,9)', A.classe_marca(0.9), 'PRESERVADA')
    confere('marca degradada (limite 0,5)', A.classe_marca(0.5), 'DEGRADADA')
    confere('marca perdida', A.classe_marca(0.1), 'PERDIDA')
    confere('marca insuficiente', A.classe_marca(None), 'INSUFICIENTE')
    confere('critério (ii) preservada', A.classe_ii(0.99, 0.99, 0.001), 'PRESERVADA')
    confere('critério (ii) fidelidade baixa', A.classe_ii(0.95, 0.5, 0.0), 'DEGRADADA')
    confere('critério (ii) emaranhamento mudou', A.classe_ii(0.95, 0.99, 0.2), 'DEGRADADA')
    confere('critério (ii) perdida', A.classe_ii(0.1, 0.4, 0.0), 'PERDIDA')
    confere('critério (ii) insuficiente', A.classe_ii(0.95, None, 0.0), 'INSUFICIENTE')
    gs = [0.03, 0.05, 0.1]
    confere('regra de ouro', A.classe_regra_de_ouro(gs, [0.08 * (g / 0.1) ** 2 for g in gs], 1.05), 'REGRA_DE_OURO')
    confere('regra de ouro: inclinação errada', A.classe_regra_de_ouro(gs, [0.08 * (g / 0.1) for g in gs], 1.05), 'FORA_DA_REGRA')
    confere('regra de ouro: amplitude errada', A.classe_regra_de_ouro(gs, [0.08 * (g / 0.1) ** 2 for g in gs], 2.0), 'FORA_DA_REGRA')
    confere('regra de ouro: Γ ausente', A.classe_regra_de_ouro(gs, [None, 0.02, 0.08], 1.0), 'INSUFICIENTE')
    confere('regra de ouro: razão ausente', A.classe_regra_de_ouro(gs, [0.007, 0.02, 0.08], None), 'INSUFICIENTE')
    confere('L-T5 sem fila', A.classe_L_T5([2.0] * 6, [1.98] * 6, [2.01] * 6), 'SEM_FILA')
    confere('L-T5 com fila', A.classe_L_T5([2.0] * 6, [6.0] * 6, [2.0] * 6), 'COM_FILA')
    confere('L-T5 indefinida', A.classe_L_T5([2.0] * 6, [2.6] * 6, [2.0] * 6), 'INDEFINIDA')
    confere('L-T5 insuficiente', A.classe_L_T5([], [2.0], [2.0]), 'INSUFICIENTE')
    confere('L-T6 rapidez, não quantidade', A.classe_plato(0.0066, 0.0065, 0.0009), 'RAPIDEZ_NAO_QUANTIDADE')
    confere('L-T6 estável sem saturação', A.classe_plato(0.0066, 0.0065, 0.005), 'QUANTIDADE_ESTAVEL_SEM_SATURACAO')
    confere('L-T6 quantidade varia', A.classe_plato(0.002, 0.0065, 0.0009), 'QUANTIDADE_VARIA')
    confere('L-T6 platô insuficiente', A.classe_plato(None, 0.0065, 0.0009), 'INSUFICIENTE')
    sel1 = [(0.005, 0.03)] * 6; sel2 = [(0.03, 0.005)] * 6; ns2 = [(0.01, 0.03)] * 6
    confere('S-T1 seletiva', A.classe_S_T1(sel1, sel2, 6), 'SELETIVA')
    confere('S-T1 não seletiva', A.classe_S_T1(sel1, ns2, 6), 'NAO_SELETIVA')
    confere('S-T1 indefinida', A.classe_S_T1(sel1, [(0.02, 0.02)] * 6, 6), 'INDEFINIDA')
    confere('S-T1 B negativo no código 1 (piso)', A.classe_S_T1([(-0.001, 0.03)] * 6, ns2, 6), 'NAO_SELETIVA')
    confere('S-T1 sinal fraco demais', A.classe_S_T1([(0.0, 1e-6)] * 6, ns2, 6), 'INSUFICIENTE')
    confere('S-T7 térmica', A.classe_S_T7([1.1] * 6, [0.95] * 6, [0.35] * 6, 6), 'TERMICA')
    confere('S-T7 memória', A.classe_S_T7([1.1] * 6, [3.0] * 6, [1.2] * 6, 6), 'MEMORIA')
    confere('S-T7 intermediário (B não lidera)', A.classe_S_T7([1.1] * 6, [3.0] * 6, [0.6] * 6, 6), 'INTERMEDIARIO')
    confere('S-T7 intermediário (código 1 fora)', A.classe_S_T7([2.5] * 6, [1.0] * 6, [0.3] * 6, 6), 'INTERMEDIARIO')
    confere('S-T7 insuficiente', A.classe_S_T7([None] * 6, [1.0] * 6, [0.3] * 6, 6), 'INSUFICIENTE')
    confere('S-T6 crescente', A.classe_S_T6(0.02, 0.04), 'CRESCENTE')
    confere('S-T6 decrescente', A.classe_S_T6(0.04, 0.02), 'DECRESCENTE')
    confere('S-T6 indefinida', A.classe_S_T6(0.03, 0.035), 'INDEFINIDA')
    confere('S-T6 ausente', A.classe_S_T6(None, 0.035), 'INSUFICIENTE')
    confere('S-T6 sem ativação', A.classe_S_T6(1e-6, 1e-6), 'INSUFICIENTE')
    confere('L×S T2 acoplamento maior', A.classe_LxS_T2(0.03, [0.3, 0.2]), 'ACOPLAMENTO_MAIOR_NA_INTERAGENTE')
    confere('L×S T2 semelhante', A.classe_LxS_T2(0.03, [0.05, 0.2]), 'SEMELHANTE')
    confere('L×S T2 insuficiente', A.classe_LxS_T2(None, [0.3, 0.2]), 'INSUFICIENTE')
    confere('global L sustentada', A.classe_global_L('SELETIVA', 'INDEPENDENTE', 'DISTINGUIVEL', 'SEM_FILA'), 'SUSTENTADA')
    confere('global L parcial (T2)', A.classe_global_L('SELETIVA', 'DEPENDENTE', 'DISTINGUIVEL', 'SEM_FILA'), 'PARCIAL')
    confere('global L parcial (T1 parcial)', A.classe_global_L('PARCIAL', 'INDEPENDENTE', 'DISTINGUIVEL', 'SEM_FILA'), 'PARCIAL')
    confere('global L parcial (T5 insuficiente)', A.classe_global_L('SELETIVA', 'INDEPENDENTE', 'DISTINGUIVEL', 'INSUFICIENTE'), 'PARCIAL')
    confere('global L não sustentada', A.classe_global_L('NAO_SELETIVA', 'INDEPENDENTE', 'DISTINGUIVEL', 'SEM_FILA'), 'NAO_SUSTENTADA')
    confere('global L insuficiente', A.classe_global_L('INSUFICIENTE', 'INDEPENDENTE', 'DISTINGUIVEL', 'SEM_FILA'), 'INSUFICIENTE')
    confere('global S(N) custo', A.classe_global_S_N('NAO_SELETIVA', 'TERMICA'), 'CUSTO')
    confere('global S(N) código', A.classe_global_S_N('SELETIVA', 'TERMICA'), 'CODIGO')
    confere('global S(N) mista (memória)', A.classe_global_S_N('NAO_SELETIVA', 'MEMORIA'), 'MISTA')
    confere('global S(N) mista (indefinida)', A.classe_global_S_N('INDEFINIDA', 'TERMICA'), 'MISTA')
    confere('global S(N) insuficiente (T1)', A.classe_global_S_N('INSUFICIENTE', 'TERMICA'), 'INSUFICIENTE')
    confere('global S(N) insuficiente (T7)', A.classe_global_S_N('NAO_SELETIVA', 'INSUFICIENTE'), 'INSUFICIENTE')
    confere('global S iguais', A.classe_global_S({'S20': 'CUSTO', 'S24': 'CUSTO'}), 'CUSTO')
    confere('global S discordantes', A.classe_global_S({'S20': 'CUSTO', 'S24': 'MISTA'}), 'MISTA')
    confere('global S com insuficiente', A.classe_global_S({'S20': 'CUSTO', 'S24': 'INSUFICIENTE'}), 'INSUFICIENTE')
    confere('global S vazio', A.classe_global_S({}), 'INSUFICIENTE')
    confere('controle N=28 consistente', A.classe_controle_N('NAO_SELETIVA', 'NAO_SELETIVA'), 'CONSISTENTE')
    confere('controle N=28 inconsistente', A.classe_controle_N('INDEFINIDA', 'NAO_SELETIVA'), 'INCONSISTENTE')
    confere('controle N=28 insuficiente', A.classe_controle_N('INSUFICIENTE', 'NAO_SELETIVA'), 'INSUFICIENTE')
    confere('L×S separação', A.classe_LxS('SUSTENTADA', 'SELETIVA', 'CUSTO'), 'SEPARACAO')
    confere('L×S iguais (código)', A.classe_LxS('SUSTENTADA', 'SELETIVA', 'CODIGO'), 'IGUAIS')
    confere('L×S iguais (custo)', A.classe_LxS('NAO_SUSTENTADA', 'NAO_SELETIVA', 'CUSTO'), 'IGUAIS')
    confere('L×S mista', A.classe_LxS('PARCIAL', 'PARCIAL', 'CUSTO'), 'MISTA')
    confere('L×S insuficiente', A.classe_LxS('INSUFICIENTE', 'SELETIVA', 'CUSTO'), 'INSUFICIENTE')
    P, Pd, Pe = 'PRESERVADA', 'PERDIDA', 'DEGRADADA'
    boa = {'D_off': [P] * 4, 'D_on': [P] * 4, 'B_zero': P, 'B_cheio': Pd, 'D_cheio': P, 'B_on': [Pd] * 4}
    confere('Q11 identidade por lacuna', A.classe_Q11(boa, boa), 'IDENTIDADE_POR_LACUNA')
    sem = dict(boa, D_off=[Pd] * 4, D_cheio=Pd)
    confere('Q11 sem portador', A.classe_Q11(sem, sem), 'SEM_PORTADOR')
    confere('Q11 mista', A.classe_Q11(boa, dict(boa, B_on=[Pe] * 4)), 'MISTA')
    confere('Q11 classe insuficiente', A.classe_Q11(boa, dict(boa, B_zero='INSUFICIENTE')), 'INSUFICIENTE')
    confere('Q11 dados ausentes', A.classe_Q11(boa, None), 'INSUFICIENTE')


def ponta_a_ponta(pasta):
    print('— ponta a ponta (fumaça e perturbações)')
    recs, cfg = A.carregar(pasta)
    res = A.avaliar_recs(recs, cfg)
    for k in A.PREVISOES:
        assert k in res['previsto_x_obtido'], k
    confere('fumaça: todas as previsões avaliadas', ('OK',), 'OK')
    Md = cfg['config']['L']['M_decisao']
    r2 = copy.deepcopy(recs)
    for r in r2:
        if r['parte'] == 'L':
            for c in r['T1']['casos']:
                c['controle_desacoplado_max'] = 1.0
    confere('controle L falha → global L', A.avaliar_recs(r2, cfg)['L']['global'], 'INSUFICIENTE')
    r3 = [r for r in recs if not (r['parte'] == 'L' and r['M'] == Md)]
    o3 = A.avaliar_recs(r3, cfg)
    confere('sem L em M_decisão → global L', o3['L']['global'], 'INSUFICIENTE')
    confere('sem L em M_decisão → Q11', o3['Q11'], 'INSUFICIENTE')
    confere('sem L em M_decisão → L×S', o3['LxS'], 'INSUFICIENTE')
    r4 = copy.deepcopy(recs)
    for r in r4:
        if r['parte'] == 'S' and r.get('rotulo') == 'S24':
            r['gs']['gap'] = 0.0
    o4 = A.avaliar_recs(r4, cfg)
    confere('S24 degenerado → T1', o4['S']['S24']['T1'], 'INSUFICIENTE')
    confere('S24 degenerado → global S', o4['S']['global'], 'INSUFICIENTE')
    confere('S24 degenerado → Q11', o4['Q11'], 'INSUFICIENTE')
    r5 = copy.deepcopy(recs)
    for r in r5:
        if r['parte'] == 'S' and r.get('rotulo') == 'S24':
            r['controle_r0']['max_abs_dn'] = 1e-3
    confere('S24 controle r=0 falha → global S', A.avaliar_recs(r5, cfg)['S']['global'], 'INSUFICIENTE')
    r6 = copy.deepcopy(recs)
    for r in r6:
        if r['parte'] == 'S' and r.get('rotulo') == 'S24':
            r['T1'][0]['norma'] = 1.001
    confere('S24 norma fora → T1', A.avaliar_recs(r6, cfg)['S']['S24']['T1'], 'INSUFICIENTE')
    r7 = [r for r in recs if not (r['parte'] == 'S' and r.get('rotulo') == 'S20')]
    confere('sem S20 → global S', A.avaliar_recs(r7, cfg)['S']['global'], 'INSUFICIENTE')
    r8 = copy.deepcopy(recs)
    for r in r8:
        if r['parte'] == 'S' and r.get('rotulo') == 'S24':
            for q in r['T1']:
                q['eth_vizinhos_medio'] = 1.0
    confere('S24 poucos vizinhos ETH → T7', A.avaliar_recs(r8, cfg)['S']['S24']['T7'], 'INSUFICIENTE')


def caminho_T1():
    print('— caminho da bateria T1 (controle N = 28) num SYK com N = 12')
    import rodar_B37 as R
    with tempfile.TemporaryDirectory() as d:
        R.rodar_S('S28', {'N': 12, 'sementes': [5], 'bateria': 'T1'}, d, lambda m: None)
        recs = [json.load(open(os.path.join(d, f))) for f in os.listdir(d) if f.endswith('.json')]
        o = A.avaliar_S_N(recs, 'S28', 1)
        assert o['T1'][0] in ('SELETIVA', 'NAO_SELETIVA', 'INDEFINIDA', 'INSUFICIENTE')
        confere('bateria T1: T7 não se aplica', o['T7'], 'NAO_SE_APLICA')
        confere('bateria T1: classe de T1 calculada', ('OK' if o['T1'][0] != '' else 'X',), 'OK')


if __name__ == '__main__':
    ramos()
    ponta_a_ponta(sys.argv[1])
    caminho_T1()
    print('\nTODOS OS %d RAMOS CONFEREM' % N_OK)
