"""B37 — modelo L: base onipresente livre (gaussiana), sem espaço e sem junções.

Base: M osciladores (massa 1) com K_base = w0² I + (2 w0 λ/√M) W, W simétrica gaussiana (GOE, entradas N(0,1) fora da
diagonal após simetrização): todos acoplados com todos; modos espalhados por tudo; banda ω ≈ [1,41; 2,45].
GMFt i (A, B, C, D): um sítio extra com sintonia própria (K_ii = Ω_i²) acoplado a TODOS os sítios da base com
K_ik = 2 w0 g_i c_ik/√M (c_ik = ±1 fixos). g_i é a prontidão (o relé). Não há termo GMFt–GMFt.
"Ausente" (lâmpada fora do soquete) = g_i = 0: o sítio fica desacoplado, o que equivale a retirá-lo.
Sinal (telecomando): um quantum da base em saca-rolha, f = (u1 + i s u2)/√2, u1 e u2 = projeções de dois perfis aleatórios
da base nos modos da base com |ω − ω_código| ≤ Δ; s = ±1 é o sentido de giro.
Ativação do sítio i = número de excitações do oscilador local, n_i = ½ (Ω_i Δ⟨x_i²⟩ + Δ⟨p_i²⟩/Ω_i), Ω_i = √K_ii.
Marca (T4/T6) = deslocamento coerente |α|² = 1 no oscilador local do GMFt, sobre o vácuo vestido de K(g)."""
import numpy as np

W0 = 2.0
LAM = 0.25
G = 0.1
SINT = {'A': 1.9, 'B': 2.2, 'C': 1.9, 'D': 3.0}       # D fora da banda da base
CODIGO = {1: 1.9, 2: 2.2}
W_FORA = 1.6                                          # sinal fora de todas as sintonias (controle)
DELTA = 0.03                                          # meia largura da janela do código
NOMES = ['A', 'B', 'C', 'D']
J = {k: j for j, k in enumerate(NOMES)}
REGIAO = 40                                           # região local da base para T3 (primeiros 40 sítios)
TS_INICIAL = np.linspace(0.0, 2.0, 9)                 # T5: crescimento inicial n_i(t) − n_i(0) ∝ t^k para t ≤ 2


class Base:
    def __init__(self, M, seed):
        rng = np.random.default_rng(seed)
        Wm = rng.standard_normal((M, M)); Wm = (Wm + Wm.T) / np.sqrt(2.0)
        self.M = M
        self.Kb = W0 ** 2 * np.eye(M) + (2 * W0 * LAM / np.sqrt(M)) * Wm
        del Wm
        self.c = {k: rng.choice([-1.0, 1.0], M) for k in NOMES}
        eb, Vb = np.linalg.eigh(self.Kb)
        self.wb = np.sqrt(eb); self.Vb = Vb
        self.rng_sinal = np.random.default_rng(seed + 7919)

    def K(self, g, sint=SINT):
        """K completo (base + 4 sítios GMFt) para prontidões g = {nome: g_i}."""
        M = self.M; Kt = np.zeros((M + 4, M + 4))
        Kt[:M, :M] = self.Kb
        for j, k in enumerate(NOMES):
            Kt[M + j, M + j] = sint[k] ** 2
            col = (2 * W0 * g[k] / np.sqrt(M)) * self.c[k]
            Kt[:M, M + j] = col; Kt[M + j, :M] = col
        return Kt

    def perfis(self, w_s):
        """dois perfis (quadraturas) da base na janela |ω − w_s| ≤ Δ; devolve (u1, u2, n_modos)."""
        m = np.abs(self.wb - w_s) <= DELTA
        out = []
        for _ in range(2):
            r = self.rng_sinal.standard_normal(self.M)
            u = self.Vb[:, m] @ (self.Vb[:, m].T @ r)
            out.append(u / np.linalg.norm(u))
        return out[0], out[1], int(m.sum())


def saca_rolha(u1, u2, s):
    return np.concatenate([(u1 + 1j * s * u2) / np.sqrt(2.0), np.zeros(4)])


class Sistema:
    def __init__(self, Kt):
        w2, U = np.linalg.eigh(Kt)
        if w2[0] <= 0:
            raise ValueError('K não positiva')
        self.om = np.sqrt(w2); self.U = U; self.Kd = np.diag(Kt).copy(); self.N = len(w2)
        self.kmin = float(w2[0])

    def coef(self, u):
        f = self.U.T @ u
        return f / np.linalg.norm(f)

    def n_local(self, f, idx, ts):
        """n_i(t) de uma partícula com coeficientes f (modos normais), para os sítios idx: matriz (nt × len(idx))."""
        Ui = self.U[idx, :]
        Om = np.sqrt(self.Kd[idx])
        out = np.empty((len(ts), len(idx)))
        a = 0.5 * np.conj(f) / np.sqrt(self.om); b = 0.5 * np.conj(f) * np.sqrt(self.om)
        for k0 in range(0, len(ts), 200):
            tt = ts[k0:k0 + 200]
            ph = np.exp(1j * np.outer(tt, self.om))
            cth = (ph * a[None, :]) @ Ui.T
            cn = 1j * ((ph * b[None, :]) @ Ui.T)
            dx = 4 * np.abs(cth) ** 2; dp = 4 * np.abs(cn) ** 2
            out[k0:k0 + 200] = 0.5 * (Om[None, :] * dx + dp / Om[None, :])
        return out

    def plato(self, f, idx):
        """média temporal infinita de n_i (sem degenerescências): ½ Σ_k |U_ik f_k|² (Ω_i/ω_k + ω_k/Ω_i)."""
        out = []
        for i in idx:
            Om = np.sqrt(self.Kd[i]); w = np.abs(f) ** 2 * self.U[i, :] ** 2
            out.append(float(0.5 * np.sum(w * (Om / self.om + self.om / Om))))
        return np.array(out)

    def XP(self):
        X = (self.U * (0.5 / self.om)) @ self.U.T
        P = (self.U * (0.5 * self.om)) @ self.U.T
        return X, P

    def evolui_media(self, x0, p0, t):
        a = self.U.T @ x0; b = self.U.T @ p0
        c, s = np.cos(self.om * t), np.sin(self.om * t)
        return self.U @ (c * a + s / self.om * b), self.U @ (-self.om * s * a + c * b)

    def media_sitio(self, x0, p0, i, ts):
        """(x_i(t), p_i(t)) da evolução clássica da média, O(N) por instante (em blocos de tempo)."""
        a = self.U.T @ x0; b = self.U.T @ p0; ui = self.U[i, :]
        xa, xb = a * ui, b * ui / self.om; pa, pb = -self.om * a * ui, b * ui
        x = np.empty(len(ts)); p = np.empty(len(ts))
        for k0 in range(0, len(ts), 256):
            ph = np.outer(ts[k0:k0 + 256], self.om); c, s = np.cos(ph), np.sin(ph)
            x[k0:k0 + 256] = c @ xa + s @ xb
            p[k0:k0 + 256] = s @ pa + c @ pb
        return x, p

    def puxa_linha(self, rx, rp, t):
        """composição à esquerda: funcional rx·x(t) + rp·p(t) → funcional sobre (x(0), p(0))."""
        a = rx @ self.U; b = rp @ self.U
        c, s = np.cos(self.om * t), np.sin(self.om * t)
        return (a * c - b * self.om * s) @ self.U.T, (a * s / self.om + b * c) @ self.U.T


def entropia_gauss(Xa, Pa):
    w, Qm = np.linalg.eigh(Xa)
    w = np.clip(w, 1e-300, None)
    Xh = (Qm * np.sqrt(w)) @ Qm.T
    Mm = Xh @ Pa @ Xh; Mm = 0.5 * (Mm + Mm.T)
    nu = np.sqrt(np.clip(np.linalg.eigvalsh(Mm), 0.25, None))
    nu = np.maximum(nu, 0.5 + 1e-15)
    a, bb = nu + 0.5, nu - 0.5
    return float(np.sum(a * np.log(a) - np.where(bb > 0, bb * np.log(bb), 0.0)))


def entropia_modo(V):
    nu = np.sqrt(max(np.linalg.det(V), 0.25))
    if nu <= 0.5 + 1e-15:
        return 0.0
    return float((nu + 0.5) * np.log(nu + 0.5) - (nu - 0.5) * np.log(nu - 0.5))


def fidelidade_modo(V1, d1, V2, d2):
    """fidelidade entre dois estados gaussianos de um modo (vácuo = ½ I)."""
    Vs = V1 + V2
    Dl = np.linalg.det(Vs)
    dl = 4 * max(np.linalg.det(V1) - 0.25, 0.0) * max(np.linalg.det(V2) - 0.25, 0.0)
    d = d1 - d2
    return float(np.exp(-0.5 * d @ np.linalg.solve(Vs, d)) / (np.sqrt(Dl + dl) - np.sqrt(dl)))


def fidelidade_fase(V0, d0, V1, d1, Om, nth=360):
    """máximo da fidelidade sobre rotações livres do modo local (coordenadas escaladas √Ω x, p/√Ω)."""
    S = np.diag([np.sqrt(Om), 1 / np.sqrt(Om)])
    A0, a0 = S @ V0 @ S.T, S @ d0
    A1, a1 = S @ V1 @ S.T, S @ d1
    best = 0.0
    for th in np.linspace(0, 2 * np.pi, nth, endpoint=False):
        R = np.array([[np.cos(th), -np.sin(th)], [np.sin(th), np.cos(th)]])
        best = max(best, fidelidade_modo(A0, a0, R @ A1 @ R.T, R @ a1))
    return best


def gamma_ajuste(ts, R, lim=0.2):
    """taxa de perda da marca: ajuste de ln R do primeiro instante > 0 até o primeiro R < lim (≥ 5 pontos)."""
    ts = np.asarray(ts); R = np.asarray(R)
    if R[-1] >= 0.98:
        return None
    k = np.nonzero(R < lim)[0]
    fim = k[0] if len(k) else len(R)
    m = (ts > 0) & (np.arange(len(R)) < fim)
    if m.sum() < 5:
        return None
    return float(-np.polyfit(ts[m], np.log(R[m]), 1)[0])


def gamma_fermi(Om, g):
    """regra de ouro: Γ = 2π Σ_k |K_kB/(2√(ω_k Ω))|² δ(Ω − ω_k) = 8 W0² g² √(R_K² − (Ω² − W0²)²) / (Ω R_K²),
    com R_K = 4 W0 λ o raio do semicírculo de K_base e ⟨(c·v_k)²⟩ = 1. Zero fora da banda."""
    RK = 4 * W0 * LAM
    rad = RK ** 2 - (Om ** 2 - W0 ** 2) ** 2
    if rad <= 0:
        return 0.0
    return float(8 * W0 ** 2 * g ** 2 / (Om * RK ** 2) * np.sqrt(rad))


def g_padrao(**kw):
    g = {k: G for k in NOMES}
    g.update(kw)
    return g


# ---------------------------------------------------------------- testes do modelo L
def t_subida(ts, n, plat, frac):
    """primeiro instante em que n ≥ frac · platô (sem suavização); None se nunca."""
    k = np.nonzero(n >= frac * plat)[0]
    return float(ts[k[0]]) if len(k) else None


def T1_T2_T5(base, ts):
    """sinais nos códigos 1 e 2 (dois sentidos) e fora de todas as sintonias; B presente e ausente (código 1)."""
    M = base.M; idx = [M + j for j in range(4)]
    s0 = Sistema(base.K(g_padrao())); sB = Sistema(base.K(g_padrao(B=0.0))); s_off = Sistema(base.K(g_padrao(A=0.0, B=0.0, C=0.0, D=0.0)))
    out = {'casos': [], 'kmin': s0.kmin}
    for nome_c, w_s in (('1', CODIGO[1]), ('2', CODIGO[2]), ('fora', W_FORA)):
        u1, u2, nm = base.perfis(w_s)
        for s in (1, -1):
            u = saca_rolha(u1, u2, s); f = s0.coef(u)
            n = s0.n_local(f, idx, ts); pl = s0.plato(f, idx)
            ne = s0.n_local(f, idx, TS_INICIAL)
            incl = [float(np.polyfit(np.log(TS_INICIAL[1:]), np.log(np.abs(ne[1:, j] - ne[0, j]) + 1e-300), 1)[0])
                    for j in range(4)]
            caso = {'codigo': nome_c, 'sentido': s, 'modos_janela': nm, 'plato': pl.tolist(),
                    'media_tardia': n[ts >= 150].mean(0).tolist(), 'pico': n.max(0).tolist(),
                    'n_inicial': ne[0].tolist(), 'inclinacao_inicial': incl,
                    't10': [t_subida(ts, n[:, j], pl[j], 0.1) for j in range(4)],
                    'curva': n[::4].tolist()}
            if nome_c == '1':
                fB = sB.coef(u); caso['plato_B_ausente'] = sB.plato(fB, idx).tolist()
                fo = s_off.coef(u); caso['controle_desacoplado_max'] = float(s_off.n_local(fo, idx, ts).max())
            out['casos'].append(caso)
    out['ts_curva'] = ts[::4].tolist()
    return out


def T3(base, gBs=(0.01, 0.03, 0.1)):
    M = base.M; reg = list(range(REGIAO))
    sa = Sistema(base.K(g_padrao(B=0.0))); X0, P0 = sa.XP()
    S0 = entropia_gauss(X0[np.ix_(reg, reg)], P0[np.ix_(reg, reg)])
    E0 = 0.5 * float(np.sum(sa.om))
    out = []
    for gB in gBs:
        sp_ = Sistema(base.K(g_padrao(B=gB))); X, P = sp_.XP()
        dX = X[:M, :M] - X0[:M, :M]; dP = P[:M, :M] - P0[:M, :M]
        Sx = entropia_gauss(X[np.ix_(reg, reg)], P[np.ix_(reg, reg)])
        out.append({'gB': gB, 'dX_F': float(np.linalg.norm(dX)), 'dP_F': float(np.linalg.norm(dP)),
                    'dX_max': float(np.abs(dX).max()), 'dS_reg': float(abs(Sx - S0)), 'S_reg': S0,
                    'dE0': 0.5 * float(np.sum(sp_.om)) - E0})
    return out


def T4(base, eps_lista, T_off, T_on, ts_off, nomes=('B', 'D')):
    """T4 (Q11, critério ii): vácuo vestido de K(g) + marca coerente |α|² = 1 no GMFt; relé do GMFt → ε por T_off;
    volta a g por T_on. Mede a marca retida R, a fidelidade do estado reduzido (com fase livre) e a entropia do modo
    (emaranhamento com o resto) ao fim do apagamento (off) e depois de religar (on)."""
    M = base.M
    sG = Sistema(base.K(g_padrao())); X0, P0 = sG.XP()
    out = []
    for nome in nomes:
        i = M + J[nome]; Om = SINT[nome]
        x0 = np.zeros(M + 4); p0 = np.zeros(M + 4); x0[i] = np.sqrt(2.0 / Om)
        e = np.zeros(M + 4); e[i] = 1.0; z = np.zeros(M + 4)
        for eps in eps_lista:
            sE = sG if eps == G else Sistema(base.K(g_padrao(**{nome: eps})))
            xs, ps = sE.media_sitio(x0, p0, i, ts_off)
            R = 0.5 * (Om * xs ** 2 + ps ** 2 / Om)

            def reduzido(fases):
                lx = (e.copy(), z.copy()); lp = (z.copy(), e.copy())
                for sis, t in fases:                    # a fase mais recente primeiro
                    lx = sis.puxa_linha(lx[0], lx[1], t); lp = sis.puxa_linha(lp[0], lp[1], t)
                V = np.array([[lx[0] @ X0 @ lx[0] + lx[1] @ P0 @ lx[1], lx[0] @ X0 @ lp[0] + lx[1] @ P0 @ lp[1]],
                              [0.0, lp[0] @ X0 @ lp[0] + lp[1] @ P0 @ lp[1]]])
                V[1, 0] = V[0, 1]
                d = np.array([lx[0] @ x0 + lx[1] @ p0, lp[0] @ x0 + lp[1] @ p0])
                return V, d

            V0, d0 = reduzido([])
            Voff, doff = reduzido([(sE, T_off)])
            Von, don = reduzido([(sG, T_on), (sE, T_off)])
            r = lambda d: float(0.5 * (Om * d[0] ** 2 + d[1] ** 2 / Om))
            out.append({'nome': nome, 'eps': eps, 'R_t': R[::8].tolist(),
                        'R0': r(d0), 'R_off': r(doff), 'R_on': r(don),
                        'S0': entropia_modo(V0), 'S_off': entropia_modo(Voff), 'S_on': entropia_modo(Von),
                        'F_off': fidelidade_fase(V0, d0, Voff, doff, Om), 'F_on': fidelidade_fase(V0, d0, Von, don, Om),
                        'Gamma': gamma_ajuste(ts_off, R), 'Gamma_Fermi': gamma_fermi(Om, eps)})
    return out


def T6(base, gAs, ts_marca):
    """prontidão de A: taxa de perda da marca (Γ_A) e platô sob o código 1 (sentido +1)."""
    M = base.M; i = M + J['A']; Om = SINT['A']; idx = [M + j for j in range(4)]
    u1, u2, _ = base.perfis(CODIGO[1]); u = saca_rolha(u1, u2, 1)
    out = []
    for gA in gAs:
        s = Sistema(base.K(g_padrao(A=gA)))
        x0 = np.zeros(M + 4); p0 = np.zeros(M + 4); x0[i] = np.sqrt(2.0 / Om)
        xs, ps = s.media_sitio(x0, p0, i, ts_marca)
        R = 0.5 * (Om * xs ** 2 + ps ** 2 / Om)
        Gam = gamma_ajuste(ts_marca, R)
        f = s.coef(u)
        out.append({'gA': gA, 'Gamma': Gam, 'Gamma_Fermi': gamma_fermi(Om, gA), 'plato_A': float(s.plato(f, [i])[0])})
    return out
