"""B37 — modelo S: base onipresente interagente (SYK de Majoranas, q = 4, todos com todos).

N Majoranas χ_0..χ_{N−1} ({χ_a, χ_b} = δ_ab), representação de Jordan–Wigner em n = N/2 qubits (bit k = férmion k).
GMFt i (i = 0..3 → A, B, C, D) = o par (χ_{2i}, χ_{2i+1}) = o férmion complexo k = i, com n_i = bit i.
H = Σ_{a<b<c<d} J_abcd Π(prontidões dos GMFt tocados) χ_aχ_bχ_cχ_d + Σ_i Ω_i (n_i − ½),
J_abcd gaussianos com variância 3! J²/N³ (Kitaev–Maldacena–Stanford).
A base são os demais N − 8 Majoranas; o sinal só atua sobre eles. Prontidão r_i multiplica cada termo que toca o par i.
"Ausente" (dissolvido) = Ω_i = 0 e r_i = 1: o par volta a ser um férmion genérico da base.
H e o sinal conservam a paridade fermiônica; tudo é feito dentro do setor de paridade do estado em questão."""
import itertools
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as sla

J0 = 1.0
OM = [0.4, 0.8, 0.4, 3.0]          # A, C no código 1; B no código 2; D fora da banda
CODIGO = {1: 0.4, 2: 0.8}
W_FORA = 1.6
F_DRIVE = 0.05
T_D, T_TOT, DT, AMOSTRA = 40.0, 80.0, 0.1, 10
JAN_FIM = (30.0, 40.0)
JAN_TARDIA = (60.0, 80.0)
R_T4 = [0.0, 0.03, 0.1, 0.3, 1.0]
T_OFF, T_ON = 200.0, 10.0
R_T6 = [0.3, 0.6]
SIGMA_FILTRO = 0.1
LARG_MC = 0.1
_PC = np.array([bin(i).count('1') & 1 for i in range(1 << 16)], dtype=np.int8)


def paridade(x):
    x = np.asarray(x, dtype=np.int64)
    return _PC[x & 0xFFFF] ^ _PC[(x >> 16) & 0xFFFF]


def majorana(k_maj):
    """(máscara de troca, máscara Z, coeficiente) de χ_k: χ_{2k} = X_k Z_<k /√2 ; χ_{2k+1} = i X_k Z_k Z_<k /√2."""
    k = k_maj // 2; low = (1 << k) - 1
    if k_maj % 2 == 0:
        return (1 << k, low, 1 / np.sqrt(2))
    return (1 << k, low | (1 << k), 1j / np.sqrt(2))


def produto(a, b):
    f1, z1, c1 = a; f2, z2, c2 = b
    return (f1 ^ f2, z1 ^ z2, c1 * c2 * (-1) ** (bin(f2 & z1).count('1') & 1))


def operador(termos, dim):
    """termos: lista de (f, z, coef) → matriz esparsa Σ coef X^f Z^z (Z aplicado antes)."""
    b = np.arange(dim, dtype=np.int64)
    acc = {}
    for f, z, c in termos:
        s = (1 - 2 * paridade(b & z)).astype(float)
        acc[f] = acc.get(f, 0) + c * s
    rows, cols, vals = [], [], []
    for f, v in acc.items():
        rows.append(b ^ f); cols.append(b); vals.append(v)
    return sp.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(dim, dim))


class SYK:
    def __init__(self, N, seed, nG=4):
        self.N, self.nG = N, nG
        self.n = N // 2; self.dim = 1 << self.n
        rng = np.random.default_rng(seed)
        sig = np.sqrt(6.0) * J0 / N ** 1.5
        Mj = [majorana(a) for a in range(N)]
        grupos = {}
        for q in itertools.combinations(range(N), 4):
            Jq = rng.standard_normal() * sig
            toc = tuple(sorted(set(a // 2 for a in q if a < 2 * nG)))
            t = produto(produto(produto(Mj[q[0]], Mj[q[1]]), Mj[q[2]]), Mj[q[3]])
            grupos.setdefault(toc, []).append((t[0], t[1], Jq * t[2]))
        self.HS = {k: operador(v, self.dim) for k, v in grupos.items()}
        self.b = np.arange(self.dim, dtype=np.int64)
        self.par = paridade(self.b)
        self.nbits = [((self.b >> i) & 1).astype(float) for i in range(nG)]
        base = list(range(2 * nG, N))
        self.O = []
        for _ in range(2):
            termos = []
            for (a, c) in itertools.combinations(base, 2):
                f, z, cc = produto(Mj[a], Mj[c])
                termos.append((f, z, 1j * rng.standard_normal() * cc))
            Op = operador(termos, self.dim)
            Op = 0.5 * (Op + Op.getH())
            nrm = np.sqrt(abs((Op.multiply(Op.conj())).sum()) / self.dim)
            self.O.append((Op / nrm).tocsr())
        pares = list(itertools.combinations(base, 2))
        idx = rng.choice(len(pares), size=min(12, len(pares)), replace=False)
        self.obs_base = []
        for k in idx:
            a, c = pares[k]
            f, z, cc = produto(Mj[a], Mj[c])
            Ob = operador([(f, z, 1j * cc)], self.dim); self.obs_base.append((0.5 * (Ob + Ob.getH())).tocsr())
        self.idx = {p: np.nonzero(self.par == p)[0] for p in (0, 1)}

    def H(self, Om, r):
        Ht = None
        for toc, Hs in self.HS.items():
            fac = 1.0
            for i in toc:
                fac *= r[i]
            Ht = Hs * fac if Ht is None else Ht + Hs * fac
        diag = sum(Om[i] * (self.nbits[i] - 0.5) for i in range(self.nG))
        return (Ht + sp.diags(diag)).tocsr()

    def setor(self, A, p):
        ix = self.idx[p]
        return A[ix][:, ix].tocsr()

    def nb(self, p):
        ix = self.idx[p]
        return [v[ix] for v in self.nbits]

    def criar(self, k, psi_s, p):
        """c_k† aplicado a um vetor do setor p; devolve vetor do setor 1 − p."""
        full = np.zeros(self.dim, dtype=complex); full[self.idx[p]] = psi_s
        out = np.zeros_like(full)
        m = ((self.b >> k) & 1) == 0
        s = 1 - 2 * paridade(self.b & ((1 << k) - 1))
        out[self.b[m] | (1 << k)] = (s[m] * full[m])
        return out[self.idx[1 - p]]


def diag_setor(Hs, denso, k=2):
    if denso:
        return np.linalg.eigh(Hs.toarray())
    w, V = sla.eigsh(Hs, k=k, which='SA', tol=1e-12)
    o = np.argsort(w)
    return w[o], V[:, o]


def fundamental(model, H, denso):
    """estado fundamental pelos dois setores de paridade: {'p', 'E0', 'psi', 'gap', 'E', 'V'} (E, V do setor p se denso)."""
    res = {}
    for p in (0, 1):
        res[p] = diag_setor(model.setor(H, p), denso)
    p0 = 0 if res[0][0][0] <= res[1][0][0] else 1
    todos = np.sort(np.concatenate([res[0][0][:2], res[1][0][:2]]))
    E, V = res[p0]
    return {'p': p0, 'E0': float(E[0]), 'psi': V[:, 0].astype(complex), 'gap': float(todos[1] - todos[0]),
            'E': E if denso else None, 'V': V if denso else None, 'outro': res[1 - p0] if denso else None}


def ocup(nb, psi):
    p = np.abs(psi) ** 2
    return np.array([p @ v for v in nb])


def evoluir_drive(Hs, O1, O2, nb, psi, w_d, F, sentido, T_d=T_D, T_tot=T_TOT, dt=DT, amostras=AMOSTRA):
    """H(t) = H + F [cos(w t) O_1 + s·sin(w t) O_2] para t < T_d (s = ±1, sentido do saca-rolha); depois H livre.
    Passos de dt com H no ponto médio (expm_multiply). Devolve tempos, ocupações nas amostras, norma e ⟨H⟩ final."""
    ts, ns = [], []
    t = 0.0
    nsteps = int(round(T_tot / dt))
    for k in range(nsteps + 1):
        if k % amostras == 0:
            ts.append(t); ns.append(ocup(nb, psi))
        if k == nsteps:
            break
        tm = t + 0.5 * dt
        if tm < T_d:
            Ht = Hs + F * (np.cos(w_d * tm) * O1 + sentido * np.sin(w_d * tm) * O2)
        else:
            Ht = Hs
        psi = sla.expm_multiply(-1j * dt * Ht, psi)
        t += dt
    E = float(np.real(np.vdot(psi, Hs @ psi)))
    return np.array(ts), np.array(ns), float(np.linalg.norm(psi)), E, psi


def n_diag(V, nb):
    """⟨k|n_i|k⟩ para todos os autovetores (colunas de V)."""
    P = np.abs(V) ** 2
    return np.array([v @ P for v in nb])


def microcanonico(E, nd, n0, w, larg):
    """média uniforme de ⟨k|n_i|k⟩ − n0_i sobre os autoestados com |E_k − E_0 − w| ≤ larg (sem o fundamental)."""
    m = np.abs(E - E[0] - w) <= larg
    m[0] = False
    if m.sum() == 0:
        return None, 0
    return (nd[:, m].mean(1) - n0), int(m.sum())


def eth_suave(E, nd, larg):
    """⟨k|n_i|k⟩ suavizado: média sobre os autoestados l ≠ k com |E_l − E_k| ≤ larg (E crescente)."""
    cs = np.concatenate([np.zeros((nd.shape[0], 1)), np.cumsum(nd, axis=1)], axis=1)
    lo = np.searchsorted(E, E - larg, side='left'); hi = np.searchsorted(E, E + larg, side='right')
    cnt = hi - lo - 1
    soma = cs[:, hi] - cs[:, lo] - nd
    return np.where(cnt > 0, soma / np.maximum(cnt, 1), np.nan), cnt


def media_janela(ts, ns, jan):
    m = (ts >= jan[0] - 1e-9) & (ts <= jan[1] + 1e-9)
    return ns[m].mean(0)


# ---------------------------------------------------------------- testes do modelo S
def rodada_drive(model, gs, w, s, extra_termico, dt=DT):
    p = gs['p']; Hs = model.setor(gs['H'], p); nb = model.nb(p)
    O1, O2 = model.setor(model.O[0], p), model.setor(model.O[1], p)
    n0 = ocup(nb, gs['psi'])
    ts, ns, nrm, Efin, psi = evoluir_drive(Hs, O1, O2, nb, gs['psi'], w, F_DRIVE, s, dt=dt, amostras=int(round(1.0 / dt)))
    d = ns - n0
    out = {'w': w, 'sentido': s, 'norma': nrm, 'dE': Efin - gs['E0'],
           'dn_fim': media_janela(ts, d, JAN_FIM).tolist(), 'dn_tardio': media_janela(ts, d, JAN_TARDIA).tolist(),
           'curva': d.tolist(), 'ts': ts.tolist()}
    if extra_termico and gs.get('E') is not None:
        nd = n_diag(gs['V'], nb)
        c = gs['V'].conj().T @ psi
        out['dn_diagonal'] = (nd @ (np.abs(c) ** 2) - n0).tolist()
        pk = np.abs(c) ** 2; pk[0] = 0.0
        nds, cnt = eth_suave(gs['E'], nd, LARG_MC)
        ok = (cnt > 0); ok[0] = False
        out['dn_eth'] = ((nds[:, ok] - n0[:, None]) @ pk[ok]).tolist()
        out['eth_vizinhos_medio'] = float((cnt[ok] @ pk[ok]) / pk[ok].sum()) if pk[ok].sum() > 0 else 0.0
        out['peso_excitado'] = float(pk.sum())
        out['energia_media_excitada'] = float((pk @ (gs['E'] - gs['E0'])) / max(pk.sum(), 1e-300))
    return out


def injecao_filtrada(model, gs, w, s, sigma=SIGMA_FILTRO):
    p = gs['p']; nb = model.nb(p)
    O1, O2 = model.setor(model.O[0], p), model.setor(model.O[1], p)
    phi = O1 @ gs['psi'] + 1j * s * (O2 @ gs['psi'])
    c = gs['V'].conj().T @ phi
    c = c * np.exp(-(gs['E'] - gs['E0'] - w) ** 2 / (2 * sigma ** 2))
    nrm = np.linalg.norm(c)
    if nrm < 1e-14:
        return {'w': w, 'sentido': s, 'peso': 0.0, 'dn0': None, 'dn_diag': None, 'dE': None}
    c /= nrm
    n0 = ocup(nb, gs['psi'])
    psi_f = gs['V'] @ c
    nd = n_diag(gs['V'], nb)
    return {'w': w, 'sentido': s, 'peso': float(nrm / np.linalg.norm(phi)), 'dn0': (ocup(nb, psi_f) - n0).tolist(),
            'dn_diag': (nd @ (np.abs(c) ** 2) - n0).tolist(), 'dE': float((np.abs(c) ** 2) @ gs['E'] - gs['E0'])}


def marca(model, gs1, i, r_vals, ts):
    """T4: vácuo de H(1) (organizado, relé fechado) + c_i† ; relé de i → r por T_OFF ; volta a 1 por T_ON."""
    p0 = gs1['p']; p1 = 1 - p0
    nb0 = model.nb(p0); nb1 = model.nb(p1)
    n0 = ocup(nb0, gs1['psi'])[i]
    psi_m = model.criar(i, gs1['psi'], p0); psi_m /= np.linalg.norm(psi_m)
    E1, V1 = gs1['outro']                      # H(1) no setor 1 − p0
    out = []
    for r in r_vals:
        rr = [1.0, 1.0, 1.0, 1.0]; rr[i] = r
        if r == 1.0:
            Er, Vr = E1, V1
        else:
            Er, Vr = np.linalg.eigh(model.setor(model.H(OM, rr), p1).toarray())
        c = Vr.conj().T @ psi_m
        ni = []
        for t in ts:
            ps = Vr @ (c * np.exp(-1j * Er * t)); ni.append((np.abs(ps) ** 2) @ nb1[i])
        ni = np.array(ni)
        ndg = float((np.abs(Vr) ** 2).T @ nb1[i] @ (np.abs(c) ** 2))
        ps_off = Vr @ (c * np.exp(-1j * Er * T_OFF))
        c1 = V1.conj().T @ ps_off
        ps_on = V1 @ (c1 * np.exp(-1j * E1 * T_ON))
        n_on = float((np.abs(ps_on) ** 2) @ nb1[i])
        n_off = float((np.abs(ps_off) ** 2) @ nb1[i])
        R = (ni - n0) / (ni[0] - n0)
        Rinf = (ndg - n0) / (ni[0] - n0)
        out.append({'r': r, 'n_vac': float(n0), 'n_t': ni.tolist(), 'R_t': R.tolist(), 'R_inf': float(Rinf),
                    'Gamma': gamma_marca(ts, R, float(Rinf)),
                    'R_off': float((n_off - n0) / (ni[0] - n0)), 'R_on': float((n_on - n0) / (ni[0] - n0)),
                    'F_off': n_off, 'S_off': h2(n_off), 'S_on': h2(n_on)})
    return out


def gamma_marca(ts, R, Rinf):
    """taxa de perda da marca: ajuste de ln((R − R∞)/(1 − R∞)) nos pontos com valor normalizado em [0,3; 0,97]."""
    if Rinf is None or Rinf >= 0.98:
        return None
    y = (np.asarray(R) - Rinf) / (1 - Rinf)
    m = (y >= 0.3) & (y <= 0.97) & (np.asarray(ts) > 0)
    k = np.nonzero(y < 0.3)[0]
    if len(k):
        m &= np.arange(len(y)) < k[0]
    if m.sum() < 5:
        return None
    return float(-np.polyfit(np.asarray(ts)[m], np.log(y[m]), 1)[0])


def h2(x):
    x = min(max(x, 0.0), 1.0)
    return float(-sum(v * np.log(v) for v in (x, 1 - x) if v > 0))


def obs_vacuo(model, gs):
    p = gs['p']
    return [float(np.real(np.vdot(gs['psi'], model.setor(O, p) @ gs['psi']))) for O in model.obs_base]
