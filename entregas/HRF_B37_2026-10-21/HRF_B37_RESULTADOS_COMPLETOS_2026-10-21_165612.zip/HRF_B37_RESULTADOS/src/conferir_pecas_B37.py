"""B37 — conferência das peças (rodada junto com a fumaça). Uso: python conferir_pecas_B37.py"""
import itertools, sys, os, time
import numpy as np
import scipy.sparse.linalg as sla

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import b37_livre as L
import b37_syk as S


def linha(nome, valor):
    print('%-72s %s' % (nome, valor))


# ---------------------------------------------------------------- SYK
Mj = [S.majorana(a) for a in range(8)]
dim = 1 << 4
ops = [S.operador([m], dim).toarray() for m in Mj]
err = max(np.abs(ops[a] @ ops[b] + ops[b] @ ops[a] - (a == b) * np.eye(dim)).max() for a in range(8) for b in range(8))
linha('Majoranas (N = 8): máx |{χ_a, χ_b} − δ_ab|', '%.1e' % err)
m = S.SYK(16, 11)
H = m.H(S.OM, [1, 1, 1, 1])
linha('SYK N = 16: máx |H − H†|', '%.1e' % abs(H - H.getH()).max())
linha('SYK N = 16: máx |O_k − O_k†| ; Tr O_k²/dim', '%.1e ; %.6f , %.6f' % (max(abs(O - O.getH()).max() for O in m.O),
      *[float(np.real((O @ O).diagonal().sum()) / m.dim) for O in m.O]))
P = np.diag(1 - 2 * m.par.astype(float))
linha('SYK N = 16: máx |[H, paridade]| ; máx |[O_k, paridade]|', '%.1e ; %.1e' % (np.abs(H.toarray() @ P - P @ H.toarray()).max(),
      max(np.abs(O.toarray() @ P - P @ O.toarray()).max() for O in m.O)))
w_full = np.linalg.eigvalsh(H.toarray())
gs = S.fundamental(m, H, True)
gs2 = S.fundamental(m, H, False)
linha('SYK N = 16: E0 (espaço inteiro) × setores denso × Krylov', '%.12f ; %.12f ; %.12f' % (w_full[0], gs['E0'], gs2['E0']))
psi_c = m.criar(1, gs['psi'], gs['p'])
nb1 = m.nb(1 - gs['p'])
linha('SYK N = 16: n_B depois de c_B† (normalizado)', '%.12f' % ((np.abs(psi_c) ** 2 @ nb1[1]) / np.linalg.norm(psi_c) ** 2))
H0 = m.H(S.OM, [0, 0, 0, 0])
g0 = S.fundamental(m, H0, True)
linha('SYK N = 16: r = 0 → ocupações do fundamental (deve ser 0 ou 1 exato)', np.round(S.ocup(m.nb(g0['p']), g0['psi']), 12))
for dt in (0.1, 0.05):
    gs['H'] = H
    q = S.rodada_drive(m, gs, 0.4, 1, False, dt=dt)
    linha('SYK N = 16: drive código 1, dt = %g → Δn fim do drive' % dt, np.round(q['dn_fim'], 6))
Hs = m.setor(H, gs['p'])
E, V = np.linalg.eigh(Hs.toarray())
nd = S.n_diag(V, m.nb(gs['p']))
nds, cnt = S.eth_suave(E, nd, S.LARG_MC)
k = len(E) // 2
manual = np.mean([nd[:, l] for l in range(len(E)) if l != k and abs(E[l] - E[k]) <= S.LARG_MC], axis=0)
linha('SYK N = 16: suavização ETH × média direta (estado do meio)', '%.1e' % np.abs(nds[:, k] - manual).max())

# ---------------------------------------------------------------- L
b = L.Base(400, 5)
s0 = L.Sistema(b.K(L.g_padrao()))
linha('L M = 400: menor autovalor de K (deve ser > 0)', '%.4f' % s0.kmin)
linha('L M = 400: banda da base em ω', '[%.3f; %.3f]' % (b.wb.min(), b.wb.max()))
X, P_ = s0.XP()
linha('L M = 400: menor √(⟨x_i²⟩⟨p_i²⟩) local (deve ser ≥ 0,5)', '%.6f' % np.sqrt(np.diag(X) * np.diag(P_)).min())
u1, u2, nm = b.perfis(L.CODIGO[1])
f = s0.coef(L.saca_rolha(u1, u2, 1))
idx = [400 + j for j in range(4)]
ts = np.linspace(0, 3000, 30001)
n = s0.n_local(f, idx, ts)
linha('L M = 400: platô exato × média de n(t) em [0; 3000] (A, C)', '%s × %s' % (np.round(s0.plato(f, idx)[[0, 2]], 6), np.round(n.mean(0)[[0, 2]], 6)))
V0 = np.array([[0.7, 0.1], [0.1, 0.6]]); d0 = np.array([0.3, -0.2])
linha('L: fidelidade gaussiana de um estado consigo mesmo', '%.12f' % L.fidelidade_modo(V0, d0, V0, d0))
linha('L: fidelidade de coerentes |α|²=1 × vácuo (deve ser e^{−1})', '%.12f × %.12f' % (L.fidelidade_modo(0.5 * np.eye(2), np.array([np.sqrt(2), 0]), 0.5 * np.eye(2), np.zeros(2)), np.exp(-1)))
q = L.T4(b, [0.0], 400.0, 40.0, np.linspace(0, 400, 1601), nomes=('B',))[0]
linha('L M = 400: T4 com ε = 0 → R_off, F_off, S_off − S0 (devem ser 1, 1, 0)', '%.12f , %.12f , %.1e' % (q['R_off'], q['F_off'], q['S_off'] - q['S0']))
sB = L.Sistema(b.K(L.g_padrao(B=0.0)))
x0 = np.zeros(404); x0[401] = 1.0; p0 = np.zeros(404)
xt, pt = sB.evolui_media(x0, p0, 7.3)
linha('L M = 400: B desacoplado gira livre (x_B(t) − cos Ω t)', '%.1e' % abs(xt[401] - np.cos(2.2 * 7.3)))
linha('L: Γ_Fermi(B, g = 0,1) ; Γ_Fermi(A, g = 0,1) ; Γ_Fermi(D, g = 0,1)', '%.4f ; %.4f ; %.4f' % (L.gamma_fermi(2.2, 0.1), L.gamma_fermi(1.9, 0.1), L.gamma_fermi(3.0, 0.1)))
