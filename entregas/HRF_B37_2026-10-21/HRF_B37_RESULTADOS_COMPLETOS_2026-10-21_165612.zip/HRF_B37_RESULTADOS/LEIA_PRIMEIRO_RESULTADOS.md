# HRF B37 — Resultados

Relatório: HRF_B37_RELATORIO_2026-10-21_165612.md

L: SUSTENTADA; S: CUSTO; L×S: SEPARACAO; Q11: IDENTIDADE_POR_LACUNA.

Resultados desta rodada: resultados/. Fumaça e entradas são antecedentes.
