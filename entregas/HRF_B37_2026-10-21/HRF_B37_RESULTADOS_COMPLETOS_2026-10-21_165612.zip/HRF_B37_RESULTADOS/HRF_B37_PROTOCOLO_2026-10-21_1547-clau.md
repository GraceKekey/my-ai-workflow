# HRF B37 — A base onipresente: a rede da cidade acende as lâmpadas pelo código?
## Seleção, independência, sombreado, fila e identidade (Q11) numa base livre e numa base SYK — protocolo pré-registrado

**Data:** 21 de outubro de 2026 (America/Sao_Paulo) — Claude (`-clau`) · fluxo ímpar
**Autoria:** Mario José do Canto Filho, MD · desenho, código e fumaça: Claude
**Decisões de Mario que fixam esta bancada (21/10):**
- 13h49 — **decisão (2): a base está em tudo ao mesmo tempo, sem junções.** A regra da QG original, em que as relações
  só interagem onde se encontram num vértice, fica fora da arquitetura da vertente Ola. Com junções, a base ganha
  "caminhos" internos e volta a ideia de algo passando de um GMFt para outro. Atualiza a nota de arquitetura de 11h49
  nesse ponto.
- 14h05 — testar duas versões de base onipresente: a **livre** (gaussiana) e a **interagente** (SYK). Imagem de trabalho:
  a base é a rede elétrica de uma cidade, sempre ligada; cada GMFt é uma lâmpada ligada à rede por uma caixa de luz, com
  um interruptor no meio.
- 14h08 — começar pelo mais simples: o interruptor é um relé sintonizado pela própria base, e a prontidão de cada GMFt
  fica fixa.
- 14h57 — "Sim" ao esboço v0.1 (14h24) e às quatro decisões propostas:
  - 4 GMFt (A, B, C, D), com D sintonizado fora da banda;
  - SYK com N = 20 e 24 como decisão e N = 28 (Krylov) como controle;
  - telecomando periódico como sinal principal e injeção filtrada como controle;
  - Q11 (critério ii) dentro da B37, no T4.

**Nada roda sem "pode rodar".**
**Vertente:** HRF-OLA. Antecedentes: esboço da B37 v0.1 (21/10, 14h24); relatório da B35 (21/10, 13h03); nota de
arquitetura da base (21/10, 11h49).

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 0. Arquitetura usada [D, 21/10]

| Termo | Nesta bancada |
|---|---|
| **base** | Graus de liberdade acoplados todos com todos, sem espaço e sem junções (decisão 2). L: osciladores com acoplamento aleatório do tipo GOE. S: férmions de Majorana com a interação SYK de 4 corpos. |
| **GMFt** | Uma organização com sintonia própria (a caixa) e prontidão (o relé). L: um sítio extra acoplado a **todos** os sítios da base. S: um par de Majoranas **da própria base** com energia Ω (n − ½). Não há termo GMFt–GMFt. |
| **sinal (telecomando)** | L: um quantum da base numa janela estreita de frequência (o código), em saca-rolha. S: um drive periódico em saca-rolha sobre bilineares da base, na frequência do código. O sinal nunca toca os GMFt diretamente. |
| **aceso** | Número de excitações locais do GMFt acima do vácuo. |
| **sombreado** | GMFt presente, organizado e ligado à base, que não responde ao sinal (fora do código). |
| **ausente** | L: prontidão zero (a lâmpada fora do soquete; o sítio sai da base). S: dissolvido (Ω = 0, r = 1): o par volta a ser um férmion genérico da base, sem perder graus de liberdade. |
| **marca** | A "informação própria" do GMFt. L: deslocamento coerente com \|α\|² = 1 no oscilador local. S: c_B† aplicado ao vácuo. |
| **ciclo (Q11)** | O relé do GMFt vai a ε (ou r) por um tempo T_off e depois volta à prontidão normal por T_on. |
| **critério (ii)** | A identidade persiste se o estado reduzido do GMFt e o seu emaranhamento com a base voltam iguais depois do ciclo. |

O nome GMFt vale só para a vertente Ola. Os GMFs históricos ficam como estão.

## 1. Objetivo

Numa base onipresente (sem espaço, sem junções, sem caminhos internos), medir:
- **T1, seleção por código:** o sinal no código 1 acende A e C e deixa B escuro? O código 2 acende B?
- **T2, independência:** tornar B ausente muda A e C? Quanto, e como escala com o tamanho da base?
- **T3, sombreado × ausente:** a base distingue B presente-e-sombreado de B ausente? A marca de B fica concentrada ou
  espalhada?
- **T4, identidade (Q11, critério ii):** a marca de B (e de D) sobrevive a um ciclo apagar/religar? O que a protege?
- **T5, sem fila:** todos os GMFt começam a sentir o sinal no mesmo instante?
- **T6, prontidão:** a prontidão controla a rapidez ou a quantidade de ativação?
- **T7, embaralhamento (só S):** depois do caos da base, a ativação ainda lembra o código?

E comparar as duas bases (**L × S**): a livre e a interagente selecionam do mesmo jeito?

## 2. Modelos

### 2.1 L — base onipresente livre [M]

- **Hamiltoniano:** H = ½ Σ p² + ½ xᵀ K x (massa 1).
  - Base: K_base = W0² I + (2 W0 λ/√M) W, com W = (G + Gᵀ)/√2 e G gaussiana N(0, 1).
  - O espectro de K_base é um semicírculo de raio R_K = 4 W0 λ em torno de W0². A banda é ω ∈ [1,41; 2,45].
  - GMFt i: sítio extra com K_ii = Ω_i² e K_ik = 2 W0 g_i c_ik/√M para **todo** sítio k da base (c_ik = ±1 fixos).
- **Parâmetros:** W0 = 2, λ = 0,25, g = 0,1.
  - Sintonias: Ω_A = Ω_C = 1,9 (código 1), Ω_B = 2,2 (código 2), Ω_D = 3,0 (fora da banda).
- **Sinal:** um quantum com coeficientes de modo normal f = Uᵀ u, onde u = (u₁ + i s u₂)/√2.
  - u₁ e u₂ são projeções de dois perfis aleatórios da base nos modos da base com |ω − ω_código| ≤ Δ = 0,03.
  - s = ±1 é o sentido do saca-rolha.
  - Códigos: ω₁ = 1,9 e ω₂ = 2,2. Controle "fora": ω = 1,6.
- **Ativação:** n_i(t) = ½ (Ω_i Δ⟨x_i²⟩ + Δ⟨p_i²⟩/Ω_i), com Ω_i = √K_ii. Platô exato (média temporal infinita):
  n_i^∞ = ½ Σ_k |U_ik f_k|² (Ω_i/ω_k + ω_k/Ω_i).
- **Simetria [F]:** K é real (invariância por reversão temporal). Por isso os dois sentidos dão **platôs idênticos** e
  diferem só nas curvas no tempo. As medidas de platô usam a média dos dois sentidos, uma amostra por semente.
- **Regra de ouro [F]:** Γ_F(Ω, g) = 8 W0² g² √(R_K² − (Ω² − W0²)²)/(Ω R_K²). Vale 0,066 para B e 0,083 para A
  (g = 0,1), e zero para D, fora da banda.

### 2.2 S — base onipresente interagente (SYK) [M]

- **Hamiltoniano:** H = Σ_{a<b<c<d} J_abcd (Π r dos GMFt tocados) χ_aχ_bχ_cχ_d + Σ_i Ω_i (n_i − ½).
  - J_abcd gaussianos com variância 3! J²/N³, J = 1.
  - GMFt i = par (χ_2i, χ_2i+1), i = 0..3 (A, B, C, D). A base são os outros N − 8 Majoranas.
  - Ω = (0,4; 0,8; 0,4; 3,0). D fica fora da faixa de excitações de um férmion da base.
  - r_i é a prontidão: multiplica todo termo SYK que toca o par i.
- **Sinal principal (telecomando):** H(t) = H + F [cos ωt O₁ + s sin ωt O₂] para t < T_d; depois H livre.
  - O_k = i Σ_{a<b ∈ base} c_ab χ_aχ_b, hermitianos, com Tr O²/dim = 1.
  - Parâmetros: F = 0,05, T_d = 40, T_total = 80, dt = 0,1 (H no ponto médio; expm_multiply).
  - Códigos: ω₁ = 0,4 (A, C) e ω₂ = 0,8 (B). Controle "fora": ω = 1,6.
- **Controle (injeção filtrada):** (O₁ + i s O₂)|Ω⟩ projetado em energia com uma gaussiana de largura 0,1 em torno de
  E₀ + ω_código.
- **Paridade:** H e o sinal conservam a paridade fermiônica. Tudo é calculado no setor do estado (dimensão 2^(N/2−1)). A
  marca c_B† troca de setor.

## 3. Hipóteses (pré-registradas) e o que já se sabe

### 3.1 O que as explorações mostraram (sementes e tamanhos fora da rodada; §9)

- **L:**
  - o código 1 acende A e C com contraste de 20 a 50 sobre B, e o código 2 acende B com contraste parecido;
  - remover B muda A e C pouco:
    - na média tardia (primeira exploração), ~3% (mediana), sem cair com M (0,034; 0,034; 0,030 em M = 400, 800 e
      1 600);
    - no platô exato, que a rodada usa, 0,047; 0,017; 0,022; 0,0095 e 0,015 em M = 200 a 3 200 (inclinação ≈ −0,4);
    - o efeito médio com sinal é zero dentro do erro;
  - a marca de B no vácuo da base é |ΔX|_F ≈ 9×10⁻⁴ (g_B = 0,1), igual em todo M e ∝ g_B²; na região de 40 sítios cai
    como 1/M;
  - Γ medido/Γ_F entre 0,9 e 1,15 em g = 0,1;
  - todos os GMFt (A, B, C e D) começam a ser excitados com n − n(0) ∝ t² (expoente 1,97–2,01; D 1,8–1,9);
  - D, fora da banda, guarda a marca (R ≥ 0,98) em qualquer prontidão.
- **S:**
  - com o código de B (ω = 0,8), B acende 2 a 3 vezes **menos** que A e C (ρ = Δn_B/Δn_AC ≈ 0,3–0,5);
  - a razão ρ sobe com a energia entregue: ≈ 0,15 (camada 0,4), ≈ 0,35 (0,8), ≈ 1,5 (1,6). Segue a média
    microcanônica da camada de energia, também na injeção filtrada;
  - depois do drive, a média temporal infinita (ensemble diagonal) coincide com a previsão ETH para a mesma distribuição
    de energia (razão 0,95–1,05 em N = 20);
  - a marca de B se perde em r = 1 (R → R_∞ ≈ 0,2, termaliza em ~5 unidades de tempo) e se guarda em r = 0;
  - D guarda a marca (R ≈ 0,96 em r = 1);
  - ao religar, B perde a marca mesmo quando a guardou no apagamento.

**Leitura física provável [H].** Na base livre, um quantum de frequência 1,9 só pode ser absorvido inteiro por quem
está em 1,9: a energia não se divide, e o código seleciona por ressonância. Na base que interage, a energia se reparte:
o quantum de 0,8 pode virar "A aceso (0,4) + 0,4 na base". Dentro da camada de energia, o embaralhamento favorece quem
custa menos. **O código abre a porta (fixa a energia); lá dentro, acende quem custa menos.**

> **Analogia médica.** Na base livre, o sinal é um hormônio que só se liga ao receptor certo. Na base que interage, é
> como a febre: o calor entra por um lugar e se espalha pelo corpo todo, e o que "acende" primeiro é o tecido com menor
> limiar, não o tecido a que o estímulo se dirigia.

### 3.2 Previsões

| Teste | Previsão | Marca | Base da previsão |
|---|---|---|---|
| L-T1 | SELETIVA | [F] | ressonância (regra de ouro); contraste ≈ (2δΩ/Γ)² ≫ 10 |
| L-T2 | INDEPENDENTE | [M] | mediana 0,01–0,03 nas explorações |
| L-T2 escala | DILUI_RAIZ (≈ M^−½) | [M] | **revisada do esboço (que previa 1/M):** B age na base como uma perturbação de posto 1 de força ∝ g_B²/M por par de modos, e o espaçamento entre níveis também é ∝ 1/M. Cada modo da janela se reorganiza numa fração η ~ g_B² ρ/\|Ω_B − ω\| que não depende de M. O platô de A soma ~2Δρ ∝ M desses modos, com sinais aleatórios, e muda em ~η/√(2Δρ) ∝ M^−½. O efeito sistemático (médio) vai a zero. |
| L-T3 | DISTINGUIVEL | [F] | deslocamento do tipo Lamb |
| L-T3 escala | MARCA_ONIPRESENTE | [M] | a marca total é O(g_B²) e não se dilui; cada pedaço da base vê só ~1/M dela |
| L-T4 | B: PRESERVADA em ε = 0; PERDIDA em ε = g; PERDIDA ao religar, para todo ε. D: PRESERVADA sempre | [F/H] | B decai a Γ(ε) ∝ ε²; D é estado ligado fora da banda |
| L-T4 regra | REGRA_DE_OURO | [F] | Γ ∝ ε² e Γ(0,1)/Γ_F ≈ 1 |
| L-T5 | SEM_FILA | [F] | todo GMFt está a "um passo" de todo modo da base: crescimento ∝ t² |
| L-T6 | REGRA_DE_OURO | [F] | Γ_A ∝ g_A² |
| L-T6 platô | RAPIDEZ_NAO_QUANTIDADE | [F/M] | enquanto Γ < 2Δ, o GMFt absorve a janela inteira (platô fixo) e g só muda a rapidez; com g = 0,2 a linha fica mais larga que a janela e o platô cai |
| S-T1 | NAO_SELETIVA | [H] | seleção pelo custo dentro da camada de energia |
| S-T7 | TERMICA | [H] | ETH: o ensemble diagonal segue a média suavizada da camada |
| S-T2 | sem previsão de classe | [?] | — |
| L×S T2 | ACOPLAMENTO_MAIOR_NA_INTERAGENTE | [H] | na base caótica, mexer em B reorganiza o espectro inteiro |
| S-T3 | DISTINGUIVEL | [M] | 0,1–0,3 nas explorações |
| S-T4 | B perde em r = 1 (termaliza), guarda em r = 0, perde ao religar; D guarda sempre | [H] | — |
| S-T6 | CRESCENTE | [H] | mais prontidão, mais ativação ("despolarização") |
| S N = 28 | CONSISTENTE | [H] | mesma classe de T1 que N = 24 |
| L × S | SEPARACAO | [H] | a livre seleciona por código; a interagente, pelo custo |
| Q11 | IDENTIDADE_POR_LACUNA | [H] | nas duas bases, só a organização sintonizada fora da banda guarda a identidade quando está ligada; apagar o relé preserva, religar dissolve quem está dentro da banda |

**Aviso de cegueira.** As previsões foram fixadas **depois** de explorações em tamanhos próximos e sementes diferentes
(§9), que já indicam o desfecho provável. As sementes da rodada nunca foram executadas:
- L: 37 500 + 100·i_M + k;
- S: 3731–3736 (N = 20), 3741–3743 (N = 24) e 3751 (N = 28).

O valor da rodada está em confirmar com outras sementes, em tamanhos maiores (M = 3 200; N = 28) e com mais repetições,
não em surpreender.

## 4. Parâmetros (rodada `completo`)

| Parte | Tamanhos | Sementes | Bateria |
|---|---|---|---|
| L | M = 400, 800, 1 600, 3 200 | 8 por M | T1/T2/T5 (códigos 1, 2 e fora × 2 sentidos; B ausente no código 1), T3 (g_B = 0,01; 0,03; 0,1), T4 (B e D; ε = 0; 0,01; 0,03; 0,1), T6 (g_A = 0,02; 0,03; 0,05; 0,1; 0,2) |
| S20 | N = 20 (setor de 512) | 6 | completa: T1 (códigos 1 e 2 × 2 sentidos), fora, injeção filtrada, controle r = 0, T2 (B dissolvido × 2 sentidos), T3, T4 (B e D; r = 0; 0,03; 0,1; 0,3; 1), T6 (r_A = 0,3 e 0,6 × 2 sentidos) |
| S24 | N = 24 (setor de 2 048) | 3 | completa |
| S28 | N = 28 (setor de 8 192, Krylov) | 1 | só T1 (códigos 1 e 2 × 2 sentidos) |

- **Decisão:** L em M = 1 600 (controle de robustez em M = 800); S em N = 20 e N = 24, nas duas; Q11 com S em N = 24
  (N = 20 relatado).
- **Tempos (L):** grade 0–300 com passo 0,25. Crescimento inicial em t ∈ {0,25; …; 2}. T4: T_off = 400 (passo 0,25) e
  T_on = 40 (≈ 3/Γ_B com g = 0,1). T6: 0–2 000 com passo 0,25.
- **Tempos (S):**
  - janela "fim do drive" = [30; 40]; janela "tardia" = [60; 80];
  - T4: T_off = 200 (201 instantes) e T_on = 10 (≈ 2–3 vezes o tempo de perda da marca de B em r = 1);
  - largura das camadas microcanônicas e da suavização ETH: 0,1.

## 5. Protocolo

1. `python -I src/testar_avaliador_B37.py fumaca` deve terminar com "TODOS OS 110 RAMOS CONFEREM".
2. `python -I src/rodar_B37.py --modo completo --parte todas` grava em `resultados/`, ou cada parte separadamente: `L`,
   `S20`, `S24` e `S28` podem rodar em paralelo.
   - Cada (parte, tamanho, semente) gera um checkpoint JSON atômico.
   - Se a execução cair, relançar retoma do ponto em que parou.
   - `config_B37.json` registra os parâmetros e os SHA-256 dos módulos.
3. `python -I src/avaliar_B37.py resultados` grava `resultados/avaliacao_B37.json` e imprime previsto × obtido.
4. Nenhum parâmetro, limiar ou semente muda depois do "pode rodar". Qualquer leitura extra vai para uma seção pós-hoc
   separada do relatório.

**Por parte:**
- **L, por semente:** monta a base; para cada código e sentido, calcula n_i(t), platôs, crescimento inicial e t₁₀; repete
  o código 1 com B ausente e com todos desacoplados (controle); T3 compara o vácuo com g_B ∈ {0,01; 0,03; 0,1} e com
  g_B = 0; T4 faz o ciclo da marca em B e em D; T6 mede Γ_A e o platô de A em cinco prontidões.
- **S, por semente:**
  - fundamental de H(Ω, r = 1) nos dois setores (o de menor energia é o vácuo);
  - camadas microcanônicas em 0,4; 0,8 e 1,6;
  - T1 com ensemble diagonal e referência ETH;
  - controle fora; injeção filtrada; controle r = 0;
  - B dissolvido: fundamental e drive no código 1 (T2); observáveis da base no vácuo (T3);
  - T4: a marca em B e em D, para cada r, por diagonalização exata no setor da marca; religar com H(r = 1);
  - T6: fundamental e drive com r_A = 0,3 e 0,6.

## 6. Medidas

- **Platô** n_i^∞ (L) e **Δn_i** médio nas janelas (S), acima do vácuo de cada configuração.
- **L-T1:** c₁ = min(n_A^∞, n_C^∞)/n_B^∞ no código 1; c₂ = n_B^∞/max(n_A^∞, n_C^∞) no código 2. Média dos dois
  sentidos, uma amostra por semente.
- **T2:**
  - L: δ = |n^∞(B ausente) − n^∞(B presente)|/n^∞(B presente), para A e para C (2 amostras por semente). Também a média
    com sinal (efeito sistemático) e o seu erro padrão.
  - S: δ = |Δn_AC(B dissolvido) − Δn_AC(B organizado)|/Δn_AC(B organizado), no fim do drive, com Δn_AC = média de A e C,
    pareado por semente e sentido.
- **T3:**
  - L: |ΔX|_F e |ΔP|_F na base inteira (covariâncias do vácuo); máx |ΔX|; ΔS da região de 40 sítios; ΔE₀ do vácuo.
  - S: máx |Δ⟨i χ_a χ_b⟩| em 12 pares fixos da base, entre B organizado e dissolvido.
- **T4:**
  - R = marca retida: L: ½(Ω x̄² + p̄²/Ω); S: (n_B − n_B^vác)/(n_B(0) − n_B^vác).
  - R_off ao fim do apagamento; R_on depois de religar.
  - L: fidelidade gaussiana do estado reduzido do modo (máximo sobre a rotação livre, 360 ângulos) e entropia do modo
    (emaranhamento com o resto). S: R_∞ (ensemble diagonal) e entropia binária de n_B.
  - Γ: ajuste de ln R (L) ou de ln((R − R_∞)/(1 − R_∞)) (S).
- **L-T5:** expoente k do ajuste log–log de n_i(t) − n_i(0) em t ∈ [0,25; 2], códigos 1 e 2, os dois sentidos.
- **L-T6:** Γ_A(g_A) e n_A^∞(g_A) no código 1, sentido +1.
- **S-T1:**
  - σ₁ = mediana de Δn_AC/max(Δn_B, 10⁻⁵) no código 1;
  - σ₂ = mediana de Δn_B/max(Δn_AC, 10⁻⁵) no código 2;
  - no fim do drive (classe) e na janela tardia (relatado).
- **S-T7:**
  - ρ = Δn_B/Δn_AC do ensemble diagonal depois do drive (ρ_diag);
  - ρ_ETH: a mesma soma pesada pela população de cada autoestado, com ⟨k|n_i|k⟩ trocado pela média sobre os autoestados
    vizinhos (|E_l − E_k| ≤ 0,1, l ≠ k);
  - a razão ρ_diag/ρ_ETH.
- **S-T6:** mediana de Δn_A (fim do drive, código 1, os dois sentidos) em r_A = 0,3; 0,6 e 1.

## 7. Regras de decisão (congeladas; `src/avaliar_B37.py`; testadas em 110 ramos)

**Gerais.**
- Medianas sobre as amostras válidas.
- Se faltar mais de 1/3 das amostras esperadas, a classe é INSUFICIENTE.
- Inclinações são ajustes log–log. Um valor ausente ou ≤ 0 dá INSUFICIENTE.
- Toda regra global trata o estado INSUFICIENTE.

**Validade.**
- L: o controle com todos os GMFt desacoplados deve dar máx n_i ≤ 10⁻¹², ou o global L é INSUFICIENTE.
- S: a semente vale se:
  - a lacuna do fundamental for ≥ 10⁻⁸;
  - |norma − 1| ≤ 10⁻⁸ em todas as rodadas de T1;
  - o controle r = 0 der máx |Δn| ≤ 10⁻¹⁰.
- S-T1: uma rodada só forma razão se Δn_AC > 10⁻⁴ (código 1) ou max(Δn_AC, Δn_B) > 10⁻⁴ (código 2).
- S-T7: exige média ≥ 5 vizinhos na suavização ETH.
- S-T2: exige lacuna ≥ 10⁻⁸ no fundamental com B dissolvido.

**Modelo L (em M = 1 600).**

| Teste | Classes |
|---|---|
| T1 | **SELETIVA:** med c₁ ≥ 10 e med c₂ ≥ 10 · **PARCIAL:** os dois ≥ 3 · **NAO_SELETIVA:** senão |
| T2 | **INDEPENDENTE:** med δ ≤ 0,10 · **DEPENDENTE:** > 0,30 · **INTERMEDIARIA:** entre os dois |
| T2 escala (M = 400…3 200) | inclinação s de med δ: **CRESCE** s > 0,25 · **NAO_DILUI** \|s\| ≤ 0,25 · **DILUI_RAIZ** −0,75 ≤ s < −0,25 · **DILUI_1_M** s < −0,75 |
| T3 | med \|ΔX\|_F (g_B = 0,1): **DISTINGUIVEL** ≥ 10⁻⁶ · **INDISTINGUIVEL** ≤ 10⁻⁹ · **INSUFICIENTE** entre os dois |
| T3 escala | **MARCA_ONIPRESENTE** se (a) inclinação de \|ΔX\|_F em g_B ∈ [1,6; 2,4], (b) \|inclinação de \|ΔX\|_F em M\| ≤ 0,2 e (c) inclinação de ΔS_região em M ∈ [−1,3; −0,7] · **LAMB_SEM_ONIPRESENCA** só (a) · **FORA_DE_LAMB** senão |
| T4 (por GMFt e ε) | critério (ii): **PRESERVADA** se R_off ≥ 0,9, F_off ≥ 0,9 e \|S_off − S₀\| ≤ 0,05 · **PERDIDA** se R_off < 0,5 · **DEGRADADA** senão. Ao religar: classe de R_on (≥ 0,9 / < 0,5) |
| T4 regra | **REGRA_DE_OURO** se a inclinação de Γ_B em ε ∈ {0,01; 0,03; 0,1} ∈ [1,6; 2,4] e Γ_B(0,1)/Γ_F ∈ [0,8; 1,25] · **FORA_DA_REGRA** senão |
| T5 | med do expoente inicial de A, B e C: **SEM_FILA** se os três ∈ [1,7; 2,3] · **COM_FILA** se algum ≥ 3 · **INDEFINIDA** senão |
| T6 | **REGRA_DE_OURO** se a inclinação de med Γ_A em g_A ∈ {0,03; 0,05; 0,1} ∈ [1,6; 2,4] e Γ_A(0,1)/Γ_F ∈ [0,8; 1,25] (g = 0,02 só relatado) |
| T6 platô | **RAPIDEZ_NAO_QUANTIDADE** se platô(0,05)/platô(0,02) ∈ [0,67; 1,5] e platô(0,2) < ½ platô(0,05) · **QUANTIDADE_ESTAVEL_SEM_SATURACAO** só a primeira · **QUANTIDADE_VARIA** senão |
| controle fora | med max(platô A, B, C) no sinal fora ≤ 0,1 × med min(platô A, C) no código 1 |
| **Global L** | **SUSTENTADA:** T1 SELETIVA, T2 INDEPENDENTE, T3 DISTINGUIVEL e T5 SEM_FILA · **NAO_SUSTENTADA:** T1 NAO_SELETIVA · **INSUFICIENTE:** T1 INSUFICIENTE ou controle falho · **PARCIAL:** senão |
| Robustez | as classes de T1, T2, T3 e T5 em M = 800 são comparadas com as de M = 1 600 (relatado) |

**Modelo S (em N = 20 e em N = 24, separadamente).**

| Teste | Classes |
|---|---|
| T1 | **SELETIVA:** σ₁ ≥ 1,5 e σ₂ ≥ 1,5 · **NAO_SELETIVA:** σ₂ ≤ 1/1,5 · **INDEFINIDA:** senão |
| T7 | **TERMICA:** med \|ln(ρ_diag/ρ_ETH)\| ≤ ln 1,5 nos dois códigos · **MEMORIA:** no código 2, med(ρ_diag/ρ_ETH) ≥ 1,5 e med ρ_diag ≥ 1 · **INTERMEDIARIO:** senão |
| T2 | como no L (0,10 / 0,30) |
| T3 | med máx \|Δ⟨O⟩\|: **DISTINGUIVEL** ≥ 10⁻³ · **INDISTINGUIVEL** ≤ 10⁻⁸ · **INSUFICIENTE** entre os dois |
| T4 (por GMFt e r) | classe de med R_off e de med R_on (≥ 0,9 / < 0,5). Relatados: monotonia de R_off em r (Spearman) e termalização de B em r = 1 (\|R_off − R_∞\| ≤ 0,1) |
| T6 | q = Δn_A(r_A = 1)/Δn_A(r_A = 0,3): **CRESCENTE** q ≥ 1,5 · **DECRESCENTE** q ≤ 1/1,5 · **INDEFINIDA** senão |
| Global S(N) | **CUSTO:** T1 NAO_SELETIVA e T7 TERMICA · **CODIGO:** T1 SELETIVA · **MISTA:** senão · **INSUFICIENTE:** T1 ou T7 INSUFICIENTE |
| **Global S** | a classe comum de N = 20 e N = 24; **MISTA** se discordam; **INSUFICIENTE** se alguma for |
| Controle N = 28 | **CONSISTENTE** se a classe de T1 em N = 28 é a de N = 24 · **INCONSISTENTE** · **INSUFICIENTE** |

**Comparações.**
- **L × S:**
  - **SEPARACAO:** L-T1 SELETIVA e global S CUSTO;
  - **IGUAIS:** L-T1 SELETIVA e global S CODIGO, ou L-T1 NAO_SELETIVA e global S CUSTO;
  - **MISTA:** senão;
  - **INSUFICIENTE:** se algum for.
- **L × S T2:** **ACOPLAMENTO_MAIOR_NA_INTERAGENTE** se min(δ_S(20), δ_S(24)) ≥ 3 × δ_L(1 600) · **SEMELHANTE** senão.
- **Q11 (L em M = 1 600; S em N = 24):**
  - **IDENTIDADE_POR_LACUNA**, se nas duas bases:
    - D é PRESERVADA no apagamento e ao religar, para todo ε (ou r);
    - B é PRESERVADA em ε = 0 (r = 0) e PERDIDA na prontidão cheia;
    - B é PERDIDA ao religar, para todo ε (ou r).
  - **SEM_PORTADOR:** D PERDIDA na prontidão cheia nas duas bases.
  - **MISTA:** senão.
  - **INSUFICIENTE:** se faltar alguma classe.

## 8. Controles, memória e tempo (medidos antes de congelar)

- **Controles:**
  - L: todos desacoplados → n_i ≡ 0 (exato).
  - S: r = 0 → Δn ≡ 0 (10⁻⁴⁴ nas explorações).
  - Sinal fora de todas as sintonias (L e S).
  - Dois sentidos do saca-rolha.
  - Injeção filtrada (S).
  - Tamanho (M; N), com o N = 28 como controle de T1.
- **Passo do drive (S):** Δn com dt = 0,1; 0,05 e 0,025 concorda em 10⁻⁴ (N = 20) e em 6×10⁻⁶ (N = 16, fumaça).
- **Custos (2 núcleos):**

  | Parte | Por semente | Total | Memória |
  |---|---|---|---|
  | L | M = 1 600 ≈ 15 s; M = 3 200 ≈ 2 min | ≈ 20 min | < 1 GB |
  | S20 | ≈ 2 min | ≈ 12 min | < 0,2 GB |
  | S24 | ≈ 12 min (diagonalização de setor 12 s; drive 38 s por rodada) | ≈ 40 min | < 1 GB |
  | S28 | construção 4 s; Krylov ≈ 30 s por setor; 0,74 s por passo; 4 rodadas de 800 passos ≈ 40 min | ≈ 45 min | 1,9 GB (medido) |

  Em sequência, ≈ 2 h. Com as quatro partes em paralelo, ≈ 45 min, com 4 núcleos e ≥ 4 GB.

## 9. O que foi tentado e mudado antes de congelar

1. **Referência térmica canônica (S).** Na energia baixa de N = 20 (β ≈ 9–16), a ocupação canônica ficava abaixo da do
   vácuo (valores negativos). Foi trocada pela referência ETH com a distribuição real de energia (§6). A média
   microcanônica das camadas fica relatada.
2. **Índice de memória Q = ρ₂/ρ₁ (S).** Ficava em 1,5–2, em cima do limiar. Trocado por σ₂ (B sob o próprio código),
   que separa bem (≈ 0,3–0,5 contra o limiar 0,67).
3. **"Sensibilidade ao passo" (S).** Era um artefato da amostragem das janelas (a cada 5 unidades). Com amostra a cada
   1, os passos 0,1, 0,05 e 0,025 coincidem. Fixado dt = 0,1.
4. **Tempos de subida t₁₀/t₅₀ (L-T5).** Dominados pelo *speckle* (de 7 a 190 unidades). Trocados pelo expoente do
   crescimento inicial. t₁₀ fica relatado.
5. **L-T2.** O esboço previa queda como 1/M.
   - A primeira exploração, com a média tardia, deu 0,034; 0,034 e 0,030, sem cair com M.
   - A rodada usa o platô exato. Uma segunda exploração (sementes 91 000+, M = 200 a 3 200) deu queda fraca (inclinação
     ≈ −0,4).
   - O argumento de posto 1 (§3.2) explica as duas: a média tardia é sensível às fases e não cai com M; o platô soma
     muitos modos e cai como M^−½.
   - Previsão fixada: DILUI_RAIZ. Os limiares de classe foram ajustados para separar 0, −½ e −1.
6. **L-T6.** O ajuste exclui g = 0,02: em M = 1 600, Γ/espaçamento ≈ 6 (espectro discreto; inclinação 2,2–2,5 se
   incluído).
7. **Sementes de L:** de 5 para 8 por M, para reduzir o ruído das medianas.
8. **S-T6.** De um sentido e Spearman em 3 pontos (instável) para os dois sentidos e a razão entre os extremos.
9. **Validade da ETH.** O mínimo de vizinhos virou média ponderada, porque os autoestados mais baixos têm poucos
   vizinhos em N = 20.
10. **Setores de paridade.** A diagonalização de N = 24 caiu de 73 s para 12 s; N = 28 ficou em 0,74 s por passo.
11. **T_on.** No L passou a 40: com 10, R_on de B em ε = 0 seria ≈ 0,5, em cima do limiar. No S ficou em 10 (B
    termaliza em ~5).
12. **Regra de ouro no S-T4.** Não é classificada: com N ≤ 24, Γ/espaçamento é pequeno (inclinações 0,7–1,7 nas
    explorações). Fica relatada.
13. **Sementes da rodada.** Afastadas de todas as sementes exploradas; a semente 3701 tinha sido explorada.

Explorações (fora do pré-registro, scripts guardados na sessão):
- L: sementes 3711, 100–102, 5, 6 e 1, em M = 400, 800 e 1 600; sementes 91 000+ em M = 200 a 3 200 (T2 no platô exato);
- S: sementes 3701 (N = 20 e 24), 11–14 (N = 20) e 21 (N = 24);
- dimensionamento de N = 28 com a semente 3701.

## 10. Leitura prevista de cada resultado [H]

- **SEPARACAO (previsto).** A seleção por código é uma propriedade da base livre (ressonância). Uma base holográfica
  caótica não lembra o código; acende pelo custo. Para a vertente Ola:
  - se a base é a boundary holográfica, a seletividade que Mario descreve não vem do código do sinal;
  - viria da sintonia **fora da faixa** (estados ligados) ou de uma estrutura de prontidão.
- **IGUAIS (código).** Mesmo a base caótica guardaria o código. Seria um forte apoio à imagem do telecomando numa base
  holográfica.
- **IDENTIDADE_POR_LACUNA (previsto).** Resposta candidata à Q11:
  - a identidade de um GMFt persiste quando a sua organização fica fora da faixa da base, protegida por uma lacuna de
    energia;
  - apagar o relé congela a identidade (ela não é destruída), mas religar dissolve quem está dentro da faixa;
  - o que guarda a identidade não é o relé: é a lacuna.
- **SEM_PORTADOR.** Nem a lacuna protege. A Q11 continua sem portador na base onipresente.
- **MARCA_ONIPRESENTE (previsto).** O GMFt sombreado deixa na base uma marca total que não se dilui, mas que nenhum
  pedaço da base vê sozinho: "está em todo lugar e em nenhum".
- **DILUI_RAIZ no T2 (previsto).** A independência na base livre é "estatística": B não muda A e C em média, mas
  reorganiza um pouco os modos que A e C usam. Esse resto encolhe devagar (∝ M^−½), não como 1/M.

## 11. Limites

- Toy models.
  - L é livre: a energia não se reparte, o que já favorece a seleção por ressonância.
  - S é pequeno (N ≤ 28). A dualidade SYK–AdS₂ é um resultado conhecido do modelo, não algo reconstruído aqui.
- No L, o GMFt é um sítio extra ligado à base, não literalmente uma organização da base. No S é.
- O "ausente" difere entre os modelos (L: desacoplado; S: dissolvido), por construção.
- A prontidão é fixa (decisão de 14h08). A variante em que o GMFt muda a própria prontidão fica para depois.
- O sinal em S é um operador aleatório escolhido; outro operador pode mudar números, não deve mudar a seleção pela
  camada de energia [H].
- Precisão dupla. Nenhuma geometria é reconstruída.

## 12. Arquivos do pré-registro

- `src/b37_livre.py` — modelo L e funções dos testes.
- `src/b37_syk.py` — modelo S (SYK por máscaras de bits, setores de paridade) e funções dos testes.
- `src/rodar_B37.py` — executor (modos `fumaca` e `completo`; partes L, S20, S24, S28).
- `src/avaliar_B37.py` — avaliador congelado (§7).
- `src/testar_avaliador_B37.py` — teste sintético e de ponta a ponta (110 ramos).
- `src/conferir_pecas_B37.py` — conferência das peças.
- `fumaca/` — checkpoints, avaliação, logs, conferência e saída do teste.
- `FUMACA_B37.md`, `LEIAME_B37.md` e o arquivo de hashes SHA-256.

## Referências

- S. Sachdev, J. Ye, Phys. Rev. Lett. 70, 3339 (1993).
- A. Kitaev, palestras no KITP (2015).
- J. Maldacena, D. Stanford, Phys. Rev. D 94, 106002 (2016).
- J. M. Deutsch, Phys. Rev. A 43, 2046 (1991); M. Srednicki, Phys. Rev. E 50, 888 (1994) (ETH).
- E. Fermi, *Nuclear Physics* (1950) (regra de ouro); E. P. Wigner, Ann. Math. 62, 548 (1955) (semicírculo).
- T. Konopka, F. Markopoulou, L. Smolin, *Quantum Graphity*, hep-th/0611197 (2006) (regra de junção que fica fora).
