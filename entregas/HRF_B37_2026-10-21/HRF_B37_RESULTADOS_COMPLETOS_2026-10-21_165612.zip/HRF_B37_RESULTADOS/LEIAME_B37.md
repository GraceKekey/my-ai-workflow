# LEIAME — B37 (pré-registro)

**Mario José do Canto Filho, MD · Claude (`-clau`) · 21/10/2026**

## O que é
Pré-registro da B37 da vertente Ola. A base está em tudo ao mesmo tempo, sem espaço e sem junções (decisão (2) de 21/10).
Há duas versões:
- **L:** osciladores com acoplamento aleatório todos com todos;
- **S:** férmions de Majorana com a interação SYK, uma boundary holográfica sem espaço.

Cada GMFt é uma lâmpada ligada à rede da cidade por uma caixa sintonizada (a sintonia) e um relé (a prontidão). A
bancada pergunta:
- se o telecomando (um sinal codificado em frequência) acende só as lâmpadas do seu código;
- se as lâmpadas são independentes;
- se uma lâmpada sombreada se distingue de uma ausente;
- se todas começam ao mesmo tempo (sem fila);
- se a identidade de uma lâmpada sobrevive a apagar e religar o relé (Q11, critério ii).

O protocolo está em `HRF_B37_PROTOCOLO_<data-hora>-clau.md` e a fumaça em `FUMACA_B37.md`. **Rodar só depois do
"pode rodar".**

## Como rodar
Requer Python ≥ 3.9, NumPy e SciPy.
```
python -I src/testar_avaliador_B37.py fumaca              # deve terminar com "TODOS OS 110 RAMOS CONFEREM"
python -I src/rodar_B37.py --modo completo --parte todas  # ou --parte L | S20 | S24 | S28 (podem rodar em paralelo)
python -I src/avaliar_B37.py resultados                   # grava resultados/avaliacao_B37.json e imprime previsto × obtido
```
- Cada (parte, tamanho, semente) grava um checkpoint JSON atômico em `resultados/`. Se a execução cair, relançar retoma.
- **Não mudar** parâmetros, sementes nem limiares.

## Quanto custa
| Execução | Tempo (2 núcleos) | Memória |
|---|---|---|
| Em sequência | ≈ 2 h | ≤ 2,5 GB (pico na parte S28) |
| As quatro partes em paralelo | ≈ 45 min | 4 núcleos e ≥ 4 GB |

## Arquivos
- `src/b37_livre.py` — modelo L: base GOE, sítios GMFt, sinal em saca-rolha, platô exato, testes T1–T6, ciclo da marca
  (T4) com fidelidade gaussiana e entropia do modo.
- `src/b37_syk.py` — modelo S:
  - SYK por máscaras de bits, com setores de paridade;
  - drive periódico em saca-rolha, injeção filtrada;
  - camadas microcanônicas e suavização ETH;
  - marca com c_B†.
- `src/rodar_B37.py` — executor (modos `fumaca` e `completo`; partes L, S20, S24, S28).
- `src/avaliar_B37.py` — avaliador congelado (protocolo §7).
- `src/testar_avaliador_B37.py` — teste sintético de todos os ramos, de ponta a ponta sobre a fumaça e do caminho da
  bateria T1.
- `src/conferir_pecas_B37.py` — conferência das peças (anticomutação, hermiticidade, paridade, energias, controles,
  fidelidade, regra de ouro).
- `fumaca/` — checkpoints, `avaliacao_B37.json`, logs, `conferencia_pecas.txt` e a saída do teste do avaliador.
- `HRF_B37_hashes_antes_da_execucao_<data-hora>-clau.txt` — SHA-256 de tudo acima.
