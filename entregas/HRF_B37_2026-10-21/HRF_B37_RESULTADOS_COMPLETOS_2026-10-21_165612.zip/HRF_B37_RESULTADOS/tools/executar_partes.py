import subprocess,os,time,json,pathlib,datetime,platform
P=pathlib.Path(__file__).resolve().parents[1]
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',TZ='America/Sao_Paulo')
python='/workspace/my-ai-workflow/.venv/bin/python3'
t0=time.time();procs=[];handles=[]
for part in ['L','S20','S24','S28']:
 f=(P/'auditoria'/('execucao_'+part+'.txt')).open('w');handles.append(f)
 procs.append((part,subprocess.Popen([python,'-I','src/rodar_B37.py','--modo','completo','--parte',part],cwd=P,env=env,stdout=f,stderr=subprocess.STDOUT)))
 if part=='L':
  while not (P/'resultados/config_B37.json').exists():
   if procs[-1][1].poll() is not None:raise RuntimeError('L terminou antes de configurar')
   time.sleep(.1)
 print('iniciada',part,flush=True)
statuses={}
while len(statuses)<4:
 for part,p in procs:
  if part not in statuses and p.poll() is not None:
   statuses[part]=p.returncode;print('terminou',part,'exit',p.returncode,flush=True)
 time.sleep(1)
for f in handles:f.close()
r=dict(inicio_utc=datetime.datetime.fromtimestamp(t0,datetime.timezone.utc).isoformat(),fim_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),tempo_parede_s=time.time()-t0,exit_codes=statuses,threads=1,partes_paralelas=4,python=platform.python_version(),plataforma=platform.platform(),cpu_quota=pathlib.Path('/sys/fs/cgroup/cpu.max').read_text().strip(),memoria_limite=pathlib.Path('/sys/fs/cgroup/memory.max').read_text().strip())
(P/'auditoria/execucao_resumo.json').write_text(json.dumps(r,indent=2));assert all(x==0 for x in statuses.values()),statuses
