"""Organiza resultados avaliados; não modifica a bancada congelada."""
import pathlib,json,csv,hashlib,zipfile,datetime,platform
from zoneinfo import ZoneInfo
import numpy as np,scipy
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
P=pathlib.Path(__file__).resolve().parents[1]
r=json.loads((P/'resultados/avaliacao_B37.json').read_text());cfg=json.loads((P/'resultados/config_B37.json').read_text())
assert cfg['modo']=='completo'
recs=[json.loads(f.read_text())for f in sorted((P/'resultados').glob('*_s*.json'))]
expected={('L',M,37500+100*i+k)for i,M in enumerate([400,800,1600,3200])for k in range(8)}|{(rot,N,sd)for rot,N,seeds in [('S20',20,range(3731,3737)),('S24',24,range(3741,3744)),('S28',28,[3751])]for sd in seeds}
actual={(x.get('rotulo',x['parte']),x.get('N',x.get('M')),x['semente'])for x in recs}
assert actual==expected and len(recs)==42,(len(recs),expected-actual,actual-expected)
for x in recs:
 if x['parte']=='L':assert all(k in x for k in ['T1','T3','T4','T6'])
 else:
  assert len(x['T1'])==4
  if x['N']in [20,24]:assert all(k in x for k in ['T2','T3','T4','T6','inj','fora','controle_r0'])
(P/'auditoria/cobertura.json').write_text(json.dumps(dict(esperados=42,obtidos=len(recs),L=32,S20=6,S24=3,S28=1,sementes_e_tamanhos='EXATOS',modo='completo'),indent=2))
# Valores de controle apenas extraídos dos checkpoints.
ls=[x for x in recs if x['parte']=='L'];ss=[x for x in recs if x['parte']=='S']
ctrl=dict(controle_L_desacoplado_max=max(q.get('controle_desacoplado_max',0)for x in ls for q in x['T1']['casos']if q['codigo']=='1'),controle_S_r0_max=max(x['controle_r0']['max_abs_dn']for x in ss if 'controle_r0'in x),erro_norma_S_T1_max=max(abs(q['norma']-1)for x in ss for q in x['T1']),gap_S_min=min(x['gs']['gap']for x in ss),gap_S_dissolvido_min=min(x['T2']['gs']['gap']for x in ss if'T2'in x),memoria_pico_por_parte_GB={part:max(x['mem_gb']for x in recs if x.get('rotulo',x['parte'])==part)for part in ['L','S20','S24','S28']})
(P/'auditoria/controles_resumo.json').write_text(json.dumps(ctrl,indent=2))
(P/'auditoria/versoes.json').write_text(json.dumps(dict(python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,matplotlib=matplotlib.__version__,plataforma=platform.platform()),indent=2))
for d in ['tabelas','figuras']:(P/d).mkdir(exist_ok=True)
def tabela(name,rows):
 with (P/'tabelas'/name).open('w',newline='')as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
tabela('previsto_x_obtido.csv',[dict(teste=k,**v)for k,v in r['previsto_x_obtido'].items()])
tabela('execucao_por_semente.csv',[dict(parte=x.get('rotulo',x['parte']),tamanho=x.get('N',x.get('M')),semente=x['semente'],tempo_s=x['tempo_s'],memoria_pico_processo_GB=x['mem_gb'])for x in recs])
rowsL=[dict(M=M,T1=r['L'][f'M{M}']['T1'][0],c1=r['L'][f'M{M}']['T1'][1],c2=r['L'][f'M{M}']['T1'][2],T2=r['L'][f'M{M}']['T2'][0],delta=r['L'][f'M{M}']['T2'][1],marca_X=r['L'][f'M{M}']['T3_dX']['0.1'],marca_S_reg=r['L'][f'M{M}']['T3_dS'],T5=r['L'][f'M{M}']['T5'][0])for M in [400,800,1600,3200]]
tabela('L_por_tamanho.csv',rowsL)
rows4=[]
for model,z in [('L1600',r['L']['M1600']),('S20',r['S']['S20']),('S24',r['S']['S24'])]:
 for k,v in z['T4'].items():rows4.append(dict(modelo=model,marca=k,R_off=v['R_off'],R_on=v['R_on'],classe_off=v.get('classe_off_ii',v.get('classe_off')),classe_on=v['classe_on']))
tabela('Q11_marcas.csv',rows4)
fig,ax=plt.subplots(1,3,figsize=(14,4.4),layout='constrained')
ms=[v['M']for v in rowsL];ds=[v['delta']for v in rowsL]
ax[0].loglog(ms,ds,'o-',label='δ mediana')
ax[0].loglog(ms,[ds[0]*(m/ms[0])**-.5 for m in ms],'--',label='referência M⁻½')
ax[0].set(xlabel='Tamanho M',ylabel='Mudança relativa δ',title='L: independência e tamanho');ax[0].legend()
for model,marker in [('L1600','o'),('S24','s')]:
 for marca,style in [('B','-'),('D','--')]:
  zz=[v for v in rows4 if v['modelo']==model and v['marca'].startswith(marca+'_')];xx=[float(v['marca'].split('_')[1])for v in zz]
  ax[1].plot(xx,[v['R_off']for v in zz],marker+style,label=f'{model} {marca}: off')
ax[1].set(xlabel='Prontidão durante apagamento (ε ou r)',ylabel='Marca retida R',title='Q11: retenção durante apagamento');ax[1].legend(fontsize=8);ax[1].set_xscale('symlog',linthresh=.01)
for name in ['S20','S24']:
 z=r['S'][name];ax[2].plot([.4,.8,1.6],[z['rho']['mc_'+s]for s in ['0.4','0.8','1.6']],'o-',label=name+' microcanônico')
 ax[2].scatter([.4,.8],[z['rho']['diag_c1'],z['rho']['diag_c2']],marker='x',s=65,label=name+' pós-drive')
ax[2].set(xlabel='Energia do código / camada',ylabel='ρ = ΔnB / ΔnAC',title='SYK: resposta e energia');ax[2].axhline(1,color='gray',ls=':');ax[2].legend(fontsize=8)
for a in ax:a.grid(alpha=.25)
fig.savefig(P/'figuras/B37_resumo.png',dpi=180);fig.savefig(P/'figuras/B37_resumo.pdf');plt.close(fig)
stamp=datetime.datetime.now(ZoneInfo('America/Sao_Paulo')).strftime('%Y-%m-%d_%H%M%S')
lines=['# HRF B37 — Relatório da execução completa',f'\n{stamp}, America/Sao_Paulo. Autoria HRF: Mario José do Canto Filho, MD. Execução: Codex.','\n## Objetivo','[M] Comparar seleção por código, independência, sombreado, início da resposta, prontidão e persistência da identidade entre uma base livre L e uma base interagente SYK S, segundo o protocolo anexado.','\n## Hipóteses','[M/H] Previsões congeladas: L seletiva, S não seletiva e térmica; separação L×S; Q11 com identidade protegida por lacuna. Previsões auxiliares incluem diluição M⁻½, marca onipresente e regra de ouro. A tabela abaixo distingue todas as previsões dos resultados.','[M] As hipóteses foram informadas por explorações anteriores em outras sementes. Esta rodada confirma em sementes pré-registradas; não é teste completamente cego.','\n## Parâmetros','[M] L: M=400, 800, 1600, 3200, oito sementes cada. S20: seis sementes; S24: três; S28: uma, somente T1. Sementes e parâmetros exatos em resultados/config_B37.json e no protocolo original. Decisão L em M1600, controle M800; S em N20 e N24; controle N28; Q11 em L1600 e S24.','\n## Protocolo','[D] Autorização recebida: “OI PODE RODAR POR FAVOR”. Hashes verificados antes e depois. Executados os 110 testes do avaliador e a conferência das peças. Quatro processos independentes executaram as partes L/S20/S24/S28 em paralelo, conforme opção expressa do protocolo; Python isolado, uma thread BLAS/OMP/MKL por processo. Código, sementes, limiares e regras permaneceram intactos.','[M] Cada caso gerou checkpoint JSON atômico. Avaliação realizada com src/avaliar_B37.py congelado. tools/ somente organiza, verifica cobertura e desenha dados; não muda decisões.','\n## Medidas','[M] Platôs e contrastes, mudança δ ao remover/dissolver B, covariâncias/observáveis do vácuo, retenção R, fidelidade e entropia, Γ e regra de ouro, expoentes iniciais, razão ρ diagonal/ETH e controles de tamanho. Dados integrais em resultados/, tabelas em tabelas/, figuras PNG/PDF em figuras/.','\n## Resultados',f"[D] L: **{r['L']['global']}**. S: **{r['S']['global']}**. L×S: **{r['LxS']}**. Q11: **{r['Q11']}**. Controle N28: **{r['S']['controle_N28']}**.",'\n| Teste | Previsto | Obtido | Confere |','|---|---|---|---|']
lines += [f"| {k} | {v['previsto']} | {v['obtido']} | {'sim' if v['confere'] else 'NÃO'} |"for k,v in r['previsto_x_obtido'].items()]
lines+=['\n[M] Valores L por tamanho:', '```json',json.dumps(rowsL,ensure_ascii=False,indent=2),'```','\n[M] Escalas L:', '```json',json.dumps({k:r['L'][k]for k in ['T2_diluicao','T3_escala']},ensure_ascii=False,indent=2),'```','\n[M] Resultados SYK:', '```json',json.dumps({k:{t:r['S'][k].get(t)for t in ['N','sementes_validas','T1','T7','T2','T3','T6','rho','global']}for k in ['S20','S24','S28']},ensure_ascii=False,indent=2),'```','\n[M] Q11 — retenção por prontidão:', '\n| Modelo | Marca/prontidão | R_off | R_on | Classe off | Classe on |','|---|---|---|---|---|---|']
lines +=[f"| {x['modelo']} | {x['marca']} | {x['R_off']:.7g} | {x['R_on']:.7g} | {x['classe_off']} | {x['classe_on']} |"for x in rows4]
lines+=['\n## Controles','[M] Cobertura: 42/42 checkpoints, com tamanhos e sementes exatos. Saídas dos testes e hashes em auditoria/. A fumaça original é antecedente e não substitui nenhum resultado desta rodada.','```json',json.dumps(ctrl,indent=2),'```','\n[M] Execução:', '```json',(P/'auditoria/execucao_resumo.json').read_text(),'```','\n[M] Robustez L:', '```json',json.dumps(r['L'].get('robustez_controle_M'),ensure_ascii=False,indent=2),'```','\n## Interpretação','[D] A rodada encontrou SEPARACAO: a base livre seleciona por código; SYK foi NAO_SELETIVA e TERMICA em N20 e N24, com T1 consistente em N28. Todas as 19 previsões listadas no avaliador conferiram. Q11 recebeu IDENTIDADE_POR_LACUNA: D preservou a marca, B a preservou com relé zero, perdeu em prontidão cheia e ao religar, nos tempos testados.', '[M] Em L1600, os contrastes medianos c1/c2 foram 45,95/47,45 e δ=0,02807. A inclinação medida de diluição foi −0,3196, dentro da classe DILUI_RAIZ; as quatro medianas não são monótonas, e essa classificação não demonstra um expoente exato de −1/2. Em S, T2 foi DEPENDENTE em N20 (δ=0,30227) e INTERMEDIARIA em N24 (δ=0,15334). A regra CRESCENTE de T6 compara extremos; ela não exige monotonia de todos os pontos intermediários.', '[M] As classes acima são as saídas literais do avaliador congelado. A comparação L×S testa se a resposta segue o código ou a distribuição de energia nos modelos escolhidos. A classificação Q11 refere-se à retenção da marca nos tempos, limiares e subsistemas definidos, e não estabelece identidade persistente em geral.','[?] L é livre e representa GMFt por sítios extras; S é finito, N≤28, e define ausência como dissolução, enquanto L usa desacoplamento. As diferenças de arquitetura limitam a comparação. Precisão dupla; prontidão fixa; nenhum espaço ou geometria é reconstruído. [H] A interpretação da identidade e sua relação com HRF permanecem hipóteses condicionadas a esses modelos.','\n## Arquivos','Pacote autocontido: entradas originais, protocolo, fontes e fumaça intactos, checkpoints, avaliação, logs por parte, auditoria, versões, tabelas e figuras. MANIFEST_SHA256_RESULTADOS.txt verifica os arquivos entregues; o manifesto original verifica o pré-registro.']
report=P/f'HRF_B37_RELATORIO_{stamp}.md';report.write_text('\n'.join(lines)+'\n')
(P/'LEIA_PRIMEIRO_RESULTADOS.md').write_text(f'# HRF B37 — Resultados\n\nRelatório: {report.name}\n\nL: {r["L"]["global"]}; S: {r["S"]["global"]}; L×S: {r["LxS"]}; Q11: {r["Q11"]}.\n\nResultados desta rodada: resultados/. Fumaça e entradas são antecedentes.\n')
files=[p for p in sorted(P.rglob('*'))if p.is_file()and'__pycache__'not in p.parts and p.name!='MANIFEST_SHA256_RESULTADOS.txt']
(P/'MANIFEST_SHA256_RESULTADOS.txt').write_text(''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+p.relative_to(P).as_posix()+'\n'for p in files))
archive=pathlib.Path('/workspace')/f'HRF_B37_RESULTADOS_COMPLETOS_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED)as z:
 for p in sorted(P.rglob('*')):
  if p.is_file()and'__pycache__'not in p.parts:z.write(p,pathlib.Path('HRF_B37_RESULTADOS')/p.relative_to(P))
with zipfile.ZipFile(archive)as z:assert z.testzip()is None
receipt=dict(archive=str(archive),report=str(report),sha256=hashlib.sha256(archive.read_bytes()).hexdigest(),bytes=archive.stat().st_size)
pathlib.Path('/workspace/HRF_B37_ENTREGA_LOCAL.json').write_text(json.dumps(receipt,indent=2));print(json.dumps(receipt))
