import pathlib,json,datetime
P=pathlib.Path(__file__).resolve().parents[1]
print(datetime.datetime.now().isoformat(timespec='seconds'))
for part in ['L','S20','S24','S28']:
 f=P/'auditoria'/('execucao_'+part+'.txt');lines=f.read_text().splitlines()
 print(part,':',lines[-1] if lines else '(iniciado)')
for pattern,expected in [('L_M*_s*.json',32),('S20_N*_s*.json',6),('S24_N*_s*.json',3),('S28_N*_s*.json',1)]:print(pattern,len(list((P/'resultados').glob(pattern))),'/',expected)
