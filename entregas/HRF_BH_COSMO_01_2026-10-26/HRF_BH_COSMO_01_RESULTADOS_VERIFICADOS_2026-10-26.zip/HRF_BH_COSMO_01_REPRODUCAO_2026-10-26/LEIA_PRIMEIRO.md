# HRF-BH-COSMO-01 — resultados reproduzidos

**EXECUTADO EM 26/10/2026.** Os cálculos fornecidos foram reproduzidos sem alterar o código. Cinco resultados e o stdout conferiram byte a byte; a conferência matemática independente passou.

Abra RELATORIO_REPRODUCAO.md. Os CSVs e o resumo JSON desta execução estão em reproducao/resultados/. Os dados anteriores ficam em original/HRF_BH_COSMO_01/, e o ZIP recebido está em entrada/. Auditoria, hashes e verificador adicional ficam em auditoria/.

[M/?] São cálculos analíticos/toy: não foi simulado um interior cosmológico relativístico nem ajustado um conjunto de observações. O tamanho real continua NÃO IDENTIFICÁVEL sob as informações disponíveis.

Para repetir, faça uma cópia do pacote antes, preservando esta auditoria; então execute `python3 -I reproducao/bench_bh_cosmologia.py`. Para a verificação independente dos resultados: `python3 -I auditoria/verificar_formulas.py`. Não importar o script de bancada para inspecioná-lo: ele escreve resultados já no nível do módulo. Não há dependências de terceiros.

O manifesto completo SHA256SUMS.txt cobre os arquivos desta entrega, exceto ele próprio. Comparação dos resultados e verificações algébricas são independentes de qualquer download externo.
