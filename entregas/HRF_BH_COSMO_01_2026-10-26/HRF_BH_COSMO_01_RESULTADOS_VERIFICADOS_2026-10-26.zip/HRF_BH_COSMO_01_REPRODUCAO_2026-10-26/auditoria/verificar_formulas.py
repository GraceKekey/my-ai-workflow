"""Independent Decimal/rational checks. Does not import/rerun the original script."""
from pathlib import Path
from decimal import Decimal,localcontext
from fractions import Fraction
import ast,json,math
ROOT=Path(__file__).resolve().parents[1]

def verify():
    result=json.loads((ROOT/'reproducao/resultados/resumo_resultados.json').read_text())
    tree=ast.parse((ROOT/'reproducao/bench_bh_cosmologia.py').read_text())
    constants={}
    for node in tree.body:
        if isinstance(node,ast.Assign) and len(node.targets)==1 and isinstance(node.targets[0],ast.Name):
            try:constants[node.targets[0].id]=ast.literal_eval(node.value)
            except (ValueError,TypeError):continue
    inputs=constants['INPUT'];D=lambda v:Decimal(str(v));rows=[]
    with localcontext() as ctx:
        ctx.prec=50
        c=D(constants['C']);G=D(constants['G']);msun=D(constants['M_SUN']);gly=D(constants['LY_M'])*D(10**9)
        H0=D(inputs['H0_km_s_Mpc'])*1000/D(constants['MPC_M']);rh=c/H0/gly
        pi=Decimal('3.1415926535897932384626433832795028841971693993751')
        robs=D(inputs['R_observavel_Gly'])
        for item in result['control_friedmann']:
            radius=rh/D(item['abs_Omega_k_assumido']).sqrt()
            expected={'raio_curvatura_Gly':radius,'Rcurv_sobre_Robs':radius/robs,'diametro_geodesico_maximo_fechado_Gly':pi*radius}
            for key,value in expected.items():
                delta=abs(D(item[key])-value)
                assert delta<=D('.0005'),(key,item,value)
            rows.append(dict(kind='FLRW',abs_Omega_k=item['abs_Omega_k_assumido'],radius_Gly_50digits=str(radius),rounded_values_correct=True))
        for item in result['toy_visibilidade']:
            ratio=D(item['A_convencional'])/D(item['limiar_epsilon_convencional'])
            power=item['potencia_p_convencional'];assert power in (1,2)
            factor=ratio if power==1 else ratio.sqrt()
            assert abs(robs*factor-D(item['Lmin_Gly']))<=D('.0005')
            assert abs(factor-D(item['Lmin_sobre_Robs']))<=D('.0005')
            rows.append(dict(kind='toy',A=item['A_convencional'],p=power,Lmin_Gly_50digits=str(robs*factor),rounded_values_correct=True))
        mass=c*c*(robs*gly)/(2*G);reference=result['controle_raio_schwarzschild']
        assert abs(D(reference['massa_schwarzschild_equivalente_kg'])/mass-1)<D('1e-14')
        assert abs(D(reference['massa_schwarzschild_equivalente_Msun'])/(mass/msun)-1)<D('1e-14')
        rows.append(dict(kind='Schwarzschild_equivalence',mass_kg_50digits=str(mass),mass_Msun_50digits=str(mass/msun),relative_tolerance=1e-14))
    # Rigid rotation identity in exact rational arithmetic, before normalization.
    residuals=[]
    for item in result['rotacao_rigida']:
        a=ast.literal_eval(item['obs']);b=ast.literal_eval(item['obj']);w=Fraction(str(inputs['swirl_omega_unitless']))
        a=tuple(Fraction(str(x)) for x in a);b=tuple(Fraction(str(x)) for x in b)
        d=[b[i]-a[i] for i in range(2)]
        dv=(-w*b[1]+w*a[1],w*b[0]-w*a[0])
        assert dv[0]*d[0]+dv[1]*d[1]==0
        assert abs(item['v_los_rotacao_rigida'])<1e-12
        residuals.append(0)
    # Independent closed form, not the original velocity-vector routine.
    signs=[];max_error=0.;rotation=[]
    def omega(position):return inputs['swirl_omega_unitless']/(1+(math.hypot(*position)/inputs['swirl_scale_arbitrary'])**2)
    for item in result['rotacao_diferencial']:
        a=ast.literal_eval(item['observador']);b=ast.literal_eval(item['galaxia'])
        distance=math.hypot(b[0]-a[0],b[1]-a[1])
        projection=(omega(b)-omega(a))*(a[0]*b[1]-a[1]*b[0])/distance
        error=abs(projection-item['v_los_rotacao_diferencial']);max_error=max(max_error,error)
        assert error<=5.1e-10
        sign='afasta' if projection>1e-12 else 'aproxima' if projection< -1e-12 else 'zero'
        assert item['sinal']==sign;signs.append(sign)
        rotation.append(dict(position=b,raw_los=projection,reported_rounded_los=item['v_los_rotacao_diferencial']))
    assert signs.count('afasta')==signs.count('aproxima')==4
    assert all(result['tests'][k] for k in ('flrw_positive_and_monotone','rigid_rotation_radial_component_exactly_zero','differential_rotation_mixed_line_of_sight_signs','a_zero_makes_size_nonidentifiable'))
    assert all(not result['tests'][k] for k in ('simulated_bh_interior_einstein_solution','observational_parameter_fit_executed','size_of_actual_universe_identified'))
    return dict(status='PASS_INDEPENDENT_MATH_CHECKS',precision_decimal_digits=50,values=rows,
                exact_rational_rigid_pairs=len(residuals),differential_positive=4,differential_negative=4,
                max_difference_due_to_9decimal_rounding=max_error,differential_values=rotation,
                original_script_modified=False,physical_BH_model_validated=False,observational_fit=False,
                internal_documentary_gate_BHC01='NOT_REAUDITED_REFERENCES_NOT_INCLUDED')

if __name__=='__main__':
    answer=verify();(ROOT/'auditoria/verificacao_independente.json').write_text(json.dumps(answer,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({k:answer[k] for k in ('status','exact_rational_rigid_pairs','differential_positive','differential_negative','original_script_modified')},indent=2))
