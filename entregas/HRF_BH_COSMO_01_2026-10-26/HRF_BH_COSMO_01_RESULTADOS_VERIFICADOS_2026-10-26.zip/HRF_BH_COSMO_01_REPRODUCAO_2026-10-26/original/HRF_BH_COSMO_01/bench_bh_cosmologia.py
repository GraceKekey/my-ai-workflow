#!/usr/bin/env python3
"""HRF-BH-COSMO-01. Toy benchmarks (NOT an Einstein/Kerr interior solution).
Standard library only. Reproduce: python3 bench_bh_cosmologia.py
"""
import csv, json, math, pathlib, hashlib
from datetime import date

ROOT = pathlib.Path(__file__).resolve().parent
OUT = ROOT / 'resultados'
OUT.mkdir(exist_ok=True)
# Defined input assumptions, NOT fitted parameters
INPUT = {
    'date': '2026-10-26',
    'R_observavel_Gly': 46.0,             # NASA 2025: ~92 billion ly across
    'H0_km_s_Mpc': 67.4,                 # Planck 2018 base LambdaCDM fit
    'Omega_k_scenarios_abs': [0.005, 0.002, 0.001, 0.0001],
    'anisotropy_budget_illustrative': 1e-5,  # not a measured global-vorticity limit
    'toy_A': [1.0, 0.01],
    'toy_power_p': [1, 2],
    'swirl_omega_unitless': 0.3,
    'swirl_scale_arbitrary': 10.0,
    'swirl_origin_offset': [3.0, 0.5],
    'status': 'ANALYTICAL_TOY_EXECUTED__PHYSICAL_BH_MODEL_NOT_EXECUTED',
}
C = 299792458.0                    # m/s
G = 6.67430e-11                     # SI
M_SUN = 1.98847e30                  # kg
MPC_M = 3.0856775814913673e22      # m
LY_M = 9.4607304725808e15          # Julian light year, m
GLY_M = LY_M * 1e9
MPC_PER_GLY = GLY_M / MPC_M
H0_SI = INPUT['H0_km_s_Mpc'] * 1000 / MPC_M
HUBBLE_GLY = C / H0_SI / GLY_M
R_OBS = INPUT['R_observavel_Gly']


def csv_write(name,rows):
    p=OUT/name
    with p.open('w',newline='',encoding='utf-8') as f:
        wr=csv.DictWriter(f,fieldnames=list(rows[0]));wr.writeheader();wr.writerows(rows)

# CONTROL 1: curved FLRW, curvature LENGTH not necessarily universe's size.
flrw=[]
for ok in INPUT['Omega_k_scenarios_abs']:
    curvature_len=HUBBLE_GLY/math.sqrt(ok)
    flrw.append({'abs_Omega_k_assumido': ok,'raio_curvatura_Gly':round(curvature_len,3),
                 'Rcurv_sobre_Robs':round(curvature_len/R_OBS,3),
                 'diametro_geodesico_maximo_fechado_Gly':round(math.pi*curvature_len,3),
                 'interpretacao':'escala de curvatura FLRW; NÃO horizonte/raio BH; diâmetro somente para 3-esfera fechada'})
csv_write('01_curvatura_flrw_cenarios.csv',flrw)

# CONTROL 2: ad hoc visibility law, useful to expose non-identifiability.
# epsilon = A*(Robs/L)^p; solution L >= Robs*(A/epsilon)**(1/p)
toy=[]
for A in INPUT['toy_A']:
    for p in INPUT['toy_power_p']:
        Lmin=R_OBS * (A/INPUT['anisotropy_budget_illustrative'])**(1.0/p)
        toy.append({'A_convencional':A,'potencia_p_convencional':p,
                    'limiar_epsilon_convencional':INPUT['anisotropy_budget_illustrative'],
                    'Lmin_Gly':round(Lmin,3),'Lmin_sobre_Robs':round(Lmin/R_OBS,3),
                    'interpretacao':'somente sensibilidade paramétrica; NÃO limite observado para o tamanho universal'})
csv_write('02_visibilidade_toy_cenarios.csv',toy)

# CONTROL 3: Schwarzschild radius equivalence is dimensional algebra, NOT a BH cosmology.
R_si = R_OBS * GLY_M
M_eq = (C*C*R_si)/(2*G)
blackhole = {'R_equivalente_Gly':R_OBS,'massa_schwarzschild_equivalente_Msun':M_eq/M_SUN,
             'massa_schwarzschild_equivalente_kg':M_eq,
             'interpretacao':'massa de um Schwarzschild exterior com Rs igual ao raio observável; não estima massa/raio de universo interno'}

# CONTROL 4: rigid rotation has exactly zero relative radial velocities for all pairs.
def sub(a,b):return (a[0]-b[0],a[1]-b[1])
def add(a,b):return (a[0]+b[0],a[1]+b[1])
def dot(a,b):return a[0]*b[0]+a[1]*b[1]
def cross_rot(omega,p):return (-omega*p[1],omega*p[0])
def norm(a):return math.hypot(a[0],a[1])
pairs=[((3.0,0.0),(7.0,4.0)),((2.2,-1.0),(-5.0,2.0)),((0.1,4.0),(6.0,-3.0)),((-7.0,2.0),(2.0,1.0))]
rigid=[]
for obs,obj in pairs:
    d=sub(obj,obs);n=norm(d);u=(d[0]/n,d[1]/n)
    delta_v=sub(cross_rot(INPUT['swirl_omega_unitless'],obj),cross_rot(INPUT['swirl_omega_unitless'],obs))
    los=dot(delta_v,u)
    rigid.append({'obs':str(obs),'obj':str(obj),'v_los_rotacao_rigida':round(los,13),'distancia_unid_arbit':round(n,6)})
    assert abs(los)<1e-12
csv_write('03_controle_rotacao_rigida.csv',rigid)

# CONTROL 5: differential rotation may induce opposite LOS signs for offset observer.
# Omega(r)=Omega0/(1+(r/Ls)^2); makes no claims for geometry or general relativity.
def omega_r(r):return INPUT['swirl_omega_unitless']/(1+(r/INPUT['swirl_scale_arbitrary'])**2)
def v_diff(pos):return cross_rot(omega_r(norm(pos)),pos)
obs=tuple(INPUT['swirl_origin_offset']); candidates=[(10.0,5.0),(10.0,-5.0),(-10.0,5.0),(-10.0,-5.0),(1.0,12.0),(1.0,-12.0),(20.0,10.0),(20.0,-10.0)]
diff=[]
for obj in candidates:
    d=sub(obj,obs);n=norm(d);u=(d[0]/n,d[1]/n)
    dv=sub(v_diff(obj),v_diff(obs));los=dot(dv,u)
    diff.append({'observador':str(obs),'galaxia':str(obj),'v_los_rotacao_diferencial':round(los,9),
                 'sinal':('afasta' if los>1e-12 else 'aproxima' if los< -1e-12 else 'zero')})
assert {x['sinal'] for x in diff} == {'afasta','aproxima'}
csv_write('04_rotacao_diferencial_toy.csv',diff)

# CONTROL 6: direct non-inferability when anisotropy response amplitude is zero.
# If A=0 in the assumed toy epsilon law, arbitrary L yields same null signal.
for L in [R_OBS, 2*R_OBS, 1000*R_OBS]:
    assert 0.0*(R_OBS/L)**2 == 0.0

results={'model':'HRF-BH-COSMO-01: benchmarks de escala e rotacao (sem metrica interior)',
         'inputs':INPUT,'control_friedmann':flrw,'toy_visibilidade':toy,
         'controle_raio_schwarzschild':blackhole,
         'rotacao_rigida':rigid,'rotacao_diferencial':diff,
         'tests':{
             'flrw_positive_and_monotone':all(flrw[i]['raio_curvatura_Gly']<flrw[i+1]['raio_curvatura_Gly'] for i in range(len(flrw)-1)),
             'rigid_rotation_radial_component_exactly_zero':True,
             'differential_rotation_mixed_line_of_sight_signs':True,
             'a_zero_makes_size_nonidentifiable':True,
             'simulated_bh_interior_einstein_solution':False,
             'observational_parameter_fit_executed':False,
             'size_of_actual_universe_identified':False
         },
         'main_conclusion':'L REAL do universo interior NAO IDENTIFICAVEL; valores condicionalmente calculados NAO equivalem a dimensao do buraco negro/universo'}
(OUT/'resumo_resultados.json').write_text(json.dumps(results,ensure_ascii=False,indent=2),encoding='utf-8')
if __name__=='__main__':
    print(json.dumps({'Hubble_length_Gly':HUBBLE_GLY,'FLRW':flrw,'toy':toy,'Schwarzschild_Msun':M_eq/M_SUN,'rotation_differential':diff,'tests':results['tests']},ensure_ascii=False,indent=2))
