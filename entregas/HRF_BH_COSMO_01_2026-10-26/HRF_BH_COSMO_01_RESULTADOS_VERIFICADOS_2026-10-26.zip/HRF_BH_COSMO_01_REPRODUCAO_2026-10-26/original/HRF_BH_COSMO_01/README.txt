HRF-BH-COSMO-01 v0.1 - 2026-10-26

BANCADA EXECUTADA: matemática FLRW, teste ad hoc de visibilidade,
rotação rígida/diferencial em 2D e conversão dimensional Schwarzschild.
NÃO EXECUTADO: interior cosmológico real de Kerr/Schwarzschild,
solução relativística 4D e ajuste a dados cosmológicos.

ATENÇÃO: NÃO É POSSÍVEL INFERIR UM TAMANHO REAL ÚNICO DE UNIVERSO DENTRO
DE UM BURACO NEGRO SEM UM MODELO FÍSICO RELATIVÍSTICO ESPECIFICADO.

Como reproduzir (Python 3, biblioteca padrão):
    python3 bench_bh_cosmologia.py

O script grava os resultados em 'resultados/'. Abra o relatório Markdown:
HRF_BH_COSMO_01_Protocolo_Relatorio_v0_1_PT_2026-10-26.md

Arquivos CSV são dados de cálculo toy, NÃO dados astronômicos.
Não contém executável binário, dependências ou chamadas de rede.
