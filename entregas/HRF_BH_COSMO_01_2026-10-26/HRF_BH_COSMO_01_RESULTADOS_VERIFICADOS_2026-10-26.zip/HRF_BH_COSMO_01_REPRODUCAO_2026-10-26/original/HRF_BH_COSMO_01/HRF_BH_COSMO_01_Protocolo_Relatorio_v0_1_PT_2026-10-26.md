# HRF-BH-COSMO-01 — Escala não observável, rotação cósmica e hipótese de universo no interior de buraco negro

**Tipo:** protocolo + relatório de bancada analítica/toy numérica [M] (executada).  
**Data:** 26/10/2026 · **Versão:** 0.1 · **Programa:** HRF — Reconstrução Unificadora Progressiva (RUP: B → A).  
**Autoridade documental interna:** Capítulo 0.1 RUP v0.2 (09/10/2026); *Geometria Emergente: Caminhos entre a Relatividade Geral e a Física Quântica* v0.1 (24/10/2026); Capítulo 3 v0.5 (24/10/2026).  
**Natureza:** estudo de compatibilidade preliminar, sem pretensão de validar a hipótese de universo no interior de um buraco negro ou executar solução de Kerr/Einstein.  
**Marcadores:** [F] física estabelecida em domínio especificado; [M] cálculo/modelo executado; [H] hipótese; [?] lacuna; [D] escolha metodológica.

## 0. Resposta operacional

**[?] NÃO IDENTIFICÁVEL:** não existe, com os dados e a geometria aqui definidos, um tamanho absoluto único do «universo real dentro de um buraco negro» que torne sua presença indetectável na parte observável. Para fazer essa inferência seriam necessários (i) métrica interna e conteúdo material, (ii) escolha da folheação/definição de tamanho, (iii) observador e sua posição, (iv) dinâmica de expansão e rotação, (v) mapeamento de observáveis CMB, BAO, supernovas e velocidades; (vi) ajuste estatístico. Nenhum desses elos vem automaticamente da fórmula do raio de Schwarzschild nem da curvatura FLRW. 

**[M] Foram realmente executadas quatro operações de bancada:** escala de curvatura FLRW sob valores assumidos de \(|\Omega_k|\); um teste paramétrico ilustrativo de «efeito global invisível»; um controle estritamente cinemático de rotação rígida/diferencial; e uma equivalência dimensional raio–massa de Schwarzschild. Não foi executado cálculo de geodésicas de Kerr, evolução cosmológica relativística, inferência observacional, nem teste real de buraco negro cosmológico.

## 1. Pergunta e hipóteses concorrentes

**Pergunta:** qual escala global seria necessária para um observador no domínio acessível não distinguir o entorno de uma geometria cósmica maior, possivelmente relacionada ao interior de um objeto gravitacional rotativo?

- **H0 [F/M de referência]:** geometria aproximadamente FLRW isotrópica no volume observável; expansão governada por \(H(z)\); velocidades peculiares locais. A finitude global não precisa ser inferível.
- **H1 [H]:** espaço-tempo cosmológico integrado a uma solução de buraco negro, com rotação/anisotropia em escalas muito maiores e efeitos observáveis localmente suprimidos.
- **H1a [M — cinemática somente]:** componente global de rotação diferencial produz aproximação/afastamento em linha de visada.
- **H1b [?]:** a mesma solução explica expansão acelerada, isotropia observada, formação de estruturas e CMB. Não testado.

### Falsificadores e controles

A bancada considera **falha** quando: o redshift angular previsto não acompanha o espectro e a distribuição observados; surge anisotropia vetorial acima da permitida; o modelo deixa de reproduzir história H(z), BAO, supernovas e CMB; violam-se equações de Einstein e causalidade; ou a quantidade «tamanho do buraco negro/universo» depende arbitrariamente da escolha de coordenadas/folheação.

## 2. Dados e fontes, sem arredondamentos escondidos

- [F] **Raio observável de referência:** \(R_{\rm obs}=46\ \mathrm{Gly}\) (metade dos aproximadamente 92 bilhões de anos-luz de diâmetro indicados pela NASA; aproximação arredondada, não distância ao horizonte de eventos). Fonte: NASA, *How Big is Space?* (2025), https://www.nasa.gov/science-research/astrophysics/how-big-is-space-we-asked-a-nasa-expert-episode-61/ .
- [F] **Hubble de referência:** \(H_0=67{,}4\ \mathrm{km\ s^{-1}\ Mpc^{-1}}\), condicionado a ΛCDM básico, Planck 2018. DOI https://doi.org/10.1051/0004-6361/201833910 .
- [F] **Exemplo de condicionamento observacional de curvatura:** Planck 2018 + BAO: \(\Omega_k \simeq 0{,}001\pm0{,}002\) (68% e sob hipóteses da análise). Os \(|\Omega_k|\) desta bancada são **pontos assumidos**, NÃO limites inferidos nem intervalos de confiança. Dados alternativos e ajustes menos dependentes de modelos podem ter incertezas muito diferentes.
- [F] **Anisotropia global:** Saadeh et al. (2016), DOI https://doi.org/10.1103/PhysRevLett.117.131302 : para o modo vetorial dos modelos Bianchi examinados, limite de **cisalhamento normalizado** \((\sigma_V/H)_0<4{,}7\times10^{-11}\) (95%). **Este número não é um limite direto para \(\Omega_{\rm rot}/H\) de qualquer métrica e NÃO foi aplicado como limite de tamanho.**
- [D] **Orçamento exploratório de anisotropia:** \(\varepsilon=10^{-5}\), tomado apenas para mostrar a sensibilidade do toy; NÃO constitui inferência do limite das observações nem substitui os likelihoods de temperatura e polarização.

## 3. Bancada A — Curvatura FLRW e escala geométrica [F/M]

Para uma seção espacial homogênea e isotrópica com curvatura não nula, a escala atual de curvatura é:

\[
R_\mathrm{curv}=\frac{c}{H_0\sqrt{|\Omega_k|}},\quad R_H=\frac{c}{H_0}\approx14{,}5073\ \mathrm{Gly}.
\]

**[D] Hipótese adicional:** somente se a topologia for a de uma 3-esfera simplesmente conexa (geometria FLRW fechada), a distância geodésica máxima entre pontos é \(\pi R_\mathrm{curv}\). Isto não é diâmetro de imersão euclidiana nem raio de horizonte de buraco negro. Topologias compactas planas ou hiperbólicas, ou um espaço infinito, possuem situações distintas.

| \(|\Omega_k|\) assumido | \(R_\mathrm{curv}\) (Gly) | \(R_\mathrm{curv}/R_\mathrm{obs}\) | \(\pi R_\mathrm{curv}\) (Gly) se 3-esfera |
|---:|---:|---:|---:|
| 0,005 | 205,164 | 4,460 | 644,542 |
| 0,002 | 324,393 | 7,052 | 1.019,111 |
| 0,001 | 458,761 | 9,973 | 1.441,241 |
| 0,0001 | 1.450,730 | 31,538 | 4.557,604 |

**[M] Interpretação:** podemos calcular escalas de *curvatura* de centenas ou milhares de bilhões de anos-luz sob parametrizações dadas. **NÃO é válido substituí-las pelo tamanho do universo interior de um buraco negro.** A topologia e a métrica global não foram identificadas.

## 4. Bancada B — Sensibilidade exploratória de visibilidade [M ilustrativo]

Um ansatz **arbitrário** para efeito global na região observável é

\[
\delta_\mathrm{global}=A\left(\frac{R_\mathrm{obs}}{L}\right)^p,
\quad \delta_\mathrm{global}\le\varepsilon
\quad\Longrightarrow\quad L\ge R_\mathrm{obs}\left(\frac{A}{\varepsilon}\right)^{1/p}.
\]

\(A\) e \(p\) são coeficientes de um toy, não parâmetros medidos ou derivados de Kerr. \(L\) é uma escala hipotética de variação global; não se define que seja o tamanho do espaço, raio de horizonte ou curvatura cosmológica.

| \(A\) [assumido] | \(p\) [assumido] | \(L_{\min}\) (Gly) | \(L_{\min}/R_\mathrm{obs}\) |
|---:|---:|---:|---:|
| 1 | 1 | 4.600.000 | 100.000 |
| 1 | 2 | 14.546,477 | 316,228 |
| 0,01 | 1 | 46.000 | 1.000 |
| 0,01 | 2 | 1.454,648 | 31,623 |

**[M] Resultado crucial:** variar apenas \(A\) ou \(p\) muda a resposta por ordens de grandeza. Se \(A=0\), qualquer \(L\) satisfaz esse toy: o tamanho é matematicamente **não identificável**. Esses resultados são uma demonstração de dependência de hipóteses, **não limites físicos ou observacionais**.

## 5. Bancada C — Aproximação e afastamento no redemoinho [M cinemático]

O controle rigidamente rotativo em um plano é \(\mathbf v(\mathbf x)=\boldsymbol\omega\times\mathbf x\). Para posições \(\mathbf x_i\), \(\mathbf x_j\), com \(\hat{\mathbf n}=(\mathbf x_j-\mathbf x_i)/|\mathbf x_j-\mathbf x_i|\),

\[
\Delta v_\mathrm{LOS}=\big(\mathbf v_j-\mathbf v_i\big)\cdot\hat{\mathbf n}
=\big[\boldsymbol\omega\times(\mathbf x_j-\mathbf x_i)\big]\cdot\hat{\mathbf n}=0.
\]

**[M/PASS]** quatro pares numéricos independentes deram \(|\Delta v_\mathrm{LOS}|<10^{-12}\) em unidades arbitrárias. Portanto, rotação rígida por si só não pode gerar os sinais mistos de afastamento/aproximação **neste modelo**.

Para rotação diferencial introduziu-se \(\omega(r)=0{,}3/[1+(r/10)^2]\) (comprimento e velocidade em **unidades arbitrárias**, sem calibração física), com observador fora do eixo \((3;0{,}5)\). Em oito pontos de teste, quatro têm componente radial positiva e quatro negativa. **[M/PASS para existência de sinais mistos]**, mas **[?]** ausência de testes de aceleração FLRW, CMB, dinâmica relativística e observações. Rotação diferencial gera sinais de linha de visão, mas não prova redshifts cosmológicos nem \(\ddot a>0\).

## 6. Bancada D — Raio-massa Schwarzschild: apenas comparação dimensional [F/M]

Se um *objeto Schwarzschild assintoticamente plano* tivesse raio de horizonte \(r_s=R_\mathrm{obs}=46\ \mathrm{Gly}\), então, pela fórmula externa,

\[
M=\frac{c^2r_s}{2G}\approx1{,}47356\times10^{23}\ M_\odot.
\]

**Não se deduz** que a massa do nosso Universo seja esta, que o raio de horizonte da hipótese coincida com \(R_\mathrm{obs}\), que o volume próprio interior tenha tal raio, ou que o interior de Kerr seja FLRW. O parâmetro radial e as fatias espaciais no interior de um horizonte não são equivalentes à geometria euclidiana de uma esfera. A identificação \(r_s=R_\mathrm{obs}\) foi **assumida**, não derivada.

## 7. Auditoria dos critérios da RUP

| Gate | Situação em 26/10/2026 | Resultado |
|---|---|---|
| BHC-01: RUP e fontes projetuais lidas | EXECUTADO | PASS documental |
| BHC-02: cálculo FLRW \(R_\mathrm{curv}\) | EXECUTADO | PASS matemático (condicional) |
| BHC-03: toy \(L(A,p,\varepsilon)\) | EXECUTADO | PASS algébrico; **tamanho real indeterminado** |
| BHC-04: rotação rígida e diferencial | EXECUTADO | Rígida: sinal radial ausente (controle negativo); diferencial: sinais mistos |
| BHC-05: equivalência Schwarzschild | EXECUTADO | PASS dimensional sem inferência cosmológica |
| BHC-06: métrica de interior de BH cosmológico | NÃO EXECUTADO | NOT_TESTED |
| BHC-07: resolver Einstein e geodésicas 4D | NÃO EXECUTADO | NOT_TESTED |
| BHC-08: comparar observáveis CMB/BAO/SNe/H(z) | NÃO EXECUTADO | NOT_TESTED |
| BHC-09: recuperar \(\ddot a>0\) sem inserir \(\Lambda\) por definição | NÃO EXECUTADO | NOT_TESTED |
| BHC-10: converter as escalas ao tamanho universal físico | NÃO IDENTIFICÁVEL | OPEN [?] |

## 8. Próxima bancada física proposta — não executada

**BHC-REL-02 (proposta):** escolher **uma solução relativística completa** de cosmologia anisotrópica/rotativa, por exemplo uma família Bianchi com setor de matéria e \(\Lambda\) explicitamente especificados, ou uma solução cosmológica concreta ligada a um interior de BH por condições de junção. Declarar métrica \(g_{\mu\nu}\), tensor \(T_{\mu\nu}\), domínio regular, hipersuperfície espacial, observador, tempo próprio, velocidade do fluido, vorticidade, expansão, cisalhamento, parâmetros e condições de contorno. Resolver \(G_{\mu\nu}+\Lambda g_{\mu\nu}=(8\pi G/c^4)T_{\mu\nu}\), com conservação; integrar geodésicas de fótons; prever \(H(z)\), anisotropias de céu, espectro CMB e distância–redshift; comparar com likelihoods apropriados. **Não generalizar a restrição de cisalhamento vetorial Bianchi para qualquer Kerr sem mapa matemático específico.** Só então varrer uma escala própria \(L\), caso a solução a defina operacionalmente.

**Observação de identifiabilidade:** sem sinal global mensurável, mesmo dados ideais restritos a uma vizinhança causal não garantem medir tamanho global; modelos cosmológicos globalmente diferentes podem compartilhar observáveis locais. O objetivo de uma bancada futura é colocar limites **num modelo concreto**, não prometer um valor universal.

## 9. Execução e proveniência

- Script: `bench_bh_cosmologia.py`, Python 3, somente biblioteca padrão, constantes SI especificadas no código.
- Rodar no diretório da bancada: `python3 bench_bh_cosmologia.py`.
- Saídas regeneráveis em `resultados/`: CSV por gate e `resumo_resultados.json`; saída capturada `execucao_stdout.json`.
- Cada conjunto distingue valores observacionais referenciados, parâmetros arbitrários e resultados calculados. As unidades arbitrárias no toy rotativo **não** são velocidades de galáxias reais.
- O programa possui controles `assert` para nulos rígidos, sinais diferenciais e degenerescência de escala; executar sem erros não valida H1.
- O código não calcula a geometria do bulk HRF nem supõe que DIO/GMFt sejam partículas ontológicas; esta bancada é **cosmológica clássica**, separada das bancadas HRF de informação distribuída.

## 10. Bibliografia e proveniência de citação

**Fontes internas:** (i) `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md` [D]; (ii) `HRF_Geometria_Emergente_Caminhos_RG_MQ_v0_1_PT_2026-10-24` [D/H/?]; (iii) `HRF_Research_Book_Cap03_Base_Quantica_Compartilhada_DIO_e_GMFt_v0_5_PT_2026-10-24.md` [D/H/?]. Caderno Mestre de Referências v0.2 (10/10/2026) consultado; reusar HRF-REF-0021 para relat. geral (David Tong) se citado na integração futura. Não foram renumerados IDs; fontes externas novas aguardam conferência de duplicatas nos índices bibliográficos posteriores antes de receber HRF-REF.

**Fontes primárias e institucionais utilizadas nesta bancada (IDs HRF pendentes):**

1. NASA, *How Big is Space? We Asked a NASA Expert* (21 maio 2025). https://www.nasa.gov/science-research/astrophysics/how-big-is-space-we-asked-a-nasa-expert-episode-61/ — dimensão observável de referência, e ausência de medida do tamanho global.
2. Planck Collaboration, *Planck 2018 results. VI. Cosmological parameters*, *Astronomy & Astrophysics* **641**, A6 (2020), https://doi.org/10.1051/0004-6361/201833910 — \(H_0\), curvatura \(\Omega_k\) e dependência de modelo.
3. Saadeh, D.; Feeney, S. M.; Pontzen, A.; Peiris, H. V.; McEwen, J. D. (2016), *How Isotropic is the Universe?*, *Physical Review Letters* **117**, 131302, https://doi.org/10.1103/PhysRevLett.117.131302 — limite de cisalhamento anisotrópico em modelos Bianchi testados.

**Decisão [D]:** preservar este protocolo/relatório como bancada independente e não alterar resultados ou status anteriores do Research Book.
