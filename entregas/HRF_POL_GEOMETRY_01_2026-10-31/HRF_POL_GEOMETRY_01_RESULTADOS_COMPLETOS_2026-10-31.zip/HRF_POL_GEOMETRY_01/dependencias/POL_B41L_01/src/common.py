"""[D] IO estrito/atômico e integridade; nenhum cálculo em importação."""
from pathlib import Path
import hashlib,json,os,tempfile
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
DEP=ROOT/'dependencias/HRF_B41L_B1_Lancamento_Limpo'
def sha(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()
def clean(v):
 if isinstance(v,dict):return {str(k):clean(x) for k,x in v.items()}
 if isinstance(v,(list,tuple)):return [clean(x) for x in v]
 if isinstance(v,np.ndarray):return clean(v.tolist())
 if isinstance(v,np.generic):return clean(v.item())
 if isinstance(v,complex):return [v.real,v.imag]
 if isinstance(v,float) and not np.isfinite(v):return None
 return v
def atomic_json(p,v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.tmp')
 with t.open('w',encoding='utf-8') as f:json.dump(clean(v),f,indent=2,ensure_ascii=False,allow_nan=False);f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def atomic_npz(p,**v):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True);t=p.with_name(p.name+'.tmp')
 with t.open('wb') as f:np.savez_compressed(f,**v);f.flush();os.fsync(f.fileno())
 os.replace(t,p)
def verify_dependency():
 rows=[]
 manifest=DEP/'HRF_B41L_hashes_antes_da_execucao_2026-10-29_2000-clau.txt'
 for line in manifest.read_text().splitlines():
  if not line.strip():continue
  h,n=line.split(maxsplit=1);p=(DEP/n).resolve()
  if not p.is_relative_to(DEP) or not p.is_file() or sha(p)!=h:raise ValueError('B41L alterada/ausente: '+n)
  rows.append(n)
 return rows
def verify_freeze():
 p=ROOT/'HASHES_PREREGISTRO.txt'
 if not p.exists():raise FileNotFoundError('pré-registro ainda não congelado')
 for line in p.read_text().splitlines():
  h,n=line.split('  ',1);q=(ROOT/n).resolve()
  if not q.is_relative_to(ROOT) or not q.is_file() or sha(q)!=h:raise ValueError('congelamento alterado: '+n)
 return True
def code_hash():
 h=hashlib.sha256()
 for p in sorted((ROOT/'src').glob('*.py')):h.update(p.name.encode());h.update(p.read_bytes())
 return h.hexdigest()

def available_memory():
 try:
  mem=dict(l.split(':',1) for l in Path('/proc/meminfo').read_text().splitlines());value=int(mem['MemAvailable'].strip().split()[0])*1024
  p=Path('/sys/fs/cgroup/memory.max')
  if p.exists() and p.read_text().strip()!='max':value=min(value,int(p.read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text()))
  return max(value,0)
 except (OSError,KeyError,ValueError):return 0
