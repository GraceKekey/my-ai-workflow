"""[F] Jones/Stokes em base destrógira; S3=2 Im(E1* E2)."""
import numpy as np
STATES={'H':[1,0],'V':[0,1],'D':np.array([1,1])/np.sqrt(2),'A':np.array([1,-1])/np.sqrt(2),
 'C+':np.array([1,1j])/np.sqrt(2),'C-':np.array([1,-1j])/np.sqrt(2),
 'E+':np.array([np.sqrt(3),1j])/2,'E-':np.array([np.sqrt(3),-1j])/2,
 'fase_alterada':np.array([1,np.exp(1j*np.pi/3)])/np.sqrt(2),'nulo':[0,0]}
STATES={k:np.asarray(v,complex) for k,v in STATES.items()}

def stokes(amplitudes,weights=None):
 a=np.atleast_2d(np.asarray(amplitudes,complex));w=np.ones(len(a)) if weights is None else np.asarray(weights)
 C=np.einsum('b,bi,bj->ij',w,a.conj(),a)/w.sum();S=np.array([np.trace(C).real,(C[0,0]-C[1,1]).real,2*C[0,1].real,2*C[0,1].imag])
 if S[0]<=1e-24:return dict(status='UNDEFINED_ZERO_INTENSITY',S=S,s=None,degree=None,purity=None,relative_phase=None)
 return dict(status='DEFINED',S=S,s=S[1:]/S[0],degree=float(np.linalg.norm(S[1:])/S[0]),purity=float(np.trace(C@C).real/S[0]**2),relative_phase=float(np.angle(C[0,1])) if abs(C[0,1])>1e-24 else None)
def distance(a,b):
 if a.get('s') is None or b.get('s') is None:return None
 return float(np.linalg.norm(np.asarray(a['s'])-np.asarray(b['s'])))
def fit_windows(t,signals,omega,weights,cycles=3.,overlap=.5):
 """Séries físicas complexas espaciais: ajustes ±omega e DC; sem normalizar campos."""
 t=np.asarray(t);a=np.asarray(signals);period=2*np.pi/omega;width=cycles*period;step=width*(1-overlap);rows=[];start=t[0]
 while start+width<=t[-1]+1e-9:
  ids=(t>=start-1e-12)&(t<=start+width+1e-12);tt=t[ids];y=a[ids]
  if len(tt)<24:break
  X=np.c_[np.exp(-1j*omega*tt),np.exp(1j*omega*tt),np.ones(len(tt))];cond=float(np.linalg.cond(X))
  coef=np.linalg.lstsq(X,y.reshape(len(tt),-1),rcond=None)[0];pred=X@coef
  residual=float(np.linalg.norm(pred-y.reshape(len(tt),-1))/max(np.linalg.norm(y),1e-30))
  phasor=2*coef[0].reshape(a.shape[1:]);measurement=stokes(phasor,weights)
  rows.append(dict(t_start=float(start),t_end=float(start+width),samples=len(tt),condition=cond,residual=residual,
                   fit_status='RESOLVED' if cond<=100 else 'ILL_CONDITIONED',phasor=phasor,**measurement))
  start+=step
 return rows
