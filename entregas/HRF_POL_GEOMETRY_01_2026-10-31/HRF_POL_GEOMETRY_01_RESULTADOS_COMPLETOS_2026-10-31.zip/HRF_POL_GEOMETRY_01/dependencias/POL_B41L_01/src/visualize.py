"""[M] Figuras e tabelas exclusivamente de arquivos de evolução reais."""
from pathlib import Path
import csv,json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from common import atomic_json

def figures(folder,output):
 folder=Path(folder);out=Path(output);out.mkdir(parents=True,exist_ok=True)
 files=sorted(folder.glob('*/evaluation.json'))
 if not files:raise FileNotFoundError('nenhum caso físico concluído para desenhar')
 rows=[json.loads(p.read_text()) for p in files];selected=[r for r in rows if r['case']['variant']=='V1' and r['case']['state']!='nulo'][:8]
 with (out/'casos.csv').open('w',newline='',encoding='utf-8') as f:
  cols=['case_id','seed','n','state','variant','dt_scale','G2','G3','G4','G6','energy_drift','gauss0','maxwell_stokes_error'];w=csv.DictWriter(f,fieldnames=cols);w.writeheader()
  for r in rows:w.writerow({k:r['case'].get(k,r.get(k)) for k in cols})
 fig,axs=plt.subplots(2,2,figsize=(12,8))
 for r in selected:
  ws=[w for w in r['windows'] if w['s'] is not None]
  if not ws:continue
  t=np.array([(w['t_start']+w['t_end'])/2 for w in ws]);s=np.array([w['s'] for w in ws]);label=r['case']['case_id']
  for i in range(3):axs.flat[i].plot(t,s[:,i],label=label)
  S0=np.array([w['S'][0] for w in ws]);axs.flat[3].plot(t,S0/S0[0],label=label)
 for ax,name in zip(axs.flat,['S1/S0','S2/S0','S3/S0','S0/S0(primeira janela)']):ax.set(xlabel='t B41L',ylabel=name);ax.grid(alpha=.3)
 axs[0,0].legend(fontsize=5);fig.suptitle('[M] Stokes extraídos da evolução real; fumaça não certifica física');fig.tight_layout();fig.savefig(out/'01_stokes.png',dpi=140);plt.close(fig)
 fig=plt.figure(figsize=(8,7));ax=fig.add_subplot(projection='3d');u=np.linspace(0,2*np.pi,40);v=np.linspace(0,np.pi,20)
 ax.plot_wireframe(np.outer(np.cos(u),np.sin(v)),np.outer(np.sin(u),np.sin(v)),np.outer(np.ones(len(u)),np.cos(v)),alpha=.1,rstride=3,cstride=3)
 for r in selected:
  s=np.array([w['s'] for w in r['windows'] if w['s'] is not None])
  if len(s):ax.plot(*s.T,'o-',label=r['case']['state'])
 ax.set(xlabel='S1/S0',ylabel='S2/S0',zlabel='S3/S0',title='[M] Poincaré: pontos medidos, sem projetar na esfera');ax.legend(fontsize=7);fig.tight_layout();fig.savefig(out/'02_poincare.png',dpi=140);plt.close(fig)
 fig,axs=plt.subplots(1,2,figsize=(12,4))
 for r in selected:
  with np.load(folder/r['case']['case_id']/'fields.npz',allow_pickle=False) as d:
   t=d['times'];H=d['energy'];den=max(abs(H[0]),1e-25)
   axs[0].plot(t,(H-H[0])/den,label=r['case']['state']);axs[1].semilogy(t,np.maximum(d['gauss_abs']/max(d['pi_norm'].max(),1e-25),1e-20))
 axs[0].set(xlabel='t',ylabel='(H-H0)/H0');axs[1].set(xlabel='t',ylabel='Gauss relativo');axs[0].legend();fig.suptitle('[M] Hamiltoniano e Gauss originais');fig.tight_layout();fig.savefig(out/'03_conservacoes.png',dpi=140);plt.close(fig)
 summary=json.loads((folder/'summary.json').read_text()) if (folder/'summary.json').exists() else {}
 rates=summary.get('seed_failure_rates',[])
 if rates:
  fig,ax=plt.subplots(figsize=(8,4));n=np.array([r['n'] for r in rates]);f=np.array([r['failures']/r['seeds'] for r in rates]);lo=np.array([r['Clopper_Pearson95'][0] for r in rates]);hi=np.array([r['Clopper_Pearson95'][1] for r in rates]);ax.errorbar(n,f,yerr=[f-lo,hi-f],fmt='o');ax.set(xlabel='lado da malha',ylabel='taxa de falha por semente',ylim=(-.02,1.02),title='[M] Clopper–Pearson 95%; sem descartar sementes');fig.tight_layout();fig.savefig(out/'04_robustez.png',dpi=140);plt.close(fig)
 lines=['# Relatório gerado dos dados disponíveis','', '**[M] '+str(summary.get('status','DADOS_PARCIAIS'))+'**. Fumaça não é rodada científica completa.','', '| Gate | Estado |','|---|---|']
 for k in ('G0','G1','G2','G3','G4','G5','G6','G7'):lines.append('|'+k+'|'+str(summary.get(k,'NOT_EXECUTED'))+'|')
 lines+=['','[?] Os P01–P05 originais não foram disponibilizados. Nenhum PASS Jones é transferido ao setor relacional. Os resultados históricos B1/B41/B41H/B41L permanecem intactos.','', '[D] Valores por caso e falhas completas em casos.csv; dados de campo/cochain e metadados nos diretórios de caso.']
 (out/'RELATORIO_DADOS.md').write_text('\n'.join(lines)+'\n',encoding='utf-8');atomic_json(out/'figuras.json',dict(status='GENERATED_FROM_ACTUAL_DATA',cases=len(rows),PDE_runs=0))
