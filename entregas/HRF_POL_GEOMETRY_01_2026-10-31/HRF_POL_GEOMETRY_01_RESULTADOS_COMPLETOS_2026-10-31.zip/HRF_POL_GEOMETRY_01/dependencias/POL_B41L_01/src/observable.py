"""[M] Campo físico Whitney original e harmônico espacial por oito subvolumes fixos."""
import numpy as np
from stokes import stokes
class Observer:
 def __init__(self,ctx,k,ea,eb):
  self.ctx=ctx;C=ctx['C'];self.k=k;self.ea=ea;self.eb=eb;self.kh=k/np.linalg.norm(k)
  self.centers=C.Xt.mean(1);self.phase=np.exp(-1j*(self.centers@k));cells=np.minimum((self.centers/C.L*2).astype(int),1)
  self.regions=cells[:,0]*4+cells[:,1]*2+cells[:,2];self.weights=np.bincount(self.regions,weights=C.vol,minlength=8)
  if np.any(self.weights<=0):raise ValueError('subvolume sem tetraedros')
 def fields(self,q,v):
  PC=self.ctx['PC'];C=self.ctx['C']
  # PC.campos_tet(C,i*v,1).E = i*W(i*v) = -Wv, incluindo a orientação original.
  E=PC.campos_tet(C,1j*v,1.)[0].real;B=PC.campos_tet(C,q,1.)[1].real
  return E,B
 def amplitudes(self,vector):
  C=self.ctx['C'];values=np.c_[vector@self.ea,vector@self.eb,vector@self.kh]*self.phase[:,None]
  a=np.empty((8,3),complex)
  for r in range(8):
   ids=self.regions==r;a[r]=(values[ids]*C.vol[ids,None]).sum(axis=0)/self.weights[r]
  return a
 def sample(self,q,v):
  C=self.ctx['C'];M=self.ctx['M1'];K=self.ctx['K'];pi=M@v;E,B=self.fields(q,v)
  return self.amplitudes(E),float(.5*v@pi+.5*q@(K@q)),float(np.linalg.norm(C.d0.T@pi)),np.linalg.norm(pi), (np.cross(E,B)*C.vol[:,None]).sum(0)
 def initial_phasor(self,q,v,omega):
  qt,_=self.ctx['cleaner'].limpar(q);E,_=self.fields(q,v);Qfield=self.ctx['PC'].campos_tet(self.ctx['C'],qt,omega)[0]
  return self.amplitudes(E+Qfield)[:,:2]
 def gauge_test(self,q,v,seed=777):
  C=self.ctx['C'];phi=np.random.default_rng(seed).normal(size=C.N);gq=q+C.d0@phi
  E,B=self.fields(q,v);Eg,Bg=self.fields(gq,v)
  es=float(np.linalg.norm(E-Eg)/(np.linalg.norm(E) if np.linalg.norm(E)>1e-25 else 1.));bs=float(np.linalg.norm(B-Bg)/(np.linalg.norm(B) if np.linalg.norm(B)>1e-25 else 1.))
  return dict(E_relative=es,B_relative=bs,scope='gauge temporal residual: chi espacial e independente do tempo; pi inalterado')
