"""[F/M] Controle Jones independente NOVO; não se passa pelos P01–P05 ausentes."""
import numpy as np
from stokes import STATES,stokes,distance
from common import atomic_json

def run_controls(output):
 # Frozen expected Stokes from definitions, including two elliptical and altered phase states.
 expected={'H':[1,0,0],'V':[-1,0,0],'D':[0,1,0],'A':[0,-1,0],'C+':[0,0,1],'C-':[0,0,-1],
  'E+':[.5,0,np.sqrt(3)/2],'E-':[.5,0,-np.sqrt(3)/2],'fase_alterada':[0,.5,np.sqrt(3)/2]}
 rows=[]
 for name,j in STATES.items():
  s=stokes(j)
  if name=='nulo':ok=s['status']=='UNDEFINED_ZERO_INTENSITY'
  else:
   ok=np.linalg.norm(s['s']-expected[name])<=1e-12
   phase=np.exp(1j*.731);unitary=np.array([[np.cos(.23),-np.sin(.23)],[np.sin(.23),np.cos(.23)]],complex)
   ok=ok and distance(s,stokes(np.array(j)*phase))<=1e-12
   ok=ok and abs(stokes(unitary@j)['S'][0]-s['S'][0])<=1e-12
  rows.append(dict(state=name,pass_diagnostic=bool(ok),measured=s))
 # Loss must not disappear by normalization; a wrong S3 map must fail correspondence.
 original=stokes(STATES['C+']);loss=stokes(.5*STATES['C+']);wrong=stokes(np.conj(STATES['C+']))
 loss_detected=abs(loss['S'][0]/original['S'][0]-1)>.05;wrong_detected=distance(original,wrong)>.1
 mixture=stokes(np.array([STATES['H'],STATES['V']]))
 result=dict(scope='NEW_CONVENTIONAL_CONTROL_NOT_ORIGINAL_POL01',diagnostic_status='PASS' if all(r['pass_diagnostic'] for r in rows) and loss_detected and wrong_detected and mixture['degree']<1e-12 else 'FAIL',
  G1='PENDING',reason='P01–P05 originais não fornecidos; nenhum ID foi inventado',states=rows,artificial_loss_detected=loss_detected,wrong_observable_map_detected=wrong_detected,unpolarized_mixture=mixture,relational_gate='NOT_EXECUTED')
 atomic_json(output,result);return result
