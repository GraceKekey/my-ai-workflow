"""[D] Testes/controle/plan/fumaça/completa separados; completa exige confirmação no Colab."""
import argparse,json,sys,unittest
from pathlib import Path
from common import ROOT,atomic_json,verify_dependency,verify_freeze
from planning import config,plan

def main(argv=None):
 p=argparse.ArgumentParser();s=p.add_subparsers(dest='command',required=True)
 for name in ('plan','run','evaluate'):
  a=s.add_parser(name);a.add_argument('--perfil',choices=['fumaca','completo'],default='fumaca');a.add_argument('--output',required=True);a.add_argument('--executar',action='store_true');a.add_argument('--confirmo-completa',action='store_true');a.add_argument('--caso')
 a=s.add_parser('verify');a.add_argument('--output')
 a=s.add_parser('test');a.add_argument('--output',required=True)
 a=s.add_parser('controls');a.add_argument('--output',required=True)
 a=s.add_parser('figures');a.add_argument('--input',required=True);a.add_argument('--output',required=True)
 args=p.parse_args(argv)
 try:
  if args.command=='verify':
   files=verify_dependency();verify_freeze();result=dict(status='PASS_INTEGRITY_ONLY',frozen_B41L_files=len(files));print(json.dumps(result))
   if args.output:atomic_json(args.output,result)
  elif args.command=='test':
   import io,contextlib
   stream=io.StringIO()
   with contextlib.redirect_stdout(stream),contextlib.redirect_stderr(stream):result=unittest.TextTestRunner(stream=stream,verbosity=2).run(unittest.defaultTestLoader.discover(str(ROOT/'tests')))
   out=Path(args.output);out.mkdir(parents=True,exist_ok=False);(out/'tests.log').write_text(stream.getvalue(),encoding='utf-8')
   atomic_json(out/'summary.json',dict(status='PASS_SOFTWARE' if result.wasSuccessful() else 'FAIL_SOFTWARE',tests=result.testsRun,errors=len(result.errors),failures=len(result.failures),scope='unit, algebra and tiny original-kernel fidelity reference only'))
   print(stream.getvalue());return 0 if result.wasSuccessful() else 1
  elif args.command=='controls':
   from controls import run_controls
   result=run_controls(args.output);print(result['diagnostic_status'],'G1',result['G1']);return 0 if result['diagnostic_status']=='PASS' else 1
  elif args.command in ('plan','run','evaluate'):
   c=config(args.perfil)
   if args.command=='evaluate':
    from evaluate import aggregate,criteria
    result=aggregate(args.output,c,criteria());atomic_json(Path(args.output)/'summary.json',result);print(json.dumps(result));return 0
   result=plan(c,args.output);print(json.dumps(result,indent=2))
   if args.command=='run' and args.executar:
    from runner import run
    run(c,args.output,args.confirmo_completa,args.caso)
  elif args.command=='figures':
   from visualize import figures
   figures(args.input,args.output)
  return 0
 except (ValueError,FileNotFoundError,MemoryError,PermissionError,FloatingPointError) as error:
  status='BLOCKED_RESOURCES' if isinstance(error,MemoryError) else 'PENDING' if isinstance(error,(FileNotFoundError,PermissionError)) else 'FAIL'
  print(json.dumps(dict(status=status,error=str(error)),ensure_ascii=False));return 2
