"""[D] Adaptador sem editar B41L. Montagem, limpeza e kernel de Verlet são os originais."""
import ast,sys,copy,hashlib
import numpy as np
from common import DEP,verify_dependency
_loaded=None
def modules():
 global _loaded
 if _loaded is None:
  verify_dependency();sys.dont_write_bytecode=True;sys.path.insert(0,str(DEP/'src'))
  import b41l_comum as B
  import b41l_limpeza as LZ
  import b41l_bloco_b as BB
  import c5a_photon_closure as PC
  import c5a_curl_curl_emergente as CC
  _loaded=(B,LZ,BB,PC,CC)
 return _loaded
def original_step():
 """Compila quatro nós AST INALTERADOS do laço de conservacao do código congelado."""
 p=DEP/'src/b41l_bloco_b.py';tree=ast.parse(p.read_text());f=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='conservacao')
 loop=next(n for n in f.body if isinstance(n,ast.For) and isinstance(n.target,ast.Name) and n.target.id=='it')
 body=copy.deepcopy(loop.body[-4:])
 expected=['v += 0.5 * dt * a','q += dt * v','a = -lu.solve(K @ q)','v += 0.5 * dt * a']
 if [ast.unparse(n) for n in body]!=expected:raise ValueError('kernel histórico não reconhecido; recusa substituição')
 function=ast.FunctionDef(name='step',args=ast.arguments(posonlyargs=[],args=[ast.arg(arg=n) for n in ('q','v','a','dt','lu','K')],kwonlyargs=[],kw_defaults=[],defaults=[]),body=body+[ast.Return(value=ast.Tuple(elts=[ast.Name(id=n,ctx=ast.Load()) for n in ('q','v','a')],ctx=ast.Load()))],decorator_list=[])
 function.type_params=[]
 module=ast.fix_missing_locations(ast.Module(body=[function],type_ignores=[]));ns={};exec(compile(module,str(p),'exec'),ns)
 return ns['step'],hashlib.sha256(ast.dump(ast.Module(body=body,type_ignores=[])).encode()).hexdigest()
def context(seed,order,n):
 import scipy.sparse.linalg as spl
 B,LZ,BB,PC,CC=modules();C,M1,M2,K=BB.malha_do_caso(seed,order,n)
 return dict(C=C,M1=M1,M2=M2,K=K,lu=spl.splu(M1.tocsc()),cleaner=LZ.Limpador(C.d0,M1,periodico=True),
             dt_original=1/np.sqrt(CC.limite_wmax(C)),PC=PC,LZ=LZ)
def prepare(ctx,direction,jones,variant,amplitude):
 C=ctx['C'];k=ctx['PC'].kvec(direction);omega=np.linalg.norm(k);ea,eb=ctx['LZ'].base_transversal(k)
 physical=np.asarray(jones,complex)[0]*ea+np.asarray(jones,complex)[1]*eb
 Q=C.onda_aresta(k,-1j*amplitude*physical/omega);q=Q.real.copy();v0=omega*Q.imag
 if variant=='V1':v,diag=ctx['cleaner'].limpar(v0)
 elif variant=='V0':v=v0.copy();diag=dict(res_transversal=None)
 else:raise ValueError('somente V0/V1; V1E não é calibração')
 return q,v,dict(k=k,omega=omega,ea=ea,eb=eb,cleaning=diag,original_velocity=v0)
