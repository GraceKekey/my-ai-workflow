#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C5A B1 — avaliador pré-registrado (escrito antes das saídas reais).

Lê saidas/<semente>/B1a_*.json, B1b_*.json, B1c_*.json e aplica:
  P1 — critérios internos do script (cópia literal da lógica de c5a_photon_closure.py, linhas 508–561), exceto o
       item 6; cada semente é avaliada em todos os itens que os seus blocos permitem (itens 7, 8 e 9 só existem nas 6
       sementes com B1c); passa se ≥ 9 de 10 sementes passarem em todos os itens disponíveis.
  P2 — helicidade (a) ordem do resíduo; (b) impureza ε = 1 − f_min; (c) deriva ε(f_min) − ε(início).
  P3 — ordem de (E² − P²c²)/E² (h = +1 e linear).
  P4 — Δ_hel compensado × h (B1c).
  P5 — Lorentz: |a1| < 0,1·|a2| nas duas malhas mais finas.
Bootstrap: 2000 reamostragens das sementes, gerador numpy com semente 12345, IC 95% por percentis 2,5 e 97,5.
Uso: python avaliar_B1.py <pasta_saidas> <saida.json>
"""
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI / "bancadas" / "c5a_curl_curl_emergente"))
import c5a_curl_curl_emergente as CC  # noqa: E402

eh_zero = CC.eh_zero
NBOOT, SEMBOOT = 2000, 12345
SEMENTES_A = list(range(20261201, 20261211))
SEMENTES_C = list(range(20261201, 20261207))
EPS_PISO = 1e-10


def carregar(pasta, bloco, s):
    p = Path(pasta) / str(s) / f"{bloco}_{s}.json"
    return json.loads(p.read_text(encoding="utf-8")) if p.exists() else None


def ordem(Nem, e):
    return float(-3 * np.polyfit(np.log(np.asarray(Nem, float)), np.log(np.asarray(e, float)), 1)[0])


def mono(e):
    return all(b < a for a, b in zip(e[:-1], e[1:]))


def boot_mediana(x, rng):
    x = np.asarray(x, float)
    m = [np.median(rng.choice(x, len(x))) for _ in range(NBOOT)]
    return float(np.median(x)), [float(np.percentile(m, 2.5)), float(np.percentile(m, 97.5))]


def inclinacao_pool(grupos):
    """grupos: lista (por semente) de listas de pares (x, y) já em log. OLS conjunto."""
    xs = np.concatenate([[p[0] for p in g] for g in grupos]); ys = np.concatenate([[p[1] for p in g] for g in grupos])
    return float(np.polyfit(xs, ys, 1)[0])


def boot_inclinacao(grupos, rng):
    est = inclinacao_pool(grupos)
    bs = [inclinacao_pool([grupos[i] for i in rng.integers(0, len(grupos), len(grupos))]) for _ in range(NBOOT)]
    return est, [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


# --------------------------------------------------------------- itens internos (lógica copiada do script original)
def itens_B1a(R, T):
    op = R["S3_S4_holonomia_e_operador"]
    h1, p3 = op["holonomia (P1 de c5a_holonomia_loops)"], op["operador e gauge (P3 de c5a_holonomia_loops)"]
    cv = p3["convergência do operador (forma fraca)"]
    po = R["S5_S6_polarizacoes_gauge_N0_N3"]
    ds = R["S7_S10_dispersao_lorentz"]
    dsN = [v for k, v in ds.items() if k.startswith("GMFs")]
    em = list(R["S8_S9_energia_momento_helicidade"].values())
    linhasD = T["dispersao.csv"]
    ok = {}
    ok["1_curl_curl_emerge"] = (all(eh_zero(x["max |H(invertido)·H − I|"]) for g in h1.values() for x in g) and
                                cv["W (∫|F|², Whitney)"][-1]["eps_cc_fraco"] < 0.5 * cv["W (∫|F|², Whitney)"][0]["eps_cc_fraco"] and
                                cv["W (∫|F|², Whitney)"][-1]["eps_cc_fraco"] < 0.02 and
                                cv["embaralhado (orientação aleatória)"][-1]["eps_cc_fraco"] > 0.5)
    ok["2_exatamente_2_modos_fisicos"] = (all(c["contagem ±15%"] == c["esperado (2 polarizações)"] for c in po["espectro verdadeiro: conchas"].values())
                                          and max(l["lon_T"] for l in linhasD) < 0.1
                                          and po["N0 pares isotrópicos"]["omega_L²/omega_T²"] > 0.5
                                          and po["N0b pares perpendiculares"]["omega_L²/omega_T²"] > 0.1)
    ok["3_longitudinal_e_gauge"] = (eh_zero(po["|d1 d0|_max"]) and eh_zero(po["|O[dφ]| / |O[q]|"]) and
                                    eh_zero(po["|div q̈| / |q̈| (div = d0ᵀ M1)"]) and
                                    all(abs(l["omega2_L/(ck)2"]) < 1e-10 for l in linhasD) and
                                    eh_zero(po["N1 conexão = gradiente puro (a = d0 φ)"]["circulação em todo loop"]) and
                                    po["N2 orientação embaralhada"]["|O[dφ]|/|O[q]|"] > 0.1)
    d1 = [abs(v["omega/ck ao longo de x, m = 1..6"][0] - 1) for v in dsN]
    ok["4_omega_ck"] = d1[-1] < d1[0] and d1[-1] < 0.01
    e2 = [abs(v["h = +1, z"]["(E² − P²c²)/E²"]) for v in em]
    e2l = [abs(v["linear, (1,1,1)"]["(E² − P²c²)/E²"]) for v in em]
    hr = [max(v["h = +1, z"]["|∇×q + h k q| / |∇×q|"], v["h = −1, z"]["|∇×q + h k q| / |∇×q|"]) for v in em]
    Nem = [int(k.split("= ")[1]) for k in R["S8_S9_energia_momento_helicidade"]]
    ok["5_E2_menos_P2c2"] = mono(e2) and mono(e2l) and ordem(Nem, e2) > 0.8 and ordem(Nem, e2l) > 0.8 and e2[-1] < 0.02
    an = [v["anisotropia: desvio de ω/ck entre 11 direções (|n| ≤ 3)"] for v in dsN]
    bi = [v["birrefringência média entre os 2 transversais (11 direções)"] for v in dsN]
    n6 = ds["N6 malha anisotrópica (espaçamento 2× em z)"]
    ok["10_lorentz_IR"] = (an[-1] < an[0] and an[-1] < 0.01 and bi[-1] < bi[0] and bi[-1] < 0.01 and
                           abs(n6["W (pesos geométricos)"]["v_z / v_x"] - 1) < 0.02 and abs(n6["U (peso uniforme)"]["v_z / v_x"] - 1) > 0.05)
    carga = R["S19_cargas"]
    ok["extra_fonte_conservada_compativel_com_gauss"] = (
        eh_zero(carga["corrente conservada (d0ᵀJ = 0)"]["lei de Gauss sem carga: |d0ᵀπ|/|π|"]) and
        not eh_zero(carga["corrente não conservada"]["lei de Gauss sem carga: |d0ᵀπ|/|π|"]) and
        eh_zero(carga["corrente não conservada"]["Gauss com a carga da continuidade: |d0ᵀπ + ρ|/|π|"]))
    a1 = [abs(v["ajuste ω/ck − 1 = a1·ka + a2·(ka)² + a3·(ka)³"][0]) for v in dsN]
    a2 = [abs(v["ajuste ω/ck − 1 = a1·ka + a2·(ka)² + a3·(ka)³"][1]) for v in dsN]
    serie = {"Nem": Nem, "e2_h+1": e2, "e2_linear": e2l, "residuo_hel": hr,
             "p_e2": ordem(Nem, e2), "p_e2l": ordem(Nem, e2l), "p_hel": ordem(Nem, hr),
             "a1": a1, "a2": a2, "omega_ck_m1": [v["omega/ck ao longo de x, m = 1..6"][0] for v in dsN]}
    return ok, serie


def itens_B1b(R, T):
    co = [v for k, v in R["S9_S15_conservacao"].items() if k.startswith("GMFs")]
    ok = {"extra_conservacoes_no_tempo": all(v["máx |ΔE/E|"] < 1e-2 and v["máx |ΔP_z/P_z|"] < 2e-2 and
                                             eh_zero(v["lei de Gauss |Δ(d0ᵀπ)|/|π| (máx)"]) for v in co)}
    linhas = T["conservacao.csv"]
    eps = {}
    for N in sorted({l["GMFs"] for l in linhas}):
        f = [l["fracao_h+"] for l in linhas if l["GMFs"] == N]
        eps[N] = {"eps_inicio": max(1 - f[0], EPS_PISO), "eps": max(1 - min(f), EPS_PISO), "deriva": f[0] - min(f)}
    return ok, eps


def itens_B1c(R):
    gl = R["S2_S11_S12_guia"]
    dh = gl["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"]
    br = gl["S12 backreaction (h = +1, −1)"]
    cu = R["S11_fundos_curvos"]
    ok = {}
    ok["7_compensado_nao_seleciona_helicidade"] = all(x["Δ_hel compensado"] < 0.15 * x["Δ_hel só χ = +1 (N4)"] for x in dh)
    c3 = cu["C3 girante"]
    ok["8_gauge_sobrevive_a_geometria_curva"] = (all(cu[g]["convergência"][-1]["eps contra ∇×(1/n)∇×"] < 0.03 and
                                                     all(eh_zero(x["|K∇φ|/|Kq| (gauge)"]) for x in cu[g]["convergência"])
                                                     for g in ("C1 poço fundo", "C2 vale")) and
                                                 all(abs(m - p) < 0.1 * abs(p) for m, p in
                                                     zip(c3["Δω(+J, +1), Δω(−J, +1), Δω(+J, −1), Δω(−J, −1)"],
                                                         c3["previsto (rotação rígida, m = −h): Δω(J, h) = −h·J"])) and
                                                 all(eh_zero(x["gauss"]) for x in dh))
    bf, bF = br["fraca"], br["N5 forte"]
    bf = {int(k): v for k, v in bf.items()}; bF = {int(k): v for k, v in bF.items()}
    ok["9_backreaction_fraca_nao_destroi"] = (all(bf[s]["η_g"] < 0.01 and abs(bf[s]["Δω/ω"]) < 0.01 and eh_zero(bf[s]["gauss"]) and
                                                  abs(bf[s]["mistura"] - m0) < 0.01 for s, m0 in zip((1, -1), gl["mistura sem backreaction (h = +1, −1)"]))
                                              and min(bF[s]["η_g"] for s in (1, -1)) > 1 and max(abs(bF[s]["Δω/ω"]) for s in (1, -1)) > 0.3)
    return ok, [{"h": x["h"], "GMFs": x["GMFs"], "comp": x["Δ_hel compensado"], "N4": x["Δ_hel só χ = +1 (N4)"]} for x in dh]


def main():
    pasta, saida = sys.argv[1], Path(sys.argv[2])
    rng = np.random.default_rng(SEMBOOT)
    por_semente, faltando = {}, []
    for s in SEMENTES_A:
        a, b, c = carregar(pasta, "B1a", s), carregar(pasta, "B1b", s), carregar(pasta, "B1c", s)
        d = {"itens": {}}
        if a: ok, d["serie"] = itens_B1a(a["R"], a["tabelas"]); d["itens"].update(ok)
        else: faltando.append(f"B1a {s}")
        if b: ok, d["eps"] = itens_B1b(b["R"], b["tabelas"]); d["itens"].update(ok)
        else: faltando.append(f"B1b {s}")
        if s in SEMENTES_C:
            if c: ok, d["guia"] = itens_B1c(c["R"]); d["itens"].update(ok)
            else: faltando.append(f"B1c {s}")
        d["itens"] = {k: bool(v) for k, v in d["itens"].items()}
        d["todos"] = all(d["itens"].values()) and bool(d["itens"])
        por_semente[str(s)] = d
    if faltando:
        print("AVISO: saídas faltando:", faltando)
    S = [por_semente[str(s)] for s in SEMENTES_A]
    P = {}
    # P1
    n_ok = sum(d["todos"] for d in S)
    falhas = {str(s): [k for k, v in por_semente[str(s)]["itens"].items() if not v] for s in SEMENTES_A}
    P["P1"] = {"sementes que passam em todos os itens disponíveis": n_ok, "de": len(S), "passa": n_ok >= 9,
               "itens que falharam por semente": {k: v for k, v in falhas.items() if v}}
    # P2
    ph = [d["serie"]["p_hel"] for d in S]
    med, ic = boot_mediana(ph, rng)
    p2a = med > 0.8 and ic[0] > 0
    Ns = sorted(int(k) for k in S[0]["eps"])
    lado = {N: round(N ** (1 / 3)) for N in Ns}
    grupos = [[(math.log(lado[int(N)]), math.log(v["eps"])) for N, v in d["eps"].items()] for d in S]
    sl, icsl = boot_inclinacao(grupos, rng)
    med_eps = {lado[N]: float(np.median([d["eps"][str(N)]["eps"] if str(N) in d["eps"] else d["eps"][N]["eps"] for d in S])) for N in Ns}
    Nfino = Ns[-1]
    def _e(d, N, campo):
        return (d["eps"][str(N)] if str(N) in d["eps"] else d["eps"][N])[campo]
    eps_f = [_e(d, Nfino, "eps") for d in S]
    p90 = float(np.percentile(eps_f, 90))
    lados = sorted(med_eps)
    p2b = med_eps[lados[-1]] < med_eps[lados[0]] and sl < 0 and icsl[1] < 0 and p90 < 0.01
    der = [_e(d, Nfino, "deriva") for d in S]
    n_der = sum(x < 0.005 for x in der)
    p2c = n_der >= 9
    P["P2"] = {"(a) ordem do resíduo de helicidade": {"por semente": ph, "mediana": med, "IC95": ic, "passa": p2a},
               "(b) impureza ε = 1 − f_min": {"mediana por lado": med_eps, "inclinação log ε × log N (conjunta)": sl,
                                             "IC95": icsl, "P90 de ε na malha mais fina": p90, "passa": p2b},
               "(c) deriva f_início − f_min na malha mais fina": {"por semente": der, "sementes < 0,005": n_der, "passa": p2c},
               "passa": p2a and p2b and p2c}
    # P3
    p3 = {}
    for nome, ch in (("h = +1", "p_e2"), ("linear (1,1,1)", "p_e2l")):
        x = [d["serie"][ch] for d in S]
        m, i = boot_mediana(x, rng)
        p3[nome] = {"por semente": x, "mediana": m, "IC95": i, "passa": m > 1.5 and i[0] > 0}
    P["P3"] = {**p3, "passa": all(v["passa"] for v in p3.values())}
    # P4
    G = [por_semente[str(s)].get("guia") for s in SEMENTES_C]
    if all(G):
        grupos = [[(math.log(x["h"]), math.log(max(x["comp"], 1e-12))) for x in g] for g in G]
        sl4, ic4 = boot_inclinacao(grupos, rng)
        razao = all(x["comp"] < 0.15 * x["N4"] for g in G for x in g)
        P["P4"] = {"inclinação log Δ_hel × log h (conjunta)": sl4, "IC95": ic4, "compensado < 0,15·N4 em tudo": razao,
                   "tabela": {str(s): g for s, g in zip(SEMENTES_C, G)}, "passa": sl4 > 0 and ic4[0] > 0 and razao}
    else:
        P["P4"] = {"passa": False, "nota": "saídas B1c incompletas"}
    # P5
    q = [all(x < 0.1 * y for x, y in zip(d["serie"]["a1"][-2:], d["serie"]["a2"][-2:])) for d in S]
    P["P5"] = {"por semente": q, "sementes que passam": sum(q), "passa": sum(q) >= 9,
               "a1, a2 (2 malhas finas)": {str(s): [d["serie"]["a1"][-2:], d["serie"]["a2"][-2:]] for s, d in zip(SEMENTES_A, S)}}
    p = {k: P[k]["passa"] for k in ("P1", "P2", "P3", "P4", "P5")}
    if p["P1"] and p["P2"] and p["P3"] and p["P4"] and p["P5"]:
        dec = "PHOTON-CLOSURE-E FECHADO (toy model)"
    elif p["P1"] and p["P2"] and p["P3"] and p["P5"]:
        dec = "FECHADO COM RESSALVA (P4 falhou)"
    elif not (p["P1"] and p["P2"] and p["P3"]):
        dec = "NÃO FECHADO — falhou: " + ", ".join(k for k in ("P1", "P2", "P3") if not p[k])
    else:
        dec = "NÃO FECHADO — P5 falhou (caso não previsto na tabela de decisão; registrado como não fechado)"
    out = {"decisao": dec, "passa": p, "criterios": P, "por_semente": por_semente, "saidas_faltando": faltando,
           "bootstrap": {"reamostragens": NBOOT, "semente": SEMBOOT}}
    saida.write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding="utf-8")
    print(dec); print(p)


if __name__ == "__main__":
    main()
