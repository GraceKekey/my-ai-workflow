#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C5A B8 — avaliador pré-registrado (escrito antes das saídas novas).
Uso: python avaliar_B8.py <pasta_B1_saidas> <avaliacao_B1.json> <B8_isotropia.json> <saida.json>"""
import csv
import json
import math
import sys
from pathlib import Path

import numpy as np

NBOOT, SEMBOOT = 2000, 12345
SEMENTES_B1 = list(range(20261201, 20261211))
# Limite observacional congelado no pré-registro [F]
E_QG2_GEV = 6.9e11          # LHAASO (Cao et al. 2024, PRL 133, 071501; arXiv:2402.06009): n = 2, subluminal, 95% CL
HBARC_GEV_M = 1.973269804e-16
L_PLANCK_M = 1.616255e-35


def ajuste_xi(x, y):
    """ω/ck − 1 = −ξ x − ζ x², x = (ka)², sem termo constante (forma do prompt)."""
    A = np.stack([-x, -x * x], 1)
    xi, ze = np.linalg.lstsq(A, y - 1, rcond=None)[0]
    return float(xi), float(ze)


def ajuste_livre(x, y):
    A = np.stack([np.ones_like(x), -x, -x * x], 1)
    c0, b1, b2 = np.linalg.lstsq(A, y, rcond=None)[0]
    return float(c0), float(b1 / c0), float(b2 / c0)


def boot_media(v, rng):
    v = np.asarray(v, float)
    bs = [np.mean(rng.choice(v, len(v))) for _ in range(NBOOT)]
    return float(np.mean(v)), [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


def a_max(xi):
    return HBARC_GEV_M / (E_QG2_GEV * math.sqrt(2 * xi)) if xi > 0 else float("inf")


def main():
    pB1, avB1, pB8, saida = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3]), Path(sys.argv[4])
    rng = np.random.default_rng(SEMBOOT)
    out = {}
    # ---------------- B8-1 (dados de dispersão da B1: eixo x, m = 1..6, malhas 10³, 14³, 20³)
    por_malha = {}
    for s in SEMENTES_B1:
        with (pB1 / str(s) / "c5a_photon_closure_dispersao.csv").open(encoding="utf-8") as fh:
            linhas = list(csv.DictReader(fh))
        for N in sorted({int(l["GMFs"]) for l in linhas}):
            ll = [l for l in linhas if int(l["GMFs"]) == N]
            x = np.array([float(l["ka"])**2 for l in ll]); y = np.array([float(l["omega/ck"]) for l in ll])
            xi, ze = ajuste_xi(x, y); c0, xl, zl = ajuste_livre(x, y)
            por_malha.setdefault(N, []).append({"semente": s, "xi": xi, "zeta": ze, "exploratório: c0, xi, zeta com constante livre": [c0, xl, zl]})
    b81 = {}
    for N, v in por_malha.items():
        m, ic = boot_media([d["xi"] for d in v], rng)
        mz, icz = boot_media([d["zeta"] for d in v], rng)
        b81[str(N)] = {"lado": round(N ** (1 / 3)), "xi médio": m, "IC95": ic, "zeta médio": mz, "IC95 zeta": icz, "por semente": v}
    Nf = max(por_malha)
    xi, icxi = b81[str(Nf)]["xi médio"], b81[str(Nf)]["IC95"]
    B1 = json.loads(avB1.read_text(encoding="utf-8"))
    p5 = B1["criterios"]["P5"]
    lin_ok = p5["sementes que passam"] >= 9
    c1 = icxi[0] > 0 or icxi[1] < 0
    out["B8_1"] = {"malha primária": f"{round(Nf ** (1 / 3))}³", "xi": xi, "IC95": icxi, "IC exclui 0": c1,
                   "termo linear desprezível (P5 da B1: |a1| < 0,1|a2| nas 2 malhas finas)": f"{p5['sementes que passam']}/10",
                   "linear ok": lin_ok, "por malha": b81}
    # ---------------- B8-2
    R = json.loads(pB8.read_text(encoding="utf-8"))
    dl = R["delaunay"]
    lados = sorted({v["lado"] for v in dl.values()})
    sem = sorted({v["semente"] for v in dl.values()})
    A = {l: {} for l in lados}; padrao = {l: [] for l in lados}; xis = {l: [] for l in lados}
    for v in dl.values():
        c0 = np.array([d["c0"] for d in v["direcoes"].values()])
        A[v["lado"]][v["semente"]] = float(np.std(c0) / np.mean(c0))
        padrao[v["lado"]].append(c0 / np.mean(c0))
        xis[v["lado"]].append([d["xi"] for d in v["direcoes"].values()])
    medA = {str(l): float(np.median(list(A[l].values()))) for l in lados}
    Aavg = {}
    for l in lados:
        p = np.mean(padrao[l], 0)
        Aavg[str(l)] = float(np.std(p) / np.mean(p))
    grupos = [[(math.log(l), math.log(A[l][s])) for l in lados] for s in sem]
    def incl(gs):
        xs = np.concatenate([[g[0] for g in G] for G in gs]); ys = np.concatenate([[g[1] for g in G] for G in gs])
        return float(np.polyfit(xs, ys, 1)[0])
    sl = incl(grupos)
    bs = [incl([grupos[i] for i in rng.integers(0, len(grupos), len(grupos))]) for _ in range(NBOOT)]
    icsl = [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]
    lf = lados[-1]
    cai = sl < 0 and icsl[1] < 0
    abaixo = medA[str(lf)] < 1e-3 and Aavg[str(lf)] < 1e-4
    xi_dir = np.mean(xis[lf], 0)
    out["B8_2"] = {"anisotropia por malha (mediana sobre realizações)": medA, "anisotropia do padrão médio": Aavg,
                   "inclinação log A × log lado (conjunta)": sl, "IC95": icsl, "cai com o refinamento": cai,
                   f"mediana A na malha {lf}³ < 1e-3 e padrão médio < 1e-4": abaixo,
                   "por realização": {str(l): A[l] for l in lados},
                   "xi por direção (média das realizações, malha mais fina)": dict(zip(list(dl.values())[0]["direcoes"].keys(), map(float, xi_dir))),
                   "exploratório: dispersão de xi entre direções (desvio/média)": float(np.std(xi_dir) / np.mean(xi_dir))}
    # controles
    cu = R["cubica_controle"][str(lf)]
    erro_xi = max(abs(v["xi"] - v["xi_analitico (Σk̂⁴/24)"]) / v["xi_analitico (Σk̂⁴/24)"] for v in cu.values())
    c0c = np.array([v["c0"] for v in cu.values()])
    cub_ok = erro_xi < 0.01 and float(np.std(c0c) / np.mean(c0c)) < 1e-6
    n6 = R["N6_controle"]
    An6 = {p: float(np.median([np.std([d["c0"] for d in v["direcoes"].values()]) / np.mean([d["c0"] for d in v["direcoes"].values()])
                                for v in n6.values() if v["pesos"] == p])) for p in ("W", "U")}
    n6_ok = An6["U"] > 1e-2
    out["controles"] = {"cúbica: erro relativo máximo de xi(k̂) contra Σk̂⁴/24": erro_xi,
                        "cúbica: anisotropia de c0": float(np.std(c0c) / np.mean(c0c)), "cúbica ok": cub_ok,
                        "N6: anisotropia mediana (W, U)": An6, "N6 U acusa anisotropia (> 1e-2)": n6_ok}
    # decisão
    if not (cub_ok and n6_ok):
        dec = "INCONCLUSIVO (controle do método falhou)"
    elif not c1:
        dec = "INCONCLUSIVO (IC de ξ inclui zero)"
    elif cai and abaixo:
        dec = "COMPATÍVEL"
    elif abaixo:
        dec = "COMPATÍVEL COM ANISOTROPIA RESIDUAL"
    else:
        dec = "NÃO COMPATÍVEL (anisotropia acima dos limites; caso não previsto na tabela)"
    out["decisao"] = dec
    # ---------------- B8-3
    am = a_max(xi)
    am_ic = [a_max(icxi[1]), a_max(icxi[0])]
    xi_cons = float(np.max(xi_dir))
    out["B8_3"] = {"E_QG,2 (GeV), LHAASO 2024, subluminal, 95% CL": E_QG2_GEV, "ħc (GeV·m)": HBARC_GEV_M, "ℓ_P (m)": L_PLANCK_M,
                   "fórmula": "a_max = ħc / (E_QG,2 · √(2ξ))",
                   "a_max (m)": am, "a_max (m), faixa pelo IC de ξ": am_ic, "a_max/ℓ_P": am / L_PLANCK_M,
                   "a_max/ℓ_P, faixa": [x / L_PLANCK_M for x in am_ic],
                   "exploratório: a_max com o maior ξ entre direções": a_max(xi_cons), "a_max/ℓ_P (idem)": a_max(xi_cons) / L_PLANCK_M,
                   "a_max < ℓ_P (tensão forte)": am < L_PLANCK_M}
    out["frase"] = (f"Com ξ = {xi:.4f} [{icxi[0]:.4f}; {icxi[1]:.4f}] e o limite E_QG,2 > 6,9×10¹¹ GeV (LHAASO, Cao et al. 2024, "
                    f"PRL 133, 071501), o espaçamento dos GMFs deve ser menor que {am:.2e} m ({am / L_PLANCK_M:.2e} ℓ_P).")
    saida.write_text(json.dumps(out, ensure_ascii=False, indent=1, default=float), encoding="utf-8")
    print(dec); print(out["frase"])


if __name__ == "__main__":
    main()
