#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C5A — PHOTON-CLOSURE: teste integrado de fechamento do setor fotônico
=====================================================================

Prompt do usuário: docs/C5A_prompt_photon_closure.md. Arquitetura (das bancadas c5a_curl_curl_emergente,
c5a_holonomia_loops e c5a_g0g_backreaction): microgeometria g⁽⁰⁾ → tapete de GMFs sem grade (estado local q_n) →
conexão relacional U_nm = e^{i a_nm} entre GMFs vizinhos → loops de Delaunay e holonomia → energia de falha de
fechamento ||H_f − 1||² (≈ ½ Cᵀ M2 C) → excitação coletiva. Nada de ∇×∇×, ∂_μF^{μν} = 0, k_μk^μ = 0 ou projeção
transversal nas equações: tudo isso é medido depois.

Seções (S#) seguem o prompt. Controles N0–N6. Saídas: JSON, CSVs, figuras e log na pasta do JSON.

Uso: python c5a_photon_closure.py [saida.json]
"""
from __future__ import annotations

import csv
import io
import json
import math
import sys
import time
from contextlib import redirect_stdout
from pathlib import Path

import numpy as np
import scipy.linalg as sl
import scipy.sparse as sp
import scipy.sparse.linalg as spl

AQUI = Path(__file__).resolve().parent
for nome in ("c5a_curl_curl_emergente", "c5a_holonomia_loops", "c5a_g0g_backreaction"):
    sys.path.insert(0, str(AQUI.parent / nome))
from malha import ARESTAS_LOC, Complexo, pontos_tapete   # noqa: E402
import c5a_curl_curl_emergente as CC                       # noqa: E402
import c5a_holonomia_loops as HOL                          # noqa: E402
import c5a_g0g_backreaction as G0G                         # noqa: E402

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402
import matplotlib.ticker          # noqa: E402

import os as _os
SEMENTE = int(_os.environ.get('PC_SEMENTE', '20261004'))
_RES = lambda nome, pad: tuple(float(x) if '.' in x else int(x) for x in _os.environ.get(nome, pad).split(','))
RES_DISP = _RES('PC_RES_DISP', '9,13,18')
RES_EM = _RES('PC_RES_EM', '6,9,13,18')
RES_CONS = _RES('PC_RES_CONS', '9,13')
RES_POL = int(_os.environ.get('PC_RES_POL', '9'))
RES_GUIA = _RES('PC_RES_GUIA', '0.6,0.5,0.42')
L = CC.L
sig, zero_ou, eh_zero, ZERO = CC.sig, CC.zero_ou, CC.eh_zero, CC.ZERO
TABELAS = {}


def log(*a):
    print(*a, flush=True)


def kvec(n):
    return 2 * math.pi / L * np.asarray(n, float)


def projetado(C, K, M, n):
    """Problema projetado nas três ondas planas de vetor k (Galerkin): ω², autovetores, conteúdo longitudinal."""
    k = kvec(n)
    Q = np.stack([C.onda_aresta(k, e) for e in np.eye(3)], 1)
    Kk = Q.conj().T @ (K @ Q); Mk = Q.conj().T @ (M @ Q)
    w2, v = sl.eigh((Kk + Kk.conj().T) / 2, (Mk + Mk.conj().T) / 2)
    kh = k / np.linalg.norm(k)
    lon = np.array([abs(kh @ v[:, i]) / np.linalg.norm(v[:, i]) for i in range(3)])
    return w2, lon


def montar_W(nl, rng, n_fun=None, tremor=0.35, nvec=None):
    if nvec is None:
        C, M1, M2 = CC.montar(nl, rng, tremor=tremor, n_fun=n_fun)
    else:
        P = pontos_tapete(np.asarray(nvec), L, rng, tremor)
        C = Complexo(P, L)
        M1, M2 = C.matrizes()
    K = (C.d1.T @ M2 @ C.d1).tocsr()
    return C, M1, M2, K


# ---------------------------------------------------------------------- S3/S4: holonomia, operador (reaproveita HOL1)
def s_holonomia_operador(rng):
    log("S3/S4: holonomia e operador")
    r1 = HOL.p1_holonomia(rng)
    r3 = HOL.p3_conexao(rng)
    return {"holonomia (P1 de c5a_holonomia_loops)": r1, "operador e gauge (P3 de c5a_holonomia_loops)": r3}


# ---------------------------------------------------------------------- S5/S6: polarizações, gauge, controles N0–N3
def s_polarizacoes(rng):
    log("S5/S6: polarizações, gauge, controles")
    C, M1, M2, K = montar_W(RES_POL, rng)
    res = {"GMFs": C.N}
    k1 = (2 * math.pi / L)**2
    conchas = {}
    for s2, mult in ((1, 6), (2, 12), (3, 8)):
        w = CC.autovalores_discretos(K, M1, s2 * k1, 2 * mult + 10) / k1
        conchas[f"|n|² = {s2}"] = {"contagem ±15%": int(np.sum(np.abs(w - s2) < 0.15 * s2)), "esperado (2 polarizações)": 2 * mult}
    res["espectro verdadeiro: conchas"] = conchas
    phi = rng.normal(size=C.N)
    qg = C.d0 @ phi
    qr = rng.normal(size=C.E)
    lu = spl.splu(M1.tocsc())
    qdd = -lu.solve(K @ qr)
    res["|d1 d0|_max"] = zero_ou(float(abs(C.d1 @ C.d0).max()))
    res["|O[dφ]| / |O[q]|"] = zero_ou(float(np.linalg.norm(K @ qg) / np.linalg.norm(qg) / (np.linalg.norm(K @ qr) / np.linalg.norm(qr))))
    res["|div q̈| / |q̈| (div = d0ᵀ M1)"] = zero_ou(float(np.linalg.norm(C.d0.T @ (M1 @ qdd)) / np.linalg.norm(M1 @ qdd)))
    # controles
    ns = [(1, 0, 0), (1, 1, 0), (2, 1, 0), (1, 1, 1)]
    h = L / RES_POL
    for tipo, nome in (("isotropico", "N0 pares isotrópicos"), ("perpendicular", "N0b pares perpendiculares")):
        lista = CC.espectro_pares(C, tipo, (0.6 * h)**2, ns)
        rT, rL = [], []
        for _, w2, lon in lista:
            o = np.argsort(lon); rT += list(w2[o[:2]]); rL.append(w2[o[2]])
        res[nome] = {"omega_L²/omega_T²": sig(float(np.mean(rL) / np.mean(rT)), 3), "modos propagantes por k": 3}
    res["N1 conexão = gradiente puro (a = d0 φ)"] = {
        "circulação em todo loop": zero_ou(float(np.abs(C.d1 @ qg).max())),
        "leitura": "C_f = 0 sempre: a energia de holonomia é identicamente zero, nenhuma onda (FAIL do setor fotônico)"}
    d1r = CC.d1_aleatorio(C, rng)
    Kr = (d1r.T @ M2 @ d1r).tocsr()
    wr = [projetado(C, Kr, M1, n)[0] for n in ns]
    res["N2 orientação embaralhada"] = {"omega² mínimo / (ck)² (gauge exigiria 0)": sig(float(min(w[0] / (kvec(n) @ kvec(n)) for w, n in zip(wr, ns))), 3),
                                       "|O[dφ]|/|O[q]|": sig(float(np.linalg.norm(Kr @ qg) / np.linalg.norm(qg) / (np.linalg.norm(Kr @ qr) / np.linalg.norm(qr))), 3)}
    res["N3 loops desligados (sem energia de holonomia)"] = {"omega² de todos os modos": 0.0,
                                                            "leitura": "sem a energia dos loops, K = 0: nada se propaga"}
    return res


# ---------------------------------------------------------------------- S7/S10: dispersão, Lorentz IR, N6
DIRS = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1), (1, -1, 0), (2, 1, 0), (1, 2, 2), (2, -1, 1)]


def s_dispersao(rng):
    log("S7/S10: dispersão e Lorentz IR")
    res, linhas = {}, []
    for nl in RES_DISP:
        C, M1, M2, K = montar_W(nl, rng)
        a = L / nl
        tab = []
        for m in range(1, 7):
            n = (m, 0, 0)
            w2, lon = projetado(C, K, M1, n)
            k = np.linalg.norm(kvec(n))
            wT = np.sqrt(w2[1:])
            tab.append((k, float(wT.mean() / k), float(abs(wT[1] - wT[0]) / wT.mean())))
            linhas.append({"GMFs": C.N, "a": a, "n": str(n), "k": k, "ka": k * a, "omega/ck": wT.mean() / k,
                           "birrefringencia": abs(wT[1] - wT[0]) / wT.mean(), "lon_T": float(lon[np.argsort(w2)][1:].max()),
                           "omega2_L/(ck)2": float(w2[0] / k**2)})
        ka = np.array([t[0] * a for t in tab]); d = np.array([t[1] - 1 for t in tab])
        A = np.stack([ka, ka**2, ka**3], 1)
        coef = np.linalg.lstsq(A, d, rcond=None)[0]
        vph = np.array([t[1] for t in tab])
        ks = np.array([t[0] for t in tab])
        w = vph * ks
        vg = np.gradient(w, ks)
        # anisotropia em |n| pequeno: direções diferentes
        dirs = []
        for n in DIRS:
            w2, _ = projetado(C, K, M1, n)
            dirs.append(float(np.sqrt(w2[1:]).mean() / np.linalg.norm(kvec(n))))
        bir = []
        for n in DIRS:
            w2, _ = projetado(C, K, M1, n)
            bir.append(float(abs(math.sqrt(w2[2]) - math.sqrt(w2[1])) / math.sqrt(w2[1:].mean())))
        res[f"GMFs = {C.N}"] = {
            "espacamento a": sig(a, 4),
            "omega/ck ao longo de x, m = 1..6": [sig(t[1], 5) for t in tab],
            "ka": [sig(x, 3) for x in ka],
            "ajuste ω/ck − 1 = a1·ka + a2·(ka)² + a3·(ka)³": [sig(float(c), 3) for c in coef],
            "v_fase (m = 1..6)": [sig(x, 4) for x in vph], "v_grupo (m = 1..6)": [sig(float(x), 4) for x in vg],
            "anisotropia: desvio de ω/ck entre 11 direções (|n| ≤ 3)": sig(float(np.std(dirs)), 3),
            "ω/ck médio nas 11 direções": sig(float(np.mean(dirs)), 4),
            "birrefringência média entre os 2 transversais (11 direções)": sig(float(np.mean(bir)), 3)}
    TABELAS["dispersao.csv"] = linhas
    # N6: malha anisotrópica proposital (espaçamento 2× maior em z)
    n6 = {}
    for nome, pesos in (("W (pesos geométricos)", "W"), ("U (peso uniforme)", "U")):
        C, M1, M2, K = montar_W(None, rng, nvec=(14, 14, 7))
        if pesos == "U":
            K = (C.d1.T @ C.d1).tocsr(); M1 = sp.identity(C.E, format="csr")
        vx = math.sqrt(projetado(C, K, M1, (1, 0, 0))[0][1:].mean()) / np.linalg.norm(kvec((1, 0, 0)))
        vz = math.sqrt(projetado(C, K, M1, (0, 0, 1))[0][1:].mean()) / np.linalg.norm(kvec((0, 0, 1)))
        w2, _ = projetado(C, K, M1, (1, 0, 0))
        n6[nome] = {"v_z / v_x": sig(vz / vx, 4), "birrefringência ao longo de x": sig(float(abs(math.sqrt(w2[2]) - math.sqrt(w2[1])) / math.sqrt(w2[1:].mean())), 3)}
    res["N6 malha anisotrópica (espaçamento 2× em z)"] = n6
    return res


# ---------------------------------------------------------------------- S8: energia–momento
def campos_tet(C, Q, w):
    g = C.grad
    wc = np.stack([0.25 * (g[:, j] - g[:, i]) for (i, j) in ARESTAS_LOC], 1)
    qa = Q[C.aresta_t]
    B = np.einsum("tei,te->ti", C.curl_local(), qa)
    E = 1j * w * np.einsum("tei,te->ti", wc, qa)
    return E, B


def s_energia_momento(rng):
    log("S8: energia–momento")
    res = {}
    for nl in RES_EM:
        C, M1, M2, K = montar_W(nl, rng)
        lin = {}
        for rot, n, A in (("h = +1, z", (0, 0, 1), np.array([1, -1j, 0])), ("h = −1, z", (0, 0, 1), np.array([1, 1j, 0])),
                          ("linear, (1,1,1)", (1, 1, 1), np.array([1.0, -1.0, 0]) / math.sqrt(2))):
            k = kvec(n)
            Q = C.onda_aresta(k, A)
            w = math.sqrt((np.vdot(Q, K @ Q) / np.vdot(Q, M1 @ Q)).real)
            E, B = campos_tet(C, Q, w)
            V = C.vol
            P = (0.5 * np.real(np.cross(E, B.conj())) * V[:, None]).sum(0)
            U = float((0.25 * (np.sum(np.abs(E)**2, 1) + np.sum(np.abs(B)**2, 1)) * V).sum())
            pc = float(np.linalg.norm(P) / U)
            lin[rot] = {"Pc/E": sig(pc, 5), "(E² − P²c²)/E²": sig(1 - pc * pc, 3),
                        "ângulo entre P e k (rad)": sig(float(math.acos(min(1, abs(P @ k) / (np.linalg.norm(P) * np.linalg.norm(k))))), 3)}
            if rot.startswith("h"):
                # S9: ∇×q_h = −h k q_h (q interpolado no centro de cada tetraedro)
                h = 1 if "+" in rot else -1
                qc = np.einsum("tei,te->ti", np.stack([0.25 * (C.grad[:, j] - C.grad[:, i]) for (i, j) in ARESTAS_LOC], 1),
                               Q[C.aresta_t])
                r = B + h * np.linalg.norm(k) * qc                  # B = ∇×q (campos_tet)
                lin[rot]["|∇×q + h k q| / |∇×q|"] = sig(float(math.sqrt((np.sum(np.abs(r)**2, 1) * V).sum() /
                                                                          (np.sum(np.abs(B)**2, 1) * V).sum())), 3)
        res[f"GMFs = {C.N}"] = lin
    return res


# ---------------------------------------------------------------------- S9/S15: conservação no tempo, helicidade
def s_conservacao(rng):
    log("S9/S15: conservação no tempo")
    res, linhas = {}, []
    for nl in RES_CONS:
        C, M1, M2, K = montar_W(nl, rng)
        lu = spl.splu(M1.tocsc())
        wmax = math.sqrt(CC.limite_wmax(C))
        dt = 1.0 / wmax
        k = kvec((0, 0, 1))
        Qp, Qm = C.onda_aresta(k, np.array([1, -1j, 0])), C.onda_aresta(k, np.array([1, 1j, 0]))
        q, v = Qp.real.copy(), (np.linalg.norm(k) * Qp.imag).copy()
        g = C.grad
        wc = np.stack([0.25 * (g[:, j] - g[:, i]) for (i, j) in ARESTAS_LOC], 1)
        clc = C.curl_local()

        def medidas(q, v):
            qa, va = q[C.aresta_t], v[C.aresta_t]
            B = np.einsum("tei,te->ti", clc, qa); E = -np.einsum("tei,te->ti", wc, va)
            P = (np.cross(E, B) * C.vol[:, None]).sum(0)
            H = 0.5 * v @ (M1 @ v) + 0.5 * q @ (K @ q)
            pi = M1 @ v
            cp, cm = np.vdot(M1 @ Qp, pi), np.vdot(M1 @ Qm, pi)
            return H, P, abs(cp)**2 / (abs(cp)**2 + abs(cm)**2), C.d0.T @ pi
        H0, P0, h0, g0 = medidas(q, v)
        T = 20.0
        ns = int(round(T / dt))
        a = -lu.solve(K @ q)
        serie = []
        for it in range(ns + 1):
            if it % max(1, ns // 40) == 0:
                H, P, hf, gs = medidas(q, v)
                serie.append((it * dt, H / H0 - 1, P[2] / P0[2] - 1, hf, float(np.linalg.norm(gs - g0) / (np.linalg.norm(M1 @ v) + 1e-300))))
                linhas.append({"GMFs": C.N, "t": it * dt, "dE/E": H / H0 - 1, "dPz/Pz": P[2] / P0[2] - 1,
                               "fracao_h+": hf, "gauss": serie[-1][4]})
            v += 0.5 * dt * a; q += dt * v; a = -lu.solve(K @ q); v += 0.5 * dt * a
        s = np.array(serie)
        res[f"GMFs = {C.N}"] = {"dt": sig(dt, 3), "T": T,
                                "máx |ΔE/E|": sig(float(np.abs(s[:, 1]).max()), 3),
                                "máx |ΔP_z/P_z|": sig(float(np.abs(s[:, 2]).max()), 3),
                                "fração na helicidade h = +1 (início, mínimo)": [sig(float(s[0, 3]), 5), sig(float(s[:, 3].min()), 5)],
                                "lei de Gauss |Δ(d0ᵀπ)|/|π| (máx)": zero_ou(float(s[:, 4].max()))}
    TABELAS["conservacao.csv"] = linhas
    res["momento angular J"] = ("a malha aleatória não tem simetria de rotação exata: J_z não é conservado exatamente; "
                                "a fração de helicidade (projeção nas ondas h = ±1) é o que se mede")
    return res


# ---------------------------------------------------------------------- S2/S11/S12: guia (Δ_hel, girante, backreaction)
def s_guia(rng):
    log("S2/S11/S12: guia, fundo compensado, backreaction")
    res = {}
    ref = []
    for hh in RES_GUIA:
        g = G0G.Guia(rng, h=hh)
        uc = G0G.u_vortices(g.cen, (1, -1))
        col = hh == RES_GUIA[1]
        r = {s: g.rodar(uc, s, coletar=col) for s in (1, -1)}
        wp, wm = r[1]["omega"][1], r[-1]["omega"][-1]
        dh = abs(wp - wm) / (0.5 * (wp + wm))
        u4 = G0G.u_vortices(g.cen, (1, 1))
        r4 = {s: g.rodar(u4, s)["omega"][s] for s in (1, -1)}
        d4 = abs(r4[1] - r4[-1]) / (0.5 * (r4[1] + r4[-1]))
        ref.append({"h": hh, "GMFs": g.C.N, "Δ_hel compensado": sig(dh, 3), "Δ_hel só χ = +1 (N4)": sig(d4, 3),
                    "gauss": zero_ou(max(r[1]["gauss"], r[-1]["gauss"]))})
        log("  h =", hh, ref[-1])
        if col:
            gb, rb, ucb = g, r, uc
    res["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"] = ref
    # backreaction fraca e forte (N5) na malha h = 0.5
    br = {}
    for Gx, rot in ((1e-5, "fraca"), (3e-2, "N5 forte")):
        out = {}
        for s in (1, -1):
            Phi, ud = G0G.backreaction(gb, rb[s]["rho"], rb[s]["S"], Gx)
            eta = float(G0G.norma_dg(Phi, ud).max() / 2)
            om = G0G.giro_eixo(gb, ud)
            gb.matrizes(np.exp(-2 * Phi))
            rr = gb.rodar(ucb + ud, s)
            gb.matrizes(np.ones(gb.C.T))
            w0 = rb[s]["omega"][s]
            out[s] = {"η_g": sig(eta, 3), "Ω_δ": sig(om, 3), "Δω/ω": sig((rr["omega"][s] - w0) / w0, 3),
                      "mistura": sig(rr["amp"][-s] / rr["amp"][s], 3), "gauss": zero_ou(rr["gauss"])}
        br[rot] = out
    res["S12 backreaction (h = +1, −1)"] = br
    res["mistura sem backreaction (h = +1, −1)"] = [sig(rb[s]["amp"][-s] / rb[s]["amp"][s], 3) for s in (1, -1)]
    return res


def s_curvo(rng):
    log("S11: fundos curvo, vale, girante (P4 de c5a_holonomia_loops)")
    return HOL.p4_fundos(rng)


# ---------------------------------------------------------------------- S13/S14: quantização efetiva, um quantum
def s_quanta(rng):
    log("S13/S14: quantização efetiva e um quantum")
    res = {}
    C, M1, M2, K = montar_W(RES_POL, rng)
    k1 = (2 * math.pi / L)**2
    w2 = CC.autovalores_discretos(K, M1, k1, 22) / k1
    par = np.sort(w2[np.abs(w2 - 1) < 0.15])[:12]
    split = float((par.max() - par.min()) / par.mean())
    res["Q1"] = {
        "modos normais": "a energia ½ q̇ᵀM1q̇ + ½ qᵀKq é quadrática: os modos normais são osciladores independentes",
        "E1 − E0": "ħω (para [q, p] = iħ, cada modo normal é um oscilador harmônico) [F]",
        "S_z": ("os dois transversais de mesmo k formam um oscilador 2D; o estado circular de um quantum tem S_z = ±ħ "
                "exatamente se os dois forem degenerados [F]"),
        "espalhamento relativo de ω² entre os 12 modos da primeira concha (729 GMFs)": sig(split, 3),
        "tempo para S_z deixar de ser bom número quântico ~ 1/δω (em unidades de 2π/ω)": sig(1 / max(split / 2, 1e-12), 3)}
    res["Q2"] = "ħ permanece entrada: nenhum mecanismo microscópico desta arquitetura fixa ħ [?]"
    # um quantum: oscilador forçado (Fock truncado) → estado coerente
    nmax = 40
    a = np.diag(np.sqrt(np.arange(1, nmax)), 1)
    tab = []
    for alfa in (0.3, 0.6, 1.0, 1.5):
        # pulso de força clássica: U = exp(α a† − α* a) aplicado ao vácuo
        Hd = alfa * (a.T - a)
        psi = sl.expm(Hd)[:, 0]
        p = np.abs(psi)**2
        tab.append({"|α|": alfa, "⟨n⟩": sig(float(np.arange(nmax) @ p), 4), "P(n = 1)": sig(float(p[1]), 4),
                    "P(n = 0)": sig(float(p[0]), 4)})
    res["S14 fonte clássica → estado coerente"] = tab
    res["S14 leitura"] = ("uma fonte clássica acoplada linearmente ao modo (o que a dinâmica dos GMFs dá) produz um estado "
                          "coerente: a energia transferida é contínua (ħω⟨n⟩) e a probabilidade de exatamente um quantum "
                          "é no máximo 1/e = 0,368 (|α| = 1). Selecionar um quantum exige um emissor não linear (dois níveis) "
                          "ou a regra de quantização: questão aberta [?]")
    return res


# ---------------------------------------------------------------------- S19: cargas
def s_cargas(rng):
    log("S19: acoplamento a fontes")
    C, M1, M2, K = montar_W(RES_POL, rng)
    lu = spl.splu(M1.tocsc())
    dt = 1.0 / math.sqrt(CC.limite_wmax(C))
    J_cons = C.d1.T @ rng.normal(size=C.F)                    # d0ᵀ J = 0 exatamente (corrente de laço)
    J_nao = rng.normal(size=C.E)
    res = {}
    for nome, J in (("corrente conservada (d0ᵀJ = 0)", J_cons), ("corrente não conservada", J_nao)):
        q = np.zeros(C.E); v = np.zeros(C.E)
        rho = np.zeros(C.N)
        w0 = 2.0
        f = lambda t: J * math.sin(w0 * t)
        t = 0.0
        a = lu.solve(-K @ q + f(t))
        for it in range(int(10 / dt)):
            v += 0.5 * dt * a; q += dt * v; t += dt
            a = lu.solve(-K @ q + f(t)); v += 0.5 * dt * a
            # continuidade ρ̇ = −d0ᵀ J, com a mesma regra do trapézio do passo de π
            rho -= 0.5 * dt * (C.d0.T @ (f(t - dt) + f(t)))
        pi = M1 @ v
        res[nome] = {"|d0ᵀJ|/|J|": zero_ou(float(np.linalg.norm(C.d0.T @ J) / np.linalg.norm(J))),
                     "lei de Gauss sem carga: |d0ᵀπ|/|π|": zero_ou(float(np.linalg.norm(C.d0.T @ pi) / np.linalg.norm(pi))),
                     "Gauss com a carga da continuidade: |d0ᵀπ + ρ|/|π|": zero_ou(float(np.linalg.norm(C.d0.T @ pi + rho) / np.linalg.norm(pi)))}
    res["leitura"] = ("a fonte entra como M q̈ = −Kq + J; a lei de Gauss d0ᵀπ = −ρ só se mantém se ρ̇ + d0ᵀJ = 0 "
                      "(conservação da carga, a versão discreta de ∇_μ J^μ = 0). A estrutura ∇_μF^{μν} = J^ν é compatível; "
                      "o que é a carga elétrica na C5A não é derivado aqui [?]")
    return res


# ---------------------------------------------------------------------- figura
def figura(R, pasta):
    fig, ax = plt.subplots(2, 3, figsize=(15, 8.6))
    # (a) dispersão δ(ka)
    a = ax[0, 0]
    linhas = TABELAS["dispersao.csv"]
    for N in sorted({l["GMFs"] for l in linhas}):
        x = np.array([l["ka"] for l in linhas if l["GMFs"] == N])
        y = np.array([l["omega/ck"] - 1 for l in linhas if l["GMFs"] == N])
        a.loglog(x, np.abs(y), "o-", label=f"{N} GMFs")
    xx = np.linspace(0.3, 3, 20)
    a.loglog(xx, 0.04 * xx**2, "k:", label="∝ (ka)²")
    a.set_xlabel("ka"); a.set_ylabel("|ω/ck − 1|"); a.set_title("(a) dispersão: δ_disp → 0 quando ka → 0")
    a.legend(fontsize=8)
    # (b) operador: ε_cc fraco
    a = ax[0, 1]
    cv = R["S3_S4_holonomia_e_operador"]["operador e gauge (P3 de c5a_holonomia_loops)"]["convergência do operador (forma fraca)"]
    for nome, mk in (("W (∫|F|², Whitney)", "o-"), ("D (dual baricêntrico, diagonal)", "s-"), ("U (uniforme)", "^-"),
                     ("embaralhado (orientação aleatória)", "x--")):
        a.loglog([x["GMFs"] for x in cv[nome]], [x["eps_cc_fraco"] for x in cv[nome]], mk, label=nome.split(" (")[0] if "emb" in nome else nome)
    a.set_xlabel("número de GMFs"); a.set_ylabel("ε_cc (forma fraca)"); a.set_title("(b) loops → curl-curl (N2: embaralhado)")
    a.legend(fontsize=7)
    # (c) energia–momento e helicidade
    a = ax[0, 2]
    em = R["S8_S9_energia_momento_helicidade"]
    Ns = [int(k.split("= ")[1]) for k in em]
    a.loglog(Ns, [abs(v["h = +1, z"]["(E² − P²c²)/E²"]) for v in em.values()], "o-", label="(E² − P²c²)/E², h = +1")
    a.loglog(Ns, [abs(v["linear, (1,1,1)"]["(E² − P²c²)/E²"]) for v in em.values()], "s-", label="(E² − P²c²)/E², linear (1,1,1)")
    a.loglog(Ns, [v["h = +1, z"]["|∇×q + h k q| / |∇×q|"] for v in em.values()], "^-", label="|∇×q + hkq|/|∇×q|, h = +1")
    a.loglog(Ns, [v["h = −1, z"]["|∇×q + h k q| / |∇×q|"] for v in em.values()], "v--", label="|∇×q + hkq|/|∇×q|, h = −1")
    a.set_xlabel("número de GMFs"); a.set_title("(c) P^μP_μ → 0 e helicidade h = ±1"); a.legend(fontsize=7)
    # (d) Lorentz IR: anisotropia e birrefringência
    a = ax[1, 0]
    ds = {k: v for k, v in R["S7_S10_dispersao_lorentz"].items() if k.startswith("GMFs")}
    Ns = [int(k.split("= ")[1]) for k in ds]
    a.loglog(Ns, [v["anisotropia: desvio de ω/ck entre 11 direções (|n| ≤ 3)"] for v in ds.values()], "o-", label="anisotropia (11 direções)")
    a.loglog(Ns, [v["birrefringência média entre os 2 transversais (11 direções)"] for v in ds.values()], "s-", label="birrefringência")
    a.loglog(Ns, [abs(v["ω/ck médio nas 11 direções"] - 1) for v in ds.values()], "^-", label="|⟨ω/ck⟩ − 1|")
    a.set_xlabel("número de GMFs"); a.set_title("(d) Lorentz no limite IR (fundo plano)"); a.legend(fontsize=8)
    # (e) Δ_hel: compensado e N4
    a = ax[1, 1]
    gl = R["S2_S11_S12_guia"]["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"]
    Ns = [x["GMFs"] for x in gl]
    a.loglog(Ns, [max(x["Δ_hel compensado"], 1e-7) for x in gl], "o-", label="compensado χ = ±1")
    a.loglog(Ns, [x["Δ_hel só χ = +1 (N4)"] for x in gl], "s--", label="N4: só χ = +1")
    a.set_xlabel("número de GMFs (guia)"); a.set_ylabel("Δ_hel"); a.set_title("(e) degenerescência das helicidades")
    a.legend(fontsize=8)
    # (f) conservações no tempo
    a = ax[1, 2]
    lc = TABELAS["conservacao.csv"]
    for N in sorted({l["GMFs"] for l in lc}):
        t = [l["t"] for l in lc if l["GMFs"] == N]
        a.plot(t, [l["dE/E"] for l in lc if l["GMFs"] == N], "-", label=f"ΔE/E ({N})")
        a.plot(t, [l["dPz/Pz"] for l in lc if l["GMFs"] == N], "--", label=f"ΔP_z/P_z ({N})")
        a.plot(t, [1 - l["fracao_h+"] for l in lc if l["GMFs"] == N], ":", label=f"1 − fração h = +1 ({N})")
    a.set_xlabel("t"); a.set_title("(f) conservações durante a propagação"); a.legend(fontsize=7)
    for a in ax.ravel():
        a.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    fig.suptitle("C5A PHOTON-CLOSURE: conexão relacional entre GMFs → setor de fóton livre efetivo [M]")
    fig.tight_layout()
    fig.savefig(pasta / "c5a_photon_closure.png", dpi=120)
    plt.close(fig)


# ---------------------------------------------------------------------- principal
class Tee(io.TextIOBase):
    def __init__(self, *fs):
        self.fs = fs

    def write(self, s):
        for f in self.fs:
            f.write(s); f.flush()
        return len(s)


def salvar_csv(pasta):
    for nome, linhas in TABELAS.items():
        with (pasta / f"c5a_photon_closure_{nome}").open("w", newline="", encoding="utf-8") as fh:
            w = csv.DictWriter(fh, fieldnames=list(linhas[0].keys()))
            w.writeheader()
            for l in linhas:
                w.writerow({k: (f"{v:.10g}" if isinstance(v, float) else v) for k, v in l.items()})


def main():
    saida = Path(sys.argv[1] if len(sys.argv) > 1 else "c5a_photon_closure.json")
    pasta = saida.resolve().parent
    pasta.mkdir(parents=True, exist_ok=True)
    flog = (pasta / "c5a_photon_closure_log.txt").open("w", encoding="utf-8")
    sys.stdout = Tee(sys.__stdout__, flog)
    rng = np.random.default_rng(SEMENTE)
    R = {}
    for chave, f in (("S3_S4_holonomia_e_operador", s_holonomia_operador), ("S5_S6_polarizacoes_gauge_N0_N3", s_polarizacoes),
                     ("S7_S10_dispersao_lorentz", s_dispersao), ("S8_S9_energia_momento_helicidade", s_energia_momento),
                     ("S9_S15_conservacao", s_conservacao), ("S2_S11_S12_guia", s_guia), ("S11_fundos_curvos", s_curvo),
                     ("S13_S14_quanta", s_quanta), ("S19_cargas", s_cargas)):
        t0 = time.time()
        R[chave] = f(rng)
        log(f"  [{chave}: {time.time() - t0:.0f} s]")
    salvar_csv(pasta)

    # ------------------------------------------------------------------ critérios (S17)
    op = R["S3_S4_holonomia_e_operador"]
    h1, p3 = op["holonomia (P1 de c5a_holonomia_loops)"], op["operador e gauge (P3 de c5a_holonomia_loops)"]
    cv = p3["convergência do operador (forma fraca)"]
    po = R["S5_S6_polarizacoes_gauge_N0_N3"]
    ds = R["S7_S10_dispersao_lorentz"]
    dsN = [v for k, v in ds.items() if k.startswith("GMFs")]
    em = list(R["S8_S9_energia_momento_helicidade"].values())
    co = [v for k, v in R["S9_S15_conservacao"].items() if k.startswith("GMFs")]
    gl = R["S2_S11_S12_guia"]
    dh = gl["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"]
    br = gl["S12 backreaction (h = +1, −1)"]
    cu = R["S11_fundos_curvos"]
    linhasD = TABELAS["dispersao.csv"]
    ok = {}
    ok["1_curl_curl_emerge"] = (all(eh_zero(x["max |H(invertido)·H − I|"]) for g in h1.values() for x in g) and
                                cv["W (∫|F|², Whitney)"][-1]["eps_cc_fraco"] < 0.5 * cv["W (∫|F|², Whitney)"][0]["eps_cc_fraco"] and
                                cv["W (∫|F|², Whitney)"][-1]["eps_cc_fraco"] < 0.02 and
                                cv["embaralhado (orientação aleatória)"][-1]["eps_cc_fraco"] > 0.5)
    ok["2_exatamente_2_modos_fisicos"] = (all(c["contagem ±15%"] == c["esperado (2 polarizações)"] for c in po["espectro verdadeiro: conchas"].values())
                                          and max(l["lon_T"] for l in linhasD) < 0.1
                                          and po["N0 pares isotrópicos"]["omega_L²/omega_T²"] > 0.5
                                          and po["N0b pares perpendiculares"]["omega_L²/omega_T²"] > 0.1)
    ok["3_longitudinal_e_gauge"] = (eh_zero(po["|d1 d0|_max"]) and eh_zero(po["|O[dφ]| / |O[q]|"]) and
                                    eh_zero(po["|div q̈| / |q̈| (div = d0ᵀ M1)"]) and
                                    all(abs(l["omega2_L/(ck)2"]) < 1e-10 for l in linhasD) and
                                    eh_zero(po["N1 conexão = gradiente puro (a = d0 φ)"]["circulação em todo loop"]) and
                                    po["N2 orientação embaralhada"]["|O[dφ]|/|O[q]|"] > 0.1)
    d1 = [abs(v["omega/ck ao longo de x, m = 1..6"][0] - 1) for v in dsN]
    ok["4_omega_ck"] = d1[-1] < d1[0] and d1[-1] < 0.01
    e2 = [abs(v["h = +1, z"]["(E² − P²c²)/E²"]) for v in em]
    e2l = [abs(v["linear, (1,1,1)"]["(E² − P²c²)/E²"]) for v in em]
    hr = [max(v["h = +1, z"]["|∇×q + h k q| / |∇×q|"], v["h = −1, z"]["|∇×q + h k q| / |∇×q|"]) for v in em]
    # "→ 0 com refinamento": queda monótona e ordem de convergência p em erro ∝ a^p (a ∝ N^{-1/3})
    Nem = np.array([int(k.split("= ")[1]) for k in R["S8_S9_energia_momento_helicidade"]], float)
    ordem = lambda e: float(-3 * np.polyfit(np.log(Nem), np.log(np.asarray(e, float)), 1)[0])
    mono = lambda e: all(b < a for a, b in zip(e[:-1], e[1:]))
    ordens = {"(E² − P²c²)/E², h = +1": sig(ordem(e2), 3), "(E² − P²c²)/E², linear (1,1,1)": sig(ordem(e2l), 3),
              "|∇×q + h k q| / |∇×q|": sig(ordem(hr), 3)}
    ok["5_E2_menos_P2c2"] = mono(e2) and mono(e2l) and ordem(e2) > 0.8 and ordem(e2l) > 0.8 and e2[-1] < 0.02
    ok["6_helicidades_h_pm1"] = (mono(hr) and ordem(hr) > 0.8 and
                                 all(v["fração na helicidade h = +1 (início, mínimo)"][1] > 0.99 for v in co))
    ok["7_compensado_nao_seleciona_helicidade"] = all(x["Δ_hel compensado"] < 0.15 * x["Δ_hel só χ = +1 (N4)"] for x in dh)
    c3 = cu["C3 girante"]
    ok["8_gauge_sobrevive_a_geometria_curva"] = (all(cu[g]["convergência"][-1]["eps contra ∇×(1/n)∇×"] < 0.03 and
                                                     all(eh_zero(x["|K∇φ|/|Kq| (gauge)"]) for x in cu[g]["convergência"])
                                                     for g in ("C1 poço fundo", "C2 vale")) and
                                                 all(abs(m - p) < 0.1 * abs(p) for m, p in
                                                     zip(c3["Δω(+J, +1), Δω(−J, +1), Δω(+J, −1), Δω(−J, −1)"],
                                                         c3["previsto (rotação rígida, m = −h): Δω(J, h) = −h·J"])) and
                                                 all(eh_zero(x["gauss"]) for x in dh))
    bf, bF = br["fraca"], br["N5 forte"]
    ok["9_backreaction_fraca_nao_destroi"] = (all(bf[s]["η_g"] < 0.01 and abs(bf[s]["Δω/ω"]) < 0.01 and eh_zero(bf[s]["gauss"]) and
                                                  abs(bf[s]["mistura"] - m0) < 0.01 for s, m0 in zip((1, -1), gl["mistura sem backreaction (h = +1, −1)"]))
                                              and min(bF[s]["η_g"] for s in (1, -1)) > 1 and max(abs(bF[s]["Δω/ω"]) for s in (1, -1)) > 0.3)
    an = [v["anisotropia: desvio de ω/ck entre 11 direções (|n| ≤ 3)"] for v in dsN]
    bi = [v["birrefringência média entre os 2 transversais (11 direções)"] for v in dsN]
    a1 = [abs(v["ajuste ω/ck − 1 = a1·ka + a2·(ka)² + a3·(ka)³"][0]) for v in dsN]
    a2 = [abs(v["ajuste ω/ck − 1 = a1·ka + a2·(ka)² + a3·(ka)³"][1]) for v in dsN]
    n6 = ds["N6 malha anisotrópica (espaçamento 2× em z)"]
    ok["10_lorentz_IR"] = (an[-1] < an[0] and an[-1] < 0.01 and bi[-1] < bi[0] and bi[-1] < 0.01 and
                           abs(n6["W (pesos geométricos)"]["v_z / v_x"] - 1) < 0.02 and abs(n6["U (peso uniforme)"]["v_z / v_x"] - 1) > 0.05)
    cons_ok = all(v["máx |ΔE/E|"] < 1e-2 and v["máx |ΔP_z/P_z|"] < 2e-2 and eh_zero(v["lei de Gauss |Δ(d0ᵀπ)|/|π| (máx)"]) for v in co)
    carga = R["S19_cargas"]
    carga_ok = (eh_zero(carga["corrente conservada (d0ᵀJ = 0)"]["lei de Gauss sem carga: |d0ᵀπ|/|π|"]) and
                not eh_zero(carga["corrente não conservada"]["lei de Gauss sem carga: |d0ᵀπ|/|π|"]) and
                eh_zero(carga["corrente não conservada"]["Gauss com a carga da continuidade: |d0ᵀπ + ρ|/|π|"]))
    ok["extra_conservacoes_no_tempo"] = cons_ok
    ok["extra_fonte_conservada_compativel_com_gauss"] = carga_ok
    E_pass = all(ok.values())
    PF = lambda b: "PASS" if b else "FAIL"
    lv_quadratico = all(x < 0.1 * y for x, y in zip(a1[1:], a2[1:]))      # termo linear desprezível nas 2 malhas finas
    tabela = {
        "A. Microgeometria → loops": "CONDICIONAL",
        "B. Loops → curl-curl": PF(ok["1_curl_curl_emerge"]),
        "C. Gauge": PF(ok["3_longitudinal_e_gauge"]),
        "D. 2 polarizações": PF(ok["2_exatamente_2_modos_fisicos"]),
        "E. ω = ck": PF(ok["4_omega_ck"]),
        "F. E = pc": PF(ok["5_E2_menos_P2c2"]),
        "G. P² = 0": PF(ok["5_E2_menos_P2c2"]),
        "H. h = ±1": PF(ok["6_helicidades_h_pm1"]),
        "I. degenerescência das helicidades": PF(ok["7_compensado_nao_seleciona_helicidade"]),
        "J. Lorentz IR": ("PASS (só limite IR; violação UV quadrática, referencial preferido da malha)" if ok["10_lorentz_IR"] and lv_quadratico
                          else ("PARCIAL" if ok["10_lorentz_IR"] else "FAIL")),
        "K. backreaction perturbativa": PF(ok["9_backreaction_fraca_nao_destroi"]),
        "L. ħ derivado": "NÃO",
        "M. emissão de 1 quantum derivada": "NÃO",
        "N. conexão relacional derivada": "NÃO",
        "O. acoplamento a carga elétrica": "NÃO (fonte conservada é compatível com a lei de Gauss; carga elétrica não derivada)"}
    fechamento = {
        "PHOTON-CLOSURE-E": "PASS" if E_pass else "FAIL",
        "PHOTON-CLOSURE-F": "NÃO FECHADO (FAIL)",
        "PHOTON-CLOSURE-F, itens que faltam": [
            "1 origem de ħ: entrada, não derivada",
            "2 emissão/absorção de um quantum: fonte clássica dá estado coerente; selecionar um quantum exige a regra de quantização",
            "3 estatística bosônica: segue de [q, p] = iħ nos modos normais (postulada), não derivada",
            "4 Lorentz sem ajuste fino: só no limite IR; o UV tem referencial preferido (o tapete)",
            "5 conexão relacional: postulada (U_nm = e^{i a_nm}); a geometria dá loops orientados e holonomia, não o grau U(1)",
            "6 acoplamento a fonte elétrica conservada: estrutura compatível (∇_μF^{μν} = J^ν exige ∇_μJ^μ = 0), carga não derivada"]}
    out = {"parametros": {"semente": SEMENTE, "caixa": L, "tremor dos GMFs": 0.35, "c": 1.0,
                          "resoluções (GMFs por lado)": {"dispersão": list(RES_DISP), "energia–momento": list(RES_EM),
                                                         "conservação": list(RES_CONS), "polarizações": RES_POL},
                          "guia": {"R": 3.0, "Lz": 4.0, "h": list(RES_GUIA), "Omega0_vortices": 0.05,
                                   "G_fraco": 1e-5, "G_forte (N5)": 3e-2},
                          "sementes": {"esta bancada": SEMENTE, "c5a_curl_curl_emergente": CC.SEMENTE,
                                       "c5a_holonomia_loops": HOL.SEMENTE, "c5a_g0g_backreaction": G0G.SEMENTE,
                                       "observação": "todas as seções usam o mesmo gerador, iniciado com a semente desta bancada"}},
           "estado": "RESULTADO CONCLUÍDO (o script terminou; a verificação dos arquivos fica no relatório)",
           **R,
           "S10 observador em movimento": ("a correção de dispersão é a2·(ka)²; o espaçamento a é o de um referencial (o do "
                                           "tapete): um observador em movimento vê a contraído e a correção muda; Lorentz "
                                           "exato não vale, só o limite IR [M]"),
           "ordens de convergência p (erro ∝ a^p)": ordens,
           "criterios": {k: bool(v) for k, v in ok.items()},
           "tabela_final": tabela, "fechamento": fechamento}
    for k, v in ok.items():
        print(k, "PASSOU" if v else "FALHOU")
    for k, v in tabela.items():
        print(k, ":", v)
    for k in ("PHOTON-CLOSURE-E", "PHOTON-CLOSURE-F"):
        print(k, "=", fechamento[k])
    with saida.open("w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    figura(R, pasta)
    sys.stdout = sys.__stdout__
    flog.close()
    return 0 if E_pass else 1


if __name__ == "__main__":
    sys.exit(main())
