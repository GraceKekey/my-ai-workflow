#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C5A-HOL1 — Origem geométrica dos loops orientados (transporte paralelo, holonomia, energia de circulação)
=========================================================================================================

Prompt do usuário: docs/C5A_prompt_holonomia_loops.md. Base: c5a_curl_curl_emergente (tapete 3D sem grade, loops de
Delaunay), c5a_tapete_gmf (poço fundo, poço girando), c5a_microgeometria_vales (vale = fileira de poços).

Partes:
  P1  microgeometria → transporte paralelo → holonomia. Métrica conforme e^{2σ}δ (plana, poço fundo, vale). O transporte
      de Levi-Civita de GMF em GMF é uma rotação (vetor de rotação ∇σ×Δx); a holonomia de cada loop é o produto dos
      transportes. Mede: loop invertido = holonomia inversa; holonomia ∝ curvatura integrada (Stokes do conector);
      fundo plano: holonomia = I; orientação embaralhada: deixa de ser holonomia.
  P2  grau das ligações DERIVADO do estado local q_n por transporte:
      B1  diferença covariante D_nm q = q_m − P_nm q_n; falha de fechamento num loop = (H_f − I) q_n1 (telescópica);
      B3  projeção na ligação a_e = ½(P q_n + P q_m)·Δx; energia Σ_f C_f².
  P3  grau das ligações como CONEXÃO RELACIONAL independente: transporte entre GMFs U_nm = e^{i a_nm} (além do
      geométrico), U_mn = U_nm⁻¹. Energia = falha de fechamento ||H_f − 1||² = 2(1 − cos C_f), C_f = Σ a (holonomia do
      loop). Pesos: W (∫|F|² com a interpolação de Whitney), D (dual baricêntrico, diagonal), U (uniforme).
  P4  fundos C0 plano, C1 curvo (poço fundo), C2 vale, C3 girante (±J), C4 orientação invertida; helicidade ℓ = 0,
      h = ±1: Δω(J, h) = −Δω(−J, h) = −Δω(J, −h).

Uso: python c5a_holonomia_loops.py [saida.json]
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent / "c5a_curl_curl_emergente"))
from malha import ARESTAS_LOC, FACES_LOC, Complexo, pontos_tapete   # noqa: E402
import c5a_curl_curl_emergente as CC                                  # noqa: E402

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402
import matplotlib.ticker          # noqa: E402

L = CC.L
SEMENTE = 20261002
sig, zero_ou, eh_zero, ZERO = CC.sig, CC.zero_ou, CC.eh_zero, CC.ZERO


# ---------------------------------------------------------------------- microgeometrias (σ: métrica e^{2σ}δ)
def _d(X, c):
    d = X - c
    return d - L * np.round(d / L)


def sigma_plano(X):
    return np.zeros(X.shape[:-1]), np.zeros(X.shape), np.zeros(X.shape + (3,))


def _gauss(d, m, s):
    e = m * np.exp(-np.sum(d * d, -1) / (2 * s * s))
    g = -d * (e / (s * s))[..., None]
    H = e[..., None, None] * (d[..., :, None] * d[..., None, :] / s**4 - np.eye(3) / (s * s))
    return e, g, H


def sigma_poco(X, m=1.0, s=L / 7):
    """Poço fundo (Φ = −m no centro; σ = −Φ). Devolve σ, ∇σ e a hessiana."""
    return _gauss(_d(X, L / 2), m, s)


def sigma_vale(X, m=0.7, s=L / 8):
    """Vale: fileira de poços sobreposta = linha ao longo de z em (L/2, L/2)."""
    d = _d(X, L / 2)
    d[..., 2] = 0
    e, g, H = _gauss(d, m, s)
    H[..., 2, :] = 0
    H[..., :, 2] = 0
    return e, g, H


GEOMETRIAS = {"plana": sigma_plano, "poço fundo": sigma_poco, "vale": sigma_vale}


def rodrigues(th):
    """exp([θ]×) para um lote de vetores de rotação θ (n, 3)."""
    a = np.linalg.norm(th, axis=1)
    k = np.where(a[:, None] > 0, th / np.where(a > 0, a, 1)[:, None], 0)
    K = np.zeros((len(th), 3, 3))
    K[:, 0, 1], K[:, 0, 2], K[:, 1, 2] = -k[:, 2], k[:, 1], -k[:, 0]
    K[:, 1, 0], K[:, 2, 0], K[:, 2, 1] = k[:, 2], -k[:, 1], k[:, 0]
    s, c = np.sin(a)[:, None, None], (1 - np.cos(a))[:, None, None]
    return np.eye(3)[None] + s * K + c * (K @ K)


def log_rot(R):
    """Vetor de rotação de um lote de matrizes de rotação (ângulos pequenos/moderados)."""
    tr = np.clip((np.trace(R, axis1=1, axis2=2) - 1) / 2, -1, 1)
    a = np.arccos(tr)
    v = np.stack([R[:, 2, 1] - R[:, 1, 2], R[:, 0, 2] - R[:, 2, 0], R[:, 1, 0] - R[:, 0, 1]], 1)
    f = np.where(a > 1e-12, a / (2 * np.sin(np.where(a > 1e-12, a, 1))), 0.5)
    return v * f[:, None]


def vertices_faces(C):
    """Posições (com o deslocamento periódico) dos três GMFs de cada loop, na ordem da orientação."""
    pos = np.zeros((C.F, 3, 3))
    vis = np.zeros(C.F, bool)
    for fl, (a, b, c) in enumerate(FACES_LOC):
        ids = C.face_t[:, fl]
        novo = ~vis[ids]
        pos[ids[novo]] = C.Xt[novo][:, [a, b, c]]
        vis[ids] = True
    return pos


def transporte(xa, xb, geo):
    """Transporte de Levi-Civita de xa para xb (métrica e^{2σ}δ, base ortonormal): rotação por ∇σ(meio)×Δx."""
    _, g, _ = geo(0.5 * (xa + xb))
    return rodrigues(np.cross(g, xb - xa))


def skew(v):
    K = np.zeros(v.shape[:-1] + (3, 3))
    K[..., 0, 1], K[..., 0, 2], K[..., 1, 2] = -v[..., 2], v[..., 1], -v[..., 0]
    K[..., 1, 0], K[..., 2, 0], K[..., 2, 1] = v[..., 2], -v[..., 1], v[..., 0]
    return K


def curvatura_loop(x0, x1, x2, geo):
    """Curvatura de Riemann integrada no loop (no centro do triângulo): ½ F(u, v), com o conector A(dx) = [∇σ×dx]×
    do transporte (dV = A V) e F(u, v) = ∂_u A(v) − ∂_v A(u) − [A(u), A(v)] (inclui o termo não abeliano)."""
    c = (x0 + x1 + x2) / 3
    u, v = x1 - x0, x2 - x0
    _, g, H = geo(c)
    Au, Av = skew(np.cross(g, u)), skew(np.cross(g, v))
    dAvu = skew(np.cross(np.einsum("nij,nj->ni", H, u), v))      # ∂_u A(v)
    dAuv = skew(np.cross(np.einsum("nij,nj->ni", H, v), u))      # ∂_v A(u)
    F = dAvu - dAuv - (Au @ Av - Av @ Au)
    Fv = np.stack([F[:, 2, 1], F[:, 0, 2], F[:, 1, 0]], 1)
    return 0.5 * Fv


def p1_holonomia(rng):
    res = {}
    for nome, geo in GEOMETRIAS.items():
        linhas = []
        for nl in (6, 9, 13, 18):
            C, _, _ = CC.montar(nl, rng)
            pos = vertices_faces(C)
            x0, x1, x2 = pos[:, 0], pos[:, 1], pos[:, 2]
            P01, P12, P20 = transporte(x0, x1, geo), transporte(x1, x2, geo), transporte(x2, x0, geo)
            H = P20 @ P12 @ P01                                   # volta 0 → 1 → 2 → 0
            Hrev = np.transpose(P01, (0, 2, 1)) @ np.transpose(P12, (0, 2, 1)) @ np.transpose(P20, (0, 2, 1))
            inv = float(np.max(np.abs(Hrev @ H - np.eye(3))))
            Th = log_rot(H)
            ref = curvatura_loop(x0, x1, x2, geo)
            A = 0.5 * np.linalg.norm(np.cross(x1 - x0, x2 - x0), axis=1)
            # orientação embaralhada: cada ligação percorrida num sentido sorteado (P ou Pᵀ); o produto deixa de ser
            # o transporte numa volta fechada
            tr = lambda P: np.transpose(P, (0, 2, 1))
            sorteio = [rng.random(C.F) < 0.5 for _ in range(3)]
            Ps = [np.where(s_[:, None, None], tr(P), P) for s_, P in zip(sorteio, (P01, P12, P20))]
            Hs = Ps[2] @ Ps[1] @ Ps[0]
            Ths = log_rot(Hs)
            nref = np.linalg.norm(ref, axis=1)
            ok = nref > 1e-3 * max(nref.max(), 1e-300)
            if nref.max() > 0:
                err = float(np.linalg.norm(Th[ok] - ref[ok]) / np.linalg.norm(ref[ok]))
                err_s = float(np.linalg.norm(Ths[ok] - ref[ok]) / np.linalg.norm(ref[ok]))
                dens = float(np.mean(np.linalg.norm(Th[ok], axis=1) / A[ok]))
            else:
                err = err_s = dens = 0.0
            linhas.append({"GMFs": C.N, "loops": C.F,
                           "max |H(invertido)·H − I|": zero_ou(inv),
                           "max |H − I| (rad)": zero_ou(float(np.max(np.linalg.norm(Th, axis=1)))),
                           "erro da holonomia contra a curvatura de Riemann integrada": zero_ou(err),
                           "holonomia / área do loop (média, rad por unidade de área)": zero_ou(dens),
                           "embaralhado: erro contra a curvatura de Riemann integrada": zero_ou(err_s)})
        res[nome] = linhas
    return res


# ---------------------------------------------------------------------- P2: grau das ligações derivado de q_n
def ondas_nos(C, k):
    return np.stack([np.kron(np.exp(1j * (C.P @ k)), e) for e in np.eye(3)], 1)     # (3N, 3)


def espectro_nos(C, K, Mn, ns):
    out = []
    for n in ns:
        k = 2 * math.pi / L * np.asarray(n, float)
        Q = ondas_nos(C, k)
        Kk = Q.conj().T @ (K @ Q)
        Mk = Q.conj().T @ (Mn[:, None] * Q)
        import scipy.linalg as sl
        w2, v = sl.eigh((Kk + Kk.conj().T) / 2, (Mk + Mk.conj().T) / 2)
        kh = k / np.linalg.norm(k)
        lon = [abs(kh @ v[:, i]) / np.linalg.norm(v[:, i]) for i in range(3)]
        out.append((n, w2 / (k @ k), lon))
    return out


def p2_derivado(rng):
    """B1: falha de fechamento das diferenças covariantes (telescópica); B3: projeção na ligação."""
    ns = [(1, 0, 0), (1, 1, 0), (2, 1, 0), (1, 1, 1)]
    res = {}
    # B1: (H_f − I) q_{n1} — termo local, sem derivadas
    lin = {}
    for nome in ("plana", "poço fundo"):
        geo = GEOMETRIAS[nome]
        C, _, _ = CC.montar(9, rng)
        pos = vertices_faces(C)
        x0, x1, x2 = pos[:, 0], pos[:, 1], pos[:, 2]
        H = transporte(x2, x0, geo) @ transporte(x1, x2, geo) @ transporte(x0, x1, geo)
        # nó de partida: o primeiro GMF do loop (menor índice)
        from malha import FACES_LOC as _FL
        ids = np.zeros(C.F, int)
        vis = np.zeros(C.F, bool)
        for fl, (a, b, c) in enumerate(_FL):
            fi = C.face_t[:, fl]
            novo = ~vis[fi]
            ids[fi[novo]] = C.ot[novo][:, a]
            vis[fi] = True
        D = H - np.eye(3)
        blocos = np.einsum("fji,fjk->fik", D, D)
        Kb = np.zeros((C.N, 3, 3))
        np.add.at(Kb, ids, blocos)
        K = sp.block_diag(list(Kb), format="csr")
        Mn = np.full(3 * C.N, L**3 / C.N)
        if np.abs(Kb).max() == 0:
            lin[nome] = {"energia de fechamento": "identicamente zero (a soma das diferenças covariantes num loop se "
                                                  "cancela; no fundo plano H = I)", "propaga": False}
        else:
            esp = espectro_nos(C, K, Mn, [(1, 0, 0), (2, 0, 0), (4, 0, 0)])
            w = [float(np.mean(w2 * (2 * math.pi / L * np.linalg.norm(n))**2)) for n, w2, _ in esp]
            lin[nome] = {"omega² médio para |n| = 1, 2, 4": [sig(x, 3) for x in w],
                         "omega²(4k)/omega²(k) (curl-curl daria 16)": sig(w[2] / w[0], 3),
                         "leitura": "termo local de curvatura (tipo massa), sem derivadas: não é curl-curl"}
    res["B1 diferença covariante q_m − P q_n, energia Σ ||falha de fechamento||²"] = lin
    # B3: a_e = ½(P q_n + P q_m)·Δx, energia Σ C_f² (pesos de Whitney), massa por GMF
    lin = []
    for nl in (6, 9, 13, 18):
        C, M1, M2 = CC.montar(nl, rng)
        E, N = C.E, C.N
        d = C.vet_aresta
        a, b = C.arestas[:, 0], C.arestas[:, 1]
        rows = np.repeat(np.arange(E), 6)
        cols = np.stack([3 * a, 3 * a + 1, 3 * a + 2, 3 * b, 3 * b + 1, 3 * b + 2], 1).ravel()
        vals = np.concatenate([0.5 * d, 0.5 * d], 1).ravel()
        T = sp.csr_matrix((vals, (rows, cols)), shape=(E, 3 * N))
        K = (T.T @ (C.d1.T @ M2 @ C.d1) @ T).tocsr()
        Mn = np.full(3 * N, L**3 / N)
        esp = espectro_nos(C, K, Mn, ns)
        wT, wL, lonT = [], [], []
        for n, w2, lon in esp:
            o = np.argsort(lon)
            wT += list(w2[o[:2]]); wL.append(w2[o[2]]); lonT.append(max(lon[o[0]], lon[o[1]]))
        cT2 = float(np.mean(wT))
        lin.append({"GMFs": N, "graus de liberdade": 3 * N, "omega_L²/omega_T² (média dos k)": sig(float(np.mean(wL)) / cT2, 3),
                    "omega_L²/omega_T² para k = 2π(2,1,0)/L": sig(float(wL[2]) / cT2, 3),
                    "maior |k̂·q| dos transversais": sig(float(max(lonT)), 3)})
    res["B3 projeção na ligação a_e = ½(P q_n + P q_m)·Δx, energia Σ C_f²"] = lin
    return res


# ---------------------------------------------------------------------- P3: conexão relacional
def pesos_duais(C):
    """Dual baricêntrico: para cada loop f, w_f = ℓ*_f / A_f (comprimento dual / área); para cada ligação e,
    m_e = A*_e / |e|. Com eles, Σ_f w_f C_f² ≈ ∫|F|² e Σ_e m_e ȧ_e² ≈ ∫|ȧ|² (F = holonomia por área)."""
    X = C.Xt
    tc = X.mean(1)
    lf = np.zeros(C.F)
    for fl, (a, b, c) in enumerate(FACES_LOC):
        fc = X[:, [a, b, c]].mean(1)
        np.add.at(lf, C.face_t[:, fl], np.linalg.norm(tc - fc, axis=1))
    pos = vertices_faces(C)
    Af = 0.5 * np.linalg.norm(np.cross(pos[:, 1] - pos[:, 0], pos[:, 2] - pos[:, 0]), axis=1)
    Ae = np.zeros(C.E)
    for el, (i, j) in enumerate(ARESTAS_LOC):
        em = 0.5 * (X[:, i] + X[:, j])
        fs = [fl for fl, f in enumerate(FACES_LOC) if i in f and j in f]
        f1 = X[:, list(FACES_LOC[fs[0]])].mean(1)
        f2 = X[:, list(FACES_LOC[fs[1]])].mean(1)
        e = X[:, j] - X[:, i]
        e = e / np.linalg.norm(e, axis=1)[:, None]
        va = 0.5 * np.cross(f1 - em, tc - em) + 0.5 * np.cross(tc - em, f2 - em)
        np.add.at(Ae, C.aresta_t[:, el], np.abs(np.sum(va * e, 1)))
    le = np.linalg.norm(C.vet_aresta, axis=1)
    return lf / Af, Ae / le


def p3_conexao(rng):
    """O grau de cada ligação é a parte relacional do transporte entre GMFs, U_nm = e^{i a_nm} (U_mn = U_nm⁻¹).
    Holonomia do loop: e^{i C_f}, C_f = soma de a ao longo da volta (a orientação vem da composição dos transportes).
    Energia: falha de fechamento w_f ||e^{iC_f} − 1||² = 2 w_f (1 − cos C_f) ≈ w_f C_f². Massa: ½ Σ m_e ȧ_e²."""
    ondas = CC.base_ondas(CC.NS_TESTE)
    ns = [(1, 0, 0), (0, 1, 1), (1, 1, 1), (2, 1, 0), (1, 2, 2), (3, 1, 1), (2, -1, 1)]
    res = {}
    conv = {"W (∫|F|², Whitney)": [], "D (dual baricêntrico, diagonal)": [], "U (uniforme)": [],
            "embaralhado (orientação aleatória)": []}
    esp_fim = {}
    for nl in (6, 9, 13, 18):
        C, M1, M2 = CC.montar(nl, rng)
        wf, me = pesos_duais(C)
        I = sp.identity(C.E, format="csr")
        variantes = {"W (∫|F|², Whitney)": (C.d1.T @ M2 @ C.d1, M1),
                     "D (dual baricêntrico, diagonal)": (C.d1.T @ sp.diags(wf) @ C.d1, sp.diags(me)),
                     "U (uniforme)": (C.d1.T @ C.d1, I)}
        d1r = CC.d1_aleatorio(C, rng)
        variantes["embaralhado (orientação aleatória)"] = (d1r.T @ M2 @ d1r, M1)
        for nome, (K, M) in variantes.items():
            K = K.tocsr()
            ef, _, al, _, _ = erro_fraco(C, K, M, ondas)
            conv[nome].append({"GMFs": C.N, "eps_cc_fraco": sig(ef, 3), "alfa": sig(al, 4)})
            if nl == 13:
                esp_fim[nome] = resumo_espectro(CC.espectro_ondas(C, K, M, ns))
                phi = rng.normal(size=C.N)
                qg = C.d0 @ phi
                esp_fim[nome]["|Kq| / |K q_aleatório| para q = ∇φ (gauge)"] = zero_ou(
                    float(np.linalg.norm(K @ qg) / np.linalg.norm(K @ rng.normal(size=C.E)) *
                          np.linalg.norm(rng.normal(size=C.E)) / np.linalg.norm(qg)))
        if nl == 13:
            # energia não linear (holonomia completa) contra a forma quadrática; invariância de gauge finita
            k = 2 * math.pi / L * np.array([1.0, 0, 0])
            q0 = C.onda_aresta(k, np.array([0, 1.0, 0])).real
            Cf0 = C.d1 @ q0
            tab = []
            for amp in (0.1, 0.5, 1.0, 2.0):
                s_ = amp / np.abs(Cf0).max()
                Cf = s_ * Cf0
                Eq = 0.5 * np.sum(wf * Cf**2)
                Ew = np.sum(wf * (1 - np.cos(Cf)))
                tab.append({"max |C_f| (rad)": amp, "E_holonomia / E_quadrática": sig(Ew / Eq, 4)})
            phi = rng.normal(size=C.N) * 3.0
            a = rng.normal(size=C.E)
            Ew1 = np.sum(wf * (1 - np.cos(C.d1 @ a)))
            Ew2 = np.sum(wf * (1 - np.cos(C.d1 @ (a + C.d0 @ phi))))
            res["energia da holonomia completa"] = {
                "razão contra a forma quadrática (onda transversal)": tab,
                "|E(a + ∇φ) − E(a)| / E(a) com φ grande (gauge finito)": zero_ou(abs(Ew2 - Ew1) / Ew1)}
            # orientação invertida (todas as voltas ao contrário): d1 → −d1
            Kinv = ((-C.d1).T @ M2 @ (-C.d1)).tocsr()
            K0 = (C.d1.T @ M2 @ C.d1).tocsr()
            res["C4 orientação invertida: |K(−d1) − K(d1)| / |K|"] = zero_ou(float(abs(Kinv - K0).max() / abs(K0).max()))
    res["convergência do operador (forma fraca)"] = conv
    res["espectro e gauge (2197 GMFs)"] = esp_fim
    return res


def erro_fraco(C, K, M, ondas):
    """Só a parte fraca de CC.erro_operador (sem as soluções ponto a ponto)."""
    V = L**3
    Q = np.stack([C.onda_aresta(k, A) for k, A, _ in ondas], 1)
    Bh = Q.conj().T @ (K @ Q)
    m = len(ondas)
    B_ex = np.zeros((m, m), complex)
    for a_, (ka, Aa, _) in enumerate(ondas):
        for b_, (kb, Ab, _) in enumerate(ondas):
            if np.allclose(ka, kb):
                B_ex[a_, b_] = V * np.cross(ka, Aa) @ np.cross(kb, Ab)
    al = np.vdot(B_ex, Bh).real / np.vdot(B_ex, B_ex).real
    return np.linalg.norm(Bh - al * B_ex) / np.linalg.norm(Bh), None, al, None, None


def resumo_espectro(lista):
    wT = np.array([np.sort(w2)[1:] for _, w2, _ in lista])
    w0 = np.array([np.sort(w2)[0] for _, w2, _ in lista])
    lonT = np.array([np.array(lon)[np.argsort(w2)][1:] for _, w2, lon in lista])
    lon0 = np.array([np.array(lon)[np.argsort(w2)][0] for _, w2, lon in lista])
    s = float(np.mean(wT))
    return {"omega/ck dos 2 transversais (média, desvio)": [sig(math.sqrt(np.mean(wT) / s), 4),
                                                           sig(float(np.std(np.sqrt(wT / s))), 3)],
            "maior |k̂·q| dos 2 transversais": sig(float(lonT.max()), 3),
            "omega²/(ck)² do terceiro modo (máximo)": zero_ou(float((w0 / s).max())),
            "conteúdo longitudinal do terceiro modo (mínimo)": sig(float(lon0.min()), 4)}


# ---------------------------------------------------------------------- P4: fundos e helicidade
def p4_fundos(rng):
    """C1 poço fundo e C2 vale (conexão relacional, pesos W): a microgeometria entra como ε = μ = n = e^{2σ} nos pesos
    (a mesma convenção de c5a_curl_curl_emergente C5); o operador esperado é ∇×(1/n)∇×.
    C3 girante (guia em rotação rígida, ±J) e C4 espelhado: helicidade ℓ = 0, h = ±1."""
    res = {}
    for nome, geo in (("C1 poço fundo", sigma_poco), ("C2 vale", sigma_vale)):
        nfun = lambda X, geo=geo: np.exp(2 * geo(X)[0])
        ondas = CC.base_ondas(CC.NS_TESTE)
        m = len(ondas)
        g = np.linspace(0, L, 48, endpoint=False)
        Xg = np.stack(np.meshgrid(g, g, g, indexing="ij"), -1)
        nn = nfun(Xg)
        V = L**3
        B_ex = np.zeros((m, m), complex)
        for a_, (ka, Aa, _) in enumerate(ondas):
            for b_, (kb, Ab, _) in enumerate(ondas):
                B_ex[a_, b_] = V * np.mean(np.exp(1j * (Xg @ (kb - ka))) / nn) * (np.cross(ka, Aa) @ np.cross(kb, Ab))
        lin = []
        for nl in (6, 9, 13):
            C, M1, M2 = CC.montar(nl, rng, n_fun=nfun)
            K = (C.d1.T @ M2 @ C.d1).tocsr()
            Q = np.stack([C.onda_aresta(k, A) for k, A, _ in ondas], 1)
            Bh = Q.conj().T @ (K @ Q)
            al = np.vdot(B_ex, Bh).real / np.vdot(B_ex, B_ex).real
            phi = rng.normal(size=C.N)
            lin.append({"GMFs": C.N, "eps contra ∇×(1/n)∇×": sig(float(np.linalg.norm(Bh - al * B_ex) / np.linalg.norm(Bh)), 3),
                        "alfa": sig(al, 4),
                        "|K∇φ|/|Kq| (gauge)": zero_ou(float(np.linalg.norm(K @ (C.d0 @ phi)) /
                                                          np.linalg.norm(K @ rng.normal(size=C.E))))})
        res[nome] = {"n_maximo": sig(float(nn.max()), 3), "convergência": lin}
    # C3 girante (±J) e C4 espelhado
    Om = 0.05
    g3 = CC.t_girante(rng, Om0=Om, omegas=(0.0, Om, -Om))
    w = {k: v for k, v in g3["omegas"].items()}
    W = lambda o, s: w[f"{o:+.3f}, s = {s:+d}"]
    dw = {(J, h): W(J, h) - W(0.0, h) for J in (Om, -Om) for h in (1, -1)}
    res["C3 girante"] = {"GMFs": g3["GMFs"], "Omega": Om,
                         "|G∇φ| / |Gq|": g3["|G∇φ| / |Gq| (o arrasto não mexe nos gradientes)"],
                         "omega(J = 0): h = +1, −1": [W(0.0, 1), W(0.0, -1)],
                         "Δω(+J, +1), Δω(−J, +1), Δω(+J, −1), Δω(−J, −1)": [sig(dw[(Om, 1)], 4), sig(dw[(-Om, 1)], 4),
                                                                        sig(dw[(Om, -1)], 4), sig(dw[(-Om, -1)], 4)],
                         "previsto (rotação rígida, m = −h): Δω(J, h) = −h·J": [-Om, Om, Om, -Om]}
    g4 = CC.t_girante(rng, Om0=Om, omegas=(0.0, Om), espelho=True)
    w4 = g4["omegas"]
    d4 = {h: w4[f"{Om:+.3f}, s = {h:+d}"] - w4[f"{0.0:+.3f}, s = {h:+d}"] for h in (1, -1)}
    res["C4 malha espelhada (y → −y), mesmo giro +J"] = {
        "Δω(+J, +1), Δω(+J, −1)": [sig(d4[1], 4), sig(d4[-1], 4)],
        "leitura": "a malha espelhada (a 'mão' da disposição dos GMFs trocada), com o mesmo giro do espaço, separa as "
                   "helicidades do mesmo jeito: o sinal vem do giro, não da malha nem da orientação dos loops"}
    return res



# ---------------------------------------------------------------------- figura e principal
def figura(r1, r2, r3, r4, pasta):
    fig, axs = plt.subplots(1, 3, figsize=(16, 4.6))
    ax = axs[0]
    for nome, cor in (("poço fundo", "#2a78d6"), ("vale", "#2f9e6e")):
        lin = r1[nome]
        ax.loglog([x["GMFs"] for x in lin], [x["erro da holonomia contra a curvatura de Riemann integrada"] for x in lin],
                  "o-", color=cor, linewidth=2, label=f"holonomia × curvatura: {nome}")
        ax.loglog([x["GMFs"] for x in lin], [x["embaralhado: erro contra a curvatura de Riemann integrada"] for x in lin],
                  "s--", color=cor, linewidth=1, label=f"orientação embaralhada: {nome}")
    ax.set_xlabel("número de GMFs"); ax.set_ylabel("erro relativo")
    ax.set_title("P1: transporte paralelo → holonomia = curvatura", fontsize=10)
    ax.legend(fontsize=7, frameon=False)
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.grid(True, which="both", alpha=0.2, linewidth=0.6)
    ax = axs[1]
    b3 = r2["B3 projeção na ligação a_e = ½(P q_n + P q_m)·Δx, energia Σ C_f²"]
    ax.loglog([x["GMFs"] for x in b3], [x["omega_L²/omega_T² (média dos k)"] for x in b3], "o-", color="#c9582b",
              linewidth=2, label="B3 derivado de q_n: ω_L²/ω_T²")
    cores = {"W (∫|F|², Whitney)": "#2a78d6", "D (dual baricêntrico, diagonal)": "#7b4fd6", "U (uniforme)": "#2f9e6e",
             "embaralhado (orientação aleatória)": "#7a7a74"}
    for nome, cor in cores.items():
        lin = r3["convergência do operador (forma fraca)"][nome]
        ax.loglog([x["GMFs"] for x in lin], [x["eps_cc_fraco"] for x in lin], "s-", color=cor, linewidth=1.5,
                  label=f"conexão {nome.split(' ')[0]}: ε_cc" if "embaralhado" not in nome else "embaralhado: ε_cc")
    ax.set_xlabel("número de GMFs")
    ax.set_title("P2/P3: grau derivado (longitudinal mole)\ncontra conexão relacional (curl-curl, gauge exato)", fontsize=10)
    ax.legend(fontsize=7, frameon=False)
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.grid(True, which="both", alpha=0.2, linewidth=0.6)
    ax = axs[2]
    c3 = r4["C3 girante"]
    med = c3["Δω(+J, +1), Δω(−J, +1), Δω(+J, −1), Δω(−J, −1)"]
    pre = c3["previsto (rotação rígida, m = −h): Δω(J, h) = −h·J"]
    x = np.arange(4)
    ax.bar(x - 0.18, pre, width=0.36, color="#d8d8d4", label="previsto (−h·J)")
    ax.bar(x + 0.18, med, width=0.36, color="#2a78d6", label="medido no tapete")
    ax.axhline(0, color="#1b1b19", linewidth=0.6)
    ax.set_xticks(x); ax.set_xticklabels(["+J, h=+1", "−J, h=+1", "+J, h=−1", "−J, h=−1"])
    ax.set_ylabel("Δω")
    ax.set_title("P4: fundo girante separa h = ±1 (ℓ = 0)", fontsize=10)
    ax.legend(fontsize=8, frameon=False)
    for a in axs:
        for lado in ("top", "right"):
            a.spines[lado].set_visible(False)
    fig.tight_layout()
    fig.savefig(pasta / "c5a_holonomia_loops.png", dpi=150)
    plt.close(fig)


def main():
    saida = Path(sys.argv[1] if len(sys.argv) > 1 else "c5a_holonomia_loops.json")
    pasta = saida.resolve().parent
    pasta.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEMENTE)
    r1 = p1_holonomia(rng)
    r2 = p2_derivado(rng)
    r3 = p3_conexao(rng)
    r4 = p4_fundos(rng)
    ok = {}
    ok["1_holonomia_converge_para_curvatura"] = all(
        eh_zero(x["max |H(invertido)·H − I|"]) for g in r1.values() for x in g) and all(
        eh_zero(x["max |H − I| (rad)"]) for x in r1["plana"]) and all(
        r1[g][-1]["erro da holonomia contra a curvatura de Riemann integrada"] <
        0.6 * r1[g][0]["erro da holonomia contra a curvatura de Riemann integrada"] for g in ("poço fundo", "vale")) and all(
        r1[g][-1]["embaralhado: erro contra a curvatura de Riemann integrada"] > 1 for g in ("poço fundo", "vale"))
    b1 = r2["B1 diferença covariante q_m − P q_n, energia Σ ||falha de fechamento||²"]
    ok["2_diferenca_covariante_nao_da_curl_curl"] = (b1["plana"]["propaga"] is False and
                                                     abs(b1["poço fundo"]["omega²(4k)/omega²(k) (curl-curl daria 16)"] - 1) < 0.1)
    b3 = r2["B3 projeção na ligação a_e = ½(P q_n + P q_m)·Δx, energia Σ C_f²"]
    ok["3_derivado_de_q_n_longitudinal_mole_mas_propaga"] = (b3[-1]["omega_L²/omega_T² (média dos k)"] <
                                                              0.3 * b3[0]["omega_L²/omega_T² (média dos k)"] and
                                                              b3[-1]["omega_L²/omega_T² (média dos k)"] > 1e-3)
    cv = r3["convergência do operador (forma fraca)"]
    es = r3["espectro e gauge (2197 GMFs)"]["W (∫|F|², Whitney)"]
    ok["4_conexao_relacional_curl_curl_e_gauge"] = (cv["W (∫|F|², Whitney)"][-1]["eps_cc_fraco"] < 0.02 and
                                                    eh_zero(es["omega²/(ck)² do terceiro modo (máximo)"]) and
                                                    eh_zero(es["|Kq| / |K q_aleatório| para q = ∇φ (gauge)"]) and
                                                    es["maior |k̂·q| dos 2 transversais"] < 0.1 and
                                                    cv["embaralhado (orientação aleatória)"][-1]["eps_cc_fraco"] > 0.5 and
                                                    eh_zero(r3["energia da holonomia completa"]["|E(a + ∇φ) − E(a)| / E(a) com φ grande (gauge finito)"]))
    ok["5_geometria_so_coeficientes"] = all(r4[g]["convergência"][-1]["eps contra ∇×(1/n)∇×"] < 0.03 and
                                            eh_zero(r4[g]["convergência"][-1]["|K∇φ|/|Kq| (gauge)"]) for g in ("C1 poço fundo", "C2 vale"))
    c3 = r4["C3 girante"]
    med = c3["Δω(+J, +1), Δω(−J, +1), Δω(+J, −1), Δω(−J, −1)"]
    pre = c3["previsto (rotação rígida, m = −h): Δω(J, h) = −h·J"]
    ok["6_helicidade_separa_com_giro"] = all(abs(m - p) < 0.1 * abs(p) for m, p in zip(med, pre)) and \
        abs(c3["omega(J = 0): h = +1, −1"][0] - c3["omega(J = 0): h = +1, −1"][1]) < 0.05 * abs(pre[0])
    out = {"parametros": {"caixa": L, "semente": SEMENTE},
           "P1_transporte_e_holonomia": r1, "P2_grau_derivado_de_q_n": r2, "P3_conexao_relacional": r3,
           "P4_fundos_e_helicidade": r4, "criterios": {k: bool(v) for k, v in ok.items()}}
    out["todos_passaram"] = bool(all(ok.values()))
    for k, v in ok.items():
        print(k, "PASSOU" if v else "FALHOU")
    with saida.open("w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    figura(r1, r2, r3, r4, pasta)
    print("GLOBAL:", "TODOS PASSARAM" if out["todos_passaram"] else "HA FALHAS")
    return 0 if out["todos_passaram"] else 1


if __name__ == "__main__":
    sys.exit(main())
