#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C5A — G0G: microgeometria basal compensada + fóton vetorial + backreaction fraca
=================================================================================

Prompt do usuário: docs/C5A_Prompt_G0G_Fundo_Basal_Foton_Backreaction_PT.md. Base: c5a_curl_curl_emergente (tapete 3D,
loops de Delaunay, guia de onda), c5a_holonomia_loops (conexão relacional, energia de Wilson), c5a_tapete_gmf (poço
girando).

Fundo basal g⁽⁰⁾ [H]: microvórtices em que o espaço é arrastado em rotação (o "poço girando" em miniatura), quiralidade
χ = +1 (anti-horário) ou −1 (horário): u⁽⁰⁾ = Σ_j χ_j Ω0 e^{−|r−c_j|²/2s²} ẑ×(r − c_j). Fundo compensado: um par χ = ±1.
Fóton: a conexão relacional dos GMFs (loops de Delaunay, energia ½ Cᵀ M2 C), num guia cilíndrico periódico em z
(modo fundamental, ℓ = 0 no eixo, h = ±1), e numa caixa periódica (ondas planas).
Backreaction: do tensor de energia-momento do modo (densidade de energia ρ e de momento S = E×B), gravidade linearizada
[H]: ∇²Φ_γ = 4πG ρ (δg_00 = −2Φ_γ, δg_ij = −2Φ_γ δ_ij) e ∇²u_δ = −16πG S (δg_0i = −u_δ, arrasto de Lense–Thirring).
δg só corrige g⁽⁰⁾; nunca o cria. Repropagação sobre g⁽⁰⁾ + δg[h].

Uso: python c5a_g0g_backreaction.py [saida.json]
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI.parent / "c5a_curl_curl_emergente"))
from malha import ARESTAS_LOC, Complexo, pontos_tapete   # noqa: E402
import c5a_curl_curl_emergente as CC                       # noqa: E402

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402

SEMENTE = 20261003
sig, zero_ou, eh_zero, ZERO = CC.sig, CC.zero_ou, CC.eh_zero, CC.ZERO


# ---------------------------------------------------------------------- guia de onda com GMFs
class Guia:
    """Guia cilíndrico (raio R, paredes condutoras), periódico em z, preenchido por um tapete de GMFs sem grade. A malha
    é a mesma para todos os casos (as diferenças entre casos não vêm do ruído da malha)."""

    def __init__(self, rng, R=3.0, Lz=4.0, h=0.5):
        self.R, self.Lz = R, Lz
        nxy, nz = int(round(2 * R / h)), int(round(Lz / h))
        Pin = pontos_tapete(np.array([nxy, nxy, nz]), np.array([2 * R, 2 * R, Lz]), rng) - np.array([R, R, 0])
        Pin = Pin[np.hypot(Pin[:, 0], Pin[:, 1]) < R - 0.35 * h]
        nb = int(round(2 * math.pi * R / h))
        zs = (np.arange(nz) + 0.5) * Lz / nz
        ang = (np.arange(nb)[None, :] + 0.5 * (np.arange(nz)[:, None] % 2) + rng.uniform(-0.2, 0.2, (nz, nb))) * 2 * math.pi / nb
        Pb = np.stack([R * np.cos(ang).ravel(), R * np.sin(ang).ravel(), np.repeat(zs, nb)], 1)
        P = np.concatenate([Pin, Pb]) + np.array([R, R, 0])
        borda = np.r_[np.zeros(len(Pin), bool), np.ones(len(Pb), bool)]
        C = Complexo(P, np.array([2 * R, 2 * R, Lz]), periodico=(False, False, True), parede=borda)
        self.C = C
        self.I = np.nonzero(~(borda[C.arestas[:, 0]] & borda[C.arestas[:, 1]]))[0]
        self.d0 = C.d0[self.I][:, np.nonzero(~borda)[0]]
        self.d1 = C.d1[:, self.I]
        self.cen = C.Xt.mean(1) - np.array([R, R, 0])          # centro de cada tetraedro, relativo ao eixo
        g = C.grad
        self.wc = np.stack([0.25 * (g[:, j] - g[:, i]) for (i, j) in ARESTAS_LOC], 1)   # w_e no centro
        self.wint = self.wc * C.vol[:, None, None]                                       # ∫ w_e dV
        self.cl = C.curl_local()
        self.loc = np.full(C.E, -1)
        self.loc[self.I] = np.arange(len(self.I))
        self.dt = 1.0 / math.sqrt(CC.limite_wmax(C)) / 1.0
        mid = C.P[C.arestas[self.I, 0]] + 0.5 * C.vet_aresta[self.I] - np.array([R, R, 0])
        self.perto = np.hypot(mid[:, 0], mid[:, 1]) < 0.5 * R
        self.matrizes(np.ones(C.T))

    def matrizes(self, n_t):
        """ε = μ = n por tetraedro (Φ estático: n = e^{−2Φ})."""
        M1, M2 = self.C.matrizes(eps_t=n_t, inv_mu_t=1 / n_t)
        I = self.I
        self.M1 = M1[I][:, I].tocsc()
        self.K = (self.d1.T @ M2 @ self.d1).tocsr()
        self.n_t = n_t
        self.lu = spl.splu(self.M1, permc_spec="MMD_AT_PLUS_A", options=dict(SymmetricMode=True))

    def matriz_G(self, u_t):
        """G_ee' = ∫ w_e·((∇×w_e')×u): o campo levado pelo arrasto u (i_u dq)."""
        Gl = np.einsum("tei,tfi->tef", self.wint, np.cross(self.cl, u_t[:, None, :]))
        return self.C._monta(Gl, self.C.aresta_t, self.C.E)[self.I][:, self.I].tocsr()

    def campos(self, q, v):
        """E = −q̇ e B = ∇×q no centro de cada tetraedro (interpolação de Whitney)."""
        a = np.zeros(self.C.E, q.dtype); a[self.I] = q
        b = np.zeros(self.C.E, v.dtype); b[self.I] = v
        qa, va = a[self.C.aresta_t], b[self.C.aresta_t]
        B = np.einsum("tei,te->ti", self.cl, qa)
        E = -np.einsum("tei,te->ti", self.wc, va)
        return E, B

    def rodar(self, u_t, pol, k_n=1, T=40.0, coletar=False):
        """Lança o modo fundamental com polarização pol (+1, −1: circular h = ±1; 0: linear em x) e mede a frequência de
        cada helicidade em π (que não depende do gauge) perto do eixo. Devolve ω_+, ω_−, a mistura, a rotação da
        polarização, a lei de Gauss e (se pedido) ρ e S médios no tempo, por tetraedro."""
        sol = self.lu.solve
        K, M1 = self.K, self.M1
        G = self.matriz_G(u_t)
        GT = G.T.tocsr()
        dt = self.dt
        k = 2 * math.pi * k_n / self.Lz
        kv = np.array([0, 0, k])
        ex, ey = np.eye(3)[0], np.eye(3)[1]
        Q = {s: self.C.onda_aresta(kv, ex - 1j * s * ey)[self.I] for s in (1, -1)}
        Qx = self.C.onda_aresta(kv, ex)[self.I]
        Q0 = Q[pol] if pol != 0 else Qx
        q = Q0.real.copy()
        v = (k * Q0.imag).copy()
        pi = M1 @ v + G @ q
        gauss0 = self.d0.T @ pi
        Hf = lambda q, pi: 0.5 * pi @ sol(pi) + 0.5 * q @ (K @ q) - pi @ sol(G @ q)
        H0 = Hf(q, pi)
        Ts = {s: M1 @ Q[s] for s in (1, -1)}
        nrm = {s: np.sum(np.abs(Ts[s][self.perto])**2) for s in (1, -1)}

        def fluxoB(q, pi, tau):
            yq, tq, yp, tp = q.copy(), q.copy(), pi.copy(), pi.copy()
            for kk in range(1, 4):
                tq = -tau * sol(G @ tq) / kk
                yq += tq
                tp = tau * (GT @ sol(tp)) / kk
                yp += tp
            return yq, yp
        ns = int(round(T / dt))
        ts, cs = [], {1: [], -1: []}
        rho = np.zeros(self.C.T); S = np.zeros((self.C.T, 3)); nmed = 0
        q, pi = fluxoB(q, pi, 0.5 * dt)
        for it in range(ns + 1):
            if it % 10 == 0:
                ts.append(it * dt)
                for s in (1, -1):
                    cs[s].append(np.vdot(Ts[s][self.perto], pi[self.perto]) / nrm[s])
                if coletar and it * dt > 5:
                    qq, pp = fluxoB(q, pi, -0.5 * dt)
                    vv = sol(pp - G @ qq)
                    E, B = self.campos(qq, vv)
                    rho += 0.5 * (self.n_t * np.sum(E * E, 1) + np.sum(B * B, 1) / self.n_t)
                    S += np.cross(E, B)
                    nmed += 1
            pi -= 0.5 * dt * (K @ q)
            q += dt * sol(pi)
            pi -= 0.5 * dt * (K @ q)
            q, pi = fluxoB(q, pi, dt if it < ns else 0.5 * dt)
        ts = np.array(ts)
        sel = ts > 5
        w, amp = {}, {}
        for s in (1, -1):
            c = np.array(cs[s])
            ph = np.unwrap(np.angle(c))
            w[s] = -np.polyfit(ts[sel], ph[sel], 1)[0]
            amp[s] = float(np.mean(np.abs(c[sel])))
        out = {"omega": w, "amp": amp,
               "gauss": float(np.linalg.norm(self.d0.T @ pi - gauss0) / np.linalg.norm(pi)),
               "energia": float((Hf(q, pi) - H0) / H0)}
        if pol == 0:                                    # rotação da polarização linear: ½ d(φ₋ − φ₊)/dt
            dphi = np.unwrap(np.angle(np.array(cs[-1]))) - np.unwrap(np.angle(np.array(cs[1])))
            out["rotacao_rad_por_tempo"] = float(0.5 * np.polyfit(ts[sel], dphi[sel], 1)[0])
        if coletar:
            out["rho"], out["S"] = rho / nmed, S / nmed
        return out


def u_vortices(cen, quiral, Om0=0.05, s=0.9, d=1.3):
    """Microvórtices de arrasto: quiral = lista de χ_j para centros em (±d, 0)."""
    u = np.zeros_like(cen)
    centros = [(-d, 0.0), (d, 0.0)]
    for chi, (cx, cy) in zip(quiral, centros):
        rx, ry = cen[:, 0] - cx, cen[:, 1] - cy
        f = chi * Om0 * np.exp(-(rx**2 + ry**2) / (2 * s * s))
        u[:, 0] += -f * ry
        u[:, 1] += f * rx
    return u


# ---------------------------------------------------------------------- backreaction
def backreaction(guia, rho, S, Gn, ngrade=48):
    """δg do tensor de energia-momento do modo, em gravidade linearizada: ∇²Φ_γ = 4πG ρ, ∇²u_δ = −16πG S (fontes
    depositadas numa grade auxiliar com folga em x, y e periódica em z; FFT). Devolve Φ_γ e u_δ no centro de cada
    tetraedro. A média das fontes é retirada (a caixa auxiliar é periódica): só gradientes e circulações contam."""
    R, Lz = guia.R, guia.Lz
    Lxy = 4 * R
    nz = max(8, int(ngrade * Lz / Lxy))
    hx, hz = Lxy / ngrade, Lz / nz
    x = guia.cen[:, 0] + Lxy / 2
    y = guia.cen[:, 1] + Lxy / 2
    z = guia.cen[:, 2] % Lz
    V = guia.C.vol
    ix, iy, iz = (x / hx).astype(int) % ngrade, (y / hx).astype(int) % ngrade, (z / hz).astype(int) % nz
    cel = hx * hx * hz

    def deposita(f):
        g = np.zeros((ngrade, ngrade, nz))
        np.add.at(g, (ix, iy, iz), f * V / cel)
        return g
    kx = 2 * np.pi * np.fft.fftfreq(ngrade, hx)
    kz = 2 * np.pi * np.fft.fftfreq(nz, hz)
    KX, KY, KZ = np.meshgrid(kx, kx, kz, indexing="ij")
    k2 = KX**2 + KY**2 + KZ**2
    k2[0, 0, 0] = 1.0

    def poisson(src):                                   # ∇²f = src
        F = np.fft.fftn(src - src.mean())
        F = -F / k2
        F[0, 0, 0] = 0
        return np.real(np.fft.ifftn(F))
    Phi = poisson(4 * np.pi * Gn * deposita(rho))[ix, iy, iz]
    u = np.stack([poisson(-16 * np.pi * Gn * deposita(S[:, c]))[ix, iy, iz] for c in range(3)], 1)
    return Phi, u


def norma_dg(Phi, u):
    """‖δg‖ de Frobenius por tetraedro: δg_00 = δg_ii = −2Φ, δg_0i = −u_i."""
    return np.sqrt(16 * Phi**2 + 2 * np.sum(u * u, 1))


def giro_eixo(guia, u, rmax=1.5):
    """Velocidade angular média de um campo de arrasto perto do eixo: a parte quiral de δg_0i."""
    r2 = np.sum(guia.cen[:, :2]**2, 1)
    m = (r2 < rmax**2) & (r2 > 1e-6)
    w = (guia.cen[m, 0] * u[m, 1] - guia.cen[m, 1] * u[m, 0]) / r2[m]
    return float(np.sum(w * guia.C.vol[m]) / np.sum(guia.C.vol[m]))


# ---------------------------------------------------------------------- caixa periódica (ondas planas)
def poços_basais(X, m=0.3, s=0.5):
    """Parte estática de g⁽⁰⁾: rede 2 × 2 × 2 de poços (n = e^{−2Φ})."""
    L = CC.L
    n = np.zeros(X.shape[:-1])
    for c in np.array(np.meshgrid([0.25, 0.75], [0.25, 0.75], [0.25, 0.75], indexing="ij")).reshape(3, -1).T * L:
        d = X - c
        d -= L * np.round(d / L)
        n += m * np.exp(-np.sum(d * d, -1) / (2 * s * s))
    return np.exp(2 * n)


def p_sobre_e(C, K, M1, n_t, kvec, A):
    """Onda plana viajante: ω pela razão de Rayleigh; ⟨E×B⟩ e ⟨ρ⟩ médios no tempo com a interpolação de Whitney no
    centro de cada tetraedro; devolve |P| c / E e ω/ck."""
    Q = C.onda_aresta(kvec, A)
    w2 = (np.vdot(Q, K @ Q) / np.vdot(Q, M1 @ Q)).real
    w = math.sqrt(w2)
    g = C.grad
    wc = np.stack([0.25 * (g[:, j] - g[:, i]) for (i, j) in ARESTAS_LOC], 1)
    qa = Q[C.aresta_t]
    B = np.einsum("tei,te->ti", C.curl_local(), qa)
    E = 1j * w * np.einsum("tei,te->ti", wc, qa)              # E = −q̇ = iω Q
    V = C.vol
    P = 0.5 * np.real(np.cross(E, B.conj())) * V[:, None]
    U = 0.25 * (n_t * np.sum(np.abs(E)**2, 1) + np.sum(np.abs(B)**2, 1) / n_t) * V
    return float(np.linalg.norm(P.sum(0)) / U.sum()), w / np.linalg.norm(kvec)


def caixa(rng):
    ns = [(1, 0, 0), (0, 1, 1), (1, 1, 1), (2, 1, 0), (1, 2, 2), (2, -1, 1), (0, 0, 2)]
    res = {}
    for nome, nfun in (("plano", None), ("g⁽⁰⁾ estático (poços basais)", poços_basais)):
        C, M1, M2 = CC.montar(13, rng, n_fun=nfun)
        n_t = np.ones(C.T) if nfun is None else nfun(C.Xt.mean(1) % CC.L)
        K = (C.d1.T @ M2 @ C.d1).tocsr()
        r = CC.espectro_ondas(C, K, M1, ns)
        wT = np.array([np.sort(w2)[1:] for _, w2, _ in r])
        w0 = np.array([np.sort(w2)[0] for _, w2, _ in r])
        lonT = max(float(np.array(lon)[np.argsort(w2)][1:].max()) for _, w2, lon in r)
        phi = rng.normal(size=C.N)
        pe = [p_sobre_e(C, K, M1, n_t, 2 * math.pi / CC.L * np.array(n_, float), A)
              for n_, A in (((0, 0, 1), np.array([1, -1j, 0])), ((0, 0, 1), np.array([1, 1j, 0])), ((0, 0, 1), np.array([1.0, 0, 0])))]
        d1r = CC.d1_aleatorio(C, rng)
        Kr = (d1r.T @ M2 @ d1r).tocsr()
        r7 = CC.espectro_ondas(C, Kr, M1, ns)
        res[nome] = {"GMFs": C.N,
                     "omega/ck dos 2 transversais (média, desvio)": [sig(float(np.sqrt(wT).mean()), 4), sig(float(np.sqrt(wT).std()), 3)],
                     "maior |k̂·q| dos transversais": sig(lonT, 3),
                     "omega² do 3º modo / (ck)²": zero_ou(float(w0.max())),
                     "|K∇φ|/|Kq| (gauge)": zero_ou(float(np.linalg.norm(K @ (C.d0 @ phi)) / np.linalg.norm(K @ rng.normal(size=C.E)))),
                     "|P|c/E para h = +1, h = −1, linear (k ao longo de z)": [sig(x[0], 4) for x in pe],
                     "C7 loops desligados (orientação embaralhada): omega² do 3º modo / (ck)²": sig(float(max(np.sort(w2)[0] for _, w2, _ in r7)), 3),
                     "C7: |K∇φ|/|Kq|": sig(float(np.linalg.norm(Kr @ (C.d0 @ phi)) / np.linalg.norm(Kr @ rng.normal(size=C.E))), 3)}
    return res


# ---------------------------------------------------------------------- guia: fundo, helicidade, backreaction
def guia_testes(rng, Gn=1e-5, Gn_medio=1e-3, Gn_forte=3e-2):
    g = Guia(rng)
    res = {"GMFs": g.C.N, "ligacoes_livres": len(g.I), "dt": sig(g.dt, 3)}
    fundos = {"C6 compensado (χ = +1, −1)": (1, -1), "C4 só χ = +1": (1, 1), "C5 só χ = −1": (-1, -1)}
    U = {nome: u_vortices(g.cen, q) for nome, q in fundos.items()}
    res["norma de g⁽⁰⁾ − η (máx |u⁽⁰⁾|·√2)"] = sig(float(np.sqrt(2) * np.linalg.norm(U["C6 compensado (χ = +1, −1)"], axis=1).max()), 3)
    phi = rng.normal(size=g.d0.shape[1])
    res["|G∇φ|/|Gq| no fundo compensado"] = zero_ou(float(np.linalg.norm(g.matriz_G(U["C6 compensado (χ = +1, −1)"]) @ (g.d0 @ phi)) /
                                                          np.linalg.norm(g.matriz_G(U["C6 compensado (χ = +1, −1)"]) @ rng.normal(size=len(g.I)))))
    base = {}
    for nome, u in U.items():
        r = {s: g.rodar(u, s, coletar=(nome.startswith("C6"))) for s in (1, -1)}
        base[nome] = r
        res[nome] = {"omega(h = +1), omega(h = −1)": [sig(r[1]["omega"][1], 6), sig(r[-1]["omega"][-1], 6)],
                     "omega(+1) − omega(−1)": sig(r[1]["omega"][1] - r[-1]["omega"][-1], 3),
                     "lei de Gauss |∇·π(t) − ∇·π(0)|/|π|": zero_ou(max(r[1]["gauss"], r[-1]["gauss"]))}
    r0 = {s: g.rodar(np.zeros_like(g.cen), s) for s in (1, -1)}
    res["fundo plano (sem vórtices): omega(+1) − omega(−1)"] = sig(r0[1]["omega"][1] - r0[-1]["omega"][-1], 3)
    uc = U["C6 compensado (χ = +1, −1)"]
    # C3 polarização linear no fundo compensado
    rl = g.rodar(uc, 0, coletar=True)
    res["C3 linear: rotação da polarização (rad por unidade de tempo)"] = sig(rl["rotacao_rad_por_tempo"], 3)
    # backreaction: δg[h] e repropagação
    br = {}
    fontes = {1: base["C6 compensado (χ = +1, −1)"][1], -1: base["C6 compensado (χ = +1, −1)"][-1], 0: rl}
    for Gx, rotulo in ((Gn, "fraca"), (Gn_medio, "intermediária"), (Gn_forte, "C8 forte")):
        lin = {}
        for s, rr in fontes.items():
            Phi, ud = backreaction(g, rr["rho"], rr["S"], Gx)
            eta = float(norma_dg(Phi, ud).max() / 2.0)
            lin[s] = (Phi, ud, eta, giro_eixo(g, ud))
        rep = {}
        for s in (1, -1):
            Phi, ud, eta, _ = lin[s]
            g.matrizes(np.exp(-2 * Phi))
            rr = g.rodar(uc + ud, s)
            g.matrizes(np.ones(g.C.T))
            w0 = base["C6 compensado (χ = +1, −1)"][s]["omega"][s]
            rep[s] = {"Δω": rr["omega"][s] - w0, "mistura": rr["amp"][-s] / rr["amp"][s], "gauss": rr["gauss"]}
        br[rotulo] = {
            "G": Gx,
            "η_g = ‖δg‖/‖g⁽⁰⁾‖ (h = +1, −1, linear)": [sig(lin[s][2], 3) for s in (1, -1, 0)],
            "giro de δg perto do eixo, Ω_δ (h = +1, −1, linear)": [sig(lin[s][3], 3) for s in (1, -1, 0)],
            "repropagação: Δω (h = +1, −1)": [sig(rep[s]["Δω"], 3) for s in (1, -1)],
            "repropagação: Δω relativo (h = +1, −1)": [sig(rep[s]["Δω"] / base["C6 compensado (χ = +1, −1)"][s]["omega"][s], 3) for s in (1, -1)],
            "repropagação: mistura de helicidades |c_−h|/|c_h|": [sig(rep[s]["mistura"], 3) for s in (1, -1)],
            "repropagação: lei de Gauss": zero_ou(max(rep[s]["gauss"] for s in (1, -1)))}
    res["backreaction"] = br
    res["mistura de helicidades sem backreaction (h = +1, −1)"] = [
        sig(base["C6 compensado (χ = +1, −1)"][s]["amp"][-s] / base["C6 compensado (χ = +1, −1)"][s]["amp"][s], 3) for s in (1, -1)]
    return res



def velocidade_grupo(rng):
    """v_g no fundo compensado, num guia mais longo (L_z = 8): ω em k = 2π/8 e 3·2π/8, diferença central em k = 2π·2/8."""
    g = Guia(rng, Lz=8.0)
    uc = u_vortices(g.cen, (1, -1))
    dk = 2 * math.pi / g.Lz
    w = {(s, kn): g.rodar(uc, s, k_n=kn, T=30.0)["omega"][s] for s in (1, -1) for kn in (1, 3)}
    vg = {s: (w[(s, 3)] - w[(s, 1)]) / (2 * dk) for s in (1, -1)}
    kc = 1.8412 / g.R
    k = 2 * dk
    return {"GMFs": g.C.N, "k": sig(k, 4),
            "omega(k = 2π/8): h = +1, −1": [sig(w[(1, 1)], 5), sig(w[(-1, 1)], 5)],
            "omega(k = 3·2π/8): h = +1, −1": [sig(w[(1, 3)], 5), sig(w[(-1, 3)], 5)],
            "v_g(h = +1), v_g(h = −1)": [sig(vg[1], 4), sig(vg[-1], 4)],
            "v_g do guia contínuo, k/√(k_c² + k²)": sig(k / math.sqrt(kc * kc + k * k), 4)}


# ---------------------------------------------------------------------- figura e principal
def figura(rg, pasta):
    fig, axs = plt.subplots(1, 3, figsize=(16, 4.6))
    ax = axs[0]
    nomes = ["fundo plano (sem vórtices): omega(+1) − omega(−1)", "C6 compensado (χ = +1, −1)", "C4 só χ = +1", "C5 só χ = −1"]
    vals = [rg[nomes[0]]] + [rg[n]["omega(+1) − omega(−1)"] for n in nomes[1:]]
    cores = ["#7a7a74", "#2a78d6", "#c9582b", "#2f9e6e"]
    ax.bar(range(4), vals, color=cores)
    ax.axhline(0, color="#1b1b19", linewidth=0.6)
    ax.set_xticks(range(4)); ax.set_xticklabels(["plano", "compensado\nχ = ±1", "só χ = +1", "só χ = −1"])
    ax.set_ylabel("ω(h = +1) − ω(h = −1)")
    ax.set_title("Fundo basal: o compensado não escolhe helicidade", fontsize=10)
    ax = axs[1]
    br = rg["backreaction"]
    Gs = [br[k]["G"] for k in ("fraca", "intermediária", "C8 forte")]
    eta = [br[k]["η_g = ‖δg‖/‖g⁽⁰⁾‖ (h = +1, −1, linear)"][0] for k in ("fraca", "intermediária", "C8 forte")]
    dw = [abs(br[k]["repropagação: Δω relativo (h = +1, −1)"][0]) for k in ("fraca", "intermediária", "C8 forte")]
    ax.loglog(Gs, eta, "o-", color="#2a78d6", linewidth=2, label="η_g = ‖δg‖/‖g⁽⁰⁾‖")
    ax.loglog(Gs, dw, "s-", color="#c9582b", linewidth=2, label="|Δω/ω| na repropagação")
    ax.axhline(1, color="#1b1b19", linewidth=0.6, linestyle=":")
    ax.set_xlabel("acoplamento G da backreaction")
    ax.set_title("Backreaction: perturbativa com G pequeno;\nC8 (G grande) destrói o setor", fontsize=10)
    ax.legend(fontsize=8, frameon=False)
    ax = axs[2]
    om = br["fraca"]["giro de δg perto do eixo, Ω_δ (h = +1, −1, linear)"]
    ax.bar(range(3), om, color=["#2a78d6", "#c9582b", "#7a7a74"])
    ax.axhline(0, color="#1b1b19", linewidth=0.6)
    ax.set_xticks(range(3)); ax.set_xticklabels(["h = +1", "h = −1", "linear"])
    ax.set_ylabel("Ω_δ (giro de δg no eixo)")
    ax.set_title("Parte quiral de δg[h]: troca de sinal com h", fontsize=10)
    for a in axs:
        for lado in ("top", "right"):
            a.spines[lado].set_visible(False)
    fig.tight_layout()
    fig.savefig(pasta / "c5a_g0g_backreaction.png", dpi=150)
    plt.close(fig)


def main():
    saida = Path(sys.argv[1] if len(sys.argv) > 1 else "c5a_g0g_backreaction.json")
    pasta = saida.resolve().parent
    pasta.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEMENTE)
    rc = caixa(rng)
    rg = guia_testes(rng)
    rv = velocidade_grupo(rng)
    c6 = rg["C6 compensado (χ = +1, −1)"]["omega(+1) − omega(−1)"]
    c4 = rg["C4 só χ = +1"]["omega(+1) − omega(−1)"]
    c5 = rg["C5 só χ = −1"]["omega(+1) − omega(−1)"]
    pl = rc["plano"]
    bf = rg["backreaction"]["fraca"]
    b8 = rg["backreaction"]["C8 forte"]
    ok = {}
    ok["1_compensado_degenerado_e_quiralidades_opostas"] = abs(c6) < 0.15 * abs(c4) and c4 * c5 < 0 and \
        abs(rv["v_g(h = +1), v_g(h = −1)"][0] - rv["v_g(h = +1), v_g(h = −1)"][1]) < 0.02
    ok["2_curl_curl_gauge_e_duas_polarizacoes"] = (eh_zero(pl["omega² do 3º modo / (ck)²"]) and eh_zero(pl["|K∇φ|/|Kq| (gauge)"])
                                                   and pl["maior |k̂·q| dos transversais"] < 0.1 and
                                                   eh_zero(rg["|G∇φ|/|Gq| no fundo compensado"]))
    ok["3_omega_ck_e_P_E_c"] = abs(pl["omega/ck dos 2 transversais (média, desvio)"][0] - 1) < 0.02 and \
        all(abs(x - 1) < 0.02 for x in pl["|P|c/E para h = +1, h = −1, linear (k ao longo de z)"])
    ok["4_backreaction_pequena_e_quiral"] = (max(bf["η_g = ‖δg‖/‖g⁽⁰⁾‖ (h = +1, −1, linear)"]) < 0.01 and
                                             bf["giro de δg perto do eixo, Ω_δ (h = +1, −1, linear)"][0] *
                                             bf["giro de δg perto do eixo, Ω_δ (h = +1, −1, linear)"][1] < 0 and
                                             abs(bf["giro de δg perto do eixo, Ω_δ (h = +1, −1, linear)"][2]) <
                                             0.1 * abs(bf["giro de δg perto do eixo, Ω_δ (h = +1, −1, linear)"][0]))
    dw = bf["repropagação: Δω (h = +1, −1)"]
    ok["5_repropagacao_sem_birrefringencia_e_gauge"] = (max(abs(x) for x in bf["repropagação: Δω relativo (h = +1, −1)"]) < 0.01
                                                        and abs(dw[0] - dw[1]) < 0.1 * abs(c4) and eh_zero(bf["repropagação: lei de Gauss"])
                                                        and all(abs(a - b) < 0.01 for a, b in zip(bf["repropagação: mistura de helicidades |c_−h|/|c_h|"],
                                                                                                  rg["mistura de helicidades sem backreaction (h = +1, −1)"])))
    ok["6_C8_acoplamento_forte_destroi"] = (min(b8["η_g = ‖δg‖/‖g⁽⁰⁾‖ (h = +1, −1, linear)"][:2]) > 1 and
                                            max(abs(x) for x in b8["repropagação: Δω relativo (h = +1, −1)"]) > 0.3)
    ok["7_C7_sem_loops_perde_o_gauge"] = (not eh_zero(pl["C7 loops desligados (orientação embaralhada): omega² do 3º modo / (ck)²"])
                                          and pl["C7: |K∇φ|/|Kq|"] > 0.1)
    out = {"parametros": {"semente": SEMENTE, "Omega0_vortices": 0.05, "G_fraco": 1e-5, "G_intermediario": 1e-3, "G_forte": 3e-2},
           "caixa_periodica": rc, "guia": rg, "velocidade_de_grupo": rv,
           "criterios": {k: bool(v) for k, v in ok.items()}}
    out["todos_passaram"] = bool(all(ok.values()))
    for k, v in ok.items():
        print(k, "PASSOU" if v else "FALHOU")
    with saida.open("w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    figura(rg, pasta)
    print("GLOBAL:", "TODOS PASSARAM" if out["todos_passaram"] else "HA FALHAS")
    return 0 if out["todos_passaram"] else 1


if __name__ == "__main__":
    sys.exit(main())
