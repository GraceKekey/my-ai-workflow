# -*- coding: utf-8 -*-
"""Tapete 3D de GMFs (posições aleatórias, sem grade), loops a partir da triangulação de Delaunay periódica, e as
matrizes das formas de Whitney. Nenhum curl contínuo entra aqui: só a topologia (quem é vizinho de quem, com qual
orientação) e a geometria (comprimentos, áreas, volumes)."""
from __future__ import annotations

import itertools
import math

import numpy as np
import scipy.sparse as sp
from scipy.spatial import Delaunay

ARESTAS_LOC = [(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)]
FACES_LOC = [(0, 1, 2), (0, 1, 3), (0, 2, 3), (1, 2, 3)]


def pontos_tapete(n, L, rng, tremor=0.35):
    """GMFs: um ponto por célula de uma grade n×n×n, sorteado com deslocamento aleatório de até ±tremor·h em cada
    direção. A grade só fixa a densidade média; as posições são aleatórias."""
    n = np.broadcast_to(np.asarray(n), (3,))
    L = np.broadcast_to(np.asarray(L, float), (3,))
    h = L / n
    g = np.stack(np.meshgrid(*[np.arange(k) for k in n], indexing="ij"), -1).reshape(-1, 3)
    return ((g + 0.5 + rng.uniform(-tremor, tremor, size=g.shape)) * h) % L


class Complexo:
    """Complexo periódico: nós (GMFs), arestas (ligações), faces (loops), tetraedros. Orientação: cada aresta e cada face
    seguem a ordem crescente dos índices dos GMFs (orientação consistente)."""

    def __init__(self, P, L, margem=None, periodico=(True, True, True), parede=None):
        self.P = P
        self.L = L = np.broadcast_to(np.asarray(L, float), (3,)).copy()
        per = np.array(periodico)
        N = len(P)
        h = (np.prod(L) / N) ** (1 / 3)
        m = 3 * h if margem is None else margem
        Xs, orig, desl = [], [], []
        for s in itertools.product(*[(-1, 0, 1) if p_ else (0,) for p_ in per]):
            s = np.array(s)
            X = P + s * L
            ok = np.all(((X > -m) & (X < L + m)) | ~per, axis=1)
            Xs.append(X[ok]); orig.append(np.nonzero(ok)[0]); desl.append(np.repeat(s[None], ok.sum(), 0))
        X = np.concatenate(Xs); orig = np.concatenate(orig); desl = np.concatenate(desl)
        tri = Delaunay(X)
        S = tri.simplices
        cen = X[S].mean(1)
        S = S[np.all(((cen >= 0) & (cen < L)) | ~per, axis=1)]
        if parede is not None:                           # lascas fora do volume: tetraedros só com GMFs da parede
            S = S[~np.all(parede[orig[S]], axis=1)]
        # ordena os vértices de cada tetraedro pelo índice do GMF (orientação canônica)
        o = orig[S]
        ordem = np.argsort(o, axis=1)
        S = np.take_along_axis(S, ordem, 1)
        o = orig[S]
        if np.any(np.diff(o, axis=1) == 0):
            raise RuntimeError("tetraedro com dois vértices do mesmo GMF: caixa pequena demais")
        self.Xt = X[S]                                   # (T, 4, 3) coordenadas absolutas
        self.ot = o
        sd = desl[S]
        T = len(S)
        # arestas: chave (a, b, deslocamento relativo)
        ch = []
        for (a, b) in ARESTAS_LOC:
            ch.append(np.concatenate([o[:, [a, b]], sd[:, b] - sd[:, a]], 1))
        ch = np.stack(ch, 1).reshape(-1, 5)
        ua, inv = np.unique(ch, axis=0, return_inverse=True)
        self.aresta_t = inv.reshape(T, 6)
        self.arestas = ua
        E = len(ua)
        chf = []
        for (a, b, c) in FACES_LOC:
            chf.append(np.concatenate([o[:, [a, b, c]], sd[:, b] - sd[:, a], sd[:, c] - sd[:, a]], 1))
        chf = np.stack(chf, 1).reshape(-1, 9)
        uf, invf = np.unique(chf, axis=0, return_inverse=True)
        self.face_t = invf.reshape(T, 4)
        F = len(uf)
        self.N, self.E, self.F, self.T = N, E, F, T
        # vetor de cada aresta (do GMF a ao GMF b, já com o deslocamento periódico)
        self.vet_aresta = P[ua[:, 1]] - P[ua[:, 0]] + ua[:, 2:5] * L
        # d0: arestas × nós; d1: faces × arestas (borda de [a,b,c] = [b,c] − [a,c] + [a,b])
        self.d0 = sp.csr_matrix((np.r_[-np.ones(E), np.ones(E)], (np.r_[np.arange(E), np.arange(E)],
                                 np.r_[ua[:, 0], ua[:, 1]])), shape=(E, N))
        idx = {e: k for k, e in enumerate(ARESTAS_LOC)}
        linhas, cols, vals = [], [], []
        for fl, (a, b, c) in enumerate(FACES_LOC):
            for (p, q), s in (((b, c), 1.0), ((a, c), -1.0), ((a, b), 1.0)):
                linhas.append(self.face_t[:, fl]); cols.append(self.aresta_t[:, idx[(p, q)]]); vals.append(np.full(T, s))
        d1 = sp.coo_matrix((np.concatenate(vals), (np.concatenate(linhas), np.concatenate(cols))), shape=(F, E)).tocsr()
        d1.data = np.sign(d1.data)                       # faces repetidas em tetraedros vizinhos somam: volta a ±1
        self.d1 = d1
        # gradientes baricêntricos e volumes
        J = self.Xt[:, 1:] - self.Xt[:, :1]
        Ji = np.linalg.inv(J)
        g = np.empty((T, 4, 3))
        g[:, 1:] = np.transpose(Ji, (0, 2, 1))
        g[:, 0] = -g[:, 1:].sum(1)
        self.grad = g
        self.vol = np.abs(np.linalg.det(J)) / 6

    # -------------------------------------------------------------- Whitney
    def matrizes(self, eps_t=None, inv_mu_t=None):
        """M1 (energia cinética, ∫ε q̇²), M2 (acoplamento entre loops, ∫B²/μ) e K = d1ᵀ M2 d1, montadas tetraedro a
        tetraedro. ε e 1/μ constantes por tetraedro (a microgeometria entra aqui)."""
        T, V, g = self.T, self.vol, self.grad
        eps_t = np.ones(T) if eps_t is None else eps_t
        imu = np.ones(T) if inv_mu_t is None else inv_mu_t
        G = np.einsum("tai,tbi->tab", g, g)
        Ml = (np.ones((4, 4)) + np.eye(4))[None] * (V / 20)[:, None, None]
        M1l = np.empty((T, 6, 6))
        for e, (i, j) in enumerate(ARESTAS_LOC):
            for f, (k, l) in enumerate(ARESTAS_LOC):
                M1l[:, e, f] = (Ml[:, i, k] * G[:, j, l] - Ml[:, i, l] * G[:, j, k]
                                - Ml[:, j, k] * G[:, i, l] + Ml[:, j, l] * G[:, i, k])
        M1l *= eps_t[:, None, None]
        # forma de Whitney de face (i,j,k): 2(λi ∇λj×∇λk + λj ∇λk×∇λi + λk ∇λi×∇λj)
        c = np.zeros((T, 4, 4, 3))
        for f, (i, j, k) in enumerate(FACES_LOC):
            c[:, f, i] = 2 * np.cross(g[:, j], g[:, k])
            c[:, f, j] = 2 * np.cross(g[:, k], g[:, i])
            c[:, f, k] = 2 * np.cross(g[:, i], g[:, j])
        M2l = np.einsum("tab,tfai,tgbi->tfg", Ml, c, c) * imu[:, None, None]
        M1 = self._monta(M1l, self.aresta_t, self.E)
        M2 = self._monta(M2l, self.face_t, self.F)
        return M1, M2

    def curl_local(self):
        """curl da forma de Whitney de cada aresta local (constante no tetraedro): 2∇λi×∇λj."""
        g = self.grad
        return np.stack([2 * np.cross(g[:, i], g[:, j]) for (i, j) in ARESTAS_LOC], 1)

    @staticmethod
    def _monta(loc, ids, n):
        T, m, _ = loc.shape
        r = np.repeat(ids, m, axis=1).reshape(T, m, m)
        c = np.tile(ids, (1, m)).reshape(T, m, m)
        return sp.coo_matrix((loc.ravel(), (r.ravel(), c.ravel())), shape=(n, n)).tocsr()

    # -------------------------------------------------------------- campos contínuos → GMFs (sem aproximação)
    def onda_aresta(self, k, A):
        """Circulação exata de A e^{ik·x} ao longo de cada ligação (mapa de de Rham)."""
        d = self.vet_aresta
        xa = self.P[self.arestas[:, 0]]
        th = d @ k
        f = np.where(np.abs(th) < 1e-12, 1.0 + 0j, (np.exp(1j * th) - 1) / (1j * np.where(th == 0, 1, th)))
        return (d @ A) * np.exp(1j * (xa @ k)) * f

    def onda_no(self, k):
        return np.exp(1j * (self.P @ k))
