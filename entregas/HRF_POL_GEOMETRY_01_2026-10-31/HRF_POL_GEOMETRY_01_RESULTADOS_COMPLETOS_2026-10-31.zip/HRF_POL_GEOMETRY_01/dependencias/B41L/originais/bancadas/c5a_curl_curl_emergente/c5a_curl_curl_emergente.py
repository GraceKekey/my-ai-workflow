#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C5A — Teste do curl-curl emergente (energia de loops orientados no tapete de GMFs)
==================================================================================

Pergunta (prompt do usuário, docs/C5A_prompt_curl_curl_emergente.md): uma energia que só soma circulações em pequenos
loops de GMFs, E = (κ/2) Σ_f C_f², C_f = Σ_{e∈∂f} s_e q_e, sem nenhum curl contínuo, dá no limite contínuo o operador
∇×∇×, com exatamente 2 modos transversais propagantes e o gradiente como grau de gauge?

Tapete 3D (como c5a_tapete_gmf, agora em 3D): GMFs em posições aleatórias (um por célula, deslocamento aleatório de até
±0,35 do espaçamento), caixa periódica. Os loops são os triângulos da triangulação de Delaunay dos GMFs; a variável q_e
mora em cada ligação (a "seta" entre dois GMFs vizinhos). Variantes da energia de loops:
  C2  loops com acoplamento geométrico: E = ½ Cᵀ M2 C, com M2 das formas de Whitney (pesos entre loops vizinhos vindos
      dos comprimentos, áreas e volumes do tapete; o mesmo papel do acoplamento geodésico de c5a_tapete_gmf);
  C2u loops com peso uniforme, a fórmula literal E = (κ/2) Σ C_f²;
  C3  loops com orientação aleatória (sinal aleatório em cada par loop–ligação);
  C0  pares isotrópicos (q vetorial em cada GMF, kernel geodésico); C1 pares perpendiculares; C1c pares centrais;
  C4  fundo plano (C2 acima); C5 microgeometria curva (poço fundo, n = e^{−2Φ}); C6 microgeometria girante (arrasto).
Equações de movimento: M q̈ = −∂E/∂q (M = matriz de massa das ligações). Nada de projeção transversal.

Uso: python c5a_curl_curl_emergente.py [saida.json]
"""
from __future__ import annotations

import json
import math
import sys
import time
from pathlib import Path

import numpy as np
import scipy.linalg as sl
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.spatial import cKDTree

sys.path.insert(0, str(Path(__file__).resolve().parent))
from malha import Complexo, pontos_tapete   # noqa: E402

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt   # noqa: E402
import matplotlib.ticker   # noqa: E402

L = 4.0
SEMENTE = 20261001


def sig(x, n=4):
    return float(f"{x:.{n}g}")


ZERO = "zero (< 1e-10)"


def zero_ou(x, n=3, tol=1e-10):
    """Valores no nível do arredondamento da máquina mudam de uma máquina para outra: guarda-se só que são zero."""
    return ZERO if abs(x) < tol else sig(x, n)


def eh_zero(x):
    return x == ZERO


# ---------------------------------------------------------------------- campos de teste
def base_ondas(ns):
    """Ondas planas de teste: para cada vetor inteiro n, k = 2πn/L e três polarizações (duas transversais, uma
    longitudinal)."""
    out = []
    for n in ns:
        k = 2 * math.pi / L * np.asarray(n, float)
        kh = k / np.linalg.norm(k)
        a = np.array([1.0, 0, 0]) if abs(kh[0]) < 0.9 else np.array([0, 1.0, 0])
        e1 = np.cross(kh, a); e1 /= np.linalg.norm(e1)
        e2 = np.cross(kh, e1)
        for pol, A in (("T1", e1), ("T2", e2), ("L", kh)):
            out.append((k, A, pol))
    return out


NS_TESTE = [(1, 0, 0), (0, 1, 1), (1, 1, 1), (2, 1, 0), (1, 2, 2), (3, 1, 1)]


def montar(nlado, rng, tremor=0.35, n_fun=None):
    P = pontos_tapete(nlado, L, rng, tremor)
    C = Complexo(P, L)
    if n_fun is None:
        M1, M2 = C.matrizes()
    else:
        nt = n_fun(C.Xt.mean(1) % L)
        M1, M2 = C.matrizes(eps_t=nt, inv_mu_t=1 / nt)
    return C, M1, M2


def d1_aleatorio(C, rng):
    d = C.d1.copy().tocoo()
    d.data = d.data * rng.choice([-1.0, 1.0], size=d.nnz)
    return d.tocsr()


# ---------------------------------------------------------------------- operador
def erro_operador(C, K, M, ondas, Msolve, B_ex=None, M_ex=None):
    """ε_cc fraco (forma bilinear contra ondas de teste) e ε_cc ponto a ponto (O[q] = M⁻¹Kq contra α Π(∇×∇×q))."""
    V = L**3
    Q = np.stack([C.onda_aresta(k, A) for k, A, _ in ondas], 1)
    Bh = Q.conj().T @ (K @ Q)
    Mh = Q.conj().T @ (M @ Q)
    if B_ex is None:
        m = len(ondas)
        B_ex = np.zeros((m, m), complex); M_ex = np.zeros((m, m), complex)
        for a, (ka, Aa, _) in enumerate(ondas):
            for b, (kb, Ab, _) in enumerate(ondas):
                if np.allclose(ka, kb):
                    B_ex[a, b] = V * np.cross(ka, Aa) @ np.cross(kb, Ab)
                    M_ex[a, b] = V * Aa @ Ab
    al = np.vdot(B_ex, Bh).real / np.vdot(B_ex, B_ex).real
    eps_fraco = np.linalg.norm(Bh - al * B_ex) / np.linalg.norm(Bh)
    be = np.vdot(M_ex, Mh).real / np.vdot(M_ex, M_ex).real
    eps_massa = np.linalg.norm(Mh - be * M_ex) / np.linalg.norm(Mh)
    # ponto a ponto, só nas ondas com parte transversal (∇×∇×q = k² q_T)
    num = den = 0.0
    Oq_all, cc_all = [], []
    for (k, A, pol), q in zip(ondas, Q.T):
        Oq = Msolve(K @ q)
        cc = C.onda_aresta(k, (k @ k) * (A - k * (k @ A) / (k @ k)))
        Oq_all.append(Oq); cc_all.append(cc)
    Oq_all = np.stack(Oq_all, 1); cc_all = np.stack(cc_all, 1)
    MO = M @ Oq_all
    alp = np.vdot(cc_all, MO).real / np.vdot(cc_all, M @ cc_all).real
    R = Oq_all - alp * cc_all
    eps_ponto = math.sqrt(np.vdot(R, M @ R).real / np.vdot(Oq_all, MO).real)
    return eps_fraco, eps_ponto, al, be, eps_massa


def espectro_ondas(C, K, M, ns):
    """Para cada k: os 3 autovalores do problema projetado nas ondas planas (Kk v = ω² Mk v), ω/ck e o conteúdo
    longitudinal |k̂·v| de cada autovetor."""
    res = []
    for n in ns:
        k = 2 * math.pi / L * np.asarray(n, float)
        Q = np.stack([C.onda_aresta(k, e) for e in np.eye(3)], 1)
        Kk = Q.conj().T @ (K @ Q); Mk = Q.conj().T @ (M @ Q)
        w2, v = sl.eigh((Kk + Kk.conj().T) / 2, (Mk + Mk.conj().T) / 2)
        kh = k / np.linalg.norm(k)
        lon = [abs(kh @ v[:, i]) / np.linalg.norm(v[:, i]) for i in range(3)]
        res.append((n, w2 / (k @ k), lon))
    return res


def autovalores_discretos(K, M, alvo, k):
    """Autovalores verdadeiros do tapete (sem projeção) perto de 'alvo' (shift-invert)."""
    w, _ = spl.eigsh(K.tocsc(), k=k, M=M.tocsc(), sigma=alvo, which="LM")
    return np.sort(w)


# ---------------------------------------------------------------------- pares (C0, C1)
def pares(C, tipo, eps_k):
    P = C.P
    arv = cKDTree(P, boxsize=L)
    pr = arv.query_pairs(6 * math.sqrt(eps_k), output_type="ndarray")
    d = P[pr[:, 1]] - P[pr[:, 0]]
    d -= L * np.round(d / L)
    r2 = np.sum(d * d, 1)
    w = np.exp(-r2 / (4 * eps_k))
    e = d / np.sqrt(r2)[:, None]
    return pr, d, w, e


def espectro_pares(C, tipo, eps_k, ns):
    pr, d, w, e = pares(C, tipo, eps_k)
    out = []
    for n in ns:
        k = 2 * math.pi / L * np.asarray(n, float)
        f = w * (2 - 2 * np.cos(d @ k))
        if tipo == "isotropico":
            Kk = np.eye(3) * f.sum()
        elif tipo == "perpendicular":
            Kk = np.eye(3) * f.sum() - np.einsum("p,pi,pj->ij", f, e, e)
        else:
            Kk = np.einsum("p,pi,pj->ij", f, e, e)
        w2, v = np.linalg.eigh(Kk)
        kh = k / np.linalg.norm(k)
        lon = [abs(kh @ v[:, i]) for i in range(3)]
        out.append((n, w2 / (k @ k), lon))
    # normaliza pela média dos dois transversais do primeiro k (c_T = 1)
    return out


# ---------------------------------------------------------------------- testes
def t_operador(rng):
    """Convergência de ε_cc com a densidade de GMFs, para C2, C2u e C3."""
    ondas = base_ondas(NS_TESTE)
    res = {}
    lados = (6, 9, 13, 18)
    tab = {"C2 loops geométricos": [], "C2u loops com peso uniforme": [], "C3 loops com orientação aleatória": []}
    for nl in lados:
        C, M1, M2 = montar(nl, rng)
        K = (C.d1.T @ M2 @ C.d1).tocsr()
        lu = spl.splu(M1.tocsc())
        Ku = (C.d1.T @ C.d1).tocsr()
        I = sp.identity(C.E, format="csr")
        d1r = d1_aleatorio(C, rng)
        Kr = (d1r.T @ M2 @ d1r).tocsr()
        for nome, KK, MM, solve in (("C2 loops geométricos", K, M1, lu.solve),
                                    ("C2u loops com peso uniforme", Ku, I, lambda x: x),
                                    ("C3 loops com orientação aleatória", Kr, M1, lu.solve)):
            ef, ep, al, be, em = erro_operador(C, KK, MM, ondas, lambda x: solve(np.ascontiguousarray(x.real)) + 1j * solve(np.ascontiguousarray(x.imag)))
            tab[nome].append({"GMFs": C.N, "ligacoes": C.E, "loops": C.F, "eps_cc_fraco": sig(ef, 3),
                              "eps_cc_ponto_a_ponto": sig(ep, 3), "alfa": sig(al, 4)})
    for nome, linhas in tab.items():
        res[nome] = linhas
    return res


def t_espectro(rng, nl=13):
    ns = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, 0, 1), (0, 1, 1), (1, 1, 1), (1, -1, 0), (2, 1, 0),
          (1, 2, 2), (3, 1, 1), (2, 2, 1), (3, 0, 0), (2, -1, 1)]
    C, M1, M2 = montar(nl, rng)
    K = (C.d1.T @ M2 @ C.d1).tocsr()
    Ku = (C.d1.T @ C.d1).tocsr()
    I = sp.identity(C.E, format="csr")
    d1r = d1_aleatorio(C, rng)
    Kr = (d1r.T @ M2 @ d1r).tocsr()
    res = {"GMFs": C.N}

    def resumo(lista, escala=None):
        wT = np.array([np.sort(w2)[1:] for _, w2, _ in lista])          # dois maiores
        w0 = np.array([np.sort(w2)[0] for _, w2, _ in lista])
        lonT = np.array([np.array(lon)[np.argsort(w2)][1:] for _, w2, lon in lista])
        lon0 = np.array([np.array(lon)[np.argsort(w2)][0] for _, w2, lon in lista])
        s = escala if escala is not None else float(np.mean(wT))
        return {"omega/ck dos 2 transversais (média, desvio)": [sig(math.sqrt(np.mean(wT) / s), 4),
                                                               sig(float(np.std(np.sqrt(wT / s))), 3)],
                "maior |k̂·q| dos 2 transversais": sig(float(lonT.max()), 3),
                "omega²/(ck)² do terceiro modo (máximo)": zero_ou(float((w0 / s).max())),
                "conteúdo longitudinal do terceiro modo (mínimo)": sig(float(lon0.min()), 4)}

    res["C2 loops geométricos"] = resumo(espectro_ondas(C, K, M1, ns))
    res["C2u loops com peso uniforme"] = resumo(espectro_ondas(C, Ku, I, ns))
    res["C3 loops com orientação aleatória"] = resumo(espectro_ondas(C, Kr, M1, ns))
    h = L / nl
    for tipo, nome in (("isotropico", "C0 pares isotrópicos"), ("perpendicular", "C1 pares perpendiculares"),
                       ("central", "C1c pares centrais")):
        lista = espectro_pares(C, tipo, (0.6 * h)**2, ns)
        # c_T: média dos modos de menor conteúdo longitudinal; o longitudinal: o de maior conteúdo
        rT, rL, lmax = [], [], []
        for n, w2, lon in lista:
            o = np.argsort(lon)
            rT += list(w2[o[:2]]); rL.append(w2[o[2]]); lmax.append(lon[o[2]])
        cT2 = float(np.mean(rT))
        res[nome] = {"modos propagantes por k": 3, "omega_L²/omega_T²": sig(float(np.mean(rL)) / cT2, 3),
                     "conteúdo longitudinal do modo L": sig(float(np.min(lmax)), 4)}
    # espectro verdadeiro do tapete (sem projeção): conchas |n|² = 1, 2, 3
    k1 = (2 * math.pi / L)**2
    conchas = {}
    for nome, KK in (("C2", K), ("C3", Kr)):
        lin = {}
        for s2, mult in ((1, 6), (2, 12), (3, 8)):
            w = autovalores_discretos(KK, M1, s2 * k1 * 1.0 + 0.0, 2 * mult + 10) / k1
            cnt = int(np.sum(np.abs(w - s2) < 0.15 * s2))
            lin[f"|n|² = {s2}"] = {"autovalores_perto (em (2π/L)²)": [sig(x, 4) for x in w],
                                   "contagem na janela ±15%": cnt, "esperado (2 polarizações)": 2 * mult}
        conchas[nome] = lin
    res["espectro verdadeiro do tapete (sem projeção)"] = conchas
    res["contagem de graus de liberdade (C2)"] = {"ligacoes": C.E, "gradientes (gauge) = GMFs − 1": C.N - 1,
                                                  "harmônicos do toro": 3,
                                                  "modos com ω > 0": C.E - (C.N - 1) - 3}
    return res


def t_gauge(rng, nl=13):
    C, M1, M2 = montar(nl, rng)
    K = (C.d1.T @ M2 @ C.d1).tocsr()
    Ku = (C.d1.T @ C.d1).tocsr()
    d1r = d1_aleatorio(C, rng)
    Kr = (d1r.T @ M2 @ d1r).tocsr()
    lu = spl.splu(M1.tocsc())
    phi = rng.normal(size=C.N)
    qg = C.d0 @ phi
    qr = rng.normal(size=C.E)
    res = {}
    for nome, KK, solve in (("C2 loops geométricos", K, lu.solve), ("C2u loops com peso uniforme", Ku, lambda x: x),
                            ("C3 loops com orientação aleatória", Kr, lu.solve)):
        qdd_g = -solve(KK @ qg)
        qdd_r = -solve(KK @ qr)
        Mq = (M1 @ qdd_r) if nome != "C2u loops com peso uniforme" else qdd_r
        div = C.d0.T @ Mq
        res[nome] = {"|q̈| / |q| para q = ∇φ (φ aleatório)": zero_ou(float(np.linalg.norm(qdd_g) / np.linalg.norm(qg) /
                                                                         (np.linalg.norm(qdd_r) / np.linalg.norm(qr)))),
                     "|∇·q̈| / |q̈| para q aleatório": zero_ou(float(np.linalg.norm(div) / np.linalg.norm(Mq)))}
    # evolução: q = ∇φ por 200 passos (leapfrog) continua parado
    q = qg.copy(); v = np.zeros_like(q)
    dt = 0.02
    a = -lu.solve(K @ q)
    for _ in range(200):
        v += 0.5 * dt * a; q += dt * v; a = -lu.solve(K @ q); v += 0.5 * dt * a
    res["C2: q = ∇φ evoluído por 200 passos, |q − q0|/|q0|"] = zero_ou(float(np.linalg.norm(q - qg) / np.linalg.norm(qg)))
    return res


def t_helicidade(rng):
    res = {}
    for nl in (9, 13, 18):
        C, M1, M2 = montar(nl, rng)
        K = (C.d1.T @ M2 @ C.d1).tocsr()
        lin = {}
        for n in ((0, 0, 1), (1, 2, 2)):
            k = 2 * math.pi / L * np.asarray(n, float)
            kh = k / np.linalg.norm(k)
            a = np.array([1.0, 0, 0]) if abs(kh[0]) < 0.9 else np.array([0, 1.0, 0])
            ex = np.cross(a, kh); ex /= np.linalg.norm(ex)
            ey = np.cross(kh, ex)
            w = {}
            for s in (1, -1):
                A = ex - 1j * s * ey                       # q_s = Re[(x̂ − i s ŷ) e^{i(kz − ωt)}]
                q = C.onda_aresta(k, A)
                w2 = (q.conj() @ (K @ q)).real / (q.conj() @ (M1 @ q)).real
                # curl discreto (fluxo nos loops) contra −s k vezes o fluxo de q nos loops (quadratura)
                fl_curl = C.d1 @ q
                fl_q = fluxo_faces(C, k, A)
                be = np.vdot(fl_q, fl_curl) / np.vdot(fl_q, fl_q)
                e_curl = np.linalg.norm(fl_curl - (-s * np.linalg.norm(k)) * fl_q) / np.linalg.norm(fl_curl)
                w[s] = (math.sqrt(w2) / np.linalg.norm(k), e_curl)
            lin[str(n)] = {"omega/ck s = +1": sig(w[1][0], 5), "omega/ck s = −1": sig(w[-1][0], 5),
                           "|omega+ − omega−| / omega": sig(abs(w[1][0] - w[-1][0]) / w[1][0], 3),
                           "erro de curl q_s = −s k q_s (s = +1, −1)": [sig(w[1][1], 3), sig(w[-1][1], 3)]}
        res[f"GMFs = {C.N}"] = lin
    return res


def fluxo_faces(C, k, A):
    """Fluxo de A e^{ik·x} através de cada loop (quadratura de 7 pontos no triângulo)."""
    # vértices de cada face a partir da primeira ocorrência em algum tetraedro
    from malha import FACES_LOC
    T = C.T
    F = C.F
    pos = np.zeros((F, 3, 3))
    vis = np.zeros(F, bool)
    for fl, (a, b, c) in enumerate(FACES_LOC):
        ids = C.face_t[:, fl]
        novo = ~vis[ids]
        pos[ids[novo]] = C.Xt[novo][:, [a, b, c]]
        vis[ids] = True
    x0, x1, x2 = pos[:, 0], pos[:, 1], pos[:, 2]
    nA = 0.5 * np.cross(x1 - x0, x2 - x0)                  # área × normal (orientação a→b→c)
    pts = [(1/3, 1/3, 1/3, 0.225)]
    a1, b1 = 0.0597158717, 0.4701420641
    a2, b2 = 0.7974269853, 0.1012865073
    for (p, q_) , wq in (((a1, b1), 0.1323941527), ((a2, b2), 0.1259391805)):
        pts += [(p, q_, q_, wq), (q_, p, q_, wq), (q_, q_, p, wq)]
    s = 0
    for l0, l1, l2, wq in pts:
        x = l0 * x0 + l1 * x1 + l2 * x2
        s = s + wq * np.exp(1j * (x @ k))
    return (nA @ A) * s


# ---------------------------------------------------------------------- C5: microgeometria curva
def n_poco(X, m=1.0, sig_=L / 7):
    d = X - L / 2
    d -= L * np.round(d / L)
    return np.exp(2 * m * np.exp(-np.sum(d * d, -1) / (2 * sig_**2)))


def t_curvo(rng):
    """Poço fundo (Φ = −1 no centro, n = e^{−2Φ} até e² = 7,4): a geometria entra só nos pesos (ε = μ = n). O operador
    contínuo esperado é ∇×(1/n)∇×, com massa n."""
    ondas = base_ondas(NS_TESTE)
    m = len(ondas)
    g = np.linspace(0, L, 64, endpoint=False)
    X = np.stack(np.meshgrid(g, g, g, indexing="ij"), -1)
    nn = n_poco(X)
    V = L**3
    B_ex = np.zeros((m, m), complex); M_ex = np.zeros((m, m), complex)
    for a, (ka, Aa, _) in enumerate(ondas):
        for b, (kb, Ab, _) in enumerate(ondas):
            fase = np.exp(1j * (X @ (kb - ka)))
            B_ex[a, b] = V * np.mean(fase / nn) * (np.cross(ka, Aa) @ np.cross(kb, Ab))
            M_ex[a, b] = V * np.mean(fase * nn) * (Aa @ Ab)
    res = {"Phi_no_fundo": -1.0, "n_maximo": sig(float(nn.max()), 3)}
    linhas = []
    for nl in (6, 9, 13, 18):
        C, M1, M2 = montar(nl, rng, n_fun=n_poco)
        K = (C.d1.T @ M2 @ C.d1).tocsr()
        Q = np.stack([C.onda_aresta(k, A) for k, A, _ in ondas], 1)
        Bh = Q.conj().T @ (K @ Q); Mh = Q.conj().T @ (M1 @ Q)
        al = np.vdot(B_ex, Bh).real / np.vdot(B_ex, B_ex).real
        e = np.linalg.norm(Bh - al * B_ex) / np.linalg.norm(Bh)
        em = np.linalg.norm(Mh - M_ex) / np.linalg.norm(Mh)
        # controle: mesma malha, pesos planos (ignorando a geometria)
        _, M2p = C.matrizes()
        Kp = C.d1.T @ M2p @ C.d1
        Bp = Q.conj().T @ (Kp @ Q)
        alp = np.vdot(B_ex, Bp).real / np.vdot(B_ex, B_ex).real
        ep = np.linalg.norm(Bp - alp * B_ex) / np.linalg.norm(Bp)
        phi = rng.normal(size=C.N)
        gauge = np.linalg.norm(K @ (C.d0 @ phi)) / np.linalg.norm(K @ rng.normal(size=C.E))
        linhas.append({"GMFs": C.N, "eps contra ∇×(1/n)∇× (fraco)": sig(e, 3), "alfa": sig(al, 4),
                       "eps da massa contra ∫n q·q": sig(em, 3),
                       "controle: pesos planos contra ∇×(1/n)∇×": sig(ep, 3),
                       "|K∇φ|/|Kq|": zero_ou(gauge)})
    res["convergência"] = linhas
    return res


# ---------------------------------------------------------------------- C6: microgeometria girante
def limite_wmax(C):
    """max_t λmax(K_t, M1_t): limite superior de ω²_max do tapete inteiro."""
    from malha import ARESTAS_LOC
    T, V, g = C.T, C.vol, C.grad
    G = np.einsum("tai,tbi->tab", g, g)
    Ml = (np.ones((4, 4)) + np.eye(4))[None] * (V / 20)[:, None, None]
    M1l = np.empty((T, 6, 6))
    for e, (i, j) in enumerate(ARESTAS_LOC):
        for f, (k, l) in enumerate(ARESTAS_LOC):
            M1l[:, e, f] = (Ml[:, i, k] * G[:, j, l] - Ml[:, i, l] * G[:, j, k]
                            - Ml[:, j, k] * G[:, i, l] + Ml[:, j, l] * G[:, i, k])
    cl = C.curl_local()
    Kl = np.einsum("tei,tfi->tef", cl, cl) * V[:, None, None]
    Li = np.linalg.cholesky(M1l)
    Lin = np.linalg.inv(Li)
    A = Lin @ Kl @ np.transpose(Lin, (0, 2, 1))
    return float(np.linalg.eigvalsh(A).max())


def t_girante(rng, Om0=0.05, R=3.0, Lz=4.0, h=0.5, T=40.0, omegas=None, espelho=False):
    """Guia de onda cilíndrico (raio R, paredes condutoras: q = 0 nas ligações da parede), periódico em z, com o
    espaço todo arrastado em rotação rígida, u = Ω ẑ×r (a métrica ds² = −dt² + (dx − u dt)², o miolo de um poço que
    gira; c5a_tapete_gmf T6) [H]. Na dinâmica dos loops: H = ½πᵀM⁻¹π + ½qᵀKq − πᵀM⁻¹Gq, G_ee' = ∫ w_e·((∇×w_e')×u)
    (o campo levado pelo arrasto, i_u dq). Lança-se o modo fundamental com as duas polarizações circulares s = ±1
    (momento angular m = −s) e mede-se a frequência em π (que não depende do gauge). Previsão exata para rotação
    rígida: ω_s = ω_0 + mΩ, isto é, ω(+1) − ω(−1) = −2Ω."""
    nxy = int(round(2 * R / h))
    nz = int(round(Lz / h))
    Pin = pontos_tapete(np.array([nxy, nxy, nz]), np.array([2 * R, 2 * R, Lz]), rng) - np.array([R, R, 0])
    Pin = Pin[np.hypot(Pin[:, 0], Pin[:, 1]) < R - 0.35 * h]
    nb = int(round(2 * math.pi * R / h))
    zs = (np.arange(nz) + 0.5) * Lz / nz
    ang = (np.arange(nb)[None, :] + 0.5 * (np.arange(nz)[:, None] % 2) + rng.uniform(-0.2, 0.2, (nz, nb))) * 2 * math.pi / nb
    Pb = np.stack([R * np.cos(ang).ravel(), R * np.sin(ang).ravel(), np.repeat(zs, nb)], 1)
    P = np.concatenate([Pin, Pb]) + np.array([R, R, 0])
    if espelho:                                          # orientação do espaço invertida (y → −y)
        P[:, 1] = 2 * R - P[:, 1]
    borda_no = np.r_[np.zeros(len(Pin), bool), np.ones(len(Pb), bool)]
    Ls = np.array([2 * R, 2 * R, Lz])
    C = Complexo(P, Ls, periodico=(False, False, True), parede=borda_no)
    M1, M2 = C.matrizes()
    K = (C.d1.T @ M2 @ C.d1).tocsr()
    # paredes condutoras: ligações entre dois GMFs da parede ficam fixas em zero
    dentro = ~(borda_no[C.arestas[:, 0]] & borda_no[C.arestas[:, 1]])
    I = np.nonzero(dentro)[0]
    M1 = M1[I][:, I].tocsc(); K = K[I][:, I].tocsr()
    lu = spl.splu(M1, permc_spec="MMD_AT_PLUS_A", options=dict(SymmetricMode=True))
    sol = lu.solve
    cen = C.Xt.mean(1)
    u = np.zeros((C.T, 3))
    u[:, 0] = -(cen[:, 1] - R)
    u[:, 1] = cen[:, 0] - R
    cl = C.curl_local()
    from malha import ARESTAS_LOC
    g = C.grad
    wint = np.stack([(g[:, j] - g[:, i]) * (C.vol / 4)[:, None] for (i, j) in ARESTAS_LOC], 1)   # ∫ w_e dV
    Gl = np.einsum("tei,tfi->tef", wint, np.cross(cl, u[:, None, :]))
    G1 = C._monta(Gl, C.aresta_t, C.E)[I][:, I].tocsr()                                          # para Ω = 1
    d0 = C.d0[I][:, np.nonzero(~borda_no)[0]]
    phi = rng.normal(size=d0.shape[1])
    res = {"GMFs": C.N, "ligacoes_livres": len(I), "raio": R, "Omega": Om0,
           "|K∇φ| / |Kq| (gauge, com as paredes)": zero_ou(float(np.linalg.norm(K @ (d0 @ phi)) /
                                                                   np.linalg.norm(K @ rng.normal(size=len(I))))),
           "|G∇φ| / |Gq| (o arrasto não mexe nos gradientes)": zero_ou(float(np.linalg.norm(G1 @ (d0 @ phi)) /
                                                                            np.linalg.norm(G1 @ rng.normal(size=len(I)))))}
    wmax = math.sqrt(limite_wmax(C))
    dt = 1.0 / wmax
    res["dt"] = sig(dt, 3)
    k = 2 * math.pi / Lz
    kv = np.array([0, 0, k])
    ex, ey = np.eye(3)[0], np.eye(3)[1]
    mid = C.P[C.arestas[I, 0]] + 0.5 * C.vet_aresta[I]
    perto = np.hypot(mid[:, 0] - R, mid[:, 1] - R) < 0.5 * R
    out = {}
    for Om in ((0.0, Om0) if omegas is None else omegas):
        G = (Om * G1).tocsr()
        GT = G.T.tocsr()

        def fluxoB(q, pi, tau):
            yq, tq = q.copy(), q.copy()
            yp, tp = pi.copy(), pi.copy()
            for kk in range(1, 4):
                tq = -tau * sol(G @ tq) / kk
                yq += tq
                tp = tau * (GT @ sol(tp)) / kk
                yp += tp
            return yq, yp
        for s in (1, -1):
            Qs = C.onda_aresta(kv, ex - 1j * s * ey)[I]
            q = Qs.real.copy()
            v = (1.0 * k * Qs.imag).copy()
            pi = M1 @ v + G @ q
            H = lambda q, pi: 0.5 * pi @ sol(pi) + 0.5 * q @ (K @ q) - pi @ sol(G @ q)
            H0 = H(q, pi)
            gauss0 = d0.T @ pi
            ns = int(round(T / dt))
            Ts = M1 @ Qs
            nrm = np.sum(np.abs(Ts[perto])**2)
            ts, fs = [], []
            if Om:
                q, pi = fluxoB(q, pi, 0.5 * dt)
            for it in range(ns + 1):
                if it % 10 == 0:
                    ts.append(it * dt)
                    fs.append(np.angle(np.vdot(Ts[perto], pi[perto]) / nrm))
                pi -= 0.5 * dt * (K @ q)
                q += dt * sol(pi)
                pi -= 0.5 * dt * (K @ q)
                if Om:
                    q, pi = fluxoB(q, pi, dt if it < ns else 0.5 * dt)
            ts, ph = np.array(ts), np.unwrap(fs)
            w = -np.polyfit(ts[ts > 5], ph[ts > 5], 1)[0]
            out[(Om, s)] = w
            res[f"Omega = {Om}, s = {s:+d}"] = {
                "omega_medido": sig(w, 5),
                "deriva de energia": sig(float((H(q, pi) - H0) / H0), 3),
                "|∇·π(t) − ∇·π(0)| / |π| (lei de Gauss)": zero_ou(float(np.linalg.norm(d0.T @ pi - gauss0) /
                                                                        np.linalg.norm(pi)))}
    if omegas is not None:
        res["omegas"] = {f"{Om:+.3f}, s = {s:+d}": sig(w, 6) for (Om, s), w in out.items()}
        return res
    res["parado: omega(+1) − omega(−1)"] = sig(out[(0.0, 1)] - out[(0.0, -1)], 3)
    res["girando: omega(+1) − omega(−1)"] = sig(out[(Om0, 1)] - out[(Om0, -1)], 3)
    res["previsto (rotação rígida, m = −s): −2 Omega"] = -2 * Om0
    return res


# ---------------------------------------------------------------------- figura e principal
def figura(r_op, r_esp, r_gir, pasta):
    fig, axs = plt.subplots(1, 3, figsize=(16, 4.6))
    ax = axs[0]
    cores = {"C2 loops geométricos": "#2a78d6", "C2u loops com peso uniforme": "#2f9e6e",
             "C3 loops com orientação aleatória": "#c9582b"}
    for nome, cor in cores.items():
        lin = r_op[nome]
        n = [x["GMFs"] for x in lin]
        ax.loglog(n, [x["eps_cc_fraco"] for x in lin], "o-", color=cor, linewidth=2, label=nome)
    ax.loglog(n, [x["eps_cc_ponto_a_ponto"] for x in r_op["C2 loops geométricos"]], "s--", color="#2a78d6",
              linewidth=1, label="C2, ponto a ponto")
    ax.set_xlabel("número de GMFs"); ax.set_ylabel("ε_cc")
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.set_title("Operador dos loops contra α ∇×∇×", fontsize=10)
    ax.legend(fontsize=7, frameon=False)
    ax.grid(True, which="both", alpha=0.2, linewidth=0.6)
    ax = axs[1]
    nomes = ["C2 loops geométricos", "C2u loops com peso uniforme", "C3 loops com orientação aleatória",
             "C0 pares isotrópicos", "C1 pares perpendiculares", "C1c pares centrais"]
    rot = ["C2", "C2u", "C3", "C0", "C1", "C1c"]
    val = []
    for nm in nomes:
        d = r_esp[nm]
        if "omega_L²/omega_T²" in d:
            val.append(d["omega_L²/omega_T²"])
        else:
            v = d["omega²/(ck)² do terceiro modo (máximo)"]
            val.append(1e-16 if eh_zero(v) else v)
    cs = ["#2a78d6", "#2f9e6e", "#c9582b", "#7a7a74", "#7a7a74", "#7a7a74"]
    ax.bar(range(6), [max(v, 1e-17) for v in val], color=cs)
    ax.set_yscale("log"); ax.set_ylim(1e-17, 10)
    for i in (0, 1):
        ax.text(i, 3e-16, "zero\n(arredon-\ndamento)", ha="center", va="bottom", fontsize=7)
    ax.set_xticks(range(6)); ax.set_xticklabels(rot)
    ax.set_ylabel("ω² do modo longitudinal / ω² transversal")
    ax.set_title("O modo longitudinal: gauge (ω = 0) só com loops orientados", fontsize=10)
    ax = axs[2]
    conchas = r_esp["espectro verdadeiro do tapete (sem projeção)"]["C2"]
    for s2, (nm, d) in zip((1, 2, 3), conchas.items()):
        w = np.array(d["autovalores_perto (em (2π/L)²)"])
        w = w[np.abs(w - s2) < 0.15 * s2]
        ax.plot(np.full(len(w), s2) + np.linspace(-0.25, 0.25, len(w)), np.sqrt(w), "o", color="#2a78d6", ms=4)
        ax.text(s2, math.sqrt(s2) + 0.12, f"{len(w)} modos\n(2 × {len(w) // 2})", ha="center", fontsize=8)
    xs = np.linspace(0.6, 3.4, 50)
    ax.plot(xs, np.sqrt(xs), color="#1b1b19", linewidth=0.8, linestyle=":", label="ω = c|k|")
    ax.set_xlabel("|n|²  (k = 2πn/L)"); ax.set_ylabel("ω / (2πc/L)")
    ax.set_title("Espectro verdadeiro do tapete (C2): duas polarizações", fontsize=10)
    ax.set_ylim(0.8, 2.1)
    ax.legend(fontsize=8, frameon=False, loc="lower right")
    for a in axs:
        for lado in ("top", "right"):
            a.spines[lado].set_visible(False)
    fig.tight_layout()
    fig.savefig(pasta / "c5a_curl_curl_emergente.png", dpi=150)
    plt.close(fig)


def main():
    saida = Path(sys.argv[1] if len(sys.argv) > 1 else "c5a_curl_curl_emergente.json")
    pasta = saida.resolve().parent
    pasta.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(SEMENTE)
    r_op = t_operador(rng)
    r_esp = t_espectro(rng)
    r_g = t_gauge(rng)
    r_h = t_helicidade(rng)
    r_c = t_curvo(rng)
    r_gir = t_girante(rng)
    c2 = r_op["C2 loops geométricos"]
    ok = {}
    ok["1_operador_converge_fraco"] = c2[-1]["eps_cc_fraco"] < 0.02 and c2[0]["eps_cc_fraco"] / c2[-1]["eps_cc_fraco"] > 5
    e2 = r_esp["C2 loops geométricos"]
    ok["2_dois_transversais_e_um_gauge"] = (e2["maior |k̂·q| dos 2 transversais"] < 0.1 and
                                           eh_zero(e2["omega²/(ck)² do terceiro modo (máximo)"]) and
                                           all(d["contagem na janela ±15%"] == d["esperado (2 polarizações)"]
                                               for d in r_esp["espectro verdadeiro do tapete (sem projeção)"]["C2"].values()))
    g2 = r_g["C2 loops geométricos"]
    ok["3_gauge_e_divergencia"] = (eh_zero(g2["|q̈| / |q| para q = ∇φ (φ aleatório)"]) and
                                  eh_zero(g2["|∇·q̈| / |q̈| para q aleatório"]) and
                                  eh_zero(r_g["C2: q = ∇φ evoluído por 200 passos, |q − q0|/|q0|"]))
    hh = r_h[list(r_h)[-1]]
    ok["4_omega_ck_e_helicidades"] = all(abs(d["omega/ck s = +1"] - 1) < 0.01 and d["|omega+ − omega−| / omega"] < 1e-3
                                         for d in hh.values())
    ok["5_controles_falham"] = (not eh_zero(r_g["C3 loops com orientação aleatória"]["|q̈| / |q| para q = ∇φ (φ aleatório)"]) and
                               all(r_esp[c]["omega_L²/omega_T²"] > 0.1 for c in
                                   ("C0 pares isotrópicos", "C1 pares perpendiculares", "C1c pares centrais")))
    cc = r_c["convergência"]
    ok["6_curvo_so_coeficientes"] = cc[-1]["eps contra ∇×(1/n)∇× (fraco)"] < 0.02 and eh_zero(cc[-1]["|K∇φ|/|Kq|"])
    ok["7_girante_separa_helicidades"] = (eh_zero(r_gir["|G∇φ| / |Gq| (o arrasto não mexe nos gradientes)"]) and
                                         abs(r_gir["parado: omega(+1) − omega(−1)"]) < 0.1 * abs(r_gir["girando: omega(+1) − omega(−1)"])
                                         and r_gir["girando: omega(+1) − omega(−1)"] * r_gir["previsto (rotação rígida, m = −s): −2 Omega"] > 0)
    out = {"parametros": {"caixa": L, "semente": SEMENTE, "tremor": 0.35,
                          "energia": "E = ½ Cᵀ M2 C, C = d1 q (circulações nos loops); C2u: E = ½ Σ C_f²"},
           "T1_operador": r_op, "T2_espectro": r_esp, "T3_gauge": r_g, "T4_helicidade": r_h,
           "C5_curvo": r_c, "C6_girante": r_gir,
           "criterios": {k: bool(v) for k, v in ok.items()}}
    out["todos_passaram"] = bool(all(ok.values()))
    for k, v in ok.items():
        print(k, "PASSOU" if v else "FALHOU")
    with saida.open("w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1)
    figura(r_op, r_esp, r_gir, pasta)
    print("GLOBAL:", "TODOS PASSARAM" if out["todos_passaram"] else "HA FALHAS")
    return 0 if out["todos_passaram"] else 1


if __name__ == "__main__":
    sys.exit(main())
