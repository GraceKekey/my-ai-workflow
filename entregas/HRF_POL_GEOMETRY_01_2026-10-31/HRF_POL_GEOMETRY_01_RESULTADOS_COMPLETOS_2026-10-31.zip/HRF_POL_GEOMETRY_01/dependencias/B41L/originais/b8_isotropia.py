#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
C5A B8 — Lorentz no UV e isotropia do fóton livre (rodadas novas: B8-2 e controles)
==================================================================================

Operador e malha: os mesmos da B1 (c5a_curl_curl_emergente: tapete de GMFs, Delaunay periódico, pesos de Whitney W;
K = d1ᵀ M2 d1, massa M1). Frequência de cada onda plana: problema de Galerkin nas 3 ondas de vetor k (mesma função
`projetado` da B1). Fundo plano (D1).

Para cada malha e cada direção k̂ (13 direções), n = m·d com m = 1, 2, 3; ajuste exato em x = (ka)²:
    ω/ck = c0 + b1 x + b2 x²   →   c0(k̂) = velocidade no limite IR,   ξ(k̂) = −b1/c0.

Controles: rede cúbica regular (Yee/Wilson, m_e = a, w_f = 1/a: dispersão analítica conhecida [F]) e malha
anisotrópica N6 da B1 (espaçamento 2× em z), com pesos W e U.

Uso: python b8_isotropia.py <pasta>   (variáveis: B8_LADOS, B8_SEMENTES)
"""
from __future__ import annotations

import json
import math
import os
import sys
import time
from pathlib import Path

import numpy as np
import scipy.linalg as sl
import scipy.sparse as sp

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI / "bancadas" / "c5a_curl_curl_emergente"))
import c5a_curl_curl_emergente as CC   # noqa: E402
from malha import Complexo, pontos_tapete   # noqa: E402

L = CC.L
LADOS = [int(x) for x in os.environ.get("B8_LADOS", "10,14,20,26").split(",")]
SEMENTES = [int(x) for x in os.environ.get("B8_SEMENTES", ",".join(str(20261501 + i) for i in range(10))).split(",")]
DIRS = [(1, 0, 0), (0, 1, 0), (0, 0, 1),
        (1, 1, 0), (1, -1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (0, 1, -1),
        (1, 1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1)]
MS = (1, 2, 3)


def kvec(n):
    return 2 * math.pi / L * np.asarray(n, float)


def projetado(onda, K, Mmul, n):
    """Galerkin nas 3 ondas planas de vetor k (como `projetado` da B1). onda(k, A) → circulação por ligação."""
    k = kvec(n)
    Q = np.stack([onda(k, e) for e in np.eye(3)], 1)
    Kk = Q.conj().T @ (K @ Q); Mk = Q.conj().T @ Mmul(Q)
    w2, v = sl.eigh((Kk + Kk.conj().T) / 2, (Mk + Mk.conj().T) / 2)
    return w2


def medir(onda, K, Mmul, a):
    """Para cada direção: ω/ck dos 2 transversais (média) em m = 1, 2, 3; ajuste exato em (ka)²."""
    out = {}
    for d in DIRS:
        xs, ys, bir = [], [], []
        for m in MS:
            n = tuple(m * c for c in d)
            k = np.linalg.norm(kvec(n))
            w2 = projetado(onda, K, Mmul, n)
            wT = np.sqrt(np.clip(w2[1:], 0, None))
            xs.append((k * a)**2); ys.append(float(wT.mean() / k)); bir.append(float(abs(wT[1] - wT[0]) / wT.mean()))
        b2, b1, c0 = np.polyfit(xs, ys, 2)
        out[str(d)] = {"(ka)²": xs, "ω/ck": ys, "birrefringência": bir, "c0": float(c0), "xi": float(-b1 / c0),
                       "zeta_eff": float(-b2 / c0)}
    return out


def delaunay(lado, semente, nvec=None, pesos="W"):
    rng = np.random.default_rng(semente)
    if nvec is None:
        C, M1, M2 = CC.montar(lado, rng)
    else:
        P = pontos_tapete(np.asarray(nvec), L, rng, 0.35)
        C = Complexo(P, L)
        M1, M2 = C.matrizes()
    if pesos == "U":
        K = (C.d1.T @ C.d1).tocsr(); M1 = sp.identity(C.E, format="csr")
    else:
        K = (C.d1.T @ M2 @ C.d1).tocsr()
    return C, K, M1


def cubica(lado):
    """Rede cúbica regular periódica: ligações x, y, z; plaquetas; m_e = a, w_f = 1/a (Yee). Igual ao controle da B2."""
    n = lado; a = L / n
    idx = lambda i, j, k: ((i % n) * n + (j % n)) * n + (k % n)
    I, J, Kk = [x.ravel() for x in np.meshgrid(np.arange(n), np.arange(n), np.arange(n), indexing="ij")]
    s = idx(I, J, Kk); N = n**3
    lig = lambda d, i, j, k: d * N + idx(i, j, k)
    desl = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    rows, cols, vals = [], [], []
    for p, (mu, nu) in enumerate(((0, 1), (1, 2), (2, 0))):
        f = p * N + s; dm, dn = desl[mu], desl[nu]
        for (dd, sh, sg) in ((mu, (0, 0, 0), 1.0), (nu, dm, 1.0), (mu, dn, -1.0), (nu, (0, 0, 0), -1.0)):
            rows.append(f); cols.append(lig(dd, I + sh[0], J + sh[1], Kk + sh[2])); vals.append(np.full(N, sg))
    d1 = sp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(3 * N, 3 * N)).tocsr()
    K = (d1.T @ d1).tocsr() / a
    me = np.full(3 * N, a)
    pos = np.stack([I, J, Kk], 1) * a
    x0 = np.concatenate([pos, pos, pos]); dv = np.concatenate([np.tile(np.array(d, float) * a, (N, 1)) for d in desl])

    def onda(k, A):
        th = dv @ k
        f = np.where(np.abs(th) < 1e-12, 1.0 + 0j, (np.exp(1j * th) - 1) / (1j * np.where(np.abs(th) < 1e-12, 1, th)))
        return (dv @ A) * np.exp(1j * (x0 @ k)) * f
    return onda, K, (lambda Q: me[:, None] * Q), a


def xi_cubica_analitico(d):
    kh = np.asarray(d, float) / np.linalg.norm(d)
    return float(np.sum(kh**4) / 24)


def main():
    pasta = Path(sys.argv[1]); pasta.mkdir(parents=True, exist_ok=True)
    t00 = time.time()
    res = {"parametros": {"L": L, "lados": LADOS, "sementes": SEMENTES, "direcoes": DIRS, "m": MS,
                          "a": "L/lado (espaçamento médio dos GMFs)", "pesos": "W (Whitney), como na B1"}}
    dl = {}
    for lado in LADOS:
        for s in SEMENTES:
            t0 = time.time()
            C, K, M1 = delaunay(lado, s)
            r = medir(C.onda_aresta, K, lambda Q: M1 @ Q, L / lado)
            dl[f"{lado}|{s}"] = {"lado": lado, "semente": s, "GMFs": C.N, "direcoes": r, "segundos": round(time.time() - t0, 1)}
            c0 = [v["c0"] for v in r.values()]
            print(f"Delaunay {lado}³ semente {s}: c0 médio {np.mean(c0):.6f}, anisotropia {np.std(c0) / np.mean(c0):.2e} "
                  f"[{time.time() - t0:.0f} s; total {time.time() - t00:.0f} s]", flush=True)
    res["delaunay"] = dl
    cu = {}
    for lado in LADOS:
        onda, K, Mm, a = cubica(lado)
        r = medir(onda, K, Mm, a)
        for d, v in r.items():
            v["xi_analitico (Σk̂⁴/24)"] = xi_cubica_analitico(eval(d))
        cu[str(lado)] = r
        print(f"cúbica {lado}³ ok", flush=True)
    res["cubica_controle"] = cu
    n6 = {}
    for pesos in ("W", "U"):
        for s in SEMENTES[:3]:
            C, K, M1 = delaunay(None, s, nvec=(14, 14, 7), pesos=pesos)
            r = medir(C.onda_aresta, K, lambda Q: M1 @ Q, (L**3 / C.N) ** (1 / 3))
            n6[f"{pesos}|{s}"] = {"pesos": pesos, "semente": s, "GMFs": C.N, "direcoes": r}
            c0 = [v["c0"] for v in r.values()]
            print(f"N6 {pesos} semente {s}: anisotropia {np.std(c0) / np.mean(c0):.2e}", flush=True)
    res["N6_controle"] = n6
    res["tempo_total_s"] = round(time.time() - t00, 1)
    (pasta / "B8_isotropia.json").write_text(json.dumps(res, ensure_ascii=False, indent=1, default=float), encoding="utf-8")


if __name__ == "__main__":
    main()
