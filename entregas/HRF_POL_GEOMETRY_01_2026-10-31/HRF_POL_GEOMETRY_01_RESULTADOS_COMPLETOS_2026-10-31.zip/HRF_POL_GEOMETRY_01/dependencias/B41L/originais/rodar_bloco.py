#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""C5A B1 — driver de bloco. Importa o c5a_photon_closure.py parametrizado (sem mudar a lógica) e roda só as seções
de um bloco, com um gerador novo iniciado na semente PC_SEMENTE. Grava o dicionário R (como o script original o
monta) e as tabelas CSV (séries com 10 algarismos) na pasta de saída.

Uso: PC_SEMENTE=... PC_RES_*=... python rodar_bloco.py <B1a|B1b|B1c> <pasta_saida>
"""
import json
import sys
import time
from pathlib import Path

import numpy as np

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI / "bancadas" / "c5a_photon_closure"))
import c5a_photon_closure as PC  # noqa: E402

BLOCOS = {
    "B1a": (("S3_S4_holonomia_e_operador", PC.s_holonomia_operador), ("S5_S6_polarizacoes_gauge_N0_N3", PC.s_polarizacoes),
            ("S7_S10_dispersao_lorentz", PC.s_dispersao), ("S8_S9_energia_momento_helicidade", PC.s_energia_momento),
            ("S13_S14_quanta", PC.s_quanta), ("S19_cargas", PC.s_cargas)),
    "B1b": (("S9_S15_conservacao", PC.s_conservacao),),
    "B1c": (("S2_S11_S12_guia", PC.s_guia), ("S11_fundos_curvos", PC.s_curvo)),
}


def main():
    bloco, pasta = sys.argv[1], Path(sys.argv[2])
    pasta.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(PC.SEMENTE)
    R, tempos = {}, {}
    t00 = time.time()
    for chave, f in BLOCOS[bloco]:
        t0 = time.time()
        R[chave] = f(rng)
        tempos[chave] = round(time.time() - t0, 1)
        PC.log(f"  [{chave}: {tempos[chave]:.0f} s]")
    PC.salvar_csv(pasta) if PC.TABELAS else None
    out = {"bloco": bloco, "semente": PC.SEMENTE,
           "resolucoes": {"disp": PC.RES_DISP, "em": PC.RES_EM, "cons": PC.RES_CONS, "pol": PC.RES_POL, "guia": PC.RES_GUIA},
           "tempos_s": tempos, "tempo_total_s": round(time.time() - t00, 1), "R": R,
           "tabelas": PC.TABELAS}
    with (pasta / f"{bloco}_{PC.SEMENTE}.json").open("w", encoding="utf-8") as fh:
        json.dump(out, fh, ensure_ascii=False, indent=1, default=float)


if __name__ == "__main__":
    main()
