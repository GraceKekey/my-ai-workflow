# HRF B41L — A B1 repetida com o lançamento limpo
## O fechamento do fóton efetivo sem a carga espúria do lançamento — protocolo pré-registrado

**Data:** 29 de outubro de 2026 (America/Sao_Paulo) — Claude (`-clau`)
**Autoria:** Mario José do Canto Filho, MD · desenho e código: Claude
**Nome provisório:** "B41L" (L de lançamento limpo), no padrão da B39H e da B41H. Os ímpares a partir de 43 estão com
os outros chats. Mario pode renomear antes de rodar; o nome não entra em nenhum cálculo.

**Decisões de Mario que fixam esta bancada (29/10):**
- 18h39 — depois do relatório da B41H: "Ok, faça o pré-registro da B1 com lançamento limpo."
- 19h46 — depois do meu aviso de que a mesma cópia do contínuo também entra no estimador da frequência (S7 da B1 e
  B8): "pode fazer". A pergunta do estimador entra como parte secundária (Q4).

**Nada foi executado nesta sessão: nem a fumaça, nem a rodada completa.** Houve só compilação do código e o teste
sintético (§8), que não monta malha e não roda física. Mario roda tudo no Colab ou na máquina dele.

**Vertente:** HRF-FM, Capítulo 2 (a onda fotônica livre). Antecedentes: B1 (1–2/10), B41 (28/10), B41H (29/10) e o
Capítulo 2 v1.5, §2.5.3 e §2.14.

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese · [?] aberto · [D] decisão.

---

## 1. Objetivo

1. **Principal.** Repetir a B1 inteira com o lançamento limpo e aplicar a regra de decisão da própria B1, com o
   avaliador original. A pergunta: o PHOTON-CLOSURE-E fecha quando o saca-rolha é preparado sem a carga espúria?
2. Medir, nas mesmas malhas, o que muda entre o lançamento original (V0) e o limpo (V1) em cada critério e item.
3. Estimar a taxa de falha por semente com o lançamento limpo. É o critério de robustez que o P1 (9 de 10) mede mal.
4. **Secundária [H].** Verificar se o estimador espectral da B1 (S7) e da B8 tem um viés pela mesma carga espúria, e
   quanto isso muda ξ e o teto de Lorentz.

A bancada não muda nenhum veredito anterior: a B1 continua FECHADO, a B41 NÃO REPRODUZIDO e a B41H
CAUSA_GAUGE_NO_LANCAMENTO. O resultado entra no Capítulo 2 como resultado novo.

---

## 2. O que já se sabe

**Da B41H [M].**
- A onda copiada do contínuo para as ligações pelo mapa de de Rham não obedece à lei de Gauss discreta: d0ᵀ M1 v₀ ≠ 0.
- A parte longitudinal parada contamina a fração de helicidade.
- Lançar limpo (v₀ → v₀ − d0 λ) zerou as falhas de preparação: 10 → 0 em 140 malhas.
- A falha marginal do item 9 (semente 41020004, h = 0,46, η_g = 0,0116) não muda com a limpeza.

**Leitura das saídas da B41H, feita ao preparar esta bancada [pós-hoc].**
- O peso da parte longitudinal na métrica M1 é δ_L1 = |v_L|_M1/|v₀|_M1. Nas 140 malhas novas, a mediana foi:

  | Malha | 10³ | 14³ | 18³ | 22³ |
  |---|---|---|---|---|
  | mediana de δ_L1 | 0,089 | 0,064 | 0,050 | 0,042 |

  Em todas, δ_L1 ≈ 0,9/n, isto é, proporcional ao espaçamento.
- **Identidade [F].** Para qualquer vetor Q, R(Q) = R(Q_T)(1 − δ²), em que:
  - R é o quociente de Rayleigh, R(Q) = QᴴKQ/QᴴM1Q;
  - Q_T é a parte limpa de Q;
  - δ² é a fração longitudinal de Q.

  A conta é K d0 = 0: a parte longitudinal pesa na massa, mas não tem energia de mola.
- **Consequência [H].** O Galerkin da B1 (S7) e da B8 usa as três ondas copiadas como funções de teste e mede ω/ck
  pela razão de Rayleigh. Só a componente longitudinal do próprio k é removida (ela é um gradiente exato). A carga
  espúria das transversais continua lá.

  Com δ ≈ 0,14·(ka), a frequência estimada fica baixa por δ²/2 ≈ 0,010·(ka)². Esse viés tem a forma da dispersão de
  rede que a B8 mede (ξ ≈ 0,016). Se for real, parte de ξ seria artefato do estimador, e o teto a_ρ,max ∝ 1/√ξ
  ficaria mais folgado.

  É uma estimativa grosseira: supõe δ ∝ k e não considera o que o próprio Galerkin já absorve.
- **Controle natural.** Na rede cúbica regular, a cópia de uma onda transversal já obedece à lei de Gauss. A limpeza
  não muda nada nela, e por isso o controle cúbico da B8 nunca viu esse efeito.

**O que se limpa na B1 (§4).**
- **Lançamentos:**
  - S9, o teste de conservação;
  - S2/S12, o guia com fundo compensado, N4 e retroação;
  - S11 C3/C4, o guia girante do item 8.
- **Estado de onda plana:** S8, energia–momento e resíduo de helicidade.
- **Estimador espectral** (só na V1E): S7, que dá dispersão, Lorentz IR e N6, e a B8-2.

Não lançam onda e ficam como na B1:
- S3/S4 (holonomia e operador);
- S5/S6 (espectro verdadeiro e controles);
- S13/S14 (quanta);
- S19 (cargas);
- S11 C1/C2 (operador em fundo curvo).

---

## 3. Hipóteses e previsões

| Hipótese | Ideia | Previsão que a distingue |
|---|---|---|
| **H_L — lançamento** [H, apoiada pela B41H] | as falhas pontuais da B1 e da B41 vinham da carga espúria | com V1, nenhuma semente falha nos itens de preparação (Q3); a regra da B1 fecha nos três conjuntos (Q1) |
| **H_0 — nada mais muda** | a limpeza só tira a contaminação | as grandezas de P2–P5 continuam nas faixas da B1; as malhas e os itens que não lançam onda ficam idênticos |
| **H_E — estimador** [H] | o Galerkin com as ondas copiadas subestima ω por ≈ δ²/2 | ξ(V1E)/ξ(V0) bem abaixo de 1 na malha mais fina; a frequência que a onda limpa de fato tem (ω_din) fica mais perto do estimador limpo que do original |

**O que se espera, sem ser critério:**
- **Item 9 (41020004).** Deve continuar falhando com V1, como na B41H. Com só essa falha, o conjunto da B41 fica com
  9/10 e passa em P1.
- **(E² − P²c²)/E² (S8).** Deve cair em cada malha, porque a energia da parte longitudinal sai do estado. A ordem de
  convergência p de P3 pode mudar. Isso não é falha: é parte do que se mede.
- **P5 com V1E.** Se ξ cair muito, |a1| < 0,1·|a2| fica mais difícil de cumprir, porque a2 diminui. Uma falha de P5 na
  V1E é informação sobre o estimador, não sobre o lançamento.

---

## 4. Parâmetros

Toda onda injetada é o saca-rolha (polarização circular), como em todas as bancadas.

**Conjuntos de sementes** (cada um é uma B1 completa, com a regra da B1):

| Conjunto | Sementes | Com guia (B1c) | V0 do guia |
|---|---|---|---|
| B1 | 20261201–20261210 (as da B1) | 20261201–20261206 | gravado (B1, 2/10) |
| B41 | 41020001–41020010 (as da B41) | 41020001–41020006 | gravado (B41, 28/10) |
| N | 41820001–41820010 (novas, nunca usadas) | 41820001–41820006 | rodado nesta bancada |

**Resoluções e tempos:** os da B1, sem mudança.
- dispersão 10, 14, 20;
- energia–momento 7, 10, 14, 17, 20;
- conservação 10, 14, 18, com T = 20;
- polarizações 10;
- guia h = 0,55; 0,46; 0,40, com T = 40;
- guia girante h = 0,5, com T = 40;
- B1a, B1b e B1c com gerador novo na semente, como em `rodar_bloco.py`.

**Variantes:**

| Variante | O que muda em relação à B1 |
|---|---|
| **V0** | nada: é a B1 |
| **V1** (principal) | lançamento e estado limpos: S8, S9, S2/S12 e S11-C3/C4 |
| **V1E** | V1 e, além disso, o estimador espectral limpo em S7 (e na B8-2) |

**A limpeza [F].**
- **Estado de onda plana e lançamento na caixa periódica:** Q → Q − d0 λ, com d0ᵀ M1 d0 λ = d0ᵀ M1 Q. O vetor
  constante é o núcleo; fixa-se λ = 0 no GMF 0.
- **Guia e girante:** o momento canônico perde a parte longitudinal, π = M1 v + G q → π − M1 d0 λ, com d0ᵀ M1 d0 λ = d0ᵀ π
  (os GMFs da parede ficam fora de d0). É o mesmo de `rodar_b41h` na B41H.
- **O que não se toca:** q mantém a parte gradiente de Re Q. Ela é puro gauge: não entra em ∇×q nem em K q, e nenhuma
  medida a vê.

**S9 sem rodar duas vezes [F].** A trajetória integrada é a limpa. A original sai dela exatamente, porque K d0 = 0:
v₀(t) = v₁(t) + d0 λ e q₀(t) = q₁(t) + t·d0 λ. Por isso o V0 da conservação é medido nos mesmos pontos, sem nova
integração. Quatro coisas conferem isso:
- as âncoras com a B1 e a B41;
- uma rodada real do lançamento original (semente 41820001 em 10³);
- na fumaça, outras duas;
- a identidade da §2.

**Parte B8** (estimador, Q4):
- a B8-2 inteira, com V0 e V1E, nas malhas da M03 da B41: lados 10, 14, 20, 26 × sementes 41030001–41030010, 13 direções,
  m = 1, 2, 3;
- mais a rede cúbica e a malha anisotrópica N6.

A B8-1 (o ξ que dá o teto) sai da S7 de cada conjunto.

**Parte F (fidelidade):** cada cópia de rotina original, com `limpar=False`, contra o original. Rodar_guia na
semente 41020001, h = 0,55, T = 40; t_girante a partir de um mesmo estado do gerador, T = 40.

**Perfil `fumaca`** (só encadeamento; números descartados):
- sementes 20261201 e 41820001;
- resoluções da fumaça da B41: disp 5, 6, 7; em 4–8; cons 5, 6, 7; pol 7; guia 1,0; 0,9; 0,8;
- T = 2 na conservação e T = 6 no guia e no girante da V1;
- B8 nos lados 8 e 10, com 2 sementes;
- duas conferências reais do V0.

---

## 5. Protocolo

1. **Pré-registro:** este arquivo, o LEIAME, o roteiro da fumaça (não executado), o código, as referências e
   `HRF_B41L_hashes_antes_da_execucao_2026-10-29_2000-clau.txt` (SHA-256 de tudo), gravados no Projeto antes de qualquer
   execução. Os arquivos em `originais/` têm os mesmos SHA-256 do pré-registro da B41.
2. **Mario, no Colab ou na máquina dele** (caderno `HRF_B41L_Colab_2026-10-29_2000-clau.ipynb`):
   1. conferir os hashes;
   2. fixar NumPy 2.5.3 e SciPy 1.18.1, as versões da B1, da B41 e da B41H, para as âncoras conferirem;
   3. rodar o teste sintético;
   4. rodar a fumaça e avaliá-la;
   5. rodar a completa e avaliá-la. O limite de memória da fila é `--memoria-gb 30`, a lição da B41H.
3. **Se a fumaça mostrar erro de código,** a correção é declarada antes da completa, em arquivos novos, com hashes novos,
   como na M07c da B41. Nenhum arquivo congelado muda.
4. **Se a sessão cair,** relançar retoma pelos marcadores. O cálculo é determinístico.
5. **O relatório** separa o que foi decidido pelas regras da §7 do que for leitura pós-hoc.

---

## 6. Medidas

**Bloco A (B1a, por semente):**
- as seções originais, como a B1 as roda (V0);
- S8 recalculada nas mesmas malhas com o estado limpo (V1);
- S7 recalculada nas mesmas malhas com o estimador limpo (V1E).

Diagnóstico:
- os espelhos (S7 e S8 reescritas, sem limpeza, devem dar o dicionário original);
- δ² e os resíduos de cada limpeza;
- ω_cru e ω_limpo de cada onda de S8.

**Bloco B (B1b, por semente e malha):**
- as medidas da B1 em V0 e V1: energia, P_z, fração na helicidade h = +1 com a métrica da B1 (M1²) e lei de Gauss.

Extras:
- a fração na métrica M1;
- δ_L1 e δ_L2;
- ω_cru e ω_limpo do saca-rolha;
- ω_din, a frequência da fase de c₊ = Q₊ᴴπ ao longo da trajetória limpa (200 pontos).

**Bloco C (B1c, por semente):** S2/S12 e S11 em V1 (e em V0 nas sementes novas), e a carga relativa de cada lançamento.

**B8:** c0, ξ e ζ por direção e malha, em V0 e V1E, e δ² de cada função de teste.

**F:** as diferenças entre cópia e original e o estado do gerador.

---

## 7. Regras de decisão (congeladas; `src/avaliar_B41L.py`)

A regra da B1 é aplicada pelo avaliador ORIGINAL, `originais/avaliar_B1.py`, só trocando as listas de sementes, como
na B41. O mesmo vale para a B8, com `originais/avaliar_B8.py`. Cada conjunto é avaliado em cada variante.

### Âncoras

| Âncora | O que confere | Passa se |
|---|---|---|
| **A1** — séries de V0 (só na completa) | `por_semente` da avaliação V0 contra a avaliação gravada: `avaliacao_B1.json` de 2/10 (B1) e de 28/10 (B41) | listas da série B1a idênticas e ordens p com \|Δ\| ≤ 10⁻¹² (BIT_A_BIT); ε no início, ε mínimo e deriva com \|Δ\| ≤ 10⁻⁹ (CONFERE) ou ≤ 10⁻⁶ (TOLERÂNCIA); itens e guia iguais |
| **A2** — decisões de V0 | decisão e falhas de P1 | B1: FECHADO, com 20261201 falhando só em `extra_conservacoes_no_tempo`; B41: "NÃO FECHADO — falhou: P1", com 41020004 (item 9) e 41020005 (item 7) |
| **A3** — B8 em V0 | B8-2 contra a M03 da B41; avaliação da B8 do conjunto B41 contra a gravada | \|Δc0\|, \|Δξ\| ≤ 10⁻¹²; decisão, ξ e IC iguais |
| **A4** — malhas do guia | V1 contra V0 | GMFs dos três guias, C1/C2 (que não lançam onda) e GMFs do girante iguais |
| **A5** — fidelidade | cópias contra originais (Parte F) | guia \|Δ\| ≤ 10⁻¹² (FIEL; ≤ 10⁻⁸, FIEL_TOLERÂNCIA); girante com resultados e estado do gerador idênticos |
| **A6** — internas | espelhos de S7 e S8; resíduos das limpezas; V0 real × V0 reconstruído | espelhos todos verdadeiros; resíduos ≤ 10⁻⁸; diferença ≤ 10⁻⁹ |

### Q1 — a regra da B1 fecha com o lançamento limpo? (principal)

- **A decisão principal** é a do avaliador original da B1 em **V1 no conjunto B1**: a B1 repetida, nas mesmas malhas,
  com o lançamento limpo.
- **Classe:** FECHA_NOS_3, FECHA_EM_k_DE_3 ou NAO_FECHA_EM_NENHUM, pelas decisões de V1 nos três conjuntos.
- **Também relatadas:** as decisões de V0 (A2) e de V1E.

### Q2 — o que muda entre V0 e V1 (pareado por semente)

- Para cada semente, compara-se "todos os itens passam" em V0 e em V1.
- b = sementes resolvidas (falham em V0, passam em V1); c = regressões (o contrário).
- McNemar exato unilateral (H1: V1 falha menos), relatado com o aviso de que o poder é pequeno.
- Classes:
  - LIMPEZA_RESOLVE_SEM_REGRESSAO (b ≥ 1, c = 0);
  - LIMPEZA_RESOLVE_COM_REGRESSAO (b ≥ 1, c ≥ 1);
  - LIMPEZA_PIORA (b = 0, c ≥ 1);
  - SEM_EFEITO.
- Também a lista dos itens que mudaram, por semente.

### Q3 — a robustez por semente

- **Itens ligados à preparação do estado:**
  - 5 (E = pc);
  - 7 (o compensado não seleciona helicidade);
  - 8c (a parte do item 8 que lança onda: o girante e a lei de Gauss nos guias);
  - `extra_conservacoes_no_tempo`.
- **Os demais:** 1, 2, 3, 4, 8a (operador em fundo curvo), 9 (retroação), 10 e `extra_fonte`.
- **Classes**, por k_L(V), o número de sementes com falha de preparação em cada variante:
  - FALHAS_DE_PREPARACAO_ELIMINADAS (k_L(V0) ≥ 1 e k_L(V1) = 0);
  - FALHAS_DE_PREPARACAO_REDUZIDAS;
  - FALHAS_DE_PREPARACAO_NAO_REDUZIDAS;
  - SEM_FALHAS_DE_PREPARACAO_EM_V0.
- **Descritivo:**
  - a taxa de falha por semente em V0 e em V1, com IC de Clopper–Pearson;
  - a probabilidade de P1 passar nessa taxa e nos limites do IC, P(P1) = (1 − f)¹⁰ + 10 f (1 − f)⁹;
  - o item 6, fora do P1 da B1.

### Q4 — o estimador espectral [H]

- **r** = ξ(V1E)/ξ(V0), com o ajuste da B8-1 na malha mais fina da dispersão (20³), por semente. Média nas 30 sementes,
  com IC por bootstrap (2 000, semente 12345).
- **Classes:**
  - ESTIMADOR_SEM_VIES_RELEVANTE: \|r − 1\| < 0,05;
  - VIES_PEQUENO: 0,05 ≤ \|r − 1\| < 0,20;
  - VIES_IMPORTANTE: \|r − 1\| ≥ 0,20.
- **INCONCLUSIVO** se um controle falhar: na rede cúbica, \|ξ(V1E) − ξ(V0)\|/ξ ≤ 10⁻⁸ em todas as direções e lados; ou
  algum resíduo de limpeza acima de 10⁻⁸.
- **Consequências, relatadas:**
  - a decisão da B8 e o a_max pelo avaliador original da B8 em V0 e V1E, em cada conjunto;
  - ξ por direção na B8-2;
  - a decisão da regra da B1 em V1E.
- **Mecanismo e dinâmica, descritivo:**
  - a identidade de Rayleigh nas ondas de S8 (conferência de código);
  - em quantos casos ω_din fica mais perto de ω_limpo que de ω_cru;
  - as medianas das diferenças.

### Veredito global

```
<cabeça>; conjuntos: <classe Q1>; Q3: <classe>; Q4: <classe>
```

- **Cabeça:**
  - B1_FECHA_COM_LANCAMENTO_LIMPO, se a decisão principal for "PHOTON-CLOSURE-E FECHADO (toy model)";
  - senão, B1_NAO_FECHA_COM_LANCAMENTO_LIMPO (decisão).
- **Prefixo** "INCOMPLETO:" se faltar saída ou um avaliador original não conseguir rodar.
- **Sufixo** "(âncora não conferiu: …)" se alguma âncora falhar.
- **Na fumaça,** o prefixo é "FUMAÇA (números descartados)", e A1–A3 não se aplicam.

---

## 8. Controles e conferências embutidos

- **Determinismo e fidelidade:** A1–A6 (§7).
- **Mesmas malhas.** As malhas de V1 são as de V0 por construção:
  - o mesmo gerador, as mesmas chamadas e a mesma ordem;
  - no bloco A, as malhas são capturadas no momento em que a seção original as monta.

  A4 e os espelhos conferem.
- **Rede cúbica:** a limpeza não pode mudar nada nela.
- **Teste sintético** (`src/testar_B41L.py`, 47 testes). **Rodou nesta sessão, sem malha nem física:** "47 testes;
  TODOS OS RAMOS CONFEREM". Ele confere:
  - estatística com valores conhecidos;
  - a álgebra da limpeza num grafo aleatório de 9 nós: sem carga, gradiente → 0, idempotência, Pitágoras, identidade de
    Rayleigh e o caso com parede;
  - a estrutura do gradiente cúbico;
  - todos os ramos do avaliador, com saídas falsas montadas a partir das gravadas. Os avaliadores originais da B1 e da
    B8 rodam sobre elas.

---

## 9. Custo estimado (a fumaça medirá)

Base: na B41, B1a ≈ 145 s, B1b ≈ 2 250 s e B1c ≈ 4 100 s por semente; na B41H, a conservação em 18³ levou ≈ 1 400–1 800 s.

| Parte | Trabalhos | CPU (h) |
|---|---|---|
| B1a (30 sementes, V0 + V1 + V1E) | 30 | ~1,7 |
| B1b (30 × 3 malhas, uma trajetória por malha) | 90 | ~19 |
| B1c antigas (12, só V1) | 12 | ~14 |
| B1c novas (6, V0 + V1) | 6 | ~14 |
| B8 (V0 + V1E) e F | 2 | ~0,5 |
| **Total** | **140** | **~48 h** |

Com 11 trabalhadores (Colab L4, 12 núcleos, 52 GB), são ~5–6,5 h de parede, ou ~8–11 unidades de computação. O
trabalho mais longo (B1c de semente nova) leva ~2,3 h e entra primeiro.

Memória estimada:
- 3,5 GB por conservação em 18³;
- 2,5–3 GB nos demais.

Com `--memoria-gb 30`, cabem 8 conservações de 18³ ao mesmo tempo.

Para encurtar, dá para rodar por partes (`--partes B1c` primeiro, depois `B1a,B1b,B8,F`); o resultado é o mesmo.

Fumaça: ~15–25 min, quase todo no V0 do girante da semente nova (T = 40 no código original).

---

## 10. Limites

- Tudo continua [M], toy model. A bancada muda a preparação do estado e o estimador, não a física do fóton.
- **O V0 do guia nas sementes antigas é o gravado,** com 3 algarismos, como a B1 grava. É o mesmo que o avaliador
  original usou em 2/10 e em 28/10.
- **O conjunto N é o único com V0 do guia rodado aqui.** O pareamento do guia (Q2) tem 18 sementes.
- **O poder estatístico de Q2 e Q3 é modesto.** São 30 sementes, e as falhas de V0 esperadas são poucas (~3–6). A
  resposta forte sobre a preparação já veio da B41H, com 140 malhas. Aqui o que se mede é a regra da B1 inteira.
- **H_E é nova e pós-hoc no seu motivo.** Ela está pré-registrada antes de qualquer número do estimador limpo, mas a
  ideia veio da leitura dos dados da B41H.

  O estimador limpo dá a média dos autovalores transversais ponderada pela energia de cada modo [F]; o original
  mistura nessa média os modos de frequência zero. Mesmo assim, "frequência de uma onda plana numa malha irregular"
  continua uma definição. A dinâmica (ω_din) é o teste independente.
- Se Q4 der VIES_IMPORTANTE, o teto de Lorentz do Capítulo 2 (§2.7.1) muda de valor, mas não de forma. A reavaliação
  completa da B8, com todos os seus critérios, fica para um pré-registro próprio.

---

## 11. Arquivos do pré-registro

- **Documentos:**
  - `HRF_B41L_PROTOCOLO_2026-10-29_2000-clau.md` (este);
  - `LEIAME_B41L_2026-10-29_2000-clau.md`;
  - `FUMACA_B41L_2026-10-29_2000-clau.md` (roteiro; **não executada**).
- **Código (`src/`):**
  - `b41l_comum.py`: perfis, sementes, limiares, utilidades e estatística;
  - `b41l_limpeza.py`: a limpeza; as cópias de Guia.rodar, t_girante e p4_fundos; o Galerkin limpo; o gradiente da
    rede cúbica;
  - `b41l_bloco_a.py` (B1a), `b41l_bloco_b.py` (B1b), `b41l_bloco_c.py` (B1c), `b41l_fidelidade.py` (F) e
    `b41l_b8.py` (B8);
  - `rodar_B41L.py`: o orquestrador;
  - `avaliar_B41L.py`: o avaliador congelado;
  - `testar_B41L.py`: o teste sintético.
- **`originais/`:** idênticos aos da B41 (mesmos SHA-256):
  - os scripts da B1: c5a_photon_closure, c5a_g0g_backreaction, c5a_curl_curl_emergente (com malha.py) e
    c5a_holonomia_loops;
  - `rodar_bloco.py`, `avaliar_B1.py`, `b8_isotropia.py`, `avaliar_B8.py` e o patch de parametrização.
- **`referencia/`:** as saídas gravadas da B1 e da B41 usadas como âncora ou como V0 do guia, com
  `FONTES_REFERENCIAS_B41L_2026-10-29_2000-clau.md`.
- **Caderno do Colab:** `HRF_B41L_Colab_2026-10-29_2000-clau.ipynb`.
- **Hashes:** `HRF_B41L_hashes_antes_da_execucao_2026-10-29_2000-clau.txt`.
