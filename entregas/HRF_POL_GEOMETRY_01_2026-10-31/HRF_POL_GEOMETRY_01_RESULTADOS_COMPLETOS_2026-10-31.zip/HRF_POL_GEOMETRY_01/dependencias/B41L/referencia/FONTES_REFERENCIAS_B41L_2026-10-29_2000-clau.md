# B41L — de onde vêm os arquivos de `referencia/`

**Mario José do Canto Filho, MD · Claude (`-clau`) · 29/10/2026**

Os arquivos desta pasta são saídas já gravadas da B1 (1–2/10) e da B41 (28/10), copiados sem nenhuma alteração. Eles
servem de âncora ou de V0 gravado. Nenhum entra num cálculo novo de física.

| Arquivo | Origem | Uso na B41L |
|---|---|---|
| `avaliacao_B1_original_B1_2026-10-02.json` | Drive, `C5A_B1_photon_closure_v2/avaliacao_B1.json` (id 1B_6CGqnr8VJa2cc07-JElURrkEfHbnrg; igual ao arquivo do Projeto com o mesmo nome) | âncoras A1 e A2 nas sementes da B1 |
| `avaliacao_B1_B41_2026-10-28.json` | `HRF_B41_RESULTADOS_com_M07c.zip` (Drive, id 1RFHcpMBhuInd_PQOfS7n6Z6ZGPDbD5st; SHA-256 do zip bfcd08cd…9699), `resultados/M02/avaliacao_B1_B41.json` | âncoras A1 e A2 nas sementes da B41 |
| `B1c_V0/B1c_2026120{1..6}.json` | Drive, `C5A_B1_photon_closure_v2/saidas/<semente>/B1c_<semente>.json` | V0 gravado do guia nas sementes da B1 |
| `B1c_V0/B1c_4102000{1..6}.json` | mesmo zip da B41, `resultados/M02/<semente>/B1c_<semente>.json` | V0 gravado do guia nas sementes da B41 |
| `B8_isotropia_B41_M03.json` | mesmo zip da B41, `resultados/M03/B8_isotropia.json` | âncora A3 (B8-2 em V0) |
| `avaliacao_B8_B41_2026-10-28.json` | mesmo zip da B41, `resultados/M03/avaliacao_B8_B41.json` | âncora A3 (decisão da B8 em V0) |
| `modelos_teste/B1a_41020001.json`, `modelos_teste/B1b_41020001.json` | mesmo zip da B41, `resultados/M02/41020001/` | só para o teste sintético do avaliador |

## SHA-256

```
3e223e4b4f589f1ba9a0d88393058de6b1f1f31d30375cab7089cdfdfae6eaf4  B1c_V0/B1c_20261201.json
e9ecfd32b9742c6f803e62d30e15ed88256d222c36df1f0cda1a67f3a647260d  B1c_V0/B1c_20261202.json
c93572d6a90b8a8c2d7c30bbe50e208639d958d0b260b4ea36fdfd315b3a7127  B1c_V0/B1c_20261203.json
fb27b6f820a07e1e8dfe9afb6517874c058f1474870fa9f212c75fb75a9665af  B1c_V0/B1c_20261204.json
f8eea4bf331fbf974250f717c56752050bc50823e4ccba5ddc18d6d761d5659d  B1c_V0/B1c_20261205.json
62b99c381ea5afd68e443ace3f97e73d53cfa772d17611d3400de4f174fb68d3  B1c_V0/B1c_20261206.json
5b44028a588f79ae74ddfc796b8e3fbdf6cbe2efe6eb8ae9f52b95e77e201327  B1c_V0/B1c_41020001.json
7ee435279d93c0d953d668a82ed7c71d614e369d2c38f4d11fe5bc2054048e06  B1c_V0/B1c_41020002.json
4ff92d9c8a373692b9cf2a03397eac8d4d890689376fed3dc1122d0af32f39d6  B1c_V0/B1c_41020003.json
30d53fa02467e2d77958da346f3b60eb0e87e97811ddcfbdc756636750563544  B1c_V0/B1c_41020004.json
65f1c2d2d508678ec7a002a8bd811fe9bdbd54e76beb8837ed3b112f7065d46d  B1c_V0/B1c_41020005.json
be586a8ce7c11fd3ee819e2807d1088b305320edab7c8034af4d34393cdbdbff  B1c_V0/B1c_41020006.json
7fc050f599a3d5b8b8b94abc09790032c57879cdab2f8bfc2b1986c240f34608  B8_isotropia_B41_M03.json
2054ae609541cdeebdc4dccfcaca7a0034d6d0299a730f648226b94b76179e7f  avaliacao_B1_B41_2026-10-28.json
3e79493a24d1654fc74bb4076e88530e38f7dc7707b777f7b535335a20c5d73f  avaliacao_B1_original_B1_2026-10-02.json
518f92d41003938ddce3b60cd2b8b477f1392ec1e7b26287607094ec74901fcd  avaliacao_B8_B41_2026-10-28.json
36dc0162cc6efeedccab042ee49ae379a29a20ab6617a09b2c74263dcb9808f6  modelos_teste/B1a_41020001.json
cbf751b611cacef1b5ade3f9c703f4f6cc327c9d5c32f590cf50ef36ad0bde30  modelos_teste/B1b_41020001.json
```

Uma ressalva sobre o V0 gravado do guia: a B1 grava os valores do guia com 3 algarismos (`sig(…, 3)`). O avaliador
original da B1 usou esses mesmos valores arredondados em 2/10 e em 28/10, e o V0 desta bancada os usa do mesmo jeito.
