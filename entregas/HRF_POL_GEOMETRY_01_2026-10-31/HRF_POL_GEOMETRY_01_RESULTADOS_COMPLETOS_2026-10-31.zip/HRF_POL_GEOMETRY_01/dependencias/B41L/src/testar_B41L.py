#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — teste sintético. NÃO monta malha nenhuma e NÃO roda física.

1. Estatística: Clopper–Pearson, McNemar exato, P(P1 passa), bootstrap determinístico.
2. Álgebra linear da limpeza num grafo aleatório de 9 nós (não é malha): Q_T sem carga, gradiente → 0, idempotência,
   entrada complexa, decomposição de Pitágoras na métrica M1 e a identidade de Rayleigh R(Q) = R(Q_T)(1 − δ²) com um
   K que anula os gradientes. Estrutura do gradiente da rede cúbica (somas por linha e grau dos nós).
3. Avaliador: saídas FALSAS montadas a partir das saídas gravadas (referencia/), em cinco cenários, conferindo cada
   ramo das regras congeladas (Q1–Q4, âncoras, INCOMPLETO). O avaliador original da B1 e o da B8 rodam sobre elas.
Uso: python -I src/testar_B41L.py   → termina com "N testes; TODOS OS RAMOS CONFEREM"
"""
from __future__ import annotations

import copy
import json
import math
import shutil
import sys
import tempfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import scipy.sparse as sp  # noqa: E402

import b41l_comum as B  # noqa: E402

N_OK = [0]


def confere(cond, nome):
    if not cond:
        raise SystemExit(f"FALHOU: {nome}")
    N_OK[0] += 1
    print(f"  ok  {nome}")


# ------------------------------------------------------------------------------------------- 1. estatística
def testar_estatistica():
    lo, hi = B.clopper_pearson(0, 30)
    confere(lo == 0.0 and abs(hi - 0.11570) < 2e-4, f"Clopper–Pearson 0/30 → [0; {hi:.4f}]")
    lo, hi = B.clopper_pearson(3, 20)
    confere(abs(lo - 0.0321) < 5e-4 and abs(hi - 0.3789) < 5e-4, f"Clopper–Pearson 3/20 → [{lo:.4f}; {hi:.4f}]")
    confere(abs(B.mcnemar_unilateral(10, 0) - 2 ** -10) < 1e-15, "McNemar b = 10, c = 0 → 2⁻¹⁰")
    confere(abs(B.mcnemar_unilateral(3, 1) - 5 / 16) < 1e-15, "McNemar b = 3, c = 1 → 5/16")
    confere(abs(B.p1_passa(0.15) - 0.5443) < 1e-3, f"P(P1 passa | f = 0,15) = {B.p1_passa(0.15):.4f}")
    confere(B.p1_passa(0.0) == 1.0, "P(P1 passa | f = 0) = 1")
    m1, ic1 = B.boot_media([1.0, 2.0, 3.0, 4.0])
    m2, ic2 = B.boot_media([1.0, 2.0, 3.0, 4.0])
    confere(m1 == 2.5 and ic1 == ic2 and ic1[0] < 2.5 < ic1[1], "bootstrap da média determinístico")
    xi, ze = B.ajuste_xi([0.1, 0.2, 0.4], [1 - 0.02 * 0.1, 1 - 0.02 * 0.2, 1 - 0.02 * 0.4])
    confere(abs(xi - 0.02) < 1e-12 and abs(ze) < 1e-10, "ajuste de ξ (forma da B8) recupera ξ = 0,02")


# ------------------------------------------------------------------------------------------- 2. álgebra da limpeza
def grafo(rng, n=9, extras=10):
    arestas = [(i, (i + 1) % n) for i in range(n)]
    while len(arestas) < n + extras:
        a, b = sorted(rng.choice(n, 2, replace=False))
        if (a, b) not in arestas:
            arestas.append((a, b))
    E = len(arestas)
    r = np.r_[np.arange(E), np.arange(E)]
    c = np.r_[[a for a, _ in arestas], [b for _, b in arestas]]
    return sp.csr_matrix((np.r_[-np.ones(E), np.ones(E)], (r, c)), shape=(E, n))


def testar_limpeza():
    import b41l_limpeza as LZ
    rng = np.random.default_rng(7)
    d0 = grafo(rng)
    E, N = d0.shape
    X = rng.normal(size=(E, E))
    M1 = sp.csr_matrix(X @ X.T + E * np.eye(E))                  # SPD qualquer
    lim = LZ.Limpador(d0, M1, periodico=True)                     # núcleo = constantes (como na caixa periódica)
    Q = rng.normal(size=E) + 1j * rng.normal(size=E)
    QT, d = lim.limpar(Q)
    confere(d["res_transversal"] < 1e-12 and d["res_lambda"] < 1e-12, f"Q_T sem carga (resíduo {d['res_transversal']:.1e})")
    QT2, d2 = lim.limpar(QT)
    confere(np.linalg.norm(QT2 - QT) < 1e-12 * np.linalg.norm(QT) and d2["delta2"] < 1e-24, "limpeza idempotente")
    phi = rng.normal(size=N)
    G, dg = lim.limpar(d0 @ phi)
    confere(np.linalg.norm(G) < 1e-12 * np.linalg.norm(d0 @ phi) and abs(dg["delta2"] - 1) < 1e-12, "gradiente puro → 0")
    QL = Q - QT
    n = lambda x: float(np.real(np.vdot(x, M1 @ x)))  # noqa: E731
    confere(abs(n(Q) - n(QT) - n(QL)) < 1e-10 * n(Q) and abs(d["delta2"] - n(QL) / n(Q)) < 1e-12, "Pitágoras na métrica M1")
    P = np.eye(E) - d0 @ np.linalg.pinv((d0.T @ d0).toarray()) @ d0.T
    Cm = rng.normal(size=(E, E)) @ P
    K = sp.csr_matrix(Cm.T @ Cm)                                    # K d0 = 0, como d1ᵀ M2 d1
    confere(np.abs(K @ d0.toarray()).max() < 1e-10, "K de teste anula gradientes")
    confere(abs(LZ.rayleigh(Q, K, M1) - LZ.rayleigh(QT, K, M1) * (1 - d["delta2"])) < 1e-12 * LZ.rayleigh(QT, K, M1),
            "identidade de Rayleigh R(Q) = R(Q_T)(1 − δ²)")
    sel = np.arange(1, N)                                           # "parede": o nó 0 fora de d0 → matriz invertível
    lim2 = LZ.Limpador(d0[:, sel], M1, periodico=False)
    QT3, d3 = lim2.limpar(Q.real)
    confere(d3["res_transversal"] < 1e-12 and np.isrealobj(QT3), "limpeza sem núcleo (guia), entrada real")
    ea, eb = LZ.base_transversal(np.array([1.0, 1.0, 1.0]))
    kh = np.ones(3) / math.sqrt(3)
    confere(abs(ea @ kh) < 1e-15 and abs(eb @ kh) < 1e-15 and abs(ea @ eb) < 1e-15 and abs(np.linalg.norm(eb) - 1) < 1e-15,
            "base transversal ortonormal")
    dc = LZ.d0_cubica(3)
    confere(dc.shape == (81, 27) and np.abs(dc.sum(1)).max() == 0 and np.all(np.abs(dc).sum(0) == 6),
            "gradiente da rede cúbica: linhas somam 0, 6 ligações por nó")


# ------------------------------------------------------------------------------------------- 3. avaliador
REF = B.REF
TPL_A = B.carregar_json(REF / "modelos_teste" / "B1a_41020001.json")
TPL_B = B.carregar_json(REF / "modelos_teste" / "B1b_41020001.json")
TPL_C = B.carregar_json(REF / "B1c_V0" / "B1c_20261201.json")
FALHA_GUIA = B.carregar_json(REF / "B1c_V0" / "B1c_41020005.json")     # Δ_hel = 1,99 em h = 0,55 (item 7 falha)


def cfg_teste(n=10):
    cfg = B.config_perfil("completo")
    cfg["conjuntos"] = {"B1": B.SEMENTES_B1[:n], "B41": B.SEMENTES_B41[:n], "N": B.SEMENTES_N[:n]}
    cfg["guia"] = {k: v[:6] for k, v in cfg["conjuntos"].items()}
    cfg["usar_referencias"] = False
    cfg["v0_guia_referencia"] = []
    cfg["v0_guia_rodar"] = [s for k in cfg["guia"] for s in cfg["guia"][k]]
    cfg["conferir_v0_real"] = [[B.SEMENTES_N[0], 10]]
    return cfg


def gravar_A(pasta, s, fator_v1e=0.6, quebra_espelho=False):
    pa = pasta / "A" / str(s)
    for v in B.VARIANTES:
        o = copy.deepcopy(TPL_A)
        o["semente"] = s
        o["variante"] = v
        if v == "V1E":
            for l in o["tabelas"]["dispersao.csv"]:
                l["omega/ck"] = 1 - fator_v1e * (1 - l["omega/ck"])
        B.salvar_json_bloco(pa / f"B1a_{v}_{s}.json", o)
        if v in ("V0", "V1E"):
            B.salvar_csv_como_B1(pa / v / "c5a_photon_closure_dispersao.csv", o["tabelas"]["dispersao.csv"])
    lz = {"res_lambda": 1e-15, "res_transversal": 1e-15, "delta2": [1e-3, 1e-3]}
    s8 = [{"omega_cru/ck": 0.99, "omega_limpo/ck": 0.995, "delta2": 1 - (0.99 / 0.995) ** 2, "res_lambda": 1e-15,
           "res_transversal": 1e-15}]
    B.salvar_json(pa / f"diagnostico_B1a_{s}.json", {"espelho_S7_confere": not quebra_espelho, "espelho_S8_confere": True,
                                                     "S7_V1E_limpeza": [lz], "S8_V1_limpeza": s8})


def gravar_B(pasta, s, dpz_v0=None, dpz_v1=None, conferir=False):
    lin = TPL_B["tabelas"]["conservacao.csv"]
    Ns = sorted({l["GMFs"] for l in lin})
    for lado, N in zip((10, 14, 18), Ns):
        serie = np.array([[l["t"], l["dE/E"], l["dPz/Pz"], l["fracao_h+"], l["gauss"]] for l in lin if l["GMFs"] == N])
        s0, s1 = serie.copy(), serie.copy()
        if dpz_v0 is not None and lado == 10:
            s0[1:, 2] = dpz_v0
        if dpz_v1 is not None and lado == 10:
            s1[1:, 2] = dpz_v1
        o = {"N": N, "dt": 0.02, "T": 20.0, "V0": {"serie": s0.tolist()}, "V1": {"serie": s1.tolist()},
             "longitudinal": {"res_lambda": 1e-15, "res_transversal": 1e-15, "omega_cru/ck": 0.99, "omega_limpo/ck": 0.995},
             "omega_din/ck": {"metrica_M1": 0.9948, "metrica_M1quadrado": 0.9949}}
        if conferir and lado == 10:
            o["conferencia_v0_real"] = {"max_dif_fracao": 1e-14, "max_dif_dE_E": 1e-14, "max_dif_dPz_Pz": 1e-14}
        B.salvar_json(pasta / "B" / f"B_{s}_{lado}.json", o)


def gravar_C(pasta, s, falha_v0=False, falha_v1=False):
    r0 = copy.deepcopy(FALHA_GUIA["R"] if falha_v0 else TPL_C["R"])
    r1 = copy.deepcopy(FALHA_GUIA["R"] if falha_v1 else TPL_C["R"])
    # malhas iguais por construção nos dois (a conferência A4 olha GMFs e C1/C2)
    if falha_v0 != falha_v1:
        alvo = r1 if falha_v0 else r0
        fonte = r0 if falha_v0 else r1
        for x, y in zip(alvo["S2_S11_S12_guia"]["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"],
                        fonte["S2_S11_S12_guia"]["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"]):
            x["GMFs"] = y["GMFs"]
        for g in ("C1 poço fundo", "C2 vale"):
            alvo["S11_fundos_curvos"][g] = copy.deepcopy(fonte["S11_fundos_curvos"][g])
        alvo["S11_fundos_curvos"]["C3 girante"]["GMFs"] = fonte["S11_fundos_curvos"]["C3 girante"]["GMFs"]
    B.salvar_json(pasta / "C" / f"C_{s}.json", {"variantes": {"V0": {"R": r0}, "V1": {"R": r1}}})


def gravar_F_B8(pasta, cubica_ok=True):
    B.salvar_json(pasta / "F" / "F.json", {"guia": {"max_dif": 0.0},
                                           "girante": {"resultados_identicos": True, "mesmo_estado_do_gerador": True}})
    ref = B.carregar_json(REF / "B8_isotropia_B41_M03.json")
    B.salvar_json(pasta / "B8" / "B8_isotropia_V0.json", ref)
    v1 = copy.deepcopy(ref)
    if not cubica_ok:
        for r in v1["cubica_controle"].values():
            for x in r.values():
                x["xi"] *= 1.01
    B.salvar_json(pasta / "B8" / "B8_isotropia_V1E.json", v1)
    lz = [{"res_lambda": 1e-15, "res_transversal": 1e-15}]
    B.salvar_json(pasta / "B8" / "diagnostico_B8.json", {"delaunay": {"x": lz}, "N6": {"y": lz}, "cubica": {}})


def cenario(nome, *, falhas_v0=(), falhas_v1=(), fator_v1e=0.6, cubica_ok=True, faltar=None, quebra_espelho=False):
    """falhas_*: lista de (semente, tipo) com tipo 'cons' (ΔP_z/P_z alto em 10³) ou 'guia' (Δ_hel = 1,99)."""
    pasta = Path(tempfile.mkdtemp(prefix=f"b41l_{nome}_"))
    cfg = cfg_teste()
    B.salvar_json(pasta / "config_B41L.json", cfg)
    f0, f1 = set(falhas_v0), set(falhas_v1)
    for s in B.todas_sementes(cfg):
        gravar_A(pasta, s, fator_v1e=fator_v1e, quebra_espelho=quebra_espelho and s == cfg["conjuntos"]["B1"][0])
        gravar_B(pasta, s, dpz_v0=0.05 if (s, "cons") in f0 else None, dpz_v1=0.05 if (s, "cons") in f1 else None,
                 conferir=[s, 10] in cfg["conferir_v0_real"])
        if s in B.sementes_guia(cfg):
            gravar_C(pasta, s, falha_v0=(s, "guia") in f0, falha_v1=(s, "guia") in f1)
    gravar_F_B8(pasta, cubica_ok=cubica_ok)
    if faltar:
        (pasta / faltar).unlink()
    import avaliar_B41L as AV
    o = AV.avaliar(pasta)
    shutil.rmtree(pasta, ignore_errors=True)
    return o


def testar_avaliador():
    S1, S41, SN = B.SEMENTES_B1, B.SEMENTES_B41, B.SEMENTES_N
    print("cenário 1: a limpeza resolve (falhas de preparação só em V0); estimador com viés de 40%")
    o = cenario("resolve", falhas_v0=[(S1[0], "cons"), (S41[3], "cons"), (S41[4], "guia"), (SN[1], "guia")])
    confere(o["Q1"]["B1"]["V0"]["decisao"] == "PHOTON-CLOSURE-E FECHADO (toy model)", "V0, conjunto B1: 9/10 → FECHADO")
    confere(o["Q1"]["B41"]["V0"]["decisao"].startswith("NÃO FECHADO") and "P1" in o["Q1"]["B41"]["V0"]["decisao"],
            "V0, conjunto B41: 8/10 → NÃO FECHADO (P1)")
    confere(all(o["Q1"][k]["V1"]["decisao"] == "PHOTON-CLOSURE-E FECHADO (toy model)" for k in ("B1", "B41", "N")),
            "V1 fecha nos três conjuntos")
    confere(o["Q1"]["classe"] == "FECHA_NOS_3", "Q1 = FECHA_NOS_3")
    confere(o["Q2"]["classe"] == "LIMPEZA_RESOLVE_SEM_REGRESSAO" and len(o["Q2"]["b_resolvidas"]) == 4, "Q2 resolve 4, sem regressão")
    confere(abs(o["Q2"]["mcnemar_p_unilateral"] - 1 / 16) < 1e-12, "McNemar b = 4 → 1/16")
    confere(o["Q3"]["classe"] == "FALHAS_DE_PREPARACAO_ELIMINADAS" and o["Q3"]["V0"]["com_falha_de_lancamento"] == 4,
            "Q3 = ELIMINADAS (4 → 0)")
    confere("7_compensado_nao_seleciona_helicidade" in o["Q3"]["V0"]["falhas"][str(S41[4])], "falha do guia classificada como item 7")
    confere("8c_girante_e_gauss_do_guia" not in o["Q3"]["V0"]["falhas"].get(str(S41[4]), []), "item 8 dividido em 8a/8c")
    confere(abs(o["Q4"]["r_xi_V1E_sobre_V0"]["media"] - 0.6) < 1e-6, f"Q4: r = {o['Q4']['r_xi_V1E_sobre_V0']['media']:.6f}")
    confere(o["Q4"]["classe"] == "VIES_IMPORTANTE", "Q4 = VIES_IMPORTANTE")
    x = o["Q4"]["B8_original_V0_V1E"]["B1"]
    confere(x["xi_V1E"] < x["xi_V0"] and x["a_max_m_V1E"] > x["a_max_m_V0"], "B8 original: ξ cai e a_max sobe com V1E")
    confere(o["veredito"].startswith("B1_FECHA_COM_LANCAMENTO_LIMPO") and "INCOMPLETO" not in o["veredito"]
            and "âncora" not in o["veredito"], f"veredito: {o['veredito']}")
    confere(o["ancoras"]["A4_malhas_do_guia"]["ok"] and o["ancoras"]["A5_fidelidade"]["ok"] and o["ancoras"]["A6_internas"]["ok"],
            "âncoras A4, A5, A6 conferem")

    print("cenário 2: regressão (V1 cria falhas)")
    o = cenario("regressao", falhas_v0=[(S41[0], "cons")], falhas_v1=[(S1[1], "cons"), (S1[2], "guia")])
    confere(o["Q2"]["classe"] == "LIMPEZA_RESOLVE_COM_REGRESSAO" and len(o["Q2"]["c_regressoes"]) == 2, "Q2 = RESOLVE_COM_REGRESSAO")
    confere(o["Q3"]["classe"] == "FALHAS_DE_PREPARACAO_NAO_REDUZIDAS", "Q3 = NÃO REDUZIDAS (1 → 2)")
    confere(o["Q1"]["B1"]["V1"]["decisao"].startswith("NÃO FECHADO") and o["veredito"].startswith("B1_NAO_FECHA"),
            "conjunto B1 em V1: 8/10 → NÃO FECHADO; veredito acompanha")
    confere(o["Q1"]["classe"] == "FECHA_EM_2_DE_3", "Q1 = FECHA_EM_2_DE_3")

    print("cenário 3: sem falhas; estimador sem viés")
    o = cenario("limpo", fator_v1e=0.98)
    confere(o["Q2"]["classe"] == "SEM_EFEITO" and o["Q3"]["classe"] == "SEM_FALHAS_DE_PREPARACAO_EM_V0", "Q2 = SEM_EFEITO; Q3 = SEM_FALHAS")
    confere(o["Q4"]["classe"] == "ESTIMADOR_SEM_VIES_RELEVANTE", "Q4 = SEM VIÉS RELEVANTE (r = 0,98)")
    o2 = cenario("pequeno", fator_v1e=0.9)
    confere(o2["Q4"]["classe"] == "VIES_PEQUENO", "Q4 = VIÉS PEQUENO (r = 0,90)")

    print("cenário 4: controle cúbico falha; espelho quebrado")
    o = cenario("cubica", cubica_ok=False, quebra_espelho=True)
    confere(o["Q4"]["classe"].startswith("INCONCLUSIVO"), "Q4 = INCONCLUSIVO quando a rede cúbica muda com a limpeza")
    confere("A6_internas" in o["veredito"], "veredito marca a âncora interna quebrada")

    print("cenário 5: saída faltando")
    o = cenario("falta", faltar=f"B/B_{S1[3]}_18.json")
    confere(o["veredito"].startswith("INCOMPLETO") and f"B/B_{S1[3]}_18" in o["saidas_faltando"], "INCOMPLETO com a saída listada")

    print("âncoras contra as saídas gravadas")
    import avaliar_B41L as AV
    ref = B.carregar_json(REF / "avaliacao_B1_original_B1_2026-10-02.json")
    d = ref["por_semente"]["20261204"]
    confere(AV.ancora_semente(copy.deepcopy(d), d)["ok"], "âncora por semente: idêntico → confere")
    dd = copy.deepcopy(d)
    dd["eps"]["1000"]["eps"] += 5e-10
    confere(AV.ancora_semente(dd, d)["B1b"] == "CONFERE", "âncora B1b: |Δε| = 5e-10 → CONFERE")
    dd["eps"]["1000"]["eps"] += 1e-7
    confere(AV.ancora_semente(dd, d)["B1b"] == "TOLERANCIA", "âncora B1b: |Δε| = 1e-7 → TOLERÂNCIA")
    dd = copy.deepcopy(d)
    dd["serie"]["p_e2"] += 1e-9
    confere(AV.ancora_semente(dd, d)["B1a"] == "NAO_CONFERE", "âncora B1a: p muda 1e-9 → NÃO CONFERE")
    pasta = Path(tempfile.mkdtemp(prefix="b41l_b8_"))
    gravar_F_B8(pasta)
    confere(AV.ancora_b8(pasta)["classe"] == "BIT_A_BIT", "âncora B8: cópia da M03 → BIT_A_BIT")
    j = B.carregar_json(pasta / "B8" / "B8_isotropia_V0.json")
    j["delaunay"]["20|41030003"]["direcoes"]["(1, 0, 0)"]["xi"] += 1e-9
    B.salvar_json(pasta / "B8" / "B8_isotropia_V0.json", j)
    confere(AV.ancora_b8(pasta)["classe"] == "TOLERANCIA", "âncora B8: Δξ = 1e-9 → TOLERÂNCIA")
    shutil.rmtree(pasta, ignore_errors=True)


def main():
    print("1. estatística")
    testar_estatistica()
    print("2. álgebra da limpeza (grafo de 9 nós, sem malha)")
    testar_limpeza()
    print("3. avaliador (saídas falsas)")
    testar_avaliador()
    print(f"{N_OK[0]} testes; TODOS OS RAMOS CONFEREM")


if __name__ == "__main__":
    main()
