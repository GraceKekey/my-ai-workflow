#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — avaliador congelado (protocolo, §7). Escrito antes de qualquer saída real.

1. Monta, para cada variante (V0, V1, V1E) e semente, os arquivos B1a/B1b/B1c no formato de rodar_bloco.py:
   - B1a: direto das saídas do bloco A;
   - B1b: junta as três malhas do bloco B no dicionário de PC.s_conservacao (V0 reconstruído, V1 limpo; V1E = V1);
   - B1c: V1 do bloco C; V0 das saídas gravadas (B1 e B41) ou do bloco C (sementes novas); V1E = V1.
2. Roda o avaliador ORIGINAL da B1 (`originais/avaliar_B1.py`, só trocando as listas de sementes) em cada variante e
   conjunto, e o ORIGINAL da B8 (`originais/avaliar_B8.py`) em V0 e V1E.
3. Âncoras (A1–A6), perguntas Q1–Q4 e veredito, pelas regras congeladas.
Uso: python -I src/avaliar_B41L.py <pasta_saidas>   (grava avaliacao_B41L.json e resumo_B41L.md na pasta)
"""
from __future__ import annotations

import io
import json
import math
import shutil
import sys
import traceback
from contextlib import redirect_stdout
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402

import b41l_comum as B  # noqa: E402

FECHADO = "PHOTON-CLOSURE-E FECHADO (toy model)"
J_TEXTO = ("a malha aleatória não tem simetria de rotação exata: J_z não é conservado exatamente; "
           "a fração de helicidade (projeção nas ondas h = ±1) é o que se mede")
LISTAS_SERIE = ("Nem", "e2_h+1", "e2_linear", "residuo_hel", "a1", "a2", "omega_ck_m1")
ESCALARES_SERIE = ("p_e2", "p_e2l", "p_hel")


def _sig(x, n):
    return float(f"{x:.{n}g}")


def _zero_ou(x, n=3, tol=1e-10):
    return "zero (< 1e-10)" if abs(x) < tol else _sig(x, n)


def eh_zero(x):
    return x == "zero (< 1e-10)"


def chamar_original(modulo, argv, **globais):
    """Roda main() de um avaliador original com argv e globais trocados (só as listas de sementes)."""
    mod = __import__(modulo)
    antigos = {k: getattr(mod, k) for k in globais}
    for k, v in globais.items():
        setattr(mod, k, v)
    argv0 = sys.argv
    sys.argv = [modulo + ".py"] + [str(a) for a in argv]
    buf = io.StringIO()
    try:
        with redirect_stdout(buf):
            mod.main()
    finally:
        sys.argv = argv0
        for k, v in antigos.items():
            setattr(mod, k, v)
    return buf.getvalue()


# ------------------------------------------------------------------------------------------------ 1. variantes
def bloco_b(outs, variante, semente):
    """Dicionário de PC.s_conservacao a partir das saídas por malha (na ordem de RES_CONS)."""
    R, linhas = {}, []
    for o in outs:
        s = np.array(o[variante]["serie"], float)
        N = o["N"]
        for row in s:
            linhas.append({"GMFs": N, "t": float(row[0]), "dE/E": float(row[1]), "dPz/Pz": float(row[2]),
                           "fracao_h+": float(row[3]), "gauss": float(row[4])})
        R[f"GMFs = {N}"] = {"dt": _sig(o["dt"], 3), "T": o["T"],
                            "máx |ΔE/E|": _sig(float(np.abs(s[:, 1]).max()), 3),
                            "máx |ΔP_z/P_z|": _sig(float(np.abs(s[:, 2]).max()), 3),
                            "fração na helicidade h = +1 (início, mínimo)": [_sig(float(s[0, 3]), 5), _sig(float(s[:, 3].min()), 5)],
                            "lei de Gauss |Δ(d0ᵀπ)|/|π| (máx)": _zero_ou(float(s[:, 4].max()))}
    R["momento angular J"] = J_TEXTO
    return {"bloco": "B1b", "semente": semente, "variante": variante, "R": {"S9_S15_conservacao": R},
            "tabelas": {"conservacao.csv": linhas}}


def montar_variantes(pasta, cfg, dest):
    faltando = []
    for s in B.todas_sementes(cfg):
        pa = pasta / "A" / str(s)
        for v in B.VARIANTES:
            f = pa / f"B1a_{v}_{s}.json"
            if f.exists():
                (dest / v / str(s)).mkdir(parents=True, exist_ok=True)
                shutil.copyfile(f, dest / v / str(s) / f"B1a_{s}.json")
                csv = pa / ("V1E" if v == "V1E" else "V0") / "c5a_photon_closure_dispersao.csv"
                if csv.exists():
                    shutil.copyfile(csv, dest / v / str(s) / "c5a_photon_closure_dispersao.csv")
            else:
                faltando.append(f"A/{s}/B1a_{v}")
        outs = [B.carregar_json(pasta / "B" / f"B_{s}_{l}.json") for l in cfg["ordem_cons"]]
        if all(o is not None for o in outs):
            for v in B.VARIANTES:
                B.salvar_json_bloco(dest / v / str(s) / f"B1b_{s}.json", bloco_b(outs, "V0" if v == "V0" else "V1", s))
        else:
            faltando += [f"B/B_{s}_{l}" for l, o in zip(cfg["ordem_cons"], outs) if o is None]
        if s in B.sementes_guia(cfg):
            c = B.carregar_json(pasta / "C" / f"C_{s}.json")
            if c is None:
                faltando.append(f"C/C_{s}")
            else:
                for v in ("V1", "V1E"):
                    B.salvar_json_bloco(dest / v / str(s) / f"B1c_{s}.json",
                                        {"bloco": "B1c", "semente": s, "variante": v, "R": c["variantes"]["V1"]["R"]})
                if s in cfg["v0_guia_referencia"]:
                    ref = B.carregar_json(B.REF / "B1c_V0" / f"B1c_{s}.json")
                    B.salvar_json_bloco(dest / "V0" / str(s) / f"B1c_{s}.json",
                                        {"bloco": "B1c", "semente": s, "variante": "V0 (gravado)", "R": ref["R"]})
                elif "V0" in c["variantes"]:
                    B.salvar_json_bloco(dest / "V0" / str(s) / f"B1c_{s}.json",
                                        {"bloco": "B1c", "semente": s, "variante": "V0", "R": c["variantes"]["V0"]["R"]})
                else:
                    faltando.append(f"C/C_{s} (V0)")
    return faltando


# ------------------------------------------------------------------------------------------------ itens extras
def item8_partes(Rc):
    cu = Rc["S11_fundos_curvos"]
    dh = Rc["S2_S11_S12_guia"]["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"]
    a = all(cu[g]["convergência"][-1]["eps contra ∇×(1/n)∇×"] < 0.03 and
            all(eh_zero(x["|K∇φ|/|Kq| (gauge)"]) for x in cu[g]["convergência"]) for g in ("C1 poço fundo", "C2 vale"))
    c3 = cu["C3 girante"]
    c = (all(abs(m - p) < 0.1 * abs(p) for m, p in zip(c3["Δω(+J, +1), Δω(−J, +1), Δω(+J, −1), Δω(−J, −1)"],
                                                       c3["previsto (rotação rígida, m = −h): Δω(J, h) = −h·J"]))
         and all(eh_zero(x["gauss"]) for x in dh))
    return {"8a_operador_em_fundo_curvo": bool(a), "8c_girante_e_gauss_do_guia": bool(c)}


def item6(d):
    """Item 6 da B1 (fora do P1 da B1; descritivo): resíduo de helicidade cai com ordem > 0,8 e f_min > 0,99 em tudo."""
    if "serie" not in d or "eps" not in d:
        return None
    hr = d["serie"]["residuo_hel"]
    mono = all(b < a for a, b in zip(hr[:-1], hr[1:]))
    return bool(mono and d["serie"]["p_hel"] > 0.8 and all(v["eps"] < 1 - B.LIMIAR_F for v in d["eps"].values()))


def itens_semente(av, dest, v, s, guia):
    d = av["por_semente"][str(s)]
    it = dict(d["itens"])
    if s in guia:
        c = B.carregar_json(dest / v / str(s) / f"B1c_{s}.json")
        if c is not None:
            it.update(item8_partes(c["R"]))
    falhas = sorted(k for k, x in it.items() if not x and k != "8_gauge_sobrevive_a_geometria_curva")
    return {"itens": it, "todos": bool(d["todos"]), "falhas": falhas,
            "falhas_lancamento": [k for k in falhas if k in B.ITENS_LANCAMENTO],
            "falhas_outras": [k for k in falhas if k in B.ITENS_OUTROS], "item6": item6(d)}


# ------------------------------------------------------------------------------------------------ âncoras
def ancora_semente(d, r):
    ser = all(d["serie"][k] == r["serie"][k] for k in LISTAS_SERIE) and \
        all(abs(d["serie"][k] - r["serie"][k]) <= B.TOL_BIT for k in ESCALARES_SERIE)
    dif = 0.0
    for N, rv in r["eps"].items():
        dv = d["eps"].get(str(N))
        if dv is None:
            dif = float("inf")
            continue
        dif = max(dif, abs(dv["eps_inicio"] - rv["eps_inicio"]), abs(dv["eps"] - rv["eps"]), abs(dv["deriva"] - rv["deriva"]))
    cls_b = "CONFERE" if dif <= B.TOL_RECONS else ("TOLERANCIA" if dif <= B.TOL_ANCORA else "NAO_CONFERE")
    itens = d["itens"] == r["itens"]
    guia = d.get("guia") == r.get("guia")
    return {"B1a": "BIT_A_BIT" if ser else "NAO_CONFERE", "B1b": cls_b, "B1b_max_dif_eps": dif,
            "itens_iguais": itens, "guia_igual": guia,
            "ok": ser and cls_b != "NAO_CONFERE" and itens and guia}


def ancora_b8(pasta):
    v0 = B.carregar_json(pasta / "B8" / "B8_isotropia_V0.json")
    ref = B.carregar_json(B.REF / "B8_isotropia_B41_M03.json")
    if v0 is None:
        return {"classe": "SEM_DADOS"}
    dmax = 0.0
    for sec in ("delaunay", "cubica_controle", "N6_controle"):
        for k, rv in ref[sec].items():
            dv = v0[sec].get(k)
            if dv is None:
                return {"classe": "NAO_CONFERE", "falta": f"{sec}/{k}"}
            rd = rv["direcoes"] if "direcoes" in rv else rv
            dd = dv["direcoes"] if "direcoes" in dv else dv
            for d, x in rd.items():
                dmax = max(dmax, abs(dd[d]["c0"] - x["c0"]), abs(dd[d]["xi"] - x["xi"]))
    return {"classe": "BIT_A_BIT" if dmax <= B.TOL_BIT else ("TOLERANCIA" if dmax <= B.TOL_ANCORA else "NAO_CONFERE"),
            "max_dif": dmax}


def malhas_guia(Rv1, Rv0):
    g1 = [x["GMFs"] for x in Rv1["S2_S11_S12_guia"]["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"]]
    g0 = [x["GMFs"] for x in Rv0["S2_S11_S12_guia"]["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"]]
    c1, c0 = Rv1["S11_fundos_curvos"], Rv0["S11_fundos_curvos"]
    cc = all(c1[g] == c0[g] for g in ("C1 poço fundo", "C2 vale"))
    gir = c1["C3 girante"]["GMFs"] == c0["C3 girante"]["GMFs"] and c1["C3 girante"]["|G∇φ| / |Gq|"] == c0["C3 girante"]["|G∇φ| / |Gq|"]
    return {"GMFs_guia_V1": g1, "GMFs_guia_V0": g0, "C1_C2_iguais": cc, "girante_igual": gir,
            "ok": g1 == g0 and cc and gir}


# ------------------------------------------------------------------------------------------------ principal
def avaliar(pasta):
    pasta = Path(pasta)
    cfg = B.carregar_json(pasta / "config_B41L.json")
    if cfg is None:
        raise SystemExit(f"sem config_B41L.json em {pasta}")
    fumaca = cfg["perfil"] != "completo"
    dest = pasta / "avaliacao"
    if dest.exists():
        shutil.rmtree(dest)
    dest.mkdir(parents=True)
    out = {"bancada": "B41L", "perfil": cfg["perfil"], "avaliado_em": B.agora(), "versoes_avaliador": B.versoes()}
    faltando = montar_variantes(pasta, cfg, dest)
    out["saidas_faltando"] = faltando
    erros = []
    conj = {k: v for k, v in cfg["conjuntos"].items() if v}
    guia_all = set(B.sementes_guia(cfg))
    # ---------------------------------------------------- avaliador original da B1
    avB1 = {}
    for v in B.VARIANTES:
        for k, sem in conj.items():
            arq = dest / f"avaliacao_B1_{v}_{k}.json"
            try:
                log = chamar_original("avaliar_B1", [dest / v, arq], SEMENTES_A=list(sem), SEMENTES_C=list(cfg["guia"][k]))
                avB1[(v, k)] = B.carregar_json(arq)
                avB1[(v, k)]["_log"] = log
            except Exception as e:  # noqa: BLE001
                erros.append(f"avaliar_B1 {v} {k}: {e!r}")
                avB1[(v, k)] = None
    # ---------------------------------------------------- avaliador original da B8 (V0 e V1E)
    avB8 = {}
    for v in ("V0", "V1E"):
        b8 = pasta / "B8" / f"B8_isotropia_{v}.json"
        for k, sem in conj.items():
            if avB1.get((v, k)) is None or not b8.exists():
                avB8[(v, k)] = None
                continue
            arq = dest / f"avaliacao_B8_{v}_{k}.json"
            try:
                chamar_original("avaliar_B8", [dest / v, dest / f"avaliacao_B1_{v}_{k}.json", b8, arq], SEMENTES_B1=list(sem))
                avB8[(v, k)] = B.carregar_json(arq)
            except Exception as e:  # noqa: BLE001
                erros.append(f"avaliar_B8 {v} {k}: {e!r}")
                avB8[(v, k)] = None
    out["erros_avaliadores"] = erros
    # ---------------------------------------------------- itens por semente
    porsem = {v: {} for v in B.VARIANTES}
    for v in B.VARIANTES:
        for k, sem in conj.items():
            av = avB1.get((v, k))
            if av is None:
                continue
            for s in sem:
                if str(s) in av["por_semente"] and av["por_semente"][str(s)]["itens"]:
                    porsem[v][s] = itens_semente(av, dest, v, s, guia_all)
    out["por_semente"] = {v: {str(s): x for s, x in d.items()} for v, d in porsem.items()}
    # ---------------------------------------------------- âncoras
    A = {}
    if cfg["usar_referencias"]:
        refs = {"B1": B.carregar_json(B.REF / "avaliacao_B1_original_B1_2026-10-02.json"),
                "B41": B.carregar_json(B.REF / "avaliacao_B1_B41_2026-10-28.json")}
        a1, a2 = {}, {}
        for k, ref in refs.items():
            av = avB1.get(("V0", k))
            if av is None:
                a1[k] = {"ok": False, "nota": "sem avaliação V0"}
                a2[k] = {"ok": False}
                continue
            a1[k] = {str(s): ancora_semente(av["por_semente"][str(s)], ref["por_semente"][str(s)])
                     for s in conj[k] if av["por_semente"].get(str(s), {}).get("serie")}
            a1[k]["ok"] = len(a1[k]) == len(conj[k]) and all(x["ok"] for x in a1[k].values())
            p1, p1r = av["criterios"]["P1"], ref["criterios"]["P1"]
            a2[k] = {"decisao_V0": av["decisao"], "decisao_gravada": ref["decisao"],
                     "falhas_P1_V0": p1["itens que falharam por semente"], "falhas_P1_gravadas": p1r["itens que falharam por semente"],
                     "ok": av["decisao"] == ref["decisao"] and p1["itens que falharam por semente"] == p1r["itens que falharam por semente"]}
        A["A1_series_V0"] = a1
        A["A2_decisoes_V0"] = a2
        a3 = ancora_b8(pasta)
        rb8 = B.carregar_json(B.REF / "avaliacao_B8_B41_2026-10-28.json")
        av8 = avB8.get(("V0", "B41"))
        if av8 is not None:
            a3["B8_decisao_V0_B41"] = av8["decisao"]
            a3["B8_xi_V0_B41"] = av8["B8_1"]["xi"]
            a3["B8_decisao_ok"] = (av8["decisao"] == rb8["decisao"] and abs(av8["B8_1"]["xi"] - rb8["B8_1"]["xi"]) <= B.TOL_BIT
                                   and all(abs(x - y) <= B.TOL_BIT for x, y in zip(av8["B8_1"]["IC95"], rb8["B8_1"]["IC95"])))
        else:
            a3["B8_decisao_ok"] = False
        a3["ok"] = a3.get("classe") in ("BIT_A_BIT", "TOLERANCIA") and a3["B8_decisao_ok"]
        A["A3_B8_V0"] = a3
    else:
        A["A1_A2_A3"] = "NAO_APLICAVEL_NA_FUMACA (resoluções reduzidas)"
    a4 = {}
    for s in sorted(guia_all):
        c1 = B.carregar_json(dest / "V1" / str(s) / f"B1c_{s}.json")
        c0 = B.carregar_json(dest / "V0" / str(s) / f"B1c_{s}.json")
        if c1 is not None and c0 is not None:
            a4[str(s)] = malhas_guia(c1["R"], c0["R"])
    A["A4_malhas_do_guia"] = {**a4, "ok": bool(a4) and all(x["ok"] for x in a4.values())}
    f = B.carregar_json(pasta / "F" / "F.json")
    if f is None:
        A["A5_fidelidade"] = {"classe": "SEM_DADOS", "ok": False}
    else:
        gd = f["guia"]["max_dif"]
        cg = "FIEL" if gd <= B.TOL_BIT else ("FIEL_TOLERANCIA" if gd <= 1e-8 else "INFIEL")
        cgi = "FIEL" if (f["girante"]["resultados_identicos"] and f["girante"]["mesmo_estado_do_gerador"]) else "INFIEL"
        A["A5_fidelidade"] = {"guia": cg, "guia_max_dif": gd, "girante": cgi, "ok": cg != "INFIEL" and cgi == "FIEL"}
    # A6: espelhos, conferência do V0 real, resíduos da limpeza
    esp, resid, conf = [], [], []
    for s in B.todas_sementes(cfg):
        d = B.carregar_json(pasta / "A" / str(s) / f"diagnostico_B1a_{s}.json")
        if d is not None:
            esp.append(bool(d["espelho_S7_confere"]) and bool(d["espelho_S8_confere"]))
            resid += [max(x["res_lambda"], x["res_transversal"]) for x in d["S7_V1E_limpeza"] + d["S8_V1_limpeza"]]
        for l in cfg["ordem_cons"]:
            o = B.carregar_json(pasta / "B" / f"B_{s}_{l}.json")
            if o is not None:
                resid.append(max(o["longitudinal"]["res_lambda"], o["longitudinal"]["res_transversal"]))
                if "conferencia_v0_real" in o:
                    c = o["conferencia_v0_real"]
                    conf.append(max(c["max_dif_fracao"], c["max_dif_dE_E"], c["max_dif_dPz_Pz"]))
    db8 = B.carregar_json(pasta / "B8" / "diagnostico_B8.json")
    if db8 is not None:
        for sec in ("delaunay", "N6"):
            for lst in db8[sec].values():
                resid += [max(x["res_lambda"], x["res_transversal"]) for x in lst]
    A["A6_internas"] = {"espelhos_S7_S8": f"{sum(esp)}/{len(esp)}", "residuo_limpeza_max": max(resid) if resid else None,
                        "conferencia_v0_real_max_dif": max(conf) if conf else None, "n_conferencias_v0_real": len(conf),
                        "ok": bool(esp) and all(esp) and bool(resid) and max(resid) <= B.TOL_LIMPEZA
                        and bool(conf) and max(conf) <= B.TOL_RECONS}
    out["ancoras"] = A
    falhas_anc = [k for k, x in A.items() if isinstance(x, dict) and not x.get("ok", True)]
    if cfg["usar_referencias"]:
        falhas_anc += [f"A1_{k}" for k, x in A["A1_series_V0"].items() if not x.get("ok")]
        falhas_anc += [f"A2_{k}" for k, x in A["A2_decisoes_V0"].items() if not x.get("ok")]
        falhas_anc = [x for x in falhas_anc if x not in ("A1_series_V0", "A2_decisoes_V0")]
    # ---------------------------------------------------- Q1: a regra da B1 com o lançamento limpo
    Q1 = {}
    for k in conj:
        Q1[k] = {v: (None if avB1.get((v, k)) is None else
                     {"decisao": avB1[(v, k)]["decisao"], "passa": avB1[(v, k)]["passa"],
                      "P1": avB1[(v, k)]["criterios"]["P1"]["sementes que passam em todos os itens disponíveis"],
                      "falhas_P1": avB1[(v, k)]["criterios"]["P1"]["itens que falharam por semente"]})
                 for v in B.VARIANTES}
    n_fecha = sum(1 for k in conj if Q1[k]["V1"] and Q1[k]["V1"]["decisao"] == FECHADO)
    Q1["classe"] = (f"FECHA_NOS_{len(conj)}" if n_fecha == len(conj) else
                    ("NAO_FECHA_EM_NENHUM" if n_fecha == 0 else f"FECHA_EM_{n_fecha}_DE_{len(conj)}"))
    out["Q1"] = Q1
    # ---------------------------------------------------- Q2: pareamento V0 × V1 por semente
    pares = [s for s in B.todas_sementes(cfg) if s in porsem["V0"] and s in porsem["V1"]]
    b = [s for s in pares if not porsem["V0"][s]["todos"] and porsem["V1"][s]["todos"]]
    c = [s for s in pares if porsem["V0"][s]["todos"] and not porsem["V1"][s]["todos"]]
    viradas = {}
    for s in pares:
        f0, f1 = set(porsem["V0"][s]["falhas"]), set(porsem["V1"][s]["falhas"])
        if f0 != f1:
            viradas[str(s)] = {"so_em_V0": sorted(f0 - f1), "so_em_V1": sorted(f1 - f0)}
    Q2 = {"n_pares": len(pares), "b_resolvidas": [str(s) for s in b], "c_regressoes": [str(s) for s in c],
          "mcnemar_p_unilateral": B.mcnemar_unilateral(len(b), len(c)), "itens_que_mudaram": viradas,
          "classe": ("SEM_EFEITO" if not b and not c else
                     ("LIMPEZA_RESOLVE_SEM_REGRESSAO" if b and not c else
                      ("LIMPEZA_PIORA" if c and not b else "LIMPEZA_RESOLVE_COM_REGRESSAO")))}
    out["Q2"] = Q2
    # ---------------------------------------------------- Q3: robustez por semente
    Q3 = {}
    for v in ("V0", "V1"):
        ss = list(porsem[v])
        n = len(ss)
        k_tot = sum(1 for s in ss if not porsem[v][s]["todos"])
        k_l = sum(1 for s in ss if porsem[v][s]["falhas_lancamento"])
        k_o = sum(1 for s in ss if porsem[v][s]["falhas_outras"])
        ic = B.clopper_pearson(k_tot, n) if n else (None, None)
        Q3[v] = {"n": n, "sementes_com_falha": k_tot, "com_falha_de_lancamento": k_l, "com_outra_falha": k_o,
                 "taxa": k_tot / n if n else None, "IC95_taxa": ic,
                 "P1_passa_na_taxa": B.p1_passa(k_tot / n) if n else None,
                 "P1_passa_nos_limites_do_IC": [B.p1_passa(ic[1]), B.p1_passa(ic[0])] if n else None,
                 "item6_passa": f"{sum(1 for s in ss if porsem[v][s]['item6'])}/{n}",
                 "falhas": {str(s): porsem[v][s]["falhas"] for s in ss if porsem[v][s]["falhas"]}}
    kl0, kl1 = Q3["V0"]["com_falha_de_lancamento"], Q3["V1"]["com_falha_de_lancamento"]
    Q3["classe"] = ("SEM_FALHAS_DE_PREPARACAO_EM_V0" if kl0 == 0 else
                    ("FALHAS_DE_PREPARACAO_ELIMINADAS" if kl1 == 0 else
                     ("FALHAS_DE_PREPARACAO_REDUZIDAS" if kl1 < kl0 else "FALHAS_DE_PREPARACAO_NAO_REDUZIDAS")))
    out["Q3"] = Q3
    # ---------------------------------------------------- Q4: o estimador espectral [H]
    Q4 = {}
    rs, porconj = [], {}
    for k, sem in conj.items():
        rk = []
        for s in sem:
            a0 = B.carregar_json(dest / "V0" / str(s) / f"B1a_{s}.json")
            a1 = B.carregar_json(dest / "V1E" / str(s) / f"B1a_{s}.json")
            if a0 is None or a1 is None:
                continue
            xi = []
            for a in (a0, a1):
                lin = a["tabelas"]["dispersao.csv"]
                Nf = max(l["GMFs"] for l in lin)
                ll = [l for l in lin if l["GMFs"] == Nf]
                xi.append(B.ajuste_xi([l["ka"] ** 2 for l in ll], [l["omega/ck"] for l in ll])[0])
            rk.append(xi[1] / xi[0])
        porconj[k] = {"r_por_semente": rk, "r_medio": float(np.mean(rk)) if rk else None}
        rs += rk
    if rs:
        rm, ric = B.boot_media(rs)
    else:
        rm, ric = None, [None, None]
    Q4["r_xi_V1E_sobre_V0"] = {"media": rm, "IC95": ric, "n": len(rs), "por_conjunto": porconj}
    b8 = {}
    for k in conj:
        x0, x1 = avB8.get(("V0", k)), avB8.get(("V1E", k))
        if x0 is not None and x1 is not None:
            b8[k] = {"decisao_V0": x0["decisao"], "decisao_V1E": x1["decisao"], "xi_V0": x0["B8_1"]["xi"], "xi_V1E": x1["B8_1"]["xi"],
                     "IC95_V0": x0["B8_1"]["IC95"], "IC95_V1E": x1["B8_1"]["IC95"],
                     "a_max_m_V0": x0["B8_3"]["a_max (m)"], "a_max_m_V1E": x1["B8_3"]["a_max (m)"],
                     "xi_por_direcao_V0": x0["B8_2"]["xi por direção (média das realizações, malha mais fina)"],
                     "xi_por_direcao_V1E": x1["B8_2"]["xi por direção (média das realizações, malha mais fina)"]}
    Q4["B8_original_V0_V1E"] = b8
    Q4["regra_da_B1_com_V1E"] = {k: (Q1[k]["V1E"]["decisao"] if Q1[k]["V1E"] else None) for k in conj}
    # controles do Q4
    cub_ok, cub_dif = None, None
    j0, j1 = B.carregar_json(pasta / "B8" / "B8_isotropia_V0.json"), B.carregar_json(pasta / "B8" / "B8_isotropia_V1E.json")
    if j0 is not None and j1 is not None:
        cub_dif = max(abs(j1["cubica_controle"][l][d]["xi"] - x["xi"]) / abs(x["xi"])
                      for l, r in j0["cubica_controle"].items() for d, x in r.items())
        cub_ok = cub_dif <= B.TOL_CUBICA
    Q4["controle_cubica"] = {"max_dif_rel_xi": cub_dif, "ok": cub_ok}
    # mecanismo (identidade exata de Rayleigh, só conferência de código) e dinâmica (descritivo)
    ident, din = [], []
    for s in B.todas_sementes(cfg):
        d = B.carregar_json(pasta / "A" / str(s) / f"diagnostico_B1a_{s}.json")
        if d is not None:
            for x in d["S8_V1_limpeza"]:
                ident.append(abs((x["omega_cru/ck"] / x["omega_limpo/ck"]) ** 2 - (1 - x["delta2"])))
        for l in cfg["ordem_cons"]:
            o = B.carregar_json(pasta / "B" / f"B_{s}_{l}.json")
            if o is not None:
                lo = o["longitudinal"]
                wd = o["omega_din/ck"]["metrica_M1"]
                din.append({"semente": s, "lado": l, "omega_din": wd, "omega_cru": lo["omega_cru/ck"], "omega_limpo": lo["omega_limpo/ck"],
                            "mais_perto_do_limpo": abs(wd - lo["omega_limpo/ck"]) < abs(wd - lo["omega_cru/ck"])})
    Q4["identidade_rayleigh_max_dif"] = max(ident) if ident else None
    Q4["dinamica"] = {"n": len(din), "mais_perto_do_limpo": sum(x["mais_perto_do_limpo"] for x in din),
                      "mediana_omega_din_menos_cru": float(np.median([x["omega_din"] - x["omega_cru"] for x in din])) if din else None,
                      "mediana_omega_din_menos_limpo": float(np.median([x["omega_din"] - x["omega_limpo"] for x in din])) if din else None,
                      "casos": din}
    resid_ok = A["A6_internas"]["residuo_limpeza_max"] is not None and A["A6_internas"]["residuo_limpeza_max"] <= B.TOL_LIMPEZA
    if rm is None:
        Q4["classe"] = "SEM_DADOS"
    elif not cub_ok or not resid_ok:
        Q4["classe"] = "INCONCLUSIVO (controle da limpeza falhou)"
    else:
        dv = abs(rm - 1)
        Q4["classe"] = ("ESTIMADOR_SEM_VIES_RELEVANTE" if dv < B.FAIXA_SEM_VIES else
                        ("VIES_PEQUENO" if dv < B.FAIXA_VIES_PEQUENO else "VIES_IMPORTANTE"))
        Q4["sentido"] = "ξ(V1E) < ξ(V0): o estimador original superestima ξ" if rm < 1 else "ξ(V1E) ≥ ξ(V0)"
    out["Q4"] = Q4
    # ---------------------------------------------------- veredito
    princ = Q1.get("B1", {}).get("V1")
    if princ is None:
        cab = "SEM_DECISAO_PRINCIPAL"
    elif princ["decisao"] == FECHADO:
        cab = "B1_FECHA_COM_LANCAMENTO_LIMPO"
    else:
        cab = f"B1_NAO_FECHA_COM_LANCAMENTO_LIMPO ({princ['decisao']})"
    ver = f"{cab}; conjuntos: {Q1['classe']}; Q3: {Q3['classe']}; Q4: {Q4['classe']}"
    if faltando or erros:
        ver = "INCOMPLETO: " + ver
    if falhas_anc:
        ver += f" (âncora não conferiu: {', '.join(sorted(set(falhas_anc)))})"
    if fumaca:
        ver = "FUMAÇA (números descartados) — " + ver
    out["veredito"] = ver
    B.salvar_json(pasta / "avaliacao_B41L.json", out)
    (pasta / "resumo_B41L.md").write_text(resumo_md(out, conj), encoding="utf-8")
    return out


def _f(x, n=4):
    return "—" if x is None else (f"{x:.{n}g}" if isinstance(x, float) else str(x))


def resumo_md(o, conj):
    L = [f"# B41L — resumo da avaliação ({o['perfil']})", "", f"**Veredito:** {o['veredito']}", ""]
    L += ["## Q1 — a regra da B1 (avaliador original) em cada variante", "", "| Conjunto | V0 | V1 (lançamento limpo) | V1E (+ estimador limpo) |", "|---|---|---|---|"]
    for k in conj:
        cel = [(f"{o['Q1'][k][v]['decisao']} (P1 {o['Q1'][k][v]['P1']}/{len(conj[k])})" if o["Q1"][k][v] else "—") for v in B.VARIANTES]
        L.append(f"| {k} | " + " | ".join(cel) + " |")
    L += ["", f"Classe: {o['Q1']['classe']}", "", "## Q2 — pareamento V0 × V1", "",
          f"- pares: {o['Q2']['n_pares']}; resolvidas: {o['Q2']['b_resolvidas']}; regressões: {o['Q2']['c_regressoes']}; "
          f"McNemar p = {_f(o['Q2']['mcnemar_p_unilateral'])}; classe: {o['Q2']['classe']}", "",
          "## Q3 — robustez por semente", ""]
    for v in ("V0", "V1"):
        q = o["Q3"][v]
        L.append(f"- {v}: {q['sementes_com_falha']}/{q['n']} sementes com falha (lançamento: {q['com_falha_de_lancamento']}; "
                 f"outras: {q['com_outra_falha']}); IC95 {[_f(x) for x in q['IC95_taxa']]}; P(P1 passa) na taxa = {_f(q['P1_passa_na_taxa'])}")
    L += ["", f"Classe: {o['Q3']['classe']}", "", "## Q4 — o estimador espectral [H]", ""]
    r = o["Q4"]["r_xi_V1E_sobre_V0"]
    L.append(f"- ξ(V1E)/ξ(V0) na malha mais fina da B1: média {_f(r['media'])}, IC95 {[_f(x) for x in r['IC95']]} (n = {r['n']})")
    for k, x in o["Q4"]["B8_original_V0_V1E"].items():
        L.append(f"- B8 ({k}): ξ {_f(x['xi_V0'])} → {_f(x['xi_V1E'])}; a_max {_f(x['a_max_m_V0'], 3)} → {_f(x['a_max_m_V1E'], 3)} m; "
                 f"{x['decisao_V0']} → {x['decisao_V1E']}")
    L += [f"- controle cúbico: {o['Q4']['controle_cubica']}", f"- classe: {o['Q4']['classe']}", "",
          "## Âncoras", "", "```", json.dumps({k: (v.get("ok") if isinstance(v, dict) else v) for k, v in o["ancoras"].items()},
                                              ensure_ascii=False, indent=1), "```", ""]
    if o["saidas_faltando"]:
        L += ["## Saídas faltando", "", ", ".join(o["saidas_faltando"]), ""]
    if o["erros_avaliadores"]:
        L += ["## Erros", "", *o["erros_avaliadores"], ""]
    return "\n".join(L)


def main():
    if len(sys.argv) < 2:
        raise SystemExit("uso: python -I src/avaliar_B41L.py <pasta_saidas>")
    try:
        o = avaliar(sys.argv[1])
    except SystemExit:
        raise
    except Exception:  # noqa: BLE001
        traceback.print_exc()
        raise SystemExit(1)
    print(o["veredito"])


if __name__ == "__main__":
    main()
