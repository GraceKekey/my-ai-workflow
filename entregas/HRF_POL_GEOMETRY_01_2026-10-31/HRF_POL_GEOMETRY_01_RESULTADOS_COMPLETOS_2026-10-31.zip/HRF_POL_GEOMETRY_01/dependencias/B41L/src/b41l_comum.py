# -*- coding: utf-8 -*-
"""HRF B41L — a B1 repetida com o lançamento limpo: peças comuns.

Autoria: Mario José do Canto Filho, MD · desenho e código: Claude (-clau), 29/10/2026.

Este módulo não roda nada sozinho. Ele guarda:
  - os caminhos do pacote e o acesso ao código ORIGINAL (pasta `originais/`, sem alteração; os SHA-256 são os mesmos
    do pré-registro da B41);
  - as sementes, os perfis `fumaca` e `completo` e os limiares congelados (protocolo, §7);
  - utilidades (JSON, hashes, horário) e a estatística (Clopper–Pearson, McNemar exato, bootstrap, P(P1 passa)).
O variável de ambiente PC_* das resoluções da B1 precisa estar definida ANTES de importar c5a_photon_closure; quem
faz isso é o orquestrador (um processo por trabalho).
"""
from __future__ import annotations

import datetime
import hashlib
import json
import math
import os
import platform
import sys
from pathlib import Path

import numpy as np

AQUI = Path(__file__).resolve().parent
RAIZ = AQUI.parent
ORIG = RAIZ / "originais"
BANC = ORIG / "bancadas"
REF = RAIZ / "referencia"
for _p in (ORIG, BANC / "c5a_photon_closure", BANC / "c5a_g0g_backreaction", BANC / "c5a_holonomia_loops",
           BANC / "c5a_curl_curl_emergente", AQUI):
    if str(_p) not in sys.path:
        sys.path.insert(0, str(_p))

# ---------------------------------------------------------------- limiares congelados [D]
TOL_BIT = 1e-12            # âncora de B1a e da B8: |Δ| ≤ 1e-12 → bit a bit
TOL_RECONS = 1e-9          # âncora de B1b (V0 reconstruído a partir da trajetória limpa): |Δε| ≤ 1e-9 → confere
TOL_ANCORA = 1e-6          # |Δε| ≤ 1e-6 → confere com tolerância
TOL_LIMPEZA = 1e-8         # resíduos da limpeza (solução de λ e lei de Gauss do estado limpo)
TOL_CUBICA = 1e-8          # rede cúbica: |ξ(V1E) − ξ(V0)|/ξ ≤ 1e-8 (o lançamento já é limpo nela)
FAIXA_SEM_VIES = 0.05      # Q4: |r − 1| < 0,05 → estimador sem viés relevante
FAIXA_VIES_PEQUENO = 0.20  # Q4: 0,05 ≤ |r − 1| < 0,20 → viés pequeno; ≥ 0,20 → viés importante
LIMIAR_F = 0.99            # item 6 da B1 (descritivo: fora do P1 da B1)
ALFA = 0.05
NBOOT, SEMBOOT = 2000, 12345   # como na B1 e na B8

# itens da B1 ligados à preparação do estado (lançamento) e os demais (protocolo, §7, Q3)
ITENS_LANCAMENTO = ("5_E2_menos_P2c2", "7_compensado_nao_seleciona_helicidade", "8c_girante_e_gauss_do_guia",
                    "extra_conservacoes_no_tempo")
ITENS_OUTROS = ("1_curl_curl_emerge", "2_exatamente_2_modos_fisicos", "3_longitudinal_e_gauge", "4_omega_ck",
                "8a_operador_em_fundo_curvo", "9_backreaction_fraca_nao_destroi", "10_lorentz_IR",
                "extra_fonte_conservada_compativel_com_gauss")

VARIANTES = ("V0", "V1", "V1E")

# ---------------------------------------------------------------- sementes e perfis
ENV_B1_COMPLETO = {"PC_RES_DISP": "10,14,20", "PC_RES_EM": "7,10,14,17,20", "PC_RES_CONS": "10,14,18",
                   "PC_RES_POL": "10", "PC_RES_GUIA": "0.55,0.46,0.40"}
ENV_B1_FUMACA = {"PC_RES_DISP": "5,6,7", "PC_RES_EM": "4,5,6,7,8", "PC_RES_CONS": "5,6,7",
                 "PC_RES_POL": "7", "PC_RES_GUIA": "1.0,0.9,0.8"}
SEMENTES_B1 = [20261201 + i for i in range(10)]
SEMENTES_B41 = [41020001 + i for i in range(10)]
SEMENTES_N = [41820001 + i for i in range(10)]     # 41 8 2 IIII: B41, L, parte 2; nenhuma usada antes
SEMENTES_B8 = [41030001 + i for i in range(10)]    # as da M03 da B41 (âncora da Parte B8)


def res_lista(env, chave):
    return [float(x) if "." in x else int(x) for x in env[chave].split(",")]


def config_perfil(perfil):
    """Parâmetros congelados. `completo` decide; `fumaca` só testa o encadeamento (números descartados)."""
    if perfil == "completo":
        conj = {"B1": SEMENTES_B1, "B41": SEMENTES_B41, "N": SEMENTES_N}
        env = ENV_B1_COMPLETO
        cfg = {"T_cons": 20.0, "T_guia": 40.0, "T_girante": 40.0, "n_densa": 200,
               "conferir_v0_real": [[41820001, 10]],
               "B8": {"lados": [10, 14, 20, 26], "sementes": SEMENTES_B8, "n6_sementes": SEMENTES_B8[:3]},
               "fidelidade": {"semente_guia": 41020001, "h": 0.55, "T": 40.0, "semente_girante": 41829001},
               "usar_referencias": True}
    elif perfil == "fumaca":
        conj = {"B1": [20261201], "B41": [], "N": [41820001]}
        env = ENV_B1_FUMACA
        cfg = {"T_cons": 2.0, "T_guia": 6.0, "T_girante": 6.0, "n_densa": 40,
               "conferir_v0_real": [[20261201, 5], [41820001, 6]],
               "B8": {"lados": [8, 10], "sementes": SEMENTES_B8[:2], "n6_sementes": SEMENTES_B8[:1]},
               "fidelidade": {"semente_guia": 20261201, "h": 1.0, "T": 6.0, "semente_girante": 41829001},
               "usar_referencias": False}
    else:
        raise ValueError(perfil)
    guia = {k: v[:6] for k, v in conj.items()}
    # V0 do guia: nas sementes antigas vem das saídas gravadas da B1 e da B41 (referencia/B1c_V0); nas novas é rodado.
    v0_ref = (guia["B1"] + guia["B41"]) if cfg["usar_referencias"] else []
    v0_rodar = [s for k in conj for s in guia[k] if s not in v0_ref]
    return {"bancada": "B41L", "perfil": perfil, "env": env, "conjuntos": conj, "guia": guia,
            "v0_guia_referencia": v0_ref, "v0_guia_rodar": v0_rodar,
            "ordem_cons": res_lista(env, "PC_RES_CONS"), "ordem_guia": res_lista(env, "PC_RES_GUIA"), **cfg}


def todas_sementes(cfg):
    return [s for k in ("B1", "B41", "N") for s in cfg["conjuntos"][k]]


def sementes_guia(cfg):
    return [s for k in ("B1", "B41", "N") for s in cfg["guia"][k]]


# ---------------------------------------------------------------- utilidades
def agora():
    try:
        from zoneinfo import ZoneInfo
        return datetime.datetime.now(ZoneInfo("America/Sao_Paulo")).isoformat(timespec="seconds")
    except Exception:  # noqa: BLE001
        return datetime.datetime.now().isoformat(timespec="seconds")


def versoes():
    import scipy
    return {"python": platform.python_version(), "numpy": np.__version__, "scipy": scipy.__version__,
            "maquina": platform.platform(), "nucleos": os.cpu_count()}


def _padrao(x):
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (np.floating,)):
        return float(x)
    if isinstance(x, (np.bool_,)):
        return bool(x)
    if isinstance(x, np.ndarray):
        return x.tolist()
    if isinstance(x, complex):
        return [x.real, x.imag]
    raise TypeError(type(x))


def salvar_json(caminho, obj):
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    tmp = caminho.with_suffix(caminho.suffix + ".tmp")
    tmp.write_text(json.dumps(obj, ensure_ascii=False, indent=1, default=_padrao), encoding="utf-8")
    os.replace(tmp, caminho)


def salvar_json_bloco(caminho, obj):
    """Como `rodar_bloco.py` da B1 grava (json.dump com default=float): o avaliador original lê esse formato."""
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    tmp = caminho.with_suffix(caminho.suffix + ".tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(obj, fh, ensure_ascii=False, indent=1, default=float)
    os.replace(tmp, caminho)


def carregar_json(caminho):
    caminho = Path(caminho)
    return json.loads(caminho.read_text(encoding="utf-8")) if caminho.exists() else None


def sha256(caminho):
    h = hashlib.sha256()
    with open(caminho, "rb") as fh:
        for bloco in iter(lambda: fh.read(1 << 20), b""):
            h.update(bloco)
    return h.hexdigest()


def salvar_csv_como_B1(caminho, linhas):
    """Mesmo formato de PC.salvar_csv (10 algarismos significativos): é o que avaliar_B8.py lê."""
    import csv
    caminho = Path(caminho)
    caminho.parent.mkdir(parents=True, exist_ok=True)
    with caminho.open("w", newline="", encoding="utf-8") as fh:
        w = csv.DictWriter(fh, fieldnames=list(linhas[0].keys()))
        w.writeheader()
        for l in linhas:
            w.writerow({k: (f"{v:.10g}" if isinstance(v, float) else v) for k, v in l.items()})


# ---------------------------------------------------------------- estatística
def clopper_pearson(k, n, alfa=ALFA):
    from scipy.stats import beta
    if n == 0:
        return (None, None)
    lo = 0.0 if k == 0 else float(beta.ppf(alfa / 2, k, n - k + 1))
    hi = 1.0 if k == n else float(beta.ppf(1 - alfa / 2, k + 1, n - k))
    return (lo, hi)


def mcnemar_unilateral(b, c):
    """McNemar exato unilateral: b = falha em V0 e passa em V1; c = o contrário. H1: V1 falha menos. Devolve p."""
    from scipy.stats import binom
    n = int(b) + int(c)
    if n == 0:
        return 1.0
    return float(binom.sf(int(b) - 1, n, 0.5))


def p1_passa(f, n=10, minimo=9):
    """Probabilidade de P1 (≥ 9 de 10 sementes sem falha) passar, com taxa f de falha por semente."""
    if f is None:
        return None
    return float(sum(math.comb(n, j) * (1 - f) ** (n - j) * f ** j for j in range(0, n - minimo + 1)))


def boot_media(v, semente=SEMBOOT, nboot=NBOOT):
    v = np.asarray(v, float)
    rng = np.random.default_rng(semente)
    bs = [float(np.mean(rng.choice(v, len(v)))) for _ in range(nboot)]
    return float(np.mean(v)), [float(np.percentile(bs, 2.5)), float(np.percentile(bs, 97.5))]


def ajuste_xi(x, y):
    """Mesmo ajuste de avaliar_B8.py (B8-1): ω/ck − 1 = −ξ x − ζ x², x = (ka)², sem termo constante."""
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    A = np.stack([-x, -x * x], 1)
    xi, ze = np.linalg.lstsq(A, y - 1, rcond=None)[0]
    return float(xi), float(ze)
