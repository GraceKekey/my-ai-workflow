# -*- coding: utf-8 -*-
"""HRF B41L — a limpeza do estado lançado e as cópias das rotinas originais que lançam o saca-rolha.

A LIMPEZA [F]. A onda do contínuo copiada para as ligações (mapa de de Rham, `Complexo.onda_aresta`) não obedece
exatamente à lei de Gauss discreta numa malha irregular: d0ᵀ M1 Q ≠ 0. A parte longitudinal é a projeção M1-ortogonal
de Q sobre os gradientes discretos, Q_L = d0 λ, com d0ᵀ M1 d0 λ = d0ᵀ M1 Q. O estado limpo é Q_T = Q − Q_L: obedece a
d0ᵀ M1 Q_T = 0, tem a mesma circulação em todo laço (d1 d0 = 0, então K Q_T = K Q e ∇×Q_T = ∇×Q) e é a parte de Q que
de fato oscila. Para a caixa periódica, a matriz d0ᵀ M1 d0 tem o vetor constante no núcleo e o lado direito é ortogonal
a ele; fixa-se λ = 0 no GMF 0 (solução exata, como na B41H). No guia, os GMFs da parede ficam fora de d0 e a matriz é
invertível.

Cópias (só a limpeza muda; com `limpar=False` cada cópia repete o original, e a fidelidade é conferida pela Parte F):
  rodar_guia        ← c5a_g0g_backreaction.Guia.rodar (a mesma cópia da B41H, `rodar_b41h`, que deu FIEL lá)
  t_girante_limpo   ← c5a_curl_curl_emergente.t_girante (guia girante, item 8 da B1)
  p4_fundos_limpo   ← c5a_holonomia_loops.p4_fundos (S11 da B1), chamando t_girante_limpo
No guia e no girante, o que se limpa é o momento canônico π = M1 v + G q (d0ᵀ π = 0), como na B41H.

Estimador espectral limpo (V1E) [H]: o Galerkin da B1 (S7) e da B8 usa as 3 ondas planas copiadas como funções de
teste. Na V1E, as duas transversais são limpas antes; a longitudinal (gradiente exato) fica como está.
"""
from __future__ import annotations

import math

import numpy as np
import scipy.linalg as sl
import scipy.sparse as sp
import scipy.sparse.linalg as spl

import b41l_comum as B  # noqa: F401  (ajusta sys.path para os originais)
import c5a_curl_curl_emergente as CC  # noqa: E402  (original, sem alteração)
import c5a_holonomia_loops as HOL  # noqa: E402  (original, sem alteração)
from malha import Complexo, pontos_tapete  # noqa: E402  (original, sem alteração)

sig, zero_ou = CC.sig, CC.zero_ou


# ---------------------------------------------------------------------------------------------------- limpeza
class Limpador:
    """Projeção M1-ortogonal no subespaço sem carga (lei de Gauss discreta). Uma fatoração por malha."""

    def __init__(self, d0, M1, periodico=True):
        self.d0 = sp.csr_matrix(d0)
        self.M1 = M1
        A = (self.d0.T @ (M1 @ self.d0)).tocsc()
        self.A = A
        self.N = A.shape[0]
        self.periodico = periodico
        self.lu = spl.splu(A[1:, 1:].tocsc()) if periodico else spl.splu(A)

    def resolver(self, b):
        b = np.asarray(b)
        if np.iscomplexobj(b):
            return self.resolver(b.real) + 1j * self.resolver(b.imag)
        lam = np.zeros(self.N)
        if self.periodico:
            lam[1:] = self.lu.solve(b[1:])
        else:
            lam = self.lu.solve(b)
        return lam

    def limpar(self, Q):
        """Devolve Q_T = Q − d0 λ e o diagnóstico: δ² = |Q_L|²_M1/|Q|²_M1; a carga antes (carga_rel) e depois
        (res_transversal) e o resíduo da solução de λ, os três relativos a |M1 Q| (escala do problema)."""
        MQ = self.M1 @ Q
        b = self.d0.T @ MQ
        lam = self.resolver(b)
        QL = self.d0 @ lam
        QT = Q - QL
        escala = max(float(np.linalg.norm(MQ)), 1e-300)
        nQ = float(np.real(np.vdot(Q, MQ)))
        nL = float(np.real(np.vdot(QL, self.M1 @ QL)))
        diag = {"delta2": nL / nQ if nQ > 0 else 0.0,
                "carga_rel": float(np.linalg.norm(b)) / escala,
                "res_lambda": float(np.linalg.norm(self.A @ lam - b)) / escala,
                "res_transversal": float(np.linalg.norm(self.d0.T @ (self.M1 @ QT))) / escala}
        return QT, diag


def base_transversal(kh):
    kh = np.asarray(kh, float) / np.linalg.norm(kh)
    ref = np.array([0.0, 0.0, 1.0]) if abs(kh[2]) < 0.9 else np.array([1.0, 0.0, 0.0])
    ea = np.cross(kh, ref)
    ea /= np.linalg.norm(ea)
    eb = np.cross(kh, ea)
    return ea, eb


def projetado_limpo(onda, K, M1, k, lim):
    """Galerkin nas 3 ondas planas de vetor k, com as 2 transversais limpas (V1E). onda(k, A) → circulação por ligação.
    Devolve ω² (crescente), o conteúdo longitudinal de cada autovetor e o diagnóstico da limpeza."""
    k = np.asarray(k, float)
    kh = k / np.linalg.norm(k)
    ea, eb = base_transversal(kh)
    QL = onda(k, kh)                                   # gradiente exato (circulação de ∇e^{ik·x}/ik)
    Qa, da = lim.limpar(onda(k, ea))
    Qb, db = lim.limpar(onda(k, eb))
    Q = np.stack([QL, Qa, Qb], 1)
    Kk = Q.conj().T @ (K @ Q)
    Mk = Q.conj().T @ (M1 @ Q)
    w2, v = sl.eigh((Kk + Kk.conj().T) / 2, (Mk + Mk.conj().T) / 2)
    lon = np.array([abs(v[0, i]) / np.linalg.norm(v[:, i]) for i in range(3)])
    return w2, lon, {"delta2": [da["delta2"], db["delta2"]], "res_lambda": max(da["res_lambda"], db["res_lambda"]),
                     "res_transversal": max(da["res_transversal"], db["res_transversal"])}


def rayleigh(Q, K, M1):
    return float(np.real(np.vdot(Q, K @ Q)) / np.real(np.vdot(Q, M1 @ Q)))


# ---------------------------------------------------------------------------------------------------- rede cúbica
def d0_cubica(lado):
    """Gradiente discreto da rede cúbica periódica de b8_isotropia.cubica (mesma numeração de nós e ligações)."""
    n = lado
    N = n ** 3
    idx = lambda i, j, k: ((i % n) * n + (j % n)) * n + (k % n)  # noqa: E731
    I, J, Kk = [x.ravel() for x in np.meshgrid(np.arange(n), np.arange(n), np.arange(n), indexing="ij")]
    s = idx(I, J, Kk)
    desl = ((1, 0, 0), (0, 1, 0), (0, 0, 1))
    rows, cols, vals = [], [], []
    for d, (a, b, c) in enumerate(desl):
        e = d * N + s
        rows += [e, e]
        cols += [s, idx(I + a, J + b, Kk + c)]
        vals += [-np.ones(N), np.ones(N)]
    return sp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(3 * N, N)).tocsr()


# ---------------------------------------------------------------------------------------------------- guia (S2/S12)
def rodar_guia(g, u_t, pol, k_n=1, T=40.0, coletar=False, limpar=False):
    """Cópia de c5a_g0g_backreaction.Guia.rodar (mesmas operações, na mesma ordem). Única diferença: `limpar`."""
    sol = g.lu.solve
    K, M1 = g.K, g.M1
    G = g.matriz_G(u_t)
    GT = G.T.tocsr()
    dt = g.dt
    k = 2 * math.pi * k_n / g.Lz
    kv = np.array([0, 0, k])
    ex, ey = np.eye(3)[0], np.eye(3)[1]
    Q = {s: g.C.onda_aresta(kv, ex - 1j * s * ey)[g.I] for s in (1, -1)}
    Qx = g.C.onda_aresta(kv, ex)[g.I]
    Q0 = Q[pol] if pol != 0 else Qx
    q = Q0.real.copy()
    v = (k * Q0.imag).copy()
    pi = M1 @ v + G @ q
    if limpar:                                                    # ← a única diferença
        A = (g.d0.T @ (M1 @ g.d0)).tocsc()
        lam = spl.splu(A).solve(g.d0.T @ pi)
        pi = pi - M1 @ (g.d0 @ lam)
    gauss0 = g.d0.T @ pi
    Hf = lambda q, pi: 0.5 * pi @ sol(pi) + 0.5 * q @ (K @ q) - pi @ sol(G @ q)  # noqa: E731
    H0 = Hf(q, pi)
    Ts = {s: M1 @ Q[s] for s in (1, -1)}
    nrm = {s: np.sum(np.abs(Ts[s][g.perto])**2) for s in (1, -1)}

    def fluxoB(q, pi, tau):
        yq, tq, yp, tp = q.copy(), q.copy(), pi.copy(), pi.copy()
        for kk in range(1, 4):
            tq = -tau * sol(G @ tq) / kk
            yq += tq
            tp = tau * (GT @ sol(tp)) / kk
            yp += tp
        return yq, yp
    ns = int(round(T / dt))
    ts, cs = [], {1: [], -1: []}
    rho = np.zeros(g.C.T); S = np.zeros((g.C.T, 3)); nmed = 0  # noqa: E702
    q, pi = fluxoB(q, pi, 0.5 * dt)
    for it in range(ns + 1):
        if it % 10 == 0:
            ts.append(it * dt)
            for s in (1, -1):
                cs[s].append(np.vdot(Ts[s][g.perto], pi[g.perto]) / nrm[s])
            if coletar and it * dt > 5:
                qq, pp = fluxoB(q, pi, -0.5 * dt)
                vv = sol(pp - G @ qq)
                E, Bc = g.campos(qq, vv)
                rho += 0.5 * (g.n_t * np.sum(E * E, 1) + np.sum(Bc * Bc, 1) / g.n_t)
                S += np.cross(E, Bc)
                nmed += 1
        pi -= 0.5 * dt * (K @ q)
        q += dt * sol(pi)
        pi -= 0.5 * dt * (K @ q)
        q, pi = fluxoB(q, pi, dt if it < ns else 0.5 * dt)
    ts = np.array(ts)
    sel = ts > 5
    w, amp = {}, {}
    for s in (1, -1):
        c = np.array(cs[s])
        ph = np.unwrap(np.angle(c))
        w[s] = -np.polyfit(ts[sel], ph[sel], 1)[0]
        amp[s] = float(np.mean(np.abs(c[sel])))
    out = {"omega": w, "amp": amp,
           "gauss": float(np.linalg.norm(g.d0.T @ pi - gauss0) / np.linalg.norm(pi)),
           "energia": float((Hf(q, pi) - H0) / H0)}
    if pol == 0:
        dphi = np.unwrap(np.angle(np.array(cs[-1]))) - np.unwrap(np.angle(np.array(cs[1])))
        out["rotacao_rad_por_tempo"] = float(0.5 * np.polyfit(ts[sel], dphi[sel], 1)[0])
    if coletar:
        out["rho"], out["S"] = rho / nmed, S / nmed
    return out


def carga_guia(g, u_t, pol, k_n=1):
    """Só leitura: tamanho da carga do lançamento no guia (|d0ᵀπ|/|π| e |π_L|/|π|)."""
    G = g.matriz_G(u_t)
    k = 2 * math.pi * k_n / g.Lz
    Q0 = g.C.onda_aresta(np.array([0, 0, k]), np.eye(3)[0] - 1j * pol * np.eye(3)[1])[g.I]
    pi = g.M1 @ (k * Q0.imag) + G @ Q0.real
    b = g.d0.T @ pi
    lam = spl.splu((g.d0.T @ (g.M1 @ g.d0)).tocsc()).solve(b)
    piL = g.M1 @ (g.d0 @ lam)
    return {"carga_rel": float(np.linalg.norm(b) / np.linalg.norm(pi)), "piL_rel": float(np.linalg.norm(piL) / np.linalg.norm(pi))}


# ---------------------------------------------------------------------------------------------------- girante (S11, C3/C4)
def t_girante_limpo(rng, Om0=0.05, R=3.0, Lz=4.0, h=0.5, T=40.0, omegas=None, espelho=False, limpar=False):
    """Cópia de c5a_curl_curl_emergente.t_girante (mesmos sorteios e operações, na mesma ordem). Única diferença:
    `limpar` (π = M1 v + G q perde M1 d0 λ, com d0ᵀ M1 d0 λ = d0ᵀ π). Chaves extras, fora do dicionário original:
    `_omegas_brutos` e `_carga` (só leitura)."""
    nxy = int(round(2 * R / h))
    nz = int(round(Lz / h))
    Pin = pontos_tapete(np.array([nxy, nxy, nz]), np.array([2 * R, 2 * R, Lz]), rng) - np.array([R, R, 0])
    Pin = Pin[np.hypot(Pin[:, 0], Pin[:, 1]) < R - 0.35 * h]
    nb = int(round(2 * math.pi * R / h))
    zs = (np.arange(nz) + 0.5) * Lz / nz
    ang = (np.arange(nb)[None, :] + 0.5 * (np.arange(nz)[:, None] % 2) + rng.uniform(-0.2, 0.2, (nz, nb))) * 2 * math.pi / nb
    Pb = np.stack([R * np.cos(ang).ravel(), R * np.sin(ang).ravel(), np.repeat(zs, nb)], 1)
    P = np.concatenate([Pin, Pb]) + np.array([R, R, 0])
    if espelho:                                          # orientação do espaço invertida (y → −y)
        P[:, 1] = 2 * R - P[:, 1]
    borda_no = np.r_[np.zeros(len(Pin), bool), np.ones(len(Pb), bool)]
    Ls = np.array([2 * R, 2 * R, Lz])
    C = Complexo(P, Ls, periodico=(False, False, True), parede=borda_no)
    M1, M2 = C.matrizes()
    K = (C.d1.T @ M2 @ C.d1).tocsr()
    dentro = ~(borda_no[C.arestas[:, 0]] & borda_no[C.arestas[:, 1]])
    I = np.nonzero(dentro)[0]
    M1 = M1[I][:, I].tocsc(); K = K[I][:, I].tocsr()  # noqa: E702
    lu = spl.splu(M1, permc_spec="MMD_AT_PLUS_A", options=dict(SymmetricMode=True))
    sol = lu.solve
    cen = C.Xt.mean(1)
    u = np.zeros((C.T, 3))
    u[:, 0] = -(cen[:, 1] - R)
    u[:, 1] = cen[:, 0] - R
    cl = C.curl_local()
    from malha import ARESTAS_LOC
    g = C.grad
    wint = np.stack([(g[:, j] - g[:, i]) * (C.vol / 4)[:, None] for (i, j) in ARESTAS_LOC], 1)
    Gl = np.einsum("tei,tfi->tef", wint, np.cross(cl, u[:, None, :]))
    G1 = C._monta(Gl, C.aresta_t, C.E)[I][:, I].tocsr()
    d0 = C.d0[I][:, np.nonzero(~borda_no)[0]]
    phi = rng.normal(size=d0.shape[1])
    res = {"GMFs": C.N, "ligacoes_livres": len(I), "raio": R, "Omega": Om0,
           "|K∇φ| / |Kq| (gauge, com as paredes)": zero_ou(float(np.linalg.norm(K @ (d0 @ phi)) /
                                                                   np.linalg.norm(K @ rng.normal(size=len(I))))),
           "|G∇φ| / |Gq| (o arrasto não mexe nos gradientes)": zero_ou(float(np.linalg.norm(G1 @ (d0 @ phi)) /
                                                                            np.linalg.norm(G1 @ rng.normal(size=len(I)))))}
    wmax = math.sqrt(CC.limite_wmax(C))
    dt = 1.0 / wmax
    res["dt"] = sig(dt, 3)
    k = 2 * math.pi / Lz
    kv = np.array([0, 0, k])
    ex, ey = np.eye(3)[0], np.eye(3)[1]
    mid = C.P[C.arestas[I, 0]] + 0.5 * C.vet_aresta[I]
    perto = np.hypot(mid[:, 0] - R, mid[:, 1] - R) < 0.5 * R
    out = {}
    carga = {}
    for Om in ((0.0, Om0) if omegas is None else omegas):
        G = (Om * G1).tocsr()
        GT = G.T.tocsr()

        def fluxoB(q, pi, tau):
            yq, tq = q.copy(), q.copy()
            yp, tp = pi.copy(), pi.copy()
            for kk in range(1, 4):
                tq = -tau * sol(G @ tq) / kk
                yq += tq
                tp = tau * (GT @ sol(tp)) / kk
                yp += tp
            return yq, yp
        for s in (1, -1):
            Qs = C.onda_aresta(kv, ex - 1j * s * ey)[I]
            q = Qs.real.copy()
            v = (1.0 * k * Qs.imag).copy()
            pi = M1 @ v + G @ q
            if limpar:                                    # ← a única diferença
                b0 = d0.T @ pi
                lam = spl.splu((d0.T @ (M1 @ d0)).tocsc()).solve(b0)
                carga[f"{Om:+.3f}, s = {s:+d}"] = float(np.linalg.norm(b0) / np.linalg.norm(pi))
                pi = pi - M1 @ (d0 @ lam)
            H = lambda q, pi: 0.5 * pi @ sol(pi) + 0.5 * q @ (K @ q) - pi @ sol(G @ q)  # noqa: E731
            H0 = H(q, pi)
            gauss0 = d0.T @ pi
            ns = int(round(T / dt))
            Ts = M1 @ Qs
            nrm = np.sum(np.abs(Ts[perto])**2)
            ts, fs = [], []
            if Om:
                q, pi = fluxoB(q, pi, 0.5 * dt)
            for it in range(ns + 1):
                if it % 10 == 0:
                    ts.append(it * dt)
                    fs.append(np.angle(np.vdot(Ts[perto], pi[perto]) / nrm))
                pi -= 0.5 * dt * (K @ q)
                q += dt * sol(pi)
                pi -= 0.5 * dt * (K @ q)
                if Om:
                    q, pi = fluxoB(q, pi, dt if it < ns else 0.5 * dt)
            ts, ph = np.array(ts), np.unwrap(fs)
            w = -np.polyfit(ts[ts > 5], ph[ts > 5], 1)[0]
            out[(Om, s)] = w
            res[f"Omega = {Om}, s = {s:+d}"] = {
                "omega_medido": sig(w, 5),
                "deriva de energia": sig(float((H(q, pi) - H0) / H0), 3),
                "|∇·π(t) − ∇·π(0)| / |π| (lei de Gauss)": zero_ou(float(np.linalg.norm(d0.T @ pi - gauss0) /
                                                                        np.linalg.norm(pi)))}
    extras = {"_omegas_brutos": {f"{Om:+.3f}, s = {s:+d}": float(w) for (Om, s), w in out.items()}, "_carga": carga}
    if omegas is not None:
        res["omegas"] = {f"{Om:+.3f}, s = {s:+d}": sig(w, 6) for (Om, s), w in out.items()}
        res.update(extras)
        return res
    res["parado: omega(+1) − omega(−1)"] = sig(out[(0.0, 1)] - out[(0.0, -1)], 3)
    res["girando: omega(+1) − omega(−1)"] = sig(out[(Om0, 1)] - out[(Om0, -1)], 3)
    res["previsto (rotação rígida, m = −s): −2 Omega"] = -2 * Om0
    res.update(extras)
    return res


def p4_fundos_limpo(rng, T_girante=40.0, limpar=True):
    """Cópia de c5a_holonomia_loops.p4_fundos (mesmos sorteios, na mesma ordem). Única diferença: o guia girante é
    t_girante_limpo (com T e `limpar`). C1 e C2 não lançam onda: devem sair iguais ao original."""
    L = HOL.L
    res = {}
    for nome, geo in (("C1 poço fundo", HOL.sigma_poco), ("C2 vale", HOL.sigma_vale)):
        nfun = lambda X, geo=geo: np.exp(2 * geo(X)[0])  # noqa: E731
        ondas = CC.base_ondas(CC.NS_TESTE)
        m = len(ondas)
        g = np.linspace(0, L, 48, endpoint=False)
        Xg = np.stack(np.meshgrid(g, g, g, indexing="ij"), -1)
        nn = nfun(Xg)
        V = L**3
        B_ex = np.zeros((m, m), complex)
        for a_, (ka, Aa, _) in enumerate(ondas):
            for b_, (kb, Ab, _) in enumerate(ondas):
                B_ex[a_, b_] = V * np.mean(np.exp(1j * (Xg @ (kb - ka))) / nn) * (np.cross(ka, Aa) @ np.cross(kb, Ab))
        lin = []
        for nl in (6, 9, 13):
            C, M1, M2 = CC.montar(nl, rng, n_fun=nfun)
            K = (C.d1.T @ M2 @ C.d1).tocsr()
            Q = np.stack([C.onda_aresta(k, A) for k, A, _ in ondas], 1)
            Bh = Q.conj().T @ (K @ Q)
            al = np.vdot(B_ex, Bh).real / np.vdot(B_ex, B_ex).real
            phi = rng.normal(size=C.N)
            lin.append({"GMFs": C.N, "eps contra ∇×(1/n)∇×": sig(float(np.linalg.norm(Bh - al * B_ex) / np.linalg.norm(Bh)), 3),
                        "alfa": sig(al, 4),
                        "|K∇φ|/|Kq| (gauge)": zero_ou(float(np.linalg.norm(K @ (C.d0 @ phi)) /
                                                          np.linalg.norm(K @ rng.normal(size=C.E))))})
        res[nome] = {"n_maximo": sig(float(nn.max()), 3), "convergência": lin}
    Om = 0.05
    g3 = t_girante_limpo(rng, Om0=Om, omegas=(0.0, Om, -Om), T=T_girante, limpar=limpar)
    w = {k: v for k, v in g3["omegas"].items()}
    W = lambda o, s: w[f"{o:+.3f}, s = {s:+d}"]  # noqa: E731
    dw = {(J, h): W(J, h) - W(0.0, h) for J in (Om, -Om) for h in (1, -1)}
    res["C3 girante"] = {"GMFs": g3["GMFs"], "Omega": Om,
                         "|G∇φ| / |Gq|": g3["|G∇φ| / |Gq| (o arrasto não mexe nos gradientes)"],
                         "omega(J = 0): h = +1, −1": [W(0.0, 1), W(0.0, -1)],
                         "Δω(+J, +1), Δω(−J, +1), Δω(+J, −1), Δω(−J, −1)": [sig(dw[(Om, 1)], 4), sig(dw[(-Om, 1)], 4),
                                                                        sig(dw[(Om, -1)], 4), sig(dw[(-Om, -1)], 4)],
                         "previsto (rotação rígida, m = −h): Δω(J, h) = −h·J": [-Om, Om, Om, -Om]}
    g4 = t_girante_limpo(rng, Om0=Om, omegas=(0.0, Om), espelho=True, T=T_girante, limpar=limpar)
    w4 = g4["omegas"]
    d4 = {h: w4[f"{Om:+.3f}, s = {h:+d}"] - w4[f"{0.0:+.3f}, s = {h:+d}"] for h in (1, -1)}
    res["C4 malha espelhada (y → −y), mesmo giro +J"] = {
        "Δω(+J, +1), Δω(+J, −1)": [sig(d4[1], 4), sig(d4[-1], 4)],
        "leitura": "a malha espelhada (a 'mão' da disposição dos GMFs trocada), com o mesmo giro do espaço, separa as "
                   "helicidades do mesmo jeito: o sinal vem do giro, não da malha nem da orientação dos loops"}
    diag = {"C3": {"carga": g3["_carga"], "omegas_brutos": g3["_omegas_brutos"]},
            "C4": {"carga": g4["_carga"], "omegas_brutos": g4["_omegas_brutos"]}}
    return res, diag
