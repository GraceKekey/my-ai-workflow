#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — Parte F: fidelidade das cópias que lançam o saca-rolha.

Com `limpar=False`, cada cópia deve repetir o original exatamente:
  1. rodar_guia contra Guia.rodar (fundo compensado, h = ±1), na mesma malha-guia;
  2. t_girante_limpo contra CC.t_girante (C3: Ω = 0, +0,05, −0,05), partindo do MESMO estado do gerador; além dos
     resultados, o estado do gerador depois das duas chamadas tem de ser o mesmo (mesmos sorteios, mesma ordem).
Também roda o girante com `limpar=True` (só leitura), para registrar o efeito da limpeza nesse caso.

Uso: python -I src/b41l_fidelidade.py --config CFG --saida ARQ.json
"""
from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402

import b41l_comum as B  # noqa: E402
import b41l_limpeza as LZ  # noqa: E402
import c5a_curl_curl_emergente as CC  # noqa: E402  (original, sem alteração)
import c5a_g0g_backreaction as G0G  # noqa: E402  (original, sem alteração)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--saida", required=True)
    a = ap.parse_args()
    cfg = B.carregar_json(a.config)
    f = cfg["fidelidade"]
    out = {"bancada": "B41L", "parte": "F", "perfil": cfg["perfil"], "inicio": B.agora(), "versoes": B.versoes(),
           "parametros": f}
    # 1. guia
    t0 = time.time()
    g = G0G.Guia(np.random.default_rng(f["semente_guia"]), h=f["h"])
    uc = G0G.u_vortices(g.cen, (1, -1))
    guia = {}
    for s in (1, -1):
        r0 = g.rodar(uc, s, T=f["T"])
        r1 = LZ.rodar_guia(g, uc, s, T=f["T"], limpar=False)
        guia[str(s)] = {"dif_omega": max(abs(float(r0["omega"][x] - r1["omega"][x])) for x in (1, -1)),
                        "dif_amp": max(abs(float(r0["amp"][x] - r1["amp"][x])) for x in (1, -1)),
                        "dif_gauss": abs(r0["gauss"] - r1["gauss"]), "dif_energia": abs(r0["energia"] - r1["energia"])}
    out["guia"] = {"GMFs": g.C.N, "por_polarizacao": guia,
                   "max_dif": max(max(v.values()) for v in guia.values()), "segundos": round(time.time() - t0, 1)}
    # 2. girante
    t0 = time.time()
    rng_a = np.random.default_rng(f["semente_girante"])
    estado = rng_a.bit_generator.state
    rg0 = CC.t_girante(rng_a, Om0=0.05, omegas=(0.0, 0.05, -0.05), T=f["T"])
    rng_b = np.random.default_rng()
    rng_b.bit_generator.state = estado
    rg1 = LZ.t_girante_limpo(rng_b, Om0=0.05, omegas=(0.0, 0.05, -0.05), T=f["T"], limpar=False)
    rg1_cmp = {k: v for k, v in rg1.items() if not k.startswith("_")}
    mesmo_estado = json.dumps(rng_a.bit_generator.state, sort_keys=True) == json.dumps(rng_b.bit_generator.state, sort_keys=True)
    rng_c = np.random.default_rng()
    rng_c.bit_generator.state = estado
    rg2 = LZ.t_girante_limpo(rng_c, Om0=0.05, omegas=(0.0, 0.05, -0.05), T=f["T"], limpar=True)
    out["girante"] = {"GMFs": rg0["GMFs"],
                      "resultados_identicos": json.dumps(rg0, sort_keys=True, default=float) == json.dumps(rg1_cmp, sort_keys=True, default=float),
                      "mesmo_estado_do_gerador": mesmo_estado,
                      "omegas_original": rg0["omegas"], "omegas_copia": rg1["omegas"], "omegas_limpo": rg2["omegas"],
                      "carga_limpo": rg2["_carga"], "segundos": round(time.time() - t0, 1)}
    out["fim"] = B.agora()
    B.salvar_json(a.saida, out)
    print(f"F: guia max_dif = {out['guia']['max_dif']:.3g}; girante idêntico = {out['girante']['resultados_identicos']}, "
          f"mesmo estado = {mesmo_estado}", flush=True)


if __name__ == "__main__":
    main()
