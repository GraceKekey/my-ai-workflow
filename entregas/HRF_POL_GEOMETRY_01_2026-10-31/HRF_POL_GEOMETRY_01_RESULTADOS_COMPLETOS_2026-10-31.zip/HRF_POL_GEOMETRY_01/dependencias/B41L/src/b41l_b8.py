#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — Parte B8: a B8-2 (isotropia e ξ por direção) com o estimador original (V0) e com o limpo (V1E).

Mesmas malhas, sementes, direções e m da M03 da B41 (`b8_isotropia.py`, original, sem alteração). Para cada malha:
  V0  = b8_isotropia.medir (Galerkin nas 3 ondas copiadas): deve repetir a M03 da B41 bit a bit (âncora);
  V1E = o mesmo ajuste, com as 2 transversais limpas antes do Galerkin (b41l_limpeza.projetado_limpo).
Controles: a rede cúbica regular (a cópia de uma onda transversal já obedece à lei de Gauss nela: a limpeza não deve
mudar nada) e a malha anisotrópica N6 (pesos W e U).
Grava ARQ_V0.json e ARQ_V1E.json no formato de B8_isotropia.json (o que avaliar_B8.py lê) e o diagnóstico.

Uso: python -I src/b41l_b8.py --config CFG --saida PASTA
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import scipy.sparse as sp  # noqa: E402

import b41l_comum as B  # noqa: E402
import b41l_limpeza as LZ  # noqa: E402
import b8_isotropia as B8  # noqa: E402  (original, sem alteração)


def medir_limpo(onda, K, M1, a, lim, diag):
    """Corpo de B8.medir, com B8.projetado trocado pelo Galerkin limpo."""
    out = {}
    for d in B8.DIRS:
        xs, ys, bir = [], [], []
        for m in B8.MS:
            n = tuple(m * c for c in d)
            k = np.linalg.norm(B8.kvec(n))
            w2, _, dd = LZ.projetado_limpo(onda, K, M1, B8.kvec(n), lim)
            diag.append({"direcao": list(d), "m": m, **dd})
            wT = np.sqrt(np.clip(w2[1:], 0, None))
            xs.append((k * a)**2); ys.append(float(wT.mean() / k)); bir.append(float(abs(wT[1] - wT[0]) / wT.mean()))  # noqa: E702
        b2, b1, c0 = np.polyfit(xs, ys, 2)
        out[str(d)] = {"(ka)²": xs, "ω/ck": ys, "birrefringência": bir, "c0": float(c0), "xi": float(-b1 / c0),
                       "zeta_eff": float(-b2 / c0)}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--saida", required=True)
    a = ap.parse_args()
    cfg = B.carregar_json(a.config)
    c = cfg["B8"]
    pasta = Path(a.saida)
    pasta.mkdir(parents=True, exist_ok=True)
    t00 = time.time()
    par = {"L": B8.L, "lados": c["lados"], "sementes": c["sementes"], "direcoes": B8.DIRS, "m": B8.MS,
           "a": "L/lado (espaçamento médio dos GMFs)", "pesos": "W (Whitney), como na B1"}
    res = {"V0": {"parametros": par, "delaunay": {}, "cubica_controle": {}, "N6_controle": {}},
           "V1E": {"parametros": {**par, "estimador": "limpo (B41L, V1E)"}, "delaunay": {}, "cubica_controle": {},
                   "N6_controle": {}}}
    diag = {"delaunay": {}, "cubica": {}, "N6": {}}
    for lado in c["lados"]:
        for s in c["sementes"]:
            t0 = time.time()
            C, K, M1 = B8.delaunay(lado, s)
            r0 = B8.medir(C.onda_aresta, K, lambda Q: M1 @ Q, B8.L / lado)
            seg0 = round(time.time() - t0, 1)
            lim = LZ.Limpador(C.d0, M1, periodico=True)
            dd = []
            r1 = medir_limpo(C.onda_aresta, K, M1, B8.L / lado, lim, dd)
            chave = f"{lado}|{s}"
            res["V0"]["delaunay"][chave] = {"lado": lado, "semente": s, "GMFs": C.N, "direcoes": r0, "segundos": seg0}
            res["V1E"]["delaunay"][chave] = {"lado": lado, "semente": s, "GMFs": C.N, "direcoes": r1,
                                             "segundos": round(time.time() - t0, 1)}
            diag["delaunay"][chave] = dd
            print(f"Delaunay {lado}³ semente {s}: c0 V0 {np.mean([v['c0'] for v in r0.values()]):.6f}, "
                  f"V1E {np.mean([v['c0'] for v in r1.values()]):.6f} [{time.time() - t0:.0f} s]", flush=True)
    for lado in c["lados"]:
        onda, K, Mm, a_ = B8.cubica(lado)
        r0 = B8.medir(onda, K, Mm, a_)
        M1c = sp.identity(3 * lado ** 3, format="csr") * a_
        lim = LZ.Limpador(LZ.d0_cubica(lado), M1c, periodico=True)
        dd = []
        r1 = medir_limpo(onda, K, M1c, a_, lim, dd)
        for r in (r0, r1):
            for d, v in r.items():
                v["xi_analitico (Σk̂⁴/24)"] = B8.xi_cubica_analitico(eval(d))
        res["V0"]["cubica_controle"][str(lado)] = r0
        res["V1E"]["cubica_controle"][str(lado)] = r1
        diag["cubica"][str(lado)] = dd
        print(f"cúbica {lado}³ ok", flush=True)
    for pesos in ("W", "U"):
        for s in c["n6_sementes"]:
            C, K, M1 = B8.delaunay(None, s, nvec=(14, 14, 7), pesos=pesos)
            aa = (B8.L**3 / C.N) ** (1 / 3)
            r0 = B8.medir(C.onda_aresta, K, lambda Q: M1 @ Q, aa)
            lim = LZ.Limpador(C.d0, M1, periodico=True)
            dd = []
            r1 = medir_limpo(C.onda_aresta, K, M1, aa, lim, dd)
            res["V0"]["N6_controle"][f"{pesos}|{s}"] = {"pesos": pesos, "semente": s, "GMFs": C.N, "direcoes": r0}
            res["V1E"]["N6_controle"][f"{pesos}|{s}"] = {"pesos": pesos, "semente": s, "GMFs": C.N, "direcoes": r1}
            diag["N6"][f"{pesos}|{s}"] = dd
            print(f"N6 {pesos} semente {s} ok", flush=True)
    for v in ("V0", "V1E"):
        res[v]["tempo_total_s"] = round(time.time() - t00, 1)
        B.salvar_json(pasta / f"B8_isotropia_{v}.json", res[v])
    B.salvar_json(pasta / "diagnostico_B8.json", {"versoes": B.versoes(), "fim": B.agora(), **diag})


if __name__ == "__main__":
    main()
