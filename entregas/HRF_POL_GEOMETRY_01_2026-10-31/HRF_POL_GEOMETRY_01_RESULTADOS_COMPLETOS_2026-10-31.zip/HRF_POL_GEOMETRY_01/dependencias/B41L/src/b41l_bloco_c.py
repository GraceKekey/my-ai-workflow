#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — bloco B1c da B1 (S2/S11/S12: guia, fundo compensado, retroação; S11: fundos curvos e guia girante) para
uma semente, com o LANÇAMENTO LIMPO.

V1 (sempre): gerador novo na semente e as MESMAS chamadas da B1, na mesma ordem (três guias de RES_GUIA, depois
p4_fundos). Toda onda é lançada pela cópia `rodar_guia(limpar=True)` ou `t_girante_limpo(limpar=True)`. Como as
cópias consomem os mesmos sorteios, as malhas são as mesmas da B1; o avaliador confere pelo número de GMFs e pelos
resultados de C1/C2 (que não lançam onda e devem sair iguais aos gravados).
V0 (só nas sementes novas): as seções ORIGINAIS PC.s_guia e PC.s_curvo, como `rodar_bloco.py B1c` as chama. Nas
sementes antigas (B1 e B41), o V0 vem das saídas gravadas (referencia/B1c_V0).

Uso: python -I src/b41l_bloco_c.py --config CFG --semente S --saida ARQ.json [--rodar-v0]
"""
from __future__ import annotations

import argparse
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402

import b41l_comum as B  # noqa: E402
import b41l_limpeza as LZ  # noqa: E402
import c5a_photon_closure as PC  # noqa: E402  (original, sem alteração)
import c5a_g0g_backreaction as G0G  # noqa: E402  (original, sem alteração)

sig, zero_ou = PC.sig, PC.zero_ou


def s_guia_limpo(rng, T):
    """Corpo de PC.s_guia, linha a linha, com g.rodar → rodar_guia(limpar=True)."""
    run = lambda g, u, s, coletar=False: LZ.rodar_guia(g, u, s, T=T, coletar=coletar, limpar=True)  # noqa: E731
    res, diag = {}, {"carga": []}
    ref = []
    for hh in PC.RES_GUIA:
        g = G0G.Guia(rng, h=hh)
        uc = G0G.u_vortices(g.cen, (1, -1))
        col = hh == PC.RES_GUIA[1]
        diag["carga"].append({"h": hh, "GMFs": g.C.N, **{f"pol {s:+d}": LZ.carga_guia(g, uc, s) for s in (1, -1)}})
        r = {s: run(g, uc, s, coletar=col) for s in (1, -1)}
        wp, wm = r[1]["omega"][1], r[-1]["omega"][-1]
        dh = abs(wp - wm) / (0.5 * (wp + wm))
        u4 = G0G.u_vortices(g.cen, (1, 1))
        r4 = {s: run(g, u4, s)["omega"][s] for s in (1, -1)}
        d4 = abs(r4[1] - r4[-1]) / (0.5 * (r4[1] + r4[-1]))
        ref.append({"h": hh, "GMFs": g.C.N, "Δ_hel compensado": sig(dh, 3), "Δ_hel só χ = +1 (N4)": sig(d4, 3),
                    "gauss": zero_ou(max(r[1]["gauss"], r[-1]["gauss"]))})
        diag.setdefault("omegas_brutos", []).append({"h": hh, "comp": {str(s): float(r[s]["omega"][s]) for s in (1, -1)},
                                                     "N4": {str(s): float(r4[s]) for s in (1, -1)}})
        PC.log("  h =", hh, ref[-1])
        if col:
            gb, rb, ucb = g, r, uc
    res["S2 Δ_hel com refinamento (fundo compensado χ = ±1, e N4 quiralidade única)"] = ref
    br = {}
    for Gx, rot in ((1e-5, "fraca"), (3e-2, "N5 forte")):
        out = {}
        for s in (1, -1):
            Phi, ud = G0G.backreaction(gb, rb[s]["rho"], rb[s]["S"], Gx)
            eta = float(G0G.norma_dg(Phi, ud).max() / 2)
            om = G0G.giro_eixo(gb, ud)
            gb.matrizes(np.exp(-2 * Phi))
            rr = run(gb, ucb + ud, s)
            gb.matrizes(np.ones(gb.C.T))
            w0 = rb[s]["omega"][s]
            out[s] = {"η_g": sig(eta, 3), "Ω_δ": sig(om, 3), "Δω/ω": sig((rr["omega"][s] - w0) / w0, 3),
                      "mistura": sig(rr["amp"][-s] / rr["amp"][s], 3), "gauss": zero_ou(rr["gauss"])}
        br[rot] = out
    res["S12 backreaction (h = +1, −1)"] = br
    res["mistura sem backreaction (h = +1, −1)"] = [sig(rb[s]["amp"][-s] / rb[s]["amp"][s], 3) for s in (1, -1)]
    return res, diag


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--semente", type=int, required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--rodar-v0", action="store_true")
    a = ap.parse_args()
    cfg = B.carregar_json(a.config)
    if PC.SEMENTE != a.semente:
        sys.exit(f"PC_SEMENTE = {PC.SEMENTE} diferente de --semente {a.semente}")
    out = {"bancada": "B41L", "bloco": "B1c", "semente": a.semente, "perfil": cfg["perfil"], "inicio": B.agora(),
           "versoes": B.versoes(), "resolucoes": {"guia": PC.RES_GUIA}, "variantes": {}}
    if a.rodar_v0:                                       # exatamente rodar_bloco.py B1c
        rng = np.random.default_rng(PC.SEMENTE)
        R, tempos = {}, {}
        for chave, f in (("S2_S11_S12_guia", PC.s_guia), ("S11_fundos_curvos", PC.s_curvo)):
            t0 = time.time()
            R[chave] = f(rng)
            tempos[chave] = round(time.time() - t0, 1)
        out["variantes"]["V0"] = {"R": R, "tempos_s": tempos}
    rng = np.random.default_rng(PC.SEMENTE)
    R, tempos = {}, {}
    t0 = time.time()
    R["S2_S11_S12_guia"], dg = s_guia_limpo(rng, cfg["T_guia"])
    tempos["S2_S11_S12_guia"] = round(time.time() - t0, 1)
    t0 = time.time()
    R["S11_fundos_curvos"], df = LZ.p4_fundos_limpo(rng, T_girante=cfg["T_girante"], limpar=True)
    tempos["S11_fundos_curvos"] = round(time.time() - t0, 1)
    out["variantes"]["V1"] = {"R": R, "tempos_s": tempos}
    out["diagnostico"] = {"guia": dg, "girante": df}
    out["fim"] = B.agora()
    B.salvar_json(a.saida, out)
    print(f"B1c {a.semente}: variantes {sorted(out['variantes'])}", flush=True)


if __name__ == "__main__":
    main()
