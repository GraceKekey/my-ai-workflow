#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — bloco B1b da B1 (S9/S15, conservação no tempo) para uma semente e uma malha, com o LANÇAMENTO LIMPO.

Malha: a mesma da B1 (gerador novo na semente; as malhas de RES_CONS montadas na ordem 10 → 14 → 18, como em
PC.s_conservacao; só a do lado pedido é usada). Lançamento:
  original (V0): q = Re Q₊, v = |k| Im Q₊;
  limpo (V1):    q igual, v → v − d0 λ, com d0ᵀ M1 d0 λ = d0ᵀ M1 v (momento π = M1 v sem carga).
A trajetória integrada é a LIMPA, com o integrador, o passo, o T e os pontos de amostragem da B1. A trajetória original
sai dela exatamente [F]: como K d0 = 0, a parte d0 λ fica parada em v e cresce linearmente em q (q₀(t) = q₁(t) + t·d0 λ,
v₀(t) = v₁(t) + d0 λ), sem mudar ∇×q nem K q. Por isso V0 é medido nos mesmos pontos sem rodar de novo; as âncoras
(B1 e B41) e, nos casos marcados, uma rodada real do lançamento original conferem isso.

Medidas (como em PC.s_conservacao): energia, P_z, fração na helicidade h = +1 com c± = (M1 Q±)ᴴ π, lei de Gauss.
Extras (só leitura): fração com a métrica M1 (c± = Q±ᴴ π); frequência da fase de c₊ ao longo do tempo (ω_din) contra
ω_cru = √R(Q₊) e ω_limpo = √R(Q₊ limpo), R o quociente de Rayleigh; δ_L1, δ_L2 e resíduos.

Uso: python -I src/b41l_bloco_b.py --config CFG --semente S --lado N --saida ARQ.json [--conferir-v0]
"""
from __future__ import annotations

import argparse
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import scipy.sparse.linalg as spl  # noqa: E402

import b41l_comum as B  # noqa: E402
import b41l_limpeza as LZ  # noqa: E402
import c5a_photon_closure as PC  # noqa: E402  (original, sem alteração)
import c5a_curl_curl_emergente as CC  # noqa: E402  (original, sem alteração)
from malha import ARESTAS_LOC  # noqa: E402  (original, sem alteração)


def malha_do_caso(semente, ordem, lado):
    """Mesma sequência de sorteios do bloco B1b da B1: um gerador novo na semente e as malhas na ordem de RES_CONS."""
    rng = np.random.default_rng(semente)
    for nl in ordem:
        C, M1, M2, K = PC.montar_W(nl, rng)
        if nl == lado:
            return C, M1, M2, K
    raise ValueError(f"lado {lado} fora da ordem {ordem}")


def fase_omega(t, c):
    """Frequência angular da fase de uma série complexa: −inclinação da fase desenrolada (MQO)."""
    t = np.asarray(t, float)
    ph = np.unwrap(np.angle(np.asarray(c)))
    return float(-np.polyfit(t, ph, 1)[0])


def conservacao(C, M1, K, T, n_densa, conferir_v0):
    lu = spl.splu(M1.tocsc())
    wmax = math.sqrt(CC.limite_wmax(C))
    dt = 1.0 / wmax
    k = PC.kvec((0, 0, 1))
    kn = float(np.linalg.norm(k))
    Qp, Qm = C.onda_aresta(k, np.array([1, -1j, 0])), C.onda_aresta(k, np.array([1, 1j, 0]))
    q0, v0 = Qp.real.copy(), (kn * Qp.imag).copy()                 # lançamento original (B1)
    g = C.grad
    wc = np.stack([0.25 * (g[:, j] - g[:, i]) for (i, j) in ARESTAS_LOC], 1)
    clc = C.curl_local()
    T2p, T2m = M1 @ Qp, M1 @ Qm

    def medidas(q, v):                                             # corpo de PC.s_conservacao.medidas
        qa, va = q[C.aresta_t], v[C.aresta_t]
        Bc = np.einsum("tei,te->ti", clc, qa); E = -np.einsum("tei,te->ti", wc, va)  # noqa: E702
        P = (np.cross(E, Bc) * C.vol[:, None]).sum(0)
        H = 0.5 * v @ (M1 @ v) + 0.5 * q @ (K @ q)
        pi = M1 @ v
        cp, cm = np.vdot(T2p, pi), np.vdot(T2m, pi)
        return H, P, abs(cp)**2 / (abs(cp)**2 + abs(cm)**2), C.d0.T @ pi

    def frac_m1(v):
        pi = M1 @ v
        a, b = abs(np.vdot(Qp, pi))**2, abs(np.vdot(Qm, pi))**2
        return a / (a + b)
    # ------------------------------------------------ limpeza do lançamento
    t_l = time.time()
    lim = LZ.Limpador(C.d0, M1, periodico=True)
    v1, dv = lim.limpar(v0)
    vL = v0 - v1
    QpT, dq = lim.limpar(Qp)
    longit = {"delta_L1": math.sqrt(max(dv["delta2"], 0.0)),
              "delta_L2": float(np.linalg.norm(M1 @ vL) / np.linalg.norm(M1 @ v0)),
              "carga_rel": dv["carga_rel"], "res_lambda": dv["res_lambda"], "res_transversal": dv["res_transversal"],
              "omega_cru/ck": math.sqrt(LZ.rayleigh(Qp, K, M1)) / kn,
              "omega_limpo/ck": math.sqrt(LZ.rayleigh(QpT, K, M1)) / kn, "delta2_Qp": dq["delta2"]}
    seg_limpeza = round(time.time() - t_l, 1)
    # ------------------------------------------------ trajetória limpa (integrador da B1, sem mudança)
    q, v = q0.copy(), v1.copy()
    H0 = {}
    H0["V1"], P0_1, _, g0_1 = medidas(q, v)
    H0["V0"], P0_0, _, g0_0 = medidas(q0, v0)
    P0 = {"V1": P0_1, "V0": P0_0}
    gz = {"V1": g0_1, "V0": g0_0}
    ns = int(round(T / dt))
    m40 = max(1, ns // 40)
    md = max(1, ns // int(n_densa))
    a = -lu.solve(K @ q)
    serie = {"V0": [], "V1": []}
    fm1 = {"V0": [], "V1": []}
    dens_t, dens_c1, dens_c2 = [], [], []
    for it in range(ns + 1):
        if it % m40 == 0:
            for nome, (qq, vv) in (("V1", (q, v)), ("V0", (q + (it * dt) * vL, v + vL))):
                H, P, hf, gs = medidas(qq, vv)
                serie[nome].append((it * dt, H / H0[nome] - 1, P[2] / P0[nome][2] - 1, hf,
                                    float(np.linalg.norm(gs - gz[nome]) / (np.linalg.norm(M1 @ vv) + 1e-300))))
                fm1[nome].append(frac_m1(vv))
        if it % md == 0:
            pi = M1 @ v
            dens_t.append(it * dt)
            dens_c1.append(np.vdot(Qp, pi))
            dens_c2.append(np.vdot(T2p, pi))
        v += 0.5 * dt * a
        q += dt * v
        a = -lu.solve(K @ q)
        v += 0.5 * dt * a
    out = {"N": int(C.N), "E": int(C.E), "dt": dt, "ns": ns, "T": T, "amostra_cada": m40, "densa_cada": md,
           "omega_k": kn, "longitudinal": longit, "segundos_limpeza": seg_limpeza}
    for nome in ("V0", "V1"):
        s = np.array(serie[nome])
        out[nome] = {"serie": s.tolist(),
                     "max_dE_E": float(np.abs(s[:, 1]).max()), "max_dPz_Pz": float(np.abs(s[:, 2]).max()),
                     "f0": float(s[0, 3]), "fmin": float(s[:, 3].min()), "gauss_max": float(s[:, 4].max()),
                     "f_M1_0": float(fm1[nome][0]), "f_M1_min": float(min(fm1[nome]))}
    out["omega_din/ck"] = {"metrica_M1": fase_omega(dens_t, dens_c1) / kn, "metrica_M1quadrado": fase_omega(dens_t, dens_c2) / kn}
    # ------------------------------------------------ conferência: a trajetória ORIGINAL rodada de verdade
    if conferir_v0:
        t_c = time.time()
        q, v = q0.copy(), v0.copy()
        a = -lu.solve(K @ q)
        real = []
        for it in range(ns + 1):
            if it % m40 == 0:
                H, P, hf, gs = medidas(q, v)
                real.append((it * dt, H / H0["V0"] - 1, P[2] / P0["V0"][2] - 1, hf,
                             float(np.linalg.norm(gs - gz["V0"]) / (np.linalg.norm(M1 @ v) + 1e-300))))
            v += 0.5 * dt * a
            q += dt * v
            a = -lu.solve(K @ q)
            v += 0.5 * dt * a
        r = np.array(real)
        s0 = np.array(serie["V0"])
        out["conferencia_v0_real"] = {"max_dif_fracao": float(np.abs(r[:, 3] - s0[:, 3]).max()),
                                      "max_dif_dE_E": float(np.abs(r[:, 1] - s0[:, 1]).max()),
                                      "max_dif_dPz_Pz": float(np.abs(r[:, 2] - s0[:, 2]).max()),
                                      "segundos": round(time.time() - t_c, 1)}
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--semente", type=int, required=True)
    ap.add_argument("--lado", type=int, required=True)
    ap.add_argument("--saida", required=True)
    ap.add_argument("--conferir-v0", action="store_true")
    a = ap.parse_args()
    cfg = B.carregar_json(a.config)
    out = {"bancada": "B41L", "bloco": "B1b", "semente": a.semente, "lado": a.lado, "perfil": cfg["perfil"],
           "inicio": B.agora(), "versoes": B.versoes()}
    t0 = time.time()
    C, M1, M2, K = malha_do_caso(a.semente, cfg["ordem_cons"], a.lado)
    out["segundos_malha"] = round(time.time() - t0, 1)
    t1 = time.time()
    out.update(conservacao(C, M1, K, cfg["T_cons"], cfg["n_densa"], a.conferir_v0))
    out["segundos_dinamica"] = round(time.time() - t1, 1)
    out["fim"] = B.agora()
    B.salvar_json(a.saida, out)
    print(f"B1b {a.semente} {a.lado}³: V0 f0 = {out['V0']['f0']:.6f}, fmin = {out['V0']['fmin']:.6f} | "
          f"V1 f0 = {out['V1']['f0']:.6f}, fmin = {out['V1']['fmin']:.6f} | δ_L1 = {out['longitudinal']['delta_L1']:.4f}",
          flush=True)


if __name__ == "__main__":
    main()
