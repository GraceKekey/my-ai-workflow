#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — orquestrador (o mesmo esquema da B41H).

Monta a fila do perfil escolhido, roda cada trabalho como processo separado (1 thread de BLAS por processo), respeita um
orçamento de memória (os maiores primeiro), grava um marcador por trabalho concluído e retoma de onde parou se for
relançado. NÃO avalia: a decisão é do `avaliar_B41L.py`, rodado depois.

Uso:
  python -I -u src/rodar_B41L.py --perfil fumaca   [--trabalhadores 4] [--memoria-gb 30] [--partes B1a,B1b] [--listar]
  python -I -u src/rodar_B41L.py --perfil completo [--trabalhadores 11] [--memoria-gb 30] [--saida resultados]
Partes: B1a, B1b, B1c, F (fidelidade das cópias) e B8 (estimador espectral).
Saídas: `fumaca/` ou `resultados/` (ou --saida), com config_B41L.json, A/, B/, C/, F/, B8/, logs/, _concluidos/,
progresso.txt, versoes.json e execucao_resumo.json.
"""
from __future__ import annotations

import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import b41l_comum as B  # noqa: E402

SRC = B.AQUI
PY = sys.executable
MEM_B1B = {10: 1.0, 14: 1.5, 18: 3.5}       # GB por trabalho de conservação (B1 e B41: ~3 GB em 18³)
MEM = {"B1a": 3.0, "B1c": 2.5, "F": 2.0, "B8": 3.0}


def montar_trabalhos(cfg, saida, cfgpath):
    J = []
    env_b1 = dict(cfg["env"])

    def job(jid, parte, script, args, marca, mem, ordem, env=None):
        J.append({"id": jid, "parte": parte, "marca": str(marca), "mem_gb": mem, "ordem": ordem, "env": env or {},
                  "cmd": [str(PY), "-I", "-u", str(SRC / script), "--config", str(cfgpath)] + [str(x) for x in args]})

    conferir = {tuple(x) for x in cfg["conferir_v0_real"]}
    for s in B.sementes_guia(cfg):
        v0 = s in cfg["v0_guia_rodar"]
        out = saida / "C" / f"C_{s}.json"
        job(f"C_{s}", "B1c", "b41l_bloco_c.py", ["--semente", s, "--saida", out] + (["--rodar-v0"] if v0 else []),
            out, MEM["B1c"], -40 if v0 else -30, {**env_b1, "PC_SEMENTE": str(s)})
    job("B8", "B8", "b41l_b8.py", ["--saida", saida / "B8"], saida / "B8" / "diagnostico_B8.json", MEM["B8"], -25)
    for s in B.todas_sementes(cfg):
        for lado in cfg["ordem_cons"]:
            out = saida / "B" / f"B_{s}_{lado}.json"
            extra = ["--conferir-v0"] if (s, lado) in conferir else []
            job(f"B_{s}_{lado}", "B1b", "b41l_bloco_b.py", ["--semente", s, "--lado", lado, "--saida", out] + extra,
                out, MEM_B1B.get(lado, 0.5), -lado, {**env_b1, "PC_SEMENTE": str(s)})
    job("F", "F", "b41l_fidelidade.py", ["--saida", saida / "F" / "F.json"], saida / "F" / "F.json", MEM["F"], -16)
    for s in B.todas_sementes(cfg):
        pasta = saida / "A" / str(s)
        job(f"A_{s}", "B1a", "b41l_bloco_a.py", ["--semente", s, "--saida", pasta],
            pasta / f"diagnostico_B1a_{s}.json", MEM["B1a"], -12, {**env_b1, "PC_SEMENTE": str(s)})
    J.sort(key=lambda j: j["ordem"])                     # os maiores primeiro: encurta a cauda da rodada
    return J


def memoria_disponivel_gb():
    try:
        v = Path("/sys/fs/cgroup/memory.max").read_text().strip()
        if v != "max":
            return int(v) / 2 ** 30
    except OSError:
        pass
    try:
        for linha in Path("/proc/meminfo").read_text().splitlines():
            if linha.startswith("MemTotal:"):
                return int(linha.split()[1]) / 2 ** 20
    except OSError:
        pass
    return 4.0


def registrar(saida, *campos):
    with (saida / "progresso.txt").open("a", encoding="utf-8") as fh:
        fh.write("\t".join([B.agora()] + [str(c) for c in campos]) + "\n")


def executar(J, saida, trabalhadores, mem_gb):
    marc = saida / "_concluidos"
    logs = saida / "logs"
    marc.mkdir(parents=True, exist_ok=True)
    logs.mkdir(parents=True, exist_ok=True)
    feito = {j["id"] for j in J if (marc / f"{j['id']}.json").exists()}
    falhou = set()
    pend = [j for j in J if j["id"] not in feito]
    ativos = {}
    base_env = os.environ.copy()
    base_env.update(OPENBLAS_NUM_THREADS="1", OMP_NUM_THREADS="1", MKL_NUM_THREADS="1", TZ="America/Sao_Paulo")
    print(f"{len(J)} trabalhos; {len(feito)} já concluídos; {len(pend)} pendentes; "
          f"{trabalhadores} por vez; orçamento {mem_gb:.1f} GB", flush=True)
    while pend or ativos:
        for j in list(pend):
            if len(ativos) >= trabalhadores:
                break
            em_uso = sum(a["job"]["mem_gb"] for a in ativos.values())
            if ativos and em_uso + j["mem_gb"] > mem_gb:
                continue
            Path(j["marca"]).parent.mkdir(parents=True, exist_ok=True)
            fh = (logs / f"{j['id']}.txt").open("w", encoding="utf-8")
            p = subprocess.Popen(j["cmd"], cwd=str(B.RAIZ), env={**base_env, **j["env"]}, stdout=fh, stderr=subprocess.STDOUT)
            ativos[j["id"]] = {"p": p, "job": j, "t0": time.time(), "fh": fh}
            pend.remove(j)
            registrar(saida, "INICIO", j["id"])
            print(f"{B.agora()}  início {j['id']}", flush=True)
        for jid, a in list(ativos.items()):
            rc = a["p"].poll()
            if rc is None:
                continue
            a["fh"].close()
            dur = round(time.time() - a["t0"], 1)
            ok = rc == 0 and Path(a["job"]["marca"]).exists()
            if ok:
                B.salvar_json(marc / f"{jid}.json", {"id": jid, "rc": rc, "segundos": dur, "fim": B.agora(),
                                                    "marca": a["job"]["marca"]})
                feito.add(jid)
            else:
                falhou.add(jid)
            registrar(saida, "FIM" if ok else "FALHA", jid, f"rc={rc}", f"{dur}s")
            print(f"{B.agora()}  {'fim' if ok else 'FALHA'} {jid} (rc = {rc}, {dur} s; "
                  f"{len(feito)}/{len(J)} prontos)", flush=True)
            del ativos[jid]
        time.sleep(2)
    return feito, falhou


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--perfil", required=True, choices=["fumaca", "completo"])
    ap.add_argument("--saida")
    ap.add_argument("--trabalhadores", type=int, default=max(1, min(2, os.cpu_count() or 1)))
    ap.add_argument("--memoria-gb", type=float)
    ap.add_argument("--partes", help="lista entre B1a, B1b, B1c, F, B8 (padrão: todas)")
    ap.add_argument("--listar", action="store_true", help="só mostra a fila, sem rodar nada")
    a = ap.parse_args()
    saida = Path(a.saida) if a.saida else B.RAIZ / ("resultados" if a.perfil == "completo" else "fumaca")
    saida = saida.resolve()
    saida.mkdir(parents=True, exist_ok=True)
    cfg = B.config_perfil(a.perfil)
    cfgpath = saida / "config_B41L.json"
    antigo = B.carregar_json(cfgpath)
    if antigo is not None and antigo != json.loads(json.dumps(cfg)):
        sys.exit(f"config_B41L.json em {saida} difere do perfil congelado: não misture rodadas (use outra --saida).")
    if antigo is None:
        B.salvar_json(cfgpath, cfg)
    J = montar_trabalhos(cfg, saida, cfgpath)
    if a.partes:
        quer = {p.strip() for p in a.partes.split(",")}
        J = [j for j in J if j["parte"] in quer]
    mem = a.memoria_gb if a.memoria_gb else 0.8 * memoria_disponivel_gb()
    if a.listar:
        for j in J:
            print(f"{j['id']:<22} parte {j['parte']:<4} {j['mem_gb']:>4.1f} GB")
        print(f"{len(J)} trabalhos; orçamento de memória {mem:.1f} GB; {a.trabalhadores} por vez")
        return
    B.salvar_json(saida / "versoes.json", B.versoes())
    t0 = time.time()
    inicio = B.agora()
    registrar(saida, "RODADA", a.perfil, f"{len(J)} trabalhos")
    feito, falhou = executar(J, saida, a.trabalhadores, mem)
    resumo = {"perfil": a.perfil, "inicio": inicio, "fim": B.agora(), "segundos_parede": round(time.time() - t0, 1),
              "concluidos": sorted(feito), "falharam": sorted(falhou), "trabalhadores": a.trabalhadores,
              "orcamento_memoria_gb": mem, "versoes": B.versoes()}
    B.salvar_json(saida / "execucao_resumo.json", resumo)
    print(f"concluídos {len(feito)}; falharam {len(falhou)}: {sorted(falhou)}", flush=True)
    sys.exit(1 if falhou else 0)


if __name__ == "__main__":
    main()
