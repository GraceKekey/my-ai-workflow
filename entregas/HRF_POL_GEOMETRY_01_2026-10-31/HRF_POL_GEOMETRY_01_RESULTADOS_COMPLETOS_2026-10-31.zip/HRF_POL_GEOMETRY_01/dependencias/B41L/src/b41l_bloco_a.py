#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""HRF B41L — bloco B1a da B1 (S3/S4, S5/S6, S7/S10, S8/S9, S13/S14, S19) para uma semente, em três variantes.

V0  — as seções ORIGINAIS da B1, chamadas como `rodar_bloco.py B1a` as chama (gerador novo na semente). É a B1a
      original: deve repetir a B1 (sementes 2026120x) e a B41 (4102000x) nas séries que o avaliador lê.
V1  — o mesmo dicionário, com S8/S9 (energia–momento e helicidade) recalculada nas MESMAS malhas, com o estado limpo.
V1E — V1 e, além disso, S7/S10 (dispersão, Lorentz IR, N6) recalculada nas mesmas malhas com o estimador limpo.
As malhas são capturadas no momento em que as seções originais as montam (um "gancho" em PC.montar_W que só guarda o
que a função original devolve; não consome sorteios nem muda nada). Conferência embutida: as seções S7 e S8
reescritas, rodadas SEM limpeza nas malhas capturadas, devem dar exatamente o dicionário original (espelho).

Uso (as variáveis PC_* vêm do orquestrador): python -I src/b41l_bloco_a.py --config CFG --semente S --saida PASTA
Grava PASTA/B1a_{V0,V1,V1E}_<semente>.json (formato de rodar_bloco.py), PASTA/{V0,V1E}/c5a_photon_closure_dispersao.csv
e PASTA/diagnostico_B1a_<semente>.json.
"""
from __future__ import annotations

import argparse
import copy
import json
import math
import sys
import time
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import numpy as np  # noqa: E402
import scipy.sparse as sp  # noqa: E402

import b41l_comum as B  # noqa: E402
import b41l_limpeza as LZ  # noqa: E402
import c5a_photon_closure as PC  # noqa: E402  (original, sem alteração; lê PC_* do ambiente)

L = PC.L
sig = PC.sig
BLOCO = (("S3_S4_holonomia_e_operador", PC.s_holonomia_operador), ("S5_S6_polarizacoes_gauge_N0_N3", PC.s_polarizacoes),
         ("S7_S10_dispersao_lorentz", PC.s_dispersao), ("S8_S9_energia_momento_helicidade", PC.s_energia_momento),
         ("S13_S14_quanta", PC.s_quanta), ("S19_cargas", PC.s_cargas))

CAPT = []
_montar_original = PC.montar_W


def _gancho(nl, rng, n_fun=None, tremor=0.35, nvec=None):
    r = _montar_original(nl, rng, n_fun=n_fun, tremor=tremor, nvec=nvec)
    CAPT.append({"nl": nl, "nvec": nvec, "C": r[0], "M1": r[1], "M2": r[2], "K": r[3]})
    return r


# ------------------------------------------------------------------------------------- S7 reescrita (proj trocável)
def s7(malhas, proj):
    """Corpo de PC.s_dispersao, linha a linha, nas malhas capturadas; `proj(C, K, M1, n)` → (ω², lon)."""
    disp = [m for m in malhas if m["nvec"] is None]
    n6m = [m for m in malhas if m["nvec"] is not None]
    res, linhas = {}, []
    for mm in disp:
        nl, C, M1, K = mm["nl"], mm["C"], mm["M1"], mm["K"]
        a = L / nl
        tab = []
        for m in range(1, 7):
            n = (m, 0, 0)
            w2, lon = proj(C, K, M1, n)
            k = np.linalg.norm(PC.kvec(n))
            wT = np.sqrt(w2[1:])
            tab.append((k, float(wT.mean() / k), float(abs(wT[1] - wT[0]) / wT.mean())))
            linhas.append({"GMFs": C.N, "a": a, "n": str(n), "k": k, "ka": k * a, "omega/ck": wT.mean() / k,
                           "birrefringencia": abs(wT[1] - wT[0]) / wT.mean(), "lon_T": float(lon[np.argsort(w2)][1:].max()),
                           "omega2_L/(ck)2": float(w2[0] / k**2)})
        ka = np.array([t[0] * a for t in tab]); d = np.array([t[1] - 1 for t in tab])  # noqa: E702
        A = np.stack([ka, ka**2, ka**3], 1)
        coef = np.linalg.lstsq(A, d, rcond=None)[0]
        vph = np.array([t[1] for t in tab])
        ks = np.array([t[0] for t in tab])
        w = vph * ks
        vg = np.gradient(w, ks)
        dirs = []
        for n in PC.DIRS:
            w2, _ = proj(C, K, M1, n)
            dirs.append(float(np.sqrt(w2[1:]).mean() / np.linalg.norm(PC.kvec(n))))
        bir = []
        for n in PC.DIRS:
            w2, _ = proj(C, K, M1, n)
            bir.append(float(abs(math.sqrt(w2[2]) - math.sqrt(w2[1])) / math.sqrt(w2[1:].mean())))
        res[f"GMFs = {C.N}"] = {
            "espacamento a": sig(a, 4),
            "omega/ck ao longo de x, m = 1..6": [sig(t[1], 5) for t in tab],
            "ka": [sig(x, 3) for x in ka],
            "ajuste ω/ck − 1 = a1·ka + a2·(ka)² + a3·(ka)³": [sig(float(c), 3) for c in coef],
            "v_fase (m = 1..6)": [sig(x, 4) for x in vph], "v_grupo (m = 1..6)": [sig(float(x), 4) for x in vg],
            "anisotropia: desvio de ω/ck entre 11 direções (|n| ≤ 3)": sig(float(np.std(dirs)), 3),
            "ω/ck médio nas 11 direções": sig(float(np.mean(dirs)), 4),
            "birrefringência média entre os 2 transversais (11 direções)": sig(float(np.mean(bir)), 3)}
    n6 = {}
    for (nome, pesos), mm in zip((("W (pesos geométricos)", "W"), ("U (peso uniforme)", "U")), n6m):
        C, M1, K = mm["C"], mm["M1"], mm["K"]
        if pesos == "U":
            K = (C.d1.T @ C.d1).tocsr(); M1 = sp.identity(C.E, format="csr")  # noqa: E702
        vx = math.sqrt(proj(C, K, M1, (1, 0, 0))[0][1:].mean()) / np.linalg.norm(PC.kvec((1, 0, 0)))
        vz = math.sqrt(proj(C, K, M1, (0, 0, 1))[0][1:].mean()) / np.linalg.norm(PC.kvec((0, 0, 1)))
        w2, _ = proj(C, K, M1, (1, 0, 0))
        n6[nome] = {"v_z / v_x": sig(vz / vx, 4), "birrefringência ao longo de x": sig(float(abs(math.sqrt(w2[2]) - math.sqrt(w2[1])) / math.sqrt(w2[1:].mean())), 3)}
    res["N6 malha anisotrópica (espaçamento 2× em z)"] = n6
    return res, linhas


class ProjLimpo:
    """proj(C, K, M1, n) da V1E, com um Limpador por (malha, M1) e o diagnóstico guardado."""

    def __init__(self):
        self.lims, self.diag = {}, []

    def __call__(self, C, K, M1, n):
        chave = (id(C), id(M1))
        if chave not in self.lims:
            self.lims[chave] = LZ.Limpador(C.d0, M1, periodico=True)
        w2, lon, d = LZ.projetado_limpo(C.onda_aresta, K, M1, PC.kvec(n), self.lims[chave])
        self.diag.append({"GMFs": C.N, "n": list(n), **d})
        return w2, lon


def proj_original(C, K, M1, n):
    return PC.projetado(C, K, M1, n)


# ------------------------------------------------------------------------------------- S8 reescrita (limpeza trocável)
def s8(malhas, limpar):
    """Corpo de PC.s_energia_momento, linha a linha, nas malhas capturadas; com `limpar`, Q → Q_T antes de tudo."""
    res, diag = {}, []
    for mm in malhas:
        C, M1, K = mm["C"], mm["M1"], mm["K"]
        lim = LZ.Limpador(C.d0, M1, periodico=True) if limpar else None
        lin = {}
        for rot, n, A in (("h = +1, z", (0, 0, 1), np.array([1, -1j, 0])), ("h = −1, z", (0, 0, 1), np.array([1, 1j, 0])),
                          ("linear, (1,1,1)", (1, 1, 1), np.array([1.0, -1.0, 0]) / math.sqrt(2))):
            k = PC.kvec(n)
            Q = C.onda_aresta(k, A)
            if limpar:
                w_cru = math.sqrt(LZ.rayleigh(Q, K, M1))
                Q, d = lim.limpar(Q)
                diag.append({"GMFs": C.N, "onda": rot, "omega_cru/ck": w_cru / np.linalg.norm(k),
                             "omega_limpo/ck": math.sqrt(LZ.rayleigh(Q, K, M1)) / np.linalg.norm(k), **d})
            w = math.sqrt((np.vdot(Q, K @ Q) / np.vdot(Q, M1 @ Q)).real)
            E, Bc = PC.campos_tet(C, Q, w)
            V = C.vol
            P = (0.5 * np.real(np.cross(E, Bc.conj())) * V[:, None]).sum(0)
            U = float((0.25 * (np.sum(np.abs(E)**2, 1) + np.sum(np.abs(Bc)**2, 1)) * V).sum())
            pc = float(np.linalg.norm(P) / U)
            lin[rot] = {"Pc/E": sig(pc, 5), "(E² − P²c²)/E²": sig(1 - pc * pc, 3),
                        "ângulo entre P e k (rad)": sig(float(math.acos(min(1, abs(P @ k) / (np.linalg.norm(P) * np.linalg.norm(k))))), 3)}
            if rot.startswith("h"):
                h = 1 if "+" in rot else -1
                qc = np.einsum("tei,te->ti", np.stack([0.25 * (C.grad[:, j] - C.grad[:, i]) for (i, j) in PC.ARESTAS_LOC], 1),
                               Q[C.aresta_t])
                r = Bc + h * np.linalg.norm(k) * qc
                lin[rot]["|∇×q + h k q| / |∇×q|"] = sig(float(math.sqrt((np.sum(np.abs(r)**2, 1) * V).sum() /
                                                                          (np.sum(np.abs(Bc)**2, 1) * V).sum())), 3)
        res[f"GMFs = {C.N}"] = lin
    return res, diag


def iguais(a, b):
    return json.dumps(a, sort_keys=True, default=float) == json.dumps(b, sort_keys=True, default=float)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--config", required=True)
    ap.add_argument("--semente", type=int, required=True)
    ap.add_argument("--saida", required=True)
    a = ap.parse_args()
    cfg = B.carregar_json(a.config)
    pasta = Path(a.saida)
    pasta.mkdir(parents=True, exist_ok=True)
    if PC.SEMENTE != a.semente:
        sys.exit(f"PC_SEMENTE = {PC.SEMENTE} diferente de --semente {a.semente}")
    PC.montar_W = _gancho                       # só guarda as malhas que a função original devolve
    rng = np.random.default_rng(PC.SEMENTE)
    R, tempos, diag = {}, {}, {"semente": a.semente, "inicio": B.agora(), "versoes": B.versoes()}
    t00 = time.time()
    R_S7_V1E = R_S8_V1 = linhas_V1E = None
    for chave, f in BLOCO:
        CAPT.clear()
        t0 = time.time()
        R[chave] = f(rng)
        tempos[chave] = round(time.time() - t0, 1)
        PC.log(f"  [{chave}: {tempos[chave]:.0f} s]")
        if chave == "S7_S10_dispersao_lorentz":
            t1 = time.time()
            esp, lin_esp = s7(CAPT, proj_original)
            diag["espelho_S7_confere"] = iguais(esp, R[chave]) and iguais(lin_esp, PC.TABELAS["dispersao.csv"])
            pl = ProjLimpo()
            R_S7_V1E, linhas_V1E = s7(CAPT, pl)
            diag["S7_V1E_limpeza"] = pl.diag
            tempos["S7_V1E"] = round(time.time() - t1, 1)
        if chave == "S8_S9_energia_momento_helicidade":
            t1 = time.time()
            esp, _ = s8(CAPT, limpar=False)
            diag["espelho_S8_confere"] = iguais(esp, R[chave])
            R_S8_V1, d8 = s8(CAPT, limpar=True)
            diag["S8_V1_limpeza"] = d8
            tempos["S8_V1"] = round(time.time() - t1, 1)
        CAPT.clear()
    PC.montar_W = _montar_original
    resol = {"disp": PC.RES_DISP, "em": PC.RES_EM, "cons": PC.RES_CONS, "pol": PC.RES_POL, "guia": PC.RES_GUIA}
    base = {"bloco": "B1a", "semente": PC.SEMENTE, "resolucoes": resol, "tempos_s": tempos,
            "tempo_total_s": round(time.time() - t00, 1)}
    tab0 = copy.deepcopy(PC.TABELAS)
    out0 = {**base, "variante": "V0", "R": R, "tabelas": tab0}
    R1 = copy.deepcopy(R)
    R1["S8_S9_energia_momento_helicidade"] = R_S8_V1
    out1 = {**base, "variante": "V1", "R": R1, "tabelas": tab0}
    R1E = copy.deepcopy(R1)
    R1E["S7_S10_dispersao_lorentz"] = R_S7_V1E
    out1e = {**base, "variante": "V1E", "R": R1E, "tabelas": {"dispersao.csv": linhas_V1E}}
    for v, o in (("V0", out0), ("V1", out1), ("V1E", out1e)):
        B.salvar_json_bloco(pasta / f"B1a_{v}_{PC.SEMENTE}.json", o)
    B.salvar_csv_como_B1(pasta / "V0" / "c5a_photon_closure_dispersao.csv", tab0["dispersao.csv"])
    B.salvar_csv_como_B1(pasta / "V1E" / "c5a_photon_closure_dispersao.csv", linhas_V1E)
    diag["fim"] = B.agora()
    diag["tempos_s"] = tempos
    B.salvar_json(pasta / f"diagnostico_B1a_{PC.SEMENTE}.json", diag)
    print(f"B1a {PC.SEMENTE}: espelho S7 {diag['espelho_S7_confere']}, espelho S8 {diag['espelho_S8_confere']}", flush=True)


if __name__ == "__main__":
    main()
