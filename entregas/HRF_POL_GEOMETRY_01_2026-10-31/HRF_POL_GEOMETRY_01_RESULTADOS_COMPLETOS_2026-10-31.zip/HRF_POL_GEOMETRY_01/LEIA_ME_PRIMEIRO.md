# HRF-POL-GEOMETRY-01

[M/D] Bancada local Codex de 34 casos em cinco distribuições. Leia o pré-registro, os relatórios científico e de auditoria. B41L e POL-B41L-01 estão preservadas em dependencias/. Nenhum acesso ao Drive é necessário.

```bash
python -m pip install -r requirements.txt
python -I tests/test_interfaces.py
python -I scripts/rodar.py prepare --workers 4
python -I scripts/rodar.py smoke --workers 4 --executar
python -I scripts/rodar.py run --workers 4 --executar
python -I scripts/rodar.py evaluate
```

A principal exige os selos de testes, fumaça, admissão e hashes de pré-registro/malhas. Os registros brutos são preservados, inclusive FAIL. Repetir a mesma versão retoma checkpoints e casos selados; configurações/código diferentes exigem pasta/versão nova. Não editar critérios depois de ver a principal.

Os casos G5 são apenas seis: helicidades opostas e uma direção extra em cada tamanho. Todas as execuções principais são circulares; controles nulos/oscilatórios são somente testes. A geração tetraédrica desordenada é um modelo angular com ausência de picos de Bragg fortes na amostra finita, não água molecular realista.
