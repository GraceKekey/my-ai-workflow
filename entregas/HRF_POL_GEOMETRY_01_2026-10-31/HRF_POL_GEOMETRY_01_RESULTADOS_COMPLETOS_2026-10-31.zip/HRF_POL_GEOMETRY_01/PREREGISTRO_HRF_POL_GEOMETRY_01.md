# HRF-POL-GEOMETRY-01 — pré-registro v0.1

[D] Data local: 31/10/2026, America/Sao_Paulo. Congelamento SHA-256 antes da fumaça e da rodada principal. Nova bancada, sem alterar B1/B41/B41H/B41L/POL-B41L-01. Mapa estudado: W. G e D holográficos não são testados.

## Objetivo e hipóteses

[H] Comparar polarização circular sobre cinco distribuições espaciais no mesmo modelo B41L. H1: mistura espectral irregular prejudica o extrator de frequência única. H2: a falha também pode ocorrer na cúbica. H3: ordem tetraédrica desordenada altera a mistura frente a Poisson. H4: ordem cristalina tetraédrica difere da desordenada.

[D] H1 é compatível na coorte quando ao menos metade dos casos irregulares com cobertura modal >=95% e mistura significativa (>=2 grupos com >=1% da energia capturada e maior grupo <=95%) apresenta: resíduo mono >0,05, predição modal <=0,05 e redução por fator >2. Sem esses exemplos, com dados elegíveis, a hipótese operacional é contrariada nesta coorte; cobertura insuficiente fica PENDING. Não se confunde uma única frequência deslocada com mistura de frequências. Grupos numericamente degenerados: tolerância 1e-8*omega, somados coerentemente.

[D] H2 é compatível na coorte se algum dos quatro controles cúbicos exceder o limite mono de 0,05; contrariada na coorte se os quatro passam esse limite. H3/H4 usam largura espectral de energia relativa a omega, nas medianas por tamanho, excluindo a orientação extra de G5. Razões G4/G3 e G5/G4 <=0,8 em ambos os níveis são redução compatível; >=1,2 em ambos, aumento compatível; em (0,8;1,2) em ambos, ausência de efeito de 20% nesta coorte; sinais mistos ou faltas, PENDING. Esses são tamanhos de efeito exploratórios pré-especificados, não testes populacionais de significância.

## Parâmetros e geometrias

[D] Caixa plana periódica L=4, c=1, unidades adimensionais históricas. N=64 e 216 em TODAS as famílias; escalas de densidade ell=1 e 2/3, mesmo volume e densidade por nível. k=(0,0,1)*2pi/L, omega=|k|, oito períodos nominais, dt original=1/sqrt(limite_wmax). G5 acrescenta +s em k=(1,0,0), mesmo módulo. Não há milhares de casos: 4 G1, 8 G2, 8 G3, 8 G4, 6 G5 = 34.

- G1: n=4/6, pontos cúbicos uniformes, origem (g+0,371)*ell. Triangulação Freudenthal periódica com seis tetraedros por cubo, uma escolha Delaunay nos empates coesféricos.
- G2: inibição sequencial aleatória periódica, N fixo, separação >=0,65 ell; teto 200.000 propostas; não relaxar o raio ao falhar.
- G3: posições iid uniformes na caixa, equivalentes a Poisson homogêneo condicionado a N. Nenhum ponto próximo ou tetraedro ruim é descartado.
- G4: pontos inicialmente Poisson-disk, recozimento Monte Carlo da energia E=sum(1-q4)+0,3 sum[(r4/(sqrt(3)ell/2)-1)^2]+4 sum max[(0,6ell)^2/r_ij^2-1,0]^2. 120 varreduras, T=0,2→0,002 geometricamente, deslocamento gaussiano 0,18ell→0,025ell. Sem molde cristalino ou potencial molecular validado. Exigir q médio >=0,5 e maior |mean exp(ikx)|² <=0,25 para k inteiros em [-6,6]^3 exceto zero. Isso testa ausência de Bragg forte apenas nessa amostra finita, não a ausência de periodicidade em escala infinita numa caixa repetida.
- G5: diamond-like, oito sítios por célula convencional FCC+deslocamento(1/4,1/4,1/4), supercélulas 2³ e 3³, N=64/216. Translação global de (0,137;0,193;0,271)ell evita centroides exatamente sobre as faces da caixa, sem distorcer a rede. Coordenação nativa quatro, q4=1. Desempate das coesfericidades por lifting ponderado periódico, peso 1e-7 ell², seed618001. Coordenadas não são perturbadas. Exigir validade Delaunay não ponderada, além de fechamento periódico. Não se preenche o espaço com tetraedros regulares.

[D] Sementes principais 73010001 e 73010002 nas famílias G2–G4. G1/G5 determinísticas, seed73010001 apenas como identificador. Fumaça fora da decisão: cinco famílias N64, s=+1, seed73019001, quatro períodos. Os controles unitários usam seed73019999.

## Lançamento helicoidal e comparação

[F/M] Q_s=onda_aresta(k,a(e1-i s e2)/sqrt(2)); q=Re Q_s; v0=|k|Im Q_s; v1=v0-d0 lambda por Limpador original. Base original e1×e2=kh. A convenção física do extrator dá S3 inicial=-s; s não é automaticamente a helicidade física. Toda execução principal é circular. O campo gira pela evolução calculada, sem reconstrução artificial de hélice.

[D] Amplitude de referência a=0,001 em todas as geometrias; energia V1 alvo 7,895683520871486e-5, fixada pela expressão contínua V omega² a²/2. Após limpar v, aplicar um único fator escalar sqrt(H_alvo/H_bruto) a q,v,v0 apenas no lançamento. Não é matematicamente possível impor simultaneamente a mesma amplitude efetiva e a mesma energia exata com formas de Whitney diferentes. Registram-se amplitude efetiva, fator e energia bruta. Não há renormalização durante a evolução.

[F/M] O controle V0 pareado usa a identidade histórica q0(t)=q1(t)+t vL e v0=v1+vL, com K d0=0. É reconstrução analítica da solução original, não uma segunda rodada independente. A identidade é testada contra integração direta no controle pequeno. A energia V0 pode diferir da V1 devido à carga espúria; é registrada, não igualada artificialmente.

## Operadores, medidas e estabilidade

[M] Mesmo Complexo original, orientação canônica, M1/M2 de Whitney e K=d1T M2 d1; mesmo kernel de Verlet extraído sem alterar seus quatro nós AST. Novos adaptadores fornecem apenas posições e regras explícitas de desempate. Não se injeta jitter para regularizar cristais. Lei de Gauss, energia, fluxo/momento, E=-Whitney(v), B=curl(q), Stokes e análise de janelas são os originais.

[D] Salvar cada passo temporal, oito subvolumes fixos, q/v em cerca de nove snapshots, V0 pareado, amplitudes regionais complexas, energia, carga de Gauss e sua variação vetorial. Sem redução silenciosa de registros. Checkpoints atômicos a cada 1024 passos, com identidade de código+configuração+caso. Limite 65.536 frames por caso; excedê-lo é BLOCKED_RESOURCES, sem ressementeamento ou aumento oculto de dt. Até quatro processos de uma thread, orçamento 1,5GiB por processo +1GiB reserva, armazenamento admitido antes da principal.

## Gates congelados

[D] G0: todos os hashes de fonte original, configuração e código novo conferem. G1: volume relativo <=1e-10, duas incidências por face, Euler toroidal zero, d1d0=0, M1 positiva definida, assimetria relativa M1/K <=1e-12, violação de esfera vazia Delaunay <=1e-7 ell²; condições adicionais de cada gerador acima. Nenhuma lasca é removida.

[D] G2: preparação pelo extrator POL original, Gauss <=1e-8, distância Stokes inicial <=0,05 e grau inicial >=0,99. G3: conservação real de energia <=0,005 e variação de Gauss <=1e-8. Estabilidade: dt*limite_wmax_original=1 <2, limite de Rayleigh local com matrizes positivas, além de teste oscilatório e solução nula.

[D] G4: requer G3/G4/G6 do avaliador POL original todos PASS e fração mínima na helicidade lançada >=0,99. Preservar os limiares: resíduo mono <=0,05, sensibilidade de janelas <=0,02, potência longitudinal <=0,05, gauge<=1e-8, deriva Stokes<=0,05, intensidade<=0,05, grau<=0,02, fase<=0,1rad, erro Maxwell<=0,1. Janelas 2/3/4 períodos, primária 3, sobreposição 50%, >=24 amostras, condição<=100. Nenhuma frequência é recalibrada para fazer o extrator passar.

[D] G5: FAIL se comparação física G4 ou qualidade G1 falhar; caso contrário PENDING para robustez, pois só há dois níveis e duas realizações, sem refinamento temporal principal. Não declarar ordem de convergência/população certificada. G6: diagnóstico modal PASS se resíduos próprios e ortogonalidade <=1e-8, energia inicial capturada >=95% e erro de predição real <=0,05. Cobertura insuficiente é PENDING; inconsistência espectral é FAIL. A predição não altera os gates do extrator anterior. G7: FAIL operacional se algum G0/G1/G2/G3/G4/G6 falhar; caso contrário PENDING enquanto G5 não fechar.

## Diagnóstico multimodal independente

[F/M] Problema generalizado K u=lambda M1 u, faixa lambda em [0,1 omega²;4 omega²], sem ajuste aos campos evoluídos. Projeções iniciais a=uT M1 q0, b=uT M1 v0. Fase discreta exata do Verlet theta=2 asin(sqrt(lambda)dt/2). Predição v_j(t_n)=b_j cos(n theta)-a_j sin(theta)/dt sin(n theta). Reconstruir campos Whitney e comparar séries complexas reais. Isso separa erro do portador nominal de mistura de frequências, sem substituir a dinâmica por Maxwell. Captura energética e banda truncada são declaradas. Grupos degenerados somados coerentemente para medidas transversais; desdobramento espectral é diagnóstico, não prova automática de birrefringência física.

## Limites e interpretação

[?] Ondas em rede 3D prescrita, Hamiltoniano Wilson no limite quadrático. Uma helicidade operacional não é spin quântico medido; polarização circular não é trajetória helicoidal de energia. As geometrias não demonstram água/gelo moleculares, microestrutura HRF real, origem do fóton, U(1), ħ, quantização, holografia ou unificação. Documentos de boundary 2D não foram usados para substituir esta bancada histórica 3D. POL-01/P01–P05 original segue indisponível; isso permanece lacuna histórica, sem reclassificação.

## Correção técnica pré-execução 01

[D] O teste de esfera vazia encontrou uma incompatibilidade da semântica de solve vetorizado no NumPy 2.2: o lado direito (T,3) precisava de eixo final (T,3,1). Corrigido antes de qualquer fumaça/principal, sem mudar coordenadas, operadores, critérios ou tolerâncias. Código anterior e hashes estão em auditoria/correcao_preexecucao_01; logs testes_v01/testes_v02 são preservados.

## Correção técnica pré-execução 02

[D] A preparação da diamond N216 detectou três facetas quase verticais do casco 4D exclusivamente fora da caixa fundamental, na região de padding que o construtor original já descarta. O adaptador agora aplica essa mesma seleção de centroides antes de validar o determinante; nenhum tetraedro central ou ponto foi removido. Código anterior, hashes e log da preparação são preservados. Acrescentado teste explícito N216. Ainda não houve fumaça ou rodada principal.
