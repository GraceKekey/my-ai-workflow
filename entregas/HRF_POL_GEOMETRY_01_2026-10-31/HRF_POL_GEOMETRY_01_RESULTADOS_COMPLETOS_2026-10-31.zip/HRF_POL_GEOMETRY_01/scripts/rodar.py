"""Entrada explícita; importação não inicia simulações."""
import os,sys,tempfile
from pathlib import Path
for key in ['OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[key]='1'
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'hrf-pol-mpl'));os.environ.setdefault('XDG_CACHE_HOME',str(Path(tempfile.gettempdir())/'hrf-pol-cache'));sys.dont_write_bytecode=True
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from controller import main
if __name__=='__main__':raise SystemExit(main())
