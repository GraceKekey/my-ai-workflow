"""Verificação SHA-256 sem importar o solver."""
from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parents[1];manifest=root/(sys.argv[1] if len(sys.argv)>1 else 'MANIFESTO_SHA256.txt');count=0
for line in manifest.read_text(encoding='utf-8').splitlines():
 if not line or line.startswith('#'):continue
 expected,name=line.split('  ',1);p=(root/name).resolve()
 if not p.is_relative_to(root) or not p.is_file():raise SystemExit('Ausente/inseguro: '+name)
 h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 if h.hexdigest()!=expected:raise SystemExit('SHA difere: '+name)
 count+=1
print('OK:',count,'arquivos verificados')
