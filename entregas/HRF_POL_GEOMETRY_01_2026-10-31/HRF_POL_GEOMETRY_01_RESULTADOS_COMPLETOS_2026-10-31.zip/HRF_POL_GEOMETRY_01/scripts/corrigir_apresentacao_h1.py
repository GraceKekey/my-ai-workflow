"""[D] Errata editorial somente leitura de resultados; nenhum gate é reavaliado."""
from pathlib import Path
import json
root=Path(__file__).resolve().parents[1];p=root/'RELATORIO_CIENTIFICO.md';s=p.read_text();h=json.loads((root/'resultados/principal/resumo.json').read_text())['hypotheses']
start=s.index('[M/H] H1:');end=s.index('[M/H] H2:',start)
s=s[:start]+f'[M/H] H1: {h["H1_compatible_cases"]}/{h["H1_multigroup"]} casos irregulares elegíveis satisfizeram a regra congelada; estado {h["H1"]}. A classificação inclui somente G2/G3/G4; não modifica o extrator anterior.\n'+s[end:]
p.write_text(s)
print('Apresentação H1 corrigida a partir do JSON congelado, sem alterar decisões.')
