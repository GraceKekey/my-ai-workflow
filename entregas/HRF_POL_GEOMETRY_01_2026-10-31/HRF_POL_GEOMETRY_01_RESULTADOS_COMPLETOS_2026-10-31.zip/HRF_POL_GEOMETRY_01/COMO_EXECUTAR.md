# Execução local explícita

Instale requirements.txt em ambiente Python compatível. Os comandos de simulação são somente leitura de casos selados quando a execução já está completa. Nenhuma instalação/importação inicia rodadas.

```bash
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -I tests/test_interfaces.py
python -I scripts/rodar.py prepare --workers 4
python -I scripts/rodar.py smoke --workers 4 --executar
python -I scripts/rodar.py run --workers 4 --executar
python -I scripts/rodar.py evaluate
```

Use uma cópia independente para reproduzir a integração desde o início, preservando o original e as malhas seladas. A fonte em src/ e as configurações não podem ser alteradas mantendo os mesmos checkpoints. O número de processos pode ser reduzido para 1 ou 2 sem mudar as condições científicas. A admissão verifica CPU, RAM e disco antes da principal.

O manifesto geral cobre todos os arquivos finais; HASHES_ANTES_PRINCIPAL e HASHES_MALHAS_ANTES_PRINCIPAL registram os congelamentos anteriores aos resultados. As fontes B41L/POL ficam em dependencias/.

Depois de reexecutar `evaluate`, aplique `python -I scripts/corrigir_apresentacao_h1.py`: ele corrige apenas a apresentação da contagem H1 no relatório automático a partir do JSON congelado, sem alterar avaliações. Essa errata editorial foi adicionada após a rodada e possui hash separado em HASHES_POS_PROCESSAMENTO.txt. O script original e seu relatório gerado são preservados para auditoria.

Para conferir os arquivos finais: `python -I scripts/verificar_manifesto.py`.
