import sys,tempfile,json,unittest
from pathlib import Path
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'src'))
from historical import verify,D,Observer,stokes
from geometry import points,characterize
from mesh_adapter import context,spectrum
from experiment import plan_cases,launch,run_case

class Algebra(unittest.TestCase):
 def test_exact_plan_and_historical_signs(self):
  c,rows=plan_cases();self.assertEqual(len(rows),34);self.assertEqual(len({r['case_id'] for r in rows}),34)
  self.assertEqual([sum(r['family']==f for r in rows) for f in ['G1','G2','G3','G4','G5']],[4,8,8,8,6])
  self.assertTrue(all(r['state']==('C-' if r['s_historical']==1 else 'C+') for r in rows))
 def test_dependencies_unchanged(self):self.assertTrue(verify())
 def test_periodic_minimum_separation_and_seed(self):
  P,_=points('G2',4,73019999);Q,_=points('G2',4,73019999);np.testing.assert_array_equal(P,Q)
  self.assertGreaterEqual(characterize(P,4)['minimum_distance'],.65)
 def test_conditional_poisson_is_unconditioned_positions(self):
  P,_=points('G3',4,123);np.testing.assert_array_equal(P,np.random.default_rng(123).uniform(0,4,(64,3)))
 def test_disordered_tetrahedral_without_crystal(self):
  P,_=points('G4',4,73019999);stats=characterize(P,4)
  self.assertGreater(stats['mean_q'],.5);self.assertLess(stats['bragg_max'],.25)
 def test_diamond_native_coordination_not_solver_edges(self):
  P,_=points('G5',4,123);stats=characterize(P,4);self.assertGreater(stats['mean_q'],1-1e-12)
  self.assertTrue(np.all(stats['native_undirected_coordination']==4));C=context(P,dict(L=4,family='G5',n=4))
  self.assertEqual(C['quality']['technical_gate'],'PASS');self.assertGreater(C['C'].E,len(stats['native_edges']))
 def test_diamond_216_padding_is_not_physical_domain(self):
  P,m=points('G5',6,123);ctx=context(P,m);self.assertEqual(ctx['quality']['technical_gate'],'PASS');self.assertEqual(ctx['C'].T,1944)
 def test_verlet_modal_prediction_is_actual_discrete_solution(self):
  eig=np.array([.3,1.7,5.]);dt=.17;a0=np.array([1.,.2,-.4]);b0=np.array([.2,-.3,.7]);q=a0.copy();v=b0.copy();acc=-eig*q
  class LU:
   def solve(self,x):return x
  step,_=D.original_step();theta=2*np.arcsin(np.sqrt(eig)*dt/2)
  for j in range(30):
   expected=b0*np.cos(j*theta)-a0*np.sin(theta)/dt*np.sin(j*theta);np.testing.assert_allclose(v,expected,atol=2e-15)
   q,v,acc=step(q,v,acc,dt,LU(),np.diag(eig))

class Interfaces(unittest.TestCase):
 @classmethod
 def setUpClass(cls):
  P,m=points('G1',4,73019999);cls.ctx=context(P,m);cls.ctx.update(geometry_gate='PASS',mesh_key='technical_cube');cls.ctx['spectrum']=spectrum(cls.ctx,np.pi/2)
  cls.c,rows=plan_cases(True);cls.x=rows[0]
 def test_periodic_cubic_operator_quality(self):
  Q=self.ctx['quality'];self.assertEqual(Q['technical_gate'],'PASS');self.assertEqual(Q['T'],384);self.assertTrue(Q['all_faces_two_tetrahedra']);self.assertEqual(Q['euler'],0)
 def test_historical_launch_energy_gauss_and_measured_stokes(self):
  for s in [1,-1]:
   x={**self.x,'s_historical':s};q,v,vL,p=launch(self.ctx,x,self.c);M=self.ctx['M1'];K=self.ctx['K'];C=self.ctx['C']
   self.assertAlmostEqual((.5*v@(M@v)+.5*q@(K@q))/self.c['energy_target'],1,places=12)
   self.assertLess(np.linalg.norm(C.d0.T@(M@v))/np.linalg.norm(M@v),1e-10)
   obs=Observer(self.ctx,p['k'],p['e1'],p['e2']);measured=stokes(obs.initial_phasor(q,v,p['omega']),obs.weights)
   self.assertAlmostEqual(measured['s'][2],-s,places=8)
 def test_null_solution_and_V0_identity(self):
  ctx=self.ctx;q,v,vL,p=launch(ctx,self.x,self.c);q0=q.copy();v0=v+vL;a=-ctx['lu'].solve(ctx['K']@q);a0=a.copy();dt=ctx['dt_original'];step,_=D.original_step()
  z=np.zeros_like(q);zz,zero,za=step(z.copy(),z.copy(),z.copy(),dt,ctx['lu'],ctx['K']);self.assertTrue(np.all(zz==0) and np.all(zero==0))
  for j in range(8):
   np.testing.assert_allclose(q0,q+j*dt*vL,atol=2e-16);np.testing.assert_allclose(v0,v+vL,atol=2e-16)
   q,v,a=step(q,v,a,dt,ctx['lu'],ctx['K']);q0,v0,a0=step(q0,v0,a0,dt,ctx['lu'],ctx['K'])
 def test_checkpoint_resume_is_bitwise_identical(self):
  c={**self.c,'smoke_periods':.5,'checkpoint_steps':2};ctx=self.ctx;x=self.x
  with tempfile.TemporaryDirectory() as temp:
   one=Path(temp)/'one';two=Path(temp)/'two';one.mkdir();two.mkdir();run_case(x,c,ctx,one)
   original=D.original_step;actual,checksum=original();count=[0]
   def interrupt(*args):
    count[0]+=1
    if count[0]==5:raise KeyboardInterrupt()
    return actual(*args)
   D.original_step=lambda:(interrupt,checksum)
   try:
    with self.assertRaises(KeyboardInterrupt):run_case(x,c,ctx,two)
   finally:D.original_step=original
   run_case(x,c,ctx,two)
   with np.load(one/x['case_id']/'fields.npz') as A,np.load(two/x['case_id']/'fields.npz') as B:
    self.assertEqual(set(A.files),set(B.files))
    for name in A.files:np.testing.assert_array_equal(A[name],B[name])
if __name__=='__main__':unittest.main(verbosity=2)
