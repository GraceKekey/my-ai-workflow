# Holographic Reconstruction of Physics
## Research Book of the Holographic Reconstruction Framework (HRF)
# Capítulo 2 — A onda fotônica livre

**Versão:** 1.5 (a v1.4 com a bancada B41H, que identifica a causa das falhas de preparação do estado de helicidade) · **Data:** 29 de outubro de 2026 — Claude (`-clau`)
**Autoria:** Mario José do Canto Filho, MD
**Programa:** Holographic Reconstruction Framework (HRF) / The Understanding Initiative · **ramo:** HRF-FM — Fields and Matter Reconstruction
**Proveniência histórica:** este capítulo deriva do ramo **C5A** do antigo PRFE Framework. Rótulos C5A/C5B em bancadas, arquivos e fontes históricas são mantidos para rastreabilidade.
**Base canônica:** `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_4_PT_2026-10-28_1653-clau.md` (v1.4). A v1.4 junta a v1.3 de 28/10 (B41) e a minuta Levin–Wen de 18/10; a v1.3, por sua vez, parte da v1.2 de 9 de outubro de 2026 (`HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_2_PT_2026-10-09.md`: fechamento provisório v1.0 de 2 de outubro, migração editorial da v1.1 e adendo 2D3V da §2.4.1) e incorpora a B41.
**Trechos incorporados:** a minuta `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_3_MINUTA_Levin_Wen_PT_2026-10-18.md` (nova §2.8.4 e notas editoriais em §§2.3.2, 2.8.2, 2.9 e 2.11), por decisão do pesquisador em 28 de outubro de 2026 [D]. Para essa parte, nenhum teste novo foi executado; o conteúdo entrou sem mudança.
**Base científica nova (v1.3):** a bancada mestre **B41** (pré-registro em 27 de outubro, 20:10; execução, correção declarada M07c e relatório em 28 de outubro). As bandas da B41 foram tiradas da v1.1; a v1.2 não mudou nenhum número.
**Base científica nova (v1.5):** a bancada **B41H** (pré-registro em 29 de outubro, 00h27; fumaça, correções C01 e C02 do caderno, rodada completa e relatório em 29 de outubro).
**Substitui:** a v1.4 de 28/10. Os resultados, números, critérios e decisões das bancadas originais e da B41 **não foram alterados** (registro de mudanças abaixo).
**Fontes:** Master Research Notebook v1.7 (§§11–21, 120–124, 142–168); relatórios e pacotes HOL1, B1, B3, B8, B10,
B11-luz-luz, B12-faixa (revisão 1); consolidação do fluxo par *Microestrutura inversa, B11/B12 e teto unificado*;
INVERSE-01/02, B11-Morse, B12-Morse e B14 (fluxo par; B14 auditada nesta sessão).
**Fontes da §2.8.4 (minuta de 18/10):** Levin e Wen 2005, *Reviews of Modern Physics* **77**, 871; Levin e Wen 2006, *Physical Review B* **73**, 035122.
**Fontes novas da v1.3:** `HRF_B41_PROTOCOLO_2026-10-27_2010-clau.md`, `LEIAME_B41.md`, `FUMACA_B41.md` e hashes de 27/10;
`FUMACA_B41_REGISTRO_2026-10-28_0900-clau.md` e `HRF_B41_hashes_correcao_M07c_2026-10-28_0900-clau.txt`;
`HRF_B41_Relatorio_e_Auditoria_PT_2026-10-28_1430-clau.md`; saídas brutas em `HRF_B41_RESULTADOS_com_M07c.zip`
(`avaliacao_B41.json`, `avaliacao_B41_com_correcao_M07c.json`, `M02/avaliacao_B1_B41.json`, `M07c/poisson8.json`,
`M07c/poisson10.json`).
**Fontes novas da v1.5:** `HRF_B41H_PROTOCOLO_2026-10-29_0027-clau.md`, `LEIAME_B41H.md`, `FUMACA_B41H.md` e hashes de
29/10, 00h27; `FUMACA_B41H_REGISTRO_2026-10-29_0055-clau.md`, `HRF_B41H_REGISTRO_EXECUCAO_2026-10-29_0430-clau.md` e
adendo de 10h04, com os hashes das correções C01 e C02; `HRF_B41H_Relatorio_e_Auditoria_PT_2026-10-29_1816-clau.md`;
saídas brutas em `HRF_B41H_RESULTADOS_COMPLETOS_2026-10-29_210503.zip` (`avaliacao_B41H.json` e as 168 saídas).

**Marcas:** [F] física ou matemática estabelecida · [M] resultado de toy model ou bancada · [H] hipótese específica do HRF ·
[?] questão aberta · [D] decisão editorial ou metodológica do pesquisador.

**Escolhas de redação desta versão:** ordem lógica (do substrato à observação), com o histórico em caixas curtas;
equações essenciais no corpo e detalhes em caixas técnicas; analogias médicas em notas curtas; “luz em meios e guias”
fica como caixa neste capítulo (pode ganhar capítulo próprio depois).

**Nota terminológica da migração HRF:** **GMF** é mantido como o nome técnico dos graus usados neste toy model fotônico, porque o próprio esqueleto do HRF ainda deixa em aberto a relação formal entre **PGFE, GMF e as entidades do HRF-PD**. Portanto, esta revisão **não** impõe uma substituição GMF → PGFE. Do mesmo modo, “microgeometria” é preservado quando descreve a conectividade/deformação das malhas históricas C5A; isso não equivale à reconstrução de geometria e espaço-tempo, que pertence ao programa **HRF-ST**.

**Numeração das bancadas:** ímpares neste fluxo de trabalho (B13, B15…), pares no outro (B14, B16…). As duas bancadas
antigas com número repetido são citadas com rótulo: **B11-luz-luz** e **B12-faixa** (este fluxo), **B11-Morse** e
**B12-Morse** (fluxo par).

> **Histórico.** v1.0 (2 out): fechamento provisório C5A. v1.1 (5 out): migração editorial para o HRF. v1.2 (9 out): “acrescentada a seção 2.4.1, que identifica os dois modelos 2D3V usados nas bancadas atuais (Yee e Voronoi–Delaunay/Whitney), com seus resultados e gates independentes. Nenhum resultado do fechamento histórico do Capítulo 2 foi recalculado ou reclassificado.” Minuta v1.3 (18 out, ramo paralelo): integração bibliográfica Levin–Wen. v1.3 (28 out): bancada mestre B41. v1.4 (28 out): junção das duas. v1.5 (29 out): bancada B41H.

> **Registro de mudanças v1.4 → v1.5 [D].**
> - **Nova §2.14:** a bancada B41H (objetivo, hipóteses, parâmetros, protocolo, medidas, resultados, controles,
>   interpretação). A causa das falhas de preparação do estado de helicidade é a carga espúria do lançamento.
> - **§2.5.3:** correção. O item 9 da semente 41020004 falhou na malha-guia h = 0,46 (η_g = 0,0116 contra 0,01). A v1.3
>   dizia que a saída do avaliador não indicava a malha; a informação estava nas saídas brutas da B41 e foi lida ao
>   preparar a B41H. Acrescentado também o parágrafo "Causa identificada (B41H)".
> - Quadro de estado, §2.0, §2.9, §2.10, §2.11, §2.12, §2.13.8 e apêndices atualizados.
> - Nenhuma bancada anterior foi recalculada e nenhum veredito muda: a B1 continua FECHADO e a B41 NÃO REPRODUZIDO.

> **Registro de mudanças v1.3 → v1.4 [D].**
> - **Nova §2.8.4:** origem emergente de campos gauge e férmions pelos mecanismos de Levin–Wen, e notas editoriais em
>   §2.3.2, §2.8.2, §2.9 e §2.11, vindas da minuta de 18/10 sem mudança de conteúdo. Ela registrava: “nova §2.8.4 e notas
>   editoriais limitadas às seções 2.3, 2.8.2, 2.9 e 2.11. Os resultados [M], controles negativos e fechamento provisório
>   §2.12 não foram recalculados nem alterados. `HRF-REF-0112/0113` são IDs **propostos**, ainda não registrados.”
> - Os rótulos “v1.3” desses trechos passaram a “v1.4”, para não confundir com a v1.3 da B41.
> - Correção de digitação: na nota de §2.8.2 da minuta, o “\b” de “\beta_c” tinha virado um caractere de controle (só
>   “eta_c” aparecia). Foi restaurado para β_c.
> - A B41 não testa nada de Levin–Wen, e a §2.8.4 não muda nenhum resultado da B41.

> **Registro de mudanças v1.2 → v1.3 [D].**
> - **Nova §2.13:** a bancada mestre B41 (objetivo, hipótese, parâmetros, protocolo, medidas, resultados, controles,
>   interpretação).
> - **Nova §2.5.3:** a B1 reproduzida nas grandezas, com o critério de robustez por semente (P1) frágil.
> - **§2.4:** o saca-rolha numa malha irregular não é um autovetor único (achado da B41).
> - **§2.7.3:** validação dinâmica da autointeração refeita modo a modo (correção declarada M07c).
> - **Notas “B41” curtas** nas seções de cada bancada (§§2.2.2, 2.3.1, 2.6.3–2.6.5, 2.7.1, 2.7.2, 2.8.1–2.8.3).
> - Quadro de estado, §2.9, §2.10, §2.11, §2.12 e apêndices atualizados.
> - Nenhuma bancada original foi recalculada e nenhum número antigo foi trocado. Os números da B41 aparecem ao lado.
> - **Interface:** desde 21–22 de outubro, o Capítulo 3 do Research Book é *A base quântica compartilhada e a emergência
>   das organizações físicas* (v0.2). A menção a “Capítulo 3 — Microestrutura dinâmica” em §2.12 segue a organização de
>   5 de outubro e fica como designação histórica; o texto dela não foi alterado.

---

## Sumário

- 2.0 Abertura: o que este capítulo afirma
- 2.1 A pergunta e o contrato do fóton livre
- 2.2 O que oscila: a relação, não o GMF
- 2.3 Da conexão à equação de onda
- 2.4 A forma da onda: o pequeno saca-rolha e a propagação reta
- 2.4.1 Nota de atualização (09/10/2026): modelos 2D3V utilizados nas bancadas atuais
- 2.5 O fechamento do fóton efetivo (B1)
- 2.6 O substrato: malhas irregulares, faixa de distâncias e deformação
- 2.7 Frente às observações
- 2.8 A versão quântica
- 2.8.4 Origem emergente de campos gauge e férmions: os mecanismos Levin–Wen *(novo na v1.4)*
- 2.9 O que o capítulo não afirma
- 2.10 Caminhos descartados
- 2.11 Questões abertas e pontes para os capítulos seguintes
- 2.12 Registro de fechamento provisório
- 2.13 Reprodutibilidade: a bancada mestre B41 *(novo na v1.3)*
- 2.14 A preparação do estado de helicidade: a bancada B41H *(novo na v1.5)*
- Apêndice A — Bancadas e arquivos
- Apêndice B — Números de referência
- Apêndice C — Glossário do capítulo

---

## 2.0 Abertura: o que este capítulo afirma

Na arquitetura editorial do HRF, o Capítulo 1 é o lugar reservado para definir o domínio holográfico pré-geométrico e formalizar a relação entre PGFE, GMF e os demais graus fundamentais. Essa identificação ainda não está fechada. Para o setor fotônico, este Capítulo 2 do **HRF-FM** mantém o substrato técnico herdado da C5A: Graus Microestruturais Fundamentais (GMFs), cada um com um estado local, ligados aos vizinhos por uma **conexão relacional**. O capítulo mostra que, nesse substrato de toy model, existe uma onda que se comporta como a luz livre. Livre quer dizer sem fontes, sem cargas e sem curvatura.

**Afirmação central [M].** Num substrato de GMFs com conexão relacional U_nm = e^{ia_nm} e energia de Wilson, emerge
uma onda com as propriedades de Maxwell no vácuo:
- duas polarizações transversais e um modo longitudinal sem dinâmica (gauge);
- ω = ck e P = E/c no limite de comprimento de onda longo;
- helicidade ±1, degenerada no vácuo.

Depois de impor a quantização canônica, ela dá fótons com spin ±ħ e estrutura de Fock bosônica. Tudo isso é compatível
com as observações testadas: Lorentz e isotropia (LHAASO), birrefringência circular (polarização de GRB) e espalhamento
luz-luz (PVLAS e QED).

**Reprodutibilidade [M] (novo na v1.3).** Uma bancada mestre pré-registrada (B41, 28 de outubro de 2026) repetiu os
resultados principais com sementes novas, em outra máquina. Todos os números caíram nas bandas fixadas antes da rodada.
A única decisão que não se reproduziu foi a do critério de robustez por semente da B1 (P1: 8 de 10 sementes, contra o
mínimo de 9). As grandezas que esse critério resume se reproduziram (§2.5.3, §2.13).

**Preparação do estado de helicidade [M] (novo na v1.5).** A bancada B41H (29 de outubro de 2026) achou a causa das
falhas pontuais que tornavam P1 frágil. O saca-rolha copiado do contínuo para a malha não obedece à lei de Gauss
discreta, e a carga espúria contamina a medida da helicidade. Lançar a onda limpa (sem essa carga) zerou as falhas em
140 malhas novas; afinar a malha as reduz, mas sozinho não remove a causa (§2.14).

**Fronteira.** ħ é entrada, não resultado. A conexão U(1) e a energia de Wilson são postuladas. Emissão e absorção de
fótons não estão aqui, porque exigem matéria carregada.

**Quadro de estado**

| Requisito do fóton livre | Estado | Onde |
|---|---|---|
| propagação, ω = ck, P = E/c | [M] fechado | §2.3, §2.5 |
| 2 transversais + gauge | [M] fechado | §2.3 |
| helicidade ±1, degenerada | [M] fechado | §2.4, §2.5 |
| Lorentz no UV compatível | [M] sim, com √ξ·a_ρ ≲ 2,0×10⁻²⁸ m | §2.7 |
| isotropia no IR | [M] sim, a 10⁻⁶ | §2.7 |
| birrefringência do vácuo | [M] compatível no canal circular | §2.7 |
| autointeração / luz-luz | [M] 3×10⁻⁵⁵ da QED | §2.7 |
| independência da faixa de distâncias | [M] velocidade, isotropia e forma da autointeração | §2.6 |
| versão quântica (Fock, ±ħ) | [M]+[F], com ħ e quantização impostos | §2.8 |
| conexão compacta compatível | [M] sim, na fase de Coulomb | §2.8 |
| **reprodução com sementes novas (B41)** | **[M] 61/61 bandas; decisão de P1 da B1 não reproduzida (8/10)** | **§2.5.3, §2.13** |
| **preparação do estado de helicidade (B41H)** | **[M] causa identificada: carga espúria do lançamento; o lançamento limpo zera as falhas (0/140)** | **§2.5.3, §2.14** |
| emissão/absorção de um quantum | [?] fora deste ramo | §2.11 |
| origem de ħ, U(1), α, carga | [?] fora deste ramo | §2.11 |

> **Analogia.** O sinal nervoso não é o neurônio viajando: é uma mudança passada de célula em célula. No toy model fotônico do **HRF-FM** (historicamente C5A), o que
> oscila e passa adiante não é nem o GMF (o “neurônio”) nem o seu estado interno, mas a **relação** entre vizinhos
> (a “sinapse”).

---

## 2.1 A pergunta e o contrato do fóton livre

A pergunta do capítulo: **o que uma onda precisa ter para ser chamada de fóton livre**, e o substrato técnico usado pelo **HRF-FM** neste capítulo produz
isso?

O contrato foi fixado antes dos modelos (caderno §18, §124):

1. propagação sequencial, de vizinho em vizinho, sem que os GMFs se desloquem;
2. ω = ck e P = E/c no limite de baixa energia (massa zero);
3. exatamente duas polarizações físicas, transversais;
4. um modo longitudinal sem dinâmica, isto é, uma simetria de gauge;
5. helicidade h = ±1, as duas com a mesma velocidade no vácuo;
6. spin separado de momento angular orbital (OAM);
7. Lorentz recuperado no limite de baixa energia, com desvios abaixo dos limites observacionais;
8. versão quântica com E = ħω e S = ±ħ.

Dois níveis de fechamento são distinguidos desde o início:
- **PHOTON-CLOSURE-E** (fóton efetivo): o toy model reproduz o contrato acima;
- **PHOTON-CLOSURE-F** (fóton físico): o fóton real seria derivado, incluindo ħ, U(1), emissão e absorção.

Este capítulo fecha o primeiro, não o segundo.

---

## 2.2 O que oscila: a relação, não o GMF

### 2.2.1 A primeira tentativa: o estado local

> **Histórico (caderno §§11–16).** O primeiro candidato a fóton foi um Modo Circular Transversal do estado local
> q_n: q_x = A cos(kz − ωt), q_y = ±A sin(kz − ωt). Os GMFs ficam no lugar e o padrão muda de GMF em GMF. A amplitude
> foi escolhida à mão para dar E = ħω e |S| = ħ, um defeito corrigido depois pela quantização canônica (§2.8). Numa
> cadeia, ω(k) = 2√(κ/μ)|sin(ka/2)|, com ω ≈ ck e c = a√(κ/μ) no contínuo. Um pacote circular na rede conservou energia
> a 10⁻⁹, L_z a 10⁻¹⁵, andou com a velocidade de grupo (erro 1,7×10⁻⁴) e deu L_zω/E ≈ ±1.

Esse caminho funcionava em cadeias, mas esbarrou em dois problemas: um campo vetorial genérico tem um modo
longitudinal físico (§2.3), e não havia razão microscópica para a estrutura rotacional que o elimina.

### 2.2.2 Por que o estado local não serve (HOL1, parte P2) [M]

A bancada HOL1 testou se o grau que vive nas ligações poderia ser **derivado** do estado local q_n:

- **diferença transportada** D_nm q = q_m − P_nm q_n: as diferenças se cancelam ao longo de um laço fechado e sobra
  (H_f − I)q. No espaço plano, a energia é identicamente zero; num poço, aparece um termo tipo massa (ω² independente
  de k). **Falha.**
- **projeção na ligação:** o modo longitudinal fica mole (ω_L²/ω_T² cai de 0,19 para 0,029 com o refinamento), mas
  **propaga** em resolução finita. Seria uma terceira polarização lenta, que mudaria por exemplo a lei de
  Stefan–Boltzmann. **Falha.**

**B41 (M01):** a projeção na ligação deu ω_L²/ω_T² = 0,222 na malha grossa e 0,0278 na fina, contra 0,19 e 0,029.

### 2.2.3 Por que a conexão serve (HOL1, parte P3) [M]

O grau que funciona é uma **fase própria de cada ligação**:

\[
U_{nm}=e^{ia_{nm}},\qquad U_{mn}=U_{nm}^{-1},\qquad
H_f=\prod_{\partial f}U=e^{iC_f},\qquad
E_f=w_f\,\|H_f-1\|^2=2w_f(1-\cos C_f)\simeq w_fC_f^2 .
\]

Resultados na malha irregular (Delaunay de 216 a 5 832 GMFs):
- duas transversais com ω/ck = 1,00 ± 0,9%;
- terceiro modo com ω = 0, 100% longitudinal;
- convergência do operador na forma fraca: erro 0,0085 com pesos de Whitney em 5 832 GMFs (orientação embaralhada:
  0,74, sem convergência);
- **gauge exato também com o cosseno completo:** a energia não muda sob a_e → a_e + φ_m − φ_n (girar a fase interna de
  um GMF);
- a energia completa sobre a quadrática vale 0,9999 (|C| = 0,1), 0,997 (0,5), 0,988 (1) e 0,952 (2): o curl-curl é o
  limite de campo fraco, e o resto é autointeração (§2.7.4).

### 2.2.4 Consequência para a ontologia operacional do toy model

\[
\boxed{\text{GMF}=\{q_n\ \text{(estado local)}\}\ \cup\ \{U_{nm}\ \text{(conexão relacional entre vizinhos)}\}}
\]

**Leitura no HRF.** Esta expressão descreve o objeto operacional usado pelo ramo fotônico histórico C5A/atual HRF-FM. Ela **não** identifica, por si só, um GMF com uma PGFE nem com a entidade fundamental do HRF-PD. Essa correspondência permanece **[?]** e deve ser definida no Capítulo 1 e nas interfaces HRF-PD ↔ HRF-FM.

- A metade **geométrica** da cadeia (vizinhança, orientação dos laços, transporte, pesos) está derivada no toy model.
- A metade **dinâmica** (a conexão como grau próprio, com energia de Wilson e termo cinético ½Σ m_e ȧ_e²) é
  **postulado [H]**.
- O resultado coincide com teoria de gauge na rede e com cálculo exterior discreto [F].

> **Caixa — o que é a fase de uma ligação.** Cada GMF tem um referencial interno (uma “fase”). A fase da ligação diz
> como comparar os referenciais de dois vizinhos. Girar o referencial interno de um GMF muda as fases de todas as suas
> ligações, mas não muda nada físico: essa é a simetria de gauge. O que é físico é a volta completa num laço (a
> holonomia), que não depende dessa escolha.

---

## 2.3 Da conexão à equação de onda

### 2.3.1 Laços orientados geram o rotacional

Numa malha de GMFs (tetraedros de Delaunay), cada face triangular é um laço orientado. A circulação no laço é a soma
das fases das suas ligações, com sinal:

\[
C_f=\sum_{e\in\partial f}s_e\,a_e,\qquad E=\tfrac12\,C^{\mathsf T}M_2\,C,\qquad M_1\,\ddot a=-\,d_1^{\mathsf T}M_2\,d_1\,a .
\]

**Nenhum operador rotacional é colocado à mão.** Mesmo assim [M] (bancada do curl-curl emergente, Atualização 20):

\[
d_1^{\mathsf T}M_2\,d_1\ \longrightarrow\ \nabla\times\nabla\times\qquad(\text{forma fraca})
\]

- erro da forma fraca: 0,097 → 0,039 → 0,018 → 0,0087 (216 → 5 832 GMFs), ordem ≈ 2;
- conchas de modos com 12, 24 e 16 modos, isto é, 2 × (número de vetores k): **exatamente duas polarizações**;
- velocidade: c² = (rigidez dos laços)/(inércia das ligações); na cadeia, c = a√(κ/μ).

**B41 (M01) [M]:** erro da forma fraca 0,0086 em 5 832 GMFs, com ordem 2,19; conchas 12, 24 e 16 em 13³.

No contínuo, a equação é a de Maxwell no vácuo no gauge temporal:

\[
\mu\,\ddot{\mathbf A}=-\kappa a^2\,\nabla\times\nabla\times\mathbf A .
\]

### 2.3.2 O gauge vem de graça

Como d₁d₀ = 0 (o rotacional de um gradiente é zero), uma configuração a = ∇φ não tem energia nem dinâmica, e a lei de
Gauss ∇·ä = 0 se mantém sem nenhuma projeção manual. Esta é uma **identidade combinatória**: vale para qualquer posição
dos GMFs, desde que a lista de ligações e laços seja consistente. Por isso ela é um controle de código, não um teste
físico da geometria. O teste físico é o que acontece quando a conectividade muda (§2.6.4).

> **Nota editorial v1.4 — Levin–Wen [F/H/?].** A identidade combinatória \(d_1d_0=0\) estabelece a invariância da energia de laços **dado** um campo em arestas, mas não explica a existência microscópica das fases de aresta ou do Hamiltoniano. Em Levin–Wen (2006), graus de rotor bosônicos e o vínculo de carga \(Q_I=0\) produzem, em uma fase coletiva, um setor gauge U(1). O mapa de Hilbert/operadores e a dinâmica de baixos níveis correspondentes **ainda não foram derivados para os graus e pesos HRF**. Ver §2.8.4.

### 2.3.3 Controles negativos: o que não funciona

| Acoplamento | Resultado |
|---|---|
| laplaciano vetorial (κ/2)Σ\|q_{n+e} − q_n\|² | 3 modos propagantes: longitudinal físico |
| pares sem laço (isotrópico, perpendicular, central) | 3 modos propagantes |
| laços com orientação embaralhada | sem convergência, sem gauge, contagem errada |
| **laços orientados (rotacional)** | **2 transversais + 1 modo de frequência zero (gauge)** |

O setor fotônico restringe não só escalas, mas a **forma** do acoplamento: precisa ser rotacional.

### 2.3.4 Pesos geométricos

Dois conjuntos de pesos foram usados:
- **Whitney (W)**, padrão da B1 e da B8: dá c = 1 sem nenhum ajuste;
- **duais baricêntricos (D)**, usados na HOL1, B10 e B11-luz-luz: a velocidade absoluta sai 12–21% acima de c, com
  fator que varia conforme a família de malha (B12-faixa). Isso não aparecia antes porque a HOL1 normalizava o espectro D
  pela média. Os pesos D exigem uma normalização ainda não derivada; as razões usadas na B11-luz-luz não dependem disso.

> **Analogia.** A pressão arterial é medida em relação à atmosfera: somar a mesma constante em todo lugar não muda nada.
> O gauge é isso. Só as diferenças em volta de um laço contam.

---

## 2.4 A forma da onda: o pequeno saca-rolha e a propagação reta

**Imagem consolidada:**

\[
\boxed{\text{pequeno saca-rolha (polarização)}+\text{propagação média reta}}
\]

- A **hélice pequena** é a rotação da fase das ligações ao longo da propagação. É a polarização circular, ou seja, a
  helicidade. Não é a trajetória de nenhum GMF e não é o estado local q_n.
- A **propagação média é reta**: o microscópico é tortuoso (a malha é irregular; o erro ponto a ponto fica em ~0,68),
  mas o coletivo converge na forma fraca com ordem 2.
- A **hélice grande** (o centro do feixe andando em espiral) não ocorre num meio homogêneo. Aparece só em fundos
  girantes ou guias.

**Spin × OAM.** Para um fóton estruturado, L_z = ℓħ (orbital, qualquer inteiro) e S_z = sħ (spin, só ±1), com
J_z = (ℓ + s)ħ. **Hélice de fase não é spin.**

**Teste leve [F/M].** O modo circular é autovetor do rotacional: ∇×q_s = −sk q_s e ∇×∇×q_s = k² q_s. O primeiro
rotacional distingue a mão; o segundo é igual para as duas. Por isso a equação de onda tem ω = c|k| para as duas
helicidades. Numericamente, a convergência é de 2ª ordem e idêntica para s = ±1.

**O saca-rolha numa malha irregular não é um modo único [M] (B41, novo na v1.3).** Numa caixa periódica, a 1ª camada
de modos tem 12 soluções com a mesma frequência no contínuo (6 vetores k × 2 polarizações). A malha irregular abre essa
degenerescência e mistura direções e polarizações nos autovetores. Lançado ao longo de z, o saca-rolha (s = +1) se
espalha pelos autovetores da camada:

| Malha (pesos D) | GMFs | autovetores com > 2% da energia | fração da energia | espalhamento de ω na camada | sobreposição com a onda plana |
|---|---|---|---|---|---|
| Poisson 8³ | 512 | 9 | 98% | 7,5% | 0,94 |
| Poisson 10³ | 1 000 | 6 | 96% | 4,9% | 0,94 |

O espalhamento diminui com o refinamento (no diagnóstico da fumaça, em Poisson 6³ e 5³, era de 10,8% e 13,5%). No
regime linear, isso não aparece: a onda anda com ω ≈ ck e helicidade bem definida, e o desdobramento entre polarizações
cai com o refinamento (§2.6.3). No regime não linear, aparece: os modos se defasam, cada um muda de frequência à sua
maneira, e a previsão de modo único deixa de valer (§2.7.3).

**Convenção.** O rótulo histórico s não é a helicidade sem dizer a direção de k: para θ = kz − ωt, s = +1 pode ser
helicidade negativa em +z.

**Cor e energia.** Cor ↔ ω, λ = 2π/k; E = ħω e p = ħk, com ħ como entrada.

> **Caixa — luz em meios e guias (não é vácuo, mas ajuda a entender).**
> - Num meio com índice n(x), o operador vira ∇×(1/n)∇×, com gauge exato (HOL1, erro 0,018). A geometria muda
>   coeficientes, não a estrutura de gauge.
> - Num fundo girante com ℓ = 0, as helicidades se separam: Δω = −hJ (~3%), com sinal vindo do giro do espaço, não da mão
>   da malha (HOL1). Na bancada do curl-curl emergente, com Ω = 0,05: ω₊ − ω₋ = −0,0986 contra −2Ω = −0,100.
> - Retroação fraca da onda sobre a microgeometria é pequena (‖δg‖/‖g⁽⁰⁾‖ ≈ 0,004) e troca de sinal com h; retroação
>   forte destrói a propagação (G0G).
> - A separação de helicidades vista na G0G e no critério P4 da B1 é efeito de **modo preso no guia**, não do vácuo
>   (B3, §2.7.3).

### 2.4.1 Nota de atualização (09/10/2026): modelos 2D3V utilizados nas bancadas atuais [D/M/?]

**[D] Modelo operacional vigente nas bancadas de onda livre e confinamento do HRF-FM.** As investigações recentes adotam a **redução 2D3V**: dependência espacial em somente duas coordenadas, \(x,y\), com \(\partial_z=0\), mas mantendo **três componentes vetoriais** dos campos ou da conexão. Para \(\mathbf{k}=(k_x,k_y,0)\), os dois setores transversais correspondem à direção no plano perpendicular a \(\mathbf{k}\) e à direção \(z\), permitindo suas combinações circulares, de sinais de helicidade \(h=\pm1\) conforme a convenção de \(\mathbf{k}\), fase e tempo. A hélice descreve **polarização**; não constitui trajetória helicoidal do pacote.

A redução não é uma simulação espacial tridimensional completa: ela cobre vetores de onda no plano, não modos com dependência em \(z\). Também não constitui, isoladamente, quantização de um fóton ou validação de sua identidade física. O setor 2D3V é empregado como **bancada intermediária controlada** entre a física estabelecida e a estrutura relacional histórica deste capítulo, em conformidade com a estratégia de reconstrução unificadora progressiva (Capítulo 0.1, B → A).

**Há duas discretizações distintas, que não devem ser confundidas:**

| Implementação atual | Graus de liberdade e malha | Resultado documentado até 09/10/2026 | Função no programa |
|---|---|---|---|
| **2D3V Yee** | Malha cartesiana uniforme escalonada; campos clássicos \(\mathbf{E},\mathbf{B},\mathbf{D},\mathbf{H}\) com três componentes, \(\partial_z=0\). | **`2D3V-MAXWELL-GATE = PASS` [M]** na propagação livre (34 casos, duas helicidades). **`PHOTON-INJECTION GATE HRF-CAP2 = NOT_TESTED` [?]**. O gate espacial da cavidade falhou; testes vetoriais longos não executados. | **Controle eletromagnético de referência**, ainda não identificado com a microdinâmica U(1) deste capítulo. |
| **2D3V Voronoi–Delaunay/Whitney** | Triangulação Delaunay irregular, laços orientados e massas Whitney; \(a_\parallel\) como 1-forma nas arestas e \(a_z\) como componente vertical de uma conexão 3D reduzida, numericamente armazenada nos vértices. | Identidades de incidência/gauge, dois setores e energia quadrática verificados [M]. **`GATE_DELAUNAY_FREE = FAIL` [M]** devido aos controles temporal e de borda. Equivalências Maxwell ↔ Delaunay e HRF-CAP2 **PENDING [?]**; cavidade **NOT_EXECUTED [D]**. | **Candidata relacional mais diretamente ligada ao Capítulo 2**, ainda sob validação numérica. |

No **controle Yee** aplica-se Maxwell sem fontes, inclusive as restrições de Gauss, com fluxo \(\mathbf{J}_E=\mathbf{E}\times\mathbf{H}\). O PASS obtido verifica a formulação clássica discreta dentro das resoluções e janelas estudadas; **não transfere automaticamente** um PASS ao modelo U(1)/Wilson.

Na **redução Delaunay/Whitney**, mantém-se o setor de conexão do capítulo, \(U_{nm}=e^{ia_{nm}}\), os laços \(C=d_1a\) e a identidade \(d_1d_0=0\). Em campo fraco, uma escrita de referência é

\[
M_1\ddot a_\parallel=-d_1^{\mathsf T}M_2d_1a_\parallel,\qquad
M_0\ddot a_z=-d_0^{\mathsf T}M_1d_0a_z,
\]

**desde que** massas e operadores sejam obtidos consistentemente da redução tridimensional Whitney. O \(a_z\) nodal é um *componente de conexão reduzida*, não um novo estado material fundamental de cada nó. A bancada registrada estudou o regime **quadrático e não a teoria compacta completa de Wilson**. A derivação/equivalência entre formulações e seus observáveis permanece uma interface a demonstrar [?].

**Distinção de proveniência [D].** As malhas Delaunay **tridimensionais**, inclusive tetraedros e seus resultados históricos, descritas nas seções 2.2–2.3, continuam sendo as fontes originais do fechamento fotônico efetivo deste capítulo. A bancada **triangular 2D3V**, formulada posteriormente, é uma *nova redução para testes de propagação e confinamento*; não reinterpreta nem substitui retroativamente as bancadas históricas.

**Critério para os próximos passos [?].** É necessário, separadamente: (i) corrigir e aprovar a validação livre Delaunay; (ii) mapear operadores, graus físicos, gauge, helicidade, energia e estados entre a redução e o Capítulo 2; (iii) resolver a convergência espacial da cavidade, especialmente onde o comprimento de onda local fica sub-resolvido; e só então (iv) estudar retenção e transporte interno por tempos longos. **Confinamento clássico não equivale à identificação de um fóton individual nem à formação de elétron.**

**Documentos de referência dessa atualização [D]:**

- `HRF_Modelo_Foton_Livre_2D3V_Yee_v0_1_PT_2026-10-09.md` — definição e validação livre da bancada Yee.
- `HRF_Modelo_Foton_Livre_2D3V_Delaunay_Whitney_v0_1_PT_2026-10-09.md` — construção relacional e resultados negativos da bancada Delaunay.
- `HRF_CAP3_2D3V_Regras_Modo_Fotonico_Cap02_v0_1_PT_2026-10-08.md` — regras do contrato fotônico para as reduções.
- `HRF_CAP3_DELAUNAY_RELATORIOS_CODIGO.zip` e `HRF_CAP3_2D3V_RELATORIOS_CODIGO_TABELAS_2026-10-08.zip` — pacotes de implementação, pré-registros e relatórios.
- `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_1_PT_2026-10-08.md` — estratégia documental B → A.

---

## 2.5 O fechamento do fóton efetivo (B1)

### 2.5.1 Histórico de método

> **Histórico.** A primeira rodada do PHOTON-CLOSURE declarou PASS, mas trocou critérios depois de ver os resultados.
> A replicação com critérios congelados (1º out) passou em todos os 12 critérios na R1 e falhou num deles na R2 (pureza
> de helicidade 0,981 em 10³, abaixo de 0,99). Daí veio o **princípio editorial 20**: critérios de PASS/FAIL de bancadas
> decisivas são pré-registrados com hash antes de rodar; trocas posteriores são só exploratórias.

### 2.5.2 A bancada B1 [M]

Dez sementes (20261201–20261210), critérios congelados (pré-registro de 1º out, 23h50).

| Critério | Resultado | Números |
|---|---|---|
| P1 itens internos, ≥ 9/10 sementes | passa | 9/10 |
| P2a ordem do resíduo de helicidade | passa | mediana 0,98 [0,98; 1,01] |
| P2b impureza de helicidade | passa | 3,8×10⁻³ → 4,3×10⁻⁴ → 1,1×10⁻⁴ (10³, 14³, 18³) |
| P2c deriva dinâmica em 18³ | passa | 10/10 < 0,005 |
| P3 ordem de (E² − P²c²)/E² | passa | 1,98 [1,96; 2,00] |
| P4 Δ_hel no fundo compensado | passa* | supressão 8–40× contra o controle |
| P5 Lorentz quadrático no UV | passa | 10/10 com termo linear desprezível |

\*Correção posterior (B3): o P4 mede um modo preso no guia, não o vácuo.

Também: ω/ck = 0,993 (10³) → 0,998 (20³), com desvio proporcional a (ka)², que é a dispersão de rede (§2.7.1).

\[
\boxed{\text{PHOTON-CLOSURE-E: FECHADO (toy model) [M]}}
\]

**Desvio declarado:** seis rodadas morreram por falta de memória e foram refeitas uma de cada vez, com o mesmo código e
sementes. **Auditoria independente:** hashes conferidos, avaliador reexecutado com resultado idêntico, controle de
determinismo idêntico.

### 2.5.3 Replicação na B41 e nova leitura do critério P1 [M] *(novo na v1.3)*

A B41 (§2.13) repetiu a B1 com dez sementes novas (41020001–41020010, seis delas com malha-guia), o mesmo código e o
avaliador original (`avaliar_B1.py`), trocando só a lista de sementes. Antes disso, a âncora M00 rodou a semente
original 20261204 e reproduziu a B1a bit a bit. Logo, qualquer diferença vem das sementes, não do código nem da máquina.

| Critério | B1 (1–2 out) | B41 (28 out) |
|---|---|---|
| P1 itens internos, ≥ 9/10 sementes | passa, 9/10 | **falha, 8/10** |
| P2a ordem do resíduo de helicidade | 0,98 [0,98; 1,01] | 0,977 [0,970; 0,991] — passa |
| P2b impureza de helicidade (10³, 14³, 18³) | 3,8×10⁻³ → 4,3×10⁻⁴ → 1,1×10⁻⁴ | 1,5×10⁻³ → 2,2×10⁻⁴ → 1,45×10⁻⁴ — passa |
| P2c deriva dinâmica em 18³ < 0,005 | 10/10 | 9/10 — passa (o critério tolera uma) |
| P3 ordem de (E² − P²c²)/E², h = +1 | 1,98 [1,96; 2,00] | 1,966 [1,945; 1,974] — passa |
| P3, polarização linear | 1,93 | 1,918 [1,892; 1,938] — passa |
| P4 Δ_hel no fundo compensado | passa*, supressão 8–40× | falha num ponto; supressão 35,8× |
| P5 Lorentz quadrático no UV | 10/10 | 10/10 — passa |
| ω/ck (m = 1), 10³ → 20³ | 0,993 → 0,998 | 0,9938 → 0,9984 (medianas) |
| bandas numéricas da B1 | — | 9/9 dentro |

**Por que P1 falhou.** Cada uma das duas sementes reprovadas teve **um único item** ruim:
- **41020004:** item 9, “retroação fraca não destrói”, na malha-guia h = 0,46: η_g = 0,0116 para h = −1, contra o
  limite de 0,01 (h = +1: 0,0088). *(Correção da v1.5: a v1.3 dizia que a malha não era conhecida.)* A B41H mostrou que
  essa falha marginal não depende da preparação do estado (§2.14).
- **41020005:** item 7, “compensado não seleciona helicidade”. Na malha-guia mais grossa (h = 0,55; 830 GMFs), tanto o
  fundo compensado quanto o controle N4 deram Δ_hel = 1,99, o máximo possível: o estado de helicidade não foi preparado
  nessa malha. Nas malhas-guia mais finas, a mesma semente dá 1,6×10⁻⁴ e 7×10⁻⁵, contra ~6,7×10⁻³ do controle. Esse
  mesmo ponto faz P4 falhar. Pela tabela original da B1, P4 sozinho levaria a “FECHADO COM RESSALVA”, mas P1 decide antes.

**A preparação do estado de helicidade é o ponto frágil [M].** Fora de P1, nas mesmas duas sementes, a malha de
conservação de 14³ preparou mal o estado: impureza de 0,40 (41020005) e 0,021 (41020004), contra ~10⁻⁴ nas outras. A
semente 41020003 teve impureza de 0,023 na malha de 18³. As medianas de P2 passam porque são medianas. Na B1 original já
havia sinal parecido: duas sementes com fração inicial de 0,49 e 0,92 em 10³, e a única falha de P1 foi de conservação de
P_z em 10³.

**Causa identificada (B41H, v1.5) [M].** O saca-rolha é lançado copiando a onda do contínuo para as ligações (mapa de
de Rham). Numa malha de Whitney, essa cópia não obedece exatamente à lei de Gauss discreta (d0ᵀ M1 v₀ ≠ 0). A carga
espúria deixa no momento uma parte longitudinal parada, π_L = M1 d0 λ, e a medida da B1, com peso M1², mistura essa
parte com a onda. A fração oscila então com a frequência da própria onda, e pode sair errada já em t = 0. A B41H
(§2.14) repetiu os casos que falharam, com o mesmo código e as mesmas malhas:
- as frações 0,4893 e 0,9249 das sementes 20261201 e 20261202 da B1 reapareceram;
- lançar limpo (v₀ → v₀ − d0 λ) resolveu cinco das seis falhas de conservação e a do guia (Δ_hel 1,99 → 9×10⁻⁶);
- em 140 malhas novas, as falhas foram de 10 para 0.

A falha do item 9 (41020004) é de outra natureza: não muda com a limpeza.

**Quanto vale P1 [M].** Somando as duas rodadas, 3 de 20 sementes tiveram falha isolada num único item. Supondo sementes
independentes com a mesma taxa f de falha pontual, a chance de P1 (pelo menos 9 de 10) passar é
(1 − f)¹⁰ + 10 f (1 − f)⁹:

| taxa de falha por semente f | 10% | 15% (= 3/20) | 20% |
|---|---|---|---|
| chance de P1 passar | 74% | 54% | 38% |

A taxa é mal determinada: 3 em 20 dá intervalo de 95% de 3% a 38% (Clopper–Pearson), e a chance de P1 passar fica
entre ~96% e ~6%. Com dez sementes, **P1 não separa bem um fechamento robusto de um frágil**. O “FECHADO” da B1 e o “NÃO
FECHADO” da B41 são compatíveis com dois sorteios do mesmo critério.

**Nova leitura da B1 [M].**
- **Fechamento físico reproduzido:** todas as grandezas que o fechamento mede (P2, P3, P5, ω/ck e a supressão de P4)
  voltaram com sementes novas, e as 9 bandas numéricas da B1 ficaram dentro.
- **Critério de robustez por semente frágil:** 9/10 na B1, 8/10 na B41, sempre com a falha de um único item por semente,
  ligada sobretudo à preparação do estado de helicidade em malhas grossas. *(v1.5: a causa dessa preparação ruim é a
  carga espúria do lançamento, §2.14.)*
- Nenhum critério de reabertura de §2.12 é atingido: nenhuma grandeza física saiu da banda.

\[
\boxed{\text{PHOTON-CLOSURE-E após a B41: grandezas reproduzidas; critério P1 frágil (9/10 na B1, 8/10 na B41) [M]}}
\]

**Para pré-registros futuros [?].** Fica em aberto como escrever um critério de robustez que não dependa do sorteio de
uma semente. Duas opções, não decididas: (a) estimar a taxa de falha pontual com mais sementes e exigir que o limite
superior do seu intervalo fique abaixo de um valor fixado antes; (b) decidir pelas medianas e intervalos (P2–P5) e
relatar as falhas pontuais à parte, com a malha em que ocorreram. *(v1.5:)* (c) lançar o estado limpo, que na B41H
removeu a fonte das falhas pontuais de preparação (§2.14). Recalcular P1 com o lançamento limpo exigiria uma rodada
nova pré-registrada.

> **Analogia.** É como repetir um exame com outro aparelho e outra amostra. Os valores do laboratório batem até a
> terceira casa. O que muda é um laudo que exigia que, de dez amostras, no máximo uma tivesse uma alteração isolada.
> Com uma taxa de alteração isolada perto de 15%, esse laudo sai normal só em metade das vezes. A fragilidade está na
> regra do laudo e na coleta (a preparação do estado), não no que o exame mede.

---

## 2.6 O substrato: malhas irregulares, faixa de distâncias e deformação

### 2.6.1 Espaço-tempo plano e conectividade (D1)

No setor fotônico do **HRF-FM**, o espaço-tempo é tratado como plano (g_μν = η_μν, decisão histórica D1). A organização que o substrato dá ao fóton
(vizinhança, orientação dos laços) é **relacional**, não curvatura. “Microgeometria”, aqui, é um rótulo histórico da C5A e quer dizer **conectividade/deformação da malha**. Não deve ser confundida com a reconstrução de distância, métrica ou espaço-tempo do **HRF-ST**.

### 2.6.2 Escalas: o que é “a distância entre GMFs”

\[
r_{\rm GMF}\ (\text{tamanho interno, se existir})\ \neq\ a_\rho=(V/N)^{1/3}\ (\text{escala de densidade})\ \neq\ r_{nm}\
(\text{distância local})\ \neq\ \Delta x_{\rm num}\ (\text{passo numérico})
\]

As distâncias locais r_nm formam uma distribuição P(r), com uma cauda superior r_tail. O passo numérico não tem
significado físico.

### 2.6.3 Faixa fixa no tempo (D3; B12-faixa) [M]

**Decisão D3 [D]:** a distância entre GMFs vizinhos varia numa faixa, com mínimo e máximo, como as moléculas do ar para o
som. Por enquanto, a faixa é fixa no tempo (vidro, não gás).

A B12-faixa comparou cinco famílias com a mesma densidade média: Poisson (sem mínimo), núcleo duro com mínimo 0,4a, 0,6a
e 0,8a, e a malha “tremor” das bancadas anteriores (45 malhas, critérios pré-registrados).

| Malha (20³) | faixa ℓ/a_ρ | ξ médio | a_ρ,max (m) | desdobramento de polarização (menor k) |
|---|---|---|---|---|
| Poisson | 0,03 – 2,92 | 0,0112 | 1,9×10⁻²⁷ | 2,6×10⁻⁴ |
| mínimo 0,4a | 0,40 – 2,84 | 0,0103 | 2,0×10⁻²⁷ | 1,7×10⁻⁴ |
| mínimo 0,6a | 0,60 – 2,55 | 0,0088 | 2,2×10⁻²⁷ | 1,5×10⁻⁴ |
| mínimo 0,8a | 0,80 – 2,09 | 0,0056 | 2,7×10⁻²⁷ | 1,1×10⁻⁴ |
| tremor | 0,32 – 2,18 | 0,0064 | 2,5×10⁻²⁷ | **1,9×10⁻³** |

- **Velocidade e isotropia não dependem da faixa:** c = 1 a 7×10⁻⁶ e isotropia a 8×10⁻⁶ em todas.
- **A forma da autointeração não depende:** κ∥/κ⊥ = 3 em todas as 45 malhas (§2.7.4).
- **O desdobramento entre as duas polarizações depende da família:** a tremor tem ~10× mais que as malhas sem grade.
  Cai com o refinamento em todas (Poisson: 2,0×10⁻³ → 5,9×10⁻⁴ → 2,6×10⁻⁴, de 10³ a 20³).
- **O teto muda pouco** (no máximo 1,4×) e melhora quando a faixa estreita.
- **O mínimo da faixa não é limitado** por nada testado.

**B41 (M08) [M]:** cinco famílias × lados 10, 14 e 20 × 3 realizações, medidas pelo mesmo `b8_isotropia.medir`. ξ em 20³:
0,0110; 0,0105; 0,0086; 0,0059; 0,0064 (Poisson … tremor). O c₀ dos pesos D repete a B12-faixa até a 3ª casa (1,198;
1,185; 1,159; 1,118; 1,143). Desdobramento tremor ÷ Poisson: 8,4; variação do teto entre famílias: 1,37×. Decisão
reproduzida (12/12 bandas).

### 2.6.4 Faixa deformável no tempo (fluxo par: B11-Morse, B12-Morse) [M]

O fluxo par testou a versão em que as distâncias oscilam no tempo, com um potencial de Morse entre GMFs:

\[
U(r)=D\,[1-e^{-\alpha(r-a_0)}]^2,\qquad
\frac{r_{\min}}{a_0}=1-\frac{\ln(1+\sqrt u)}{\lambda},\quad
\frac{r_{\max}}{a_0}=1-\frac{\ln(1-\sqrt u)}{\lambda},
\]

com λ = αa₀ e u a fração da energia de dissociação em cada ligação. O Morse dá naturalmente r_min e r_max como
**pontos de retorno** de cada ligação para a sua energia; não são constantes universais.

- **B11-Morse:** com 20% de deformação, as distâncias exploraram ~0,71 a ~1,28 r₀, e a conectividade de Delaunay foi
  reconstruída no tempo (Jaccard mínimo ≈ 0,925). Gauge preservado (10⁻¹⁶), N + 2 modos nulos, nenhum ω² < 0.
- **B12-Morse** (4³ → 6³ → 8³, uma realização por resolução):

| | 4³ | 6³ | 8³ |
|---|---|---|---|
| ω/ck, equilíbrio | 0,9465 | 0,9786 | 0,9862 |
| desdobramento, equilíbrio | 1,04×10⁻² | 5,56×10⁻³ | 3,24×10⁻⁴ |
| ω/ck, 20% de deformação | 0,9482 | 0,9770 | 0,9854 |
| desdobramento, 20% de deformação | 1,77×10⁻² | 1,04×10⁻² | 2,01×10⁻³ |

**Leitura.** O déficit de ω/ck é a dispersão quadrática de rede já conhecida: supondo k = 2π/L, o déficit dividido por
(ka)² dá ξ ≈ 0,02 nas três resoluções, perto do valor da B8. O desdobramento cai com o refinamento mesmo sob deformação,
mas de forma irregular; com uma realização por resolução, o salto em 8³ pode ser acaso. Falta repetir com várias
realizações e pré-registro.

**B41 (M10) [M]:** a repetição pré-registrada pedida acima, com n = 4, 6 e 8, três realizações cada, λ = 4, u = 0,2 e
20 períodos. ξ_eff = 0,016 no equilíbrio e 0,015 sob deformação, mais perto da B8 que a estimativa ≈ 0,02. O
desdobramento sob deformação cai de 1,30×10⁻² para 1,63×10⁻³ (grosso → fino). Decisão reproduzida (4/4 bandas), o que
exige, em todos os casos, gauge < 10⁻¹⁰ em toda foto da malha, N + 2 modos nulos, nenhum ω² negativo, ω/ck deformado a
menos de 2% do equilíbrio em 8³ e conectividade que de fato mudou (Jaccard < 1).
**Mas o regime não foi o mesmo:** as distâncias foram de 0,70 a 2,39 r₀ e o Jaccard mínimo foi 0,80, porque a injeção
de energia por velocidades aleatórias leva algumas ligações de Morse além da dissociação. O fóton sobreviveu num regime
mais forte que o original; a repetição no regime original (~0,71–1,28 r₀) continua pendente (§2.11).

### 2.6.5 Qual parte da faixa controla o UV (B12-faixa, B14) [M]

Na B12-faixa, no mesmo tamanho de malha, ξ acompanha a cauda superior da faixa: ξ/(ℓ_max/a_ρ)² varia ±3% entre as
famílias e ξ/(p99/a_ρ)², cerca de ±11%. Mas ℓ_max é o maior valor de uma amostra e cresce com o tamanho da malha.

A **B14** (fluxo par) testou a causalidade: uma família RARA, com um único defeito local que aumenta ℓ_max em 24%, contra
a malha-base e uma família DIFUSA (modulação senoidal em z), com p1, média, RMS e p99 iguais a < 0,3%.

- **RARA contra a base:** ξ muda só **+0,2%** em 20³. Um único extremo não controla ξ. **ℓ_max isolado está descartado
  como variável.**
- A razão de 1,04 do relatório original (RARA/DIFUSA) vem da DIFUSA, que baixa ξ em 3,6% e varia de forma errática com a
  resolução (+6,6%, −0,8%, −3,6%). A DIFUSA não é um controle neutro.
- **Modelos treinados na B12 e testados na B14:**

| Modelo | erro no treino (B12) | erro no teste (B14) |
|---|---|---|
| ξ = C·ℓ_max² | 3,6% | 22% |
| ξ = C·p99² | 8% | 13% |
| ξ = C·⟨ℓ⁴⟩^½ | 18% | 5% |
| ξ = C·⟨ℓ²⟩ | 22% | 10% |

  Nenhum dos quatro passa nos dois testes. O ⟨ℓ⁴⟩ só acerta a B14 porque as três famílias dela têm quase o mesmo valor e a
  calibração cai por acaso nesse ponto. O p99 é o candidato menos ruim. É possível que ξ dependa de algo que não é um
  momento das distâncias (forma dos tetraedros, correlações espaciais, memória de grade).
- **Auditoria:** reproduzi a malha-base da B14 com código independente; ξ, c0, ℓ_max e p99 saíram idênticos. O código
  das famílias deformadas não veio no pacote.

**B41 (M09) [M]:** tremor 14³ e 20³, três realizações; |ξ(defeito)/ξ(base) − 1| = 0,32% em 20³ (B14: +0,2%). O gerador
do defeito foi reimplementado, porque o original não veio no pacote. Decisão reproduzida (2/2 bandas).

**Um ponto de fundo:** um defeito único ocupa ~0,3% do volume em 20³, e ξ é uma média de volume. O teste confirma o
esperado; o resultado útil é metodológico: **a variável a reconstruir é a distribuição P(r) e suas correlações, não uma
distância máxima.**

---

## 2.7 Frente às observações

Cada propriedade que poderia denunciar a rede, o dado que a limita e a folga.

| Teste | Observação usada | Resultado | Bancada |
|---|---|---|---|
| Lorentz no UV | LHAASO, GRB 221009A: E_QG,2 > 6,9×10¹¹ GeV | √ξ·a_ρ ≲ 2,0×10⁻²⁸ m | B8, consolidação |
| isotropia no IR | — | anisotropia de c cai a 1,4×10⁻⁶ (26³) | B8, B12-faixa |
| birrefringência acumulada, canal circular | polarização do GRB 140206A (z = 2,739) | média zero; giro ~10⁻¹² rad (permitido π/2) | B3 |
| autointeração / luz-luz | PVLAS; QED (Euler–Heisenberg) | 3×10⁻⁵⁵ da QED | B11-luz-luz |

Os quatro resultados se repetiram na B41 com sementes novas (§2.13).

### 2.7.1 Lorentz no UV e o teto unificado (B8) [M]

A dispersão medida na malha é

\[
\frac{\omega}{ck}=1-\xi\,(k a_\rho)^2+\dots,\qquad \frac{v_g}{c}=1-3\xi\,(k a_\rho)^2+\dots
\]

Na convenção quadrática do LHAASO, v = c[1 − (3/2)(E/E_QG,2)²]. Com E = ħck:

\[
\boxed{\ a_{\rho,\max}=\frac{\hbar c}{E_{\rm QG,2}\sqrt{2\xi}}\quad\Longleftrightarrow\quad \sqrt{\xi}\,a_\rho\lesssim 2{,}0\times10^{-28}\ \text{m}\ }
\]

com E_QG,2 > 6,9×10¹¹ GeV (Cao et al. 2024, PRL 133, 071501). Esta é a **forma canônica**, adotada pelos dois fluxos.

| Caso | ξ | a_ρ,max |
|---|---|---|
| cadeia uniforme | 1/24 | 9,9×10⁻²⁸ m |
| tremor, eixo (B8, 20³, 10 sementes) | 0,0163 [0,0161; 0,0164] | 1,6×10⁻²⁷ m ≈ 10⁸ ℓ_P |
| tremor, eixo (B41, 20³, 10 realizações novas) | 0,0162 [0,0159; 0,0166] | 1,59×10⁻²⁷ m |
| Poisson … mínimo 0,8a (B12-faixa, 20³) | 0,0112 … 0,0056 | 1,9 … 2,7×10⁻²⁷ m |
| INVERSE-01 antigo | — | 7,6×10⁻²⁸ m (**aposentado**: convenção sem o fator 3/2) |

**Como ler.** O observável limita a **combinação** √ξ·a_ρ, não cada distância r_nm. O ξ depende da estatística da
rede (§2.6.5). O valor 1,6×10⁻²⁷ m é um teto conservador da família tremor, não a “distância máxima universal entre
GMFs”. GMFs de escala de Planck não são pressionados.

**Isotropia.** A velocidade no IR é isotrópica: a anisotropia entre 13 direções cai de 3,4×10⁻⁴ (10³) para 1,4×10⁻⁶
(26³). O UV, porém, depende da direção na malha tremor (eixos ≈ 0,017, diagonais de face ≈ 0,005, diagonais de cubo
≈ 0,001): a malha guarda memória da grade que a gera. As malhas sem grade (Poisson, núcleo duro) não têm esse problema.

**B41 (M03) [M]:** lados 10, 14, 20 e 26 × 10 realizações, 13 direções, avaliador original da B8. Teto canônico
√ξ·a_max = 2,02×10⁻²⁸ m; anisotropia de c_eff em 26³ de 1,36×10⁻⁶ (inclinação −5,78); ξ nos eixos, diagonais de face e
de cubo 0,0165 / 0,0048 / 0,0009. Controles: a rede cúbica dá ξ(k̂) = Σk̂⁴/24 com erro de 1,2×10⁻⁵; a rede N6 com pesos
U acusa anisotropia (0,050), e com pesos W não (8×10⁻⁵). Decisão reproduzida (8/8 bandas).

**Referencial preferido [F].** Uma malha define um referencial preferido. O teto acima é o que o torna inobservável com
os dados atuais.

### 2.7.2 Birrefringência acumulada (B3) [M]

Uma luz que atravessa bilhões de anos-luz acumularia qualquer rotação sistemática do plano de polarização.

| Fonte | média zero | δ ∝ (ka)^p | Δθ ∝ L^r |
|---|---|---|---|
| malha tremor | sim | p = 4,6 | r = 0,68 |
| malha Poisson | sim | p = 3,5 | r = 0,59 |
| quiralidade compensada, tremor | sim | p = 1,8 | r = 0,41 |
| quiralidade compensada, Poisson | sim | p = 2,8 | r = 0,75 |

- Controles: atividade óptica uniforme reproduzida (δ/ξk = 0,993 em 26³, Drude–Born–Fedorov [F]); quiralidade única ~10⁴
  vezes a compensada.
- Limite: polarização do GRB 140206A em 200–400 keV, z = 2,739 (Götz et al. 2014, MNRAS 444, 2776). O teto mais
  restritivo da B3 (5,8×10⁻²³ m) é muito mais frouxo que o da B8. Abaixo do teto da B8, o giro previsto é ~10⁻¹² rad.
- Argumento robusto [F]: a média de uma densidade aleatória de sinal ± num volume V cai como (s³/V)^½ (limite central).
- **Ressalva:** a B3 mediu o **canal circular** (rotação do plano). O canal linear pode ser maior nos dados brutos e o
  desdobramento depende da família de malha (§2.6.3). O transporte completo de polarização (Stokes/Jones) está em aberto.

**B41 (M04) [M]:** lados 10–26, Lz até 32, 10 realizações, avaliador original da B3. Calibração δ/(ξk) = 0,9932 em 26³;
quiralidade única 1,6×10⁴ vezes a compensação exata. Decisão COMPATÍVEL reproduzida (4/4 bandas). O teto mais
restritivo saiu 4,6×10⁻¹⁹ m, contra 5,8×10⁻²³ m na B3. Os dois ficam muito acima do teto da B8, e a banda pré-registrada
(≥ 10× o teto da B8) passa. Mas o valor variou quatro ordens de grandeza entre as rodadas: o “teto mais restritivo da
B3” não é um número estável e não deve ser citado como tal.

**Correção registrada:** microvórtices de arrasto **não** são um modelo de quiralidade do vácuo. Um vórtice localizado tem
vorticidade total nula, e rotação é pseudovetor, não pseudoescalar; o efeito de primeira ordem sobre uma onda extensa
some. O modelo adequado é uma densidade pseudoescalar compensada (“fitas de ambas as mãos”).

### 2.7.3 Autointeração e espalhamento luz-luz (B11-luz-luz) [M]

Se a conexão é compacta, o termo −C⁴/24 da energia de Wilson é uma autointeração do fóton que só existe por causa da
rede. Num campo magnético forte B₀, ela produz birrefringência magnética do vácuo:

\[
|\Delta n_{\rm rede}|=\frac{e^2a^4B_0^2}{4\hbar^2}\,\Delta\kappa,\qquad \kappa=\frac{\text{termo quártico}}{\text{termo quadrático}} .
\]

| Grandeza | Valor |
|---|---|
| Δκ (Poisson 20³) | 0,319 ± 0,004 |
| \|Δn_rede\|/Δn_QED no teto da B8 | **3×10⁻⁵⁵** |
| a em que a rede igualaria a QED | 6,8×10⁻¹⁴ m ≈ 0,18 ƛ_C |
| a máximo pela PVLAS (2σ), se a conexão for compacta | 1,2×10⁻¹³ m |

- Validação dinâmica: uma onda plana com a energia completa muda de frequência como um pêndulo, com erro de 3–6% contra a
  previsão Δω/ω = −(1/16)⟨|C|⁴⟩/⟨|C|²⟩.
- **Forma universal [M]+[F]:** κ∥/κ⊥ = 3 em todas as malhas. É forçado pela isotropia: um tensor de 4ª ordem totalmente
  simétrico e isotrópico só pode dar (B²)².
- **Assinatura oposta à da QED [M]:** na QED, n(E∥B₀) > n(E⊥B₀), na razão 7:4. Na rede de Wilson hamiltoniana, que só
  tem quártico magnético, n(E⊥B₀) > n(E∥B₀), na razão 3:1.
- Automodulação de uma onda única (ausente na QED): Δω/ω ~ 10⁻⁶⁵ no laser mais intenso já feito. Luz-luz no LHC:
  correção < 10⁻⁴⁰ da QED. Inobserváveis.
- Fontes: PVLAS, Δn = (12 ± 17)×10⁻²³ a 2,5 T (Ejlli et al. 2020, Phys. Rep. 871, 1); QED 3A_e ≈ 4,0×10⁻²⁴ T⁻²
  (CODATA 2018).

**B41, parte estática (M07) [M]:** Poisson e tremor 10, 14 e 20, três realizações. Δκ (Poisson 20³) = 0,3213;
κ∥/κ⊥ = 2,984–3,003; |Δn_rede|/Δn_QED no teto da B8 = 2,98×10⁻⁵⁵; a em que a rede igualaria a QED = 6,80×10⁻¹⁴ m;
a máximo pela PVLAS = 1,17×10⁻¹³ m. Controle cúbico de κ: 0,6017 e 0,1974 (esperado 3/5 e 1/5). É a parte que decide a
física, e ela reproduziu.

**B41, validação dinâmica (M07 e correção declarada M07c) [M] (novo na v1.3).** A reimplementação lançou o saca-rolha
(s = +1) em malhas Poisson 8³ e 10³ (pesos D, como na B11-luz-luz), com três amplitudes, e comparou o desvio de
frequência com a previsão coerente de modo único acima. A razão medido/previsto saiu ~1,49, igual nas três amplitudes.
A causa, achada na fumaça: o saca-rolha não é um modo único (§2.4), e a previsão de modo único não corresponde ao estado
lançado. Os modos se defasam, e cada um muda de frequência por automodulação de fase e por modulação mútua dos outros.
Um autovetor isolado, lançado só no diagnóstico, segue a fórmula de modo único a 0,2%.

A correção declarada M07c (feita antes da rodada completa, em arquivos novos; sementes, malhas, amplitudes, tempo,
limiares e bandas sem mudança) compara modo a modo. Para modos não degenerados, com b_i a amplitude do modo i e
u_fi = (d₁V_i)_f a circulação do modo i na face f, a previsão de 1ª ordem é

\[
\frac{\Delta\omega_i}{\omega_i}=-\frac{1}{8\,\omega_i^{2}}\sum_f w_f\,u_{fi}^{2}\Big[\tfrac12\,|b_i|^{2}u_{fi}^{2}+\sum_{j\neq i}|b_j|^{2}u_{fj}^{2}\Big].
\]

O primeiro termo é a automodulação; o segundo, a modulação mútua, com peso duas vezes maior por unidade de energia. Com
um único modo, a fórmula volta à de modo único. A razão agregada pondera pela fração de energia de cada modo, somando os
que têm mais de 2%. A menor separação de frequência entre esses modos (0,2%) fica acima do maior desvio não linear
(~0,06%), condição para tratá-los como não degenerados.

| | Poisson 8³ | Poisson 10³ |
|---|---|---|
| razão da M07 (previsão coerente), A = 0,02 / 0,1 / 0,2 | 1,487 / 1,488 / 1,492 | 1,497 / 1,498 / 1,498 |
| previsão incoerente ÷ previsão coerente | 1,457 | 1,489 |
| **razão modo a modo (M07c), A = 0,02 / 0,1 / 0,2** | **0,957 / 0,957 / 0,958** | **0,999 / 1,000 / 1,002** |
| razão por modo significativo | 0,70–1,02 | 0,93–1,04 |
| modos significativos (fração da energia) | 9 (98%) | 6 (96%) |

**Leitura [M].** A razão original não muda com a amplitude e bate com o fator incoerente/coerente: não era efeito
não linear de ordem alta, era a previsão errada para o estado. Com a previsão certa, a razão vai a 1,000 na malha mais
fina. A autointeração de Wilson e sua expansão quártica valem também na dinâmica. O erro de 3–6% da B11-luz-luz original
não pôde ser comparado diretamente: o código original não está no Projeto nem no Drive, e não se sabe como ele lançava a
onda. O veredito pré-registrado da M07 (INCONCLUSIVO pela validação dinâmica) é relatado ao lado do corrigido
(COMPATÍVEL), §2.13.

> **Analogia.** É a diferença entre a farmacocinética de um compartimento e a de vários. Se o remédio se distribui por
> vários compartimentos com tempos diferentes, a fórmula de um compartimento erra a resposta, por mais certa que seja
> para um compartimento isolado. O saca-rolha numa malha irregular é uma dose dividida entre vários modos: a previsão
> precisa seguir cada modo e as trocas entre eles.

> **Analogia (B11-luz-luz).** É como checar se um remédio tem efeito paradoxal em dose altíssima. O mecanismo existe, mas na dose
> real, fixada pela B8, o efeito é 10⁵⁵ vezes menor que o do “remédio de referência” (a QED). A única marca reconhecível
> seria um padrão invertido no exame (qual polarização desacelera mais), longe de qualquer sensibilidade disponível.

### 2.7.4 Leitura de conjunto

O teto mais forte é o de Lorentz (B8). Os outros testes são muito mais frouxos. A rede do setor fotônico **HRF-FM**, herdada da C5A, com a_ρ abaixo de
~10⁻²⁷ m, é observacionalmente indistinguível do vácuo de Maxwell em todos os testes feitos.

> **Analogia.** Exames de rastreio com sensibilidades diferentes. O LHAASO é o exame mais sensível e parece enxergar
> sobretudo a cauda longa da faixa. O limite inferior das distâncias não aparece em nenhum exame feito até agora.

---

## 2.8 A versão quântica

### 2.8.1 Quantização canônica da conexão (B10, parte A) [M]+[F]

Impondo [a_e, Π_e'] = iħ δ_ee' na conexão não compacta:

| Critério | tremor 6³ | tremor 8³ | Poisson 8³ | tremor 10³ |
|---|---|---|---|---|
| modos nulos = N + 2 (gauge N − 1 + 3 harmônicos do toro) | 218 = 218 | 514 = 514 | 514 = 514 | 1 002 = 1 002 |
| lei de Gauss nos modos físicos | 4×10⁻¹⁴ | 3×10⁻¹⁴ | 4×10⁻¹⁴ | 5×10⁻¹⁴ |
| ω² negativos | 0 | 0 | 0 | 0 |
| camadas (12, 24) | sim | sim | sim | sim |
| helicidade de um quantum | ±0,89 | ±0,94 | ±0,93 | **±0,96** |

O desvio de |h| = 1 cai com o refinamento (0,110 → 0,062 → 0,038).

**B41 (M05) [M]:** as mesmas quatro malhas, com sementes novas. |h| médio de um quantum em tremor 10³: 0,9615; desvio de
|h| = 1: 0,108 → 0,062 → 0,0385 (tremor 6, 8, 10). Decisão reproduzida (4/4 bandas).

**Leitura correta.** Depois de **impor** a quantização canônica, o espectro físico é positivo, o gauge é exato, há dois
estados de um fóton por vetor k, e a helicidade converge para ±1, isto é, S = ±ħ. Cada modo é um oscilador independente,
e a estrutura de Fock, E = ħω(n + ½), segue [F]. **Nem a estatística bosônica nem ħ são derivadas.**

> **Histórico (caderno §15).** O oscilador transversal com [q, p] = iħ já dava E₁ − E₀ = ħω e L_z = ±ħ, tirando a
> amplitude “escolhida à mão” da primeira construção.

### 2.8.2 Conexão compacta e fase de Coulomb (B10, parte B) [M]

Se a fase das ligações é um ângulo (conexão compacta, decisão D2 ainda aberta), a teoria tem duas fases: uma confinante,
com monopolos de rede condensados e sem fóton livre, e uma de Coulomb, com fóton livre.

| Rede | β_c | monopolos: β = 0,2 → β_c + 0,5 |
|---|---|---|
| cúbica 6⁴ e 8⁴ (controle) | 1,00 (literatura: 1,011, Arnold et al., hep-lat/0011058) | 0,42 → 3–4×10⁻⁴ |
| Delaunay 5³×6 e 6³×6 (malha dos GMFs) | **0,64** nos dois tamanhos | 0,34 → 2×10⁻⁴ |

**B41 (M06) [M]:** cúbica 6⁴ e 8⁴: β_c = 1,00 e 1,00. Delaunay 5³×6 e 6³×6, duas realizações de cada, 300 + 300
varreduras: β_c = 0,62; 0,64; 0,64; 0,64. Monopolos em β = 0,2: 0,421 (cúbica) e 0,336 (Delaunay). A queda até
β_c + 0,5 foi de 855× a 1 894× (dois valores abaixo dos “> 1 000×” do texto original, acima do limiar pré-registrado de
500×). Bianchi D₃·B = 0 em todas as redes. Decisão reproduzida (5/5 bandas).

- Condição sobre o substrato [H], na correspondência isotrópica β = 𝒜*/ħ: **𝒜*/ħ ≳ 0,64** se a conexão for compacta.
  A correspondência entre a rede euclidiana e o limite hamiltoniano é aproximada.
- β_c **não** é constante física universal: depende de pesos, tamanhos e realizações (uma realização em dois tamanhos na
  B10; duas por tamanho na B41, 0,62–0,64). A B11-Morse encontrou transição perto de 0,6 também sob deformação forte
  (exploratório).
- O EM físico corresponde a β_EM = 1/(4πα) ≈ 10,9, fundo na fase de Coulomb. Na mesma correspondência, isso daria
  𝒜* ≈ 11 ħ e α = ħ/(4π𝒜*) [H]. **Isso não deriva α**; só troca “por que 1/137?” por “por que 𝒜* ≈ 11 ħ?”.
- D2 atualizada: conexão não compacta → nenhuma condição; compacta → exige 𝒜*/ħ ≳ 0,6, traz monopolos de rede (raros
  na fase de Coulomb) e a autointeração da §2.7.3.

> **Nota editorial v1.4 — setor compactado [F/M/?].** A existência de uma fase de Coulomb no modelo bosônico de rotores de Levin–Wen é um precedente de emergência **dentro daquele Hamiltoniano**; não identifica sua transição de fase ou parâmetros com a B10. Em especial, \(\beta_c\simeq0{,}64\) continua sendo o limiar medido no protocolo específico da malha Delaunay histórica do HRF e **não** é uma predição de Levin–Wen. Ver §2.8.4.

### 2.8.3 Energia de ponto zero [F]

A energia de ponto zero da rede é E₀/V ≈ 17,5 ħc/a⁴ (tremor) a 18,9 ħc/a⁴ (Poisson). Com a perto do teto da B8, ela é
enorme: é o problema da constante cosmológica em versão de rede. **Estimativa [M]:** se essa energia fosse a energia
escura observada (ρ_Λ ≈ 5,3×10⁻¹⁰ J/m³), daria a ≈ 0,18 mm, contradizendo o teto do LHAASO por ~10²³. O **HRF-FM**, ao herdar este setor da C5A, herda também o
problema e não o resolve aqui: ou a energia de ponto zero não gravita, ou é cancelada por outro mecanismo.

**B41 (M05):** E₀a⁴/V = 17,3 ħc (tremor) e 18,7 ħc (Poisson).

> **Analogia.** ħ é como o valor de referência que o laboratório fornece: usamos para interpretar o exame, mas ele não
> sai do exame.

---

### 2.8.4 Origem emergente de campos gauge e férmions: os mecanismos Levin–Wen [F/H/?]

**Objeto e estatuto.** [F] Os modelos bosônicos de Levin e Wen mostram que uma fase quântica coletiva, descrita por condensação de *string-nets*, admite excitações efetivas de gauge e, sob condições adicionais, partículas carregadas fermiônicas. São resultados de **modelos microscópicos determinados**, não comprovação experimental de uma ontologia do vácuo físico. [H/?] Sua incorporação ao HRF fornece uma **rota candidata** para reduzir a independência da conexão U(1) e da descrição de matéria carregada, mas **não** constitui uma derivação do Hamiltoniano do Capítulo 2 nem da dualidade holográfica HRF. Referências originais: Levin e Wen (2005, *Reviews of Modern Physics* **77**, 871–879, DOI 10.1103/RevModPhys.77.871; proposta `HRF-REF-0112`); Levin e Wen (2006, *Physical Review B* **73**, 035122, DOI 10.1103/PhysRevB.73.035122; proposta `HRF-REF-0113`).

**(a) Da microdinâmica bosônica ao setor de gauge.** [F, no modelo] Levin e Wen (2006, §II, eq. 1) consideram rotores quânticos nas **arestas de uma rede cúbica espacial 3D**, com operadores de momento angular inteiro \(L^z_\ell\) e operadores de deslocamento \(L_\ell^\pm=e^{\pm i\theta_\ell}\), na convenção \(\hbar=1\). Uma forma fiel do Hamiltoniano não torcido é

\[
H_{\mathrm{LW}}=V\sum_{I} Q_I^2+J\sum_{\ell}(L^z_\ell)^2-g\sum_p(B_p+B_p^\dagger),\quad
Q_I=(-1)^I\sum_{\ell\ni I}L^z_\ell,\quad
B_p=L_1^+L_2^-L_3^+L_4^-.
\]

O sinal \((-1)^I\) depende da bipartição da rede cúbica; a alternância em \(B_p\) segue a orientação dos quatro lados do plaquete. O operador de carga \(Q_I\) implementa uma penalização energética da violação do vínculo local, enquanto o termo com \(B_p\) cria/deforma laços de fluxo. Para \(V\gg g\gg J>0\), o setor de baixa energia apresenta \(Q_I=0\) e uma superposição quântica de redes de strings fechadas: fase denominada *string-net condensada*. A fase não é a presença de uma única string clássica, mas um estado quântico altamente correlacionado de configurações de fluxo (Levin e Wen 2006, §§II.A–C; Levin e Wen 2005, §§IV–VII).

Levin e Wen constroem um **mapeamento de espaço de estados e operadores** entre o modelo de rotores não torcido e a teoria gauge compacta U(1) com matéria escalar carregada; no caso sem salto de carga \(t=0\), os setores são matematicamente equivalentes. Em particular, na convenção orientada correspondente,

\[
E_{IJ}\longleftrightarrow(-1)^I L^z_{\ell(IJ)},\qquad
n_I\longleftrightarrow Q_I,\qquad
\nabla_{\!d}\!\cdot E=n,\qquad
\frac12(B_p+B_p^\dagger)\longleftrightarrow\cos\!\left(\sum_{\ell\in\partial p}s_{p\ell}A_\ell\right).
\]

O termo \(J\sum E^2\) é elétrico/cinético e o termo de plaquete é magnético/Wilson. No setor de Coulomb desconfinado, suas flutuações longas têm modos gauge sem massa: \(c_{\mathrm{LW}}\sim a\sqrt{gJ}\) e acoplamento efetivo de ordem \(\alpha_{\mathrm{LW}}\sim\sqrt{J/g}\), **até convenções e coeficientes de normalização** (Levin e Wen 2006, §II.C). Esses parâmetros dependem do Hamiltoniano escolhido; não são automaticamente a velocidade \(c\) ou a constante \(\alpha\) observadas.

**(b) Correspondência com o Capítulo 2, e diferença entre identidade cinemática e derivação microscópica.** [M] O HRF-FM histórico toma como graus operacionais \(a_e\) e \(U_e=e^{ia_e}\), com circulação \(C_f=(d_1a)_f\), energia de Wilson e forma quadrática \(d_1^{\mathsf T}M_2d_1\); \(d_1d_0=0\) garante invariância de gauge. Seu Hamiltoniano canônico esquemático, para massa de aresta \(M_1\) positiva, pode ser escrito

\[
H_{\mathrm{HRF}}=\tfrac12\Pi^{\mathsf T}M_1^{-1}\Pi
+\sum_f2w_f\,[1-\cos(d_1a)_f],\qquad \Pi=M_1\dot a.
\]

Esta é uma **reescrita hamiltoniana do setor assumido**, não um Hamiltoniano bosônico subjacente já derivado. [F] A aproximação \(1-\cos C_f\simeq C_f^2/2\) liga o termo de Wilson ao operador discreto *curl–curl*. [H] Uma interface LW→HRF exigiria construir, em uma rede e em uma janela de energias especificadas, um projetor \(P_{\mathrm{low}}\), um mapa \(\mathcal U\) entre espaços de Hilbert/álgebras de observáveis e uma aproximação controlada

\[
\mathcal U\,P_{\mathrm{low}}H_{\mathrm{micro}}P_{\mathrm{low}}\,\mathcal U^\dagger
=H_{\mathrm{HRF}}+\Delta H,\quad
\|\Delta H\|_{\mathcal S}/\Lambda\ll1,
\]

em setor finito \(\mathcal S\) e escala \(\Lambda\) declarados, juntamente com mapa de operadores \(E\leftrightarrow\Pi\), \(e^{iA}\leftrightarrow U\), lei de Gauss, parâmetros e espectro transversal. A igualdade escrita é **um contrato de teste [H]**, não resultado obtido. O vínculo \(d_1d_0=0\), embora necessário, **não basta** para demonstrar que o espaço físico quântico do HRF seja o subespaço sujeito à lei de Gauss do modelo de rotores; é preciso especificar o gerador de gauge, estados físicos e possíveis cargas/condições de borda. Em particular, a **energia de Wilson e a conexão deixam de ser entradas independentes apenas depois desse mapa**.

A igualdade estrutural entre plaquetes não impõe igualdade entre pesos e geometrias. [M/?] A matriz de Whitney \(M_2\), as métricas de aresta \(M_1\), os plaquetes triangulares e as medidas das malhas Delaunay do HRF **não** estão derivados do \(g,J,V\) e dos plaquetes quadrados cúbicos de Levin–Wen. Tampouco é permitido transportar a transição \(\beta_c\simeq0{,}64\) da B10 em Delaunay para o modelo LW: regulador, ação, parâmetros e limite estatístico diferem. Os resultados e falhas de HOL1, B1, B10, controles 2D3V e respectivas gates permanecem em seus escopos históricos, sem alteração.

**(c) Férmions: a torção não é opcional.** [F, nos modelos] O Hamiltoniano não torcido com saltos de cargas produz **cargas bosônicas**. Para cargas fermiônicas, Levin e Wen (2006, §III, eqs. 8–11) introduzem um **operador de string torcido**, com fator de sinal \((-1)^{\sum n_\ell^{c}L_\ell^z}\) associado a cruzamentos e a uma convenção de *framing*, modificando os operadores de plaquete e de transporte. No setor de cargas móveis, a álgebra de saltos torna-se

\[
\widetilde t_{IL}\widetilde t_{KI}\widetilde t_{IJ}=
-\widetilde t_{IJ}\widetilde t_{KI}\widetilde t_{IL},
\]

para os caminhos locais indicados no artigo (Levin e Wen 2006, eq. 19). Essa relação operacional diagnostica estatística fermiônica. No artigo de 2005 (§VII.B), o mesmo conteúdo é expresso por regras de amplitudes de strings orientadas com rótulos inteiros e conservação \(a+b+c=0\), e por fases de cruzamento que dão sinais de troca fermiônicos para extremidades de strings de fluxo ímpar. **Uma conexão U(1), um laço orientado ou uma onda circular do HRF, isoladamente, não produzem esse sinal de troca.** Até haver operadores de extremidades, álgebra de transporte e setor carregado, a estatística fermiônica permanece **[?] no HRF**.

**(d) Modos de Dirac e massa do elétron.** [F, no modelo] Levin e Wen (2006, §IV) constroem ainda um Hamiltoniano bosônico modificado com sub-redes \(eee\) e \(ooo\), saltos de duas arestas e fluxo efetivo \(\pi\) nos plaquetes duplicados. A dispersão de bandas em um fundo apropriado é

\[
\varepsilon_\pm(\mathbf k)=\pm t\sqrt{\cos^2(2k_xa)+\cos^2(2k_ya)+\cos^2(2k_za)}-\mu.
\]

Para \(\mu=0\), os nós de banda dão excitações relativísticas de Dirac **sem massa**, com multiplicidades especificadas pelos autores (quatro espécies de espinores de Dirac de quatro componentes). O modelo não deriva por si mesmo a massa de repouso do elétron físico, \(m_ec^2\simeq511\,\mathrm{keV}\), nem as interações quirais completas do Modelo Padrão. A velocidade fermiônica \(c_e\sim ta\) e a velocidade gauge \(c\sim a\sqrt{gJ}\) não coincidem genericamente: no exemplo, ajusta-se \(t\) para igualá-las (Levin e Wen 2006, §IV.D). Uma compatibilidade com Lorentz no infravermelho precisa ser demonstrada, não imputada por nomenclatura.

**(e) Dimensionalidade e holografia.** [D/?] Os modelos explícitos de Levin–Wen descritos aqui usam **três dimensões espaciais microscópicas** mais tempo. A projeção gráfica de seus *string-nets* ou a escolha de *framing* em um plano 2D **não** constitui uma CFT na boundary nem uma dualidade holográfica. O HRF possui três contextos historicamente distintos: (i) malhas Delaunay **3D** do Capítulo 2; (ii) solvers **2D3V**, com \(\partial_z=0\) e três componentes vetoriais; (iii) programa **boundary espacial 2D → bulk espacial 3D** por reconstrução holográfica. Um modelo LW de rede 3D não fornece automaticamente o terceiro contexto, tampouco sua componente vertical é uma coordenada radial holográfica. Seriam necessários álgebra quântica regional, espaço de estados adequado, dicionário de operadores boundary↔bulk, tratamento de gauge/edge modes, correlações e condições de validade de RT/HRT. Essa costura permanece **[H/?]**.

**(f) Resultado editorial e limite de incorporação.** [D] A física de Levin–Wen será incorporada ao Capítulo 2 como **precedente construtivo** para investigar a origem do setor gauge e, em estudos posteriores, das cargas fermiônicas. [M] Permanecem válidos **apenas nos escopos registrados** os resultados do Capítulo 2: duas polarizações e identidade combinatória de gauge, espectros, controles e limites de bancada; os PASS e FAIL 2D3V não se transferem ao modelo de rotores. [?] Não estão derivados pelo HRF o Hamiltoniano microscópico LW, o mapa de Hilbert entre os modelos, \(\hbar\), \(\alpha\), a carga eletrônica, a estatística fermiônica, a massa de 511 keV, a invariância relativística exata ou uma equivalência holográfica LW/HRF. Não se altera o fechamento provisório histórico da §2.12.

**[D] Próximo gate puramente analítico, NÃO EXECUTADO:** estabelecer a existência ou impossibilidade de um mapa canônico entre o setor de rotores não torcido sem cargas e o setor U(1)/Wilson do HRF, primeiro numa malha 3D de referência com pesos uniformes e só depois numa célula Delaunay/Whitney. Caso a correspondência não sobreviva à geometria irregular, registrar **INCOMPATÍVEL/FAIL**, não reinterpretá-la como derivação.

---

## 2.9 O que o capítulo não afirma

- que GMFs existem fisicamente ou constituem a ontologia fundamental completa do HRF: os resultados são de toy models;
- que GMF e PGFE são sinônimos: essa relação permanece aberta no HRF;
- que este capítulo reconstrói a geometria ou o espaço-tempo: essa tarefa pertence ao HRF-ST;
- que ħ foi derivado: entra como dado;
- que a estatística bosônica foi derivada: é reproduzida depois de impor a quantização;
- que a conexão U(1) e a energia de Wilson foram derivadas: são postuladas; por que U(1) e não SO(3) está em aberto;
- que α foi derivado: α = ħ/(4π𝒜*) só reformula a pergunta;
- que Lorentz vale exatamente no UV: há referencial preferido da rede, com efeitos abaixo dos limites;
- que a birrefringência do vácuo está fechada em todos os canais: só o circular foi testado;
- que 1,6×10⁻²⁷ m é a distância máxima entre GMFs: o limite é sobre √ξ·a_ρ;
- que ℓ_max amostral é uma escala física: a B14 descartou essa leitura;
- que β_c ≈ 0,64 é constante universal;
- que emissão e absorção estão explicadas;
- que monopolos de rede, topologia ou helicidade são carga elétrica;
- *(v1.3)* que a B41 testa algo novo sobre o fóton: ela é uma replicação;
- *(v1.3)* que o critério P1 da B1 é um indicador robusto do fechamento: com a taxa de falhas pontuais observada, ele
  passa em cerca de metade das rodadas;
- *(v1.3)* que a validação dinâmica original da B11-luz-luz foi refeita tal como foi feita: o código original não foi
  encontrado; a B41 validou a dinâmica com uma previsão modo a modo;
- *(v1.3)* que o “teto mais restritivo da B3” é um número estável: variou quatro ordens de grandeza entre rodadas;
- *(v1.5)* que afinar a malha, sozinho, elimina as falhas de preparação do estado de helicidade: as reduz (15% em 10³,
  0 em 20 em 22³), mas a carga espúria típica para de cair entre 18³ e 22³ (§2.14);
- *(v1.5)* que a falha do item 9 da semente 41020004 na B41 é de preparação: não depende da limpeza do lançamento.

---

**Nota editorial v1.4 [D/?]:** a adição do precedente Levin–Wen **não** altera os itens acima: o HRF continua sem derivação própria de U(1), energia de Wilson, cargas/estatística fermiônica, elétron de massa 511 keV, origem de \(\hbar\) ou correspondência holográfica com rede de rotores. A formulação de Levin–Wen é uma **possibilidade de derivação futura**, não um resultado transplantado.

---

## 2.10 Caminhos descartados

| Ramo | Lição |
|---|---|
| campo derivado do estado local q_n (HOL1 P2) | não gera fóton: energia zero no plano ou longitudinal propagante |
| acoplamento laplaciano vetorial | deixa um longitudinal físico (3 modos) |
| micro-hélice geodésica (G0, G0B, G0C) | torção uniforme é calibre; torção física em onda pp exige fonte que viola a NEC |
| saca-rolha gravitacional (G0D, G0E) | só é admissível empurrado por meio com energia; custo mínimo = energia do giro (von Laue) |
| hélice autoinduzida (G0F) | exigiria acoplamento gravitacional ~(λ/ℓ_P)² × G |
| onda com “ponta” como elétron | substituída pela captura (capítulo de matéria) |
| vórtices de arrasto como quiralidade do vácuo (B3) | vorticidade total nula: não agem em ondas extensas |
| ℓ_max amostral como escala física (B14) | um extremo isolado não muda ξ |
| teto do INVERSE-01 (7,6×10⁻²⁸ m) | convenção errada; substituído pela forma canônica |
| *(v1.3)* previsão de modo único coerente para o saca-rolha numa malha irregular (B41, M07) | o estado lançado é multimodal; a comparação certa é modo a modo (M07c) |
| *(v1.5)* lançar o saca-rolha copiando o contínuo sem impor a lei de Gauss discreta (B1, B41) | deixa carga espúria que contamina a medida da helicidade; lançar limpo (B41H) |

---

## 2.11 Questões abertas e pontes para os capítulos seguintes

**Refinamentos do próprio ramo (não impedem o fechamento):**
- transporte completo de polarização (Stokes/Jones), incluindo o canal linear;
- qual propriedade da faixa controla ξ (p99, correlações espaciais, forma dos tetraedros);
- normalização dos pesos D;
- β_c com mais tamanhos, realizações e pesos geométricos (a B41 acrescentou duas realizações por tamanho: 0,62–0,64);
- B12-Morse com várias realizações e pré-registro: feito na B41 (M10), mas num regime de deformação mais forte que o
  original; falta repetir no regime original (~0,71–1,28 r₀), controlando a injeção de energia;
- faixa variando no tempo × coerência de fótons cosmológicos;
- ~~*(v1.3)* taxa de falha da preparação do estado de helicidade por semente e por malha~~ — **respondida na v1.5
  (B41H, §2.14):** 15% → 7,5% → 2,5% → 0% de 10³ a 22³; a causa é a carga espúria do lançamento;
- *(v1.5)* adotar o lançamento limpo como padrão das bancadas do capítulo [D, a decidir] e, se for o caso, repetir a B1
  com ele, num pré-registro novo;
- *(v1.5)* o caso extremo da semente 20261201 (lasca de 0,056°, com 99% da carga espúria em 1% dos GMFs) precisa da
  limpeza e da métrica M1 juntas;
- *(v1.5)* a retroação fraca na malha-guia h = 0,46 fica 16% acima do limite do item 9 (η_g = 0,0116), com ou sem
  limpeza;
- *(v1.3)* recuperar o código original da validação dinâmica da B11-luz-luz ou adotar a comparação modo a modo (M07c)
  como padrão das validações não lineares com o saca-rolha;
- *(v1.3)* teto da B3 como distribuição sobre realizações, não como um valor único.

**Pertencem a outros ramos/capítulos do HRF:**
- **emissão e absorção de um quantum** → **HRF-FM, Capítulo 4 — Estados ligados e massa emergente** (captura, B4/B5; ação de transição, B6), com interface posterior ao Capítulo 5;
- **não linearidade da QED por pares virtuais** → **HRF-FM, Capítulo 5 — O programa do elétron**;
- **origem de ħ** → problema de unificação do HRF, retomado no **Capítulo 12**; historicamente ligado à hipótese da ação universal de transição (Atualização 28), enquanto a B2 não encontrou quantum de ação na
  conexão compacta clássica;
- **origem de U(1), de α e da carga** → [?], interface dos Capítulos 5, 11 e 12;
- **formulação covariante** A_μ/F_μν e Lorentz spin-1 → [?].

**Ponte nova, não pré-registrada (v1.3) [H].** A nota de 27 de outubro de 2026, *Horizonte na malha de GMFs: escoamento
contra a onda fotônica* (Claude Doc), propõe fazer a malha escoar contra a onda fotônica, com um gradiente de
velocidade, para formar um horizonte análogo ao de Unruh (1981) em 3+1D. A dispersão da rede é subluminal
(ω/ck = 1 − ξ(ka)²), o regime estudado por Unruh (1995) e Corley–Jacobson (1996) para o problema trans-planckiano. É a
proposta da bancada B43, ainda não pré-registrada nem executada.

**Programa inverso:** partir dos observáveis e inferir a região de microestruturas compatíveis,
θ_micro = {a_ρ, P(r), r_tail, U(r), μ, conectividade, …}, com parte dos dados guardada para teste. Os limites do setor
do fóton só dão tetos (desigualdades). Para fixar valores, o programa precisa de **números positivos medidos**: α
(via 𝒜*), ħ, m_e, G e a constante cosmológica, este como teste de consistência.

---

**Adendo editorial v1.4 — interface Levin–Wen [H/?], NÃO EXECUTADA:** em sequência B → A, verificar (1) mapa de estados/cargas entre os rotores e o campo U(1) de referência, (2) equivalência hamiltoniana/canônica com os laços do HRF, (3) migração de plaquetes quadrados para triangulações Delaunay e pesos Whitney, (4) construção separada do setor torcido com sinais fermiônicos e (5) somente após isso, existência de dicionário boundary–bulk com álgebra/edge modes. Todos os cinco são **propostas**, não tarefas executadas. Ver §2.8.4 e protocolo analítico independente.

---

## 2.12 Registro de fechamento provisório

\[
\boxed{\text{HRF-FM — ramo da onda fotônica livre: FECHADO PROVISORIAMENTE como toy model [M] — 2 de outubro de 2026}}
\]

**Decisão [D] (Mario, 2 out 2026):** o ramo do fóton livre é considerado provisoriamente fechado. No desenvolvimento histórico C5A, o trabalho passou ao ramo da matéria (elétron). Na organização editorial do HRF, os resultados seguintes distribuem-se principalmente entre o **Capítulo 3 — Microestrutura dinâmica**, o **Capítulo 4 — Estados ligados e massa emergente** e o **Capítulo 5 — O programa do elétron**, levando como entrada:
1. a conexão relacional U(1) com energia de Wilson e pesos de Whitney;
2. malhas sem grade, com faixa de distâncias (D3), estáticas ou deformáveis;
3. gauge preservado sob deformação;
4. a_ρ distinto de r_nm; o teto UV escrito como √ξ·a_ρ ≲ 2,0×10⁻²⁸ m;
5. ℓ_max isolado descartado como variável;
6. se a conexão for compacta, a fase de Coulomb (𝒜*/ħ ≳ 0,64) e a autointeração de rede (desprezível).

*[Nota v1.3: “Capítulo 3 — Microestrutura dinâmica” é a designação da organização de 5 de outubro. Desde 21–22 de
outubro, o Capítulo 3 é “A base quântica compartilhada e a emergência das organizações físicas”; a designação antiga
fica rastreável.]*

**Critérios para reabrir:**
- um resultado do ramo de matéria exigir uma conexão ou malha incompatível com as deste capítulo;
- uma observação nova apertar o teto de Lorentz a ponto de exigir ξ menor que o de qualquer família testada;
- uma medida de birrefringência do vácuo (circular ou linear) incompatível com o desdobramento previsto;
- uma assinatura de polarização tipo rede (3:1 invertido) em birrefringência magnética do vácuo.

**Atualização de 28 de outubro de 2026 (B41) [M].** A bancada mestre B41 repetiu o capítulo com sementes novas (§2.13).
Com a correção declarada M07c, as 61 bandas numéricas ficaram dentro, e 9 das 10 decisões se repetiram. A única decisão
não reproduzida foi a do critério P1 da B1 (8/10 contra o mínimo de 9/10), lida em §2.5.3 como fragilidade do critério
e da preparação do estado de helicidade, não das grandezas. Nenhum dos critérios de reabertura acima foi atingido, e o
fechamento provisório continua de pé por eles. Uma eventual qualificação do rótulo é decisão do pesquisador [D] e não
está registrada nesta versão. Os itens de entrada 2 a 6 foram testados de novo na B41 e se reproduziram; o item 1 é a
escolha de modelo usada em todos os módulos.

**Atualização de 29 de outubro de 2026 (B41H) [M].** A fragilidade de P1 tinha uma causa técnica no lançamento, não na
física (§2.14): a carga espúria da onda copiada para a malha. Nenhum critério de reabertura foi atingido. A mudança é
de método: o lançamento limpo é a forma recomendada de preparar o estado nas próximas bancadas [D, a decidir].

---

## 2.13 Reprodutibilidade: a bancada mestre B41 [M] *(novo na v1.3)*

### 2.13.1 Objetivo

Reproduzir numa só rodada, com sementes novas e pela regra de decisão de cada bancada original, os resultados
principais deste capítulo: curl-curl emergente e HOL1, B1, B8, B3, B10 (partes A e B), B11-luz-luz, B12-faixa, B14 e a
faixa deformável de Morse. A B41 não testa nada novo sobre o fóton. Se reproduzir, o fechamento ganha robustez; se não
reproduzir, aponta qual resultado precisa ser revisto e em qual módulo.

### 2.13.2 Hipóteses

- **H0 [M]:** os resultados não dependem das sementes nem da máquina. Cada módulo deve repetir a decisão da bancada
  original, e os números devem cair em bandas tiradas da v1.1.
- **Âncora:** a B1a original, com a semente original 20261204 e as mesmas versões de NumPy e SciPy, deve dar o mesmo
  resultado bit a bit. Ela separa “a física mudou” de “o ambiente numérico mudou”.

### 2.13.3 Parâmetros

Sementes novas: 41 000 000 + 10 000·módulo + índice, nenhuma usada antes. Caixa periódica L = 4, malhas 3D: as Delaunay
tridimensionais históricas, não as reduções 2D3V de §2.4.1. Toda onda injetada é o saca-rolha (polarização circular).

| Módulo | Bancada original | Tamanhos e réplicas |
|---|---|---|
| M00 | âncora B1a | semente 20261204, resoluções da B1 |
| M01 | curl-curl + HOL1 | espectro e gauge em 13³ |
| M02 | B1 | 10 sementes (6 com guia); dispersão 10, 14, 20; energia–momento 7–20; conservação 10, 14, 18; guia h = 0,55; 0,46; 0,40 |
| M03 | B8 | lados 10, 14, 20, 26 × 10 realizações, 13 direções |
| M04 | B3 | lados 10–26, Lz até 32, 10 realizações, mais os controles |
| M05 | B10 parte A | tremor 6, 8, 10 e Poisson 8 |
| M06 | B10 parte B | cúbica 6⁴ e 8⁴; Delaunay 5³×6 e 6³×6, duas de cada; 300 + 300 varreduras |
| M07 | B11-luz-luz | estático: Poisson e tremor 10, 14, 20 × 3; dinâmico: Poisson 8 e 10, T = 200 |
| M08 | B12-faixa | 5 famílias × lados 10, 14, 20 × 3 |
| M09 | B14 | tremor 14³ e 20³ × 3 |
| M10 | Morse | n = 4, 6, 8 × 3; λ = 4, u = 0,2; 20 períodos |

### 2.13.4 Protocolo

1. **27/10, 20:10:** pré-registro congelado com hashes e copiado no Projeto antes de qualquer execução.
2. **28/10, 06:51–07:00:** fumaça (tamanhos reduzidos, números descartados), 26 de 26 trabalhos sem erro. Uma conferência
   de código falhou: a dinâmica da M07 deu medido/previsto ≈ 1,5–1,7.
3. **09:00:** correção declarada da M07 (M07c), feita depois do diagnóstico na fumaça e antes de a M07c rodar em
   tamanho completo. Só arquivos novos; nenhum arquivo congelado mudou.
4. **Rodada completa** no Google Colab (12 núcleos, 52 GB, 11 trabalhadores; Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1).
   Interrompida por reinícios da sessão (07:51 e 12:34) e retomada pelos marcadores de trabalho concluído. Terminou às
   14:04 com 65 de 65 trabalhos e nenhuma falha. O cálculo é determinístico, então os reinícios não mudam números.
5. **14:04–14:06:** avaliador pré-registrado; M07c em Poisson 8 e 10; avaliação com a correção, relatada ao lado da
   pré-registrada.

### 2.13.5 Medidas

Cada módulo mede o que a bancada original media e passa pela regra dela. M02, M03 e M04 usam os avaliadores originais
(`avaliar_B1`, `avaliar_B8`, `avaliar_B3`), trocando só as listas de sementes. Os demais aplicam, em código novo
escrito antes da rodada, a regra do pré-registro original: B10 (A e B), B11-luz-luz, B12-faixa, B14 e Morse foram
**reimplementados**, porque o código original não estava no Projeto nem no Drive. As 61 bandas comparam os números com os
da v1.1.

### 2.13.6 Resultados

**Veredito.**

| | Pré-registrado | Com a correção declarada M07c |
|---|---|---|
| **Veredito** | **NÃO REPRODUZIDO** (M02, M07) | **NÃO REPRODUZIDO** (só M02) |
| Decisões iguais às deste capítulo | 8 de 10 | 9 de 10 |
| Bandas numéricas dentro | 60 de 61 | 61 de 61 |
| Âncora M00 | confere bit a bit | confere bit a bit |

**Decisões por módulo.**

| Módulo | Bancada | Decisão esperada | Decisão obtida | Bandas |
|---|---|---|---|---|
| M01 | curl-curl + HOL1 | OPERADOR E GAUGE REPRODUZIDOS | igual | 5/5 |
| **M02** | **B1** | **PHOTON-CLOSURE-E FECHADO** | **NÃO FECHADO — falhou: P1** (§2.5.3) | **9/9** |
| M03 | B8 | COMPATÍVEL | igual | 8/8 |
| M04 | B3 | COMPATÍVEL | igual | 4/4 |
| M05 | B10-A | FÓTON QUÂNTICO LIVRE OK | igual | 4/4 |
| M06 | B10-B | COMPACTA VIÁVEL | igual | 5/5 |
| **M07** | **B11-luz-luz** | **COMPATÍVEL** | **INCONCLUSIVO (validação dinâmica) → COMPATÍVEL com M07c** (§2.7.3) | **7/8 → 8/8** |
| M08 | B12-faixa | FAIXA NEUTRA; PESOS D REQUEREM FATOR GLOBAL | igual | 12/12 |
| M09 | B14 | ℓ_max ISOLADO DESCARTADO | igual | 2/2 |
| M10 | Morse | FÓTON SOBREVIVE À FAIXA DEFORMÁVEL | igual | 4/4 |

**Números principais, v1.1 × B41.**

| Grandeza | v1.1 | B41 |
|---|---|---|
| ε_cc (pesos W, 5 832 GMFs); ordem de convergência | 0,0087; ≈ 2 | 0,0086; 2,19 |
| conchas do espectro (13³) | 12, 24, 16 | 12, 24, 16 |
| HOL1 P2: ω_L²/ω_T², malha grossa / fina | 0,19 / 0,029 | 0,222 / 0,0278 |
| B1: ordem do resíduo de helicidade (mediana) | 0,98 | 0,977 |
| B1: impureza de helicidade em 18³ | 1,1×10⁻⁴ | 1,45×10⁻⁴ |
| B1: ordem de (E² − P²c²)/E², h = +1 / linear | 1,98 / 1,93 | 1,966 / 1,918 |
| B1: ω/ck (m = 1) em 20³ | 0,998 | 0,9984 |
| B1: supressão Δ_hel(N4)/Δ_hel(compensado) | 8–40× | 35,8× |
| **B8: ξ (eixo, 20³)** | **0,0163 [0,0161; 0,0164]** | **0,0162 [0,0159; 0,0166]** |
| **B8: teto a_ρ,max** | **1,6×10⁻²⁷ m** | **1,59×10⁻²⁷ m** |
| B8: teto canônico √ξ·a_ρ | 2,0×10⁻²⁸ m | 2,02×10⁻²⁸ m |
| B8: anisotropia de c em 26³ | 1,4×10⁻⁶ | 1,36×10⁻⁶ (inclinação −5,78) |
| B8: ξ eixos / diagonais de face / de cubo | ≈ 0,017 / 0,005 / 0,001 | 0,0165 / 0,0048 / 0,0009 |
| B3: calibração δ/(ξk) em 26³ | 0,993 | 0,9932 |
| B3: quiralidade única ÷ compensada | ~10⁴ | 1,6×10⁴ |
| B10-A: \|h\| de um quantum (tremor 10³); desvio | 0,96; 0,038 | 0,9615; 0,0385 |
| B10-A: E₀a⁴/V, tremor / Poisson | 17,5 / 18,9 ħc | 17,3 / 18,7 ħc |
| B10-B: β_c cúbica / Delaunay | 1,00 / 0,64 | 1,00, 1,00 / 0,62, 0,64, 0,64, 0,64 |
| B10-B: monopolos em β = 0,2, cúbica / Delaunay | 0,42 / 0,34 | 0,421 / 0,336 |
| B11: Δκ (Poisson 20³); κ∥/κ⊥ | 0,319 ± 0,004; 3 | 0,3213; 2,984–3,003 |
| B11: \|Δn_rede\|/Δn_QED no teto da B8 | 3×10⁻⁵⁵ | 2,98×10⁻⁵⁵ |
| B11: a em que a rede igualaria a QED; a máximo pela PVLAS | 6,8×10⁻¹⁴ m; 1,2×10⁻¹³ m | 6,80×10⁻¹⁴ m; 1,17×10⁻¹³ m |
| B11: razão dinâmica medido/previsto | erro de 3–6% | 1,000 em Poisson 10³ (modo a modo, M07c) |
| B12: ξ por família, 20³ (Poisson, mínimo 0,4a / 0,6a / 0,8a, tremor) | 0,0112; 0,0103; 0,0088; 0,0056; 0,0064 | 0,0110; 0,0105; 0,0086; 0,0059; 0,0064 |
| B12: c₀ com pesos D (Poisson … tremor) | 1,197; 1,185; 1,159; 1,117; 1,143 | 1,198; 1,185; 1,159; 1,118; 1,143 |
| B12: desdobramento tremor ÷ Poisson; variação do teto | ~7–10; ≤ 1,4× | 8,4; 1,37× |
| B14: \|ξ(defeito)/ξ(base) − 1\| em 20³ | 0,2% | 0,32% |
| Morse: ξ_eff no equilíbrio / sob deformação | ≈ 0,02 / ≈ 0,02 | 0,016 / 0,015 |
| Morse: desdobramento sob deformação, grosso → fino | 1,77×10⁻² → 2,01×10⁻³ | 1,30×10⁻² → 1,63×10⁻³ |

### 2.13.7 Controles e convergência

- **Âncora M00:** confere bit a bit com a B1a original (mesmas séries e ordens: p_e2 = 1,9475…, p_hel = 0,9554…). O
  código deste capítulo é determinístico entre máquinas com as mesmas versões.
- **M03:** o controle cúbico dá ξ(k̂) = Σk̂⁴/24 com erro de 1,2×10⁻⁵ e c₀ isotrópico a 6×10⁻¹⁶. A rede N6 com pesos U
  acusa anisotropia (0,050), e com pesos W não (8×10⁻⁵).
- **M05:** o desvio de |h| cai com o refinamento: 0,108 → 0,062 → 0,0385.
- **M06:** o controle cúbico dá β_c = 1,00; Bianchi D₃·B = 0 em todas as redes.
- **M07:** o controle cúbico de κ dá 0,6017 e 0,1974 (esperado 0,6 e 0,2); a convergência Poisson de Δκ fica dentro de
  10%. A razão modo a modo da M07c converge para 1 com a malha: 0,957 em Poisson 8³ e 1,000 em Poisson 10³.
- **M08:** o ponto de partida (V0) é idêntico ao da M03 (diferença 0 em c₀ e em ξ).

**Desvios declarados.**
1. **M07c:** correção de desenho achada na fumaça e declarada antes da rodada completa da M07c, em arquivos novos. O
   veredito pré-registrado é relatado lado a lado com o corrigido.
2. **Interrupções da rodada completa** (07:51 e 12:34): retomada pelos marcadores; cálculo determinístico; nenhum
   trabalho aproveitado pela metade.
3. **M10, regime de deformação:** 0,70–2,39 r₀ e Jaccard mínimo 0,80, contra ~0,71–1,28 r₀ e 0,925 no original (§2.6.4).
4. **M04:** o teto mais restritivo da B3 saiu 4,6×10⁻¹⁹ m, contra 5,8×10⁻²³ m; a banda passa (§2.7.2).
5. **M06:** a queda de monopolos foi de 855× a 1 894×, acima do limiar pré-registrado de 500× (§2.8.2).

### 2.13.8 Interpretação

- **[M] O capítulo se reproduz em números.** Com sementes novas e em outra máquina, as 61 bandas caem dentro (60 sem a
  correção M07c). Os resultados centrais se repetem até o terceiro algarismo: o teto de Lorentz a_ρ,max = 1,59×10⁻²⁷ m,
  ξ = 0,016, κ∥/κ⊥ = 3 e 3×10⁻⁵⁵ da QED, β_c = 0,64 na malha dos GMFs, o c₀ dos pesos D por família, as conchas
  12/24/16 e as ordens de convergência da B1.
- **[M] O que não se reproduz é uma regra, não um número.** O “FECHADO” da B1 depende de um critério (P1 ≥ 9/10) que,
  com a taxa de falhas pontuais observada, passa em cerca de metade das rodadas (§2.5.3).
- **[M] A validação dinâmica da B11-luz-luz vale com a previsão certa para o estado lançado** (§2.7.3). O achado
  correspondente sobre a forma da onda está em §2.4: numa malha irregular, o saca-rolha se distribui por vários modos.
- **[?] A preparação ocasionalmente falha do estado de helicidade** (B1 em 10³; B41 em 14³, 18³ e na guia h = 0,55) é o
  ponto técnico aberto (§2.11). *(Resolvido na v1.5: a causa é a carga espúria do lançamento, §2.14.)*
- **Sem mudança de status:** PHOTON-CLOSURE-F continua NÃO FECHADO, e nada aqui deriva o fóton físico.

> **Analogia.** A B41 é a segunda opinião com outro laboratório. Ela confirma o diagnóstico em todos os valores medidos
> e aponta duas coisas que o primeiro laudo não mostrava: uma regra de decisão sensível demais ao acaso (P1) e uma
> fórmula que só valia para um caso particular do exame (a validação dinâmica de modo único).

---

## 2.14 A preparação do estado de helicidade: a bancada B41H [M] *(novo na v1.5)*

Relatório completo e auditoria: `HRF_B41H_Relatorio_e_Auditoria_PT_2026-10-29_1816-clau.md`.

### 2.14.1 Objetivo

Descobrir por que algumas sementes da B1 e da B41 preparam mal o estado de helicidade (§2.5.3), e responder à pergunta do
pesquisador: usar malhas mais finas evita essas falhas? A bancada não muda nenhum veredito anterior.

### 2.14.2 Hipóteses

- **H0, resolução:** malhas grossas preparam pior. Prevê que a taxa de falha cai com o tamanho da malha.
- **H3, gauge no lançamento [H]:** a onda copiada leva uma parte longitudinal parada (carga espúria). Prevê que lançar
  limpo elimina a falha e que a fração oscila com a frequência da própria onda (Ω ≈ ω).
- **Alternativas:**
  - H4: métrica da medida;
  - H2: mistura de modos, que daria oscilação lenta;
  - H1: lascas (tetraedros quase achatados).

A leitura das saídas brutas da B41 já apontava para a H3 [pós-hoc, antes do pré-registro]:
- a semente 41020005 em 14³ saía com fração 0,916 já em t = 0;
- a fração oscilava com período ≈ 4 = 2π/ω.

### 2.14.3 Parâmetros

- **Parte A:** os casos que falharam, repetidos exatamente.
  - Conservação: sementes da B41 41020001–41020005 em 10³, 14³ e 18³.
  - Conservação: sementes da B1 20261201–20261210 em 10³.
  - Guia: 41020005 e o controle 41020001, ambos com h = 0,55; e 41020004 com h = 0,46.
- **Parte B:** 40 sementes novas em 10³, 14³ e 18³, e 20 delas também em 22³.
- O saca-rolha é lançado em todas. Falha quer dizer f_min ≤ 0,99 (item 6 da B1).

### 2.14.4 Protocolo

- Pré-registro em 29/10, 00h27. Fumaça às 00h43, rodada por Mario: passou em todas as conferências.
- Duas tentativas da rodada completa caíram por falta de RAM. Daí duas correções só do caderno do Colab:
  - C01: a saída dos comandos fica visível;
  - C02: limite de memória da fila, uma opção que já existia no orquestrador congelado.
- A rodada que valeu foi das 10h14 às 17h45, com 168 de 168 trabalhos e nenhuma falha. Avaliação congelada às 18h05.

### 2.14.5 Medidas

- **V0:** a fração na helicidade lançada medida como na B1.
- **V1:** a mesma medida sem a parte longitudinal π_L = M1 d0 λ. Equivale a lançar com v₀ − d0 λ.
- **M1 e M1T:** a métrica M1, com e sem π_L.
- **Também:** f(0), f_min e a frequência dominante; δ_L2 = |π_L|/|π₀|; diedros; Δ_hel no guia; a retroação fraca.

### 2.14.6 Resultados

| Regra congelada | Resultado |
|---|---|
| **Veredito** | **CAUSA_GAUGE_NO_LANCAMENTO** |
| Q1: afinar reduz as falhas? | **sim:** 6/40 (10³), 3/40 (14³), 1/40 (18³), 0/20 (22³); tendência p = 0,0054 |
| Q2: o lançamento limpo resolve? | **elimina:** 10 falhas → 0 em 140 malhas; McNemar p = 0,00098 |
| Q3: malha mais fina | 0/20 em 22³, IC 95% de 0 a 16,8% |
| A2: mecanismo nos casos antigos | H3 predominante: 6 de 7 GAUGE e 1 METRICA (20261201) |
| A4: item 9 (41020004, h = 0,46) | marginal e independente da limpeza: η_g = 0,01156 → 0,01154 |

**Casos antigos (Parte A).**
- **Sementes da B1.** As frações iniciais 0,4893 e 0,9249 das sementes 20261201 e 20261202 reapareceram: são o "0,49 e
  0,92" registrados na B1. A semente 20261209 também falha (f_min = 0,932).
- **Assinatura e limpeza.** Nas seis falhas de conservação, a fração oscila com Ω/ω de 0,987 a 1,004. A limpeza resolve
  cinco delas; a pior da B41 (41020005 em 14³) vai de 0,598 a 0,99995.
- **Guia 41020005 (h = 0,55).** Δ_hel vai de 1,99 a 9×10⁻⁶. A frequência da helicidade lançada, que estava parada em
  0,003, volta a 1,661 (no controle, 1,657).

**Pós-hoc, descritivo.**
- **δ_L2 separa as falhas.** Na Parte B, toda falha tem δ_L2 ≥ 0,28, e só 3 das 130 malhas que passam chegam a esse
  valor.
- **Afinar corta a cauda.** O máximo de δ_L2 cai de 0,90 a 0,28 de 10³ a 22³. A mediana para em 0,13 em 18³ e 22³.
- **Lascas não bastam.** O diedro mínimo piora quando se afina a malha (0,69° → 0,16°), e mesmo assim as falhas
  diminuem.
- **O que sobra é física [H].** Depois da limpeza, a pequena oscilação restante tem 2ω, o batimento com a helicidade
  oposta: é a impureza genuína da onda discreta, que converge com a malha.

### 2.14.7 Controles e convergência

- **Código e versões.** O código usado (11 arquivos de cálculo, no Drive) tem os hashes do pré-registro. As 168 saídas
  têm as mesmas versões (NumPy 2.5.3, SciPy 1.18.1).
- **Âncoras.** As 15 de conservação conferem bit a bit com a B41. As 12 do guia conferem com os números gravados pela B41
  (Δ_hel = 1,99; η_g = 0,0116).
- **Fidelidade.** V0 é a fração da própria B1 (diferença 0), e a cópia do guia é fiel (diferença 0).
- **Conservação.** A lei de Gauss se mantém (≤ 4×10⁻¹²), e os resíduos da limpeza ficam ≤ 7×10⁻¹⁵.
- **Reavaliação.** Feita fora do Colab, deu resultado idêntico.
- **Convergência.** Com o lançamento limpo, a mediana de ε cai de 8,0×10⁻⁴ (10³) a 2,6×10⁻⁵ (22³).

### 2.14.8 Interpretação

- **[M] Causa identificada.** A fragilidade da preparação do estado de helicidade na B1 e na B41 era do método de
  lançamento, não da física. A onda copiada pelo mapa de de Rham não obedece à lei de Gauss discreta. A parte
  longitudinal parada que resulta, amplificada pelo peso M1² da medida, contamina a fração de helicidade.
- **[M] Malhas mais finas ajudam, mas não resolvem.** Elas reduzem as falhas (15% → 0 em 20) sem remover a causa. O
  lançamento limpo custa um sistema linear do tamanho do número de GMFs e zerou as falhas em todas as malhas novas.
- **[M] O item 9 da B41 é outra coisa:** a retroação fraca em h = 0,46, marginal e independente da limpeza.
- **Recomendação [D, a decidir]:** o lançamento limpo como padrão das próximas bancadas do capítulo.
- **Sem mudança de status:** PHOTON-CLOSURE-F continua NÃO FECHADO; a B1 continua FECHADO e a B41 NÃO REPRODUZIDO.

> **Analogia.** É a hemólise na coleta. O potássio sai alto não porque o paciente tem hipercalemia, mas porque o tubo
> contaminou a amostra. Uma agulha melhor (malha mais fina) hemolisa menos; coletar do jeito certo (lançamento limpo)
> acaba com a contaminação. O exame do paciente, que é a física da onda, estava certo o tempo todo.

---

## Apêndice A — Bancadas e arquivos

**Rastreabilidade histórica.** Os nomes de arquivos e bancadas com prefixo `C5A_` são mantidos deliberadamente. Eles registram a proveniência anterior à adoção do HRF e não devem ser renomeados retroativamente.

| Bancada | Pergunta | Decisão | Arquivos principais |
|---|---|---|---|
| curl-curl emergente (Atualização 20) | laços orientados geram ∇×∇×? | sim [M] | caderno §121 |
| HOL1 | de onde vem o grau das ligações? | PASS condicional: conexão própria [M] | caderno §122 |
| replicação PHOTON-CLOSURE | critérios congelados | não replicada (item 6) | `C5A_photon_closure_replicacao_*_2305-clau` |
| B1 | fóton efetivo fechado? | FECHADO [M] | `C5A_B1_PREREGISTRO_2026-10-01_2350-clau.md`, relatório e pacote `*_0530-clau` |
| G0G | fundo compensado e retroação | retroação fraca pequena [M] | caderno §152 |
| B8 | Lorentz no UV e isotropia | COMPATÍVEL [M] | `C5A_B8_PREREGISTRO_2026-10-02_1153-clau.md`, relatório `*_1200-clau` |
| B3 | birrefringência acumulada | COMPATÍVEL (canal circular) [M] | `C5A_B3_PREREGISTRO_2026-10-02_1545-clau.md`, relatório `*_1558-clau` |
| B10 | quantização; fase de Coulomb | FÓTON QUÂNTICO LIVRE OK; COMPACTA VIÁVEL [M] | `C5A_B10_PREREGISTRO_2026-10-02_1553-clau.md`, relatório `*_1621-clau` |
| B11-luz-luz | autointeração × PVLAS | COMPATÍVEL [M] | `C5A_B11_PREREGISTRO_2026-10-02_1824-clau.md`, relatório `*_1837-clau` |
| B12-faixa | faixa fixa de distâncias | FAIXA NEUTRA; pesos D sem calibração [M] | `C5A_B12_PREREGISTRO_2026-10-02_1907-clau.md`, relatório revisão 1 `*_2015-clau` |
| INVERSE-01/02 (fluxo par) | problema inverso; Morse | teto antigo aposentado; holdout de ħ negativo | consolidação do fluxo par |
| B11-Morse, B12-Morse (fluxo par) | faixa deformável no tempo | gauge preservado; fóton sobrevive [M] | relatórios do fluxo par |
| B14 (fluxo par) | ℓ_max × cauda distribuída | ℓ_max isolado descartado [M]; auditada | `C5A_B14_cauda_distribuicao_2026-10-02.zip` |
| **B41 (bancada mestre, v1.3)** | **o capítulo se reproduz com sementes novas?** | **NÃO REPRODUZIDO pelo veredito pré-registrado (M02, M07); com a correção declarada M07c, só M02 (P1 da B1, 8/10); 61/61 bandas [M]** | `HRF_B41_PROTOCOLO_2026-10-27_2010-clau.md`, `LEIAME_B41.md`, `FUMACA_B41.md`, pacote `HRF_B41_Bancada_Mestre_Cap02_PREREGISTRO_2026-10-27_2010-clau.zip`; `FUMACA_B41_REGISTRO_2026-10-28_0900-clau.md`, `HRF_B41_correcao_M07c_2026-10-28_0900-clau.zip`; `HRF_B41_Relatorio_e_Auditoria_PT_2026-10-28_1430-clau.md`, `LEIAME_B41_resultados.md`, `HRF_B41_RESULTADOS_com_M07c.zip` |
| **B41H (v1.5)** | **por que a preparação do estado de helicidade falha, e afinar a malha resolve?** | **CAUSA_GAUGE_NO_LANCAMENTO: afinar reduz (15% → 0/20); o lançamento limpo elimina (10 → 0) [M]** | `HRF_B41H_PROTOCOLO_2026-10-29_0027-clau.md`, `LEIAME_B41H.md`, `FUMACA_B41H.md`, pacote `HRF_B41H_Helicidade_Preparacao_PREREGISTRO_2026-10-29_0027-clau.zip`; `FUMACA_B41H_REGISTRO_2026-10-29_0055-clau.md`, `HRF_B41H_REGISTRO_EXECUCAO_2026-10-29_0430-clau.md` (+ adendo de 10h04), hashes das correções C01 e C02; `HRF_B41H_Relatorio_e_Auditoria_PT_2026-10-29_1816-clau.md`, `LEIAME_B41H_resultados.md`, `HRF_B41H_RESULTADOS_COMPLETOS_2026-10-29_210503.zip` |

---

## Apêndice B — Números de referência

| Grandeza | Valor | Fonte | B41 (28/10) |
|---|---|---|---|
| ξ (tremor, eixo, 20³) | 0,0163 [0,0161; 0,0164] | B8 | 0,0162 [0,0159; 0,0166] |
| a_ρ,max (tremor, eixo) | 1,6×10⁻²⁷ m | B8 | 1,59×10⁻²⁷ m |
| ξ médio (Poisson … mínimo 0,8a, 20³) | 0,0112 … 0,0056 | B12-faixa | 0,0110 … 0,0059 |
| teto canônico | √ξ·a_ρ ≲ 2,0×10⁻²⁸ m | B8, consolidação | 2,02×10⁻²⁸ m |
| E_QG,2 | > 6,9×10¹¹ GeV | LHAASO (Cao et al. 2024) | entrada |
| ordem de (E² − P²c²)/E² | 1,98 [1,96; 2,00] | B1 | 1,966 [1,945; 1,974] |
| impureza de helicidade (18³) | 1,1×10⁻⁴ (mediana) | B1 | 1,45×10⁻⁴ |
| P1 da B1 (sementes sem falha) | 9/10 | B1 | 8/10 |
| *(v1.5)* falha de preparação por malha, lançamento da B1 | — | B41H | 15% (10³), 7,5% (14³), 2,5% (18³), 0/20 (22³) |
| *(v1.5)* falha de preparação, lançamento limpo | — | B41H | 0 em 140 (IC 95%: 0–2,6%) |
| *(v1.5)* δ_L2 a partir do qual aparecem falhas | — | B41H | ≈ 0,28 (pós-hoc) |
| anisotropia de c (26³) | 1,4×10⁻⁶ | B8 | 1,36×10⁻⁶ |
| giro de polarização (GRB 140206A, teto B8) | ~10⁻¹² rad | B3 | — |
| β_c (Delaunay; cúbica) | 0,64; 1,00 | B10 | 0,62–0,64; 1,00 |
| β_EM = 1/(4πα) | 10,9 | [F] | — |
| Δκ (Poisson 20³); κ∥/κ⊥ | 0,319; 3,00 | B11-luz-luz, B12-faixa | 0,3213; 2,984–3,003 |
| \|Δn_rede\|/Δn_QED no teto | 3×10⁻⁵⁵ | B11-luz-luz | 2,98×10⁻⁵⁵ |
| razão dinâmica medido/previsto (B11) | erro de 3–6% | B11-luz-luz | 1,000 (Poisson 10³, modo a modo) |
| E₀/V | 17,5–18,9 ħc/a⁴ | B10 | 17,3–18,7 ħc/a⁴ |
| constantes | CODATA 2018 | [F] | — |

**Referências externas:** Cao et al. 2024, PRL 133, 071501 (LHAASO, GRB 221009A); Götz et al. 2014, MNRAS 444, 2776
(GRB 140206A); Ejlli et al. 2020, Phys. Rep. 871, 1 (PVLAS); Arnold, Lippert, Neuhaus, Schilling, hep-lat/0011058
(QED compacta na rede); Gao, Jafferis, Wall 2017 (citado no Capítulo 1). *(v1.3, ponte de §2.11:)* Unruh 1981, PRL 46,
1351; Unruh 1995, Phys. Rev. D 51, 2827; Corley e Jacobson 1996, Phys. Rev. D 54, 1568. *(v1.4, §2.8.4:)* Levin e Wen 2005,
Rev. Mod. Phys. 77, 871; Levin e Wen 2006, Phys. Rev. B 73, 035122.

---

## Apêndice C — Glossário do capítulo

| Termo | Significado |
|---|---|
| HRF | Holographic Reconstruction Framework; nome guarda-chuva atual do programa |
| HRF-FM | Fields and Matter Reconstruction; ramo do HRF que herda principalmente a linha histórica C5A |
| HRF-ST | Spacetime Reconstruction; ramo separado para emergência/reconstrução de geometria e espaço-tempo |
| C5A | rótulo histórico preservado em fontes, bancadas e arquivos para rastreabilidade |
| GMF | Grau Microestrutural Fundamental; termo técnico do toy model fotônico herdado da C5A, sem equivalência ainda fixada com PGFE/HRF-PD |
| PGFE | termo reservado à ontologia pré-geométrica do HRF; sua relação formal com GMF ainda permanece aberta neste capítulo |
| q_n | estado local de um GMF |
| a_nm, U_nm = e^{ia_nm} | fase da ligação; conexão relacional entre vizinhos |
| C_f, H_f = e^{iC_f} | circulação e holonomia de um laço |
| energia de Wilson | Σ w_f (1 − cos C_f) |
| d₀, d₁ | gradiente e rotacional discretos (d₁d₀ = 0) |
| pesos W, D | Whitney; duais baricêntricos |
| a_ρ | escala de densidade, (V/N)^{1/3} |
| r_nm, P(r), r_tail | distância local, sua distribuição e a cauda superior |
| Δx_num | passo numérico, sem significado físico |
| ξ | coeficiente da correção quadrática ω/ck = 1 − ξ(ka_ρ)² |
| κ∥, κ⊥ | razão quártico/quadrático para sonda paralela e perpendicular a B₀ |
| β, β_c | acoplamento da rede compacta; valor da transição |
| fase de Coulomb | fase da conexão compacta em que existe fóton livre |
| 𝒜* | ação característica do substrato (hipótese) |
| helicidade h | projeção do spin na direção de propagação |
| OAM, ℓ | momento angular orbital |
| PHOTON-CLOSURE-E/F | fechamento do fóton efetivo / físico |
| D1, D2, D3 | espaço-tempo plano no setor do fóton; conexão compacta?; faixa de distâncias fixa no tempo |
| microgeometria (uso histórico C5A) | conectividade/deformação da malha usada nos toy models; não equivale à geometria emergente do HRF-ST |
| *(v1.3)* B41, bancada mestre | replicação pré-registrada dos resultados principais deste capítulo, em módulos M00–M10 |
| *(v1.3)* âncora de determinismo (M00) | rodada com a semente original da B1a, que deve dar o mesmo resultado bit a bit |
| *(v1.3)* bandas numéricas | intervalos fixados no pré-registro da B41 para cada número de referência; não confundir com a faixa de distâncias (D3) |
| *(v1.3)* fumaça | rodada curta, em tamanhos reduzidos, para testar o encadeamento; números descartados |
| *(v1.3)* P1 | critério de robustez da B1: pelo menos 9 de 10 sementes passando em todos os itens internos |
| *(v1.3)* M07c | correção declarada da validação dinâmica da B11-luz-luz na B41: comparação modo a modo, com auto e mútua modulação de fase |
| *(v1.3)* automodulação / modulação mútua de fase | mudança de frequência de um modo causada pela sua própria amplitude / pela amplitude dos outros modos, via o termo quártico |
| *(v1.5)* carga espúria | divergência discreta (d0ᵀ M1 v₀ ≠ 0) que a onda copiada do contínuo leva para a malha; gera uma parte longitudinal parada no momento |
| *(v1.5)* lançamento limpo | lançar com v₀ − d0 λ, que obedece à lei de Gauss discreta sem carga (B41H: variante V1) |
| *(v1.5)* δ_L2 | peso da parte longitudinal parada: \|π_L\| / \|π₀\| |
| *(v1.5)* V0, V1, M1, M1T | medida da B1 (métrica M1²); a mesma com o lançamento limpo; métrica M1; métrica M1 com o lançamento limpo |
