# Capítulo 0.1 — Diretrizes de Reconstrução Unificadora Progressiva

**Framework:** Holographic Reconstruction Framework (HRF)  
**Programa:** *Holographic Reconstruction of Physics*  
**Versão:** v0.2  
**Data:** 9 de outubro de 2026  
**Atualização:** integração das diretrizes para novas bancadas boundary 2D–Delaunay–Voronoi–GMF, com pré-registro de testes e preservação do Capítulo 0.1 v0.1  
**Posição no livro:** Research Book — Capítulo 0.1 (fundamentos metodológicos)  
**Tipo:** diretriz metodológica transversal / capítulo de orientação do Projeto  
**Estatuto:** [D] orientação estratégica aprovada pelo pesquisador; não é resultado de validação física.

## 0.1.1 — Decisão estratégica central

**[D] Começar pela opção B para investigar progressivamente a opção A.**

- **B — arquitetura integradora:** reunir partes relevantes da física estabelecida, preservar seus domínios de validade, estabelecer interfaces matemáticas e identificar as lacunas reais.
- **A — reconstrução a partir de fundamento comum:** investigar se essas partes podem ser derivadas, em regimes e limites apropriados, de uma estrutura física mais geral, eventualmente pré-geométrica.
- **Trajetória B → A:** a integração é o método de trabalho imediato; a unidade fundamental é uma meta de pesquisa, **não uma premissa demonstrada nem um destino garantido**.

Nome de trabalho para essa estratégia: **Reconstrução Unificadora Progressiva (RUP)**. RUP designa uma metodologia de pesquisa **dentro do HRF**, não uma renomeação do framework nem uma teoria física adicional.

## 0.1.2 — Princípio de integração física

> O HRF deve preservar e reutilizar resultados estabelecidos da física sempre que forem matematicamente compatíveis. Sua investigação original deve concentrar-se nas interfaces não demonstradas, nos mecanismos ausentes e na reconstrução coerente de uma descrição física integrada.

**[D] Não exigir originalidade de cada componente.** Um resultado que possui explicação satisfatória na física existente pode ser incorporado e referenciado, desde que suas hipóteses e limites sejam respeitados. A eventual contribuição própria do HRF pode residir nas correspondências, derivações comuns, mecanismos de conexão e previsões da arquitetura integrada.

**[D] Não confundir justaposição com unificação.** Usar equações de duas teorias lado a lado não demonstra que derivem de um mesmo sistema físico. A interface deve estabelecer o mapa relevante de estados, observáveis, simetrias, dinâmica e condições de validade.

## 0.1.3 — Regras práticas permanentes

1. **Consultar a documentação do HRF antes de reconstruir o modelo.** Priorizar os arquivos anexados ao Projeto; recorrer à biblioteca HRF no Google Drive se necessário e à literatura externa quando o problema exigir.
2. **Reaproveitar a física conhecida.** Não gastar recursos tentando redescobrir leis já estabelecidas; verificar, sim, sua aplicação à bancada específica.
3. **Separar componentes e interfaces.** Para cada ligação entre modelos, registrar entrada, saída, hipóteses, espaço de estados, operadores, observáveis, simetrias, leis de conservação e limites.
4. **Localizar exatamente o mecanismo faltante.** Uma lacuna não deve ser preenchida por vocabulário (“holografia”, “emergência”, “confinamento”) sem equações.
5. **Buscar reduções controladas.** Quando duas descrições compartilham um setor, tentar construir equivalência, limite efetivo ou mapeamento parcial; não exigir identidade total sem fundamento.
6. **Executar primeiro análises econômicas.** Preferir provas analíticas, análise dimensional, correspondência espectral, reprocessamento arquivado e controles pequenos antes de grandes simulações.
7. **Testar principalmente as costuras.** Os testes novos devem avaliar se a interface preserva propriedades e produz consequências não inseridas por definição.
8. **Preservar falhas e alternativas.** Resultados negativos, aproximações insuficientes e interfaces incompatíveis devem permanecer no registro.
9. **Não impor teleologia.** Se não houver redução a uma base única, manter uma arquitetura efetiva integradora, sem declarar a meta fundamental alcançada.
10. **Consolidar proveniência.** Registrar versões de documentos, protocolos, códigos, parâmetros e distinção entre decisões históricas e correntes.

## 0.1.4 — Classificação epistemológica HRF

- **[F]** resultado físico ou matemático estabelecido, com domínio de validade explicitado;
- **[M]** resultado de modelo matemático, cálculo ou simulação do HRF;
- **[H]** hipótese de conexão ou mecanismo ainda não demonstrado;
- **[?]** questão aberta, incluindo robustez ou incompatibilidade não resolvida;
- **[D]** decisão metodológica ou editorial.

Regras: **[M] não implica evidência empírica; aproximação formal não implica identidade física; imagem reconstruída não implica partícula; êxito numérico de uma peça não valida sua conexão com as demais.**

## 0.1.5 — Critérios mínimos para aceitar uma “costura”

Para ligar dois setores teóricos, documentar, quando aplicável:

| Critério | Pergunta de auditoria |
|---|---|
| Graus de liberdade | O que existe em cada descrição? Quais são físicos, redundantes ou efetivos? |
| Espaços de estados | Há mapa entre estados clássicos/quânticos? É invertível, aproximado ou restrito? |
| Dinâmica | Hamiltonianos/ações/equações correspondem em que limite? |
| Simetrias e gauge | Quais invariâncias e restrições são preservadas? |
| Observáveis | Energias, correlações, entropias e fluxos têm definições comparáveis? |
| Conservação e causalidade | O mapa respeita os balanços, limites causais e condições de contorno? |
| Escalas e parâmetros | Há constantes, cortes, regularizadores ou dados ajustados ad hoc? |
| Quantização | A equivalência clássica sobrevive ao nível quântico? |
| Testabilidade | Que resultado separaria a conexão proposta de uma simples analogia? |
| Proveniência | Quais arquivos, versões e execuções sustentam cada afirmação? |

Uma interface pode receber estatuto de **correspondência parcial** sem ser promovida a equivalência integral. Se alguma propriedade ainda não foi estudada, registrar **PENDING/NOT_TESTED**, não PASS.

## 0.1.6 — Aplicação imediata aos programas atuais

### 6.1 CAP2 — modo fotônico relacional

**[M]** O Capítulo 2 documenta um setor relacional de conexões orientadas \(U_{nm}=e^{ia_{nm}}\), laços, gauge e operador discreto *curl–curl*, com resultados de bancada no domínio indicado pelos relatórios. **[?]** Sua correspondência integral com implementações posteriores e a recuperação física completa devem ser avaliadas por gates próprios.

### 6.2 E-67 — excitação gaussiana e reconstrução operacional

**[M]** O E-67 registra respostas entrópicas de um estado gaussiano apertado em campo escalar Z, com classificações históricas H67 = SIM — regime não linear, H67-N = NORMALIZÁVEL e H67-Z = PROPORCIONAL, estritamente segundo critérios operacionais; VL falhou em \(w=7\), fecho dessa largura não foi medido e não houve evolução temporal nem refinamento espacial.

**[D]** Explicações convencionais de teoria gaussiana, entropia e escala podem ser incorporadas. Não é obrigatório demonstrar novidade física em cada característica do E-67. Entretanto, para reivindicar *bulk* físico, modo material ou partícula, continuam necessárias as definições e validações independentes correspondentes.

**[H] Ponte prioritária:** testar matematicamente se o campo Z corresponde ao setor livre fora do plano \(A_z\) de uma conexão tridimensional U(1) reduzida a 2D, preservando estrutura canônica, operador, energia, gauge residual, espectro e álgebra de observáveis. Uma equivalência perturbativa parcial não deve ser confundida com equivalência completa, especialmente em setores globais ou compactos.

### 6.3 CAP3 — confinamento dinâmico

**[M]** As bancadas clássicas intermediárias demonstraram aspectos de propagação e transporte, mas não certificaram confinamento fotônico dinâmico completo; a bancada Yee 2D3V apresentou falha de convergência espacial da cavidade e não executou a fase longa. **[D]** Resolver convergência e gate CAP2 antes de atribuir identidade fotônica ao campo confinado.

**[?]** Confinamento de energia clássica não implica alteração entrópica, partícula quântica ou normalizabilidade holográfica. A ligação posterior requer Hamiltoniano quantizado, estados, covariâncias (ou métodos não gaussianos), observáveis e regras de reconstrução justificadas.

### 6.4 Meta maior de matéria e espaço-tempo

**[H]** Investigar se uma arquitetura relacional comum pode recuperar, em limites apropriados, campos, geometria, ondas, estados ligados e matéria. **[?]** Ainda não estão derivados do mesmo mecanismo carga eletrônica, spin 1/2, estatística fermiônica, massa do elétron, gravitação emergente ou uma dualidade holográfica física geral. Esses itens não devem ser inferidos a partir de formas visuais no bulk.

## 0.1.7 — Priorização e economia científica

Prioridade padrão:

1. **Auditoria documental e matemática da interface.**
2. **Reanálise dos dados existentes e prova em modelos mínimos.**
3. **Testes pequenos de correspondência entre operadores e observáveis.**
4. **Controles adversariais, refinamento e convergência.**
5. **Simulações extensas de dinâmica acoplada, somente após gates anteriores.**

A prioridade imediata sugerida para o ciclo E-67/CAP2/CAP3 é a **derivação de correspondência Z ↔ A_z**, como investigação analítica de interface. O controle adversarial gaussiano E67-68 continua disponível para testar interpretações holográficas fortes, mas não é condição para aproveitar os resultados matemáticos conhecidos do E-67 como ferramenta descritiva.

## 0.1.8 — Como avaliar progresso em direção à opção A

Uma integração B aproxima o HRF da reconstrução A somente quando **reduz pressupostos independentes** ou **deriva relações antes introduzidas separadamente**, mantendo ou ampliando o poder explicativo.

Indicadores de progresso:

- mapa explícito de equivalência ou redução entre setores antes distintos;
- parâmetros que deixam de ser escolhidos independentemente e passam a ser derivados;
- simetrias ou leis de conservação recuperadas da formulação mais geral;
- observáveis quantitativos reproduzidos sem ajuste posterior específico para cada caso;
- previsões e limites de validade verificáveis;
- identificação inequívoca dos problemas ainda não resolvidos.

A redução ontológica a uma realidade fundamental única é **objetivo de longo prazo [H]**, não critério para declarar sucesso de toda bancada intermediária.

## 0.1.9 — Orientação para pesquisadores e chats do Projeto

Ao iniciar uma nova análise HRF:

**Leitura obrigatória:** consultar efetivamente o conteúdo integral da versão corrente deste Capítulo 0.1 antes de qualquer nova análise, pesquisa, simulação, revisão ou elaboração documental. Não basta reconhecer seu título. A seção 0.1.12 em diante orienta as novas bancadas boundary 2D; o protocolo especializado permanece a fonte de detalhe.

1. Identificar a pergunta e o setor do projeto.
2. Consultar primeiro os documentos pertinentes anexados diretamente ao Projeto e usar o esqueleto como mapa estrutural.
3. Recuperar a fonte especializada ou o Drive apenas se necessário.
4. Declarar quais leis já conhecidas podem ser incorporadas e quais conexões permanecem hipóteses.
5. Propor primeiramente a menor derivação ou experimento capaz de testar a **interface** desejada.
6. Reportar resultados positivos, negativos, não medidos e não executados com a classificação [F]/[M]/[H]/[?]/[D].
7. Não apresentar analogias, nomenclaturas ou diagramas como derivação física.
8. Manter o nome atual **Holographic Reconstruction Framework (HRF)**. Conservar PRFE, C1–C5, C5A/C5B e PGFE apenas para documentação histórica e proveniência quando pertinente; na formulação corrente usar **sistema físico / subsistema físico**, sem introduzir PGFE como ente fundamental.

## 0.1.10 — Síntese da diretriz

> **Começar com B e trabalhar em direção a A.** Integrar de maneira rigorosa as ferramentas da física conhecida; demonstrar as interfaces; acrescentar apenas os mecanismos necessários; investigar se a integração pode ser progressivamente reconstruída a partir de fundamentos comuns, sem presumir antecipadamente que essa redução seja possível ou única.

**Esta diretriz orienta o programa; não altera retroativamente os relatórios históricos nem transforma hipóteses em resultados.**

## 0.1.11 — Referências documentais internas

- `HRF_Esqueleto_Research_Book_v0_1_PT.md` — estrutura geral, classes epistemológicas, objetivos e proveniência.
- `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_1_PT_2026-10-05.md` — estrutura do modo fotônico relacional (versão histórica consultada na elaboração v0.1; confrontar com v1.2 quando disponível).
- `RELATORIO_E67_FINAL_v0_2.md` — resultados históricos do E-67.
- `RELATORIO_AUDITORIA_POST_E67_v0_1.md` — reprodução do pós-processamento e limites de auditoria.
- `RELATORIO_CIENTIFICO_CAP2_v0_2.md` — resultados e falhas da bancada Yee 2D3V.

**Nota de proveniência:** as diretrizes das seções 1–3, 5, 7–10 são consolidação metodológica da decisão do pesquisador no diálogo originário. Não são apresentadas como extraídas de experimentos. A revisão v0.2 preserva essas seções, registra adaptações pontuais na seção 0.1.9 e acrescenta um bloco metodológico explícito para as novas bancadas; não reclassifica experimentos históricos.


---

## 0.1.12 — Diretriz adicional permanente: boundary 2D, Delaunay, GMFs e área inter-GMF

**Origem documental:** `HRF_Orientacao_Novas_Bancadas_Boundary_2D_Delaunay_GMF_ZigueZague_v0_1_PT_2026-10-09.md`, documento de **protocolo e pré-registro**, não relatório de execução. Esta seção consolida seu conteúdo normativo; **a orientação especializada deve ser consultada integralmente para executar as bancadas**.

**[D] Configuração de referência das próximas bancadas geométricas HRF-FM:** uma fatia **espacial bidimensional da boundary** com métrica inicialmente especificada; malha primal **Delaunay irregular**, dual **Voronoi**, e graus microestruturais designados **GMF** nos vértices. A malha é um **regulador/modelo geométrico**, não evidência de uma teoria quântica holográfica por si mesma. A referência AdS₄/CFT₃ corresponde a boundary **2+1** e bulk **3+1** (dimensões espaciais + tempo), em regimes adequados [F].

| Objeto / símbolo | Significado operacional na bancada | Limite interpretativo obrigatório |
|---|---|---|
| `GMF_i` | Vértice `i` da triangulação de Delaunay no HRF-FM | Rótulo operativo histórico; **não** postula novo ente ontológico fundamental. A linguagem geral corrente segue sendo **sistema físico/subsistema físico**. |
| `e_ij` | Aresta orientada entre GMFs vizinhos, possível suporte para conexão e fluxo | Não é automaticamente trajetória de um fóton. |
| `T_ijk` | Face triangular de Delaunay formada por três vértices | Não é célula de Voronoi e nem quantum físico. |
| `A_ijk = Área(T_ijk)` | Área inter-GMF, clássica na métrica de fundo 2D escolhida | Não é «quântum de área», nem área RT/HRT do bulk; quantização exigiria operador, espectro e estados. |
| `V_i` | Célula poligonal da tesselação dual de Voronoi | Sua área não deve ser trocada pela área dos triângulos de Delaunay. |

Notação inicial permitida: `G_D=(V,E,F)`, comprimentos `ℓ_ij`, conexão candidata `U_ij=exp(i a_ij)` com `a_ji=-a_ij`, e circulação `C_ijk=a_ij+a_jk+a_ki`. Esses símbolos não substituem a especificação de variáveis canônicas, ação/Hamiltoniano, gauge, contornos e observáveis no protocolo executado.

**[D] Não promover uma escolha de discretização à ontologia.** O projeto pode futuramente investigar a origem da métrica da boundary (opção A), mas inicialmente a toma como entrada controlada (opção B). Delaunay/Voronoi não são impostos pela AdS/CFT, tampouco constituem redes de spin da LQG por analogia.

## 0.1.13 — Três mapas separados e uma hipótese de transporte

Cada novo estudo deve indicar explicitamente qual pergunta resolve:

1. **G — geometria/holografia:** reconstrução do bulk a partir de estados quânticos, álgebra de regiões `R`/`R̄`, `W[R]`, correladores, entropias e dicionário apropriado da boundary. RT/HRT relaciona entropia da boundary à área de superfícies extremas **no bulk**, não diretamente às faces de Delaunay da boundary.
2. **W — dinâmica da onda/excitação:** evolução local de amplitudes, energia, fase, polarização e fluxo por acoplamentos entre vizinhos em modelo definido da boundary (ou, separadamente, do bulk). **W não reconstrói por definição a dimensão espacial adicional.**
3. **D — dicionário boundary ↔ bulk:** mapa controlado de estados, operadores e observáveis de excitação/campo entre as duas descrições. **D permanece [?] até ser construído e testado**, mesmo se G ou W funcionarem isoladamente.

**[H] Hipótese específica do zigue-zague:** investigar se o transporte energético na rede irregular exibe uma sequência local mensurável de arestas com mudanças de direção. **Não impor** um caminho individual à solução. Separar quatro significados: (a) geometria da rede, (b) sequência de transferência local, (c) fluxo calculado de energia e (d) trajetória macroscópica do centro de energia. Um caminho `P=(i₀,...,iₘ)` escolhido para desenhar a onda não é, sem procedimento físico de extração, um observável de trajetória.

**[D] «Saca-rolha» do Capítulo 2** = rotação da polarização de um campo circularmente polarizado, cujo fluxo médio pode ser retilíneo. **[H]** Uma hélice da trajetória do centro do pacote é afirmação distinta, exigindo demonstração. Em particular, **zigue-zague 2D ≠ hélice 3D** por mera analogia visual. A separação G/W/D não impede *backreaction* quando um modelo físico a descreve.

## 0.1.14 — Contrato sequencial para novas bancadas HRF-FM

**[D] Sequência padrão de custos crescentes e dependências.** Todos os itens abaixo são **propostas de teste, não resultados obtidos**. Cada fase deve gerar pacote reproduzível, critérios pré-registrados e decisão PASS/FAIL/PENDING/NOT_EXECUTED.

| Etapa / identificador | Pergunta e ensaio mínimo | Dependência e gate principal |
|---|---|---|
| **B0 — BOUNDARY-GEOMETRY-2D-01** | Construir mesmo conjunto de geradores em Delaunay + Voronoi; comparar malhas regular, perturbada e Poisson/irregular; medir incidências, qualidade, áreas, dualidade, fronteiras, degenerescências e refinamento. | Entrada para W. Exigir área positiva, balanço de área, topologia consistente, seeds e hashes reprodutíveis; entregar `d₀/d₁`, tabelas primal/dual e scripts. |
| **B1 — BOUNDARY-WAVE-EDGE-01** | Injetar perturbação inicialmente **energética/ondulatória**, sem presumir fóton; medir energia por suporte, fluxos por cortes, frente, fase, dispersão, `R_E(t)`, anisotropia, reflexões e vazamentos. | B0 aprovado; conservação/contornos, causalidade/localidade, estabilidade e refinamento, com controles de direção, escala e integrador. |
| **B2 — BOUNDARY-ZIGZAG-01** | Comparar trilha desenhada, caminho extraído *a posteriori* do fluxo e campo distribuído; testar `L_P`, `D`, `τ=L_P/D` para `D>0`, ângulos, dispersão e fluxo transversal. | B1; variar orientação, seed e refinamento. Se zigue-zague desaparecer como observável convergente, reportar artefato da representação; quando não há caminho único, não inventar `τ`. |
| **B3 — BOUNDARY-EM-2D3V-01** | Verificar contrato Maxwell em **duas realizações separadas**: Yee 2D3V e Delaunay–Voronoi/Whitney 2D3V; inicialmente congelar a geometria, liberando T1 só após gates próprios. | B0/B1 e controles Yee independentes; Gauss/gauge, relações de dispersão, duas polarizações/helicidades ±1, energia, fluxo, orientações e convergência. Um PASS Yee **não transfere** PASS à malha Delaunay. |
| **B4 — BOUNDARY-FOAM-RESPONSE-01** | Medir resposta da espuma móvel, T1, cavitação, memória e segunda onda, distinguindo efeitos do campo e da mecânica. | B3 e dinâmica T1 auditada; controles pareados: espuma sem nova onda, perturbação mecânica sem EM e pulso EM; balanço energético antes/depois de mudanças de conectividade. |
| **B5 — HOLOGRAPHIC-INTERFACE-2D3D-01** | Construir separadamente **G** e o dicionário **D** a partir de um exemplo quântico holográfico específico; avaliar regiões, `W[R]`, entropias, superfícies RT/HRT no domínio admissível e operadores/campos no bulk. | Pré-condição independente: teoria de boundary, classe de estados, álgebra, dicionário e benchmarks explícitos. A execução/êxito B0–B4 **não valida automaticamente B5**. |

**Prioridade inicial recomendada [D]:** `HRF-BOUNDARY-GEOMETRY-WAVE-01`, integrando B0 + piloto B1 + diagnóstico B2, sem reivindicar previamente Maxwell, holografia ou matéria. Em seguida, `HRF-BOUNDARY-EM-2D3V-01`; depois `HRF-BOUNDARY-FOAM-TRIGGER-CAPTURE-01`. Em **frente separada**, `HRF-HOLOGRAPHIC-B2B-01`, somente com modelo holográfico previamente escolhido. A tabela é roteiro revisável por decisão explícita, não sequência de resultados pré-determinados.

## 0.1.15 — Pré-registro, gates e controles obrigatórios

Cada bancada deverá especificar **antes de observar o resultado**:

- **Malha/geometria:** dimensão, domínio, métrica de fundo, `N`, coordenadas/seeds, famílias regular/irregular, primal e dual, orientação, incidências, qualidade, contornos, degenerescências, T1 quando houver, e refinamento.
- **Setor dinâmico:** variável escalar auxiliar, conexão nas arestas `a_∥`, componente reduzida `A_z`, 2D3V, graus mecânicos `X_i/P_i` ou outro — **não misturá-los** sob a mesma etiqueta. Em 2D3V, `A_z` é **componente vetorial fora do plano**, não coordenada radial do bulk; o setor mecânico não é terceira polarização do fóton.
- **Ondas e custos físicos:** pacote/estado inicial, amplitudes, direção, `k`, `ω`, banda, helicidade, condições de injeção, energias clássicas totais, unidades, integrador/`dt`, estabilidade/CFL, fronteiras e janela de medidas. `E=ℏω` não determina a energia total de um pacote clássico nem seu número de fótons.
- **Medições/gates:** conservação e fluxos por setor e entre setores, Gauss/gauge, espectro, polarização/helicidade, velocidade de grupo, isotropia, dispersão, tortuosidade **somente quando definida**, capturas e duração, erro, comparações com Yee, tamanho de domínio, seeds, orientações e convergência `dx/dt`.
- **Controles adversariais:** sem injeção; direção reversa; rotação/refinamento da malha; espuma sem onda; perturbação apenas mecânica; pulso EM; campo remanescente vs ausência de nova injeção; histórico de T1 e balanço energético em reconexões.
- **Registro reproduzível:** nome e versão de protocolo/código, commit e hash quando possível, parâmetros, seeds, arquivos brutos, script de pós-processamento, critérios numéricos fixados previamente, `PASS/FAIL/PENDING/NOT_EXECUTED` e discussão de limites. **Não calibrar o limiar após ver a resposta.**

**Prioridade epistêmica:** um campo se propagar e confinar classicamente não prova fóton quântico, partícula, elétron, massa de repouso, carga, spin 1/2 ou reconstrução holográfica. O zigue-zague pode ser efeito de malha. A área geométrica 2D é clássica. Uma cavidade que surge sem nova onda não deve ser tratada como erro por definição; é necessário separar instabilidade autônoma, campo residual e impulso novo. Identidade, causalidade e balanço energético exigem evidência própria.

## 0.1.16 — Separação dos três contextos dimensionais e proveniência

**[D] Nenhuma reclassificação retroativa:**

1. **Capítulo 2 histórico HRF-FM (3D):** malhas 3D, incluindo tetraedros de Delaunay, com estudo de ondas, gauge e helicidades segundo protocolos originais. **Não é**, por isso, uma simulação de boundary CFT.
2. **Bancadas Maxwell 2D3V:** dependência espacial 2D, com três componentes vetoriais, como redução computacional de propagação. O controle **Yee livre PASS** e o gate livre **Delaunay–Whitney FAIL** pertencem às respectivas implementações e critérios; a cavidade Delaunay correspondente permaneceu sem execução no registro consultado. Esses qualificadores não são transferíveis entre códigos.
3. **Programa holográfico boundary 2D → bulk 3D:** relação física ainda **[H/?]**, que requer estado quântico, álgebra, observáveis e dicionário. Não identificar uma coordenada técnica do solver 2D3V com dimensão extra holográfica.

Registros anteriores como E-61 (propagação após T1 com balanço energético ainda incompleto) e E-63 (cavitação metaestável sem captura circulante demonstrada) devem ser consultados nos relatórios originais para avaliação específica. Nenhuma hipótese de zigue-zague ou resposta da espuma altera retroativamente tais classificações.

**[D] Organização editorial:** Capítulo 1 — problema holográfico e reconstrução de sistema físico; Capítulo 2 — onda fotônica e história 3D/2D3V; Capítulo 3 — microestrutura dinâmica (GMFs, Delaunay/Voronoi, T1); Capítulo 4 — estados ligados; Capítulo 5 — elétron. Este Capítulo 0.1 determina o método e os requisitos comuns, **não substitui** os protocolos e capítulos especializados.

## 0.1.17 — Procedimento obrigatório para chats e agentes novos

Antes de começar uma nova bancada ou formular conclusões, cada chat/agente deverá:

1. **Ler realmente este Capítulo 0.1 v0.2** (ou a versão posterior expressamente adotada), preservando sua RUP B → A e classificação epistemológica.
2. **Consultar a fonte especializada** `HRF_Orientacao_Novas_Bancadas_Boundary_2D_Delaunay_GMF_ZigueZague_v0_1_PT_2026-10-09.md` quando o trabalho envolver boundary 2D, propagação entre GMFs, zigue-zague, espuma ou holografia boundary→bulk; se ela não estiver acessível, dizer isso, sem presumir detalhes.
3. Respeitar a ordem de fontes: **arquivos do Projeto → Google Drive HRF apenas quando necessário → literatura externa quando necessária**. Para B3–B5, priorizar também documentos de controle 2D3V, registros E-61/E-63 e capítulos especializados; não alegar leitura de documentos não consultados.
4. Declarar **qual mapa (G, W ou D)** está sendo investigado, qual realização do solver é usada, quais gates anteriores estão aprovados e quais são PENDING/FAIL/NOT_EXECUTED.
5. Propor primeiro a **menor análise ou teste falsificável**, registrar critérios e controles antes da execução, e preservar todos os resultados, incluindo negativos e não executados.
6. **Nunca** converter um resultado geométrico/numérico em afirmação ontológica ou holográfica sem derivação e teste da interface. Manter nomenclatura histórica em sua origem e **sistema físico/subsistema físico** como vocabulário corrente do HRF.

### Fontes complementares e histórico de revisão

- **Referência incorporada nesta versão:** `HRF_Orientacao_Novas_Bancadas_Boundary_2D_Delaunay_GMF_ZigueZague_v0_1_PT_2026-10-09.md` — pré-registro B0–B5; consulta integral para parâmetros, critérios detalhados e texto de continuidade de bancada. Versão no Drive: https://drive.google.com/file/d/12qpZUwai8ZNC83T1Vj19JXmFsrZr2Dv-/view
- `HRF_Nota_Arquitetura_Boundary_2D_GMF_Bulk_3D_e_Propagacao_Fotonica_v0_1_PT_2026-10-09.md` — alinhamento conceitual dimensional; arquivo do Projeto.
- `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_2_PT_2026-10-09.md` — adendo com controles 2D3V, consultar para estado corrente quando acessível.
- `HRF_Diretriz_Permanente_Modelos_Fotonicos_2D3V_e_Duas_Malhas_v0_1_PT_2026-10-09.md` — duas realizações Maxwell e seus gates, quando acessível.
- `HRF_ELETRON_61_RELATORIO_2026-10-08_1040-clau.md` e `HRF_ELETRON_63_RELATORIO_2026-10-08_1350-clau.md` — proveniência de T1/cavitação, não substituída por este método.

**Controle de versões:** a versão 0.1 (08/10/2026) permanece arquivo histórico. Esta **v0.2 (09/10/2026)** acrescenta 0.1.12–0.1.17 e explicita a leitura obrigatória na seção 0.1.9; conserva as decisões e os limites já documentados. **Nenhuma nova bancada, simulação ou prova física foi executada para esta atualização editorial.**
