# CODEX — HRF-POL-GEOMETRY-01
## Bancada comparativa de polarização helicoidal em cinco geometrias tridimensionais

### 1. Objetivo

Criar e executar uma nova bancada do Holographic Reconstruction Framework (HRF), utilizando a dinâmica relacional da B41L e os métodos de medição da HRF-POL-B41L-01.

**Pergunta central:** a geometria da rede influencia a propagação, a pureza de helicidade e a conservação da polarização de uma onda inicialmente helicoidal?

Investigar cinco distribuições:

1. **Cúbica regular** — controle periódico.
2. **Poisson-disk / blue-noise** — distribuição irregular com separação mínima.
3. **Delaunay irregular genérica** — pontos aleatórios Poisson com tetraedrização Delaunay.
4. **Tetraédrica desordenada, tipo água** — ordem local aproximadamente tetraédrica, sem periodicidade cristalina.
5. **Tetraédrica regular, tipo gelo** — ordem tetraédrica periódica, com somente seis casos iniciais.

O objetivo é investigar a dependência geométrica e diagnosticar as falhas da bancada anterior, não demonstrar ontologia fundamental.

### 2. Limitação de acesso e arquivos

Você NÃO tem acesso ao Google Drive nem aos arquivos anexados ao Projeto HRF no ChatGPT.

Procure exclusivamente os arquivos realmente disponíveis no seu ambiente local ou enviados pelo usuário.

Fontes prioritárias:

- Pacote original da B41L, incluindo `originais/`, `src/`, operadores, malhas e integradores.
- Código da HRF-POL-B41L-01, incluindo extrator de Stokes, configurações e critérios congelados.
- Relatório e avaliação original da POL-B41L-01, quando disponíveis.
- Capítulo 0.1 v0.2 e Capítulo 2 v1.5, caso estejam anexados localmente.

Antes de começar, inventarie os arquivos e registre seus hashes. Leia integralmente o Capítulo 0.1 v0.2 quando disponível. Se faltar, registre essa lacuna documental, respeitando as instruções metodológicas expressas neste prompt.

**Não invente código, resultados ou conteúdo de arquivos ausentes.**

Se faltar o solver original, prepare os geradores geométricos e controles independentes, mas classifique a execução relacional como `NOT_EXECUTED`. Não substitua silenciosamente a B41L por Maxwell, por Jones ou por um novo solver.

### 3. Condição inicial obrigatória — onda helicoidal

**Todas as execuções físicas principais devem começar com uma onda circularmente polarizada, em forma de saca-rolha.**

Reutilize a construção original da B1/B41L.

Para um vetor de propagação k e uma base ortonormal transversal e1, e2, a referência para o lançamento é:

\[
Q_s=C.\mathrm{onda\_aresta}(k,e_1-is e_2),
\quad s=\pm1.
\]

Na formulação histórica da B41L, o lançamento utiliza:

\[
q(0)=\operatorname{Re}Q_s,\qquad
v(0)=|k|\operatorname{Im}Q_s.
\]

Verifique a implementação efetiva, as unidades e a convenção temporal antes de utilizá-las.

A designação física de helicidade positiva ou negativa deve considerar o sentido de propagação e a orientação da base. Não confundir automaticamente o parâmetro histórico `s` com a helicidade física.

**Aplicar a limpeza V1 da B41L**, removendo a componente longitudinal espúria da velocidade ou do momento canônico, conforme o setor do modelo.

Registrar o estado V0 como controle pareado quando viável.

Não reconstruir a hélice artificialmente durante a evolução. A rotação do campo deve resultar da dinâmica calculada.

Não impor uma trajetória helicoidal ao centro de energia. Se surgir movimento espacial em espiral, medi-lo separadamente, sem confundi-lo com polarização circular.

### 4. As cinco geometrias

Cada geometria deve ter uma definição matemática reprodutível, parâmetros, sementes, estatísticas de vizinhança e condições de contorno.

**G1 — Cúbica regular**

Rede periódica uniforme. Usar como controle de simetria e de modos espectrais.

**G2 — Poisson-disk**

Pontos irregulares com distância mínima controlada, sem aglomerações arbitrariamente próximas.

**G3 — Poisson / Delaunay irregular**

Processo pontual Poisson tridimensional com tetraedrização de Delaunay. Registrar degenerescências e qualidade dos tetraedros.

**G4 — Tetraédrica desordenada, tipo água**

Construir uma distribuição com correlações locais tetraédricas e ausência de ordem cristalina de longo alcance. Registrar função radial de distribuição, distribuição angular, coordenação e parâmetro de ordem tetraédrica.

Não chamar essa configuração de água molecular realista se não houver modelo molecular validado.

**G5 — Tetraédrica regular, tipo gelo**

Usar como controle uma rede idealizada de coordenação tetraédrica periódica, por exemplo uma estrutura tipo gelo cúbico Ic ou rede diamond-like, desde que a construção seja documentada.

A ordem tetraédrica entre quatro vizinhos não é sinônimo de preencher o espaço com tetraedros regulares. A tetraedrização Delaunay do conjunto poderá introduzir outras arestas. Registrar separadamente a rede de vizinhança original e a conectividade utilizada pelo solver.

Usar apenas seis casos iniciais para G5.

### 5. Comparabilidade

Preservar, sempre que matematicamente possível:

- O mesmo volume físico e densidade média de pontos.
- O mesmo vetor de onda e comprimento de onda em relação à escala de densidade.
- A mesma amplitude e energia inicial normalizada.
- O mesmo integrador e critérios de estabilidade.
- As mesmas janelas de observação.
- As mesmas condições de contorno.
- Os mesmos observáveis físicos e tolerâncias.

Não equiparar automaticamente o número de pontos à resolução efetiva, especialmente entre malhas com geometrias diferentes.

Exigir verificação de conservação, estabilidade e qualidade dos operadores em cada família.

### 6. Plano inicial econômico

Executar primeiro uma fumaça pequena, cujos resultados não contarão para o veredito principal.

Depois, se os testes de integridade passarem:

| Família | Tamanhos | Casos |
|---|---|---|
| G1 cúbica | 2 | 4 |
| G2 Poisson-disk | 2 | 8 |
| G3 Poisson/Delaunay | 2 | 8 |
| G4 tetraédrica desordenada | 2 | 8 |
| G5 tetraédrica regular | 2 | 6 |
| **Total inicial** | | **34** |

Para G1: duas helicidades por tamanho.

Para G2–G4: duas helicidades, duas realizações independentes e dois tamanhos.

Para G5: por tamanho, testar helicidade positiva, negativa e um caso adicional de rotação da orientação de propagação, totalizando seis casos.

Escolher dimensões e tamanhos compatíveis com os geradores reais disponíveis, documentando a contagem exata de pontos, pois diferentes famílias podem exigir supercélulas distintas.

Não aumentar automaticamente a rodada para milhares de casos.

### 7. Observáveis

Medir diretamente a partir da evolução da B41L:

1. Resíduo inicial e temporal da lei de Gauss.
2. Energia total e sua deriva.
3. Pureza de helicidade nos dois sentidos.
4. Amplitudes transversais e fase relativa.
5. Parâmetros de Stokes S0, S1, S2 e S3.
6. Erro de reconstrução dos fasores.
7. Desdobramento de frequências entre modos.
8. Mistura entre polarizações e possíveis efeitos de anisotropia.
9. Dependência com refinamento e orientação espacial.

Aplicar prioritariamente o extrator original da POL-B41L-01, preservando seus critérios de avaliação.

Adicionar, como diagnóstico independente, uma reconstrução multimodal baseada nos autovalores ou espectro da rede, desde que haja separação clara entre observáveis medidos e parâmetros ajustados.

A análise multimodal não pode mudar retroativamente o veredito do extrator original.

### 8. Diagnóstico da falha anterior

A POL-B41L-01 registrou falha nos gates G3, G4 e G5. Na amostra anteriormente auditada, a mediana do resíduo do ajuste de fasores foi aproximadamente 0,0779, diante de um limite congelado de 0,05.

A limpeza V1 reduziu substancialmente o resíduo de Gauss, mas não resolveu a falha do ajuste.

Tratar esses números como contexto a verificar nos arquivos originais, não como novos resultados desta bancada.

Testar as seguintes hipóteses:

- H1: a rede irregular mistura modos de frequências próximas e prejudica o extrator de frequência única.
- H2: a falha aparece também na rede regular, apontando para a preparação, o extrator ou a própria dinâmica.
- H3: ordem local tetraédrica reduz ou altera a mistura de modos quando comparada com Poisson.
- H4: a ordem cristalina do controle tipo gelo produz comportamento diferente da rede tetraédrica desordenada.

Registrar resultados negativos e rejeitar hipóteses quando contrariadas pelos dados.

### 9. Gates e pré-registro

Antes de executar a rodada principal, criar e congelar:

`PREREGISTRO_HRF_POL_GEOMETRY_01.md`

Definir critérios numéricos a partir das tolerâncias originais ou de uma justificativa matemática independente, antes de ver os resultados principais.

Gates:

- G0 — Arquivos, integridade e proveniência.
- G1 — Qualidade e definição matemática das cinco geometrias.
- G2 — Preparação helicoidal e lei de Gauss.
- G3 — Evolução física e conservação.
- G4 — Extração de Stokes e helicidade.
- G5 — Comparação das geometrias e robustez.
- G6 — Diagnóstico de frequência única versus multimodal.
- G7 — Veredito global.

Usar `PASS`, `FAIL`, `PENDING` ou `NOT_EXECUTED`.

Não alterar critérios depois de observar a resposta. Não eliminar casos desfavoráveis nem regularizar artificialmente malhas ruins sem registrar a operação.

### 10. Execução local no Codex

O usuário pretende rodar a bancada no próprio ambiente do Codex, não no Google Colab.

Portanto:

- Não depender de Google Drive, autenticação Google ou montagem `/content/drive`.
- Usar somente arquivos locais.
- Detectar automaticamente CPU, RAM, Python, NumPy e SciPy.
- Permitir execução sequencial e paralelismo moderado.
- Disponibilizar comandos simples de preparação, testes, fumaça, execução e avaliação.
- Registrar logs e checkpoints.
- Evitar sobrescrever resultados.
- Permitir retomada segura após interrupções.
- Executar primeiro testes pequenos; não iniciar uma rodada extensa antes dos gates técnicos.

Caso existam recursos locais suficientes, executar a rodada inicial de 34 casos após aprovação das verificações, sem solicitar autorização adicional.

Se houver erro de implementação, preservar log e versão original; corrigir em uma versão nova, sem reclassificar resultados históricos.

### 11. Entregáveis

Criar uma pasta independente:

`HRF_POL_GEOMETRY_01/`

Com:

- `LEIA_ME_PRIMEIRO.md`
- `PREREGISTRO_HRF_POL_GEOMETRY_01.md`
- `RELATORIO_CIENTIFICO.md`
- `RELATORIO_AUDITORIA.md`
- `configs/`
- `src/`
- `tests/`
- `resultados/`
- `graficos/`
- `logs/`
- `MANIFESTO_SHA256.txt`

Criar gráficos comparativos da estrutura das redes, distribuições de vizinhos, pureza de helicidade, Stokes, resíduos de ajuste e convergência.

Gerar um ZIP final compacto com código, relatórios, gráficos, resultados essenciais e manifestos.

Caso os dados brutos sejam volumosos, colocá-los em ZIPs separados, com índice e hashes.

### 12. Regras científicas permanentes

Seguir a Reconstrução Unificadora Progressiva do HRF (B → A).

Separar física estabelecida [F], simulação [M], hipótese [H], lacuna [?] e decisão [D].

Não confundir a organização molecular de água ou gelo com a existência física dos graus microestruturais do HRF. As geometrias são modelos ou reguladores de teste.

Não declarar origem do fóton, quantização, holografia ou unificação fundamental a partir de uma comparação geométrica.

Não modificar os resultados das bancadas B1, B41, B41H, B41L ou POL-B41L-01.

**Prioridade absoluta: preservar o lançamento helicoidal da onda e verificar, com a mesma dinâmica relacional, como cada geometria afeta a propagação e a polarização.**

Toda documentação, avaliação e conclusão devem ser escritas em português brasileiro.
