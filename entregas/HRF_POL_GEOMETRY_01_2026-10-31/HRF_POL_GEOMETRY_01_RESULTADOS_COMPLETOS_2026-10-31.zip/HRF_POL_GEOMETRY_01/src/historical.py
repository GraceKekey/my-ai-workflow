"""[D] Importação explícita das dependências locais congeladas, sem alterações."""
from pathlib import Path
import sys,hashlib,json
ROOT=Path(__file__).resolve().parents[1]
POL=ROOT/'dependencias/POL_B41L_01'
sys.path.insert(0,str(POL/'src'))
import dependency as D
from observable import Observer
from stokes import stokes,fit_windows,STATES
from evaluate import analyze,criteria
from common import atomic_json,atomic_npz,clean,sha

def verify():
 D.verify_dependency()
 p=ROOT/'HASHES_FONTES_CONGELADAS.txt'
 for line in p.read_text().splitlines():
  expected,name=line.split('  ',1)
  if sha(ROOT/name)!=expected:raise ValueError('Dependência alterada: '+name)
 return True
