"""[M] Avaliação sem mudar os gates antigos; gráficos são somente leitura."""
import json,csv
from pathlib import Path
import numpy as np
from historical import ROOT,atomic_json,clean

def evaluate(out):
 rows=json.loads((out/'TODOS_RESULTADOS.json').read_text());status=json.loads((out/'RUN_STATUS.json').read_text());smoke=bool(rows[0]['case']['smoke'])
 hist=['G0','G1','G2','G3','G4','G6'];gates={g:'FAIL' if any(r[g]=='FAIL' for r in rows) else 'PASS' if all(r[g]=='PASS' for r in rows) else 'PENDING' for g in hist}
 # Only two sizes and two irregular realizations: population robustness cannot be certified.
 gates['G5']='FAIL' if gates['G4']=='FAIL' or gates['G1']=='FAIL' else 'PENDING'
 gates['G7']='FAIL' if any(gates[g]=='FAIL' for g in ['G0','G1','G2','G3','G4','G6']) else 'PENDING'
 integration_complete=status['completed']==status['expected']
 summary=dict(status='SMOKE_ONLY' if smoke else 'EVALUATED',gates=gates,expected=status['expected'],physical_integrations_completed=status['completed'],technical_integrations_complete=integration_complete and all(r['G1']=='PASS' and r['G3'] in ['PASS','FAIL'] for r in rows),elapsed_seconds=status['elapsed_seconds'],
              original_verdicts_unchanged=True,scientific_success=False,robustness='PENDING: two sizes; no main temporal refinement or population-level certification')
 table=[]
 for family in ['G1','G2','G3','G4','G5']:
  for n in sorted({r['case']['n'] for r in rows}):
   rs=[r for r in rows if r['case']['family']==family and r['case']['n']==n];good=[r for r in rs if 'multimodal' in r]
   median=lambda key:float(np.median([r[key] for r in good if r.get(key) is not None])) if any(r.get(key) is not None for r in good) else None
   table.append(dict(family=family,n=n,cases=len(rs),executed=len(good),median_fit_residual=median('max_original_fit_residual'),median_min_helicity=median('minimum_helicity_fraction'),median_energy_drift=median('energy_drift'),median_multimodal_residual=float(np.median([r['multimodal']['relative_prediction_residual'] for r in good])) if good else None,gates={g:{v:sum(r[g]==v for r in rs) for v in ['PASS','FAIL','PENDING','NOT_EXECUTED']} for g in hist}))
 summary['comparisons']=table;summary['hypotheses']=hypotheses(rows);atomic_json(out/'resumo.json',summary)
 cols=['family','n','cases','executed','median_fit_residual','median_min_helicity','median_energy_drift','median_multimodal_residual']
 with (out/'comparacao.csv').open('w',newline='') as f:w=csv.DictWriter(f,fieldnames=cols);w.writeheader();w.writerows({k:r[k] for k in cols} for r in table)
 if not smoke:report(out,summary,rows)
 return 0 if integration_complete else 2

def report(out,summary,rows):
 lines=['# HRF-POL-GEOMETRY-01 — relatório científico','', '## Objetivo e hipóteses','', '[H] H1 mistura espectral prejudica o extrator monofrequência; H2 a falha pode ocorrer no controle regular; H3 correlação tetraédrica altera a mistura frente a Poisson; H4 cristal tetraédrico difere da rede desordenada. Resultados são modelos finitos, não água/gelo realistas ou demonstração ontológica.','', '## Parâmetros e protocolo','', '[D] Domínio periódico L=4, N=64 e 216, mesmas densidades em cada nível, k=(0,0,1)·2π/L; G5 acrescenta k=(1,0,0). Casos 4/8/8/8/6, total 34. Construção helicoidal histórica q=Re Q_s, v=|k|Im Q_s; limpeza V1; s histórico corresponde a S3 inicial=-s na base destrógira. Ajuste escalar somente no lançamento para igualar energia. Amplitude de referência e amplitude efetiva estão registradas; não são ambas impostas simultaneamente.','', '[D] Operadores e integrador B41L e extrator POL congelados. V0 pareado reconstruído pela identidade gauge q0=q1+t vL, v0=v1+vL, sem uma segunda integração. Predição multimodal utiliza autovalores da rede e projeções iniciais, com a fase discreta exata do Verlet, sem ajustar frequências aos dados temporais.','', '## Medidas e resultados','',f'[M] Integrações físicas concluídas: {summary["physical_integrations_completed"]}/{summary["expected"]}. Tempo total da rodada: {summary["elapsed_seconds"]/60:.2f} min.','', '| Gate | Estado |','|---|---|']
 for g,v in summary['gates'].items():lines.append(f'| {g} | {v} |')
 lines+=['','| Família | N | Casos | Resíduo mono mediano | Resíduo multimodal mediano | Pureza mínima mediana |','|---|---:|---:|---:|---:|---:|']
 for r in summary['comparisons']:
  f=lambda x:'NOT_EXECUTED' if x is None else f'{x:.6g}'
  lines.append(f'| {r["family"]} | {r["n"]**3} | {r["cases"]} | {f(r["median_fit_residual"])} | {f(r["median_multimodal_residual"])} | {f(r["median_min_helicity"])} |')
 regular=[r for r in rows if r['case']['family']=='G1' and r.get('max_original_fit_residual') is not None]
 multimodal=[r for r in rows if 'multimodal' in r and r['multimodal']['initial_energy_captured']>=.95]
 compatible=sum(r['multimodal']['distinct_significant_frequency_groups']>=2 and r['multimodal']['dominant_frequency_energy_fraction']<=.95 and r['G6']=='PASS' and r['max_original_fit_residual']>.05 and r['multimodal']['relative_prediction_residual']<r['max_original_fit_residual']/2 for r in multimodal)
 lines+=['','## Controles, convergência e interpretação','',f'[M/H] H1: {compatible}/{len(multimodal)} casos com cobertura modal ≥95% têm predição multimodal aprovada, resíduo monofrequência >0,05 e melhora superior a fator 2. Isso testa uma explicação espectral nos casos indicados; não reclassifica o extrator original.',f'[M/H] H2: {sum(r["max_original_fit_residual"]>.05 for r in regular)}/{len(regular)} casos regulares excederam o limite monofrequência. A presença da falha na malha regular impede atribuí-la exclusivamente à irregularidade.','', '[D/M] Estados operacionais das hipóteses: '+str(summary['hypotheses'])+'.','', '[?] H3/H4: comparações descritivas por família na tabela e no CSV. Duas realizações e dois tamanhos não certificam um efeito universal, uma fase líquida/cristalina física ou convergência populacional. Não se converte uma diferença de medianas em descoberta estabelecida.','', '[M/D] Qualidade das malhas, q tetraédrico, g(r), ângulos, coordenação nativa e conectividade Delaunay/Whitney são registrados separadamente. G1 usa triangulação Freudenthal, G5 usa lifting ponderado periódico para desempatar coesfericidades, sem deslocar os pontos. Essas escolhas de regulador podem afetar os observáveis e pertencem aos limites da comparação.','', '[?] Esta bancada testa o mapa W: propagação e polarização. Não deriva U(1), ħ, fóton individual, holografia, matéria ou uma trajetória helicoidal de energia. Critérios e resultados históricos B1/B41/B41H/B41L/POL-B41L-01 permanecem intactos. Os casos e as falhas estão preservados.']
 (ROOT/'RELATORIO_CIENTIFICO.md').write_text('\n'.join(lines)+'\n')


def hypotheses(rows):
 good=[r for r in rows if 'multimodal' in r]
 irregular=[r for r in good if r['case']['family'] in ['G2','G3','G4'] and r['multimodal']['initial_energy_captured']>=.95]
 multi=[r for r in irregular if r['multimodal']['distinct_significant_frequency_groups']>=2 and r['multimodal']['dominant_frequency_energy_fraction']<=.95]
 evidence=[r for r in multi if r['G6']=='PASS' and r['max_original_fit_residual']>.05 and r['multimodal']['relative_prediction_residual']<r['max_original_fit_residual']/2]
 regular=[r for r in good if r['case']['family']=='G1']
 H1='COMPATIVEL_NA_COHORTE' if multi and len(evidence)>=len(multi)/2 else 'CONTRARIADA_NA_COHORTE' if irregular and not evidence else 'PENDING'
 H2='COMPATIVEL_NA_COHORTE' if any(r['max_original_fit_residual']>.05 for r in regular) else 'CONTRARIADA_NA_COHORTE' if len(regular)==4 else 'PENDING'
 def comparison(a,b):
  ratios=[]
  for n in [4,6]:
   A=[r['multimodal']['relative_energy_spectral_width'] for r in good if r['case']['family']==a and r['case']['n']==n and r['case']['direction']==[0,0,1]]
   B=[r['multimodal']['relative_energy_spectral_width'] for r in good if r['case']['family']==b and r['case']['n']==n and r['case']['direction']==[0,0,1]]
   if A and B:ratios.append(float(np.median(A)/max(float(np.median(B)),1e-12)))
  state='PENDING'
  if len(ratios)==2:
   if all(v<=.8 for v in ratios):state='REDUCAO_COMPATIVEL_NA_COHORTE'
   elif all(v>=1.2 for v in ratios):state='AUMENTO_COMPATIVEL_NA_COHORTE'
   elif all(.8<v<1.2 for v in ratios):state='SEM_EFEITO_20PORCENTO_NA_COHORTE'
  return dict(state=state,ratios=ratios,metric='relative eigenenergy spectral width; descriptive finite cohort')
 return dict(H1=H1,H1_eligible_irregular=len(irregular),H1_multigroup=len(multi),H1_compatible_cases=len(evidence),H2=H2,H3=comparison('G4','G3'),H4=comparison('G5','G4'))
