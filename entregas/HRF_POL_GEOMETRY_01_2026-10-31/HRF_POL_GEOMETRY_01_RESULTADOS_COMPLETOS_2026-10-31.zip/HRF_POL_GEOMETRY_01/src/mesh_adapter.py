"""[M] Novas coordenadas/topologia; montagem Whitney e operadores originais."""
import itertools, numpy as np
from types import SimpleNamespace
from scipy.spatial import ConvexHull
from scipy import linalg
import scipy.sparse.linalg as spl
from historical import D

class Ties:
 def __init__(self,P,L,kind,n):self.P=P;self.L=L;self.kind=kind;self.n=n;self.metadata={}
 def __call__(self,X):
  if self.kind=='G1':
   h=self.L/self.n;keys={tuple(np.rint(x/h-.371).astype(int)):i for i,x in enumerate(X)};S=[]
   for g in itertools.product(range(-1,self.n),repeat=3):
    for perm in itertools.permutations(range(3)):
     v=np.array(g);vertices=[keys[tuple(v)]]
     for a in perm:v=v.copy();v[a]+=1;vertices.append(keys[tuple(v)])
     S.append(vertices)
   self.metadata=dict(method='Freudenthal, six tetrahedra per cubic cell; exact coordinates',coordinate_jitter=0)
   return SimpleNamespace(simplices=np.array(S))
  weights=np.random.default_rng(618001).uniform(-1,1,len(self.P));keys={tuple(np.round(p/self.L,11)):i for i,p in enumerate(self.P)}
  ids=np.array([keys[tuple(np.round((x%self.L)/self.L,11))] for x in X])
  eps=1e-7*(self.L/len(self.P)**(1/3))**2
  lift=np.c_[X,np.sum(X*X,axis=1)-eps*weights[ids]]
  hull=ConvexHull(lift,qhull_options='Qt Qx');S=hull.simplices[hull.equations[:,-2]<-1e-10]
  outside=len(S);center=X[S].mean(1);S=S[np.all((center>=0)&(center<self.L),axis=1)];outside-=len(S)
  det=np.linalg.det(X[S[:,1:]]-X[S[:,:1]])
  if np.any(abs(det)<1e-12*(self.L/len(self.P)**(1/3))**3):raise ValueError('tie-break criou tetraedro degenerado; não foi removido')
  self.metadata=dict(method='periodic weighted lifting to resolve crystalline cospherical ties',coordinate_jitter=0,weight_epsilon=eps,tie_seed=618001,padding_facets_outside_box=outside)
  return SimpleNamespace(simplices=S)

def context(P,meta):
 B,LZ,BB,PC,CC=D.modules();import malha
 L=meta['L'];original=malha.Delaunay;tie=None
 try:
  if meta['family'] in ['G1','G5']:tie=Ties(P,L,meta['family'],meta['n']);malha.Delaunay=tie
  C=malha.Complexo(P,L)
 finally:malha.Delaunay=original
 M1,M2=C.matrizes();K=(C.d1.T@M2@C.d1).tocsr();lu=spl.splu(M1.tocsc());cleaner=LZ.Limpador(C.d0,M1,periodico=True)
 counts=np.bincount(C.face_t.ravel(),minlength=C.F);chain=C.d1@C.d0
 sym=lambda A:float(spl.norm(A-A.T)/max(spl.norm(A),1e-30))
 linalg.cholesky(M1.toarray(),lower=True,check_finite=False)
 quality=dict(N=C.N,E=C.E,F=C.F,T=C.T,volume=float(C.vol.sum()),volume_relative_error=float(abs(C.vol.sum()/L**3-1)),
              all_faces_two_tetrahedra=bool(np.all(counts==2)),face_multiplicities=np.unique(counts,return_counts=True),euler=C.N-C.E+C.F-C.T,
              boundary_squared_max=float(max(abs(chain.data),default=0)),M1_symmetry=sym(M1),K_symmetry=sym(K),M1_positive_definite=True,
              minimum_volume=float(C.vol.min()),max_gradient=float(np.max(np.linalg.norm(C.grad,axis=2))),tie_break=tie.metadata if tie else dict(method='original scipy.spatial.Delaunay',coordinate_jitter=0))
 # Mean-ratio quality and aspect condition are diagnostics, not excuses to remove slivers.
 J=C.Xt[:,1:]-C.Xt[:,:1];quality['tetra_condition']=np.linalg.cond(J)
 center=C.Xt[:,0]+np.linalg.solve(2*J,np.sum(J*J,axis=2)[...,None])[...,0];radius2=np.sum((center-C.Xt[:,0])**2,axis=1)
 diff=P[None,:,:]-center[:,None,:];diff-=L*np.rint(diff/L);nearest=np.min(np.einsum('tni,tni->tn',diff,diff),axis=1)
 quality['unweighted_Delaunay_empty_sphere_violation_scaled']=float(np.max(np.maximum(radius2-nearest,0))/(L/C.N**(1/3))**2)
 valid=quality['volume_relative_error']<=1e-10 and quality['all_faces_two_tetrahedra'] and quality['euler']==0 and quality['boundary_squared_max']==0 and max(quality['M1_symmetry'],quality['K_symmetry'])<=1e-12 and quality['unweighted_Delaunay_empty_sphere_violation_scaled']<=1e-7
 quality['technical_gate']='PASS' if valid else 'FAIL'
 return dict(C=C,M1=M1,M2=M2,K=K,lu=lu,cleaner=cleaner,PC=PC,LZ=LZ,dt_original=1/np.sqrt(CC.limite_wmax(C)),quality=quality)

def spectrum(ctx,omega):
 K=ctx['K'];M=ctx['M1'];values,U=linalg.eigh(K.toarray(),M.toarray(),subset_by_value=[.1*omega**2,4*omega**2],driver='gvx',check_finite=False)
 residual=np.linalg.norm(K@U-(M@U)*values,axis=0)/np.maximum(np.linalg.norm(K@U,axis=0)+np.linalg.norm((M@U)*values,axis=0),1e-30)
 orth=float(np.max(abs(U.T@(M@U)-np.eye(len(values)))))
 return dict(values=values,U=U,residual=residual,orthogonality_error=orth,band=[.1*omega**2,4*omega**2])
