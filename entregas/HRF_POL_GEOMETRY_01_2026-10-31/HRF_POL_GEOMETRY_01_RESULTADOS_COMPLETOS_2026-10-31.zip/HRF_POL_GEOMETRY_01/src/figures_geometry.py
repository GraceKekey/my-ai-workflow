"""[M] Gráficos comparativos de dados reais, sem alterar decisões."""
from pathlib import Path
import json,numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from historical import ROOT

def figures(out):
 out=Path(out);dest=ROOT/'graficos';dest.mkdir(exist_ok=True);families=['G1','G2','G3','G4','G5'];colors=['#137cba','#e09b21','#7d4aad','#168956','#d04b5b']
 meshfolders=sorted((out/'malhas').glob('*'));pick={}
 for p in meshfolders:
  m=json.loads((p/'gerador.json').read_text())
  if m['n']==6 and m['family'] not in pick:pick[m['family']]=p
 fig=plt.figure(figsize=(17,4))
 for i,family in enumerate(families):
  if family not in pick:continue
  p=pick[family];P=np.load(p/'pontos.npz')['points'];E=np.load(p/'conectividade.npz')['native_edges'];ax=fig.add_subplot(1,5,i+1,projection='3d');ax.scatter(*P.T,s=5,c=colors[i])
  for a,b in E[:350]:
   d=P[b]-P[a]
   if np.linalg.norm(d)<2:ax.plot(*np.c_[P[a],P[b]],lw=.3,alpha=.2,c=colors[i])
  ax.set(xlim=(0,4),ylim=(0,4),zlim=(0,4),xlabel='x',ylabel='y',zlabel='z',title=family+' — N=216')
 fig.suptitle('[M] Geometrias prescritas; linhas nativas/estatísticas, não trajetórias');fig.tight_layout();fig.savefig(dest/'01_geometrias.png',dpi=145);plt.close(fig)
 fig,axs=plt.subplots(1,3,figsize=(15,4))
 for i,family in enumerate(families):
  if family not in pick:continue
  s=json.loads((pick[family]/'estatisticas.json').read_text());axs[0].plot(s['rdf_r'],s['rdf_g'],label=family,c=colors[i]);axs[1].hist(np.array(s['neighbor_cosines']).ravel(),bins=np.linspace(-1,1,35),density=True,histtype='step',label=family,color=colors[i]);axs[2].hist(s['q_tetra'],bins=np.linspace(-3,1,40),density=True,histtype='step',label=family,color=colors[i])
 for ax,title in zip(axs,['g(r), r≤L/2','cos dos seis ângulos entre quatro vizinhos','q tetraédrico (seleção ambígua na cúbica)']):ax.set_title(title);ax.legend();ax.grid(alpha=.2)
 fig.tight_layout();fig.savefig(dest/'02_vizinhos_ordem.png',dpi=145);plt.close(fig)
 rows=json.loads((out/'TODOS_RESULTADOS.json').read_text());rows=[r for r in rows if 'multimodal' in r]
 fig,axs=plt.subplots(1,3,figsize=(14,4))
 for i,family in enumerate(families):
  rs=[r for r in rows if r['case']['family']==family]
  for n,mark in [(4,'o'),(6,'s')]:
   rr=[r for r in rs if r['case']['n']==n]
   if rr:
    axs[0].scatter([i+(n-5)*.12]*len(rr),[r['minimum_helicity_fraction'] for r in rr],c=colors[i],marker=mark,alpha=.65)
    axs[1].scatter([i+(n-5)*.12]*len(rr),[r['max_original_fit_residual'] for r in rr],c=colors[i],marker=mark,alpha=.65)
    axs[2].scatter([r['max_original_fit_residual'] for r in rr],[r['multimodal']['relative_prediction_residual'] for r in rr],c=colors[i],marker=mark,label=family+' '+str(n**3))
 for ax in axs[:2]:ax.set_xticks(range(5),families);ax.grid(alpha=.2)
 axs[0].axhline(.99,c='k',ls='--',lw=.8);axs[0].set(ylabel='menor fração de helicidade',title='círculos N=64; quadrados N=216')
 axs[1].axhline(.05,c='k',ls='--',lw=.8);axs[1].set(ylabel='maior resíduo monofrequência')
 axs[2].set(xlabel='resíduo monofrequência',ylabel='resíduo predição multimodal');axs[2].legend(fontsize=5);axs[2].grid(alpha=.2)
 fig.tight_layout();fig.savefig(dest/'03_helicidade_residuos.png',dpi=145);plt.close(fig)
 fig,axs=plt.subplots(2,3,figsize=(13,7))
 for i,family in enumerate(families):
  selected=next((r for r in rows if r['case']['family']==family and r['case']['n']==6 and r['case']['s_historical']==1 and r['case']['direction']==[0,0,1]),None)
  if selected:
   old=json.loads((out/selected['case']['case_id']/'avaliacao_POL_original.json').read_text());ws=[w for w in old['windows'] if w['s'] is not None];tt=[(w['t_start']+w['t_end'])/2 for w in ws];ss=np.array([w['s'] for w in ws])
   for j in range(3):axs.flat[i].plot(tt,ss[:,j],'o-',ms=3,label='S'+str(j+1)+'/S0')
   axs.flat[i].set(title=family,xlabel='t');axs.flat[i].legend(fontsize=6);axs.flat[i].grid(alpha=.2)
 axs.flat[-1].axis('off');fig.suptitle('[M] Stokes do extrator original, inclusive casos reprovados');fig.tight_layout();fig.savefig(dest/'04_stokes.png',dpi=145);plt.close(fig)
 fig,axs=plt.subplots(1,2,figsize=(11,4))
 for i,family in enumerate(families):
  for field,ax in [('max_original_fit_residual',axs[0]),('minimum_helicity_fraction',axs[1])]:
   vals=[np.median([r[field] for r in rows if r['case']['family']==family and r['case']['n']==n]) for n in [4,6]]
   ax.plot([4,6],vals,'o-',label=family,c=colors[i]);ax.set_xticks([4,6],['N=64','N=216']);ax.grid(alpha=.2);ax.legend()
 axs[0].set(ylabel='resíduo mono mediano',title='Dois níveis: tendência, não certificação de ordem');axs[1].set(ylabel='fração mínima mediana');fig.tight_layout();fig.savefig(dest/'05_refinamento.png',dpi=145);plt.close(fig)
