"""[M] Evolução efetiva com o passo B41L congelado e observáveis POL originais."""
from pathlib import Path
import json,hashlib,math,time,platform,sys
import numpy as np
from historical import ROOT,D,Observer,atomic_json,atomic_npz,clean,sha,analyze,criteria
from geometry import points,characterize
from mesh_adapter import context,spectrum

def plan_cases(smoke=False):
 c=json.loads((ROOT/'configs/plano.json').read_text());rows=[]
 for family in ['G1','G2','G3','G4','G5']:
  for n in ([4] if smoke else c['sizes']):
   seeds=[c['smoke_seed']] if smoke else (c['seeds'] if family in ['G2','G3','G4'] else [c['seeds'][0]])
   for seed in seeds:
    pairs=[(1,[0,0,1])] if smoke else [(1,[0,0,1]),(-1,[0,0,1])]+([(1,[1,0,0])] if family=='G5' else [])
    for s,direction in pairs:
     rows.append(dict(family=family,n=n,seed=seed,s_historical=s,direction=direction,variant='V1',state='C-' if s==1 else 'C+',dt_scale=1.,
          case_id=f'{family}_n{n}_r{seed}_s{str(s).replace("-","m")}_k'+''.join(map(str,direction)),smoke=smoke))
 return c,rows

def fingerprint():
 h=hashlib.sha256()
 for p in sorted((ROOT/'src').glob('*.py')):h.update(p.name.encode());h.update(p.read_bytes())
 h.update((ROOT/'configs/plano.json').read_bytes());h.update((ROOT/'configs/criterios_POL_originais.json').read_bytes())
 return h.hexdigest()

def launch(ctx,x,c):
 k=ctx['PC'].kvec(x['direction']);omega=float(np.linalg.norm(k));e1,e2=ctx['LZ'].base_transversal(k)
 Q=ctx['C'].onda_aresta(k,c['amplitude_raw']*(e1-1j*x['s_historical']*e2)/np.sqrt(2))
 q=Q.real.copy();v0=omega*Q.imag;v,_=ctx['cleaner'].limpar(v0);Hraw=.5*v@(ctx['M1']@v)+.5*q@(ctx['K']@q)
 alpha=np.sqrt(c['energy_target']/Hraw);q*=alpha;v*=alpha;v0*=alpha
 return q,v,v0-v,dict(k=k,omega=omega,e1=e1,e2=e2,raw_energy=float(Hraw),initial_energy_scale=float(alpha),amplitude_effective=float(c['amplitude_raw']*alpha))

def geometry_gate(meta,stats,quality,c):
 good=quality['technical_gate']=='PASS'
 if meta['family']=='G2':good=good and stats['minimum_distance']>=.65*meta['L']/meta['n']*(1-1e-10)
 if meta['family']=='G4':good=good and stats['mean_q']>=c['tetra_disordered_q_min'] and stats['bragg_max']<=c['tetra_disordered_bragg_max']
 if meta['family']=='G5':good=good and stats['mean_q']>=1-1e-10 and np.all(stats['native_undirected_coordination']==4)
 return 'PASS' if good else 'FAIL'

def prepare_mesh(x,c,out):
 key=f'{x["family"]}_n{x["n"]}_r{x["seed"]}';folder=out/'malhas'/key;folder.mkdir(parents=True,exist_ok=True)
 if (folder/'pontos.npz').exists():
  meta=json.loads((folder/'gerador.json').read_text());expected=json.loads((folder/'pontos_hash.json').read_text())['sha256']
  if sha(folder/'pontos.npz')!=expected:raise ValueError('coordenadas históricas do gerador alteradas')
  P=np.load(folder/'pontos.npz')['points']
 else:
  P,meta=points(x['family'],x['n'],x['seed'],c['L'],c['amorphous_sweeps']);atomic_npz(folder/'pontos.npz',points=P);atomic_json(folder/'gerador.json',meta);atomic_json(folder/'pontos_hash.json',dict(sha256=sha(folder/'pontos.npz')))
 stats=characterize(P,c['L'])
 if x['family']=='G1':
  from geometry import displacements
  ds=displacements(P,c['L']);r2=np.einsum('ijk,ijk->ij',ds,ds);ii,jj=np.where(np.triu(np.isclose(r2,(c['L']/x['n'])**2,rtol=0,atol=1e-10),1));stats['native_edges']=np.c_[ii,jj];stats['native_undirected_coordination']=np.bincount(np.r_[ii,jj],minlength=len(P))
 stats['native_graph_definition']='cubic six nearest axis neighbors' if x['family']=='G1' else 'diamond four nearest bonds' if x['family']=='G5' else 'nearest-four diagnostic graph; generator prescribes no molecular bonds'
 ctx=context(P,meta);atomic_json(folder/'estatisticas.json',{k:v for k,v in stats.items() if k not in ['native_edges','nearest4_ids']})
 atomic_npz(folder/'conectividade.npz',native_edges=stats['native_edges'],nearest4_ids=stats['nearest4_ids'],solver_edges=ctx['C'].arestas,solver_tetrahedra=ctx['C'].ot,solver_coordinates=ctx['C'].Xt)
 ctx['quality']['solver_coordination']=np.bincount(ctx['C'].arestas[:,:2].ravel(),minlength=len(P))
 atomic_json(folder/'operadores.json',ctx['quality']);gate=geometry_gate(meta,stats,ctx['quality'],c);ctx.update(geometry_gate=gate,mesh_key=key,geometry_stats=stats)
 if gate=='PASS':
  spec=spectrum(ctx,float(np.linalg.norm(ctx['PC'].kvec([0,0,1]))));ctx['spectrum']=spec
  atomic_npz(folder/'espectro.npz',eigenvalues=spec['values'],eigenvectors=spec['U'],eigen_residual=spec['residual'])
  atomic_json(folder/'espectro.json',{k:v for k,v in spec.items() if k!='U'})
 return ctx

def valid_case(folder,identity):
 if not (folder/'COMPLETED.json').exists():return False
 seal=json.loads((folder/'COMPLETED.json').read_text())
 if seal['identity']!=identity:raise ValueError('saída de outra versão; usar pasta nova')
 for n,digest in seal['files'].items():
  if sha(folder/n)!=digest:raise ValueError('caso corrompido: '+n)
 return True

def run_case(x,c,ctx,out):
 folder=out/x['case_id'];folder.mkdir(exist_ok=True);ident=hashlib.sha256((fingerprint()+json.dumps(c,sort_keys=True)+json.dumps(x,sort_keys=True)).encode()).hexdigest()
 if valid_case(folder,ident):return json.loads((folder/'avaliacao.json').read_text())
 if ctx['geometry_gate']!='PASS':
  result=dict(case=x,G0='PASS',G1='FAIL',G2='NOT_EXECUTED',G3='NOT_EXECUTED',G4='NOT_EXECUTED',G5='PENDING',G6='NOT_EXECUTED',G7='FAIL',reason='geometria não passou controles; nenhuma integração realizada')
  atomic_json(folder/'avaliacao.json',result);return result
 q,v,vL,prep=launch(ctx,x,c);C=ctx['C'];M=ctx['M1'];K=ctx['K'];omega=prep['omega'];dt=ctx['dt_original']*c['dt_scale'];periods=c['smoke_periods'] if x['smoke'] else c['periods'];steps=round(periods*2*np.pi/omega/dt)
 if steps+1>c['max_frames']:raise MemoryError('BLOCKED_RESOURCES: passos '+str(steps)+' excedem '+str(c['max_frames'])+'; nenhuma malha foi regularizada')
 obs=Observer(ctx,prep['k'],prep['e1'],prep['e2']);initial=obs.initial_phasor(q,v,omega);gauge=obs.gauge_test(q,v);g0=C.d0.T@(M@v);g00=C.d0.T@(M@(v+vL));a=-ctx['lu'].solve(K@q)
 spec=ctx['spectrum'];U=spec['U'];coefq=U.T@(M@q);coefv=U.T@(M@v)
 mode_fields=np.array([obs.amplitudes(ctx['PC'].campos_tet(C,1j*U[:,j],1)[0].real) for j in range(U.shape[1])])
 start=0;frames=[];v0frames=[];snapshots=[];stimes=[];stride=max(1,steps//(c['snapshot_target']-1));cp=folder/'checkpoint.npz'
 meta=dict(case=x,status='RUNNING',identity=ident,source_code_sha256=fingerprint(),mesh_key=ctx['mesh_key'],steps=steps,dt=dt,actual_T=steps*dt,target_periods=periods,omega=omega,gauge=gauge,
           conventions='Q_s=onda_aresta(k, a(e1-i*s*e2)/sqrt(2)); q=Re Q, v=|k| Im Q; ea x eb=kh; physical Stokes S3=-s initially; E=-Whitney(v)',launch=prep,
           started_UTC=__import__('datetime').datetime.now(__import__('datetime').timezone.utc).isoformat(),environment=dict(python=sys.version,numpy=np.__version__,scipy=__import__('scipy').__version__,platform=platform.platform()))
 def arrays():
  def unpack(f):return dict(times=np.array([z[0] for z in f]),electric_regions=np.array([z[1] for z in f]),energy=np.array([z[2] for z in f]),gauss_abs=np.array([z[3] for z in f]),pi_norm=np.array([z[4] for z in f]),momentum=np.array([z[5] for z in f]),gauss_change=np.array([z[6] for z in f]))
  return unpack(frames),unpack(v0frames)
 if cp.exists():
  with np.load(cp,allow_pickle=False) as z:
   if str(z['identity'])!=ident:raise ValueError('checkpoint de outra versão')
   q=z['q'].copy();v=z['v'].copy();a=z['a'].copy();start=int(z['next_step']);snapshots=list(z['snapshots']);stimes=list(z['snapshot_times'])
   for dest,prefix in [(frames,''),(v0frames,'V0_')]:
    for j in range(len(z[prefix+'times'])):dest.append(tuple(z[prefix+n][j] for n in ['times','electric_regions','energy','gauss_abs','pi_norm','momentum','gauss_change']))
 atomic_json(folder/'run.json',meta);step,kernel=D.original_step();started=time.monotonic()
 try:
  for it in range(start,steps+1):
   t=it*dt
   for dest,qq,vv,gg in [(frames,q,v,g0),(v0frames,q+t*vL,v+vL,g00)]:
    E,H,G,Pn,P=obs.sample(qq,vv);dest.append((t,E,H,G,Pn,P,np.linalg.norm(C.d0.T@(M@vv)-gg)))
   if it%stride==0 or it==steps:snapshots.append(np.stack([q,v]));stimes.append(t)
   if it==steps:break
   q,v,a=step(q,v,a,dt,ctx['lu'],K)
   if not np.isfinite(q).all() or not np.isfinite(v).all():raise FloatingPointError('estado não finito')
   if (it+1)%c['checkpoint_steps']==0:
    data,vzero=arrays();atomic_npz(cp,identity=ident,q=q,v=v,a=a,next_step=it+1,snapshots=np.array(snapshots),snapshot_times=np.array(stimes),**data,**{'V0_'+k:y for k,y in vzero.items()})
  data,vzero=arrays();data.update(region_volumes=obs.weights,initial_phasor=initial)
  atomic_npz(folder/'fields.npz',**data,**{'V0_'+k:y for k,y in vzero.items()},snapshots=np.array(snapshots),snapshot_times=np.array(stimes))
  old=analyze(data,x,meta,criteria());atomic_json(folder/'avaliacao_POL_original.json',old)
  # Absolute prediction from initial eigenmode coefficients; no fit to the evolved series.
  eig=spec['values'];theta=2*np.arcsin(np.sqrt(eig)*dt/2);times=data['times'];phase=np.outer(np.arange(len(times)),theta)
  vm=np.cos(phase)*coefv-np.sin(phase)*(coefq*np.sin(theta)/dt)
  predicted=np.einsum('tm,mrc->trc',vm,mode_fields)
  residual=float(np.linalg.norm(predicted-data['electric_regions'])/max(np.linalg.norm(data['electric_regions']),1e-30))
  capture=float(np.sum(.5*coefv**2+.5*eig*coefq**2)/data['energy'][0]);spectralgood=max(spec['residual'],default=0)<=c['spectral_residual_max'] and spec['orthogonality_error']<=c['spectral_orthogonality_max']
  modal=dict(relative_prediction_residual=residual,initial_energy_captured=capture,eigenmode_count=len(eig),eigenfrequency_min=float(np.sqrt(eig.min())),eigenfrequency_max=float(np.sqrt(eig.max())),fit_parameters_from_time_series=0,method='network eigenvalues + initial projections + exact modal discrete Verlet phase; no refit of omega/xi')
  frequencies=theta/dt;grouped=[]
  for j,f in enumerate(frequencies):
   if not grouped or abs(f-frequencies[grouped[-1][0]])>1e-8*omega:grouped.append([j])
   else:grouped[-1].append(j)
  phasor_coeff=coefv-1j*coefq*np.sin(theta)/dt
  groupfields=np.array([np.einsum('m,mrc->rc',phasor_coeff[ids],mode_fields[ids,:,:2]) for ids in grouped])
  power=np.sum(abs(groupfields)**2*obs.weights[None,:,None],axis=1);groupfreq=np.array([frequencies[ids].mean() for ids in grouped])
  groupenergy=np.array([np.sum(.5*coefv[ids]**2+.5*eig[ids]*coefq[ids]**2) for ids in grouped]);ef=groupenergy/max(groupenergy.sum(),1e-30);emean=float(np.sum(ef*groupfreq))
  modal['distinct_significant_frequency_groups']=int(np.sum(ef>=.01));modal['dominant_frequency_energy_fraction']=float(ef.max());modal['relative_energy_spectral_width']=float(np.sqrt(np.sum(ef*(groupfreq-emean)**2))/omega)
  mean=np.sum(power*groupfreq[:,None],axis=0)/np.maximum(np.sum(power,axis=0),1e-30);modal['transverse_frequency_mean']=mean;modal['frequency_splitting']=float(mean[0]-mean[1]);modal['frequency_grouping_tolerance']=1e-8*omega;modal['frequency_interpretation']='spectral means; coherent sums in numerically degenerate subspaces; not a fitted birefringence coefficient'
  atomic_npz(folder/'multimodal.npz',prediction=predicted,eigenvalues=eig,initial_q_coefficients=coefq,initial_v_coefficients=coefv,mode_transverse_power=power)
  windows=[w for w in old.get('windows',[]) if w['s'] is not None];fractions=[float((1-x['s_historical']*w['s'][2])/2) for w in windows];minfraction=min(fractions,default=None)
  G3='PASS' if old['energy_drift']<=criteria()['energy_drift_max'] and old['gauss_variation']<=criteria()['gauss_max'] else 'FAIL'
  G4='PASS' if all(old[g]=='PASS' for g in ['G3','G4','G6']) and minfraction is not None and minfraction>=c['helicity_fraction_min'] else ('PENDING' if old['G3']=='PENDING' else 'FAIL')
  G6='FAIL' if not spectralgood else 'PASS' if capture>=c['multimodal_energy_capture_min'] and residual<=c['multimodal_prediction_residual_max'] else 'PENDING'
  result=dict(case=x,G0='PASS',G1='PASS',G2=old['G2'],G3=G3,G4=G4,G5='PENDING',G6=G6,G7='FAIL' if any(g=='FAIL' for g in [old['G2'],G3,G4,G6]) else 'PENDING',
      original_POL_gates={g:old[g] for g in ['G2','G3','G4','G6']},minimum_helicity_fraction=minfraction,multimodal=modal,
      max_original_fit_residual=max([w['residual'] for w in windows],default=None),energy_drift=old['energy_drift'],gauss0=old['gauss0'],gauss_variation=old['gauss_variation'],source_conventions=meta['conventions'],elapsed_seconds=time.monotonic()-started)
  atomic_json(folder/'avaliacao.json',result);meta.update(status='COMPLETED',elapsed_seconds=time.monotonic()-started,kernel_AST_sha256=kernel);atomic_json(folder/'run.json',meta)
  names=['fields.npz','run.json','avaliacao_POL_original.json','multimodal.npz','avaliacao.json'];atomic_json(folder/'COMPLETED.json',dict(identity=ident,files={n:sha(folder/n) for n in names}));cp.unlink(missing_ok=True)
  return clean(result)
 except BaseException as e:
  meta.update(status='INTERRUPTED' if isinstance(e,(KeyboardInterrupt,SystemExit)) else 'FAILED',error=str(e));atomic_json(folder/'run.json',meta);raise
