"""[M] Geradores periódicos; nenhuma dinâmica de água molecular é postulada."""
import itertools, numpy as np
from scipy.spatial import cKDTree

def displacements(P,L):
 d=P[None,:,:]-P[:,None,:];return d-L*np.rint(d/L)
def tetra_stats(P,L):
 d=displacements(P,L);r2=np.einsum('ijk,ijk->ij',d,d);np.fill_diagonal(r2,np.inf)
 ids=np.argsort(r2,axis=1)[:,:4];v=np.take_along_axis(d,ids[:,:,None],axis=1);r=np.linalg.norm(v,axis=2);u=v/r[:,:,None]
 angles=np.array([np.einsum('ij,ij->i',u[:,a],u[:,b]) for a,b in itertools.combinations(range(4),2)]).T
 q=1-3/8*np.sum((angles+1/3)**2,axis=1)
 return q,r,angles,ids,r2

def poisson_disk(N,L,rng,rmin):
 P=[];attempts=0
 while len(P)<N and attempts<200000:
  x=rng.uniform(0,L,3);attempts+=1
  if P:
   d=np.array(P)-x;d-=L*np.rint(d/L)
   if np.min(np.einsum('ij,ij->i',d,d))<rmin*rmin:continue
  P.append(x)
 if len(P)!=N:raise RuntimeError('gerador Poisson-disk não atingiu N; nenhum raio foi afrouxado')
 return np.array(P),attempts

def amorphous(N,L,rng,sweeps):
 ell=L/N**(1/3);P,attempts=poisson_disk(N,L,rng,.65*ell)
 def energy(P):
  q,r,_,_,r2=tetra_stats(P,L)
  penalty=np.maximum(.6**2*ell**2/r2-1,0)
  return np.sum(1-q)+.3*np.sum((r/(np.sqrt(3)/2*ell)-1)**2)+4*np.sum(penalty**2)
 E=energy(P);accepted=0
 for j in range(sweeps*N):
  f=j/max(sweeps*N-1,1);T=.2*(.002/.2)**f;sigma=ell*(.18*(1-f)+.025*f)
  i=int(rng.integers(N));old=P[i].copy();P[i]=(P[i]+rng.normal(0,sigma,3))%L
  trial=energy(P);delta=trial-E
  if delta<=0 or rng.random()<np.exp(-delta/T):E=trial;accepted+=1
  else:P[i]=old
 return P,dict(algorithm='annealed nearest-four angular/radial energy; initially Poisson-disk, no lattice template',sweeps=sweeps,proposals=sweeps*N,accepted=accepted,final_energy=float(E),initial_rejection_attempts=attempts)

def points(family,n,seed,L=4.,sweeps=120):
 rng=np.random.default_rng(seed);N=n**3;ell=L/n;meta=dict(family=family,n=n,N=N,L=L,seed=seed,density=N/L**3)
 if family=='G1':P=(np.array(list(itertools.product(range(n),repeat=3)))+.371)*ell;meta['algorithm']='exact cubic lattice; Freudenthal periodic triangulation'
 elif family=='G2':P,attempts=poisson_disk(N,L,rng,.65*ell);meta.update(minimum_separation=.65*ell,attempts=attempts,algorithm='periodic random sequential inhibition, fixed N')
 elif family=='G3':P=rng.uniform(0,L,(N,3));meta['algorithm']='iid uniform fixed N: homogeneous Poisson conditioned on N'
 elif family=='G4':P,extra=amorphous(N,L,rng,sweeps);meta.update(extra)
 elif family=='G5':
  assert n%2==0;q=n//2;fcc=np.array([[0,0,0],[0,.5,.5],[.5,0,.5],[.5,.5,0]]);basis=np.r_[fcc,(fcc+.25)%1]
  P=np.concatenate([(np.array(c)+basis)*(L/q) for c in itertools.product(range(q),repeat=3)])
  P=(P+np.array([.137,.193,.271])*ell)%L;meta['global_translation_density_units']=[.137,.193,.271]
  meta['algorithm']='diamond-like: FCC four sites plus (1/4,1/4,1/4), eight sites per conventional cell'
 else:raise ValueError(family)
 return P,meta

def characterize(P,L):
 N=len(P);ell=L/N**(1/3);q,r,cos,ids,r2=tetra_stats(P,L)
 kv=np.array([v for v in itertools.product(range(-6,7),repeat=3) if v!=(0,0,0)])
 bragg=abs(np.exp(2j*np.pi/L*(P@kv.T)).mean(0))**2
 pair=np.sqrt(r2[np.triu_indices(N,1)]);bins=np.linspace(0,L/2,41);counts,_=np.histogram(pair,bins);shell=4*np.pi/3*np.diff(bins**3)
 rdf=counts/(N*(N-1)/2*shell/L**3)
 edges=sorted({tuple(sorted((i,int(j)))) for i,row in enumerate(ids) for j in row})
 return dict(q_tetra=q,nearest4_distances=r,neighbor_cosines=cos,native_edges=np.array(edges),nearest4_ids=ids,
             minimum_distance=float(np.sqrt(np.min(r2))),mean_q=float(np.mean(q)),fraction_q_above_half=float(np.mean(q>.5)),
             bragg_max=float(np.max(bragg)),bragg_k=kv[np.argmax(bragg)],rdf_r=(bins[:-1]+bins[1:])/2,rdf_g=rdf,
             nearest4_directed_coordination=4,tetra_selection_degenerate=np.isclose(np.sort(r2,axis=1)[:,3],np.sort(r2,axis=1)[:,4],atol=1e-10*ell**2,rtol=0),native_undirected_coordination=np.bincount(np.array(edges).ravel(),minlength=N))
