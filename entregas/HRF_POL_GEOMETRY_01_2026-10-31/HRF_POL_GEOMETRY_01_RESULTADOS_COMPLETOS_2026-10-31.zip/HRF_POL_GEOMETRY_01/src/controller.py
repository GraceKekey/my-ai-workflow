"""[D] CLI, admissão de recursos e lotes independentes, sem execução em importação."""
from pathlib import Path
import argparse,json,sys,time,os,concurrent.futures as cf,multiprocessing as mp,traceback,shutil
from historical import ROOT,verify,atomic_json,sha
from common import available_memory
from experiment import plan_cases,prepare_mesh,run_case,fingerprint

def frozen():
 for line in (ROOT/'HASHES_ANTES_PRINCIPAL.txt').read_text().splitlines():
  expected,name=line.split('  ',1)
  if sha(ROOT/name)!=expected:raise ValueError('pré-registro alterado: '+name)
 verify()

def grouped(rows):
 groups={}
 for x in rows:groups.setdefault((x['family'],x['n'],x['seed']),[]).append(x)
 return list(groups.values())

def preparation(payload):
 xs,c,out=payload;ctx=prepare_mesh(xs[0],c,Path(out));omega=float(__import__('numpy').linalg.norm(ctx['PC'].kvec([0,0,1])))
 steps=round(c['periods']*2*__import__('numpy').pi/omega/ctx['dt_original'])
 return dict(mesh=ctx['mesh_key'],family=xs[0]['family'],n=xs[0]['n'],seed=xs[0]['seed'],points=ctx['C'].N,edges=ctx['C'].E,steps=steps,gate=ctx['geometry_gate'],frames_admitted=steps+1<=c['max_frames'],estimated_bytes=(steps+1)*1600*len(xs)+ctx['C'].E**2*24)

def execute(payload):
 xs,c,out=payload;out=Path(out);rows=[]
 try:ctx=prepare_mesh(xs[0],c,out)
 except Exception as e:
  error=dict(type=type(e).__name__,error=str(e),traceback=traceback.format_exc());atomic_json(out/'erros'/f'{xs[0]["family"]}_{xs[0]["n"]}_{xs[0]["seed"]}.json',error)
  return [dict(case=x,G0='PASS',G1='FAIL',G2='NOT_EXECUTED',G3='NOT_EXECUTED',G4='NOT_EXECUTED',G5='PENDING',G6='NOT_EXECUTED',G7='FAIL',error=error) for x in xs]
 for x in xs:
  try:result=run_case(x,c,ctx,out)
  except Exception as e:
   result=dict(case=x,G0='PASS',G1=ctx['geometry_gate'],G2='NOT_EXECUTED',G3='NOT_EXECUTED',G4='NOT_EXECUTED',G5='PENDING',G6='NOT_EXECUTED',G7='PENDING',error=str(e),traceback=traceback.format_exc());atomic_json(out/x['case_id']/'erro.json',result)
  rows.append(result);print(x['case_id'],{k:result[k] for k in ['G1','G2','G3','G4','G6']},flush=True)
 return rows

def main(argv=None):
 p=argparse.ArgumentParser();p.add_argument('command',choices=['prepare','smoke','run','evaluate']);p.add_argument('--output',type=Path);p.add_argument('--workers',type=int,default=4,choices=range(1,5));p.add_argument('--executar',action='store_true');a=p.parse_args(argv)
 c,rows=plan_cases(a.command=='smoke');out=a.output or ROOT/'resultados'/('fumaca' if a.command=='smoke' else 'principal');out.mkdir(parents=True,exist_ok=True)
 verify()
 if a.command=='prepare':
  with cf.ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context('spawn')) as pool:plans=list(pool.map(preparation,[(xs,c,str(out)) for xs in grouped(rows)]))
  quota=available_memory();cpu_text=Path('/sys/fs/cgroup/cpu.max').read_text().split();cpu_budget=float(cpu_text[0])/int(cpu_text[1]) if cpu_text[0]!='max' else len(os.sched_getaffinity(0));ram=a.workers*c['memory_per_worker_bytes']+2**30;disk=sum(r['estimated_bytes'] for r in plans)+2**30
  admitted=ram<=quota and a.workers<=cpu_budget and disk<=shutil.disk_usage(out).free and disk<=c['disk_budget_bytes']
  result=dict(status='ADMITTED' if admitted else 'BLOCKED_RESOURCES',cases=len(rows),meshes=plans,RAM_budget_bytes=ram,disk_budget_bytes=disk,workers=a.workers,CPU_quota=cpu_budget,free_RAM_bytes=quota,environment=dict(python=sys.version,numpy=__import__('numpy').__version__,scipy=__import__('scipy').__version__),new_integrations=0);atomic_json(out/'preparacao.json',result);print(json.dumps(result));return 0 if admitted else 2
 if a.command=='evaluate':
  from analysis_geometry import evaluate
  return evaluate(out)
 frozen()
 if not a.executar:print('Nenhuma integração iniciada; use --executar.');return 0
 if a.command=='run':
  technical=json.loads((ROOT/'auditoria/TESTES.json').read_text());smoke=json.loads((ROOT/'resultados/fumaca/resumo.json').read_text());prep=json.loads((out/'preparacao.json').read_text())
  if technical['status']!='PASS' or not smoke['technical_integrations_complete'] or prep['status']!='ADMITTED':raise ValueError('gates técnicos, fumaça ou recursos não aprovados')
  for line in (ROOT/'HASHES_MALHAS_ANTES_PRINCIPAL.txt').read_text().splitlines():
   expected,name=line.split('  ',1)
   if sha(ROOT/name)!=expected:raise ValueError('malha pré-registrada foi alterada')
 t=time.monotonic();allrows=[];atomic_json(out/'RUN_STATUS.json',dict(status='RUNNING',expected=len(rows),completed=0,workers=a.workers))
 with cf.ProcessPoolExecutor(max_workers=a.workers,mp_context=mp.get_context('spawn')) as pool:
  futures=[pool.submit(execute,(xs,c,str(out))) for xs in grouped(rows)]
  for f in cf.as_completed(futures):
   allrows.extend(f.result());atomic_json(out/'RUN_STATUS.json',dict(status='RUNNING',expected=len(rows),evaluated=len(allrows),completed=len(list(out.glob('*/COMPLETED.json'))),workers=a.workers,elapsed_seconds=time.monotonic()-t))
 atomic_json(out/'TODOS_RESULTADOS.json',allrows);atomic_json(out/'RUN_STATUS.json',dict(status='COMPLETED',expected=len(rows),evaluated=len(allrows),completed=len(list(out.glob('*/COMPLETED.json'))),workers=a.workers,elapsed_seconds=time.monotonic()-t))
 frozen()
 from analysis_geometry import evaluate
 return evaluate(out)
