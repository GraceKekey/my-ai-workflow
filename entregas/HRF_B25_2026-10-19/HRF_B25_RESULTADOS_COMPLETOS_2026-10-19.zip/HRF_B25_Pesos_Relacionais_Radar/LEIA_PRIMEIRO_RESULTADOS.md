# B25 — resultados locais

R1: BIRREFRINGÊNCIA FRACA; R2: INDEFINIDO; Q: EMERGE. T é exploratório.

Comece por RELATORIO_CIENTIFICO_B25.md e resultados/avaliacao_B25.json. A decisão foi tomada pelo avaliador original sem editar critérios. Confira resultados/CONFERENCIA_COBERTURA.json e MANIFEST_SHA256_ENTREGA.json.

O pacote inclui protocolo, código original, dados, figuras e relatório. Para reproduzir em outra máquina: Python≥3.10, numpy e scipy; as versões desta execução estão em requirements_execucao.txt. Use uma cópia nova da pasta e preserve resultados existentes antes de executar novamente os comandos do LEIAME_B25.md. Não use fumaca/ como resultado completo.

Os resultados foram gravados localmente, sem publicação no GitHub. Criar e verificar o ZIP confirma o arquivo no ambiente, não confirma que a interface do chat o disponibilizou como anexo baixável.
