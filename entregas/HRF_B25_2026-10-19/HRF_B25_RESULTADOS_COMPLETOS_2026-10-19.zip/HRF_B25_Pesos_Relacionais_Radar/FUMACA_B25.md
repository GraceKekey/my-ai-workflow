# HRF B25 — Teste de fumaça e cronometragem (não valem como resultado)

**Data:** 19 out 2026, 14h50–15h26 — Claude (`-clau`). Executado **antes** do congelamento do protocolo, só para
verificar o código. Os números abaixo **não** entram em nenhuma decisão.

## O que rodou

`python -I src/rodar_B25.py fumaca` (saídas em `fumaca/`), 7 s:

| Bloco | Configuração mínima | Serviu para |
|---|---|---|
| B25-Q | tetraedro S = 1, λ = 0,1; sem sinal S = 1 | montar K₄ com triângulos e quadriláteros, analisar por comprimento de laço |
| B25-R | n = 8 e 10, 2 sementes; N-Poisson n = 8; X2 com um caso | famílias, Stokes, W exato, homogeneização U, saltos, invariância afim |
| B25-T | n = 12, pacote em lâmina | filtro espectral, integrador, centroide circular, helicidade |

`python -I src/teste_avaliador_sintetico_B25.py` com dados **inventados**: todos os ramos foram alcançados (CONE ÚNICO,
BIRREFRINGENTE, BIRREFRINGÊNCIA FRACA, INCONCLUSIVO; UMA/DUAS GEOMETRIAS, INDEFINIDO; EMERGE, NÃO EMERGE, PARCIAL).

## Verificações de código feitas durante a fumaça

- **Convenções:** Stokes local ≤ 10⁻¹⁴; d₁ℓ = 0 a 2×10⁻¹⁵; com Whitney, |ε − 1| ~ 10⁻¹⁶ e |ν − 1| ~ 10⁻⁸ (o controle
  exato funciona e confirma a orientação dos vetores de área contra a d₁).
- **Invariância afim:** P idêntico entre F-iso e F-aff; η_L exatamente × 2.
- **Homogeneização × autovalores verdadeiros** (uma amostra F-iso n = 24, semente de teste 11, fora do conjunto
  pré-registrado): os 8 modos mais baixos (k ao longo de ±x, ±y) a ω/k = 0,571–0,582 contra 0,578 previsto; os 8
  seguintes a 0,807–0,821 contra 0,818 (= 0,578·√2). Fatoração LU de 186 s; só usada nesta validação.
- **Sonda do radar direto:** com pesos U, a onda plana nua (mapa de de Rham) tem 96% do peso nos modos vestidos e
  ~1% em modos de célula, mas esse 1% carrega energia comparável à da onda (o quociente de Rayleigh dava ω/k = 0,83
  contra 0,58). Com envelope 3D, o centroide andava a ~0,87 v por causa das componentes transversais de k.
  Correção: pacote em lâmina, filtrado (Chebyshev com núcleo de Jackson, testado num operador diagonal: vazamento
  ≤ 5×10⁻⁴ em amplitude) e sem gradientes. Resultado no teste n = 24 (não decisivo): v_radar/v_homog = 0,974–0,994.

## Cronometragem (números não impressos)

- B25-R, uma amostra com n = 24: 12,8 s.
- B25-Q, tetraedro S = 3, um valor de λ: 700 s (≈ 12 min; os três λ somam ≈ 35 min e dominam a rodada).

## Mudanças feitas depois da fumaça (antes do congelamento)

Ver o protocolo, §9 (resíduo do CG em escala absoluta; fontes de saltos com semente fixa; sonda do radar direto em
lâmina filtrada). A fumaça final foi refeita às 15h14 com o código congelado.
