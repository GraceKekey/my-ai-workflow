# -*- coding: utf-8 -*-
"""
HRF B25-T (EXPLORATÓRIO) — radar direto: tempo de voo de um pacote em saca-rolha (polarização circular) com a regra
relacional U. O pacote é uma lâmina (envelope gaussiano só ao longo do eixo de propagação), filtrado espectralmente
para conter só os modos vestidos da rede (sem gradientes e sem o conteúdo de célula da onda nua). Mede a velocidade de radar ao longo de x, y, z e a pureza de helicidade no fim, e compara com o
radar de onda longa (homogeneização) da mesma amostra. Coordenadas: só para preparar o pacote e medir o centroide.
Dinâmica: M1 ä = −d1ᵀ M2 d1 a com M1 = M2 = 1 (nenhuma coordenada).
"""
from __future__ import annotations

import math
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl

import b25_complexos as B
from malha import FACES_LOC


def _centros_faces(C):
    c = np.zeros((C.F, 3))
    for fl, (i, j, k) in enumerate(FACES_LOC):
        c[C.face_t[:, fl]] = C.Xt[:, [i, j, k]].mean(1)
    return c % C.L


def passa_baixa(K, X, lc, lmax, grau):
    """Filtro espectral p(K)X ≈ projetor nos modos com ω² ≤ lc (expansão de Chebyshev com núcleo de Jackson).
    Remove do pacote "nu" (mapa de de Rham da onda contínua) o conteúdo de alta frequência que não é o modo vestido
    da rede: com pesos U a onda plana nua não é autovetor, e o corretor local vem do próprio operador."""
    tc = 2 * lc / lmax - 1
    th = math.acos(max(-1.0, min(1.0, tc)))
    ks = np.arange(grau + 1)
    c = np.empty(grau + 1)
    c[0] = (math.pi - th) / math.pi
    c[1:] = -2 / math.pi * np.sin(ks[1:] * th) / ks[1:]
    a = math.pi / (grau + 2)
    g = ((grau + 2 - ks) * np.cos(ks * a) + np.sin(ks * a) / math.tan(a)) / (grau + 2)
    T0, T1 = X, (2 / lmax) * (K @ X) - X
    Y = c[0] * g[0] * T0 + c[1] * g[1] * T1
    for k in range(2, grau + 1):
        T0, T1 = T1, 2 * ((2 / lmax) * (K @ T1) - T1) - T0
        Y = Y + c[k] * g[k] * T1
    return Y


def pacote(C, K, eixo, m_k, sigma, dist, h=+1, ciclo_amostra=2, grau_filtro=120):
    L = C.L
    d = np.zeros(3); d[eixo] = 1.0
    t1, t2 = [np.eye(3)[j] for j in range(3) if j != eixo]
    k0 = 2 * math.pi * m_k / L[eixo] * d
    Q1, Q2 = C.onda_aresta(k0, t1), C.onda_aresta(k0, t2)
    xa = C.P[C.arestas[:, 0]]
    xm = (xa + 0.5 * C.vet_aresta) % L
    # envelope só ao longo do eixo (pacote em lâmina, plano nas direções transversais): nenhuma componente
    # transversal de k, logo o centroide anda com a velocidade de grupo ao longo do eixo
    centro = L[eixo] / 2
    r = xm[:, eixo] - centro
    r -= L[eixo] * np.round(r / L[eixo])
    G = np.exp(-r ** 2 / (2 * sigma ** 2))
    psi_nu = (Q1 + 1j * h * Q2) / math.sqrt(2) * G
    lmax = float(spl.eigsh(K, k=1, which="LA", return_eigenvectors=False, tol=1e-6)[0]) * 1.01
    # 1) tira a parte de gradiente (gauge: não tem energia magnética e deixaria energia elétrica parada)
    L0 = (C.d0.T @ C.d0).tocsc()
    L0 = (L0 + 1e-12 * spl.norm(L0) * sp.identity(C.N, format="csc")).tocsc()
    lu = spl.splu(L0)

    def sem_gradiente(z):
        return z - C.d0 @ lu.solve(C.d0.T @ z)

    psi = sem_gradiente(psi_nu.real) + 1j * sem_gradiente(psi_nu.imag)
    # 2) filtro: só os modos vestidos até 2,5× a frequência nua da onda
    w2_nu = float(np.real(np.vdot(psi, K @ psi)) / np.real(np.vdot(psi, psi)))
    Z = passa_baixa(K, np.stack([psi.real, psi.imag], 1), 2.5 ** 2 * w2_nu, lmax, grau_filtro)
    psi = sem_gradiente(Z[:, 0]) + 1j * sem_gradiente(Z[:, 1])
    retido = float(np.real(np.vdot(psi, psi)) / np.real(np.vdot(psi_nu, psi_nu)))
    w2 = float(np.real(np.vdot(psi, K @ psi)) / np.real(np.vdot(psi, psi)))
    w = math.sqrt(w2)
    a = np.real(psi).copy()
    v = np.real(-1j * w * psi).copy()
    dt = 0.5 / math.sqrt(lmax)
    v_est = w / np.linalg.norm(k0)
    T = dist / v_est
    ns = int(math.ceil(T / dt))
    cf = _centros_faces(C)
    fase_e = np.exp(2j * math.pi * xm[:, eixo] / L[eixo])
    fase_f = np.exp(2j * math.pi * cf[:, eixo] / L[eixo])

    def energia_e_centro(a, v):
        Cf = C.d1 @ a
        we, wf = 0.5 * v ** 2, 0.5 * Cf ** 2
        z = (we @ fase_e + wf @ fase_f) / (we.sum() + wf.sum())
        return float(we.sum() + wf.sum()), np.angle(z) * L[eixo] / (2 * math.pi)

    E0, x0 = energia_e_centro(a, v)
    ts, xs = [0.0], [x0]
    acc = -(K @ a)
    for s in range(1, ns + 1):
        v_meio = v + 0.5 * dt * acc
        a = a + dt * v_meio
        acc = -(K @ a)
        v = v_meio + 0.5 * dt * acc
        if s % ciclo_amostra == 0 or s == ns:
            E, x = energia_e_centro(a, v)
            ts.append(s * dt); xs.append(x)
    E1, _ = energia_e_centro(a, v)
    xs = np.unwrap(np.array(xs) * 2 * math.pi / L[eixo]) * L[eixo] / (2 * math.pi)
    ts = np.array(ts)
    sel = ts >= 0.25 * ts[-1]
    v_radar = float(np.polyfit(ts[sel], xs[sel], 1)[0])
    G2 = np.array([[np.vdot(Q1, Q1), np.vdot(Q1, Q2)], [np.vdot(Q2, Q1), np.vdot(Q2, Q2)]])
    c = np.linalg.solve(G2, np.array([np.vdot(Q1, a), np.vdot(Q2, a)]))
    cp, cm = (c[0] - 1j * c[1]) / math.sqrt(2), (c[0] + 1j * c[1]) / math.sqrt(2)
    pur = float(abs(cp) ** 2 / (abs(cp) ** 2 + abs(cm) ** 2)) if h > 0 else float(abs(cm) ** 2 / (abs(cp) ** 2 + abs(cm) ** 2))
    return {"eixo": "xyz"[eixo], "k0": float(np.linalg.norm(k0)), "k0_a": float(np.linalg.norm(k0) * (np.prod(L) / C.N) ** (1 / 3)),
            "omega_rayleigh": w, "v_fase_rayleigh": v_est, "omega_nu": math.sqrt(w2_nu), "fracao_retida_filtro": retido, "v_radar": v_radar, "T": float(ts[-1]), "passos": ns, "dt": dt,
            "deriva_energia": abs(E1 - E0) / E0, "pureza_helicidade_final": pur, "deslocamento": float(xs[-1] - xs[0])}


def rodar(cfg):
    out = {}
    t0 = time.time()
    rng = np.random.default_rng(cfg["semente"])
    f = B.familias(cfg["n"], cfg["s"], cfg["dmin"], rng)
    for nome, eixos in (("ani", (0, 1, 2)), ("iso", (0, 1))):
        C = f[nome]
        K = (C.d1.T @ C.d1).tocsr()
        ell, A, V = B.geometria(C)
        eps, nu, _ = B.homogeneizar(C, ell, A, V)
        hom = B.derivados(eps, nu)
        r = {"N": C.N, "E": C.E, "homogeneizacao": {k: hom[k] for k in ("v_x", "v_y", "v_z", "P", "eta_L", "birref_x")}}
        r["pacotes"] = []
        for e in eixos:
            p = pacote(C, K, e, cfg["m_k"], cfg["sigma"], cfg["distancia"], h=cfg["helicidade"])
            vh = hom["v_" + "xyz"[e]]
            w2 = B.fresnel(eps, nu, np.eye(3)[e])
            dv = abs(math.sqrt(w2[1]) - math.sqrt(w2[0]))
            p["v_radar_sobre_v_homog"] = p["v_radar"] / vh
            p["pureza_prevista_homog"] = float(math.cos(0.5 * p["k0"] * dv * p["T"]) ** 2)
            r["pacotes"].append(p)
            print(f"  B25-T {nome} eixo {'xyz'[e]}: v_radar={p['v_radar']:.4f} v_homog={vh:.4f} "
                  f"razão={p['v_radar_sobre_v_homog']:.4f} pureza={p['pureza_helicidade_final']:.5f} "
                  f"(prevista {p['pureza_prevista_homog']:.5f}) deriva E={p['deriva_energia']:.1e}", flush=True)
        vx = [p["v_radar"] for p in r["pacotes"] if p["eixo"] == "x"][0]
        if nome == "ani":
            vz = [p["v_radar"] for p in r["pacotes"] if p["eixo"] == "z"][0]
            r["eta_radar_direto"] = vz / vx
        out[nome] = r
    out["segundos"] = round(time.time() - t0, 1)
    return out
