# -*- coding: utf-8 -*-
"""
HRF B25 — complexos relacionais 3D.
  · famílias de GMFs (núcleo duro por adição sequencial aleatória, RSA) e o complexo de Delaunay periódico;
  · vetores de aresta e de área num referencial de ANÁLISE (as coordenadas não entram na dinâmica das regras
    relacionais; servem só para preparar sondas e exprimir resultados);
  · homogeneização exata da conexão (limite de onda longa = "radar de onda longa"): tensores ε (inércia das
    ligações, termo elétrico) e ν = μ⁻¹ (rigidez dos laços, termo de Wilson);
  · velocidades de Fresnel, índice de Plebanski (cone único) e geometria de saltos (distância no grafo).

Fatos usados [F]: um meio linear homogêneo com tensores ε e μ tem um único cone de luz (sem birrefringência, e então
equivale a uma métrica) se e só se μ ∝ ε (Plebanski 1960; de Felice 1971). As formas de Whitney reproduzem campos
uniformes exatamente, logo com pesos de Whitney ε = ν = 1 em qualquer malha (controle exato).
"""
from __future__ import annotations

import math

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spl
from scipy.optimize import least_squares
from scipy.sparse.csgraph import shortest_path

from malha import FACES_LOC, Complexo


# ============================================================================ famílias de GMFs
def rsa_nucleo_duro(N, caixa, dmin, rng, max_tent_por_ponto=400):
    """N pontos numa caixa periódica, nenhum par a menos de dmin (adição sequencial aleatória)."""
    caixa = np.asarray(caixa, float)
    if dmin <= 0:                                   # Poisson (sem núcleo duro)
        return rng.uniform(0.0, 1.0, size=(N, 3)) * caixa, N
    nc = np.maximum(np.floor(caixa / dmin).astype(int), 1)
    tam = caixa / nc
    grade = {}
    pts = np.empty((N, 3))
    n, tent = 0, 0
    d2 = dmin * dmin
    Lx, Ly, Lz = caixa
    vizinhos = [(dx, dy, dz) for dx in (-1, 0, 1) for dy in (-1, 0, 1) for dz in (-1, 0, 1)]
    while n < N:
        cand = rng.uniform(0.0, 1.0, size=(8192, 3)) * caixa
        for x, y, z in cand:
            tent += 1
            if tent > max_tent_por_ponto * N:
                raise RuntimeError(f"RSA não alcançou N = {N} (dmin = {dmin})")
            cx, cy, cz = int(x // tam[0]) % nc[0], int(y // tam[1]) % nc[1], int(z // tam[2]) % nc[2]
            ok = True
            celulas = {((cx + a) % nc[0], (cy + b) % nc[1], (cz + c) % nc[2]) for a, b, c in vizinhos}
            for cel in celulas:
                for j in grade.get(cel, ()):
                    px, py, pz = pts[j]
                    ddx = px - x; ddx -= Lx * round(ddx / Lx)
                    ddy = py - y; ddy -= Ly * round(ddy / Ly)
                    ddz = pz - z; ddz -= Lz * round(ddz / Lz)
                    if ddx * ddx + ddy * ddy + ddz * ddz < d2:
                        ok = False
                        break
                if not ok:
                    break
            if ok:
                pts[n] = (x, y, z)
                grade.setdefault((cx, cy, cz), []).append(n)
                n += 1
                if n == N:
                    break
    return pts, tent


def familias(n, s, dmin, rng):
    """Conjunto-base P0: núcleo duro isotrópico (densidade 1) numa caixa n × n × n/s.
    F-iso: Delaunay(P0) no próprio referencial.  F-aff: o MESMO complexo, analisado com z esticado por s.
    F-ani: Delaunay(P0 esticado em z por s): combinatória anisotrópica (nenhum referencial a torna isotrópica)."""
    caixa0 = np.array([n, n, n / s], float)
    N = int(round(n ** 3 / s))
    P0, tent = rsa_nucleo_duro(N, caixa0, dmin, rng)
    iso = Complexo(P0, caixa0)
    est = np.array([1.0, 1.0, s])
    ani = Complexo(P0 * est, caixa0 * est)
    return {"P0": P0, "iso": iso, "ani": ani, "esticamento": est, "tentativas_RSA": tent, "N": N}


# ============================================================================ geometria de análise
def geometria(C, S=None):
    """Vetores de aresta ℓ_e, vetores de área A_f (orientação da d1) e volume, no referencial de análise
    x' = S x (S diagonal)."""
    S = np.ones(3) if S is None else np.asarray(S, float)
    ell = C.vet_aresta * S
    X = C.Xt * S
    A = np.zeros((C.F, 3))
    for fl, (i, j, k) in enumerate(FACES_LOC):
        A[C.face_t[:, fl]] = 0.5 * np.cross(X[:, j] - X[:, i], X[:, k] - X[:, i])
    V = float(np.prod(C.L * S))
    return ell, A, V


def checar_stokes(C, ntet=200, rng=None):
    """Controle de convenção: para A(x) = ½ B0 × x, a circulação orientada pela d1 em cada face local deve ser B0·A_f."""
    rng = np.random.default_rng(0) if rng is None else rng
    B0 = rng.normal(size=3)
    idx = {e: k for k, e in enumerate([(0, 1), (0, 2), (0, 3), (1, 2), (1, 3), (2, 3)])}
    T = rng.choice(C.T, size=min(ntet, C.T), replace=False)
    pior = 0.0
    for t in T:
        X = C.Xt[t]
        for (a, b, c) in FACES_LOC:
            circ = 0.0
            for (p, q), s in (((b, c), 1.0), ((a, c), -1.0), ((a, b), 1.0)):
                xm = 0.5 * (X[p] + X[q])
                circ += s * 0.5 * np.cross(B0, xm) @ (X[q] - X[p])
            Af = 0.5 * np.cross(X[b] - X[a], X[c] - X[a])
            pior = max(pior, abs(circ - B0 @ Af) / (np.linalg.norm(B0) * np.linalg.norm(Af)))
    return pior


# ============================================================================ homogeneização (radar de onda longa)
def _cg(Aop, b, tol, maxiter, escala):
    """CG pré-condicionado (Jacobi) num sistema singular consistente. O resíduo é medido contra a ESCALA dos termos que
    se cancelam no lado direito (com pesos de Whitney o lado direito é zero a menos de arredondamento)."""
    d = Aop.diagonal()
    Mpre = sp.diags(1.0 / np.where(d > 0, d, 1.0))
    if np.linalg.norm(b) <= 1e-13 * escala:
        return np.zeros_like(b), float(np.linalg.norm(b) / escala)
    x, _ = spl.cg(Aop, b, rtol=tol, atol=tol * escala, maxiter=maxiter, M=Mpre)
    return x, float(np.linalg.norm(Aop @ x - b) / escala)


def homogeneizar(C, ell, A, V, M1=None, M2=None, tol=1e-12, maxiter=20000):
    """ε: min_ψ (ℓE0 + d0ψ)ᵀM1(ℓE0 + d0ψ)/V  (campo elétrico uniforme + corretor de potencial nos GMFs);
    ν: min_χ (A B0 + d1χ)ᵀM2(A B0 + d1χ)/V  (fluxo magnético uniforme + corretor nas ligações).
    M1 = M2 = identidade: regra relacional U (todas as relações no mesmo estado)."""
    d0, d1 = C.d0, C.d1
    M1 = sp.identity(C.E, format="csr") if M1 is None else M1
    M2 = sp.identity(C.F, format="csr") if M2 is None else M2
    L0 = (d0.T @ M1 @ d0).tocsr()
    K = (d1.T @ M2 @ d1).tocsr()
    Gh = ell.copy()
    rhs = -(d0.T @ (M1 @ ell))
    esc_e = abs(d0.T) @ (abs(M1) @ np.abs(ell))
    res = []
    for j in range(3):
        b = rhs[:, j] - rhs[:, j].mean()
        psi, r = _cg(L0, b, tol, maxiter, float(np.linalg.norm(esc_e[:, j])))
        res.append(r)
        Gh[:, j] += d0 @ psi
    eps = Gh.T @ (M1 @ Gh) / V
    Ah = A.copy()
    rhs = -(d1.T @ (M2 @ A))
    esc_m = abs(d1.T) @ (abs(M2) @ np.abs(A))
    for j in range(3):
        chi, r = _cg(K, rhs[:, j], tol, maxiter, float(np.linalg.norm(esc_m[:, j])))
        res.append(r)
        Ah[:, j] += d1 @ chi
    nu = Ah.T @ (M2 @ Ah) / V
    return (eps + eps.T) / 2, (nu + nu.T) / 2, max(res)


def _cruz(k):
    return np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])


def fresnel(eps, nu, khat):
    """Velocidades² dos dois modos transversais para a direção khat: −[k]×ν[k]× e = ω² ε e (|k| = 1)."""
    k = np.asarray(khat, float) / np.linalg.norm(khat)
    Nk = -_cruz(k) @ nu @ _cruz(k)
    Li = np.linalg.cholesky(eps)
    Linv = np.linalg.inv(Li)
    w = np.linalg.eigvalsh(Linv @ Nk @ Linv.T)
    return np.sort(w)[1:]                      # o menor é o longitudinal (zero)


DIRECOES = [(1, 0, 0), (0, 1, 0), (0, 0, 1), (1, 1, 0), (1, -1, 0), (1, 0, 1), (1, 0, -1), (0, 1, 1), (0, 1, -1),
            (1, 1, 1), (1, 1, -1), (1, -1, 1), (-1, 1, 1), (2, 1, 0), (1, 2, 0), (2, 0, 1), (1, 0, 2), (0, 2, 1), (0, 1, 2)]


def derivados(eps, nu):
    """Quantidades de decisão. P = birrefringência (em v²) para k ∥ x, forma uniaxial; B = índice de Plebanski geral."""
    e_p, n_p = (eps[0, 0] + eps[1, 1]) / 2, (nu[0, 0] + nu[1, 1]) / 2
    P = (eps[2, 2] * nu[2, 2]) / (e_p * n_p) - 1.0
    Le = np.linalg.cholesky(eps)
    X = Le.T @ nu @ Le
    lam = np.linalg.eigvalsh((X + X.T) / 2)
    B = float((lam[-1] - lam[0]) / lam.mean())
    vx = fresnel(eps, nu, (1, 0, 0))
    vy = fresnel(eps, nu, (0, 1, 0))
    vz = fresnel(eps, nu, (0, 0, 1))
    bir = [float((math.sqrt(w[1]) - math.sqrt(w[0])) / math.sqrt(w.mean())) for w in (fresnel(eps, nu, d) for d in DIRECOES)]
    return {"P": float(P), "B_plebanski": B,
            "v_x": float(math.sqrt(vx.mean())), "v_y": float(math.sqrt(vy.mean())), "v_z": float(math.sqrt(vz.mean())),
            "eta_L": float(math.sqrt(vz.mean() / vx.mean())),
            "birref_x": float((math.sqrt(vx[1]) - math.sqrt(vx[0])) / math.sqrt(vx.mean())),
            "birref_max_19dir": float(max(bir)),
            "aniso_plano_xy": float(abs(math.sqrt(vx.mean()) - math.sqrt(vy.mean())) / math.sqrt(vx.mean())),
            "eps": eps.tolist(), "nu": nu.tolist()}


# ============================================================================ geometria de saltos (grafo)
def geometria_saltos(C, S, semente_fontes, nfontes=20, hmin=3, frac=0.45):
    """Distância no grafo (número de ligações) a partir de nfontes GMFs; ajuste h ≈ √(a_x Δx² + a_y Δy² + a_z Δz²) + β
    (Δ no referencial de análise, mínima imagem). η_H = √(a_⊥/a_z) = (comprimento por salto em z)/(em x)."""
    N = C.N
    a, b = C.arestas[:, 0], C.arestas[:, 1]
    adj = sp.coo_matrix((np.ones(2 * C.E), (np.r_[a, b], np.r_[b, a])), shape=(N, N)).tocsr()
    adj.data[:] = 1.0
    fontes = np.random.default_rng(semente_fontes).choice(N, size=min(nfontes, N), replace=False)
    D = shortest_path(adj, unweighted=True, indices=fontes)
    S = np.asarray(S, float)
    Lb = C.L * S
    P = C.P * S
    dd, hh = [], []
    for i, s0 in enumerate(fontes):
        d = P - P[s0]
        d -= Lb * np.round(d / Lb)
        ok = (D[i] >= hmin) & np.all(np.abs(d) <= frac * Lb, axis=1)
        dd.append(d[ok]); hh.append(D[i, ok])
    dd, hh = np.concatenate(dd), np.concatenate(hh)

    def r(p):
        return np.sqrt(p[0] * dd[:, 0] ** 2 + p[1] * dd[:, 1] ** 2 + p[2] * dd[:, 2] ** 2) + p[3] - hh

    f = least_squares(r, x0=[1.0, 1.0, 1.0, 0.0], bounds=([1e-8, 1e-8, 1e-8, -20], [1e3, 1e3, 1e3, 20]))
    ax, ay, az, beta = f.x
    return {"a_x": float(ax), "a_y": float(ay), "a_z": float(az), "beta": float(beta),
            "eta_H": float(math.sqrt(0.5 * (ax + ay) / az)), "aniso_plano_xy_H": float(abs(math.sqrt(ax / ay) - 1)),
            "rms_resid": float(np.sqrt(np.mean(f.fun ** 2))), "n_pares": int(len(hh))}
