# -*- coding: utf-8 -*-
"""
HRF B25 — orquestrador.  Uso:  python -I rodar_B25.py fumaca|completo  [pasta_saida]
"fumaca": só verifica o código (tamanhos mínimos); números NÃO valem como resultado.
"completo": rodada pré-registrada; só depois do "pode rodar" do pesquisador.
"""
from __future__ import annotations

import json
import os
import platform
import sys
import time
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))

import numpy as np            # noqa: E402
import scipy                  # noqa: E402

import b25q_triangulos as Q   # noqa: E402
import b25r_relacional as R   # noqa: E402
import b25t_radar_direto as T  # noqa: E402

CONFIG = {
    "completo": {
        "B25R": {"tamanhos": [12, 16, 20, 24], "sementes": 10, "s": 2.0, "dmin": 0.8, "semente_base": 20262500,
                 "N_Poisson": {"n": 16, "sementes": 10, "semente_base": 20262600},
                 "X2_dose": {"n": 16, "sementes": 5, "semente_base": 20262700, "casos": [[0.4, 2.0], [0.6, 2.0], [0.8, 1.5]]}},
        "B25Q": {"S": [1, 2, 3], "lambdas": [0.2, 0.1, 0.05], "controle_sem_sinal": [[2, 0.1], [2, 0.05]]},
        "B25T": {"n": 40, "s": 2.0, "dmin": 0.8, "semente": 20262800, "m_k": 2, "sigma": 6.0, "distancia": 12.0,
                 "helicidade": 1},
    },
    "fumaca": {
        "B25R": {"tamanhos": [8, 10], "sementes": 2, "s": 2.0, "dmin": 0.8, "semente_base": 20262500,
                 "N_Poisson": {"n": 8, "sementes": 2, "semente_base": 20262600},
                 "X2_dose": {"n": 8, "sementes": 1, "semente_base": 20262700, "casos": [[0.4, 2.0]]}},
        "B25Q": {"S": [1], "lambdas": [0.1], "controle_sem_sinal": [[1, 0.1]]},
        "B25T": {"n": 12, "s": 2.0, "dmin": 0.8, "semente": 20262800, "m_k": 1, "sigma": 2.5, "distancia": 3.0,
                 "helicidade": 1},
    },
}


def main():
    modo = sys.argv[1] if len(sys.argv) > 1 else "fumaca"
    assert modo in CONFIG
    pasta = Path(sys.argv[2]) if len(sys.argv) > 2 else AQUI.parent / ("fumaca" if modo == "fumaca" else "resultados")
    pasta.mkdir(parents=True, exist_ok=True)
    cfg = CONFIG[modo]
    meta = {"modo": modo, "inicio": time.strftime("%Y-%m-%d %H:%M:%S"), "python": platform.python_version(),
            "numpy": np.__version__, "scipy": scipy.__version__, "maquina": platform.platform(), "nucleos": os.cpu_count()}
    json.dump({"meta": meta, "config": cfg}, open(pasta / "B25_config.json", "w"), ensure_ascii=False, indent=1)
    print(f"HRF B25 — modo {modo} — {meta['inicio']}", flush=True)
    t0 = time.time()
    print("B25-Q — anéis em triângulos (diagonalização exata)", flush=True)
    json.dump(Q.rodar(cfg["B25Q"]), open(pasta / "B25Q.json", "w"), ensure_ascii=False, indent=1)
    print("B25-R — pesos relacionais, radar de onda longa, cone único (bloco principal)", flush=True)
    json.dump(R.rodar(cfg["B25R"]), open(pasta / "B25R.json", "w"), ensure_ascii=False, indent=1)
    print("B25-T — radar direto com pacote em saca-rolha (exploratório)", flush=True)
    json.dump(T.rodar(cfg["B25T"]), open(pasta / "B25T.json", "w"), ensure_ascii=False, indent=1)
    meta["fim"] = time.strftime("%Y-%m-%d %H:%M:%S")
    meta["segundos_total"] = round(time.time() - t0, 1)
    json.dump({"meta": meta, "config": cfg}, open(pasta / "B25_config.json", "w"), ensure_ascii=False, indent=1)
    print(f"fim — {meta['segundos_total']} s", flush=True)


if __name__ == "__main__":
    main()
