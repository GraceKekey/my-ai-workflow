# -*- coding: utf-8 -*-
"""Teste do avaliador da B25 com dados SINTÉTICOS (inventados, não são resultados): só confere que as regras rodam e
que cada ramo de decisão é alcançável. Uso: python -I teste_avaliador_sintetico_B25.py"""
import sys
from pathlib import Path

import numpy as np

sys.path.insert(0, str(Path(__file__).resolve().parent))
import avaliar_B25 as AV  # noqa: E402


def amostra(n, P_ani, G_ani, rng, P_iso_sd=0.002, ok=True, s=2.0):
    def U(P, eta):
        return {"P": P, "eta_L": eta, "residuo_cg": 1e-12 if ok else 1e-3, "birref_max_19dir": abs(P) / 2 + 1e-4}
    pi = float(rng.normal(0, P_iso_sd))
    eta_iso = 1.0 + float(rng.normal(0, 0.003))
    return {"n": n, "s": s, "stokes_max": 1e-15,
            "iso": {"d1_ell_max": 0.0, "U": U(pi, eta_iso), "W": {"desvio_eps_I": 1e-15, "desvio_nu_I": 1e-9, "eta_L": 1.0},
                    "saltos": {"eta_H": eta_iso}, "G_luz_sobre_saltos": 1.0 + float(rng.normal(0, 0.005))},
            "aff": {"d1_ell_max": 0.0, "U": U(pi, eta_iso * s), "saltos": {"eta_H": eta_iso * s}},
            "ani": {"d1_ell_max": 0.0, "U": U(P_ani + float(rng.normal(0, 0.002)), 1.12),
                    "W": {"desvio_eps_I": 1e-15, "desvio_nu_I": 1e-9, "eta_L": 1.0},
                    "saltos": {"eta_H": 1.1}, "G_luz_sobre_saltos": G_ani + float(rng.normal(0, 0.005))}}


def fake_R(P_ani, G_ani, seed=1, ok=True):
    rng = np.random.default_rng(seed)
    principal = [amostra(n, P_ani, G_ani, rng, ok=ok) for n in (12, 16, 20, 24) for _ in range(10)]
    poisson = [{"ani": {"U": {"P": float(rng.normal(0, 0.002)), "eta_L": 1.0 + float(rng.normal(0, 0.003))}}} for _ in range(10)]
    return {"principal": principal, "N_Poisson": poisson, "X2_dose": []}


def fake_Q(tri=0.999, grosso=False):
    casos = []
    for S in (1, 2, 3):
        for lam in (0.2, 0.1, 0.05):
            r3 = 0.5 if (grosso and lam == 0.05) else (1 - 0.5 * lam ** 2 if tri > 0.99 else tri)
            casos.append({"S": S, "lambda": lam, "residuo_autovetores": 1e-12, "g_min_sobreposicao": 0.99, "gap_sobre_2V": 0.9,
                          "laco_3": {"razao_media": r3, "razao_min": r3 - 1e-4, "razao_max": r3 + 1e-4},
                          "laco_4": {"razao_media": 1 - 0.5 * lam}, "razao_dJ": 1 - 0.3 * lam ** 2, "residuo_fora_dos_lacos": 0.01})
    ctl = [{"lambda": 0.05, "lacos_frustrados_por_comprimento": {"3": 4}, "laco_4": {"razao_media": 0.99}}]
    return {"casos": casos, "controle_sem_sinal": ctl}


for nome, (P, G) in {"cone único/uma geometria": (0.0, 1.0), "birrefringente/duas geometrias": (0.03, 1.2),
                     "fraca/indefinido": (0.003, 1.04)}.items():
    a = AV.avaliar_R(fake_R(P, G))
    print(f"R sintético [{nome}] → R1: {a['R1_cone_unico']} | R2: {a['R2_luz_e_saltos']}")
print("R sintético [resíduo ruim] →", AV.avaliar_R(fake_R(0.0, 1.0, ok=False))["R1_cone_unico"])
print("Q sintético →", AV.avaliar_Q(fake_Q())["decisao"], "|", AV.avaliar_Q(fake_Q(grosso=True))["decisao"], "|",
      AV.avaliar_Q(fake_Q(tri=0.95))["decisao"])
