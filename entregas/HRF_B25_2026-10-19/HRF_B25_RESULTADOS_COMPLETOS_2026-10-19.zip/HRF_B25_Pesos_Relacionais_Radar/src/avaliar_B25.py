# -*- coding: utf-8 -*-
"""
HRF B25 — avaliador com as regras PRÉ-REGISTRADAS (escrito antes de qualquer saída da rodada completa).
Uso: python -I avaliar_B25.py [pasta_resultados] → grava avaliacao_B25.json. O bloco T é exploratório (só relato).
"""
from __future__ import annotations

import json
import math
import sys
from pathlib import Path

import numpy as np
from scipy import stats


def ic(x, nivel=0.95):
    x = np.asarray(x, float)
    m = float(x.mean())
    if x.size < 2:
        return m, m, m
    h = float(stats.t.ppf(0.5 + nivel / 2, x.size - 1) * x.std(ddof=1) / math.sqrt(x.size))
    return m, m - h, m + h


def inclinacao(xs, ys):
    return float(np.polyfit(np.log(np.asarray(xs, float)), np.log(np.abs(np.asarray(ys, float))), 1)[0])


# ----------------------------------------------------------------------------- B25-R
def avaliar_R(r):
    A = r["principal"]
    ns = sorted({a["n"] for a in A})
    nmin, nmax = ns[0], ns[-1]
    # validade
    V1 = all(a["stokes_max"] <= 1e-12 and max(a[f]["d1_ell_max"] for f in ("iso", "aff", "ani")) <= 1e-10 for a in A)
    V2 = all(max(a[f]["W"]["desvio_eps_I"], a[f]["W"]["desvio_nu_I"]) <= 1e-6 for a in A for f in ("iso", "ani"))
    V3 = all(a[f]["U"]["residuo_cg"] <= 1e-8 for a in A for f in ("iso", "aff", "ani"))
    s = A[0]["s"]
    V4 = all(abs(a["aff"]["U"]["P"] - a["iso"]["U"]["P"]) <= 1e-9 and
             abs(a["aff"]["U"]["eta_L"] / a["iso"]["U"]["eta_L"] - s) <= 1e-9 * s and
             abs(a["aff"]["saltos"]["eta_H"] / a["iso"]["saltos"]["eta_H"] - s) <= 1e-3 * s for a in A)
    NP = r["N_Poisson"]
    mP, lP, hP = ic([a["ani"]["U"]["P"] for a in NP], 0.99)
    mE, lE, hE = ic([a["ani"]["U"]["eta_L"] for a in NP], 0.99)
    V5 = (lP <= 0 <= hP) and (lE >= 0.97) and (hE <= 1.03)
    iso_max = [a["iso"]["U"]["P"] for a in A if a["n"] == nmax]
    mi, li, hi = ic(iso_max, 0.99)
    V6 = li <= 0 <= hi
    validade = {"V1_stokes_e_d1": V1, "V2_whitney_exato": V2, "V3_residuo_cg": V3, "V4_invariancia_afim": V4,
                "V5_N_Poisson": V5, "V6_iso_nulo": V6,
                "N_Poisson": {"P_99": [mP, lP, hP], "eta_L_99": [mE, lE, hE]}, "iso_P_99_nmax": [mi, li, hi]}
    # R1: cone único (F-ani, U)
    porn = {}
    for n in ns:
        P = [a["ani"]["U"]["P"] for a in A if a["n"] == n]
        Pi = [a["iso"]["U"]["P"] for a in A if a["n"] == n]
        G = [a["ani"]["G_luz_sobre_saltos"] for a in A if a["n"] == n]
        Gi = [a["iso"]["G_luz_sobre_saltos"] for a in A if a["n"] == n]
        porn[n] = {"P_ani": ic(P), "P_iso": ic(Pi), "G_ani": ic(G), "G_iso": ic(Gi),
                   "eta_L_ani": ic([a["ani"]["U"]["eta_L"] for a in A if a["n"] == n]),
                   "eta_H_ani": ic([a["ani"]["saltos"]["eta_H"] for a in A if a["n"] == n]),
                   "birref_max_ani": ic([a["ani"]["U"]["birref_max_19dir"] for a in A if a["n"] == n]),
                   "birref_max_iso": ic([a["iso"]["U"]["birref_max_19dir"] for a in A if a["n"] == n]),
                   "eta_L_W_ani": ic([a["ani"]["W"]["eta_L"] for a in A if a["n"] == n])}
    m1, l1, h1 = porn[nmax]["P_ani"]
    m0 = porn[nmin]["P_ani"][0]
    if not all((V1, V2, V3, V4, V5, V6)):
        R1 = "INCONCLUSIVO"
    elif (l1 <= 0 <= h1) and (h1 - m1) <= 0.01:
        R1 = "CONE ÚNICO"
    elif not (l1 <= 0 <= h1) and abs(m1) >= 0.005 and abs(m1) >= 0.5 * abs(m0) and np.sign(m1) == np.sign(m0):
        R1 = "BIRREFRINGENTE"
    elif not (l1 <= 0 <= h1) and abs(m1) < 0.005:
        R1 = "BIRREFRINGÊNCIA FRACA"
    else:
        R1 = "INDEFINIDO"
    # R2: uma geometria? (luz × saltos)
    g, gl, gh = porn[nmax]["G_ani"]
    gi, gil, gih = porn[nmax]["G_iso"]
    if R1 == "INCONCLUSIVO" or not (gil >= 0.95 and gih <= 1.05):
        R2 = "INCONCLUSIVO"
    elif gl >= 0.97 and gh <= 1.03:
        R2 = "UMA GEOMETRIA"
    elif gh < 0.95 or gl > 1.05:
        R2 = "DUAS GEOMETRIAS"
    else:
        R2 = "INDEFINIDO"
    return {"R1_cone_unico": R1, "R2_luz_e_saltos": R2, "validade": validade,
            "por_tamanho": {str(n): v for n, v in porn.items()},
            "inclinacao_P_ani_vs_N": inclinacao([n ** 3 / s for n in ns], [porn[n]["P_ani"][0] for n in ns]),
            "inclinacao_birref_iso_vs_N": inclinacao([n ** 3 / s for n in ns], [porn[n]["birref_max_iso"][0] for n in ns]),
            "X2_dose": _x2(r["X2_dose"])}


def _x2(X):
    out = {}
    for chave in sorted({(a["dmin"], a["s"]) for a in X}):
        sel = [a for a in X if (a["dmin"], a["s"]) == chave]
        out[f"dmin={chave[0]} s={chave[1]}"] = {"P_ani": ic([a["ani"]["U"]["P"] for a in sel]),
                                                "eta_L_ani": ic([a["ani"]["U"]["eta_L"] for a in sel]),
                                                "G_ani": ic([a["ani"]["G_luz_sobre_saltos"] for a in sel])}
    return out


# ----------------------------------------------------------------------------- B25-Q
def avaliar_Q(q):
    casos = q["casos"]
    Ss = sorted({c["S"] for c in casos})
    Q0 = all(c["residuo_autovetores"] <= 1e-8 and c["g_min_sobreposicao"] >= 0.5 for c in casos if c["lambda"] <= 0.2)
    Q1 = all(c["gap_sobre_2V"] >= 0.5 for c in casos if c["lambda"] <= 0.2)
    Q2 = Q3 = Q4 = True
    grosso = False
    por = {}
    for S in Ss:
        cs = {c["lambda"]: c for c in casos if c["S"] == S}
        c5 = cs[0.05]
        t3, t4 = c5["laco_3"], c5["laco_4"]
        ok2 = (abs(t3["razao_media"] - 1) <= 0.03 and (t3["razao_max"] - t3["razao_min"]) <= 0.03 and
               abs(t4["razao_media"] - 1) <= 0.05 and abs(c5["razao_dJ"] - 1) <= 0.03)
        ls = [0.2, 0.1, 0.05]
        d3 = [abs(cs[l]["laco_3"]["razao_media"] - 1) for l in ls]
        dj = [abs(cs[l]["razao_dJ"] - 1) for l in ls]
        p3 = inclinacao(ls, d3) if max(d3) >= 1e-7 else float("inf")
        pj = inclinacao(ls, dj) if max(dj) >= 1e-7 else float("inf")
        ok3 = p3 >= 1.5 and pj >= 1.5
        ok4 = c5["residuo_fora_dos_lacos"] <= 0.05
        if not (0.8 <= t3["razao_media"] <= 1.2):
            grosso = True
        Q2 &= ok2; Q3 &= ok3; Q4 &= ok4
        por[f"S={S}"] = {"tri_0.05": t3["razao_media"], "quad_0.05": t4["razao_media"], "dJ_0.05": c5["razao_dJ"],
                         "ordem_tri": p3, "ordem_dJ": pj, "residuo_0.05": c5["residuo_fora_dos_lacos"]}
    ss = {c["lambda"]: c for c in q["controle_sem_sinal"]}
    c5 = ss[0.05]
    N1 = (c5["lacos_frustrados_por_comprimento"].get("3", 0) == 4 and "laco_3" not in c5 and
          "laco_4" in c5 and abs(c5["laco_4"]["razao_media"] - 1) <= 0.05)
    if not Q0:
        dec = "INCONCLUSIVO"
    elif grosso:
        dec = "NÃO EMERGE"
    elif Q1 and Q2 and Q3 and Q4 and N1:
        dec = "EMERGE"
    else:
        dec = "PARCIAL"
    return {"decisao": dec, "Q0": Q0, "Q1": Q1, "Q2": Q2, "Q3": Q3, "Q4": Q4, "N1_sem_sinal": N1, "por_S": por}


def main():
    pasta = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "resultados"
    r = json.load(open(pasta / "B25R.json"))
    q = json.load(open(pasta / "B25Q.json"))
    t = json.load(open(pasta / "B25T.json"))
    aR, aQ = avaliar_R(r), avaliar_Q(q)
    out = {"B25R": aR, "B25Q": aQ,
           "B25T_exploratorio": {k: {"eta_radar_direto": v.get("eta_radar_direto"),
                                     "pacotes": [{kk: p[kk] for kk in ("eixo", "v_radar_sobre_v_homog", "pureza_helicidade_final",
                                                                       "pureza_prevista_homog", "deriva_energia")}
                                                 for p in v["pacotes"]],
                                     "eta_L_homog": v["homogeneizacao"]["eta_L"]}
                                 for k, v in t.items() if isinstance(v, dict) and "pacotes" in v}}
    json.dump(out, open(pasta / "avaliacao_B25.json", "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps({"R1": aR["R1_cone_unico"], "R2": aR["R2_luz_e_saltos"], "Q": aQ["decisao"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
