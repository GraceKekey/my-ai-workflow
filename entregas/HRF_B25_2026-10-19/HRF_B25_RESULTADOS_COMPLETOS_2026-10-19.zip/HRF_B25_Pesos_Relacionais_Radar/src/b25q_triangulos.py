# -*- coding: utf-8 -*-
"""
HRF B25-Q (secundário) — o anel de Wilson emerge também em laços TRIANGULARES (os laços mínimos da Delaunay)?
Mesmo modelo microscópico da B23a, sem invariância de gauge:  H = V Σ_I Q_I² − Γ Σ_e S^x_e.
Complexo: superfície do tetraedro (K₄: 4 GMFs, 6 ligações, 4 triângulos, 3 quadriláteros).
Previsões: triângulo −(3/16)Γ³/V²·Π√(…) (3ª ordem); quadrilátero −(5/32)Γ⁴/V³·Π√(…) (4ª ordem); δJ = Γ²/(4V).
Controle: conservação sem sinal (grafo não bipartido) → triângulos frustrados (sem anel), quadriláteros com anel.
Reaproveita b23_modelo.py da B23 (cópia idêntica; hash no pacote).
"""
from __future__ import annotations

import math
import time

import numpy as np

import b23_modelo as M


def ciclos(N, pares, Lmax=4):
    adj = {i: set() for i in range(N)}
    for a, b in pares:
        adj[a].add(b); adj[b].add(a)
    vistos, out = set(), []

    def dfs(c):
        if len(c) >= 3 and c[0] in adj[c[-1]]:
            rots = [tuple(c[i:] + c[:i]) for i in range(len(c))]
            rots += [r[::-1] for r in rots]
            m = min(rots)
            if m not in vistos:
                vistos.add(m); out.append(list(m))
        if len(c) == Lmax:
            return
        for w in sorted(adj[c[-1]]):
            if w > c[0] and w not in c:
                dfs(c + [w])

    for s in range(N):
        dfs([s])
    return out


def tetraedro():
    pares = [(a, b) for a in range(4) for b in range(a + 1, 4)]
    cs = ciclos(4, pares)
    return M.Complexo("tetraedro", 4, pares, M._faces_de_ciclos(pares, cs))


def analisar_por_laco(Heff, mP, cx, S, V, Gam, incid):
    d = Heff.shape[0]
    pads = M.padroes_de_laco(cx, incid)
    chave = {tuple(r): i for i, r in enumerate(mP.tolist())}
    por_n = {}
    usados = np.zeros((d, d), bool)
    escala = 0.0
    frustrados = {}
    for f, v in pads:
        nlen = len(cx.faces[f])
        if v is None:
            frustrados[nlen] = frustrados.get(nlen, 0) + 1
            continue
        c = M.coef_anel(nlen) * Gam ** nlen / V ** (nlen - 1)
        es = np.nonzero(v)[0]
        for i in range(d):
            for sgn in (+1, -1):
                alvo = mP[i] + sgn * v
                if np.any(np.abs(alvo) > S):
                    continue
                j = chave.get(tuple(alvo.tolist()))
                if j is None:
                    continue
                pred = c * np.prod(M.ME(S, mP[i, es].astype(float), sgn * v[es]))
                escala = max(escala, abs(pred))
                por_n.setdefault(nlen, []).append(Heff[j, i] / pred)
                usados[i, j] = usados[j, i] = True
    fora = Heff.copy()
    np.fill_diagonal(fora, 0.0)
    fora[usados] = 0.0
    s2 = (mP.astype(float) ** 2).sum(1)
    coef, *_ = np.linalg.lstsq(np.stack([np.ones(d), s2], 1), np.diag(Heff), rcond=None)
    out = {"razao_dJ": float(coef[1] / M.dJ_efetivo(Gam, V)),
           "residuo_fora_dos_lacos": float(np.abs(fora).max() / escala) if escala > 0 else float("nan"),
           "lacos_frustrados_por_comprimento": {str(k): v for k, v in frustrados.items()}}
    for nlen, rs in por_n.items():
        rs = np.array(rs)
        out[f"laco_{nlen}"] = {"n_elementos": int(rs.size), "razao_media": float(rs.mean()),
                               "razao_min": float(rs.min()), "razao_max": float(rs.max())}
    return out


def caso(S, lam, sem_sinal=False, V=1.0):
    t0 = time.time()
    cx = tetraedro()
    Gam = lam * V / math.sqrt(S * (S + 1))
    incid = np.abs(cx.d0) if sem_sinal else cx.d0
    H, m, Qtot = M.h_micro(cx, S, V, Gam, incid=incid)
    P = M.espaco_P(m, incid)
    d = len(P)
    w, Yb, res = M.autoespaco_baixo(H, d, extra=4, Pidx=P, corte=V)
    Heff, gmin = M.des_cloizeaux(H, Yb, P)
    out = {"S": S, "lambda": lam, "Gamma": Gam, "sem_sinal": sem_sinal, "dim_total": int(H.shape[0]), "dim_P": d,
           "residuo_autovetores": res, "g_min_sobreposicao": gmin, "gap_sobre_2V": float((w[d] - w[d - 1]) / (2 * V)),
           **analisar_por_laco(Heff, m[P], cx, S, V, Gam, incid), "segundos": round(time.time() - t0, 1)}
    return out


def rodar(cfg):
    res = {"casos": [], "controle_sem_sinal": []}
    for S in cfg["S"]:
        for lam in cfg["lambdas"]:
            r = caso(S, lam)
            res["casos"].append(r)
            print(f"  B25-Q tetra S={S} λ={lam}: dimP={r['dim_P']} tri={r.get('laco_3', {}).get('razao_media', float('nan')):.5f} "
                  f"quad={r.get('laco_4', {}).get('razao_media', float('nan')):.5f} dJ={r['razao_dJ']:.5f} ({r['segundos']} s)", flush=True)
    for (S, lam) in cfg["controle_sem_sinal"]:
        r = caso(S, lam, sem_sinal=True)
        res["controle_sem_sinal"].append(r)
        print(f"  B25-Q sem sinal S={S} λ={lam}: frustrados={r['lacos_frustrados_por_comprimento']} "
              f"quad={r.get('laco_4', {}).get('razao_media', float('nan')):.5f}", flush=True)
    return res
