# -*- coding: utf-8 -*-
"""
HRF B25-R (bloco principal) — pesos a partir do estado das relações, radar de onda longa e isotropia.

Regras de peso:
  U  relacional: todas as relações no mesmo estado (Levin–Wen em ordem dominante: δJ igual em toda ligação, K igual em
     todo triângulo) → M1 = 1, M2 = 1. NENHUMA coordenada entra.
  W  controle de coordenadas: pesos de Whitney a partir das posições dos GMFs (leitura (a), Cap. 2).
Famílias (mesmo conjunto-base de GMFs): F-iso (Delaunay isotrópico), F-aff (o mesmo complexo, z esticado só no
referencial de análise), F-ani (Delaunay do conjunto esticado: combinatória anisotrópica).
Radar de onda longa: homogeneização exata → ε, ν → velocidades de Fresnel. Cone único ⇔ ν ∝ ε⁻¹ (Plebanski).
"""
from __future__ import annotations

import time

import numpy as np

import b25_complexos as B


def amostra(n, s, dmin, semente, com_W=True):
    t0 = time.time()
    rng = np.random.default_rng(semente)
    f = B.familias(n, s, dmin, rng)
    iso, ani, est = f["iso"], f["ani"], f["esticamento"]
    out = {"n": n, "s": s, "dmin": dmin, "semente": semente, "N": f["N"], "E_iso": iso.E, "E_ani": ani.E,
           "tentativas_RSA": f["tentativas_RSA"]}
    out["stokes_max"] = max(B.checar_stokes(iso), B.checar_stokes(ani))
    sf = semente + 7
    for nome, C, S in (("iso", iso, None), ("aff", iso, est), ("ani", ani, None)):
        ell, A, V = B.geometria(C, S)
        r = {"d1_ell_max": float(np.abs(C.d1 @ ell).max())}
        eps, nu, res = B.homogeneizar(C, ell, A, V)
        r["U"] = B.derivados(eps, nu)
        r["U"]["residuo_cg"] = res
        if com_W and nome != "aff":
            M1, M2 = C.matrizes()
            eW, nW, resW = B.homogeneizar(C, ell, A, V, M1, M2)
            r["W"] = {"desvio_eps_I": float(np.abs(eW - np.eye(3)).max()), "desvio_nu_I": float(np.abs(nW - np.eye(3)).max()),
                      "residuo_cg": resW, **{k: v for k, v in B.derivados(eW, nW).items() if k in ("P", "eta_L", "B_plebanski")}}
        r["saltos"] = B.geometria_saltos(C, est if nome == "aff" else np.ones(3), sf)
        r["G_luz_sobre_saltos"] = r["U"]["eta_L"] / r["saltos"]["eta_H"]
        out[nome] = r
    out["segundos"] = round(time.time() - t0, 1)
    return out


def rodar(cfg):
    res = {"principal": [], "N_Poisson": [], "X2_dose": []}
    for n in cfg["tamanhos"]:
        for i in range(cfg["sementes"]):
            sem = cfg["semente_base"] + 100 * n + i
            a = amostra(n, cfg["s"], cfg["dmin"], sem)
            res["principal"].append(a)
            print(f"  B25-R n={n} sem={sem} N={a['N']}: P_ani={a['ani']['U']['P']:+.5f} P_iso={a['iso']['U']['P']:+.5f} "
                  f"ηL_ani={a['ani']['U']['eta_L']:.4f} ηH_ani={a['ani']['saltos']['eta_H']:.4f} ({a['segundos']} s)", flush=True)
    c = cfg["N_Poisson"]
    for i in range(c["sementes"]):
        sem = c["semente_base"] + i
        a = amostra(c["n"], cfg["s"], 0.0, sem, com_W=False)
        res["N_Poisson"].append(a)
    print(f"  B25-R N-Poisson feito ({len(res['N_Poisson'])} amostras)", flush=True)
    x = cfg["X2_dose"]
    for (dmin, s) in x["casos"]:
        for i in range(x["sementes"]):
            sem = x["semente_base"] + int(1000 * dmin) + int(10 * s) * 7 + i
            a = amostra(x["n"], s, dmin, sem, com_W=False)
            res["X2_dose"].append(a)
        print(f"  B25-R X2 dmin={dmin} s={s} feito", flush=True)
    return res
