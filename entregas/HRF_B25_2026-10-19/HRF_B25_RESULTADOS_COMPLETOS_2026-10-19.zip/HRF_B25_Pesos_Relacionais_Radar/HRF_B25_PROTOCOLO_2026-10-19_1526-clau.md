# HRF B25 — Pesos a partir do estado das relações, distância de radar e isotropia da luz
## Protocolo pré-registrado

**Data:** 19 de outubro de 2026, 15h26 (America/Sao_Paulo) — Claude (`-clau`) · fluxo ímpar
**Ramo:** HRF-FM, Capítulo 2 (onda fotônica livre), com interface ao HRF-ST (distância e geometria emergentes).
**Estado:** escrito **antes** da rodada completa. Só a fumaça (tamanhos mínimos, números descartados) e uma
cronometragem (números não impressos) foram executadas. A rodada completa só será disparada depois do
"pode rodar" de Mario.
**Antecedentes:** `HRF_Nota_LevinWen_Reducao_Baixa_Energia_PT_2026-10-19_1105-clau.md` (§5) e B23 (pré-registrada, ainda
não rodada). A B25 não depende do resultado da B23.

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 0. Contexto e decisões

Conversa de 19/10 (11h25–14h42), depois da nota Levin–Wen:
- O GMF corresponde ao **vértice** de Levin–Wen e o rotor à **ligação** (a relação). O fóton já vivia nas relações no
  Capítulo 2; Levin–Wen explicam por que elas se comportam como conexão U(1) com energia de Wilson.
- Fundir os dois não gera conflito no setor do fóton, mas deixa quatro pontos de atrito: posições/pesos, conectividade
  que muda, o estado local q_n e a leitura (b).
- Opção mais compatível com a emergência holográfica [H]: **tirar a propriedade das coordenadas e pô-la no estado das
  relações**. Pesos e distâncias são função do estado de cada relação; a distância física é definida pela luz
  (radar); ligações não somem, esmaecem; q_n é carga relacional (no bulk) ou carga global (na fronteira).
- **[D] Mario, 19/10 14h42:** a B25 tem como bloco principal o teste "pesos a partir do estado da relação, distância de
  radar: a luz fica isotrópica?".

## 1. Objetivo

Testar se, **sem nenhuma coordenada na dinâmica**, a luz de um substrato relacional define **uma única geometria**
consistente: um só cone de luz (sem birrefringência), que dá a distância de radar, e verificar se essa geometria
coincide com a geometria do próprio grafo (distância em número de saltos).

O caso não trivial é um grafo **deformado** (combinatória anisotrópica), modelo de uma região onde as relações foram
esticadas, como perto de matéria. Na Relatividade Geral, a luz numa região deformada continua com um só cone (a
gravidade age como métrica, não como cristal birrefringente [F]). A pergunta é se o substrato relacional faz o mesmo.

| Bloco | Pergunta | Estatuto |
|---|---|---|
| **B25-R** | Com pesos relacionais (todas as relações no mesmo estado), a luz num grafo deformado tem cone único? A geometria da luz é a do grafo? | **principal** |
| **B25-Q** | O anel de Wilson emerge também em laços triangulares (os laços mínimos da Delaunay), com o coeficiente previsto? | secundário |
| **B25-T** | Radar direto: o tempo de voo de um pacote em saca-rolha confirma a velocidade de radar de onda longa? | exploratório |

## 2. Hipóteses e previsões (escritas antes)

**B25-R.**
- **H-R0 [F].** Com pesos de Whitney (W, a partir das coordenadas), ε = ν = 1 exatamente em qualquer malha (as formas de
  Whitney reproduzem campos uniformes): a luz de W lê as coordenadas.
- **H-R0' [F].** Com pesos relacionais (U), a luz só depende da combinatória: esticar as coordenadas sem mudar o grafo
  (F-aff) não muda nada físico (P idêntico; η_L multiplicado exatamente pelo esticamento).
- **H-R1 [?] (a pergunta).** Num grafo de combinatória anisotrópica (F-ani), a regra U dá cone único (ν ∝ ε⁻¹,
  condição de Plebanski) ou birrefringência sistemática? **Não há previsão direcional.** Para um complexo isotrópico
  esticado de forma afim, uma conta ingênua sem corretores dá cone único exato; F-ani não é afim-equivalente a um
  complexo isotrópico, e os corretores locais entram. Os dois resultados são informativos (§8).
- **H-R2 [?].** A geometria da luz coincide com a geometria de saltos do grafo? Em redes regulares não coincide (na
  rede cúbica a distância de saltos é a de Manhattan [F]); em Delaunay de Poisson a forma assintótica dos saltos é
  uma esfera [F, Vahidi-Asl & Wierman 1990]. Em F-ani, sem previsão.

**B25-Q.** Mesma teoria de perturbação da nota: triângulo −(3/16)Γ³/V²·Π√(S(S+1) − m(m±1)), quadrilátero
−(5/32)Γ⁴/V³·Π√(…), δJ = Γ²/(4V); correções O(λ²). Conservação sem sinal num grafo não bipartido: triângulos
frustrados (sem anel), quadriláteros com anel.

**B25-T.** v_radar/v_homog = 1 a menos de efeitos de comprimento de onda finito e da componente retrógrada (espera-se
dentro de ~3%); pureza de helicidade ≥ 0,99 se o cone for único.

## 3. Parâmetros

**Famílias (B25-R).** Conjunto-base P0: núcleo duro isotrópico, distância mínima d_min = 0,8, densidade 1, caixa
periódica n × n × n/s, N = n³/s GMFs, gerado por adição sequencial aleatória (RSA).
- **F-iso:** Delaunay(P0) no próprio referencial.
- **F-aff:** o mesmo complexo de F-iso, analisado com z multiplicado por s (controle de invariância).
- **F-ani:** Delaunay(P0 com z multiplicado por s), cubo n: combinatória anisotrópica.
s = 2. n ∈ {12, 16, 20, 24} (N = 864 … 6 912). 10 sementes por tamanho: 20262500 + 100·n + i, i = 0…9.
Fontes para a geometria de saltos: semente da amostra + 7 (as mesmas em F-iso e F-aff).

**Regras de peso.** U (relacional): M1 = 1 (mesmo δJ em toda ligação), M2 = 1 (mesmo K em todo triângulo), Levin–Wen em
ordem dominante. W (controle de coordenadas): Whitney.

**Controles extras.** N-Poisson: d_min = 0 (Poisson), s = 2, n = 16, 10 sementes (20262600 + i): esticar Poisson dá
Poisson, logo F-ani é estatisticamente isotrópico.
**Exploratório X2 (dose):** n = 16, 5 sementes (20262700 + 1000·d_min + 70·s + i): (d_min, s) ∈ {(0,4; 2), (0,6; 2), (0,8; 1,5)}.

**B25-Q.** Superfície do tetraedro (K₄: 4 GMFs, 6 ligações, 4 triângulos, 3 quadriláteros). V = 1;
λ = Γ√(S(S+1))/V ∈ {0,2; 0,1; 0,05}; S ∈ {1, 2, 3}. Controle sem sinal: S = 2, λ ∈ {0,1; 0,05}.

**B25-T.** n = 40, s = 2, d_min = 0,8, semente 20262800. F-ani: eixos x, y, z; F-iso (caixa 40 × 40 × 20): x, y.
Pacote em lâmina (envelope gaussiano só ao longo do eixo, σ = 6), polarização circular h = +1 (saca-rolha),
k₀ = 2π·2/L, distância percorrida 12; filtro espectral de Chebyshev (grau 120) e projeção sem gradientes.

## 4. Protocolo

1. `python -I src/rodar_B25.py completo` → `resultados/B25Q.json`, `B25R.json`, `B25T.json`, `B25_config.json`.
2. `python -I src/avaliar_B25.py resultados` → `resultados/avaliacao_B25.json`.
3. Figuras e relatório depois da avaliação; nada disso muda as decisões.

**Radar de onda longa (B25-R).** Para cada amostra e regra, homogeneização exata da conexão na caixa periódica:
- ε: min_ψ (ℓE₀ + d₀ψ)ᵀM1(ℓE₀ + d₀ψ)/V (campo elétrico uniforme mais corretor de potencial nos GMFs);
- ν = μ⁻¹: min_χ (A B₀ + d₁χ)ᵀM2(A B₀ + d₁χ)/V (fluxo uniforme mais corretor nas ligações);
- velocidades de Fresnel (−[k]×ν[k]× e = ω²εe) em 19 direções.
ℓ_e e A_f (vetores de aresta e de área) vêm do referencial de análise e servem só para exprimir um campo uniforme; a
dinâmica U não usa coordenadas. Na caixa periódica, este é o limite exato k → 0 da dispersão [F]. A validação contra
os autovalores verdadeiros foi feita na fumaça: os 8 modos mais baixos de uma amostra F-iso n = 24 caíram em
ω/k = 0,571–0,582, contra 0,578 da homogeneização.

**Geometria de saltos.** Menor número de ligações (busca em largura) a partir de 20 GMFs; ajuste
h ≈ √(a_x Δx² + a_y Δy² + a_z Δz²) + β nos pares com h ≥ 3 e |Δ_i| ≤ 0,45 L_i.

## 5. Medidas

- **P** (birrefringência para k ∥ x, em v²): P = (ε_zz ν_zz)/(ε_⊥ ν_⊥) − 1, ⊥ = média de xx e yy. P = 0 ⇔ cone único na
  simetria uniaxial (Plebanski).
- **B** (índice de Plebanski geral): dispersão relativa dos autovalores de ε^{1/2} ν ε^{1/2}.
- birrefringência máxima em 19 direções; v_x, v_y, v_z; **η_L = v_z/v_x** (anisotropia da luz no referencial de análise).
- **η_H = √(a_⊥/a_z)** (comprimento por salto em z sobre em x) e **G = η_L/η_H** (G = 1: a luz e o grafo dão a mesma
  geometria).
- Validade: Stokes (convenção de orientação), d₁ℓ = 0, ε_W = ν_W = 1, resíduos do CG, invariância afim.

## 6. Regras de decisão (congeladas; implementadas em `src/avaliar_B25.py`)

**Validade da B25-R** (se qualquer uma falhar: R1 e R2 = **INCONCLUSIVO**):
- V1: Stokes ≤ 10⁻¹² e |d₁ℓ| ≤ 10⁻¹⁰ em todas as amostras;
- V2: |ε_W − 1|, |ν_W − 1| ≤ 10⁻⁶ (F-iso e F-ani);
- V3: resíduo do CG (regra U) ≤ 10⁻⁸;
- V4: invariância afim: |P_aff − P_iso| ≤ 10⁻⁹; η_L,aff/η_L,iso = s a 10⁻⁹; η_H,aff/η_H,iso = s a 10⁻³;
- V5 N-Poisson: IC 99% de P contém 0 e IC 99% de η_L dentro de [0,97; 1,03];
- V6 nulo isotrópico: IC 99% de P em F-iso, n = 24, contém 0.

**R1 — cone único (F-ani, regra U, n = 24; IC 95% t de Student, 10 sementes):**
- **CONE ÚNICO:** o IC de P contém 0 e tem meia-largura ≤ 0,01;
- **BIRREFRINGENTE:** o IC exclui 0, |P̄| ≥ 0,005, |P̄(24)| ≥ 0,5·|P̄(12)| e o mesmo sinal;
- **BIRREFRINGÊNCIA FRACA:** o IC exclui 0 e |P̄| < 0,005;
- **INDEFINIDO:** qualquer outro caso.

**R2 — uma geometria? (F-ani, regra U, n = 24):** controle: o IC 95% de G em F-iso tem de estar em [0,95; 1,05], senão
**INCONCLUSIVO**.
- **UMA GEOMETRIA:** IC de G ⊂ [0,97; 1,03];
- **DUAS GEOMETRIAS:** IC de G inteiramente fora de [0,95; 1,05];
- **INDEFINIDO:** qualquer outro caso.

**B25-Q** (como a B23a):
- Q0 (validade): resíduo ≤ 10⁻⁸ e g_min ≥ 0,5 para λ ≤ 0,2, senão **INCONCLUSIVO**.
- Q1: gap/2V ≥ 0,5.
- Q2 (λ = 0,05):
  - triângulo: |razão − 1| ≤ 0,03 e espalhamento ≤ 0,03;
  - quadrilátero: |razão − 1| ≤ 0,05;
  - δJ: |razão − 1| ≤ 0,03.
- Q3: ordem ≥ 1,5 (triângulo e δJ).
- Q4: resíduo fora dos laços ≤ 0,05.
- N1 (sem sinal, λ = 0,05): os 4 triângulos frustrados, nenhum anel de 3 ligações, quadriláteros com razão a ±5%.

Decisão: **EMERGE** se Q1–Q4 e N1 passam; **NÃO EMERGE** se a razão do triângulo em λ = 0,05 cair fora de [0,8; 1,2];
senão **PARCIAL**.

**B25-T:** exploratório, sem decisão; relata v_radar/v_homog, η do radar direto e a pureza de helicidade contra a
prevista pela homogeneização.

## 7. Controles e o que cada um protege

| Controle | Previsão | Protege contra |
|---|---|---|
| Stokes local; d₁ℓ = 0 | identidades | erro de orientação dos laços ou das imagens periódicas |
| W em F-iso e F-ani | ε = ν = 1 exato | erro nos vetores de área, na d₁ ou no corretor |
| F-aff × F-iso (U) | P idêntico; η exatamente × s | a regra U estar lendo coordenadas escondidas |
| N-Poisson | P ≈ 0; η ≈ 1 | anisotropia criada pelo método e não pela combinatória |
| F-iso (nulo) | P ≈ 0 | viés estatístico do estimador |
| B25-Q sem sinal | triângulos frustrados | a regra do laço (U(1) × Z₂) |

## 8. O que cada resultado significaria (escrito antes)

| R1 / R2 | Leitura [H] |
|---|---|
| CONE ÚNICO + UMA GEOMETRIA | o grafo relacional define uma só geometria, e a luz a lê; "distância = relação" funciona até em regiões deformadas |
| CONE ÚNICO + DUAS GEOMETRIAS | a luz define uma geometria consistente, mas contar saltos não dá essa geometria: a distância física tem de ser a de radar |
| BIRREFRINGENTE | relações num só estado não bastam num grafo deformado: ou a combinatória tem de ser estatisticamente isotrópica (princípio de seleção), ou o estado das relações tem de responder à combinatória local (B27: regra Γ_e a partir da estrutura local) |
| BIRREFRINGÊNCIA FRACA | efeito sistemático pequeno; avaliar contra os limites de birrefringência do vácuo e de birrefringência gravitacional |

> **Analogia.** É examinar o mesmo tecido com dois métodos: o ultrassom (a luz, que mede tempo de voo) e a contagem
> de células ao microscópio (os saltos no grafo). A primeira pergunta é se o ultrassom dá uma imagem única, sem
> "eco duplo" (birrefringência). A segunda é se a imagem do ultrassom bate com a contagem de células.

## 9. Fumaça e cronometragem (não valem como resultado)

`rodar_B25.py fumaca` (15h14, 7 s): B25-Q em S = 1 e λ = 0,1; B25-R com n = 8 e 10, 2 sementes; B25-T com n = 12.
Serviu para verificar que o código roda, as convenções (Stokes e W exatos), a invariância afim e o caminho de todos os
blocos. Teste do avaliador com dados sintéticos: todos os ramos alcançados. Cronometragem dos maiores casos sem
imprimir números. Detalhes em `FUMACA_B25.md`.

**Mudanças no código feitas durante a fumaça, antes deste congelamento (declaradas):**
1. Resíduo do CG medido contra a escala dos termos que se cancelam; com Whitney o lado direito é zero a menos de
   arredondamento, e o resíduo relativo ao próprio lado direito explodia.
2. Fontes da geometria de saltos com semente fixa por amostra (as mesmas em F-iso e F-aff), para a invariância afim
   ser exata.
3. B25-T: o pacote "nu" (mapa de de Rham da onda contínua com envelope 3D) não serve como sonda com pesos U. Ele tem
   ~1% de amplitude em modos de célula, que carregam energia comparável à da onda, e o envelope 3D mistura direções
   (o centroide andava a ~0,87 v). Troquei por pacote em lâmina, filtrado espectralmente e sem gradientes; o radar
   direto ficou a 1–3% da homogeneização numa amostra de teste n = 24 (não decisiva).
4. Validação da homogeneização contra autovalores verdadeiros (uma amostra F-iso n = 24, semente de teste 11, fora do
   conjunto pré-registrado): 8 modos a ω/k = 0,571–0,582 contra 0,578 previsto.

## 10. Limites declarados

- F-ani é um modelo de **deformação** do grafo, não do vácuo: o vácuo real já é limitado a uma isotropia
  extraordinária (B8, B3).
- A regra U é Levin–Wen em ordem dominante. As correções de 4ª ordem (acoplamento entre triângulos vizinhos e termos
  elétricos entre ligações vizinhas) ficam para depois.
- A homogeneização mede o limite de onda longa (k → 0). Dispersão de rede e espalhamento por desordem ficam fora da
  decisão (B25-T é só ilustrativo).
- B25-Q não inclui o octaedro: com S = 1 o setor sem cargas tem 495 estados num espaço de 531 441, e a iteração de
  subespaço passaria da memória desta máquina.
- ħ entra nas relações de comutação (B25-Q); a B25 não deriva ħ.
- Bulk 3D. A leitura (b) (fronteira 2D) não é testada aqui (nota, §5.4).

## 11. Custo estimado

Nuvem desta sessão (2 núcleos, 7 GB). B25-R: ~13 s por amostra em n = 24, ~5 min no total. B25-Q: S = 3 domina
(~12 min por λ, ~35 min). B25-T: alguns minutos. Total estimado: 45–60 min.

## 12. Arquivos

`src/b25_complexos.py`, `src/b25r_relacional.py`, `src/b25q_triangulos.py`, `src/b25t_radar_direto.py`, `src/rodar_B25.py`,
`src/avaliar_B25.py`, `src/teste_avaliador_sintetico_B25.py`, `src/malha.py` (cópia idêntica da bancada C5A
curl-curl emergente), `src/b23_modelo.py` (cópia idêntica da B23), `fumaca/`, `FUMACA_B25.md`, `LEIAME_B25.md`,
`hashes_antes_da_execucao.txt`.

## Referências

- J. Plebanski, Phys. Rev. 118, 1396 (1960); F. de Felice, Gen. Rel. Grav. 2, 347 (1971) — meio ↔ métrica.
- S. Vahidi-Asl, J. C. Wierman, *First-passage percolation on the Voronoi tessellation and Delaunay triangulation*
  (1990) — forma esférica das bolas de saltos.
- T. Konopka, F. Markopoulou, S. Severini, Phys. Rev. D 77, 104029 (2008) — *quantum graphity*.
- C. Cao, S. Carroll, S. Michalakis, Phys. Rev. D 95, 024031 (2017) — espaço a partir do espaço de Hilbert.
- A. Bossavit (1998); D. Arnold, R. Falk, R. Winther (2006) — formas de Whitney e cálculo exterior discreto.
- M. Levin, X.-G. Wen, Rev. Mod. Phys. 77, 871 (2005).
