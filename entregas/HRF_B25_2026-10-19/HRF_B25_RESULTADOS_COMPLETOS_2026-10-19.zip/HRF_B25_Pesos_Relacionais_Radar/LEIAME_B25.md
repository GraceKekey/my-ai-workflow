# LEIAME — HRF B25 (pesos relacionais, distância de radar e isotropia da luz)

**Estado deste pacote (19 out 2026):** protocolo pré-registrado + código + fumaça. **A rodada completa ainda não foi
executada**; aguarda o "pode rodar" de Mario.

## O que é

Bancada do fluxo ímpar (HRF-FM, Cap. 2, com interface ao HRF-ST). Pergunta principal: **com pesos que dependem só do
estado das relações (nenhuma coordenada), a luz define uma única geometria, mesmo num grafo deformado?**

- **B25-R (principal):** homogeneização exata da conexão (radar de onda longa) em três famílias de complexos de
  Delaunay: F-iso, F-aff (controle) e F-ani (combinatória deformada). Regras U (relacional) e W (Whitney, controle).
  Mede o cone único (condição de Plebanski, P) e compara a geometria da luz com a geometria de saltos do grafo (G).
- **B25-Q (secundário):** o anel de Wilson emerge em triângulos com −(3/16)Γ³/V²? (diagonalização exata no tetraedro)
- **B25-T (exploratório):** radar direto com pacote em saca-rolha.

## Como rodar

```bash
python -I src/rodar_B25.py completo      # 45–60 min em 2 núcleos; grava resultados/
python -I src/avaliar_B25.py resultados  # regras congeladas → resultados/avaliacao_B25.json
```
Requer Python ≥ 3.10, numpy, scipy. Integridade: `hashes_antes_da_execucao.txt`.

## Arquivos

| Arquivo | Conteúdo |
|---|---|
| `HRF_B25_PROTOCOLO_2026-10-19_1526-clau.md` | protocolo, hipóteses, regras de decisão |
| `hashes_antes_da_execucao.txt` | SHA-256 do protocolo e do código, antes da rodada completa |
| `src/b25_complexos.py` | famílias (RSA), geometria de análise, homogeneização, Fresnel, geometria de saltos |
| `src/b25r_relacional.py`, `src/b25q_triangulos.py`, `src/b25t_radar_direto.py` | os três blocos |
| `src/rodar_B25.py`, `src/avaliar_B25.py` | orquestrador e avaliador |
| `src/teste_avaliador_sintetico_B25.py` | teste do avaliador com dados inventados |
| `src/malha.py` | complexo de Delaunay periódico e formas de Whitney (cópia idêntica da bancada C5A curl-curl emergente) |
| `src/b23_modelo.py` | Hamiltoniano microscópico e des Cloizeaux (cópia idêntica da B23) |
| `fumaca/`, `FUMACA_B25.md` | fumaça (números descartados) |
