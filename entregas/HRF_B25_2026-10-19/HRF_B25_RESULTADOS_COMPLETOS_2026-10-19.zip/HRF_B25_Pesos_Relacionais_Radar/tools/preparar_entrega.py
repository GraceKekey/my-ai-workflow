"""Reports only: frozen scientific code and evaluator remain unchanged."""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import csv
import hashlib
import json
import os
import platform
import re
import sys
import zipfile

ROOT=Path(__file__).resolve().parents[1]
os.environ.setdefault('MPLCONFIGDIR',str(ROOT/'.cache/matplotlib'))
os.environ.setdefault('XDG_CACHE_HOME',str(ROOT/'.cache'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
import scipy


def load(name):return json.loads((ROOT/'resultados'/name).read_text())
def save(path,value):path.write_text(json.dumps(value,ensure_ascii=False,indent=2,allow_nan=False)+'\n')
def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def csv_write(path,rows):
    with path.open('w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)


def coverage(r,q,t,cfg):
    checks={}
    rc=cfg['B25R'];qc=cfg['B25Q'];tc=cfg['B25T']
    want={(n,rc['semente_base']+100*n+i) for n in rc['tamanhos'] for i in range(rc['sementes'])}
    got={(a['n'],a['semente']) for a in r['principal']}
    checks['R_principal_40_sementes']=got==want and len(r['principal'])==len(want)
    checks['R_poisson_10_sementes']={a['semente'] for a in r['N_Poisson']}=={rc['N_Poisson']['semente_base']+i for i in range(rc['N_Poisson']['sementes'])} and len(r['N_Poisson'])==10
    wantdose={(d,s,rc['X2_dose']['semente_base']+int(1000*d)+int(10*s)*7+i) for d,s in rc['X2_dose']['casos'] for i in range(rc['X2_dose']['sementes'])}
    checks['R_dose_15_sementes']={(a['dmin'],a['s'],a['semente']) for a in r['X2_dose']}==wantdose and len(r['X2_dose'])==15
    checks['Q_9_casos']={(a['S'],a['lambda']) for a in q['casos']}=={(s,l) for s in qc['S'] for l in qc['lambdas']} and len(q['casos'])==9
    checks['Q_2_controles']={(a['S'],a['lambda']) for a in q['controle_sem_sinal']}=={tuple(x) for x in qc['controle_sem_sinal']} and len(q['controle_sem_sinal'])==2
    checks['T_5_eixos']=([p['eixo'] for p in t['ani']['pacotes']]==['x','y','z'] and [p['eixo'] for p in t['iso']['pacotes']]==['x','y'])
    checks['T_tamanho']=(t['ani']['N']==t['iso']['N']==round(tc['n']**3/tc['s']))
    hashes={}
    for line in (ROOT/'hashes_antes_da_execucao.txt').read_text().splitlines():
        m=re.fullmatch(r'([0-9a-fA-F]{64})\s+\*?(.+)',line)
        if m:hashes[m[2]]=digest(ROOT/m[2])==m[1].lower()
    checks['10_hashes_preservados']=len(hashes)==10 and all(hashes.values())
    checks['execucao_completa_registrada']=bool(load('B25_config.json')['meta'].get('fim'))
    out={'checks':checks,'source_hashes':hashes,'passed':all(checks.values()),
         'meaning':'Coverage/integrity checks, not scientific PASS.'}
    save(ROOT/'resultados/CONFERENCIA_COBERTURA.json',out)
    if not out['passed']:raise RuntimeError('Incomplete run or changed preregistration; preserve all files and investigate')
    return out


def main():
    r,q,t=load('B25R.json'),load('B25Q.json'),load('B25T.json')
    ev=load('avaliacao_B25.json');run=load('B25_config.json');cfg=run['config']
    cov=coverage(r,q,t,cfg)
    csvdir=ROOT/'tabelas';csvdir.mkdir(exist_ok=True)
    figs=ROOT/'figuras';figs.mkdir(exist_ok=True)
    rows=[]
    for kind in ('principal','N_Poisson','X2_dose'):
        for a in r[kind]:
            for fam in ('iso','aff','ani'):
                f=a[fam];u=f['U'];w=f.get('W',{})
                rows.append(dict(bloco=kind,n=a['n'],semente=a['semente'],N=a['N'],s=a['s'],dmin=a['dmin'],familia=fam,
                                 P=u['P'],B_plebanski=u['B_plebanski'],v_x=u['v_x'],v_y=u['v_y'],v_z=u['v_z'],eta_L=u['eta_L'],eta_H=f['saltos']['eta_H'],G=f['G_luz_sobre_saltos'],birref_max=u['birref_max_19dir'],residuo_cg=u['residuo_cg'],stokes=a['stokes_max'],d1_ell=f['d1_ell_max'],W_desvio_eps=w.get('desvio_eps_I'),W_desvio_nu=w.get('desvio_nu_I')))
    csv_write(csvdir/'B25R_todas_amostras.csv',rows)
    qr=[]
    for key in ('casos','controle_sem_sinal'):
        for c in q[key]:
            tri=c.get('laco_3',{});quad=c.get('laco_4',{})
            qr.append(dict(tipo=key,S=c['S'],lambda_=c['lambda'],dim_total=c['dim_total'],dim_P=c['dim_P'],tri_razao=tri.get('razao_media'),tri_min=tri.get('razao_min'),tri_max=tri.get('razao_max'),quad_razao=quad.get('razao_media'),dJ_razao=c['razao_dJ'],residuo=c['residuo_autovetores'],g_min=c['g_min_sobreposicao'],gap_sobre_2V=c['gap_sobre_2V'],residuo_fora_lacos=c['residuo_fora_dos_lacos'],segundos=c['segundos']))
    csv_write(csvdir/'B25Q_casos.csv',qr)
    tr=[]
    for fam in ('ani','iso'):
        for p in t[fam]['pacotes']:tr.append(dict(familia=fam,**p))
    csv_write(csvdir/'B25T_pacotes.csv',tr)
    ns=sorted(int(n) for n in ev['B25R']['por_tamanho'])
    by=ev['B25R']['por_tamanho']
    for metric,label,filename in [('P','P — desvio do cone único','B25R_cone.png'),('G','G — geometria da luz / saltos','B25R_geometrias.png')]:
        fig,ax=plt.subplots(figsize=(7,4.5))
        for fam in ('ani','iso'):
            vals=np.array([by[str(n)][metric+'_'+fam] for n in ns])
            ax.errorbar(ns,vals[:,0],yerr=np.array([vals[:,0]-vals[:,1],vals[:,2]-vals[:,0]]),marker='o',capsize=4,label=f'F-{fam}, IC 95% t')
        ax.axhline(0 if metric=='P' else 1,color='black',ls='--',lw=1)
        if metric=='G':ax.axhspan(.97,1.03,color='green',alpha=.08,label='faixa [0, 97;1,03]')
        ax.set(xlabel='n (N=n³/2)',ylabel=label,title='B25-R — rodada completa [M]');ax.legend();fig.tight_layout();fig.savefig(figs/filename,dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,3,figsize=(12,4))
    for S in cfg['B25Q']['S']:
        sel=sorted((c for c in q['casos'] if c['S']==S),key=lambda c:c['lambda'])
        for ax,key in zip(axs,['laco_3','laco_4','razao_dJ']):
            ax.plot([c['lambda'] for c in sel],[c[key]['razao_media'] if isinstance(c[key],dict) else c[key] for c in sel],'-o',label=f'S={S}')
    for ax,title in zip(axs,['Triângulos','Quadriláteros','δJ']):
        ax.axhline(1,color='k',ls='--');ax.set(xlabel='λ',ylabel='razão / previsão',title=title);ax.legend()
    fig.suptitle('B25-Q — coeficientes efetivos [M]');fig.tight_layout();fig.savefig(figs/'B25Q_razoes.png',dpi=180);plt.close(fig)
    fig,axs=plt.subplots(1,2,figsize=(10,4))
    labels=[row['familia']+'-'+row['eixo'] for row in tr]
    axs[0].bar(labels,[row['v_radar_sobre_v_homog'] for row in tr]);axs[0].axhline(1,color='k',ls='--');axs[0].set(ylabel='v_radar / v_homog',title='Radar direto (exploratório)')
    axs[1].plot(labels,[row['pureza_helicidade_final'] for row in tr],'o',label='medida');axs[1].plot(labels,[row['pureza_prevista_homog'] for row in tr],'x',label='prevista');axs[1].axhline(.99,color='k',ls='--');axs[1].set(ylabel='Pureza na base do código',title='Diagnóstico de polarização');axs[1].legend()
    fig.tight_layout();fig.savefig(figs/'B25T_radar.png',dpi=180);plt.close(fig)
    R=ev['B25R'];Q=ev['B25Q'];nmax=str(max(ns));final=R['por_tamanho'][nmax]
    def interval(v):return f"{v[0]:.8g} [{v[1]:.8g}; {v[2]:.8g}]"
    checks='\n'.join(f'- {k}: `{v}`.' for k,v in R['validade'].items() if k.startswith('V'))
    qt='\n'.join(f"| {key} | {v['tri_0.05']:.8g} | {v['quad_0.05']:.8g} | {v['dJ_0.05']:.8g} | {v['ordem_tri']:.6g} | {v['ordem_dJ']:.6g} |" for key,v in Q['por_S'].items())
    tt='\n'.join(f"| {v['familia']} | {v['eixo']} | {v['v_radar_sobre_v_homog']:.8g} | {v['pureza_helicidade_final']:.8g} | {v['pureza_prevista_homog']:.8g} | {v['deriva_energia']:.5g} |" for v in tr)
    report=f'''# HRF B25 — relatório da rodada completa

## Resultado do avaliador congelado [M]

- B25-R, R1 (cone único): **{R['R1_cone_unico']}**.
- B25-R, R2 (luz × saltos): **{R['R2_luz_e_saltos']}**.
- B25-Q: **{Q['decisao']}**.
- B25-T: **exploratório**, sem decisão confirmatória pré-registrada.

Essas são as saídas literais do avaliador fornecido, sem ajuste de critérios após os resultados. São resultados de toy model [M], não demonstração de geometria física universal, de um elétron ou de um fóton individual.

## Execução, integridade e cobertura [D/M]

Comando: `python -I src/rodar_B25.py completo`, seguido de `python -I src/avaliar_B25.py resultados`.
Foram concluídas 40 amostras principais de R, 10 controles N-Poisson, 15 amostras exploratórias de dose, 9 casos Q mais 2 controles sem sinal, e 5 pacotes T.
Cobertura e os 10 hashes originais: ver `resultados/CONFERENCIA_COBERTURA.json` (passou: {cov['passed']}). Nenhum arquivo científico pré-registrado foi editado. Dados em `fumaca/` e o teste sintético são separados dos resultados completos.
Início/fim do orquestrador, no fuso America/Sao_Paulo: {run['meta']['inicio']} / {run['meta']['fim']}. Tempo medido: {run['meta']['segundos_total']} s.
Python {platform.python_version()}, NumPy {np.__version__}, SciPy {scipy.__version__}; quota de 4 CPUs, 32 GiB e 4 threads BLAS. Os tempos podem diferir da estimativa original. Resultados gravados apenas neste ambiente; sem publicação no GitHub.

## B25-R — controles e medidas

{checks}

Em n={nmax}, IC 95% t de Student (média [inferior; superior]):

- P em F-ani: {interval(final['P_ani'])}.
- P em F-iso: {interval(final['P_iso'])}.
- G em F-ani: {interval(final['G_ani'])}.
- G em F-iso: {interval(final['G_iso'])}.
- η_L em F-ani: {interval(final['eta_L_ani'])}.
- η_H em F-ani: {interval(final['eta_H_ani'])}.

Leitura dos limiares: R1 usa o IC de P e a magnitude da média para distinguir cone único, birrefringência fraca e os demais ramos. R2 exige que o IC de G fique todo dentro de [0,97;1,03] para UMA GEOMETRIA, ou todo fora de [0,95;1,05] para DUAS GEOMETRIAS. Um IC que indique desvio de G=1 pode continuar INDEFINIDO por esses limiares pré-registrados; significância estatística não substitui a regra de decisão.

Os IC 99% dos controles, as inclinações entre tamanhos, o índice geral de Plebanski, as 19 direções e a dose exploratória permanecem nos JSON/CSV. As figuras não redefinem os gates. Se algum controle invalidar a decisão, o rótulo INCONCLUSIVO deve ser respeitado; tendências brutas não o substituem.

## B25-Q — anéis de baixa energia

| Spin | Triângulo λ=0,05 | Quadrilátero | δJ | Ordem triângulo | Ordem δJ |
|---|---:|---:|---:|---:|---:|
{qt}

Controles congelados: {json.dumps({k:v for k,v in Q.items() if k not in ('por_S','decisao')},ensure_ascii=False)}.
Todos os casos e controles, inclusive desvios da previsão e resíduos, estão preservados em B25Q.json e B25Q_casos.csv.

[?] O caminho denso do código original (D≤7000) registra resíduo 0 sem calcular um diagnóstico independente de norma. Essa convenção original foi preservada; não se apresenta o zero como resíduo numericamente medido. No caminho esparso, o código calcula o resíduo normalizado descrito no protocolo. O avaliador foi aplicado como fornecido.

## B25-T — radar direto, sem decisão confirmatória

| Família | Eixo | v_radar/v_homog | Pureza final | Pureza prevista | Deriva E |
|---|---|---:|---:|---:|---:|
{tt}

O código mede um pacote em lâmina filtrado, com helicidade configurada h=+1; não constitui uma varredura de ambas as helicidades. Os resultados não substituem o teste principal no limite k→0. A projeção/filtro, os passos e as estimativas de velocidade permanecem no código original e nos JSON. O estimador de λ_max em T chama eigsh sem fixar explicitamente v0; portanto, mesmo com a semente geométrica registrada, não se promete reprodução bit a bit dos passos e diagnósticos entre execuções. A deriva E fornecida é a diferença entre energia final e inicial, não o máximo da deriva em todos os instantes.

[F/D] Convenção adicional a preservar na leitura: o código escolhe t1 e t2 pela ordem cartesiana dos eixos restantes. Para propagação em +y, t1=x e t2=z, portanto t1×t2=-y. Assim, o rótulo h=+1 da configuração não é uma convenção de helicidade física com a mesma mão relativa a +k em todos os eixos. A pureza acima é o diagnóstico na base escolhida pelo código; a fonte congelada não foi corrigida ou reorientada nesta execução. Isso limita a leitura da helicidade de T, sem alterar as decisões R ou Q do avaliador.

Concordância de velocidades e alta pureza durante esta janela finita não aprovam automaticamente a condição de cone único. R1 mantém sua decisão estatística independente, com as amostras e os controles do bloco R.

## Interpretação e limites

[M] As classificações acima respondem às hipóteses operacionais da bancada com a regra U (massas unitárias) e seus controles W. [H/?] Uma leitura ontológica do substrato ou uma equivalência com geometria física requer trabalho adicional. A homogeneização é de onda longa, a malha é congelada, as correções microscópicas de ordem superior não foram incluídas e ħ continua uma entrada.
[D] Não houve mudança de limiares, substituição de amostras ou promoção de testes de fumaça a resultados completos. Não se apagaram resultados negativos. As decisões completas e todos os controles constam no JSON original do avaliador.

## Arquivos

`src/` e protocolo: originais; `resultados/`: saídas completas e avaliação; `logs/`: execução e teste sintético; `tabelas/`: CSV derivados; `figuras/`: gráficos derivados; `tools/`: preparação da entrega. O manifesto desta entrega permite conferir os arquivos. Os relatórios não exigem acesso a GitHub, Drive ou repositório externo.
'''
    (ROOT/'RELATORIO_CIENTIFICO_B25.md').write_text(report)
    (ROOT/'LEIA_PRIMEIRO_RESULTADOS.md').write_text(f'''# B25 — resultados locais

R1: {R['R1_cone_unico']}; R2: {R['R2_luz_e_saltos']}; Q: {Q['decisao']}. T é exploratório.

Comece por RELATORIO_CIENTIFICO_B25.md e resultados/avaliacao_B25.json. A decisão foi tomada pelo avaliador original sem editar critérios. Confira resultados/CONFERENCIA_COBERTURA.json e MANIFEST_SHA256_ENTREGA.json.

O pacote inclui protocolo, código original, dados, figuras e relatório. Para reproduzir em outra máquina: Python≥3.10, numpy e scipy; as versões desta execução estão em requirements_execucao.txt. Use uma cópia nova da pasta e preserve resultados existentes antes de executar novamente os comandos do LEIAME_B25.md. Não use fumaca/ como resultado completo.

Os resultados foram gravados localmente, sem publicação no GitHub. Criar e verificar o ZIP confirma o arquivo no ambiente, não confirma que a interface do chat o disponibilizou como anexo baixável.
''')
    start=json.loads((ROOT/'EXECUTION_PROVENANCE_START.json').read_text())
    finish={'finished':datetime.now(ZoneInfo('America/Sao_Paulo')).isoformat(),'source_hashes_match_start':all(digest(ROOT/name)==sha for name,sha in start['source_hashes'].items()),'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'matplotlib':matplotlib.__version__,'coverage_passed':cov['passed'],'scientific_results':{'R1':R['R1_cone_unico'],'R2':R['R2_luz_e_saltos'],'Q':Q['decisao']},'published_to_github':False}
    assert finish['source_hashes_match_start']
    save(ROOT/'EXECUTION_PROVENANCE_FINISH.json',finish)
    print(json.dumps(finish,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
