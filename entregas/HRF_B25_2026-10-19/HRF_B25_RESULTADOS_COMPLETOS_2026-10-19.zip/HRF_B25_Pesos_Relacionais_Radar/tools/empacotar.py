"""Create a local ZIP and verify its bytes; does not publish or upload files."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

ROOT=Path(__file__).resolve().parents[1]


def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as source:
        for b in iter(lambda:source.read(1024*1024),b''):h.update(b)
    return h.hexdigest()


if __name__=='__main__':
    parser=argparse.ArgumentParser()
    parser.add_argument('--output',type=Path,default=ROOT.parent/'HRF_B25_RESULTADOS_COMPLETOS_2026-10-19.zip')
    output=parser.parse_args().output.resolve()
    for name in ('RELATORIO_CIENTIFICO_B25.md','resultados/avaliacao_B25.json','resultados/CONFERENCIA_COBERTURA.json','EXECUTION_PROVENANCE_FINISH.json'):
        if not (ROOT/name).is_file():raise FileNotFoundError(name)
    check=json.loads((ROOT/'resultados/CONFERENCIA_COBERTURA.json').read_text())
    assert check['passed']
    manifest=ROOT/'MANIFEST_SHA256_ENTREGA.json'
    files=[p for p in sorted(ROOT.rglob('*')) if p.is_file() and p!=manifest and not any(x in ('.cache','__pycache__') for x in p.relative_to(ROOT).parts)]
    entries=[{'path':str(p.relative_to(ROOT)),'bytes':p.stat().st_size,'sha256':sha(p)} for p in files]
    manifest.write_text(json.dumps({'scope':'All present delivery files except this manifest; runtime caches excluded. Scientific original hashes are separately preserved.','files':entries},indent=2,ensure_ascii=False)+'\n')
    if output.exists():raise FileExistsError('Preserve existing deliveries')
    with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files+[manifest]:z.write(p,'HRF_B25_Pesos_Relacionais_Radar/'+str(p.relative_to(ROOT)))
    output.chmod(0o644)
    with zipfile.ZipFile(output) as z:
        assert z.testzip() is None
        for entry in entries:
            content=z.read('HRF_B25_Pesos_Relacionais_Radar/'+entry['path'])
            assert hashlib.sha256(content).hexdigest()==entry['sha256'],entry['path']
    report={'local_path':str(output),'bytes':output.stat().st_size,'sha256':sha(output),'files':len(files)+1,'CRC_and_contents_hashes_verified':True,'uploaded_or_published':False,'browser_download_confirmed':False}
    output.with_suffix('.verificacao.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps(report,indent=2))
