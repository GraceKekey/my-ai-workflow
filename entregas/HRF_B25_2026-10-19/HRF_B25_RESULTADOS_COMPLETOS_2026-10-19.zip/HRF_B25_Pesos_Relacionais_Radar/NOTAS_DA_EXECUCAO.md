# B25 — notas desta execução

[D] A rodada completa foi autorizada na conversa. O destino é local; não há publicação no GitHub.
[D] Os arquivos do pacote pré-registrado permanecem sem alterações. A execução usa Python 3.12, NumPy 2.2.6 e SciPy 1.15.3, em máquina de nuvem com quota de 4 CPUs e 32 GiB. Bibliotecas BLAS limitadas a 4 threads. TZ=America/Sao_Paulo para os horários do orquestrador.
[D] Comando científico original: python -I src/rodar_B25.py completo. Avaliação original: python -I src/avaliar_B25.py resultados.
[D] Os dados em fumaca/ são entradas históricas de fumaça e NÃO são usados como resultados completos. O teste sintético atual está em logs/teste_avaliador_sintetico_atual.txt e NÃO é evidência física.
[D] Relatórios, CSV e figuras complementares serão produzidos após a avaliação; eles não alteram as regras do avaliador.
[?] O código fornecido do bloco Q retorna resíduo 0 explicitamente no caminho de diagonalização densa (D≤7000); isso é uma convenção da implementação, não uma medição independente do resíduo. Os casos esparsos calculam o resíduo normalizado. Esse detalhe será preservado e declarado no relatório.
