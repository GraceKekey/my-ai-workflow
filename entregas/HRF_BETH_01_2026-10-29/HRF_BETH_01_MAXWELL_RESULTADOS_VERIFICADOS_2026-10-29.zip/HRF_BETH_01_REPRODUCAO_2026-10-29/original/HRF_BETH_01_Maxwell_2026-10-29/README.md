# HRF-BETH-01 — Controle eletromagnético do experimento de Beth

**Versão:** v0.1 · **Data:** 29/10/2026 · **Classe:** [M] bancada numérica de física conhecida.

Esta bancada **não** utiliza a implementação relacional do Capítulo 2. É o **controle Maxwell independente** acordado enquanto a robustez da helicidade da B41-M02 é investigada em outro trabalho. Não implementa fótons únicos, não deriva \(\hbar\) ou spin quântico e não reproduz literalmente o arranjo multipasse de Beth (1936).

## Método

Uma onda plana monocromática entra em uma placa birrefringente, com eixos próprios \(x,y\), índices reais \(n_x,n_y\) e **sem reflexões, dispersão, perdas ou variações transversais**. As amplitudes complexas são soluções harmônicas das equações de Maxwell no material:

\[
E_x(z)=E_0 j_x e^{i n_x\omega z/c},\quad E_y(z)=E_0 j_y e^{i n_y\omega z/c}.
\]

A amplitude \(E_0\) é fixada pelo fluxo de Poynting interno \(P/A=\epsilon_0c(n_x|E_x|^2+n_y|E_y|^2)/2\), e **não** pelo resultado esperado do torque. A polarização material é \(\mathbf P_{\rm mat}=\epsilon_0(\epsilon_r-I)\mathbf E\). O torque material local, calculado como interação de dipolos, é:

\[
\langle\tau_z\rangle=\langle(\mathbf P_{\rm mat}\times\mathbf E)_z\rangle
=\frac{\epsilon_0}{2}(n_x^2-n_y^2)\operatorname{Re}(E_xE_y^*).
\]

Integra-se numericamente sobre o volume da placa. A verificação independente calcula a diferença do fluxo de momento angular óptico através das faces. **Ambos partem das mesmas hipóteses ópticas; a concordância testa a consistência interna, não representa evidência experimental independente.**

Para luz circular, a retardância \(|\delta|=\pi\) (meia onda) inverte o sinal de Stokes \(S_3\) e o resultado analítico esperado é \(|\tau|=2P/\omega\). Esse valor **não entra** no cálculo do torque material: é usado apenas na avaliação final. Para polarização linear a 45° a torque pode ser não nulo com uma placa de quarto de onda; o controle linear nulo é para placa meia onda ou polarização ao longo dos eixos próprios.

## Execução local

Requisitos: Python 3.10+; NumPy, SciPy e Matplotlib.

```bash
python -m unittest discover -s tests -v
python run_bench.py --out resultados
```

Gera CSVs, quatro PNGs, `avaliacao.json` e o relatório de execução. Os parâmetros de referência são ilustrativos: \(n_x=1.50\), \(n_y=1.55\), \(\lambda=532\,nm\), potência 10 mW, área transversal 1 mm². A espessura de meia onda é calculada, não medida. O pêndulo mecânico é **ilustrativo**, usando constantes sintéticas, e não representa calibração do aparelho Beth 1936.

## Limites e critérios

- A análise é de um único feixe e **passagem única**, não do sistema completo de placas espelhadas de Beth. Para comparações com o arranjo histórico, calcular separadamente cada passagem e as trocas com os suportes.
- Não há absorção, reflexão Fresnel, eletrostrição, torque orbital, efeitos de borda, deformação elástica óptica, termo de Abraham–Minkowski, ruído térmico ou leitura de detector real.
- `PASS` exige simultaneamente concordância entre torque material e \(2P/\omega\) com erro relativo abaixo de 5e-5, concordância de balanço de fluxos, inversão ao trocar helicidade e diminuição monotônica do erro ao refinar.
- `NOT_EXECUTED` para a ponte C5A/B41 → torque físico, não inventar PASS.

## Fonte primária e documentos internos

- Richard A. Beth, *Mechanical Detection and Measurement of the Angular Momentum of Light*, Physical Review **50**, 115–125 (1936). DOI https://doi.org/10.1103/PhysRev.50.115.
- `HRF_Research_Book_Cap0_1_Diretrizes_Reconstrucao_Unificadora_Progressiva_v0_2_PT_2026-10-09.md` — RUP B → A.
- `HRF_Research_Book_Cap02_Onda_Fotonica_Livre_v1_4_PT_2026-10-28_1653-clau.md` — seção fotônica e B41.
- `HRF_B41_Relatorio_e_Auditoria_PT_2026-10-28_1430-clau.md` — falha registrada M02 (8/10). 
- `HRF_Caderno_Mestre_de_Referencias_v0_2_PT_2026-10-10.md` foi consultado. Beth (1936) ainda **não tem ID HRF-REF-XXXX atribuído/verificado nesse caderno**; adicionar em próxima revisão bibliográfica, sem inventar ID.
