# HRF-BETH-01 — Critérios congelados ANTES da primeira rodada formal

Data: 2026-10-29; rodada de controle óptico Maxwell. **Sem acoplamento ao HRF.**

- H1: uma placa de meia onda ideal inverte o Stokes S3 de incidência circular; módulo do torque de volume deve coincidir com 2P/ω a erro relativo < 5×10⁻⁵.
- H2: torque volume = fluxo angular incidente - fluxo emergente, erro relativo < 5×10⁻⁵.
- H3: inverter helicidade troca sinal do torque com erro relativo < 5×10⁻⁵.
- H4: integrar em 17,33,65,129,257,513,1025 pontos deve diminuir monotonicamente o erro relativo.
- H5 controles: potência zero, retardância zero, polarização linear nos eixos e linear a 45° com meia onda dão torque zero no limite numérico; onda linear a 45° com quarto de onda NÃO deve ser classificada como nula.
- H6: torque escala linearmente com potência e, quando a espessura da placa é recalculada para meia onda, é proporcional a λ para potência fixa.
- Pendulo torcional com inércia, rigidez e amortecimento escolhidos para visualização: sem reivindicação de parâmetros históricos.
- Resultado global PASS somente com H1–H4 e testes unitários passando; teste HRF-CAP2 permanece NOT_EXECUTED por definição.
- Não ajustar os limites após conhecer resultados; alterações documentar em novo arquivo de errata ou protocolo.

**Congelamento:** este arquivo é criado antes do comando `python -m unittest` e antes do `run_bench.py`. Verificar hash pelo manifest do pacote.
