import sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"src"))
import unittest
import numpy as np
from scipy.constants import pi
from beth01 import Plate,calculate,predict_reference_halfwave,torsion_trajectory

P=Plate()


class BethTests(unittest.TestCase):
    def test_circular_plus(self):
        d=calculate(P,"circular_mais",n_z=1024)
        ref=predict_reference_halfwave(P.power_w,P.wavelength_m,1)
        self.assertLess(abs(d["torque_bulk_nm"]/ref-1),3e-6)
        self.assertLess(abs(d["torque_flux_nm"]/ref-1),1e-10)
        self.assertAlmostEqual(d["s3_in"],1,places=10)
        self.assertAlmostEqual(d["s3_out"],-1,places=10)

    def test_circular_reverse(self):
        a=calculate(P,"circular_mais",n_z=1024)
        b=calculate(P,"circular_menos",n_z=1024)
        self.assertAlmostEqual(a["torque_bulk_nm"]/b["torque_bulk_nm"],-1,places=10)
        self.assertAlmostEqual(a["torque_flux_nm"]/b["torque_flux_nm"],-1,places=10)

    def test_no_gradient_retardance_zero(self):
        for pol in ["circular_mais","linear_45"]:
            d=calculate(P,pol,retardance=0,n_z=200)
            self.assertLess(abs(d["torque_bulk_nm"]),1e-23)
            self.assertLess(abs(d["torque_flux_nm"]),1e-23)

    def test_dark(self):
        d=calculate(Plate(power_w=0),"circular_mais",n_z=128)
        self.assertEqual(d["torque_bulk_nm"],0)
        self.assertEqual(d["torque_flux_nm"],0)

    def test_linear_x_y_and_45_hwp(self):
        for pol in ("linear_x","linear_y","linear_45"):
            d=calculate(P,pol,n_z=512)
            self.assertLess(abs(d["torque_bulk_nm"]),1e-23)
            self.assertLess(abs(d["torque_flux_nm"]),1e-23)

    def test_linear_45_quarterwave_not_null(self):
        d=calculate(P,"linear_45",retardance=pi/2,n_z=1024)
        self.assertGreater(abs(d["torque_flux_nm"]),1e-19)
        self.assertLess(abs(d["torque_bulk_nm"]-d["torque_flux_nm"])/abs(d["torque_flux_nm"]),3e-6)

    def test_power_scaling(self):
        a=calculate(P,"circular_mais",n_z=512)
        b=calculate(Plate(power_w=2*P.power_w),"circular_mais",n_z=512)
        self.assertAlmostEqual(b["torque_bulk_nm"]/a["torque_bulk_nm"],2.,places=10)

    def test_inverse_frequency_at_halfwave(self):
        a=calculate(P,"circular_mais",n_z=512)
        b=calculate(Plate(wavelength_m=2*P.wavelength_m),"circular_mais",n_z=512)
        self.assertAlmostEqual(b["torque_bulk_nm"]/a["torque_bulk_nm"],2.,places=10)

    def test_angular_flux_conservation(self):
        for pol in ("circular_mais","circular_menos","linear_x","linear_y","linear_45"):
            for delta in (pi/4,pi/2,pi):
                d=calculate(P,pol,retardance=delta,n_z=1024)
                scale=max(abs(d["torque_flux_nm"]),1e-23)
                self.assertLess(abs(d["torque_bulk_nm"]-d["torque_flux_nm"])/scale,5e-6)

    def test_second_order_convergence(self):
        ref=predict_reference_halfwave(P.power_w,P.wavelength_m)
        errors=[]
        for n in (33,65,129,257):
            d=calculate(P,"circular_mais",n_z=n)
            errors.append(abs(d["torque_bulk_nm"]-ref)/abs(ref))
        for a,b in zip(errors,errors[1:]):
            self.assertGreater(a/b,3.9)

    def test_pendulum_settles(self):
        tau=calculate(P,"circular_mais",n_z=512)["torque_bulk_nm"]
        tt,theta=torsion_trajectory(tau,duration_s=12,n_t=350)
        expected=tau/1e-12
        self.assertLess(abs(theta[-1]/expected-1),0.025)

if __name__=="__main__":unittest.main()
