"""HRF-BETH-01: benchmark independente de Beth a partir de Maxwell em placa birrefringente.

Convenções: E(t) = Re[E_complex(z) exp(-i omega t)]; propagação +z;
Ey = +i Ex designa o rótulo s3=+1 (não se identifica a mão visual sem fixar a convenção).
Modelo: ondas planas normais, placa sem reflexão/absorção/disp ersão, polarizabilidade real,
graus ópticos isolados e polarização homogênea na seção, acoplamento material local P x E.
A densidade de torque calculada não usa a fórmula de Beth 2P/omega.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
from scipy.constants import c, epsilon_0, pi


@dataclass(frozen=True)
class Plate:
    n_x: float = 1.50
    n_y: float = 1.55
    wavelength_m: float = 532e-9
    area_m2: float = 1e-6
    power_w: float = 0.01

    def __post_init__(self):
        if self.n_x <= 0 or self.n_y <= 0 or self.n_x == self.n_y:
            raise ValueError("Indices positivos e distintos sao necessarios")
        if min(self.wavelength_m, self.area_m2) <= 0 or self.power_w < 0:
            raise ValueError("Parametros fisicos invalidos")

    @property
    def omega(self):
        return 2*pi*c/self.wavelength_m

    @property
    def delta_k(self):
        return 2*pi*(self.n_x-self.n_y)/self.wavelength_m

    def length_for_retardance(self, abs_delta: float = pi):
        return abs_delta / abs(self.delta_k)


POLARIZATIONS = {
    "circular_mais": np.array([1., 1j], dtype=complex) / np.sqrt(2),
    "circular_menos": np.array([1., -1j], dtype=complex) / np.sqrt(2),
    "linear_x": np.array([1., 0.], dtype=complex),
    "linear_y": np.array([0., 1.], dtype=complex),
    "linear_45": np.array([1., 1.], dtype=complex) / np.sqrt(2),
}


def stokes3(jones: np.ndarray) -> float:
    """S3/S0 = 2 Im(Ex* Ey)/(|Ex|2+|Ey|2), sinal convencionado."""
    jones = np.asarray(jones, dtype=complex)
    return float(2*np.imag(np.conj(jones[0])*jones[1])/np.vdot(jones, jones).real)


def amplitude_from_power(plate: Plate, jones: np.ndarray) -> float:
    """Normaliza fluxo de Poynting interno, sem refletancias nas interfaces."""
    j = np.asarray(jones, complex)
    weighted = plate.n_x*abs(j[0])**2 + plate.n_y*abs(j[1])**2
    return float(np.sqrt(2*plate.power_w/(plate.area_m2*epsilon_0*c*weighted))) if plate.power_w else 0.


def field_amplitudes(plate: Plate, jones: np.ndarray, z_m: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    """Solucao harmônica de Maxwell nas direções principais x,y da placa."""
    E0 = amplitude_from_power(plate, jones)
    j = np.asarray(jones, dtype=complex)
    zz = np.asarray(z_m, dtype=float)
    return (E0*j[0]*np.exp(1j*2*pi*plate.n_x*zz/plate.wavelength_m),
            E0*j[1]*np.exp(1j*2*pi*plate.n_y*zz/plate.wavelength_m))


def torque_density(plate: Plate, ex: np.ndarray, ey: np.ndarray) -> np.ndarray:
    """< (P x E)_z >= eps0*(nx²-ny²)*Re[Ex Ey*]/2, N/m².

    Produto de polarizacao material P=eps0*(n_i²-1) E com campo elétrico.
    Não confundir polarização material P com potência óptica em watts.
    """
    return 0.5*epsilon_0*(plate.n_x**2-plate.n_y**2)*np.real(ex*np.conj(ey))


def angular_momentum_flux(plate: Plate, ex: complex, ey: complex) -> float:
    """Fluxo canônico de spin (N*m) da onda no modelo ideal anisotrópico.

    J = A*eps0*c*(nx+ny)/(2 omega) Im(Ex* Ey), valor constante para helicidade
    pura em região homogênea, mas pode variar na placa por troca com o meio.
    Equivale a s3*P/omega para |Ex|=|Ey| (casos circulares e 45 graus).
    """
    return float(plate.area_m2*epsilon_0*c*(plate.n_x+plate.n_y)/(2*plate.omega)*np.imag(np.conj(ex)*ey))


def calculate(plate: Plate, polarization: str, retardance: float = pi, n_z: int = 512) -> dict:
    if polarization not in POLARIZATIONS:
        raise ValueError("Polarizacao desconhecida")
    if n_z < 3:
        raise ValueError("n_z deve ser >=3")
    length=plate.length_for_retardance(retardance)
    z=np.linspace(0, length, n_z)
    ex,ey=field_amplitudes(plate,POLARIZATIONS[polarization],z)
    local=torque_density(plate,ex,ey)
    bulk=float(plate.area_m2*np.trapezoid(local,z))
    jin=angular_momentum_flux(plate,ex[0],ey[0]); jout=angular_momentum_flux(plate,ex[-1],ey[-1])
    flux=jin-jout
    expected=0. if polarization.startswith("linear") else (2 if polarization=="circular_mais" else -2)*plate.power_w/plate.omega
    return {
        "polarization":polarization,"power_w":plate.power_w,"wavelength_m":plate.wavelength_m,
        "omega_rad_s":plate.omega,"retardance_abs_rad":float(retardance),
        "thickness_m":float(length),"n_z":int(n_z),
        "s3_in":stokes3(np.array([ex[0],ey[0]])) if plate.power_w else 0.,
        "s3_out":stokes3(np.array([ex[-1],ey[-1]])) if plate.power_w else 0.,
        "torque_bulk_nm":bulk,"torque_flux_nm":flux,
        "beth_hwp_reference_nm":expected if abs(retardance-pi)<1e-12 else None,
        "rel_flux_balance_err":abs(bulk-flux)/max(abs(flux),1e-30),
        "z_m":z,"local_torque_density_nm2":local,
    }


def predict_reference_halfwave(power_w: float, wavelength_m: float, sign: int = 1) -> float:
    """Controle analítico independente (não usado em calculate)."""
    omega=2*pi*c/wavelength_m
    return sign*2*power_w/omega


def torsion_trajectory(torque_nm: float, duration_s: float = 3., n_t: int = 800,
                       inertia_kg_m2: float = 1e-14, spring_nm_rad: float = 1e-12,
                       damping_ratio: float = 0.15) -> tuple[np.ndarray,np.ndarray]:
    """Pêndulo torcional I theta'' + b theta' + k theta = tau, torque constante."""
    from scipy.integrate import solve_ivp
    if min(inertia_kg_m2,spring_nm_rad,duration_s) <= 0 or damping_ratio < 0:
        raise ValueError("Parametrizacao mecanica invalida")
    b=2*damping_ratio*np.sqrt(inertia_kg_m2*spring_nm_rad)
    def fun(_t,y):
        return [y[1],(torque_nm-b*y[1]-spring_nm_rad*y[0])/inertia_kg_m2]
    t=np.linspace(0,duration_s,n_t)
    sol=solve_ivp(fun,(0,duration_s),[0.,0.],t_eval=t,rtol=1e-10,atol=1e-13,method="DOP853")
    if not sol.success: raise RuntimeError(sol.message)
    return t,sol.y[0]
