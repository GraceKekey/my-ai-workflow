"""Gera resultados de HRF-BETH-01 (controle Maxwell/Jones + torque dipolar).
Uso: python run_bench.py --out resultados
"""
from __future__ import annotations
import argparse,csv,json,platform,sys,hashlib,datetime
from pathlib import Path
import numpy as np
from scipy.constants import pi
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
sys.path.insert(0,str(Path(__file__).resolve().parent/"src"))
from beth01 import Plate,calculate,predict_reference_halfwave,torsion_trajectory


def write_csv(path,rows,fields=None):
    rows=list(rows)
    if not rows:return
    if fields is None:fields=list(rows[0].keys())
    with path.open("w",newline="",encoding="utf-8") as f:
        dw=csv.DictWriter(f,fieldnames=fields)
        dw.writeheader(); dw.writerows(rows)


def short_result(d):return {k:float(v) if isinstance(v,(np.floating,float)) else int(v) if isinstance(v,(np.integer,int)) else v for k,v in d.items() if k not in {"z_m","local_torque_density_nm2"}}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("--out",default="resultados")
    args=ap.parse_args()
    out=Path(args.out);out.mkdir(parents=True,exist_ok=True)
    plate=Plate()
    tolerance=5e-5 # definido antes de executar a rodada; conferir PREREGISTRO.
    baseline=calculate(plate,"circular_mais",n_z=1025)
    reverse=calculate(plate,"circular_menos",n_z=1025)
    analytic=predict_reference_halfwave(plate.power_w,plate.wavelength_m)
    rows=[]
    for delta in np.linspace(0,2*pi,33):
        for pol in ("circular_mais","circular_menos","linear_x","linear_y","linear_45"):
            d=calculate(plate,pol,retardance=float(delta),n_z=1025)
            rows.append({"retardo_rad":float(delta),"polarizacao":pol,"torque_volume_Nm":d["torque_bulk_nm"],"torque_fluxo_Nm":d["torque_flux_nm"],"s3_entrada":d["s3_in"],"s3_saida":d["s3_out"]})
    write_csv(out/"varredura_retardo.csv",rows)

    powers=[0,0.0025,0.005,0.01,0.02,0.04]
    powerrows=[]
    for p in powers:
        d=calculate(Plate(power_w=p),"circular_mais",n_z=1025)
        powerrows.append({"potencia_W":p,"torque_volume_Nm":d["torque_bulk_nm"],"torque_fluxo_Nm":d["torque_flux_nm"]})
    write_csv(out/"varredura_potencia.csv",powerrows)

    wavelengths=[405e-9,450e-9,532e-9,650e-9,780e-9]
    wlrows=[]
    for wl in wavelengths:
        d=calculate(Plate(wavelength_m=wl),"circular_mais",n_z=1025)
        wlrows.append({"comprimento_onda_nm":wl*1e9,"espessura_meia_onda_um":d["thickness_m"]*1e6,"torque_volume_Nm":d["torque_bulk_nm"],"torque_fluxo_Nm":d["torque_flux_nm"]})
    write_csv(out/"varredura_comprimento_onda.csv",wlrows)

    conv=[]
    for n in (17,33,65,129,257,513,1025):
        d=calculate(plate,"circular_mais",n_z=n)
        conv.append({"n_pontos_z":n,"torque_volume_Nm":d["torque_bulk_nm"],"torque_fluxo_Nm":d["torque_flux_nm"],"erro_relativo_referencia":abs(d["torque_bulk_nm"]-analytic)/abs(analytic)})
    write_csv(out/"convergencia.csv",conv)

    t,theta=torsion_trajectory(baseline["torque_bulk_nm"],duration_s=8.,n_t=1200)
    write_csv(out/"pendulo_torcao.csv",({"tempo_s":float(ti),"angulo_rad":float(th),"angulo_urad":float(th*1e6)} for ti,th in zip(t,theta)))

    z=baseline["z_m"];td=baseline["local_torque_density_nm2"]
    write_csv(out/"torque_local.csv",({"z_um":float(x*1e6),"densidade_torque_Nm2":float(q)} for x,q in zip(z,td)))

    # Figuras sem ajuste de dados nem reescolha de cortes após observar resultados.
    plt.figure(figsize=(8,4.7))
    for pol in ["circular_mais","circular_menos","linear_45"]:
        rr=[r for r in rows if r["polarizacao"]==pol]
        plt.plot([r["retardo_rad"]/pi for r in rr],[r["torque_volume_Nm"]*1e18 for r in rr],label=pol.replace("_"," "))
    plt.axvline(1,linestyle="--",linewidth=.9,label="meia onda")
    plt.xlabel("Retardância |δ|/π");plt.ylabel("Torque material (10⁻¹⁸ N m)")
    plt.title("Beth idealizado: torque calculado de P × E")
    plt.legend();plt.tight_layout();plt.savefig(out/"fig01_torque_polarizacoes.png",dpi=170);plt.close()

    plt.figure(figsize=(8,4.7))
    plt.plot([r["potencia_W"]*1000 for r in powerrows],[r["torque_volume_Nm"]*1e18 for r in powerrows],"o-",label="Integração no material")
    plt.plot([r["potencia_W"]*1000 for r in powerrows],[r["torque_fluxo_Nm"]*1e18 for r in powerrows],"--",label="Balanço de fluxo")
    plt.xlabel("Potência (mW)");plt.ylabel("Torque (10⁻¹⁸ N m)")
    plt.title("Escala linear do torque com potência")
    plt.legend();plt.tight_layout();plt.savefig(out/"fig02_torque_potencia.png",dpi=170);plt.close()

    plt.figure(figsize=(8,4.7))
    plt.loglog([r["n_pontos_z"] for r in conv],[r["erro_relativo_referencia"] for r in conv],"o-")
    plt.xlabel("Pontos em z");plt.ylabel("Erro relativo para 2P/ω")
    plt.title("Convergência da integração do torque no material")
    plt.tight_layout();plt.savefig(out/"fig03_convergencia.png",dpi=170);plt.close()

    plt.figure(figsize=(8,4.7))
    plt.plot(t,theta*1e6,label="Ângulo do pêndulo")
    plt.axhline(baseline["torque_bulk_nm"]/1e-12*1e6,linestyle="--",label="Equilíbrio τ/κ")
    plt.xlabel("Tempo (s)");plt.ylabel("Desvio angular (µrad)")
    plt.title("Resposta ilustrativa do pêndulo de torção")
    plt.legend();plt.tight_layout();plt.savefig(out/"fig04_pendulo_torcao.png",dpi=170);plt.close()

    checks={
        "beth_torque_relative_error":abs(baseline["torque_bulk_nm"]-analytic)/abs(analytic),
        "balance_relative_error":baseline["rel_flux_balance_err"],
        "reverse_sign_relative_error":abs(baseline["torque_bulk_nm"]+reverse["torque_bulk_nm"])/abs(baseline["torque_bulk_nm"]),
        "convergence_monotonic":all(a["erro_relativo_referencia"]>b["erro_relativo_referencia"] for a,b in zip(conv,conv[1:])),
    }
    pass_all=checks["beth_torque_relative_error"]<tolerance and checks["balance_relative_error"]<tolerance and checks["reverse_sign_relative_error"]<tolerance and checks["convergence_monotonic"]
    report={
        "bancada":"HRF-BETH-01",
        "version":"v0.1",
        "classification":"[M] controle eletromagnético convencional; não valida microdinâmica HRF",
        "timestamp_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "environment":{"python":platform.python_version(),"numpy":np.__version__,"platform":platform.platform()},
        "input":{"n_x":plate.n_x,"n_y":plate.n_y,"wavelength_m":plate.wavelength_m,"power_w":plate.power_w,"area_m2":plate.area_m2,"thickness_hwp_m":plate.length_for_retardance()},
        "principal":short_result(baseline),"reverse":short_result(reverse),
        "control_reference_nm":analytic,"checks":checks,"thresholds":{"relative_error":tolerance},
        "veredito_controle":"PASS" if pass_all else "FAIL",
        "gate_hrf_b41":"PENDING — isolado desta bancada; B41-M02 permanece FAIL",
        "gate_hrf_beth":"NOT_EXECUTED — nenhuma conexão do Capítulo 2 foi usada",
    }
    (out/"avaliacao.json").write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps({"controle":report["veredito_controle"],"torque_num_nm":baseline["torque_bulk_nm"],"beth_ref_nm":analytic,"relative_err":checks["beth_torque_relative_error"],"ratio":baseline["torque_bulk_nm"]/analytic,"spin_in":baseline["s3_in"],"spin_out":baseline["s3_out"]},indent=2))
    if not pass_all:sys.exit(1)


if __name__=="__main__":main()
