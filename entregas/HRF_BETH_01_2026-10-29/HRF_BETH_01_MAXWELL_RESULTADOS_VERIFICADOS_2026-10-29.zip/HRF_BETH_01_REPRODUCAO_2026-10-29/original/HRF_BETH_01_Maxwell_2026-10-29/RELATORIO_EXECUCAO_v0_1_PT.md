# HRF-BETH-01 — Relatório de execução do controle Maxwell

**Data:** 29/10/2026 · **Versão:** 0.1 · **Natureza:** [M] simulação computacional de eletrodinâmica convencional, não experimento de laboratório.

## Objetivo e separação de trabalhos

Construir agora a parte independente Maxwell do experimento de Beth, enquanto a fragilidade de preparação da helicidade na B41-M02 é investigada em outra frente. **A B41 não foi alterada nem declarada corrigida.** A ponte com o setor fotônico relacional U(1)/Wilson continua `NOT_EXECUTED`.

## Equações e critério de cálculo

Em ondas planas harmônicas na placa anisotrópica ideal, \(E_x(z)=E_0 j_x e^{in_x\omega z/c}\), \(E_y(z)=E_0 j_y e^{in_y\omega z/c}\). O código calcula a densidade média de torque **a partir do acoplamento material local**:

\[
\langle (\mathbf P_{mat}\times\mathbf E)_z\rangle=\tfrac12\epsilon_0(n_x^2-n_y^2)\operatorname{Re}(E_xE_y^*)
\]

com integração trapezoidal no volume da placa. Em separado, calcula o fluxo angular de spin em cada face e sua diferença. A lei analítica \(|\tau|=2P/\omega\) para o retardo \(\pi\) só é usada na avaliação, não na função de cálculo do torque.

## Parâmetros ilustrativos

- Potência \(P=10\,mW\); comprimento de onda \(\lambda=532\,nm\); área \(A=1\,mm^2\).
- \(n_x=1,50\), \(n_y=1,55\); espessura de meia onda \(L=5,32\,µm\).
- Passagem **única**, reflexão nula por idealização. Esses valores não foram ajustados a medidas de Beth (1936).

## Resultado e avaliação

| Observável/controle | Resultado | Situação |
|---|---|---|
| Predição Beth para passagem única \(2P/\omega\) | \(5,648603056\times10^{-18}\,N\,m\) | [F] referência |
| Torque calculado no volume \(\int\langle\mathbf P\times\mathbf E\rangle dV\) | \(5,648598626\times10^{-18}\,N\,m\) | [M] |
| Torque pelo fluxo de momento angular | \(5,648603056\times10^{-18}\,N\,m\) | [M] |
| Erro relativo do torque de volume | \(7,844\times10^{-7}\), ou \(0,0000784\%\) | PASS (<\(5\times10^{-5}\)) |
| Helicide Stokes \(S_3\), entrada → saída | \(+1\to-1\) | PASS |
| Inversão de helicidade incidente | \(\tau_-= -\tau_+\) | PASS |
| Controles de potência zero, retardância zero e polarizações lineares para meia onda | torque zero numérico | PASS |
| Quarto de onda com linear 45° | torque não nulo, como deve ser | PASS |
| Erro de integração com refinamento | decrescente monotonicamente | PASS |
| Testes automáticos do código | **11/11** | PASS |
| Propriedades fotônicas HRF U(1)/Wilson submetidas a Beth | não implementadas | NOT_EXECUTED |
| Critério B41-M02 (P1 da B1) | 8/10 sementes | FAIL histórico, inalterado |

**Veredito restrito [M]: `PASS — controle eletromagnético idealizado`.** Este resultado não revalida a B41, não demonstra spin fotônico a partir de uma ontologia microscópica do HRF, nem substitui um experimento físico com instrumentação real.

## Limitações e auditoria

A dupla verificação do torque foi implementada de duas formas numéricas distintas, mas ambas compartilham as mesmas hipóteses constitutivas de Maxwell. Foram omitidos reflexões de Fresnel, perdas, dispersão, bordas, tensões mecânicas, eletrostrição e a configuração multipasse de Beth. O pêndulo de torção usa parâmetros mecânicos sintéticos e serve para mostrar o que seria detectado, não para validar sensibilidade instrumental.

O protocolo e os limiares foram escritos antes da execução formal, com hashes preservados em `HASHES_ANTES_DA_RODADA.txt`. O pacote inclui o código, CSVs, gráficos e `resultados/avaliacao.json` com valores e ambiente. **Nenhuma nova bancada do HRF foi executada fora deste controle independente.**

## Próximo gate, não executado

Quando o trabalho B41-M02 tiver critério de estabilidade aprovado separadamente, investigar como introduzir uma placa/elemento anisotrópico dinâmico no setor relacional e obter torque como derivada de ação do sistema acoplado, fechando o balanço de momento angular entre campo e material. É indispensável derivar o acoplamento e seus observáveis, sem injetar a lei \(2P/\omega\) como força.

## Referências e proveniência

- **Fonte primária**: R. A. Beth, “Mechanical Detection and Measurement of the Angular Momentum of Light”, *Physical Review* **50**, 115–125 (1936). https://doi.org/10.1103/PhysRev.50.115.
- HRF Capítulo 0.1 v0.2 (09/10/2026); HRF Capítulo 2 v1.4 (28/10/2026); relatório B41 (28/10/2026); caderno de referências HRF v0.2 (10/10/2026). A referência Beth ainda aguarda registro de ID HRF-REF.
