# HRF-BETH-01 — controle Maxwell reproduzido

**EXECUTADO EM 29/10/2026. 11/11 testes passaram; controle óptico PASS.**

Abra RELATORIO_REPRODUCAO.md. Resultados desta execução: reproducao/resultados/ (6 CSVs, 4 PNGs,avaliacao.json e testes_unitarios.log). Logs de execução: reproducao/logs/. Auditoria de hashes/comparação: auditoria/. O pacote recebido foi preservado em entrada/ e original/.

[M] Torque principal5.648598625673127e-18 N m, referência2P/omega5.648603056244219e-18 N m, erro relativo7.843658064482779e-7. Seis CSVs e valores científicos do JSON coincidem com os recebidos. Código/protocolo/testes congelados não foram alterados.

[?] Este é um controle de eletromagnetismo convencional idealizado, sem acoplamento ao modelo relacional HRF. A ponte com Capítulo2/B41 permanece NOT_EXECUTED. Não há revalidação de B41 nem experimento físico novo.

Para repetir, preserve esta cópia auditada e trabalhe numa nova cópia. Instale os pacotes de requirements_reproducao.lock e entre em reproducao/. Então:

```bash
python -I -m unittest discover -s tests -v
python -I run_bench.py --out resultados_novos
```

A dependência NumPy precisa ser 2.0 ou posterior por causa de np.trapezoid; o ambiente exato testado está no lock. Os arquivos de entrada originais mantêm seu requirements.txt para preservar os hashes. O manifesto MANIFESTO_SHA256.txt cobre todos os arquivos entregues, exceto ele próprio e caches Python (não incluídos).
