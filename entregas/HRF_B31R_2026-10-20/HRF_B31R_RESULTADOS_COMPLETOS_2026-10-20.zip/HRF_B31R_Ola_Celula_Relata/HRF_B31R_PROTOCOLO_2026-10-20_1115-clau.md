# HRF B31-R — A ola célula a célula, e células ou relações?
## B31a-R (hamiltoniano modular refeito), B31e (álgebras de células × relações), B31f (o limite de uma célula)
## Protocolo pré-registrado

**Data:** 20 de outubro de 2026, 11h15 (America/Sao_Paulo) — Claude (`-clau`) · fluxo ímpar
**Autoria:** Mario José do Canto Filho, MD · redação: Claude
**Autorização para registrar e empacotar:** Mario, 10h58 ("faça o pacote para eu rodar em outro lugar"), com a escolha
"B31-R com A-R, E e F".
**Execução:** externa, pelo Mario. Protocolo, código e hashes ficam congelados antes da rodada completa.
**Antecedentes:** B31 (`HRF_B31_PROTOCOLO_2026-10-19_2345-clau.md`) e a sua auditoria
(`HRF_B31_Relatorio_e_Auditoria_PT_2026-10-20_0850-clau.md`): B31a INCONCLUSIVO só pelo controle de Lt, B31b DUAL_EXATO,
B31c GAP_QUEBRA_CHM, B31d CONFIRMADA. Nota `HRF_Nota_Progresso_Dualidade_Relata_Primarios_PT_2026-10-19_2300-clau.md`
(decisão [D]: a relação é a variável primária; pergunta aberta: qual é o relatum primário).

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 1. Objetivo

Continuar o teste da **hipótese paralela de Mario (H-par)**: o sistema fundamental é o GMF (uma célula da fronteira)
emaranhado com o resto; o hamiltoniano "fecha" entre o pedaço e o resto; as excitações são uma ola, e a "altura" de cada
pessoa é a força do emaranhamento da sua célula com o resto.

| Bloco | Pergunta |
|---|---|
| **B31a-R** | Com o controle de tamanho certo e discos maiores, o hamiltoniano modular do disco é local e tem a forma CHM? (fecha o INCONCLUSIVO da B31a) |
| **B31e** | O mesmo vácuo, visto como **células** (cada GMF é um fator próprio, o valor Z da célula é observável) ou só como **relações** (diferenças entre células e fluxos das bolhas), tem a mesma estrutura de emaranhamento? |
| **B31f** | Como fica o hamiltoniano modular de **um GMF sozinho** e de regiões pequenas (F1)? E a ola, vista **célula a célula** (F2): cada GMF de uma fila se levanta e se senta quando o quantum passa, na velocidade do pacote? |

## 2. Hipóteses e previsões (escritas antes)

**Modelo [M].** O mesmo da B31: tapete triangular da E-65 (a = 1), campo Z nos GMFs,
H = Σ P²/(2A) + ½ Σ w (Z_i − Z_j)², w = 1/√3, A = √3/2, c = 1, vácuo do plano infinito.

**B31a-R [F na continuidade; M na rede].** Igual à B31a (CHM com o tensor melhorado, ξ = 1/8). Previsões novas:
- a diferença entre as fontes L = 2048 e L = 1024 cresce como (R/L)³: ≈ 1,6×10⁻⁴ (R/16)³, ou seja ≈ 5×10⁻⁴ em R = 24
  (abaixo do limite de 10⁻³);
- desvio de CHM ≤ 0,5% para R ≥ 12;
- localidade suave (termos cruzados, seção 3) a ≤ 0,02 do CHM em todos os discos;
- [H] a localidade por sítio cai com R mas sobe com q: é artefato do corte de precisão, não física. Por isso ela
  **não entra** nas regras de decisão desta vez (é só relatada).

**B31e [F].** Pelo resultado de Cardy (2013), a informação mútua entre duas regiões distantes decai como
(R_A R_B / r²)^(2Δ), com Δ o menor peso de escala dos operadores da álgebra (álgebras "incompletas", com centro:
Casini–Huerta–Rosabal 2014; Casini–Huerta–Magán–Pontello 2020):
- álgebra de **células** (contém o próprio Z, Δ = ½): I ~ r⁻²;
- álgebras de **relações** (só gradientes de Z e momentos P = fluxos das bolhas, Δ = 3/2): I ~ r⁻⁶, tanto com centro
  magnético quanto com centro elétrico.
Centros previstos: magnético, 1 por disco (o fluxo total pela borda, P_tot); elétrico, |O| − 1 por disco (as relações
entre as células do anel externo O, isto é, o campo elétrico que atravessa a borda).
[M] As duas descrições têm o mesmo espectro (B31b), mas não a mesma estrutura de emaranhamento.
[H] Se o fóton do HRF é um campo de gauge (relação primária, decisão [D] de 19/10), a álgebra física é a de relações; o
valor "absoluto" Z de uma célula não seria observável.

**B31f.**
- **F1 [?].** Hipótese literal: um GMF sozinho já carrega a forma do hamiltoniano de fronteira. Expectativa a priori
  [M]: CHM é uma afirmação de contínuo; numa célula o desvio deve ser da ordem de 10%, e a forma CHM (≤ 5%) deve aparecer
  a partir de R ≈ 2–3. [M] Na álgebra de relações com centro magnético, uma célula sozinha **não tem parte quântica**
  (só o fluxo P_0, clássico).
- **F2 [H, versão literal da ola].** Um quantum em saca-rolha andando ao longo de +x faz cada célula da fila "se
  levantar" (ΔS₂ da célula sozinha sobe) quando o pacote passa e "se sentar" depois; o pico anda na velocidade de grupo
  v_g = 0,941 (k₀ = 0,8); a helicidade não importa. [?] A altura de cada célula em relação à fórmula de quasipartícula
  com a fração de energia local é medida, sem previsão.

## 3. Parâmetros

**Fontes de correlação (A-R, E, F1).** Plano infinito por extrapolação de Richardson em 1/Lt (G = 2G(2L) − G(L)):
principal L = 2048 (toros 2048/4096); controle L = 1024 (1024/2048).

**B31a-R.**
- Discos R ∈ {8, 12, 16, 20, 24} (241 a 2 083 GMFs); R_ef = √(N·A/π).
- Cortes de precisão q ∈ {11, 12, 13}: decisão q = 13, controle q = 12; q = 11 só para a tendência.
- Razões: os 6 campos de teste da B31a (gaussianas σ = 0,3 R_ef em s = 0; 0,15; 0,3 R_ef, direções 0° e 90°, janela
  0,7–0,9 R_ef).
- **Localidade suave:** para cada direção (0° e 90°), duas gaussianas de largura 0,2 R_ef com centros em ±0,3 R_ef, com a
  mesma janela. c_K = ⟨g1, K g2⟩ / √(⟨g1, K g1⟩⟨g2, K g2⟩), para K = N e K = M; o mesmo número com as formas CHM
  (N: 2π Σ β_i g1 g2 / A; M: 2π Σ_e β_e w Δg1 Δg2 + (π/R) Σ A g1 g2). Medida: |c_K − c_K(CHM)|.

**B31e.**
- Fontes: as mesmas (2048 principal, 1024 controle).
- Discos isolados R ∈ {2, 4, 6, 8, 12}: S_Z (células), S_q e h do centro (relações, magnético e elétrico).
- Informação mútua entre dois discos de raio R_d centrados em (0,0) e (r,0):
  R_d = 2 com r ∈ {8, 12, 16, 24, 32, 48}; R_d = 3 com r ∈ {12, 16, 24, 32, 48}. Os discos e os seus anéis não se tocam.
- Inclinação: ajuste de ln I contra ln r nos 4 maiores r de cada série.
- Para álgebras com centro: S = h(centro) + S_q (h é diferencial e depende da unidade; I não depende).

**B31f.**
- F1: regiões R ∈ {0,5 (1 célula); 1 (7); 2 (19); 3 (37); 4 (61); 6 (127); 8 (241)}; q ∈ {12, 13}. Campo de teste
  g_i = β_i² normalizado (β_i = (R_ef² − r_i²)/(2R_ef), zero fora), que vai a zero na borda e existe até numa célula.
- F2: toros Lt = 1024 (decisão) e 2048 (controle), correladores do próprio toro (como na B31d). Pacote gaussiano em k:
  k₀ = (0,8; 0), Δk = k₀/6, centro inicial x = −30, t = 0, 1, …, 64. Fila de 9 células no eixo x: x = −16, −12, …, 16.
  Duas formas: a célula sozinha e o hexágono de 7 em volta dela. **Onda em saca-rolha (regra do projeto):** quantum em
  polarização circular com duas cópias do campo, as duas helicidades; linear como referência. τ = 10⁻¹⁰ (decisão) e
  10⁻¹² (controle).

## 4. Protocolo

1. `python -I src/rodar_B31R.py completo` (checkpoint atômico por caso; relançar retoma).
2. `python -I src/avaliar_B31R.py resultados` → `resultados/avaliacao_B31R.json`.
3. Relatório na ordem Objetivo → Hipóteses → Parâmetros → Protocolo → Medidas → Resultados → Controles → Interpretação.

**Álgebras de relações (B31e) para estados gaussianos.**
- Magnético: Q_i = Z_i − Z_{i0} (i ≠ i0), Π_i = P_i − P_tot/n, centro z = P_tot. A parte quântica usa a covariância de P
  condicionada a P_tot.
- Elétrico: y_i = Z_i − Z_{o*} (i em A, o* uma célula fixa do anel) com P_i; centro Z_o − Z_{o*} (o ≠ o*). A parte quântica
  usa a covariância de y condicionada ao centro.
- A dimensão do centro é verificada de forma independente: núcleo da forma simplética restrita ao espaço gerado pelos
  geradores originais (todas as diferenças e todos os P).

**Mudança de código em relação à B31.** `b31d_ola.py` é a cópia da B31 com uma única mudança: grava o ν mínimo bruto,
antes do piso ½ (corrige a verificação vazia apontada pela auditoria). `b31_rede.py` e `b31a_modular.py` são idênticos aos
da B31 (mesmos SHA-256).

## 5. Medidas

- **B31a-R:** razões ρ_M (melhorada e canônica) e ρ_N; termos cruzados c_N, c_M e os do CHM; localidade por sítio em
  q = 11, 12, 13; perfil diagonal de N; S, S₂; modos cortados.
- **B31e:** S_Z, S_q (magnético e elétrico), h dos centros, dimensões dos centros (prevista e numérica); I_Z, I_mag, I_ele e
  a parte clássica de I (centros); inclinações.
- **B31f:** F1: S, S₂, menores ε, ρ_M e ρ_N com g = β², S_q das relações, e para uma célula M₁₁, N₁₁, ν, ε. F2: para cada
  célula e forma, ΔS₂(t) linear e circular ±, p_E(t), Z(t); tempo e altura do pico (interpolação parabólica), velocidade
  ajustada, razão altura/quasipartícula, retorno antes e depois do pico.

## 6. Regras de decisão (congeladas; `src/avaliar_B31R.py`)

**B31a-R.** Validade: |Δ| entre L = 2048 e 1024 ≤ 10⁻³ (razões e termos cruzados, todos os R); |Δ| entre q = 13 e 12 ≤ 0,01;
ν_min bruto ≥ ½ − 10⁻⁹. Desvio = max |ρ − 1| (ρ_M melhorado e ρ_N); dc = max |c − c_CHM| (N e M, duas direções).
- **INCONCLUSIVO** se a validade falha;
- **NAO_CHM** se em R = 24 alguma razão sai de [0,8; 1,2] ou dc > 0,10;
- **LOCAL_CHM** se em R = 24 o desvio ≤ 0,05, o desvio ≤ o de R = 8 e dc ≤ 0,02;
- **LOCAL_DEFORMADO** nos outros casos.
A localidade por sítio é relatada (com a tendência em q), sem entrar na decisão.

**B31e.** Validade: dimensões dos centros numéricas = previstas (discos e pares); |I(2048) − I(1024)|/I ≤ 0,01 em todos os
pontos e álgebras; I > 0; ν_min ≥ ½ − 10⁻⁹.
- **INCONCLUSIVO** se a validade falha;
- **SEPARA** se, para R_d = 2 e R_d = 3, a inclinação de células ∈ [−2,4; −1,6] e as duas de relações ∈ [−6,8; −5,2];
- **IGUAIS** se, para algum R_d, |inclinação de células − inclinação magnética| ≤ 1;
- **PARCIAL** nos outros casos.

**B31f1.** Validade: |Δρ| entre L = 2048 e 1024 ≤ 10⁻³; |Δρ| entre q = 13 e 12 ≤ 0,01; ν_min ≥ ½ − 10⁻⁹. Desvio(R) =
max(|ρ_M − 1|, |ρ_N − 1|) com q = 13. R* = menor R a partir do qual todos os desvios ficam ≤ 0,05.
- **INCONCLUSIVO** se a validade falha;
- **CELULA_JA_CHM** se a própria célula (R = 0,5) já tem desvio ≤ 0,05 (e todos os maiores também);
- **EMERGE** se a célula tem desvio > 0,05 e o disco R = 8 tem ≤ 0,05;
- **NAO_EMERGE** se R = 8 tem desvio > 0,05.

**B31f2.** Validade: |Z − 1| ≤ 10⁻⁸ (todas as formas, células, polarizações e τ); |ΔS₂(τ₁) − ΔS₂(τ₂)| ≤ 10⁻⁶; energia a
10⁻⁸; |ΔS₂(Lt 1024) − ΔS₂(Lt 2048)| ≤ 1% do menor pico de cada forma; ν_min bruto ≥ ½ − 10⁻⁹. Na célula sozinha,
circular +, τ = 10⁻¹⁰, Lt = 1024:
- O1 (a ola anda): velocidade ajustada dos picos (reta t_pico × x) a ≤ 5% de v_g;
- O2 (levanta e senta): em toda célula, ΔS₂ em t = 0 e em t = 64 ≤ 10% do seu pico;
- helicidade: |ΔS₂(+) − ΔS₂(−)| ≤ 10⁻¹⁰.
Decisões: **INCONCLUSIVO** se a validade falha; **SEM_OLA** se algum pico < 10⁻⁸; **OLA_CELULAR** se O1, O2 e helicidade
passam; **OLA_DEFORMADA** nos outros casos.

**Global (H-par, B31-R):** **INCONCLUSIVA** se B31a-R ou B31f2 forem INCONCLUSIVO; **NÃO APOIADA** se B31a-R = NAO_CHM ou
B31f2 = SEM_OLA; **APOIADA** se B31a-R = LOCAL_CHM e B31f2 = OLA_CELULAR; **PARCIAL** nos outros casos.
**Relatum (B31e)** e **uma célula (B31f1)** têm decisão própria, relatada à parte.

## 7. Fumaça (não vale como resultado)

`python -I src/rodar_B31R.py fumaca` (20/10, 11h14, 3 s), tamanhos e toros fora do conjunto de decisão (fontes L = 256 e 128):
- **A-R** (R = 5 e 6): desvio 0,4% com o tensor melhorado (canônico 12%); dc ≤ 0,004; localidade por sítio 0,998. A
  validade de Lt falha nos toros pequenos (2–3×10⁻³), como esperado.
- **E** (R_d = 2, r = 8 a 24): inclinações −2,10 (células), −6,19 (magnético), −6,31 (elétrico). Centros conferidos (1 e
  |O| − 1). A validade de Lt falha em r = 24 com toros pequenos (1,5–2,3%). Discos: R = 2, S_Z = 1,08, S_q mag = 0,64,
  S_q ele = 0,21.
- **F1** (R = 0,5; 1; 2): razões (M; N) 0,915; 1,062 numa célula, 1,033; 1,059 no hexágono, 1,029; 1,028 em R = 2 → EMERGE com
  R* = 2 nesses toros. Uma célula: S = 0,193, ν = 0,547, ε = 3,10; S_q magnético = 0 (sem parte quântica), elétrico 0,049.
- **F2** (Lt 256/512, células em x = −8, 0, 8, t até 40): a ola anda a 0,996 v_g (célula) e 0,994 v_g (hexágono); alturas
  0,021 → 0,014 (célula) e 0,107 → 0,076 (hexágono), caindo porque o pacote se espalha; altura/quasipartícula 1,27–1,29
  (célula) e 0,97–0,98 (hexágono); circular − linear ≤ 5×10⁻⁵. A última célula ainda não tinha "sentado" em t = 40
  (0,15 do pico) → OLA_DEFORMADA na fumaça; por isso a rodada completa vai até t = 64.
- **Dimensionamento das tolerâncias** (lição da B31a), medido na fumaça e em toros intermediários (512/1024): as diferenças
  de tamanho caem ~8× por duplicação (A-R e E) e ~2× por duplicação (F2). Previsões para a rodada completa: A-R ≈ 5×10⁻⁴ em
  R = 24 (limite 10⁻³); E ≤ 4×10⁻⁴ relativo em r = 48 (limite 10⁻²); F2 ≈ 0,1% do menor pico (limite 1%).
- `src/teste_avaliador_sintetico_B31R.py`: todos os ramos das regras alcançados.

Custo estimado da rodada completa: 5 a 10 minutos; memória de pico ≈ 2,5 GB.

## 8. Limites declarados

- Campo livre, não compacto (sem vórtices nem gap de Polyakov); não é uma fronteira holográfica de verdade.
- Polarização "fora do plano" e cópia dela para o saca-rolha.
- As álgebras de relações são as do campo livre não compacto; a versão compacta (laços de Wilson, cargas) fica para depois.
- A entropia com centro tem uma parte clássica que depende da unidade; só a informação mútua e a parte quântica são
  comparáveis entre álgebras.
- Precisão dupla: modos com ν − ½ < 10^(−q) são cortados (A-R, F1).
- F2 usa ΔS₂ (Rényi-2); a "fração local" p_E é de energia, que numa célula sozinha não é a fração de partícula.

## 9. Arquivos

`src/b31_rede.py`, `src/b31a_modular.py` (idênticos à B31), `src/b31d_ola.py` (cópia com ν bruto), `src/b31ra.py`,
`src/b31e_algebras.py`, `src/b31f_celula.py`, `src/rodar_B31R.py`, `src/avaliar_B31R.py`,
`src/teste_avaliador_sintetico_B31R.py`, `fumaca/`, `LEIAME_B31R.md`, `FUMACA_B31R.md`, `hashes_antes_da_execucao.txt`.

## Referências

- H. Casini, M. Huerta, R. C. Myers, JHEP 05 (2011) 036.
- J. Cardy, J. Phys. A 46, 285402 (2013) (informação mútua de regiões distantes).
- H. Casini, M. Huerta, J. M. Magán, D. Pontello, JHEP 02 (2020) 014 (setores de superseleção; álgebras incompletas).
- H. Casini, M. Huerta, J. A. Rosabal, Phys. Rev. D 89, 085012 (2014) (centros elétrico e magnético na rede).
- H. Casini, M. Huerta, J. Phys. A 42, 504007 (2009).
- M. Nozaki, T. Numasawa, T. Takayanagi, Phys. Rev. Lett. 112, 111602 (2014).
