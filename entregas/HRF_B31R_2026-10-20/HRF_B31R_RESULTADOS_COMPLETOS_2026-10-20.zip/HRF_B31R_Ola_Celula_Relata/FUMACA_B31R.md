# FUMAÇA — B31-R (não vale como resultado)

Rodada `python -I src/rodar_B31R.py fumaca` em 20/10/2026, 11h14 (3 s), nesta sessão (Python 3.13.16, NumPy 2.5.3,
SciPy 1.18.1). Toros e tamanhos fora do conjunto de decisão: fontes L = 256 (principal) e 128 (controle); F2 com Lt = 256/512.
Saídas em `fumaca/`. Avaliador congelado aplicado à fumaça (`fumaca/avaliacao_saida.txt`):

| Bloco | Na fumaça | Por quê |
|---|---|---|
| B31a-R | INCONCLUSIVO | toros pequenos: |Δ| de Lt = 2–3×10⁻³ (limite 10⁻³); física dentro do CHM (desvio 0,4%, dc ≤ 0,004) |
| B31e | INCONCLUSIVO | toros pequenos: |ΔI|/I = 1,5–2,3% em r = 24 (limite 1%); inclinações −2,10 / −6,19 / −6,31 |
| B31f1 | EMERGE (R* = 2) | célula 0,915/1,062; hexágono 1,033/1,059; R = 2: 1,029/1,028 |
| B31f2 | OLA_DEFORMADA | só até t = 40: a última célula ainda estava a 0,15 do pico; velocidade 0,996 v_g |

Números principais:
- **A-R:** R = 5 e 6: desvio 0,40% e 0,35% (canônico 12%); dc 0,0031 e 0,0037; localidade por sítio 0,998 (q = 11 a 13).
- **E:** R_d = 2, r = 8, 12, 16, 24: I_Z = 3,4×10⁻², 1,3×10⁻², 7,2×10⁻³, 3,1×10⁻³; I_mag = 1,1×10⁻³ … 9,7×10⁻⁷;
  I_ele = 4,8×10⁻³ … 3,0×10⁻⁶. Centros: magnético 1, elétrico |O| − 1 (conferidos numericamente).
  Discos: R = 2 (19 células) S_Z = 1,08, S_q mag = 0,64, S_q ele = 0,21; R = 3: 1,54; 1,05; 0,28.
- **F1:** uma célula: S = 0,193, S₂ = 0,090, ν = 0,547, ε = 3,10, M₁₁ = 4,74, N₁₁ = 2,02; S_q mag = 0 (sem parte quântica),
  S_q ele = 0,049. Hexágono: S = 0,625. R = 2: S = 1,078.
- **F2:** alturas (célula) 0,021; 0,017; 0,014 em x = −8, 0, 8; (hexágono) 0,107; 0,091; 0,076; altura/quasipartícula
  1,27–1,29 (célula) e 0,97–0,98 (hexágono); circular − linear ≤ 5×10⁻⁵; helicidades idênticas.

Dimensionamento das tolerâncias (medido aqui com fontes 256, 512 e 1024, para não repetir o erro da B31a):
- E: |ΔI|/I cai 8× por duplicação de L (r = 48: 2,4% → 0,30%) → previsto ≈ 0,04% entre 2048 e 1024 (limite 1%).
- F2: a diferença cai 2× por duplicação de Lt (hexágono: 2,7×10⁻⁴ → 1,3×10⁻⁴) → previsto ≈ 0,1% do menor pico entre 1024
  e 2048 (limite 1%).
- A-R: pela auditoria da B31, 1,6×10⁻⁴ (R/16)³ → ≈ 5×10⁻⁴ em R = 24 (limite 10⁻³).

Teste sintético do avaliador (`fumaca/teste_avaliador_sintetico.txt`): todos os ramos de todas as regras alcançados.
