# LEIAME — B31-R (pacote para rodar em outro lugar)

**Bancada:** HRF B31-R — B31a-R (hamiltoniano modular refeito), B31e (células × relações), B31f (uma célula; ola célula a célula).
**Protocolo:** `HRF_B31R_PROTOCOLO_2026-10-20_1115-clau.md` (leia antes; as regras de decisão estão congeladas).
**Autoria:** Mario José do Canto Filho, MD · preparação: Claude (`-clau`).

## Requisitos

- Python ≥ 3.10, NumPy, SciPy (testado com Python 3.13.16, NumPy 2.5.3, SciPy 1.18.1).
- Memória: ≥ 4 GB livres (pico ≈ 2,5 GB). Tempo: 5 a 10 minutos num núcleo.

## Passo a passo

```bash
unzip HRF_B31R_Ola_Celula_Relata_PREREGISTRO_2026-10-20_1120-clau.zip
cd HRF_B31R_Ola_Celula_Relata
sha256sum -c hashes_antes_da_execucao.txt          # todos devem dar OK
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 python3 -I src/rodar_B31R.py completo > resultados_log.txt 2>&1
python3 -I src/avaliar_B31R.py resultados
```

- Se a rodada for interrompida, é só repetir o mesmo comando: os casos já gravados em
  `resultados/B31R_checkpoint.json` não são refeitos.
- Dá para rodar por bloco: `python3 -I src/rodar_B31R.py completo a` (ou `e`, `f1`, `f2`).
- Não altere nada em `src/`; qualquer mudança invalida o pré-registro.

## O que devolver

Um zip com a pasta inteira depois da rodada, incluindo:
- `resultados/B31R_checkpoint.json`, `resultados/B31R_config_completo.json`, `resultados/avaliacao_B31R.json`;
- `resultados_log.txt`;
- a saída do `sha256sum -c` (pode colar num arquivo `verificacao_hashes.txt`).

## Saída esperada do avaliador

Um JSON curto com as cinco decisões:
`B31aR` (LOCAL_CHM / LOCAL_DEFORMADO / NAO_CHM / INCONCLUSIVO), `B31e` (SEPARA / IGUAIS / PARCIAL / INCONCLUSIVO),
`B31f1` (CELULA_JA_CHM / EMERGE / NAO_EMERGE / INCONCLUSIVO), `B31f2` (OLA_CELULAR / OLA_DEFORMADA / SEM_OLA / INCONCLUSIVO)
e `global_H_par` (APOIADA / PARCIAL / NAO_APOIADA / INCONCLUSIVA).

## Estrutura

```
HRF_B31R_PROTOCOLO_2026-10-20_1115-clau.md   protocolo pré-registrado
LEIAME_B31R.md, FUMACA_B31R.md               este arquivo e o resumo da fumaça
hashes_antes_da_execucao.txt                 SHA-256 do protocolo e do código, antes da rodada
src/                                         código congelado
fumaca/                                      saída da fumaça (não vale como resultado)
```
