# B31-R — entrega completa

Leia RELATORIO_CIENTIFICO_B31R.md e resultados/avaliacao_B31R.json. Inclui a pasta inteira após a execução, o ZIP original e o log da conferência de hashes. fumaca/ não participa da decisão completa.
