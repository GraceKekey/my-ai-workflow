# -*- coding: utf-8 -*-
"""HRF B31f — o limite de uma célula: o GMF sozinho emaranhado com o resto (versão literal da H-par).

F1 (estática). Regiões pequenas: 1 célula (R = 0,5), hexágono de 7 (R = 1) e discos R = 2, 3, 4, 6, 8.
   Para cada uma: S, S2, espectro modular eps_k, núcleos M e N, e comparação com o CHM de rede usando o campo de teste
   g_i = beta_i^2 (beta_i = (R_ef^2 - r_i^2)/(2 R_ef), zero fora), que se anula na borda e existe mesmo em discos pequenos.
   Também a parte quântica das álgebras de relações (B31e) para as mesmas regiões.
F2 (dinâmica: a ola célula a célula). Um quantum em saca-rolha (polarização circular, duas cópias do campo) anda ao
   longo de +x. Para cada célula de uma fila no eixo x, mede-se ΔS2 da célula sozinha (e do hexágono de 7 em volta dela)
   em função do tempo, com a fórmula fechada de Rényi-2 da B31d.
"""
import numpy as np

import b31_rede as rd
import b31a_modular as ma
import b31d_ola as od
import b31e_algebras as ea


# ----------------------------------------------------------------------------------------------- F1
def estatica(R, fontes, qs=(12, 13)):
    idx = rd.disco(R)
    xy = np.array([rd.coords(a, b) for a, b in idx])
    E = rd.arestas_internas(idx).reshape(-1, 2)  # uma célula: nenhuma aresta interna
    n = len(idx)
    Ref = float(np.sqrt(n * rd.A_C / np.pi))
    r = np.hypot(xy[:, 0], xy[:, 1])
    beta = np.maximum(Ref * Ref - r * r, 0.0) / (2 * Ref)
    g = beta ** 2
    g = g / np.max(np.abs(g))
    out = {"R_nominal": R, "R_efetivo": Ref, "n_sitios": int(n), "n_arestas_internas": int(len(E)), "por_correlador": {}}
    for rot, fonte in fontes.items():
        XA, PA = fonte(idx)
        nu, W, Xh, Xmh = ma.williamson(XA, PA)
        S, S2 = ma.entropias(nu)
        sub = {"nu_min_bruto": float(nu.min()), "nu_max": float(nu.max()), "S": S, "S2": S2, "por_q": {}}
        _, eps_todos = ma.eps_de(nu, 16)
        sub["eps_menores"] = [float(x) for x in np.sort(eps_todos)[:5]]
        for q in qs:
            M, N, eps = ma.nucleos(nu, W, Xh, Xmh, q)
            Mc, Mm, Np = ma.previsoes(g, xy, E, Ref, 0.0)
            gm, gn = float(g @ M @ g), float(g @ N @ g)
            sub["por_q"][str(q)] = {"modos_cortados": int(np.sum(nu - 0.5 < 10.0 ** (-q))),
                                    "rho_M_mel": gm / Mm, "rho_M_can": (gm / Mc) if Mc > 0 else None, "rho_N": gn / Np}
            if n == 1:
                sub["por_q"][str(q)]["celula"] = {"M11": float(M[0, 0]), "N11": float(N[0, 0]), "X": float(XA[0, 0]),
                                                  "P": float(PA[0, 0]), "nu": float(nu[0]), "eps": float(eps[0])}
        # álgebras de relações para a mesma região (parte quântica e centro)
        reg = ea.Regioes([(0, 0)], R)
        alg = ea.entropias(fonte, reg)
        sub["algebras"] = {"S_Z": alg["S_Z"],
                           "mag": {k: alg["mag"][k] for k in ("S_q", "h", "dim_centro")},
                           "ele": {k: alg["ele"][k] for k in ("S_q", "h", "dim_centro")}}
        out["por_correlador"][rot] = sub
    return out


# ----------------------------------------------------------------------------------------------- F2
def velocidade_grupo(k0):
    """velocidade de grupo d omega / d k_x no vetor k0 = (kx, 0) da relação de dispersão do tapete."""
    kx = k0[0]
    w2 = (4.0 / 3.0) * (3 - np.cos(kx) - 2 * np.cos(kx / 2))
    return float((4.0 / 3.0) * (np.sin(kx) + np.sin(kx / 2)) / (2 * np.sqrt(w2)))


def ola_celular(Lt, xs_celulas, formas, k0, dk, x_ini, tempos, taus=(1e-10, 1e-12)):
    """formas: {"celula": R = 0.5, "hexagono": R = 1}. Para cada forma e cada célula da fila (n1 = x, n2 = 0),
    a série ΔS2(t) (linear, circular +, circular -), p_E(t), Z(t)."""
    Xg, Pg = rd.correladores(Lt, 0.0)
    regs = {}
    for nome, R in formas.items():
        base = rd.disco(R)
        XA = rd.bloco(Xg, base, Lt)
        PA = rd.bloco(Pg, base, Lt)
        nu, Gphi, Gpi = od.williamson_modos(XA, PA)
        regs[nome] = {"base": base, "XA": XA, "PA": PA, "n": nu - 0.5, "Gphi": Gphi, "Gpi": Gpi,
                      "nu_min_bruto": od.williamson_modos.nu_min_bruto}
    series = {nome: {str(x): [] for x in xs_celulas} for nome in formas}
    globais = []
    r2 = 1.0 / np.sqrt(2.0)
    for t in tempos:
        al, be, f, w = rd.pacote(Lt, 0.0, k0, dk, (x_ini, 0.0), t)
        e = rd.densidade_energia(al, be, 0.0)
        Etot = float(e.sum())
        globais.append({"t": float(t), "E_total": Etot, "E_esperada": float(np.sum(np.abs(f) ** 2 * w))})
        for nome, Rg in regs.items():
            for x in xs_celulas:
                idx = Rg["base"] + np.array([x, 0])
                sel = (idx[:, 0] % Lt, idx[:, 1] % Lt)
                aA, bA = al[sel], be[sel]
                pE = float(e[sel].sum() / Etot)
                cnorm = od.norma_complemento(aA, bA, Rg["XA"], Rg["PA"])
                p, q = od.coef_modos(aA, bA, Rg["Gphi"], Rg["Gpi"])
                lin = {"t": float(t), "p_E": pE, "dS2_quasiparticula": float(-np.log(pE ** 2 + (1 - pE) ** 2))}
                for tau in taus:
                    d_lin, Z, c, _ = od.renyi2([p], [q], Rg["n"], tau, cnorm)
                    d_cp, Zp, _, _ = od.renyi2([p * r2, 1j * p * r2], [q * r2, 1j * q * r2], Rg["n"], tau, cnorm)
                    d_cm, Zm, _, _ = od.renyi2([p * r2, -1j * p * r2], [q * r2, -1j * q * r2], Rg["n"], tau, cnorm)
                    lin[f"tau={tau:g}"] = {"dS2_linear": d_lin, "dS2_circ_mais": d_cp, "dS2_circ_menos": d_cm,
                                           "Z_linear": Z, "Z_circ_mais": Zp, "Z_circ_menos": Zm}
                series[nome][str(x)].append(lin)
    return {"Lt": Lt, "k0": list(k0), "dk": dk, "x_ini": x_ini, "v_g": velocidade_grupo(k0),
            "formas": {nome: {"R": R, "n_sitios": int(len(regs[nome]["base"])), "nu_min_bruto": regs[nome]["nu_min_bruto"]}
                       for nome, R in formas.items()},
            "globais": globais, "series": series}


def pico(ts, ys):
    """tempo e altura do máximo com interpolação parabólica nos três pontos em volta do máximo amostrado."""
    ts, ys = np.asarray(ts, float), np.asarray(ys, float)
    i = int(np.argmax(ys))
    if 0 < i < len(ys) - 1:
        y0, y1, y2 = ys[i - 1], ys[i], ys[i + 1]
        den = y0 - 2 * y1 + y2
        d = 0.5 * (y0 - y2) / den if den != 0 else 0.0
        h = ts[1] - ts[0]
        return float(ts[i] + d * h), float(y1 - 0.25 * (y0 - y2) * d)
    return float(ts[i]), float(ys[i])
