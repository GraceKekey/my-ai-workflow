# -*- coding: utf-8 -*-
"""Exercita todos os ramos do avaliador congelado da B31-R com dados sintéticos derivados da fumaça (não é resultado)."""
import copy
import json
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import avaliar_B31R as av  # noqa: E402

pasta = AQUI.parent / "fumaca"
base = json.load(open(pasta / "B31R_checkpoint.json"))["casos"]
cfg = json.load(open(pasta / "B31R_config_fumaca.json"))["config"]
Lp, Lc = av.rotulos(cfg)
vistos = {k: set() for k in ("aR", "e", "f1", "f2", "g")}


def controle_igual(c, prefixo):
    """faz o correlador de controle igual ao principal (torna a validade de Lt satisfeita)."""
    for k, v in c.items():
        if k.startswith(prefixo) and "por_correlador" in v:
            v["por_correlador"][Lc] = copy.deepcopy(v["por_correlador"][Lp])


# ---------------------------------------------------------------- A-R
def a_mexe(c, fun):
    for R in cfg["B31aR"]["R"]:
        for q, Q in c[f"B31aR|R={R}"]["por_correlador"][Lp]["por_q"].items():
            fun(R, q, Q)


def a_chm(R, q, Q):
    for t in Q["testes"]:
        t.update(rho_M_mel=1 + 0.01 / R, rho_N=1 + 0.01 / R)
    for x in Q["cruzados"]:
        x.update(c_N=x["c_N_CHM"] + 0.001, c_M=x["c_M_CHM"] + 0.001)


Rmax = max(cfg["B31aR"]["R"])
for nome, extra in {"chm": None,
                    "nao": lambda R, q, Q: [x.update(c_N=x["c_N_CHM"] + 0.2) for x in Q["cruzados"]] if R == Rmax else None,
                    "deform": lambda R, q, Q: [x.update(c_N=x["c_N_CHM"] + 0.05) for x in Q["cruzados"]] if R == Rmax else None,
                    "inconc": "L"}.items():
    c = copy.deepcopy(base)
    a_mexe(c, a_chm)
    if extra not in (None, "L"):
        a_mexe(c, extra)
    if extra != "L":
        controle_igual(c, "B31aR|")
    r = av.avaliar_aR(c, cfg)
    vistos["aR"].add(r["decisao"])
    print("B31aR", nome, "->", r["decisao"])

# ---------------------------------------------------------------- E
rs = cfg["B31e"]["MI"]["2"]


def e_mexe(c, fun):
    for r in rs:
        fun(r, c[f"B31e|MI|Rd=2|r={r}"]["por_correlador"][Lp])


for nome in ("separa", "iguais", "parcial", "inconc"):
    c = copy.deepcopy(base)
    if nome == "iguais":
        e_mexe(c, lambda r, P: P.update(I_mag=P["I_Z"]))
    if nome == "parcial":
        e_mexe(c, lambda r, P: P.update(I_ele=P["I_ele"] * r ** 2.5))
    if nome != "inconc":
        controle_igual(c, "B31e|")
    else:
        c[f"B31e|disco|R={cfg['B31e']['discos'][0]}"]["dim_centro_numerica"]["ele"] += 1
        controle_igual(c, "B31e|")
    r = av.avaliar_e(c, cfg)
    vistos["e"].add(r["decisao"])
    print("B31e", nome, "->", r["decisao"], r["inclinacoes"])

# ---------------------------------------------------------------- F1
for nome in ("celula", "emerge", "nao", "inconc"):
    c = copy.deepcopy(base)
    Rs = cfg["B31f1"]["R"]
    for R in Rs:
        for Q in c[f"B31f1|R={R}"]["por_correlador"][Lp]["por_q"].values():
            if nome == "celula":
                Q.update(rho_M_mel=1.01, rho_N=0.99)
            if nome == "nao" and R == max(Rs):
                Q.update(rho_M_mel=1.2, rho_N=1.2)
    controle_igual(c, "B31f1|")
    if nome == "inconc":
        c[f"B31f1|R={Rs[0]}"]["por_correlador"][Lc]["por_q"]["13"]["rho_N"] += 0.01
    r = av.avaliar_f1(c, cfg)
    vistos["f1"].add(r["decisao"])
    print("B31f1", nome, "->", r["decisao"], "R* =", r["R_estrela"])


# ---------------------------------------------------------------- F2
def f2_mexe(c, fun):
    for Lt in cfg["B31f2"]["Lt"]:
        fun(c[f"B31f2|Lt={Lt}"])


def senta(s):  # a última amostra de cada célula volta a zero
    for porx in s["series"].values():
        for ser in porx.values():
            for tau in ("tau=1e-10", "tau=1e-12"):
                for kk in ("dS2_linear", "dS2_circ_mais", "dS2_circ_menos"):
                    ser[-1][tau][kk] = 0.0


def some(s):
    for porx in s["series"].values():
        for ser in porx.values():
            for l in ser:
                for tau in ("tau=1e-10", "tau=1e-12"):
                    for kk in ("dS2_linear", "dS2_circ_mais", "dS2_circ_menos"):
                        l[tau][kk] *= 1e-9


def zruim(s):
    s["series"]["celula"][str(cfg["B31f2"]["xs"][0])][0]["tau=1e-10"]["Z_circ_mais"] = 1.001


for nome, fun in {"ola": senta, "deformada": lambda s: None, "sem": some, "inconc": zruim}.items():
    c = copy.deepcopy(base)
    f2_mexe(c, fun)
    r = av.avaliar_f2(c, cfg)
    vistos["f2"].add(r["decisao"])
    print("B31f2", nome, "->", r["decisao"])

# ---------------------------------------------------------------- global
for a, f in [("LOCAL_CHM", "OLA_CELULAR"), ("LOCAL_DEFORMADO", "OLA_CELULAR"), ("NAO_CHM", "OLA_CELULAR"),
             ("LOCAL_CHM", "INCONCLUSIVO"), ("LOCAL_CHM", "SEM_OLA")]:
    vistos["g"].add(av.global_({"decisao": a}, {"decisao": f}))
print(json.dumps({k: sorted(v) for k, v in vistos.items()}, ensure_ascii=False))
esperado = {"aR": {"LOCAL_CHM", "NAO_CHM", "LOCAL_DEFORMADO", "INCONCLUSIVO"},
            "e": {"SEPARA", "IGUAIS", "PARCIAL", "INCONCLUSIVO"},
            "f1": {"CELULA_JA_CHM", "EMERGE", "NAO_EMERGE", "INCONCLUSIVO"},
            "f2": {"OLA_CELULAR", "OLA_DEFORMADA", "SEM_OLA", "INCONCLUSIVO"},
            "g": {"APOIADA", "PARCIAL", "NAO_APOIADA", "INCONCLUSIVA"}}
assert all(vistos[k] == esperado[k] for k in esperado), "ramo não alcançado"
print("todos os ramos alcançados")
