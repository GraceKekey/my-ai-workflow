# -*- coding: utf-8 -*-
"""HRF B31 — tapete triangular da E-65 (fronteira), campo Z nos GMFs, vácuo gaussiano.

Convenções (iguais à E-65): espaçamento a = 1, w_e = 1/sqrt(3) (peso cotangente), A_i = sqrt(3)/2 (área de Voronoi),
H = sum_i P_i^2/(2A) + 1/2 sum_e w (Z_i - Z_j)^2 + 1/2 sum_i m^2 A Z_i^2, velocidade da luz c = 1.
Sítio (n1, n2) -> x = n1 + n2/2, y = n2*sqrt(3)/2.
Correlatores de vácuo no plano infinito aproximados num toro Lt x Lt (modo zero excluído quando m = 0).
"""
import numpy as np

S3 = np.sqrt(3.0)
W_E = 1.0 / S3
A_C = S3 / 2.0
VIZ = [(1, 0), (0, 1), (-1, 1), (-1, 0), (0, -1), (1, -1)]  # 6 vizinhos em (n1, n2)


def coords(n1, n2):
    return n1 + 0.5 * n2, 0.5 * S3 * n2


def thetas(Lt):
    t = 2 * np.pi * np.fft.fftfreq(Lt) * 1.0  # em (-pi, pi]
    return np.meshgrid(t, t, indexing="ij")


def omega2(T1, T2, m):
    return (4.0 / 3.0) * (3.0 - np.cos(T1) - np.cos(T2) - np.cos(T1 - T2)) + m * m


def k_cart(T1, T2):
    """vetor de onda cartesiano a partir das fases nas direções a1, a2."""
    return T1, (2.0 * T2 - T1) / S3


def correladores(Lt, m):
    """X(n) = <Z_0 Z_n>, P(n) = <P_0 P_n> no toro, como grades Lt x Lt indexadas por (n1 mod Lt, n2 mod Lt)."""
    T1, T2 = thetas(Lt)
    w2 = omega2(T1, T2, m)
    w = np.sqrt(np.maximum(w2, 0.0))
    inv = np.zeros_like(w)
    ok = w > 0
    inv[ok] = 1.0 / (2.0 * A_C * w[ok])
    Xg = np.real(np.fft.ifft2(inv))
    Pg = np.real(np.fft.ifft2(A_C * w / 2.0))
    return Xg, Pg


def disco(R):
    """sítios com |x| <= R (centro no sítio (0,0)), em ordem fixa."""
    lim = int(np.ceil(2 * R / S3)) + 2
    pts = []
    for n2 in range(-lim, lim + 1):
        for n1 in range(-lim - abs(n2), lim + abs(n2) + 1):
            x, y = coords(n1, n2)
            if x * x + y * y <= R * R + 1e-9:
                pts.append((n1, n2))
    pts.sort(key=lambda p: (p[1], p[0]))
    return np.array(pts, dtype=int)


def bloco(G, idx, Lt):
    """submatriz G(n_i - n_j) para a lista de sítios idx (N x 2)."""
    d1 = (idx[:, 0][:, None] - idx[:, 0][None, :]) % Lt
    d2 = (idx[:, 1][:, None] - idx[:, 1][None, :]) % Lt
    return G[d1, d2]


def arestas_internas(idx):
    """arestas (i, j) com i < j, ambos no conjunto idx."""
    pos = {tuple(p): k for k, p in enumerate(idx)}
    E = []
    for k, (a, b) in enumerate(idx):
        for (d1, d2) in VIZ[:3]:
            j = pos.get((a + d1, b + d2))
            if j is not None:
                E.append((k, j))
    return np.array(E, dtype=int)


def pacote(Lt, m, k0, dk, x0, t, pol=None):
    """operador de criação a^dagger(f) = sum_n (alpha_n Z_n + beta_n P_n) de um pacote gaussiano no espaço k.
    f(k) ~ exp(-|k-k0|^2/(4 dk^2)) exp(-i k.x0) exp(-i w t); normalizado sum |f|^2 = 1.
    Devolve grades alpha, beta (Lt x Lt, complexas), f e w."""
    T1, T2 = thetas(Lt)
    kx, ky = k_cart(T1, T2)
    w = np.sqrt(omega2(T1, T2, m))
    f = np.exp(-((kx - k0[0]) ** 2 + (ky - k0[1]) ** 2) / (4 * dk * dk)) * np.exp(-1j * (kx * x0[0] + ky * x0[1]))
    f[w == 0] = 0.0
    f = f / np.sqrt(np.sum(np.abs(f) ** 2))
    f = f * np.exp(-1j * w * t)
    N = Lt * Lt
    ws = np.where(w > 0, w, 1.0)
    alpha = np.sqrt(N) * np.fft.ifft2(f * np.sqrt(A_C * ws / 2.0))
    beta = -1j * np.sqrt(N) * np.fft.ifft2(f / np.sqrt(2.0 * A_C * ws))
    return alpha, beta, f, w


def densidade_energia(alpha, beta, m):
    """excesso de energia do estado de uma partícula em cada sítio (grade): cinético + metade das arestas + massa."""
    e = np.abs(alpha) ** 2 / A_C + m * m * A_C * np.abs(beta) ** 2
    for (d1, d2) in VIZ[:3]:
        db = beta - np.roll(np.roll(beta, -d1, axis=0), -d2, axis=1)
        pe = W_E * np.abs(db) ** 2
        e = e + 0.5 * pe + 0.5 * np.roll(np.roll(pe, d1, axis=0), d2, axis=1)
    return e


def grade_em(G, idx, Lt):
    return G[idx[:, 0] % Lt, idx[:, 1] % Lt]


class Fonte:
    """correladores do plano infinito por extrapolação de Richardson em 1/Lt: G = 2 G(2L) - G(L)."""

    def __init__(self, L, m):
        self.L, self.m = L, m
        self.X1, self.P1 = correladores(L, m)
        self.X2, self.P2 = correladores(2 * L, m)

    def __call__(self, idx):
        XA = 2 * bloco(self.X2, idx, 2 * self.L) - bloco(self.X1, idx, self.L)
        PA = 2 * bloco(self.P2, idx, 2 * self.L) - bloco(self.P1, idx, self.L)
        return XA, PA
