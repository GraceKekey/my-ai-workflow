# -*- coding: utf-8 -*-
"""HRF B31e — células ou relações? O mesmo vácuo visto por três álgebras de uma região A de GMFs.

Variáveis do tapete: Z_i (valor da célula) e P_i (momento conjugado; no lado dual, P_i é o fluxo B da bolha i).
1. Álgebra de CÉLULAS  A_Z(A)   = {Z_i, P_i : i em A}. Cada GMF é um fator tensorial próprio. Sem centro.
2. Álgebra de RELAÇÕES, centro MAGNÉTICO A_mag(A) = {Z_i - Z_j (i, j em A), P_i (i em A)}.
   Só diferenças (paredes internas) e fluxos das bolhas. Centro: P_tot(A) = soma dos P = fluxo total pela borda.
   Coordenadas canônicas: Q_i = Z_i - Z_i0 (i != i0), Pi_i = P_i - P_tot/n; centro z = P_tot.
3. Álgebra de RELAÇÕES, centro ELÉTRICO A_ele(A) = {Z_u - Z_v (u, v em A U O), P_i (i em A)}, O = anel externo de vizinhos.
   Inclui as paredes que cruzam a borda. Coordenadas canônicas: y_i = Z_i - Z_o* (i em A) com P_i;
   centro: Z_o - Z_o* (o em O, o != o*), dimensão |O| - 1.
Para um estado gaussiano, S(álgebra) = h(centro) [entropia diferencial, depende da unidade] + S_q, onde S_q é a entropia
de von Neumann da parte quântica condicionada ao centro (independe do valor do centro). A informação mútua entre regiões
separadas, I = S(A) + S(B) - S(AB), não depende da unidade.
Previsão (Cardy, J. Phys. A 46, 285402, 2013): I ~ (R_A R_B / r^2)^(2 Delta), com Delta o menor peso de escala na
álgebra: células, Delta = 1/2 (o próprio Z) -> I ~ r^-2; relações, Delta = 3/2 (gradiente e P) -> I ~ r^-6.
(Álgebras incompletas e centros: Casini–Huerta–Magán–Pontello, JHEP 02 (2020) 014; Casini–Huerta–Rosabal 2014.)
"""
import numpy as np
from scipy.linalg import eigh

import b31_rede as rd


def anel_externo(idx):
    """vizinhos de A que não estão em A (ordem fixa)."""
    pos = {tuple(p) for p in idx}
    O = []
    for (a, b) in idx:
        for (d1, d2) in rd.VIZ:
            v = (a + d1, b + d2)
            if v not in pos and v not in O:
                O.append(v)
    O.sort(key=lambda p: (p[1], p[0]))
    return np.array(O, dtype=int)


def nu_canonico(Xq, Pp):
    """autovalores simpléticos de blocos canônicos sem correlação cruzada (posição x momento)."""
    ex, U = eigh(0.5 * (Xq + Xq.T))
    if ex.min() <= 0:
        raise ValueError("covariância de posição não positiva")
    Xh = (U * np.sqrt(ex)) @ U.T
    C2 = Xh @ Pp @ Xh
    nu2 = eigh(0.5 * (C2 + C2.T), eigvals_only=True)
    return np.sqrt(np.maximum(nu2, 0.0)), float(np.sqrt(nu2.min()))


def S_de_nu(nu):
    a = np.maximum(nu - 0.5, 0.0)
    b = nu + 0.5
    with np.errstate(divide="ignore", invalid="ignore"):
        ta = np.where(a > 0, a * np.log(np.where(a > 0, a, 1.0)), 0.0)
    return float(np.sum(b * np.log(b) - ta))


def h_gauss(Sig):
    Sig = np.atleast_2d(Sig)
    k = Sig.shape[0]
    if k == 0:
        return 0.0
    sgn, ld = np.linalg.slogdet(Sig)
    if sgn <= 0:
        raise ValueError("covariância do centro não positiva")
    return float(0.5 * (k * np.log(2 * np.pi * np.e) + ld))


def condicional(S_yy, S_yc, S_cc):
    if S_cc.shape[0] == 0:
        return S_yy
    return S_yy - S_yc @ np.linalg.solve(S_cc, S_yc.T)


class Regioes:
    """união de discos (separados) com as matrizes de mudança de variável de cada álgebra."""

    def __init__(self, centros, Rd):
        self.partes = []
        for c in centros:
            d = rd.disco(Rd) + np.array(c, dtype=int)
            self.partes.append({"A": d, "O": anel_externo(d)})
        todos = [tuple(p) for P in self.partes for p in np.vstack([P["A"], P["O"]])]
        if len(set(todos)) != len(todos):
            raise ValueError("regiões (com anéis) se sobrepõem")


def entropias(fonte, reg):
    """S_Z, (h, S_q) magnético e elétrico para a união das partes de reg. fonte(idx) -> (X, P) do plano infinito."""
    # --- células
    A = np.vstack([P["A"] for P in reg.partes])
    XA, PA = fonte(A)
    nuZ, nminZ = nu_canonico(XA, PA)
    out = {"n": int(len(A)), "S_Z": S_de_nu(nuZ), "nu_min_Z": nminZ}
    # --- magnético: Q = D Z_A, Pi = E P_A, z = U P_A (uma linha por parte)
    n = len(A)
    D, Erows, Urows = [], [], []
    k0 = 0
    for P in reg.partes:
        m = len(P["A"])
        for i in range(1, m):
            r = np.zeros(n); r[k0 + i] = 1.0; r[k0] = -1.0; D.append(r)
            e = np.zeros(n); e[k0 + i] = 1.0; e[k0:k0 + m] -= 1.0 / m; Erows.append(e)
        u = np.zeros(n); u[k0:k0 + m] = 1.0; Urows.append(u)
        k0 += m
    U = np.array(Urows)
    Pcc = U @ PA @ U.T
    if len(D) == 0:  # uma célula só: a álgebra de relações não tem parte quântica (só o centro P_0)
        SqM, nminM = 0.0, float("nan")
    else:
        D, Em = np.array(D), np.array(Erows)
        Xq = D @ XA @ D.T
        Pyy, Pyc = Em @ PA @ Em.T, Em @ PA @ U.T
        nuM, nminM = nu_canonico(Xq, condicional(Pyy, Pyc, Pcc))
        SqM = S_de_nu(nuM)
    out["mag"] = {"h": h_gauss(Pcc), "S_q": SqM, "dim_centro": int(U.shape[0]), "nu_min": nminM,
                  "var_centro": [float(v) for v in np.diag(Pcc)]}
    # --- elétrico: y = Z_A - Z_o*, centro = Z_o - Z_o* (o != o*), por parte
    B = np.vstack([np.vstack([P["A"], P["O"]]) for P in reg.partes])
    XB, _ = fonte(B)
    nb = len(B)
    Y, C = [], []
    k0 = 0
    for P in reg.partes:
        m, o = len(P["A"]), len(P["O"])
        estrela = k0 + m  # primeiro sítio do anel desta parte
        for i in range(m):
            r = np.zeros(nb); r[k0 + i] = 1.0; r[estrela] -= 1.0; Y.append(r)
        for j in range(1, o):
            r = np.zeros(nb); r[estrela + j] = 1.0; r[estrela] -= 1.0; C.append(r)
        k0 += m + o
    Y, C = np.array(Y), np.array(C)
    Xyy, Xyc, Xcc = Y @ XB @ Y.T, Y @ XB @ C.T, C @ XB @ C.T
    nuE, nminE = nu_canonico(condicional(Xyy, Xyc, Xcc), PA)
    out["ele"] = {"h": h_gauss(Xcc), "S_q": S_de_nu(nuE), "dim_centro": int(C.shape[0]), "nu_min": nminE}
    out["mag"]["S"] = out["mag"]["h"] + out["mag"]["S_q"]
    out["ele"]["S"] = out["ele"]["h"] + out["ele"]["S_q"]
    return out


def dim_centro_numerica(reg, qual):
    """dimensão do núcleo da matriz de comutadores do conjunto gerador original (verificação independente)."""
    rows_Z, rows_P = [], []
    if qual == "mag":
        A = np.vstack([P["A"] for P in reg.partes]); n = len(A)
        k0 = 0
        for P in reg.partes:
            m = len(P["A"])
            for i in range(m):
                for j in range(i + 1, m):
                    r = np.zeros(n); r[k0 + i] = 1; r[k0 + j] = -1; rows_Z.append(r)
            k0 += m
        geradores = [np.concatenate([r, np.zeros(n)]) for r in rows_Z] + [np.concatenate([np.zeros(n), e]) for e in np.eye(n)]
    else:
        A = np.vstack([P["A"] for P in reg.partes])
        Bl = np.vstack([np.vstack([P["A"], P["O"]]) for P in reg.partes]); nb = len(Bl)
        lista_A = {tuple(p): k for k, p in enumerate(Bl) if any((p == a).all() for a in A)}
        k0 = 0
        for P in reg.partes:
            m = len(P["A"]) + len(P["O"])
            for i in range(m):
                for j in range(i + 1, m):
                    r = np.zeros(nb); r[k0 + i] = 1; r[k0 + j] = -1; rows_Z.append(r)
            k0 += m
        geradores = [np.concatenate([r, np.zeros(nb)]) for r in rows_Z]
        for k in lista_A.values():
            e = np.zeros(nb); e[k] = 1.0
            geradores.append(np.concatenate([np.zeros(nb), e]))
    G = np.array(geradores)
    nn = G.shape[1] // 2
    J = np.block([[np.zeros((nn, nn)), np.eye(nn)], [-np.eye(nn), np.zeros((nn, nn))]])
    # subespaço gerado V (base ortonormal) e forma simplética restrita
    Uv, sv, _ = np.linalg.svd(G.T, full_matrices=False)
    V = Uv[:, sv > 1e-9 * sv.max()]
    Om = V.T @ J @ V
    s = np.linalg.svd(Om, compute_uv=False)
    return int(np.sum(s < 1e-9 * max(s.max(), 1.0)))


def informacao_mutua(fonte, Rd, r):
    """I(A:B) para dois discos de raio Rd centrados em (0,0) e (r,0) [direção a1], nas três álgebras."""
    a = Regioes([(0, 0)], Rd)
    b = Regioes([(r, 0)], Rd)
    ab = Regioes([(0, 0), (r, 0)], Rd)
    Ea, Eb, Eab = entropias(fonte, a), entropias(fonte, b), entropias(fonte, ab)
    out = {"Rd": Rd, "r": r, "n_por_disco": Ea["n"],
           "I_Z": Ea["S_Z"] + Eb["S_Z"] - Eab["S_Z"]}
    for alg in ("mag", "ele"):
        out[f"I_{alg}"] = Ea[alg]["S"] + Eb[alg]["S"] - Eab[alg]["S"]
        out[f"I_{alg}_classica"] = Ea[alg]["h"] + Eb[alg]["h"] - Eab[alg]["h"]
    out["nu_min"] = min(Eab["nu_min_Z"], Eab["mag"]["nu_min"], Eab["ele"]["nu_min"])
    return out


def inclinacao(rs, Is):
    return float(np.polyfit(np.log(np.asarray(rs, float)), np.log(np.asarray(Is, float)), 1)[0])


# ------------------------------------------------------------------ casos gravados no checkpoint
def caso_disco(R, fontes):
    reg = Regioes([(0, 0)], R)
    out = {"R": R, "n_sitios": int(len(reg.partes[0]["A"])), "anel": int(len(reg.partes[0]["O"])),
           "dim_centro_numerica": {"mag": dim_centro_numerica(reg, "mag"), "ele": dim_centro_numerica(reg, "ele")},
           "dim_centro_prevista": {"mag": 1, "ele": int(len(reg.partes[0]["O"])) - 1}, "por_correlador": {}}
    for rot, fonte in fontes.items():
        out["por_correlador"][rot] = entropias(fonte, reg)
    return out


def caso_MI(Rd, r, fontes):
    ab = Regioes([(0, 0), (r, 0)], Rd)
    nO = int(len(ab.partes[0]["O"]))
    out = {"Rd": Rd, "r": r, "dim_centro_numerica": {"mag": dim_centro_numerica(ab, "mag"), "ele": dim_centro_numerica(ab, "ele")},
           "dim_centro_prevista": {"mag": 2, "ele": 2 * (nO - 1)}, "por_correlador": {}}
    for rot, fonte in fontes.items():
        out["por_correlador"][rot] = informacao_mutua(fonte, Rd, r)
    return out
