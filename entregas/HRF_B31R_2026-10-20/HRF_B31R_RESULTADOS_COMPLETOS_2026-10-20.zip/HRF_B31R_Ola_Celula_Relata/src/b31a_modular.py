# -*- coding: utf-8 -*-
"""HRF B31a/B31c — hamiltoniano modular de um disco de GMFs no vácuo (Z nos GMFs).

rho_A = exp(-K_A)/Z,  K_A = 1/2 Z^T M Z + 1/2 P^T N P  (estado gaussiano, sem termos cruzados).
Com C^2 = X^{1/2} P X^{1/2} = W diag(nu^2) W^T e eps = log((nu+1/2)/(nu-1/2)):
    M = X^{-1/2} W diag(nu*eps) W^T X^{-1/2},   N = X^{1/2} W diag(eps/nu) W^T X^{1/2}.
Modos com nu - 1/2 < 10^-q são cortados em eps_max = log((1+10^-q)/10^-q) (limite da precisão dupla);
a validade exige que as razões não dependam do corte (q = 12 contra q = 14).

Previsão de Casini–Huerta–Myers (CFT, disco de raio R): K = 2 pi int beta(r) T_00, beta(r) = (R^2 - r^2)/(2R),
com o tensor melhorado do escalar conforme (xi = 1/8): para campos de teste nulos perto da borda,
    <g, M g>_prev = 2 pi sum_e beta_e w (g_i - g_j)^2 + (pi/R) sum_i A g_i^2   [+ 2 pi sum_i beta_i m^2 A g_i^2 se m > 0]
    <h, N h>_prev = 2 pi sum_i beta_i h_i^2 / A.
"""
import numpy as np
from scipy.linalg import eigh

import b31_rede as rd


def williamson(XA, PA):
    ex, U = eigh(XA)
    if ex.min() <= 0:
        raise ValueError("X_A não é positiva")
    Xh = (U * np.sqrt(ex)) @ U.T
    Xmh = (U / np.sqrt(ex)) @ U.T
    C2 = Xh @ PA @ Xh
    C2 = 0.5 * (C2 + C2.T)
    nu2, W = eigh(C2)
    nu = np.sqrt(np.maximum(nu2, 0.0))
    return nu, W, Xh, Xmh


def eps_de(nu, q):
    nuc = np.maximum(nu, 0.5 + 10.0 ** (-q))
    return nuc, np.log((nuc + 0.5) / (nuc - 0.5))


def nucleos(nu, W, Xh, Xmh, q):
    nuc, eps = eps_de(nu, q)
    M = (Xmh @ W) @ np.diag(nuc * eps) @ (Xmh @ W).T
    N = (Xh @ W) @ np.diag(eps / nuc) @ (Xh @ W).T
    return 0.5 * (M + M.T), 0.5 * (N + N.T), eps


def entropias(nu):
    a = np.maximum(nu - 0.5, 1e-300)
    b = nu + 0.5
    S = float(np.sum(b * np.log(b) - a * np.log(a)))
    S2 = float(np.sum(np.log(2.0 * np.maximum(nu, 0.5))))
    return S, S2


def janela(r, R):
    w = np.ones_like(r)
    zona = (r > 0.7 * R) & (r < 0.9 * R)
    w[zona] = np.cos(0.5 * np.pi * (r[zona] - 0.7 * R) / (0.2 * R)) ** 2
    w[r >= 0.9 * R] = 0.0
    return w


def funcoes_teste(xy, R, desloc, direcoes, sigma_rel=0.2):
    r = np.hypot(xy[:, 0], xy[:, 1])
    jan = janela(r, R)
    out = []
    for s in desloc:
        for ang in direcoes:
            x0 = s * R * np.array([np.cos(np.radians(ang)), np.sin(np.radians(ang))])
            sig = sigma_rel * R
            g = np.exp(-((xy[:, 0] - x0[0]) ** 2 + (xy[:, 1] - x0[1]) ** 2) / (2 * sig * sig)) * jan
            out.append({"s": s, "dir": ang, "g": g})
    return out


def previsoes(g, xy, E, R, m):
    beta = lambda x, y: (R * R - (x * x + y * y)) / (2 * R)
    i, j = E[:, 0], E[:, 1]
    mx = 0.5 * (xy[i, 0] + xy[j, 0])
    my = 0.5 * (xy[i, 1] + xy[j, 1])
    grad = 2 * np.pi * np.sum(beta(mx, my) * rd.W_E * (g[i] - g[j]) ** 2)
    bet_i = beta(xy[:, 0], xy[:, 1])
    massa = 2 * np.pi * np.sum(bet_i * m * m * rd.A_C * g * g)
    melhoria = (np.pi / R) * np.sum(rd.A_C * g * g)
    M_can = grad + massa
    M_mel = grad + massa + melhoria
    N_prev = 2 * np.pi * np.sum(bet_i * g * g / rd.A_C)
    return M_can, M_mel, N_prev


def vizinhos_lista(idx):
    pos = {tuple(p): k for k, p in enumerate(idx)}
    viz = []
    for (a, b) in idx:
        L = [pos[(a, b)]]
        for (d1, d2) in rd.VIZ:
            j = pos.get((a + d1, b + d2))
            if j is not None:
                L.append(j)
        viz.append(L)
    return viz


def localidade(K, xy, R, viz):
    r = np.hypot(xy[:, 0], xy[:, 1])
    fr = []
    for i in np.where(r <= 0.6 * R)[0]:
        tot = np.sum(K[i] ** 2)
        perto = np.sum(K[i, viz[i]] ** 2)
        fr.append(perto / tot)
    return float(np.mean(fr)), float(np.min(fr))


def perfil_diag(N, xy, R):
    r = np.hypot(xy[:, 0], xy[:, 1])
    sel = r <= 0.6 * R
    med = np.diag(N)[sel] * rd.A_C / (2 * np.pi)
    prev = (R * R - r[sel] ** 2) / (2 * R)
    inc = float(np.sum(med * prev) / np.sum(prev * prev))
    corr = float(np.corrcoef(med, prev)[0, 1])
    return inc, corr


def caso(R, m, fontes, desloc=(0.0, 0.15, 0.3), direcoes=(0, 90), qs=(12, 13), sigma_rel=0.3):
    """fontes: dicionário {rótulo: função(idx) -> (X_A, P_A)} (correladores já extrapolados)."""
    idx = rd.disco(R)
    xy = np.array([rd.coords(a, b) for a, b in idx])
    E = rd.arestas_internas(idx)
    viz = vizinhos_lista(idx)
    Rn = R
    R = float(np.sqrt(len(idx) * rd.A_C / np.pi))  # raio efetivo pela área (congelado no protocolo)
    testes = funcoes_teste(xy, R, desloc, direcoes, sigma_rel)
    res = {"R_nominal": Rn, "R_efetivo": R, "m": m, "n_sitios": int(len(idx)), "por_correlador": {}}
    for rot, fonte in fontes.items():
        XA, PA = fonte(idx)
        nu, W, Xh, Xmh = williamson(XA, PA)
        S, S2 = entropias(nu)
        sub = {"nu_min": float(nu.min()), "nu_max": float(nu.max()), "S": S, "S2": S2, "por_q": {}}
        for q in qs:
            M, N, eps = nucleos(nu, W, Xh, Xmh, q)
            cort = int(np.sum(nu - 0.5 < 10.0 ** (-q)))
            linhas = []
            for t in testes:
                g = t["g"]
                Mc, Mm, Np = previsoes(g, xy, E, R, m)
                linhas.append({"s": t["s"], "dir": t["dir"],
                               "rho_M_mel": float(g @ M @ g / Mm), "rho_M_can": float(g @ M @ g / Mc),
                               "rho_N": float(g @ N @ g / Np)})
            locN = localidade(N, xy, R, viz)
            locM = localidade(M, xy, R, viz)
            inc, corr = perfil_diag(N, xy, R)
            sub["por_q"][str(q)] = {"modos_cortados": cort, "eps_max_usado": float(eps.max()), "testes": linhas,
                                    "localidade_N_media_min": locN, "localidade_M_media_min": locM,
                                    "perfil_N_inclinacao": inc, "perfil_N_correlacao": corr}
        res["por_correlador"][rot] = sub
    return res
