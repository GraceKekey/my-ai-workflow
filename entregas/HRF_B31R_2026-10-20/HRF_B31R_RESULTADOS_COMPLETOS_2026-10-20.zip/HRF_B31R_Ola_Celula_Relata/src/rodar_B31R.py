# -*- coding: utf-8 -*-
"""Orquestrador da B31-R (blocos A-R, E, F). Uso:
    python -I src/rodar_B31R.py fumaca              (tamanhos pequenos, fora do conjunto de decisão)
    python -I src/rodar_B31R.py completo [a|e|f1|f2|tudo]
Cada caso concluído é gravado de forma atômica em resultados/B31R_checkpoint.json; relançar retoma sem refazer.
"""
import json
import os
import platform
import sys
import time
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np  # noqa: E402
import scipy  # noqa: E402

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import b31_rede as rd  # noqa: E402
import b31ra as ra  # noqa: E402
import b31e_algebras as ea  # noqa: E402
import b31f_celula as fc  # noqa: E402

CONFIG = {
    "fumaca": {
        "fontes": {"L_principal": 256, "L_controle": 128},
        "B31aR": {"R": [5, 6], "qs": [11, 12, 13]},
        "B31e": {"discos": [2, 3], "MI": {"2": [8, 12, 16, 24]}, "ajuste_ultimos": 3},
        "B31f1": {"R": [0.5, 1, 2], "qs": [12, 13]},
        "B31f2": {"Lt": [256, 512], "xs": [-8, 0, 8], "formas": {"celula": 0.5, "hexagono": 1.0},
                  "k0": [0.8, 0.0], "dk": 0.8 / 6, "x_ini": -22.0, "tempos": list(range(0, 41, 2)),
                  "taus": [1e-10, 1e-12]},
    },
    "completo": {
        "fontes": {"L_principal": 2048, "L_controle": 1024},
        "B31aR": {"R": [8, 12, 16, 20, 24], "qs": [11, 12, 13]},
        "B31e": {"discos": [2, 4, 6, 8, 12], "MI": {"2": [8, 12, 16, 24, 32, 48], "3": [12, 16, 24, 32, 48]},
                 "ajuste_ultimos": 4},
        "B31f1": {"R": [0.5, 1, 2, 3, 4, 6, 8], "qs": [12, 13]},
        "B31f2": {"Lt": [1024, 2048], "xs": list(range(-16, 17, 4)), "formas": {"celula": 0.5, "hexagono": 1.0},
                  "k0": [0.8, 0.0], "dk": 0.8 / 6, "x_ini": -30.0, "tempos": list(range(0, 65)),
                  "taus": [1e-10, 1e-12]},
    },
}


class Caderno:
    def __init__(self, caminho):
        self.caminho = Path(caminho)
        self.dados = json.load(open(self.caminho)) if self.caminho.exists() else {"casos": {}}

    def tem(self, chave):
        return chave in self.dados["casos"]

    def grava(self, chave, valor):
        self.dados["casos"][chave] = valor
        tmp = self.caminho.with_suffix(".tmp")
        with open(tmp, "w") as fh:
            json.dump(self.dados, fh, indent=1)
        os.replace(tmp, self.caminho)
        print(f"[{time.strftime('%H:%M:%S')}] gravado {chave}", flush=True)


_FONTES = {}


def fontes(cfg):
    if not _FONTES:
        for k in ("L_principal", "L_controle"):
            L = cfg["fontes"][k]
            _FONTES[f"L{L}"] = rd.Fonte(L, 0.0)
    return _FONTES


def bloco_a(cfg, cad):
    c = cfg["B31aR"]
    for R in c["R"]:
        ch = f"B31aR|R={R}"
        if cad.tem(ch):
            continue
        t = time.time()
        res = ra.caso_R(R, fontes(cfg), qs=tuple(c["qs"]))
        res["segundos"] = round(time.time() - t, 1)
        cad.grava(ch, res)


def bloco_e(cfg, cad):
    c = cfg["B31e"]
    for R in c["discos"]:
        ch = f"B31e|disco|R={R}"
        if not cad.tem(ch):
            cad.grava(ch, ea.caso_disco(R, fontes(cfg)))
    for Rd, rs in c["MI"].items():
        for r in rs:
            ch = f"B31e|MI|Rd={Rd}|r={r}"
            if not cad.tem(ch):
                cad.grava(ch, ea.caso_MI(int(Rd), r, fontes(cfg)))


def bloco_f1(cfg, cad):
    c = cfg["B31f1"]
    for R in c["R"]:
        ch = f"B31f1|R={R}"
        if cad.tem(ch):
            continue
        cad.grava(ch, fc.estatica(R, fontes(cfg), qs=tuple(c["qs"])))


def bloco_f2(cfg, cad):
    c = cfg["B31f2"]
    for Lt in c["Lt"]:
        ch = f"B31f2|Lt={Lt}"
        if cad.tem(ch):
            continue
        t = time.time()
        res = fc.ola_celular(Lt, c["xs"], c["formas"], tuple(c["k0"]), c["dk"], c["x_ini"],
                             np.array(c["tempos"], dtype=float), tuple(c["taus"]))
        res["segundos"] = round(time.time() - t, 1)
        cad.grava(ch, res)


def main():
    modo = sys.argv[1]
    qual = sys.argv[2] if len(sys.argv) > 2 else "tudo"
    cfg = CONFIG[modo]
    pasta = AQUI.parent / ("fumaca" if modo == "fumaca" else "resultados")
    pasta.mkdir(exist_ok=True)
    meta = {"modo": modo, "config": cfg, "python": platform.python_version(), "numpy": np.__version__,
            "scipy": scipy.__version__, "maquina": platform.platform(), "inicio": time.strftime("%Y-%m-%d %H:%M:%S")}
    with open(pasta / f"B31R_config_{modo}.json", "w") as fh:
        json.dump(meta, fh, indent=1)
    cad = Caderno(pasta / "B31R_checkpoint.json")
    for b, fn in [("a", bloco_a), ("e", bloco_e), ("f1", bloco_f1), ("f2", bloco_f2)]:
        if qual in ("tudo", b):
            fn(cfg, cad)
    print("fim", time.strftime("%H:%M:%S"))


if __name__ == "__main__":
    main()
