# -*- coding: utf-8 -*-
"""HRF B31a-R — o hamiltoniano modular do disco, refeito com o controle certo e discos maiores.

Mudanças em relação à B31a (o resto é o mesmo código congelado de b31a_modular.py):
1. Fonte principal L = 2048 (toros 2048/4096, Richardson); controle L = 1024 (1024/2048). Na B31a o controle era 512,
   pequeno demais para R = 16 (a diferença cresce como (R/L)^3; auditoria de 20/10).
2. Discos R = 8, 12, 16, 20, 24.
3. Localidade suave: o teste de localidade por sítio (fração do peso de N no GMF e nos 6 vizinhos) depende do corte de
   precisão (a parte de curta distância do núcleo é a que se perde). Aqui a localidade que decide é medida por termos
   cruzados entre duas gaussianas separadas (largura 0,2 R_ef, centros em +-0,3 R_ef):
       c = <g1, K g2> / sqrt(<g1, K g1> <g2, K g2>)   (K = N ou M melhorado),
   comparado com o mesmo número calculado com o núcleo CHM (local). Um núcleo não local dá |c_med - c_CHM| grande.
4. A localidade por sítio continua relatada, em q = 11, 12 e 13, para separar artefato do corte de física.
"""
import numpy as np

import b31_rede as rd
import b31a_modular as ma


def bilinear_prev(g1, g2, xy, E, R):
    beta = lambda x, y: (R * R - (x * x + y * y)) / (2 * R)
    i, j = E[:, 0], E[:, 1]
    mx = 0.5 * (xy[i, 0] + xy[j, 0])
    my = 0.5 * (xy[i, 1] + xy[j, 1])
    Mm = 2 * np.pi * np.sum(beta(mx, my) * rd.W_E * (g1[i] - g1[j]) * (g2[i] - g2[j])) + \
        (np.pi / R) * np.sum(rd.A_C * g1 * g2)
    Np = 2 * np.pi * np.sum(beta(xy[:, 0], xy[:, 1]) * g1 * g2 / rd.A_C)
    return Mm, Np


def pares_cruzados(xy, R, direcoes=(0, 90), sig_rel=0.2, sep_rel=0.3):
    r = np.hypot(xy[:, 0], xy[:, 1])
    jan = ma.janela(r, R)
    out = []
    for ang in direcoes:
        u = np.array([np.cos(np.radians(ang)), np.sin(np.radians(ang))])
        s = sig_rel * R
        gs = []
        for sinal in (+1, -1):
            x0 = sinal * sep_rel * R * u
            gs.append(np.exp(-((xy[:, 0] - x0[0]) ** 2 + (xy[:, 1] - x0[1]) ** 2) / (2 * s * s)) * jan)
        out.append({"dir": ang, "g1": gs[0], "g2": gs[1]})
    return out


def caso_R(R, fontes, qs=(11, 12, 13)):
    base = ma.caso(R, 0.0, fontes, qs=qs)  # razões, localidade por sítio, perfil, entropias (código da B31a)
    idx = rd.disco(R)
    xy = np.array([rd.coords(a, b) for a, b in idx])
    E = rd.arestas_internas(idx)
    Ref = base["R_efetivo"]
    pares = pares_cruzados(xy, Ref)
    for rot, fonte in fontes.items():
        XA, PA = fonte(idx)
        nu, W, Xh, Xmh = ma.williamson(XA, PA)
        for q in qs:
            M, N, _ = ma.nucleos(nu, W, Xh, Xmh, q)
            linhas = []
            for p in pares:
                g1, g2 = p["g1"], p["g2"]
                Mm12, Np12 = bilinear_prev(g1, g2, xy, E, Ref)
                Mm11, Np11 = bilinear_prev(g1, g1, xy, E, Ref)
                Mm22, Np22 = bilinear_prev(g2, g2, xy, E, Ref)
                cN = float(g1 @ N @ g2 / np.sqrt((g1 @ N @ g1) * (g2 @ N @ g2)))
                cM = float(g1 @ M @ g2 / np.sqrt((g1 @ M @ g1) * (g2 @ M @ g2)))
                linhas.append({"dir": p["dir"], "c_N": cN, "c_N_CHM": float(Np12 / np.sqrt(Np11 * Np22)),
                               "c_M": cM, "c_M_CHM": float(Mm12 / np.sqrt(Mm11 * Mm22))})
            base["por_correlador"][rot]["por_q"][str(q)]["cruzados"] = linhas
    return base
