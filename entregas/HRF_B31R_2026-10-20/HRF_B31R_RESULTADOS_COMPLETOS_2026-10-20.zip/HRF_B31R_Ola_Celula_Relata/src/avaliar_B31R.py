# -*- coding: utf-8 -*-
"""Avaliador congelado da B31-R. Uso: python -I src/avaliar_B31R.py <pasta com B31R_checkpoint.json e B31R_config_*.json>"""
import json
import math
import sys
from pathlib import Path

import numpy as np

D_B31R = {
    "aR": {"tol_L": 1e-3, "tol_q": 0.01, "nu_min": 0.5 - 1e-9, "tol_chm": 0.05, "faixa": (0.8, 1.2),
           "tol_c": 0.02, "c_nao": 0.10, "q_dec": "13", "q_ctrl": "12"},
    "e": {"tol_L_rel": 0.01, "nu_min": 0.5 - 1e-9, "Z": (-2.4, -1.6), "rel": (-6.8, -5.2), "iguais": 1.0},
    "f1": {"tol_L": 1e-3, "tol_q": 0.01, "nu_min": 0.5 - 1e-9, "tol_chm": 0.05, "q_dec": "13", "q_ctrl": "12"},
    "f2": {"tol_Z": 1e-8, "tol_tau": 1e-6, "tol_E": 1e-8, "tol_Lt_rel": 0.01, "nu_min": 0.5 - 1e-9,
           "h_min": 1e-8, "tol_v": 0.05, "sentado": 0.10, "tol_hel": 1e-10},
}


def rotulos(cfg):
    return f"L{cfg['fontes']['L_principal']}", f"L{cfg['fontes']['L_controle']}"


# ------------------------------------------------------------------------------------------- A-R
def _raz(t):
    return [t["rho_M_mel"], t["rho_N"]]


def _cruz(c):
    return [c["c_N"], c["c_M"]]


def avaliar_aR(casos, cfg):
    d = D_B31R["aR"]
    Lp, Lc = rotulos(cfg)
    valid, falhas, por_R = True, [], {}
    Rs = cfg["B31aR"]["R"]
    for R in Rs:
        k = casos[f"B31aR|R={R}"]
        P, C = k["por_correlador"][Lp], k["por_correlador"][Lc]
        Pq, Pc, Cq = P["por_q"][d["q_dec"]], P["por_q"][d["q_ctrl"]], C["por_q"][d["q_dec"]]
        dL = max([abs(a - b) for x, y in zip(Pq["testes"], Cq["testes"]) for a, b in zip(_raz(x), _raz(y))] +
                 [abs(a - b) for x, y in zip(Pq["cruzados"], Cq["cruzados"]) for a, b in zip(_cruz(x), _cruz(y))])
        dq = max([abs(a - b) for x, y in zip(Pq["testes"], Pc["testes"]) for a, b in zip(_raz(x), _raz(y))] +
                 [abs(a - b) for x, y in zip(Pq["cruzados"], Pc["cruzados"]) for a, b in zip(_cruz(x), _cruz(y))])
        numin = min(P["nu_min"], C["nu_min"])
        if dL > d["tol_L"]:
            valid = False
            falhas.append(f"R={R}: |Δ| entre {Lp} e {Lc} = {dL:.2e}")
        if dq > d["tol_q"]:
            valid = False
            falhas.append(f"R={R}: |Δ| entre q=13 e q=12 = {dq:.2e}")
        if numin < d["nu_min"]:
            valid = False
            falhas.append(f"R={R}: nu_min = {numin}")
        todas = [r for t in Pq["testes"] for r in _raz(t)]
        dc = max(max(abs(c["c_N"] - c["c_N_CHM"]), abs(c["c_M"] - c["c_M_CHM"])) for c in Pq["cruzados"])
        loc = {q: P["por_q"][q]["localidade_N_media_min"][0] for q in P["por_q"]}
        por_R[R] = {"desvio_max": max(abs(r - 1) for r in todas), "razoes_min_max": [min(todas), max(todas)],
                    "desvio_M_canonico": max(abs(t["rho_M_can"] - 1) for t in Pq["testes"]),
                    "dc_max": dc, "localidade_N_por_q": loc,
                    "localidade_sobe_com_q": loc.get("13", 0) - loc.get("11", 0),
                    "dif_L": dL, "dif_q": dq, "R_efetivo": k["R_efetivo"], "S": P["S"], "S2": P["S2"],
                    "modos_cortados_q13": Pq["modos_cortados"]}
    Rmax, Rmin = max(Rs), min(Rs)
    g = por_R[Rmax]
    if not valid:
        dec = "INCONCLUSIVO"
    elif g["razoes_min_max"][0] < d["faixa"][0] or g["razoes_min_max"][1] > d["faixa"][1] or g["dc_max"] > d["c_nao"]:
        dec = "NAO_CHM"
    elif g["desvio_max"] <= d["tol_chm"] and g["desvio_max"] <= por_R[Rmin]["desvio_max"] and g["dc_max"] <= d["tol_c"]:
        dec = "LOCAL_CHM"
    else:
        dec = "LOCAL_DEFORMADO"
    return {"decisao": dec, "validade": valid, "falhas_validade": falhas, "por_R": por_R}


# ------------------------------------------------------------------------------------------- E
def _incl(rs, Is):
    return float(np.polyfit(np.log(np.asarray(rs, float)), np.log(np.asarray(Is, float)), 1)[0])


def avaliar_e(casos, cfg):
    d = D_B31R["e"]
    c = cfg["B31e"]
    Lp, Lc = rotulos(cfg)
    valid, falhas = True, []
    discos = {}
    for R in c["discos"]:
        k = casos[f"B31e|disco|R={R}"]
        if k["dim_centro_numerica"] != k["dim_centro_prevista"]:
            valid = False
            falhas.append(f"disco R={R}: centro {k['dim_centro_numerica']} != {k['dim_centro_prevista']}")
        P = k["por_correlador"][Lp]
        discos[R] = {"n": k["n_sitios"], "S_Z": P["S_Z"], "S_q_mag": P["mag"]["S_q"], "S_q_ele": P["ele"]["S_q"],
                     "h_mag": P["mag"]["h"], "h_ele": P["ele"]["h"], "dim_ele": P["ele"]["dim_centro"]}
    incl, series = {}, {}
    for Rd, rs in c["MI"].items():
        lin = {"Z": [], "mag": [], "ele": []}
        for r in rs:
            k = casos[f"B31e|MI|Rd={Rd}|r={r}"]
            if k["dim_centro_numerica"] != k["dim_centro_prevista"]:
                valid = False
                falhas.append(f"MI Rd={Rd} r={r}: centro")
            P, C = k["por_correlador"][Lp], k["por_correlador"][Lc]
            if P["nu_min"] < d["nu_min"]:
                valid = False
                falhas.append(f"MI Rd={Rd} r={r}: nu_min = {P['nu_min']}")
            for a in ("Z", "mag", "ele"):
                Ip, Ic = P[f"I_{a}"], C[f"I_{a}"]
                if not (Ip > 0):
                    valid = False
                    falhas.append(f"MI Rd={Rd} r={r} {a}: I = {Ip}")
                elif abs(Ip - Ic) / Ip > d["tol_L_rel"]:
                    valid = False
                    falhas.append(f"MI Rd={Rd} r={r} {a}: |ΔI|/I = {abs(Ip - Ic) / Ip:.2e}")
                lin[a].append(Ip)
        n = c["ajuste_ultimos"]
        incl[Rd] = {a: (_incl(rs[-n:], lin[a][-n:]) if all(x > 0 for x in lin[a][-n:]) else float("nan")) for a in lin}
        series[Rd] = {"r": rs, **{f"I_{a}": v for a, v in lin.items()}}
    sep = all(d["Z"][0] <= v["Z"] <= d["Z"][1] and d["rel"][0] <= v["mag"] <= d["rel"][1] and d["rel"][0] <= v["ele"] <= d["rel"][1]
              for v in incl.values())
    igual = any(abs(v["Z"] - v["mag"]) <= d["iguais"] for v in incl.values())
    if not valid:
        dec = "INCONCLUSIVO"
    elif sep:
        dec = "SEPARA"
    elif igual:
        dec = "IGUAIS"
    else:
        dec = "PARCIAL"
    return {"decisao": dec, "validade": valid, "falhas_validade": falhas[:20], "inclinacoes": incl,
            "series_MI": series, "discos": discos}


# ------------------------------------------------------------------------------------------- F1
def avaliar_f1(casos, cfg):
    d = D_B31R["f1"]
    Lp, Lc = rotulos(cfg)
    valid, falhas, por = True, [], {}
    Rs = cfg["B31f1"]["R"]
    for R in Rs:
        k = casos[f"B31f1|R={R}"]
        P, C = k["por_correlador"][Lp], k["por_correlador"][Lc]
        a, b, cq = P["por_q"][d["q_dec"]], C["por_q"][d["q_dec"]], P["por_q"][d["q_ctrl"]]
        dL = max(abs(a["rho_M_mel"] - b["rho_M_mel"]), abs(a["rho_N"] - b["rho_N"]))
        dq = max(abs(a["rho_M_mel"] - cq["rho_M_mel"]), abs(a["rho_N"] - cq["rho_N"]))
        numin = min(P["nu_min_bruto"], C["nu_min_bruto"])
        if dL > d["tol_L"]:
            valid = False
            falhas.append(f"R={R}: |Δρ| L = {dL:.2e}")
        if dq > d["tol_q"]:
            valid = False
            falhas.append(f"R={R}: |Δρ| q = {dq:.2e}")
        if numin < d["nu_min"]:
            valid = False
            falhas.append(f"R={R}: nu_min = {numin}")
        por[R] = {"n": k["n_sitios"], "R_efetivo": k["R_efetivo"], "rho_M_mel": a["rho_M_mel"], "rho_N": a["rho_N"],
                  "desvio": max(abs(a["rho_M_mel"] - 1), abs(a["rho_N"] - 1)), "S": P["S"], "S2": P["S2"],
                  "eps_min": P["eps_menores"][0], "S_q_mag": P["algebras"]["mag"]["S_q"],
                  "S_q_ele": P["algebras"]["ele"]["S_q"], "dif_L": dL, "dif_q": dq}
        if "celula" in a:
            por[R]["celula"] = a["celula"]
    Rord = sorted(Rs)
    Rstar = None
    for i, R in enumerate(Rord):
        if all(por[x]["desvio"] <= d["tol_chm"] for x in Rord[i:]):
            Rstar = R
            break
    if not valid:
        dec = "INCONCLUSIVO"
    elif por[Rord[0]]["desvio"] <= d["tol_chm"] and Rstar == Rord[0]:
        dec = "CELULA_JA_CHM"
    elif por[Rord[-1]]["desvio"] <= d["tol_chm"]:
        dec = "EMERGE"
    else:
        dec = "NAO_EMERGE"
    return {"decisao": dec, "validade": valid, "falhas_validade": falhas, "R_estrela": Rstar, "por_R": por}


# ------------------------------------------------------------------------------------------- F2
def _pico(ts, ys):
    ts, ys = np.asarray(ts, float), np.asarray(ys, float)
    i = int(np.argmax(ys))
    if 0 < i < len(ys) - 1:
        y0, y1, y2 = ys[i - 1], ys[i], ys[i + 1]
        den = y0 - 2 * y1 + y2
        dd = 0.5 * (y0 - y2) / den if den != 0 else 0.0
        return float(ts[i] + dd * (ts[1] - ts[0])), float(y1 - 0.25 * (y0 - y2) * dd)
    return float(ts[i]), float(ys[i])


def _ola(s, xs, tau, chave="dS2_circ_mais"):
    tp, hs, antes, depois, razao_qp = [], [], [], [], []
    for x in xs:
        ser = s[str(x)]
        ts = [l["t"] for l in ser]
        y = [l[tau][chave] for l in ser]
        t0, h = _pico(ts, y)
        tp.append(t0)
        hs.append(h)
        antes.append(y[0] / h if h > 0 else float("inf"))
        depois.append(y[-1] / h if h > 0 else float("inf"))
        i = int(np.argmax(y))
        razao_qp.append(y[i] / ser[i]["dS2_quasiparticula"] if ser[i]["dS2_quasiparticula"] > 0 else float("nan"))
    v = 1.0 / float(np.polyfit(xs, tp, 1)[0])
    return {"t_pico": tp, "altura": hs, "antes_sobre_pico": antes, "depois_sobre_pico": depois,
            "altura_sobre_quasiparticula": razao_qp, "v_ajuste": v}


def avaliar_f2(casos, cfg):
    d = D_B31R["f2"]
    c = cfg["B31f2"]
    taus = [f"tau={t:g}" for t in c["taus"]]
    s1, s2 = casos[f"B31f2|Lt={c['Lt'][0]}"], casos[f"B31f2|Lt={c['Lt'][1]}"]
    valid, falhas = True, []
    for s in (s1, s2):
        for nome, f in s["formas"].items():
            if f["nu_min_bruto"] < d["nu_min"]:
                valid = False
                falhas.append(f"Lt={s['Lt']} {nome}: nu_min = {f['nu_min_bruto']}")
        for g in s["globais"]:
            if abs(g["E_total"] / g["E_esperada"] - 1) > d["tol_E"]:
                valid = False
                falhas.append(f"Lt={s['Lt']} t={g['t']}: energia")
        for nome, porx in s["series"].items():
            for x, ser in porx.items():
                for l in ser:
                    for tau in taus:
                        for zk in ("Z_linear", "Z_circ_mais", "Z_circ_menos"):
                            if abs(l[tau][zk] - 1) > d["tol_Z"]:
                                valid = False
                                falhas.append(f"Lt={s['Lt']} {nome} x={x} t={l['t']}: {zk}")
                    dt = abs(l[taus[0]]["dS2_circ_mais"] - l[taus[1]]["dS2_circ_mais"])
                    if dt > d["tol_tau"]:
                        valid = False
                        falhas.append(f"Lt={s['Lt']} {nome} x={x} t={l['t']}: |Δtau| = {dt:.2e}")
    dLt = {}
    for nome in s1["series"]:
        dif = max(abs(a[taus[0]]["dS2_circ_mais"] - b[taus[0]]["dS2_circ_mais"])
                  for x in s1["series"][nome] for a, b in zip(s1["series"][nome][x], s2["series"][nome][x]))
        pmin = min(max(l[taus[0]]["dS2_circ_mais"] for l in ser) for ser in s1["series"][nome].values())
        dLt[nome] = {"dif_abs": dif, "menor_pico": pmin, "dif_rel": dif / pmin if pmin > 0 else float("inf")}
        if dLt[nome]["dif_rel"] > d["tol_Lt_rel"]:
            valid = False
            falhas.append(f"{nome}: |Δ Lt| / menor pico = {dLt[nome]['dif_rel']:.2e}")
    xs = c["xs"]
    vg = s1["v_g"]
    res = {}
    for nome in s1["series"]:
        o = _ola(s1["series"][nome], xs, taus[0])
        o["v_sobre_vg"] = o["v_ajuste"] / vg
        o["hel_max"] = max(abs(l[taus[0]]["dS2_circ_mais"] - l[taus[0]]["dS2_circ_menos"])
                           for x in xs for l in s1["series"][nome][str(x)])
        o["circ_menos_linear_max"] = max(abs(l[taus[0]]["dS2_circ_mais"] - l[taus[0]]["dS2_linear"])
                                         for x in xs for l in s1["series"][nome][str(x)])
        res[nome] = o
    cel = res["celula"]
    O1 = abs(cel["v_sobre_vg"] - 1) <= d["tol_v"]
    O2 = all(a <= d["sentado"] for a in cel["antes_sobre_pico"]) and all(b <= d["sentado"] for b in cel["depois_sobre_pico"])
    Oh = cel["hel_max"] <= d["tol_hel"]
    if not valid:
        dec = "INCONCLUSIVO"
    elif min(cel["altura"]) < d["h_min"]:
        dec = "SEM_OLA"
    elif O1 and O2 and Oh:
        dec = "OLA_CELULAR"
    else:
        dec = "OLA_DEFORMADA"
    return {"decisao": dec, "validade": valid, "falhas_validade": falhas[:20], "dif_Lt": dLt, "v_g": vg,
            "O1_velocidade": O1, "O2_levanta_e_senta": O2, "helicidade": Oh, "por_forma": res}


def global_(aR, f2):
    if "INCONCLUSIVO" in (aR["decisao"], f2["decisao"]):
        return "INCONCLUSIVA"
    if aR["decisao"] == "NAO_CHM" or f2["decisao"] == "SEM_OLA":
        return "NAO_APOIADA"
    if aR["decisao"] == "LOCAL_CHM" and f2["decisao"] == "OLA_CELULAR":
        return "APOIADA"
    return "PARCIAL"


def main():
    pasta = Path(sys.argv[1])
    casos = json.load(open(pasta / "B31R_checkpoint.json"))["casos"]
    cfgf = sorted(pasta.glob("B31R_config_*.json"))[-1]
    meta = json.load(open(cfgf))
    cfg = meta["config"]
    aR, e, f1, f2 = avaliar_aR(casos, cfg), avaliar_e(casos, cfg), avaliar_f1(casos, cfg), avaliar_f2(casos, cfg)
    out = {"modo": meta["modo"], "B31aR": aR, "B31e": e, "B31f1": f1, "B31f2": f2,
           "global_H_par": global_(aR, f2), "relatum_B31e": e["decisao"], "regras": D_B31R}
    with open(pasta / "avaliacao_B31R.json", "w") as fh:
        json.dump(out, fh, indent=1, default=str)
    print(json.dumps({"B31aR": aR["decisao"], "B31e": e["decisao"], "B31f1": f1["decisao"], "B31f2": f2["decisao"],
                      "global_H_par": out["global_H_par"]}, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
