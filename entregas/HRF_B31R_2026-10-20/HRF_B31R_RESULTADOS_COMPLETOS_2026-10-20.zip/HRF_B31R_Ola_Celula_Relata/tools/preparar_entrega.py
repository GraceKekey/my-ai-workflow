"""Pós-processamento da entrega; não altera fontes ou decisões congeladas."""
from pathlib import Path
import json,csv,hashlib,datetime,zipfile,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent.parent
load=lambda name:json.loads((R/name).read_text())
meta=load('resultados/B31R_config_completo.json');cfg=meta['config'];data=load('resultados/B31R_checkpoint.json')['casos'];ev=load('resultados/avaliacao_B31R.json')
expected={f'B31aR|R={r}' for r in cfg['B31aR']['R']}|{f'B31e|disco|R={r}' for r in cfg['B31e']['discos']}|{f'B31e|MI|Rd={rd}|r={r}' for rd,rs in cfg['B31e']['MI'].items() for r in rs}|{f'B31f1|R={r}' for r in cfg['B31f1']['R']}|{f'B31f2|Lt={lt}' for lt in cfg['B31f2']['Lt']}
checks={'modo_completo':meta['modo']=='completo','chaves_previstas_exatas':set(data)==expected}
for lt in cfg['B31f2']['Lt']:
 s=data[f'B31f2|Lt={lt}'];checks[f'formas_Lt_{lt}']=set(s['series'])==set(cfg['B31f2']['formas'])
 checks[f'globais_Lt_{lt}']=[l['t'] for l in s['globais']]==cfg['B31f2']['tempos']
 for form,porx in s['series'].items():
  checks[f'celulas_{lt}_{form}']=set(porx)=={str(x) for x in cfg['B31f2']['xs']}
  for x,ser in porx.items():
   checks[f'tempos_{lt}_{form}_{x}']=[l['t'] for l in ser]==cfg['B31f2']['tempos']
   checks[f'taus_{lt}_{form}_{x}']=all(all(f'tau={t:g}' in l for t in cfg['B31f2']['taus']) for l in ser)
for line in (R/'hashes_antes_da_execucao.txt').read_text().splitlines():
 if not line or line.startswith('#'):continue
 h,f=line.split(maxsplit=1);checks['hash:'+f]=hashlib.sha256((R/f).read_bytes()).hexdigest()==h
assert all(checks.values()),checks
(R/'VERIFICACAO_COBERTURA.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False))
(R/'tabelas').mkdir(exist_ok=True);(R/'figuras').mkdir(exist_ok=True)
def table(name,rows):
 keys=list(dict.fromkeys(k for row in rows for k in row))
 with (R/'tabelas'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
rows=[];cross=[]
for k,c in data.items():
 if k.startswith('B31aR|'):
  for cor,p in c['por_correlador'].items():
   for q,v in p['por_q'].items():
    for t in v['testes']:rows.append({'caso':k,'correlador':cor,'q':q,**t,'S':p['S'],'S2':p['S2'],'nu_min':p['nu_min'],'localidade_N_media':v['localidade_N_media_min'][0]})
    for t in v['cruzados']:cross.append({'caso':k,'correlador':cor,'q':q,**t})
table('B31aR_testes.csv',rows);table('B31aR_termos_cruzados.csv',cross)
rows=[]
for k,c in data.items():
 if k.startswith('B31e|MI|'):
  for cor,p in c['por_correlador'].items():rows.append({'caso':k,'correlador':cor,**p})
table('B31e_informacao_mutua.csv',rows)
rows=[]
for k,c in data.items():
 if k.startswith('B31e|disco|'):
  for cor,p in c['por_correlador'].items():
   rows.append({'caso':k,'correlador':cor,'n':c['n_sitios'],'S_Z':p['S_Z'],**{f'{alg}_{key}':p[alg][key] for alg in ('mag','ele') for key in ('S_q','h','dim_centro')}})
table('B31e_discos.csv',rows)
rows=[]
for k,c in data.items():
 if k.startswith('B31f1|'):
  for cor,p in c['por_correlador'].items():
   for q,v in p['por_q'].items():rows.append({'caso':k,'correlador':cor,'q':q,'n':c['n_sitios'],'S':p['S'],'S2':p['S2'],'nu_min_bruto':p['nu_min_bruto'],'rho_M_mel':v['rho_M_mel'],'rho_N':v['rho_N'],'S_q_mag':p['algebras']['mag']['S_q'],'S_q_ele':p['algebras']['ele']['S_q']})
table('B31f1_regioes.csv',rows)
rows=[]
for lt in cfg['B31f2']['Lt']:
 s=data[f'B31f2|Lt={lt}']
 for form,porx in s['series'].items():
  for x,ser in porx.items():
   for l in ser:
    base={k:v for k,v in l.items() if not isinstance(v,dict)}
    for tau,values in l.items():
     if isinstance(values,dict):rows.append({'Lt':lt,'forma':form,'x':x,'tau':tau,**base,**values})
table('B31f2_series_completas.csv',rows)
rows=[]
for form,c in ev['B31f2']['por_forma'].items():
 for i,x in enumerate(cfg['B31f2']['xs']):rows.append({'forma':form,'x':x,**{k:c[k][i] for k in ('t_pico','altura','antes_sobre_pico','depois_sobre_pico','altura_sobre_quasiparticula')},'v_ajuste':c['v_ajuste'],'v_sobre_vg':c['v_sobre_vg']})
table('B31f2_picos.csv',rows)
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.2})
fig,ax=plt.subplots(2,2,figsize=(12,8))
a=ev['B31aR']['por_R'];rs=[float(k) for k in a]
ax[0,0].semilogy(rs,[v['desvio_max'] for v in a.values()],'o-',label='Desvio CHM');ax[0,0].semilogy(rs,[v['dc_max'] for v in a.values()],'s--',label='Termos cruzados');ax[0,0].axhline(.05,ls=':',color='gray');ax[0,0].set(title='A-R · Modular e localidade suave',xlabel='Raio R',ylabel='Desvio');ax[0,0].legend(fontsize=8)
colors={'Z':'#2878bf','mag':'#ef7531','ele':'#299c73'}
for rd,s in ev['B31e']['series_MI'].items():
 for alg in ('Z','mag','ele'):ax[0,1].loglog(s['r'],s[f'I_{alg}'],marker='o',ls='-' if rd=='2' else '--',color=colors[alg],label=f'{alg}, R_d={rd}')
ax[0,1].set(title='E · Informação mútua',xlabel='Separação r',ylabel='I');ax[0,1].legend(fontsize=8)
f=ev['B31f1']['por_R'];rs=[float(k) for k in f]
ax[1,0].plot(rs,[v['desvio'] for v in f.values()],'o-');ax[1,0].axhline(.05,ls=':',color='gray',label='Limite 5%');ax[1,0].set(title='F1 · Da célula ao disco',xlabel='Raio R',ylabel='Máximo |ρ − 1|');ax[1,0].legend(fontsize=8)
xs=cfg['B31f2']['xs']
for form,s in ev['B31f2']['por_forma'].items():ax[1,1].plot(xs,s['t_pico'],'o-',label=f"{form}, v/v_g={s['v_sobre_vg']:.4f}")
ax[1,1].set(title='F2 · Propagação dos picos',xlabel='Posição x',ylabel='Tempo do pico');ax[1,1].legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'figuras/B31R_resumo.png',dpi=160);plt.close(fig)
fig,axs=plt.subplots(2,1,figsize=(10,7),sharex=True);s=data[f"B31f2|Lt={cfg['B31f2']['Lt'][0]}"];tau=f"tau={cfg['B31f2']['taus'][0]:g}"
for ax,form in zip(axs,cfg['B31f2']['formas']):
 grid=np.array([[l[tau]['dS2_circ_mais'] for l in s['series'][form][str(x)]] for x in xs]);im=ax.imshow(grid,origin='lower',aspect='auto',extent=(-.5,64.5,xs[0]-2,xs[-1]+2),cmap='viridis');ax.grid(False);ax.set(title=f'F2 · {form}, circular +, Lt=1024',ylabel='Posição x');fig.colorbar(im,ax=ax,label='ΔS₂')
axs[-1].set_xlabel('Tempo t');fig.tight_layout();fig.savefig(R/'figuras/B31R_ola_celular.png',dpi=160);plt.close(fig)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
lines=['# HRF B31-R — relatório completo','',f'Concluído em {now}.','',f"**H-par no modelo livre: {ev['global_H_par']}.**",'','| Bloco | Decisão congelada |','|---|---|']+[f"| {b} | {ev[b]['decisao']} |" for b in ('B31aR','B31e','B31f1','B31f2')]
lines+=['','## Objetivo','','Refazer o modular com o controle de tamanho prescrito, comparar emaranhamento das álgebras de células e relações e testar o limite de uma célula e a propagação celular da ola.','','## Hipóteses','','A-R: forma CHM e localidade suave. E: informação mútua com inclinações aproximadamente −2 para células e −6 para relações. F1: emergência da forma contínua ao aumentar a região. F2: os picos celulares propagam com a velocidade de grupo e retornam a valores pequenos antes e depois da passagem.','','## Parâmetros','','```json',json.dumps(cfg,ensure_ascii=False,indent=2),'```','','## Protocolo','','A pasta foi extraída do ZIP recebido e os dez hashes foram aprovados por sha256sum -c, com a saída preservada em verificacao_hashes.txt. Executados rodar_B31R.py completo e avaliar_B31R.py resultados com Python isolado (-I). OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=1 e MKL_NUM_THREADS=1. Todos os arquivos de src/ e o protocolo permaneceram intactos. O teste sintético do avaliador passou e alcançou todos os ramos; a fumaça não integra a decisão científica.','','Ambiente da execução:','','```json',json.dumps({k:v for k,v in meta.items() if k!='config'},ensure_ascii=False,indent=2),'```','','## Medidas e resultados','','### A-R — modular','','| R | Desvio máximo | dc máximo | ΔL | Δq |','|---|---:|---:|---:|---:|']
for r,v in a.items():lines.append(f"| {r} | {v['desvio_max']:.10g} | {v['dc_max']:.10g} | {v['dif_L']:.10g} | {v['dif_q']:.10g} |")
lines+=['','### E — células e relações','','| R_d | Inclinação células | Magnético | Elétrico |','|---|---:|---:|---:|']
for rd,v in ev['B31e']['inclinacoes'].items():lines.append(f"| {rd} | {v['Z']:.9g} | {v['mag']:.9g} | {v['ele']:.9g} |")
lines+=['','### F1 — regiões pequenas','',f"R* relatado pelo avaliador: {ev['B31f1']['R_estrela']}.",'','| R | Células | ρ_M | ρ_N | Desvio | S_q mag |','|---|---:|---:|---:|---:|---:|']
for r,v in f.items():lines.append(f"| {r} | {v['n']} | {v['rho_M_mel']:.9g} | {v['rho_N']:.9g} | {v['desvio']:.9g} | {v['S_q_mag']:.9g} |")
lines+=['','### F2 — ola celular','','| Forma | v ajustada | v/v_g | Diferença helicidades |','|---|---:|---:|---:|']
for form,v in ev['B31f2']['por_forma'].items():lines.append(f"| {form} | {v['v_ajuste']:.9g} | {v['v_sobre_vg']:.9g} | {v['hel_max']:.9g} |")
lines+=['','## Controles','','Cobertura exata de 30 casos: A-R=5, E=16 (5 discos e 11 pares), F1=7, F2=2. Conferidos os 65 instantes, nove posições, duas formas e dois cortes em cada toro de F2. Os dez hashes congelados continuam iguais após a rodada. Verificação detalhada em VERIFICACAO_COBERTURA.json. Todos os dados completos estão no checkpoint e nas tabelas.','','Avaliação congelada integral:','','```json',json.dumps(ev,ensure_ascii=False,indent=2),'```','','## Interpretação','']
for b in ('B31aR','B31e','B31f1','B31f2'):
 fail=ev[b].get('falhas_validade',[])
 if fail:lines.append(f"{b}: falhas de validade registradas: {'; '.join(fail)}. Uma classificação inconclusiva é uma limitação de validade, não uma refutação física.")
lines+=[f"A classificação global {ev['global_H_par']} segue exclusivamente A-R e F2 conforme o protocolo. As decisões E ({ev['B31e']['decisao']}) e F1 ({ev['B31f1']['decisao']}) são relatadas separadamente e não alteram a decisão global.",'','Os limites foram mantidos sem ajustes após os resultados. R* e inclinações devem ser interpretados junto aos testes de validade. A localidade por sítio de A-R é relatada para os três q e não participa da decisão desta revisão.','','## Limites e reprodução','','Modelo livre não compacto, sem vórtices ou gap de Polyakov; não constitui uma fronteira holográfica completa. As polarizações circulares usam duas cópias do campo fora do plano. Entropias de centro são diferenciais e dependem da unidade; a informação mútua e a parte quântica são as comparações relevantes. F2 mede Rényi-2, e p_E é fração local de energia, não fração de partícula numa célula. Precisão dupla e os cortes do protocolo foram preservados.','','Consulte LEIAME_B31R.md para os comandos originais. requirements_execucao.txt registra as versões utilizadas. Para reproduzir sem reutilizar resultados, execute numa cópia com src/ e protocolo e sem resultados/. O ZIP original está em entrada/. fumaca/ contém somente a execução preliminar recebida. Os dados atuais, logs, tabelas e figuras estão incluídos; não é necessário acessar o repositório para ler ou reproduzir o pacote.']
(R/'RELATORIO_CIENTIFICO_B31R.md').write_text('\n'.join(lines)+'\n')
(R/'LEIA_PRIMEIRO_RESULTADOS.md').write_text('# B31-R — entrega completa\n\nLeia RELATORIO_CIENTIFICO_B31R.md e resultados/avaliacao_B31R.json. Inclui a pasta inteira após a execução, o ZIP original e o log da conferência de hashes. fumaca/ não participa da decisão completa.\n')
(R/'requirements_execucao.txt').write_text(f"numpy=={meta['numpy']}\nscipy=={meta['scipy']}\nmatplotlib=={matplotlib.__version__}\n")
(R/'PROVENIENCIA_CONCLUSAO.json').write_text(json.dumps({'utc':now,'python':meta['python'],'numpy':meta['numpy'],'scipy':meta['scipy'],'matplotlib':matplotlib.__version__,'resultado':ev['global_H_par'],'cobertura_completa':True,'fontes_congeladas_inalteradas':True},ensure_ascii=False,indent=2))
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256_ENTREGA.json']
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(R/'MANIFEST_SHA256_ENTREGA.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
archive=R.parent.parent/'HRF_B31R_RESULTADOS_COMPLETOS_2026-10-20.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[R/'MANIFEST_SHA256_ENTREGA.json']):z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(f'{R.name}/{name}')).hexdigest()==h
shutil.copy2(R/'RELATORIO_CIENTIFICO_B31R.md',R.parent.parent/'HRF_B31R_RELATORIO_2026-10-20.md')
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'resultado':ev['global_H_par'],'arquivos':len(files)+1},ensure_ascii=False,indent=2))
