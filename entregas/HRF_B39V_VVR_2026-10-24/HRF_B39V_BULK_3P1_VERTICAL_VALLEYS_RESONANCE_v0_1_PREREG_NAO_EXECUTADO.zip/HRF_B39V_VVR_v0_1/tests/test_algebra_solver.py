"""Matrix/derivative identities of the real reused solver. No RK4 step is executed."""
import unittest,json,tempfile,contextlib,io
from pathlib import Path
from unittest.mock import patch
import numpy as np
from hrf_integral.mesh_adaptive import RectilinearMesh
from hrf_integral.geometry import ADM
from hrf_vertical.system import VerticalSystem,forcing
from hrf_vertical.geometry import GaussianHeight,ArchivedHeight,metric_audit
from hrf_vertical.observer import EnergyObserver
from hrf_vertical.energy import power_terms,balance,hemisphere_powers
from hrf_vertical.spectral import transfer,foh_matrix,spectrum,threshold_arrivals,oscillator_band
from hrf_vertical.common import ROOT,save_json,save_npz,sha
from hrf_vertical.config import load,plan,frozen_checks
from hrf_vertical.storage import ChunkStore,finalize,verify_completion
from hrf_vertical.controls import observed_order,standing_solution,certify

class SolverMatrixIdentities(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.mesh=RectilinearMesh([np.linspace(-1,1,4)]*3)
        cls.system=VerticalSystem(cls.mesh,ADM(),.7,points=[[0.,0.,0.],[.5,0.,0.]],reciprocal_mask=[True,False],boundary='neumann')
    def test_zero_is_exact_rhs_fixed_point(self):
        s=self.system;y=np.zeros(2*s.mesh.n+2*s.h);self.assertTrue(np.array_equal(s.rhs(0.,y),y))
    def test_hamiltonian_adjoint_reciprocal_and_passive(self):
        s=self.system;y=np.random.default_rng(77).normal(size=2*s.mesh.n+2*s.h)*.01;force=lambda t:np.full(s.mesh.n,.003)
        rhs=s.rhs(0.,y,force);eps=1e-5;derivative=(s.energy(y+eps*rhs)-s.energy(y-eps*rhs))/(2*eps)
        power=power_terms(s,y,0.,force);self.assertAlmostEqual(derivative,power[0]-power[1]-power[2],delta=1e-9)
    def test_passive_receiver_not_in_global_H(self):
        s=self.system;y=np.zeros(2*s.mesh.n+2*s.h);y[-1]=10.;self.assertEqual(s.energy(y),0.)
    def test_conservative_energy_projection(self):
        s=self.system;y=np.random.default_rng(8).normal(size=2*s.mesh.n+2*s.h)*.01;y[2*s.mesh.n:]=0
        obs=EnergyObserver(s).evaluate(y);self.assertAlmostEqual(obs['total_Eulerian_energy'],s.energy(y),delta=1e-11)
        self.assertGreater(obs['old_kinetic_quadrature_deficit'],0.)
    def test_sponge_loss_nonnegative(self):
        s=VerticalSystem(self.mesh,ADM(),.7,boundary='sponge',sponge=.5,sponge_width=[.5,.5,.5]);y=np.ones(2*self.mesh.n)
        self.assertGreaterEqual(power_terms(s,y,0.,None)[1],0.)
    def test_gradient_partition_of_unity(self):self.assertLess(abs(self.mesh.grad.sum(axis=1)).max(),1e-13)
    def test_mass_quadrature_is_domain_volume(self):self.assertAlmostEqual(self.system.mm.sum(),8.)
    def test_trilinear_receivers_preserve_linear_fields(self):
        points=np.array([[.2,.1,-.4],[-.8,.2,.1]]);C=self.mesh.interpolation(points);self.assertTrue(np.allclose(C@(self.mesh.xyz@np.array([2.,3.,-1.])),points@np.array([2.,3.,-1.])))
    def test_geometry_lorentzian_and_parity_covariant(self):
        metric=ADM('graph',height_map=GaussianHeight([[0.,2.,12.,8.]]),thickness=15.);r=metric_audit(metric,[[1.,2.,4.],[-1.,3.,-8.]])
        self.assertTrue(r['lorentzian']);self.assertLess(r['parity_covariance_error'],1e-12)
    def test_archived_height_interpolates_archived_nodes(self):
        h=ArchivedHeight('G_V1a12_s+1');indices=np.arange(1000,len(h.h),30000);self.assertTrue(np.allclose(h(h.P[indices])[0],h.h[indices],atol=1e-10))
    def test_regional_power_sums_are_global_power(self):
        s=self.system;y=np.random.default_rng(3).normal(size=2*s.mesh.n+2*s.h);force=lambda t:np.ones(s.mesh.n)*.03
        global_power=power_terms(s,y,0.,force);regional=hemisphere_powers(s,y,0.,force)
        self.assertTrue(np.allclose(regional.reshape(3,2).sum(axis=1),global_power))
    def test_same_continuum_source_in_different_metrics(self):
        c=load(ROOT/'config/vertical_symmetric.json')['cases'][0];metric=ADM('graph',height_map=GaussianHeight([[0.,0.,1.,2.]]))
        curved=VerticalSystem(self.mesh,metric,.7,boundary='neumann');_,a=forcing(self.system,c);_,b=forcing(curved,c)
        self.assertTrue(np.allclose(a/self.system.mm[:,None],b/curved.mm[:,None]))

class OscillatorAlgebra(unittest.TestCase):
    def test_resonance_transfer(self):self.assertAlmostEqual(abs(transfer(1.85,1.85,.1,.05)),.05/(.1*1.85))
    def test_static_transfer(self):self.assertAlmostEqual(transfer(0.,.13,.1,.05).real,-.05/.13**2)
    def test_no_coupling_no_response(self):self.assertEqual(abs(transfer(.13,1.85,.1,0.)),0.)
    def test_transfer_phase(self):self.assertAlmostEqual(np.angle(transfer(1.,1.,.1,.05)),np.pi/2)
    def test_constant_force_matrix_identity(self):
        t=.2;om=1.85;gam=.1;g=.05;wd=np.sqrt(om*om-gam*gam/4);expected=-g/om**2*(1-np.exp(-gam*t/2)*(np.cos(wd*t)+gam/(2*wd)*np.sin(wd*t)))
        actual=foh_matrix(t,om,gam,g)@np.array([0.,0.,1.,0.]);self.assertAlmostEqual(actual[0],expected,delta=1e-14)
    def test_measured_spectrum_not_nominal_frequency_only(self):
        t=np.arange(1024)*.1;signal=np.sin(.13*t)+.5*np.sin(1.85*t);r=spectrum(t,signal[:,None]);self.assertGreater(r['bandwidth95'][0],1.)
    def test_zero_spectrum_is_undefined_peak(self):self.assertTrue(np.isnan(spectrum(np.arange(32.),np.zeros((32,1)))['peak_omega'][0]))
    def test_aliasing_nonuniform_samples_rejected(self):
        with self.assertRaises(ValueError):spectrum(np.arange(32.)**1.1,np.zeros((32,1)))
    def test_arrival_interpolated_not_causal_front(self):self.assertAlmostEqual(threshold_arrivals([0,1,2],[[0.],[1.],[2.]],.1)[0],.2)
    def test_null_arrival_undefined(self):self.assertTrue(np.isnan(threshold_arrivals([0,1],[[0.],[0.]])[0]))
    def test_overdamping_is_not_called_a_resonant_peak(self):self.assertEqual(oscillator_band(.1,.2)['status'],'NO_NONZERO_RESONANT_PEAK')
    def test_exact_weak_damping_band_is_near_gamma(self):self.assertAlmostEqual(oscillator_band(1.85,.1)['half_power_width'],.1,delta=.001)

class AdmissionAndStorage(unittest.TestCase):
    def test_plan_allocates_no_solver(self):
        c=load(ROOT/'config/vertical_symmetric.json')
        with tempfile.TemporaryDirectory() as td,patch('hrf_vertical.runner.run_case',side_effect=AssertionError('PDE called')):
            r=plan(c,td,actual_limits=False);self.assertFalse(r['new_scientific_simulations_executed']);self.assertEqual(len(r['cases']),3)
    def test_memory_admission_fails(self):
        c=load(ROOT/'config/vertical_symmetric.json');c['limits']['memory_bytes']=1
        with tempfile.TemporaryDirectory() as td:self.assertEqual(plan(c,td,actual_limits=False)['status'],'BLOCKED_RESOURCES')
    def test_disk_admission_fails(self):
        c=load(ROOT/'config/vertical_symmetric.json');c['limits']['disk_bytes']=1
        with tempfile.TemporaryDirectory() as td:self.assertEqual(plan(c,td,actual_limits=False)['status'],'BLOCKED_RESOURCES')
    def test_cpu_admission_fails(self):
        c=load(ROOT/'config/vertical_symmetric.json');c['limits']['max_matvec_operations']=1
        with tempfile.TemporaryDirectory() as td:self.assertEqual(plan(c,td,actual_limits=False)['status'],'BLOCKED_RESOURCES')
    def test_chunk_corruption_detected(self):
        with tempfile.TemporaryDirectory() as td:
            s=ChunkStore(td,'SYNTHETIC_TEST');s.write(0,0.,sample=dict(X=np.zeros(2)));name=s.catalog['records'][0]['sample'];(Path(td)/name).write_bytes(b'corrupt')
            with self.assertRaises(ValueError):ChunkStore(td,'SYNTHETIC_TEST')
    def test_chunk_replay_idempotent(self):
        with tempfile.TemporaryDirectory() as td:
            s=ChunkStore(td,'SYNTHETIC_TEST');s.write(0,0.,sample=dict(X=np.zeros(2)));s.write(1,1.,sample=dict(X=np.ones(2)));s.rollback(0);s.write(0,0.,sample=dict(X=np.zeros(2)));self.assertEqual(len(s.catalog['records']),1)
    def test_final_metadata_both_completed(self):
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);ChunkStore(root/'chunks','SYNTHETIC_TEST');save_npz(root/'observations.npz',synthetic=np.zeros(2));save_npz(root/'grid.npz',synthetic=np.zeros(2));finalize(root,dict(run_id='SYNTHETIC_TEST',test_only=True))
            self.assertTrue(verify_completion(root));self.assertEqual(json.loads((root/'run.json').read_text())['status'],'COMPLETED')
    def test_null_energy_balance_exact(self):self.assertEqual(balance(0.,0.,[0.,0.,0.])['balance_relative_error'],0.)
    def test_wrong_work_fails_balance(self):self.assertGreater(balance(1.,0.,[0.,0.,0.])['balance_relative_error'],.5)
    def test_hashless_control_cannot_pass(self):
        g=json.loads((ROOT/'config/gates.json').read_text());self.assertFalse(any(certify({'PASS_ENERGY_BALANCE':{'measurements':{'relative_error':0.}}},g).values()))
    def test_order_is_a_difference_ratio_not_fake_execution(self):self.assertAlmostEqual(observed_order(.04,.01),2.)
    def test_reference_analytical_mode_boundary_zero(self):
        q,w=standing_solution([np.linspace(-1,1,5)]*3,0.,.2);self.assertAlmostEqual(q[2,2,2],1.);self.assertLess(abs(q[0]).max(),1e-14)
    def test_run_requires_explicit_admission_before_allocation(self):
        from hrf_vertical.runner import run_case
        c=load(ROOT/'config/vertical_symmetric.json')['cases'][0]
        with tempfile.TemporaryDirectory() as td,patch('hrf_vertical.runner.RectilinearMesh',side_effect=AssertionError('mesh allocated')):
            with self.assertRaises(PermissionError):run_case(c,td)
    def test_plan_execute_flag_does_not_launch_solver(self):
        from hrf_vertical.cli import main
        with tempfile.TemporaryDirectory() as td,patch('hrf_vertical.runner.run_case',side_effect=AssertionError('PDE called')),contextlib.redirect_stdout(io.StringIO()):
            self.assertEqual(main(['plan','--execute','--config',str(ROOT/'config/vertical_symmetric.json'),'--output',td]),0)
    def test_changed_config_argument_is_detected(self):
        c=load(ROOT/'config/vertical_symmetric.json');c['cases'][0]['source']['amplitude']*=2
        self.assertIn('config_argument_differs_from_frozen_preset',frozen_checks(c)['changed'])
    def test_scientific_replay_missing_documents_cannot_run(self):
        from hrf_vertical.cli import main
        c=load(ROOT/'config/receivers_frequency_sweep.json')
        with tempfile.TemporaryDirectory() as td:
            result=plan(c,td,actual_limits=False);result['status']='PLANNED_NOT_EXECUTED';result['frozen_checks']={'missing':[],'changed':[]};result['dependencies']={'missing':['MANDATORY_CURRENT_DOCUMENT']}
            with patch('hrf_vertical.cli.plan',return_value=result),patch('hrf_vertical.analysis.receiver_sweep',side_effect=AssertionError('scientific replay launched')),contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(main(['run','--execute','--config',str(ROOT/'config/receivers_frequency_sweep.json'),'--output',td]),3)
