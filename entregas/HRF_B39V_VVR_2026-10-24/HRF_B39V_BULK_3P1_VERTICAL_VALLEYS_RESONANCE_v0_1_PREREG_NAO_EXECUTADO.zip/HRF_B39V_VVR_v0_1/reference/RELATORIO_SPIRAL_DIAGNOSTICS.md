# Relatório de implementação — SPIRAL diagnostics

[D] Estado: pré-registro para execução externa, sem grandes rodadas científicas. Os resultados de verificações permitidas ficam nos relatórios técnicos, separados deste protocolo. A pergunta é se existe ou não estrutura helicoidal ascendente detectável e em quais regimes.

## Objetivo e hipóteses

[H] Explorar a possível distinção entre uma fonte girante, fase com m≠0, torção em z, cristas e fluxo de energia. Não inserir subida na fonte nem interpretar visualizações como prova. [M] Paridade em z oferece controle nulo de preferência ascendente nos presets simétricos.

## Parâmetros e código

[D] Sete presets em config/spiral*.json, com massa, omega/F0, duração/mode, sigmas, malha/domínio, sondas, contorno, observação e limites de recurso explícitos. Cinco nomes obrigatórios estão presentes e há dois presets adicionais para proximidade histórica e controles. Regras de fase/classificação foram congeladas em PROTOCOLO_SPIRAL.md e nos JSONs.

[M] O código completo inclui o núcleo integral preservado e a camada nova descrita em MAPA_DE_MODULOS.md. A integração guarda frames volumétricos e cortes em vez de tentar reconstruir a onda completa a partir das casas. Grades graduadas e escalas/limites de visualização são identificados.

## Medidas e saídas

[M] Energia/fluxo Eulerianos, Lz operacional, fase de lock-in, harmônicos m, winding, centro por altura e global, crista ambígua/única, classificação geométrica, chegadas por limiar e curvas dos receptores. Figuras A–F e diagrama adicional de energia/raio×tempo são rotinas executáveis. Fase indefinida é exibida em cinza. A comparação s± usa mesma escala e verifica tempo/malha.

## Verificação e limitações

[D] Testes unitários cobrem controles positivos/negativos, aliasing, falta de fase, simetria de transporte, lobos equivalentes, máscaras de sondas, malha graduada, energia e exportação. O smoke permitido limita-se a13³ e t=.6. Nenhum resultado desse smoke valida uma hélice. Exemplos e relatório técnico preservam eventuais falhas/correções.

[?] Grandes presets não executados; a estrutura física é INCONCLUSIVE_SPIRAL_STRUCTURE. A aproximação histórica não está certificada. A parte holográfica permanece BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY. Não foram implementadas materialização DIO/GMFt ou evolução gravitacional.
