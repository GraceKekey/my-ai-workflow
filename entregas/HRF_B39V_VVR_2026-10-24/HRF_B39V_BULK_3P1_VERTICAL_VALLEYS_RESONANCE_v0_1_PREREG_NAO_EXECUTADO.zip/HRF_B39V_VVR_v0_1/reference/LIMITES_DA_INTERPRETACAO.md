# Limites da interpretação

[M] Rotação local de fase, enrolamento angular, momento orbital, crista geométrica e transporte de energia são grandezas distintas. Um m≠0 não demonstra subida, uma hélice de fase não demonstra uma trajetória material, e fluxo para fora em ±z não demonstra preferência por +z. Para os presets pares em z espera-se simetria axial de transporte entre os hemisférios, salvo assimetrias ou artefatos que devem ser investigados.

[D] A fase é uma medida estreita em banda com janela Hann e fonte conhecida. Bordas, nodos e amplitude insuficiente são mascarados. A fase média de um anel vorticial pode ser indefinida; não confundir com coeficiente harmônico. Ajustes de kz não atravessam lacunas válidas nem resolvem ambiguidades de2π. A guarda de Nyquist da fonte é necessária; o estado gravado também registra a guarda pelo limite de frequência do sistema discreto. Conteúdo não resolvido não recebe PASS físico.

[M] A crista de um dipolo real pode ter dois lobos antipodais equivalentes. O algoritmo preserva essa ambiguidade, em vez de desenhar uma hélice escolhendo arbitrariamente um lobo. Corrente/energia derivam de gradientes FEM e projeções, cuja precisão depende da malha. A energia da rede estacionária e suas interferências não entram nos volumes de perturbação; readout e campo são saídas separadas.

[D] Novos receptores são sondas passivas por padrão e não mudam a PDE. Suas energias mecânicas não compõem um Hamiltoniano fechado. Se o usuário escolher modo recíproco, os receptores extras passam a ser matéria acoplada do modelo e podem alterar propagação, sombra e momento orbital. Duplicatas de posição são catalogadas como detectores independentes.

[M] Isosuperfícies e nuvens sofrem apenas redução visual documentada, com escala compartilhada entre casos. Diagnósticos usam os dados originais. H(x,y,z) é escalar de embedding auxiliar da métrica candidata; cor em z=0 não significa que z=H seja uma superfície física 3D. O refinamento local é uma grade retangular graduada, sem AMR dinâmico ou malha não estruturada adaptativa.

[?] Standard e high_info são novas escalas exploratórias para resolver melhor fonte/comprimento de onda em um domínio com468 posições. Não são réplica de B39V. O preset historical_closest conserva os parâmetros principais e a regra de relé, mas a malha permanece coarse; não há PASS de transferência. Nenhum limiar foi recalibrado.

[?] Os grandes presets não foram executados nesta entrega. As figuras de smoke verificam geração de arquivos; uma janela de.6 não mede a estrutura de uma onda de vários ciclos. Memória e disco são projeções conservadoras, não garantias de duração; o método ainda exige máquina externa para rodadas maiores e controle de reflexão/refinamento.

[?] Não existem nesta derivação dicionário físico HRF→CFT, recuperação DIO→GMFt, HRT/QES temporal validada, dinâmica gravitacional ou setores Maxwell/Dirac. Campo escalar e osciladores não demonstram fóton, partícula ou helicidade intrínseca. A parte holográfica mantém BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY, independentemente das imagens.
