# Protocolo pré-registrado — SPIRAL-01

## Objetivo e hipóteses

[D] Construir observação completa de phi(x,y,z,t), energia/corrente, fase angular, máximos locais e receptores. [H] Uma fonte dipolar girante pode gerar componente angular m≠0; não se pressupõe helicidade fundamental, hélice geométrica ou transporte ascendente. [M] Para geometria, fonte, contornos e receptores pares em z, a hipótese nula é simetria +z/−z; momento angular orbital pode coexistir com ausência de transporte líquido ascendente. O padrão cos(m theta+kz z−omega t) descreve fase, não uma linha material.

## Fontes e preservação

[D] Cap0_1 v0.1 e Cap03 v0.2, protocolo/mapa/gates integrais e código histórico/atual foram consultados. Cópias estão em documentacao/, reference/ e historico/. O núcleo geometry.py, fem.py e dynamics.py foi reaproveitado sem modificar a entrega anterior. A malha graduada, o sistema misto de sondas e o integrador com frames são módulos derivados novos. Todos os hashes são registrados.

[M] 468 posições históricas exatas em z=0; novos anéis em z=±5/±10/±20 e anéis verticais xz/yz. Históricos têm acoplamento recíproco; extras são passivos por padrão: leem o campo e têm oscilador forçado sem realimentar a PDE. A energia Hamiltoniana do sistema fechado exclui as sondas passivas; sua leitura é aproximação de medida, não criação de energia material. O modo extra recíproco é opcional e explicitamente muda o modelo. Receptores fora do domínio pequeno de smoke permanecem catalogados e inativos, sem clamping ou exclusão silenciosa.

## Dinâmica e fonte

[M] FEM P1 tetraédrico, massa concentrada e RK4 do núcleo integral. p é momento canônico integrado. Na nova integração, dt é uma subdivisão comum de amostra/frame, respeitando o limite conservador do sistema. Isso evita o último frame irregular que invalidaria a análise temporal. Checkpoint e frames são atômicos; configuração e SHA-256 do código identificam a rodada. Campos completos são gravados por frame, não apenas nas casas.

[D] Fonte F=F0·env(t)[P_x cos(omega t)+s P_y sin(omega t)], com gaussianas xy e z. Não há fase axial imposta, modulação azimutal artificial dependente de z ou movimento ascendente introduzido. Pulsos sin², trem de pulsos não sobrepostos e quase-harmônico com rampas sin². A convenção global de sinal de P pode diferir por uma fase π da fonte histórica, sem alterar s ou m. A frequência histórica da rede é1 e a razão de força500; rede estacionária apenas no preset mais próximo do histórico. Limiares históricos por caso são carregados de tabela congelada, nunca ajustados aos resultados novos.

## Energia, fluxo e momento orbital

[M] pi_n=(p/M)/N é a derivada normal aproximada ao nó, beta=0 nos presets novos. Nos tetraedros: e=1/2[pi_n²+gamma^ij ∂i phi ∂j phi+m²phi²]; S^i=−pi_n gamma^ij∂j phi. Projeção nodal conservativa por volumes físicos V=sqrt(gamma)·V_coord. e é energia Euleriana local da perturbação, não a energia total da rede estacionária. Fluxos por z são integrais de superfície aproximadas obtidas da projeção/slab; devem ser refinados para interpretação quantitativa.

[M/D] l_z=−pi_n(x∂y phi−y∂x phi), integrado com volume físico, é diagnóstico orbital operacional. Não é helicidade intrínseca do escalar. Só há interpretação de carga Noether conservada sob simetria axial e condições de fechamento adequadas; fonte, detectores e sponge fornecem torque/dissipação. Saídas guardam Lz, centros de energia, fluxos líquidos e fluxos para fora separadamente. Radiação simétrica nos dois sentidos pode ter fluxo para fora positivo e fluxo líquido em z nulo.

## Fase angular e torção

[D] A fase local é de lock-in finito: Psi=janela Hann normalizada * [2 phi exp(+i omega t)]. Para cos(m theta+kz z−omega t), arg Psi=m theta+kz z. Janela padrão de dois ciclos, número ímpar de frames; descartar meia janela em cada borda. Sem janela suficiente, fase fica indefinida. Não calcular arg de um campo real e chamá-lo de fase complexa. Pulsos têm fase de banda estreita condicionada à janela, não uma fase única universal.

[M] c_m=<Psi exp(−im theta)>_theta; potência |c_m|² normalizada pela potência total do anel, inclusive conteúdo fora do conjunto de m registrado. Fase média por anel é média circular, indefinida se resultante<.05. Enrolamento exige amplitudes acima do piso em todo o anel. Pisos: relativo1e−6 e absoluto1e−14. Modo primário prévio m=s; ajuste de torção exige fração de potência primária≥.6.

[D] Ajustar fase de c_s contra z em maior trecho conectado válido, globalmente e nos hemisférios z>0 e z<0. Exigir quatro alturas conectadas; rejeitar incrementos de fase >.8π como possível aliasing. Candidato linear de torção exige variação≥.5rad e RMS relativo≤.25. dtheta_crista/dz=−kz/m e passo z por2π=−2πm/kz são quantidades de crista de fase. Seu sinal não prova direção do fluxo de energia.

## Cristas e controles negativos

[D] Máximos locais de |phi| em cada xy são guardados, até oito candidatos. Se mais de um lobo está a≤.1% do máximo, não inventar uma crista única por desempate. A linha principal permanece indefinida nessa fatia. Centros de energia são calculados independentemente, podendo ficar no eixo mesmo com lóbulos rotativos.

[M] Com quatro ou mais z válidos: linha axial abaixo de dois passos xy não resolve torção; linha afim com erro≤passo xy e ângulo<π/4 é LINE_LIKE. Candidato geométrico helicoidal exige variação angular≥π, CV do raio≤.25 e erro relativo da hélice≤.2. Candidato fraco exige variação≥π/2 com os mesmos limites. Outros padrões ficam radiais candidatos ou indefinidos. São classificações geométricas descritivas, não certificação de transporte.

## Gates e execução desta entrega

- [D] PASS_SPIRAL_VISUALIZATION_PIPELINE: arquivos previstos A/B/D/E/F, nuvem, cortes e animação gerados e válidos; C exige par s± com mesma configuração, malha, escala/paleta e tempo. Não depende de existir uma hélice.
- [D] PASS_ZSCAN_DIAGNOSTICS: ao menos três alturas com energia acima do piso e pelo menos três frames permitem calcular a chegada fracionária de10%. Chegada é de limiar, não frente causal; fonte gaussiana tem caudas.
- [D] PASS_HELICITY_DIAGNOSTIC: decomposição/fase definida em algum anel válido com≥16 frames e janela temporal completa. Um resultado nulo pode ser informativo; o gate não afirma helicidade física.
- [D] FAIL_NO_RESOLVED_INFORMATION: fonte sem≥3 células por sigma local, comprimento de onda sem≥12 passos globais, banda de frames insuficiente, janela temporal insuficiente ou sinal abaixo do piso. O smoke técnico não certifica informação resolvida.
- [D] BLOCKED_RESOURCE_LIMIT: pico estimado, análise por slab ou saída por caso/sweep excedem os limites configurados. Planejamento não aloca malha.
- [D] INCONCLUSIVE_SPIRAL_STRUCTURE: veredito estrutural nesta versão até controles físicos de convergência e fronteira. Candidatos descritivos não promovem esse gate automaticamente.

[D] Antes da fotografia final: verificações estáticas, testes unitários algébricos com campos fabricados e um smoke técnico de13³ nós, dois sentidos s, t_final=.6, 24 passos de.025 por sentido e cinco frames por caso. Uma interrupção/retomada do mesmo caso valida checkpoints. Não executar standard, high_info, zscan, helicity_compare ou controls nesta entrega. Figuras de exemplo somente desse smoke, rotuladas. Não gerar figuras dos campos sintéticos unitários.
