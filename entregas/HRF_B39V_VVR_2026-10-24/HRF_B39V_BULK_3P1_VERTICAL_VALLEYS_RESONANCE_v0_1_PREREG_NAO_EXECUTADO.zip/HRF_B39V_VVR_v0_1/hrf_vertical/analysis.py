"""Read-only old-data audit and streaming analysis. Never calls a PDE solver."""
from pathlib import Path
import json,csv
import numpy as np
from hrf_integral.phase_analysis import demodulate,azimuthal,axial_phase_fit,longest_contiguous
from hrf_integral.helicity_metrics import chirality
from hrf_integral.spiral_source import envelope
from hrf_integral.history import load as historical
from .common import ROOT,save_json,save_npz,sha,relative,clean
from .dataset import Dataset
from .storage import audit_old_metadata
from .transport import vertical_observables,flux_history,parity_error,orientation_nematic,ring_currents
from .spectral import diagnose,passive_replay

def masked_axial_fit(z,coeff,gates):
    # The inherited helper's np.max is NaN-sensitive. Zero marks invalid input
    # only for its amplitude test; no phase/height is filled or interpolated.
    c=np.where(np.isfinite(coeff),coeff,0j);z=np.asarray(z)
    fit=axial_phase_fit(z,c,gates['phase_min_z'],gates['phase_fit_residual_max'],gates['phase_span_min'])
    amp=abs(c);idx=longest_contiguous(np.flatnonzero(amp>max(np.max(amp,initial=0)*1e-6,1e-14)))
    fit['slope_SE_descriptive']=None
    if fit.get('kz') is not None and len(idx)>2:
        X=np.c_[z[idx],np.ones(len(idx))];w=amp[idx]**2;phase=np.unwrap(np.angle(c[idx]));coef=np.linalg.lstsq(X*np.sqrt(w)[:,None],phase*np.sqrt(w),rcond=None)[0]
        variance=np.sum(w*(phase-X@coef)**2)/(len(idx)-2);cov=np.linalg.pinv(X.T@(w[:,None]*X))*variance;fit['slope_SE_descriptive']=float(np.sqrt(max(cov[0,0],0.)))
    fit['uncertainty_notice']='fit-residual standard error only; correlated samples require grid/window/boundary controls, not a statistical confidence claim'
    return fit

def phase_diagnostic(t,rings,z,theta,omega,rotation,gates):
    m=np.arange(-4,5);primary=rotation if rotation else 1;mi=list(m).index(primary)
    z=np.asarray(z);arrays={};fits=[];phase_masks=[];mean_chirality=[];fit_candidates=[]
    for cycle in gates['phase_window_cycles']:
        psi,valid,meta=demodulate(rings,t,omega,cycle);angular=azimuthal(psi,theta,m,gates['phase_relative_floor'],gates['phase_absolute_floor'])
        coeff=angular['coefficients'];power=angular['power_fraction'];usable=valid[:,None,None]&(np.max(angular['amplitude'],axis=-1)>angular['amplitude_floor'])
        cprimary=np.where(usable&(power[...,mi]>=gates['primary_mode_purity_min']),coeff[...,mi],np.nan+1j*np.nan)
        candidates=set()
        for it in np.flatnonzero(valid):
            for ir in range(rings.shape[2]):
                for side,mask in [('all',np.ones(len(z),bool)),('plus',z>0),('minus',z<0)]:
                    fit=masked_axial_fit(z[mask],cprimary[it,mask,ir],gates)
                    fits.append(dict(cycles=cycle,time_index=int(it),t=float(t[it]),radius_index=ir,side=side,m=int(primary),**fit))
                    if fit['status']=='PHASE_TWIST_CANDIDATE':candidates.add((int(it),int(ir),side))
        arrays['cycles_'+str(cycle)]=dict(meta=meta,valid=valid,mode_real=coeff.real,mode_imag=coeff.imag,power_fraction=power,
                                      phase=np.where(valid[:,None,None,None],angular['phase'],np.nan),usable=usable,
                                      chirality_operational=np.where(usable,chirality(power,m),np.nan))
        fit_candidates.append(candidates);phase_masks.append(usable);mean_chirality.append(float(np.nanmean(np.where(usable,chirality(power,m),np.nan))) if usable.any() else None)
    common=set.intersection(*fit_candidates) if fit_candidates else set();robust=[]
    lookup={(f['cycles'],f['time_index'],f['radius_index'],f['side']):f for f in fits}
    for key in sorted(common):
        members=[lookup[(cycle,*key)] for cycle in gates['phase_window_cycles']]
        kz=np.array([f['kz'] for f in members]);change=np.ptp(kz)/max(np.max(abs(kz)),1e-30)
        if change<=gates['phase_window_kz_sensitivity_max']:robust.append(dict(time_index=key[0],radius_index=key[1],side=key[2],kz=float(kz.mean()),relative_window_sensitivity=float(change)))
    primary_arrays=arrays['cycles_2.0'];status='PASS_PHASE_DIAGNOSTIC' if len(t)>=gates['phase_min_frames'] and np.any(primary_arrays['usable']) else 'INCONCLUSIVE'
    return dict(status=status,m_values=m,primary_m=primary,arrays=arrays,exploratory_candidates=fits,robust_candidates=robust,
                phase_candidate_status='HELICAL_PHASE_CANDIDATE' if robust else 'NO_ACCEPTED_PHASE_TWIST',mean_chirality_by_window=mean_chirality)

def flatten_arrays(prefix,obj,result):
    for key,value in obj.items():
        name=prefix+str(key)
        if isinstance(value,np.ndarray):result[name]=value
        elif isinstance(value,dict):flatten_arrays(name+'__',value,result)

def audit_receivers(ds,gates):
    obs=ds.observations();c=ds.config;r=c['receivers'];t=obs['ts'];indices=obs.get('active_catalog_indices',np.arange(obs['X'].shape[1]));hist=indices<468
    thresholds=ds.meta.get('thresholds')
    if thresholds is None:
        table=json.loads((ROOT/'inputs/historical_thresholds.json').read_text());key=r['historical_threshold_case'];key=key.replace('_s+1','_s-1') if c['rotation']==-1 else key;thresholds=table[key]
    source=np.c_[[envelope(float(tt),c['source'])*np.cos(c['source']['omega']*float(tt)) for tt in t],
                           [envelope(float(tt),c['source'])*c['rotation']*np.sin(c['source']['omega']*float(tt)) for tt in t]]*c['source']['amplitude']
    diag=diagnose(t,obs['field'],obs['X'],obs['P'],r['omega'],r['gamma'],r['coupling'],thresholds['theta_lock'],source)
    # Reproduce the actual historical channel including stationary-network initialization.
    rl=historical('b39_rele');network=obs.get('network');scale=float(obs.get('network_scale',0.))
    readout=rl.leitura(t,obs['X'],obs['P'],np.full(obs['X'].shape[1],r['omega']),Xr=network,A=scale,Om_r=1.)
    channel_error=relative(readout,obs['readout']);lock=rl.rele(t,readout,thresholds['theta_lock'],'trava')
    report=dict(status='PASS_RECEIVER_SPECTRAL_DIAGNOSTIC' if channel_error<=gates['receiver_reproduction_relative_max'] and np.max(diag['incident_spectrum']['nyquist_edge_power_fraction'],initial=0)<=gates['nyquist_edge_power_fraction_max'] else 'INCONCLUSIVE',
                historical_active=int(hist.sum()),raw_readout_sha256=sha(ds.folder/'observations.npz'),readout_reproduction_relative_error=channel_error,
                historical_readout_max=float(np.max(readout[:,hist],initial=0)),historical_lock_threshold=thresholds['theta_lock'],
                historical_max_threshold_ratio=float(np.max(readout[:,hist],initial=0)/thresholds['theta_lock']),historical_relays_fired=int(np.any(lock[:,hist]>0,axis=0).sum()),
                incident_nonzero_receivers=int(np.sum(diag['received_max'][hist]>gates['phase_absolute_floor'])),coupling_nonzero=bool(r['coupling']!=0),
                responding_oscillators=int(np.sum(diag['response_max'][hist]>gates['phase_absolute_floor'])),
                threshold_crossings=int(np.any(readout[:,hist]>=thresholds['theta_lock'],axis=0).sum()),
                distinction=['incident perturbation','coupling','oscillator response','threshold crossing','historical relay'],
                exact_transfer_band=diag['exact_transfer_band'],
                causal_explanation='detuning may contribute; measured input spectrum and controlled passive replays required; no DIO/GMFt inference')
    diag['actual_network_inclusive_readout']=readout
    return report,diag

def analyze_case(folder,output,gates,with_flowlines=False,controls=None):
    if (Path(folder)/'frames/frames.json').exists() and Path(output).resolve().is_relative_to(Path(folder).resolve()):raise ValueError('historical input is read-only: select a separate analysis output folder')
    from .admission import analysis_admission
    admission=analysis_admission(folder,output,gates,with_flowlines)
    if admission['status']=='BLOCKED_RESOURCES':save_json(Path(output)/'BLOCKED_RESOURCES.json',admission);return admission
    ds=Dataset(folder);out=Path(output);out.mkdir(parents=True,exist_ok=True);times=[];records=[];parity=[];nematic=[]
    # Old outputs use their archived quadrature. New outputs carry the corrected one.
    gamma=ds.metric_grid() if ds.old or with_flowlines else None
    if ds.old:
        for t,d in ds.volumes():
            times.append(t);records.append(vertical_observables(ds.axes,d['energy_density'],d['flux'],ds.grid['node_volume'],gamma=gamma,planes=[p for p in (5.,10.,20.) if p<=min(-ds.axes[2][0],ds.axes[2][-1])]))
            records[-1]['ring_currents']=ring_currents(ds.axes,d['flux'],ds.grid['probe_z'],ds.grid['probe_r'],gamma)
            records[-1]['orbital_Lz']=float(d.get('orbital_Lz_operational',np.nan))
            parity.append(parity_error(d['phi'],d['energy_density'],d['flux'],ds.axes))
            k=np.argmin(abs(ds.axes[2]));nematic.append(orientation_nematic(d['phi'][:,:,k],*ds.axes[:2]))
    else:
        for t,d in ds.cuts():
            times.append(t);records.append(json.loads(str(d['stats_json'])));parity.append(json.loads(str(d['parity_json'])));nematic.append(json.loads(str(d['nematic_json'])))
    if not records:raise ValueError('no diagnostic records')
    rows=[];cut_times=[]
    for t,d in ds.cuts():cut_times.append(t);rows.append(d['ring'])
    phase=phase_diagnostic(np.asarray(cut_times),np.asarray(rows),ds.grid['probe_z'],ds.grid['probe_theta'],ds.config['source']['omega'],ds.config['rotation'],gates)
    receiver,receiver_arrays=audit_receivers(ds,gates);time_array=np.asarray(times);flux=flux_history(records,time_array)
    actual95=receiver_arrays['incident_spectrum']['bandwidth95'];powers=receiver_arrays['incident_spectrum']['variance_integral']
    meaningful=powers>=max(float(np.max(powers,initial=0))*gates['phase_relative_floor']**2,gates['phase_absolute_floor']**2)
    finite95=actual95[np.isfinite(actual95)&meaningful]
    from .resolution import proper_steps
    proper_dx=proper_steps(ds.config,[np.diff(a).max() for a in ds.axes]);dx=max(proper_dx);frequency95=float(np.max(finite95)) if len(finite95) else None
    wavelength95=2*np.pi/np.sqrt(frequency95**2-ds.config['field']['mass']**2) if frequency95 is not None and frequency95>ds.config['field']['mass'] else None
    source=ds.config['source'];source_resolved=source['sigma_xy']>=3*max(np.diff(a).max() for a in ds.axes[:2]) and source['sigma_z']>=3*np.diff(ds.axes[2]).max()
    geometry_resolved=ds.config.get('geometry_min_sigma',np.inf)>=3*max(np.diff(a).max() for a in ds.axes[:2])
    radii=ds.grid['probe_r'];angular_ok=wavelength95 is not None and 2*np.pi/wavelength95*max(radii)<=.8*(len(ds.grid['probe_theta'])/2)
    information_resolved=source_resolved and geometry_resolved and angular_ok and wavelength95 is not None and wavelength95>=gates['wavelength_cells_min']*dx
    raw_phase_fit_status=phase['phase_candidate_status']
    if not information_resolved:phase['phase_candidate_status']='INCONCLUSIVE'
    arrays=dict(times=time_array,E_plus=np.array([r['E_plus'] for r in records]),E_minus=np.array([r['E_minus'] for r in records]),
                asymmetry=np.array([r['up_down_asymmetry'] for r in records]),azimuthal_signed=np.array([r['currents']['azimuthal'] for r in records]),
                azimuthal_absolute=np.array([r['currents']['azimuthal_absolute'] for r in records]),radial_signed=np.array([r['currents']['radial'] for r in records]),
                vertical_signed=np.array([r['currents']['vertical'] for r in records]),centroid_x=np.array([r['centroid_x'] for r in records]),centroid_y=np.array([r['centroid_y'] for r in records]))
    for key in ('circulation','mean_Jtheta','mean_Jz_outward','angular_vertical_alignment'):arrays['rings__'+key]=np.asarray([r['ring_currents'][key] for r in records])
    arrays['orbital_Lz_operational']=np.array([r['orbital_Lz'] for r in records]);arrays['operational_torque_dLdt']=np.gradient(arrays['orbital_Lz_operational'],time_array) if len(time_array)>1 else np.full(1,np.nan)
    flatten_arrays('flux__',flux,arrays);save_npz(out/'vertical.npz',**arrays)
    phase_arrays={};flatten_arrays('',phase['arrays'],phase_arrays);save_npz(out/'phase.npz',t=np.asarray(cut_times),z=ds.grid['probe_z'],theta=ds.grid['probe_theta'],**phase_arrays)
    save_json(out/'phase_candidates.json',dict(status=phase['phase_candidate_status'],exploratory=phase['exploratory_candidates'],window_robust=phase['robust_candidates']))
    rr={};flatten_arrays('',receiver_arrays,rr);save_npz(out/'receiver_spectra.npz',**rr);save_json(out/'receivers.json',receiver)
    save_json(out/'nematic_and_parity.json',dict(parity=parity,nematic=nematic))
    with (out/'vertical.csv').open('w',newline='',encoding='utf-8') as f:
        writer=csv.writer(f);writer.writerow(['t','E_plus','E_minus','asymmetry','Jtheta_signed_volume_integral','Jr_signed_volume_integral'])
        writer.writerows(zip(times,arrays['E_plus'],arrays['E_minus'],arrays['asymmetry'],arrays['azimuthal_signed'],arrays['radial_signed']))
    obs=ds.observations();symmetry=max((max(p.get('phi',0)/gates['vertical_phi_relative_max'],p.get('energy',0)/gates['vertical_energy_relative_max'],p.get('current',0)/gates['vertical_current_relative_max']) for p in parity if p['status']=='MEASURED'),default=np.inf)
    balance_error=float(np.max(obs['balance_relative_error'])) if 'balance_relative_error' in obs else None
    vertical_weight=max((float(v['cumulative_plus_out'][-1]+v['cumulative_minus_out'][-1]) for v in flux.values()),default=0.)
    normE=max(np.max(arrays['E_plus']+arrays['E_minus']),1e-30);vtransport=vertical_weight>gates['vertical_transport_relative_min']*normE
    controls={} if controls is None else dict(controls)
    if not information_resolved:controls['SPATIAL_CONVERGENCE']=False
    structure=dict(status='INCONCLUSIVE',reason='numerical and boundary controls are not yet certified');structures={}
    if with_flowlines:
        from .helical import track_curves,transport_gate
        eligible=[p for p in ds.config.get('planes',[10.,20.]) if p>=gates['seed_plane_sigma_z_min']*ds.config['source']['sigma_z']]
        for sign in (1,-1):
            if not eligible:
                structure=dict(status='INCONCLUSIVE',reason='no plane outside the frozen source-width exclusion zone');break
            source_height=min(eligible)
            # t=0 has zero flux. Select a data-defined seed time at 10% cumulative outward flux.
            curve_times=np.array([r['t'] for r in ds.catalog if ds.old or r.get('volume')]);v=flux[str(float(source_height))];cumulative=v['cumulative_plus_out' if sign==1 else 'cumulative_minus_out']
            if cumulative[-1]<=1e-28:continue
            source_end=ds.config['source']['duration']+(ds.config['source'].get('count',1)-1)*ds.config['source'].get('period',0) if ds.config['source']['mode']=='pulse_train' else ds.config['source']['duration']
            it=int(np.searchsorted(cumulative,.1*cumulative[-1]));seed_time=max(times[it],source_end)
            start=int(np.searchsorted(curve_times,seed_time))
            trace=track_curves(ds.axes,ds.flow_frames,start,sign*source_height,gamma=gamma)
            if trace['status']=='OPERATIONAL_ENERGY_CURRENT_CURVES':save_npz(out/f'flow_curves_{sign:+d}.npz',**{k:v for k,v in trace.items() if isinstance(v,np.ndarray)})
            reflux=float(v['cumulative_plus_return' if sign==1 else 'cumulative_minus_return'][-1]/max(cumulative[-1],1e-30))
            side_result=transport_gate(trace,max(np.diff(a).max() for a in ds.axes),ds.config['source']['omega'],gates,controls,reflux);structures['plus' if sign==1 else 'minus']=side_result;save_json(out/f'flow_gate_{sign:+d}.json',side_result)
        if any(v['status']=='HELICAL_ENERGY_TRANSPORT_CANDIDATE' for v in structures.values()):structure=dict(status='HELICAL_ENERGY_TRANSPORT_CANDIDATE',scope='see separate hemispheres; no inference of net upward transport')
        elif len(structures)==2 and all(v['status']=='NO_RESOLVED_HELICAL_TRANSPORT' for v in structures.values()):structure=dict(status='NO_RESOLVED_HELICAL_TRANSPORT',scope='both hemispheres passed required controls and sampling')
    primary_arrays=phase['arrays']['cycles_2.0'];nonzero_power=primary_arrays['power_fraction'][...,np.asarray(phase['m_values'])!=0].sum(axis=-1)
    angular_structure=bool(np.any((nonzero_power>=.5)&primary_arrays['usable']))
    summary=dict(case_id=ds.meta.get('case_id',ds.folder.name),status='REANALYSIS_ONLY_OLD_VERDICT_PRESERVED' if ds.old else 'NEW_DATA_ANALYZED',
                 source_case_sha256=sha(ds.folder/'case.json'),raw_files_modified=False,diagnostic_records=len(times),receiver=receiver,
                 gates=dict(phase=phase['status'],vertical_symmetry='PASS_VERTICAL_SYMMETRY_CONTROL' if symmetry<=1 else ('FAIL_NUMERICAL' if any(p['status']=='MEASURED' for p in parity) else 'INCONCLUSIVE'),
                            energy='PASS_ENERGY_BALANCE' if balance_error is not None and balance_error<=gates['energy_relative_max'] else 'INCONCLUSIVE',
                            azimuthal='PASS_AZIMUTHAL_FLOW_DIAGNOSTIC' if all(np.isfinite(arrays[k]).all() for k in ('azimuthal_signed','azimuthal_absolute','radial_signed','vertical_signed')) else 'FAIL_NUMERICAL',receiver=receiver['status']),
                 evidence=dict(ANGULAR_PHASE_STRUCTURE=angular_structure,AZIMUTHAL_ENERGY_CIRCULATION=bool(np.any(abs(arrays['azimuthal_signed'])>gates['azimuthal_signed_fraction_min']*np.maximum(arrays['azimuthal_absolute'],1e-30))),
                               VERTICAL_ENERGY_TRANSPORT=bool(vtransport),phase_candidate=phase['phase_candidate_status']),
                 structure=structure,structure_by_hemisphere=structures,raw_phase_fit_status=raw_phase_fit_status,max_balance_relative_error=balance_error,mean_chirality_by_window=phase['mean_chirality_by_window'],previous_archived_verdict=ds.meta.get('scientific_verdict'),
                 information=dict(source_resolved=bool(source_resolved),geometry_resolved=bool(geometry_resolved),received_omega95=frequency95,wavelength95=wavelength95,conservative_proper_axis_step=proper_dx.tolist(),angular_sampling_adequate=bool(angular_ok),spatial_resolution_adequate=bool(information_resolved),notice='measured finite sampled spectrum cannot rule out pre-recording aliasing'),
                 quadrature='archived old mean(pi)^2; no silent replacement' if ds.old else 'new mass-lumped mean(pi^2)',
                 HRF_holography='BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY')
    save_json(out/'summary.json',summary);return summary

def baseline(root,output,gates):
    root=Path(root);out=Path(output);out.mkdir(parents=True,exist_ok=True)
    folders=[root] if (root/'case.json').exists() else sorted(p.parent for p in root.glob('*/case.json'))
    if not folders:
        result=dict(status='BLOCKED_MISSING_HISTORICAL_DATA',missing='actual splus/sminus SPIRAL scientific outputs',new_PDE_integrations=0);save_json(out/'baseline.json',result);return result
    summaries=[];metadata=[]
    for folder in folders:
        if (folder/'run.json').exists():metadata.append(audit_old_metadata(folder))
        summaries.append(analyze_case(folder,out/folder.name,gates))
    result=dict(status='READ_ONLY_BASELINE_AUDIT',cases=summaries,metadata=metadata,new_PDE_integrations=0,old_classifications_changed=False)
    save_json(out/'baseline.json',result);return result

def receiver_sweep(folder,output,parameters,gates):
    from .admission import analysis_admission
    admission=analysis_admission(folder,output,gates)
    if admission['status']=='BLOCKED_RESOURCES':save_json(Path(output)/'BLOCKED_RESOURCES.json',admission);return admission
    ds=Dataset(folder);obs=ds.observations();out=Path(output);out.mkdir(parents=True,exist_ok=True);c=ds.config;table=json.loads((ROOT/'inputs/historical_thresholds.json').read_text());key=c['receivers']['historical_threshold_case'];key=key.replace('_s+1','_s-1') if c['rotation']==-1 else key;threshold=table[key]['theta_lock']
    summaries=[]
    for params in parameters:
        X,P=passive_replay(obs['ts'],obs['field'],params['omega'],params['gamma'],params['coupling'])
        diag=diagnose(obs['ts'],obs['field'],X,P,params['omega'],params['gamma'],params['coupling'],threshold)
        name=params['case_id'];save_npz(out/(name+'.npz'),ts=obs['ts'],X=X,P=P,readout=diag['readout'],threshold_ratio=diag['threshold_ratio'])
        summaries.append(dict(**params,max_threshold_ratio=float(np.max(diag['threshold_ratio'])),counterfactual_shadow_relays=int(diag['relay_fired'].sum()),
                              interpretation='passive replay of fixed incident signal; these are not actual historical reciprocal relay events',threshold_unchanged=threshold))
    result=dict(status='PASSIVE_COUNTERFACTUAL_REPLAY',cases=summaries,PDE_integrations=0,field_self_consistency='not recomputed; reciprocal model is a separate experiment')
    save_json(out/'sweep.json',result);return result
