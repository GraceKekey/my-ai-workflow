"""Figures 1--8 and true volumetric animations, exclusively from supplied data."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from hrf_integral.visualization_3d import isosurface,point_cloud
from hrf_integral.export_animation import export_frames
from .common import save_json,relative
from .dataset import Dataset
from .controls import differences

def finish(fig,path,title):
    fig.suptitle(title+'\n[M] Campo escalar em geometria prescrita; figuras não são trajetórias materiais')
    fig.tight_layout();fig.savefig(path,dpi=120);plt.close(fig)

def overlay(ax,ds):
    g=ds.grid;hist=np.arange(len(g['receiver_xyz']))<468;active=g['receiver_active']
    for mask,color,label in [(hist&active,'black','468 históricos (ativos no domínio)'),(~hist&active,'goldenrod','sondas extras passivas')]:
        p=g['receiver_xyz'][mask]
        if len(p):ax.scatter(*p.T,s=3,color=color,alpha=.45,label=label)
    ax.scatter(*ds.config['source']['center'],s=50,marker='*',color='green',label='fonte')
    x,y,z=ds.axes;X,Y=np.meshgrid(x,y,indexing='ij');H=g['H'][:,:,np.argmin(abs(z))]
    if np.ptp(H)>1e-14:
        color=plt.colormaps['Greys']((H-H.min())/np.ptp(H));color[...,3]=.18
        ax.plot_surface(X,Y,np.zeros_like(X),facecolors=color,rstride=max(1,len(x)//24),cstride=max(1,len(y)//24),shade=False)
    ax.set(xlim=(x[0],x[-1]),ylim=(y[0],y[-1]),zlim=(z[0],z[-1]),xlabel='x',ylabel='y',zlabel='z')
    ax.set_box_aspect([np.ptp(a) for a in ds.axes]);ax.view_init(elev=22,azim=-55)

def draw_volume(ax,ds,phi,vmax):
    meta=[]
    for level,color in ((.3*vmax,'crimson'),(-.3*vmax,'royalblue')):
        tri,m=isosurface(phi,ds.axes,level,max_axis=32,max_triangles=8000);meta.append(m)
        if len(tri):ax.add_collection3d(Poly3DCollection(tri,alpha=.45,facecolor=color,edgecolor='none'))
    overlay(ax,ds);return meta

def pair_statistics(plus,minus,analysis_plus,analysis_minus):
    a=Dataset(plus);b=Dataset(minus);changes=differences(a.config,b.config)
    if set(changes)!={'rotation'}:raise ValueError('rotation pair has additional independent changes: '+str(changes))
    if any(not np.array_equal(x,y) for x,y in zip(a.axes,b.axes)):raise ValueError('rotation pair grids differ')
    numerator=den=0.;matched=0
    for (t,fa),(tb,fb) in zip(a.volumes(),b.volumes()):
        if abs(t-tb)>1e-9:raise ValueError('rotation pair times differ')
        numerator+=float(np.sum((fa['phi']-fb['phi'][:,::-1,:])**2));den+=float(np.sum(fa['phi']**2));matched+=1
    with np.load(Path(analysis_plus)/'phase.npz',allow_pickle=False) as pa,np.load(Path(analysis_minus)/'phase.npz',allow_pickle=False) as pb:
        prefix='cycles_2.0__';valid=pa[prefix+'usable']&pb[prefix+'usable'];ca=pa[prefix+'mode_real']+1j*pa[prefix+'mode_imag'];cb=pb[prefix+'mode_real']+1j*pb[prefix+'mode_imag']
        powers_a=np.sum(abs(ca[valid])**2,axis=0);powers_b=np.sum(abs(cb[valid])**2,axis=0)[::-1]
        chirality_plus=float(np.mean(pa[prefix+'chirality_operational'][valid])) if valid.any() else None
        chirality_minus=float(np.mean(pb[prefix+'chirality_operational'][valid])) if valid.any() else None
    return dict(matched_volume_frames=matched,field_y_reflection_relative_L2=float(np.sqrt(numerator/max(den,1e-30))),
                mean_chirality_plus=chirality_plus,mean_chirality_minus=chirality_minus,
                angular_power_reflection_relative_error=relative(powers_a,powers_b) if valid.any() else None,
                scope='controlled rotation pair; reflection symmetry prediction requires reflection-invariant geometry')

def render_case(folder,analysis,out,vmax,max_frames=16):
    ds=Dataset(folder);out=Path(out);out.mkdir(parents=True,exist_ok=True);analysis=Path(analysis);catalog=[r for r in ds.catalog if ds.old or r.get('volume')]
    if not catalog:raise ValueError('no actual volume frames to render')
    peak=-1.;selected=None
    for t,d in ds.volumes():
        value=float(np.max(abs(d['phi'])))
        if value>peak:peak=value;selected=(t,d['phi'])
    t,phi=selected;shape=phi.shape;x,y,z=ds.axes;extent=[x[0],x[-1],z[0],z[-1]]
    fig=plt.figure(figsize=(13,5));ax=fig.add_subplot(121,projection='3d');meta=draw_volume(ax,ds,phi,vmax);ax.set_title('phi positivo/vermelho e negativo/azul; H como cor em z=0')
    ax=fig.add_subplot(122,projection='3d');tri,m=isosurface(abs(phi),ds.axes,.3*vmax,max_axis=32,max_triangles=8000)
    if len(tri):ax.add_collection3d(Poly3DCollection(tri,alpha=.35,facecolor='teal',edgecolor='none'))
    overlay(ax,ds);ax.set_title('|phi|; mesmos eixos físicos');finish(fig,out/'Figure1_bulk.png',f'Figura 1 — t={t:g}')
    cuts=[r for r in ds.catalog if ds.old or r.get('cuts')];wanted=np.unique(np.linspace(0,len(cuts)-1,min(4,len(cuts))).astype(int));fig,axs=plt.subplots(2,len(wanted),figsize=(4*len(wanted),7),squeeze=False)
    for j,index in enumerate(wanted):
        ti=cuts[index]['t'];d=ds.read_item(cuts[index],'cuts')
        for row,key,a in [(0,'xz',x),(1,'yz',y)]:
            axs[row,j].imshow(d[key].T,origin='lower',extent=[a[0],a[-1],z[0],z[-1]],vmin=-vmax,vmax=vmax,cmap='RdBu_r',aspect='auto');axs[row,j].set(xlabel=key[0],ylabel='z',title=f'{key}; t={ti:g}')
    finish(fig,out/'Figure2_vertical.png','Figura 2 — propagação para +z e −z; cruzamentos de amplitude não são frentes causais')
    with np.load(analysis/'vertical.npz',allow_pickle=False) as d:vertical={k:d[k] for k in d.files}
    tt=vertical['times'];fig,axs=plt.subplots(2,2,figsize=(12,8));axs[0,0].plot(tt,vertical['E_plus'],label='E+');axs[0,0].plot(tt,vertical['E_minus'],label='E−');axs[0,0].legend();axs[0,0].set_ylabel('energia Euleriana')
    for key,v in vertical.items():
        if key.startswith('flux__') and 'cumulative_' in key:axs[0,1].plot(tt,v,label=key.replace('flux__',''))
    axs[0,1].legend(fontsize=6,ncol=2);axs[0,1].set_ylabel('energia atravessando planos')
    obs=ds.observations()
    if 'ledger' in obs:
        for j,name in enumerate(('trabalho da fonte','perda sponge','perda receptores recíprocos')):axs[1,0].plot(obs['ts'],obs['ledger'][:,j],label=name)
        axs[1,1].semilogy(obs['ts'],np.maximum(obs['balance_relative_error'],1e-20));axs[1,1].set_ylabel('erro relativo do balanço Hamiltoniano')
    else:
        axs[1,0].text(.05,.5,'Histórico: ledger de perdas/fonte não gravado.\nNão reconstruir como zero.',transform=axs[1,0].transAxes)
        axs[1,1].text(.05,.5,'Balanço histórico não certificado.',transform=axs[1,1].transAxes)
    for ax in axs.flat:ax.set_xlabel('t')
    if 'ledger' in obs:axs[1,0].legend()
    finish(fig,out/'Figure3_energy_balance.png','Figura 3 — hemisférios, fluxos orientados e balanço')
    with np.load(analysis/'phase.npz',allow_pickle=False) as d:phase={k:d[k] for k in d.files}
    prefix='cycles_2.0__';valid=np.flatnonzero(phase[prefix+'valid']);it=valid[len(valid)//2] if len(valid) else len(phase['t'])//2
    fig,axs=plt.subplots(2,3,figsize=(16,8));axs[0,0].imshow(np.ma.masked_invalid(phase[prefix+'phase'][it,:,0,:]),origin='lower',aspect='auto',extent=[0,2*np.pi,phase['z'][0],phase['z'][-1]],vmin=-np.pi,vmax=np.pi,cmap='twilight');axs[0,0].set(xlabel='theta',ylabel='z',title='fase angular; indefinida se sem janela')
    current_limit=max(float(np.nanmax(abs(vertical['rings__mean_Jtheta']),initial=0)),float(np.nanmax(abs(vertical['rings__mean_Jz_outward']),initial=0)),1e-30)
    for ax,key,title in [(axs[0,1],'rings__mean_Jtheta','corrente azimutal'),(axs[0,2],'rings__mean_Jz_outward','corrente vertical para fora')]:
        ax.imshow(np.nanmean(vertical[key],axis=2).T,origin='lower',aspect='auto',extent=[tt[0],tt[-1],phase['z'][0],phase['z'][-1]],vmin=-current_limit,vmax=current_limit,cmap='RdBu_r');ax.set(xlabel='t',ylabel='z',title=title)
    for key in ('centroid_x','centroid_y'):axs[1,0].plot(z,np.asarray(vertical[key])[len(tt)//2],label=key)
    axs[1,0].set(xlabel='z',ylabel='centroide transversal',ylim=(min(x[0],y[0]),max(x[-1],y[-1])));axs[1,0].legend()
    from hrf_integral.ridge_tracking import local_peaks
    near=min(cuts,key=lambda row:abs(row['t']-phase['t'][it]));cut=ds.read_item(near,'cuts')
    for zz,values in zip(ds.grid['slice_actual_z'],cut['xy']):
        peaks=local_peaks(values,x,y)
        for xx,yy,amplitude in peaks['points']:axs[1,1].scatter(np.arctan2(yy,xx),zz,c='gray' if peaks['ambiguous'] else 'red',s=10)
    axs[1,1].set(xlabel='theta dos máximos',ylabel='z',title='máximos antipodais: empates em cinza')
    axs[1,2].plot(tt,vertical['orbital_Lz_operational'],label='Lz operacional');axs[1,2].plot(tt,vertical['operational_torque_dLdt'],label='dLz/dt operacional');axs[1,2].legend();axs[1,2].set(xlabel='t',title='sem presumir conservação Noether no reticulado')
    finish(fig,out/'Figure4_circulation_phase.png','Figura 4 — fase, circulação e transporte são observáveis distintos')
    curve_files=[p for p in analysis.glob('flow_curves_*.npz')]
    if curve_files:
        fig=plt.figure(figsize=(9,6));ax=fig.add_subplot(projection='3d')
        for p in curve_files:
            with np.load(p,allow_pickle=False) as d:
                xyz=d['xyz'];ids=np.unique(np.linspace(0,xyz.shape[1]-1,min(64,xyz.shape[1])).astype(int))
                for i in ids:ax.plot(*xyz[:,i].T,alpha=.4,lw=.8)
        overlay(ax,ds);finish(fig,out/'Figure4B_energy_current_curves.png','Figura 4B — curvas integrais operacionais de J/e; todas as degenerescências de crista preservadas')
    rr=json.loads((analysis/'receivers.json').read_text());indices=obs.get('active_catalog_indices',np.arange(obs['X'].shape[1]));hist=indices<468
    chosen=np.flatnonzero(hist);chosen=int(chosen[np.argmax(np.max(obs['readout'][:,hist],axis=0))]) if len(chosen) else 0
    with np.load(analysis/'receiver_spectra.npz',allow_pickle=False) as d:spec={k:d[k] for k in d.files}
    fig,axs=plt.subplots(2,2,figsize=(12,8));axs[0,0].plot(obs['ts'],obs['field'][:,chosen]);axs[0,0].set(xlabel='t',ylabel='campo incidente')
    axs[0,1].semilogy(spec['incident_spectrum__omega'],np.maximum(spec['incident_spectrum__PSD_per_angular_frequency'][:,chosen],1e-300));axs[0,1].axvline(ds.config['receivers']['omega'],color='red',label='Omega receptor');axs[0,1].set(xlabel='omega [rad/tempo]',ylabel='PSD incidente');axs[0,1].legend()
    axs[1,0].plot(obs['ts'],obs['X'][:,chosen],label='X');axs[1,0].plot(obs['ts'],obs['P'][:,chosen],label='P');axs[1,0].legend();axs[1,0].set_xlabel('t')
    axs[1,1].plot(obs['ts'],obs['readout'][:,chosen],label='leitura');axs[1,1].axhline(rr['historical_lock_threshold'],color='red',label='limiar histórico congelado');axs[1,1].set(xlabel='t',ylabel='readout');axs[1,1].legend()
    finish(fig,out/'Figure6_receivers.png','Figura 6 — campo, espectro, oscilador e limiar')
    pngs=[];frameout=out/'animation_frames';frameout.mkdir(exist_ok=True);chosen_rows=np.unique(np.linspace(0,len(catalog)-1,min(max_frames,len(catalog))).astype(int))
    for n,index in enumerate(chosen_rows):
        d=ds.read_item(catalog[index],'volume');fig=plt.figure(figsize=(8,6));ax=fig.add_subplot(projection='3d');draw_volume(ax,ds,d['phi'],vmax)
        path=frameout/f'frame_{n:04d}.png';finish(fig,path,f'Bulk volumétrico — t={catalog[index]["t"]:g}; câmera e escala fixas');pngs.append(path)
    animation=export_frames(pngs,out/'bulk_animation',fps=5,gif=True,mp4=True)
    result=dict(status='VISUALIZATION_FROM_REAL_SUPPLIED_FIELDS',common_vmax=vmax,isosurfaces=meta,animation=animation,new_PDE_runs=0,
                missing=['Figure5 needs a matched valley family','Figure7 needs a matched rotation pair','Figure8 needs actual convergence/control comparisons'])
    save_json(out/'visualization.json',result);return result

def matched_comparison(folders,out,vmax,figure_number,requested_time=None):
    sets=[Dataset(p) for p in folders]
    times=[{float(r['t']) for r in ds.catalog if ds.old or r.get('volume')} for ds in sets];common=sorted(set.intersection(*times))
    if not common:raise ValueError('no matched physical times')
    t=common[len(common)//2] if requested_time is None else min(common,key=lambda value:abs(value-requested_time))
    if any(any(not np.array_equal(a,b) for a,b in zip(sets[0].axes,ds.axes)) for ds in sets[1:]):raise ValueError('matched figures require identical grids')
    fig,axs=plt.subplots(1,len(sets),figsize=(5*len(sets),4),squeeze=False)
    for ax,ds in zip(axs.flat,sets):
        row=next(r for r in ds.catalog if abs(r['t']-t)<1e-10);d=ds.read_item(row,'volume');iz=np.argmin(abs(ds.axes[2]));x,y,_=ds.axes
        ax.imshow(d['phi'][:,:,iz].T,origin='lower',extent=[x[0],x[-1],y[0],y[-1]],vmin=-vmax,vmax=vmax,cmap='RdBu_r');ax.set(title=ds.folder.name,xlabel='x',ylabel='y')
    path=Path(out)/f'Figure{figure_number}_matched.png';finish(fig,path,f'Figura {figure_number} — escala comum, t={t:g}');return path

def convergence_figure(comparisons,out):
    rows=json.loads(Path(comparisons).read_text());rows=rows['comparisons'] if isinstance(rows,dict) else rows
    fig,ax=plt.subplots(figsize=(10,5));ax.bar(np.arange(len(rows)),[r['spacetime_field_relative_L2'] for r in rows]);ax.set_xticks(np.arange(len(rows)),[Path(r['second']).name for r in rows],rotation=30,ha='right');ax.set_ylabel('variação relativa L2 do campo');finish(fig,Path(out)/'Figure8_controls.png','Figura 8 — refinamento e fronteiras: medições fornecidas')
