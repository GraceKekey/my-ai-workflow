"""Small, deterministic, strict and portable IO utilities."""
from pathlib import Path
import hashlib, json, os, tempfile
import numpy as np

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def clean(x):
    if isinstance(x, dict): return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [clean(v) for v in x]
    if isinstance(x, np.ndarray): return clean(x.tolist())
    if isinstance(x, np.generic): return clean(x.item())
    if isinstance(x, float) and not np.isfinite(x): return None
    if isinstance(x, Path): return str(x)
    return x

def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name+'.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(clean(obj), f, indent=2, ensure_ascii=False, allow_nan=False)
            f.write('\n'); f.flush(); os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def save_npz(path, **arrays):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name+'.', suffix='.npz', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            np.savez_compressed(f, **arrays); f.flush(); os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def code_hash():
    h = hashlib.sha256()
    files = [p for folder in ('hrf_vertical','hrf_integral','historico/B39V/src','scripts') for p in (ROOT/folder).glob('*.py')]
    for p in sorted(files): h.update(str(p.relative_to(ROOT)).encode()); h.update(p.read_bytes())
    return h.hexdigest()

def fingerprint(obj):
    return hashlib.sha256(json.dumps(clean(obj), sort_keys=True, allow_nan=False).encode()).hexdigest()

def cumulative(t, values):
    t=np.asarray(t); v=np.asarray(values)
    shape=(len(t)-1,)+(1,)*(v.ndim-1)
    return np.concatenate([np.zeros_like(v[:1]), np.cumsum((v[1:]+v[:-1])*.5*np.diff(t).reshape(shape),axis=0)])

def relative(a,b,floor=1e-30):
    return float(np.linalg.norm(np.asarray(a)-np.asarray(b))/max(np.linalg.norm(a),np.linalg.norm(b),floor))
