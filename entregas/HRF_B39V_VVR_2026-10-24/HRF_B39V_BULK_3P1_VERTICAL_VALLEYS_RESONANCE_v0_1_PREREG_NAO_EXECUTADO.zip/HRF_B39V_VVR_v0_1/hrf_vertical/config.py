"""Allocation-free planning, admission and frozen-input verification."""
from pathlib import Path
import json, shutil, os,re
import numpy as np
from fractions import Fraction
from math import gcd,lcm,ceil
from hrf_integral.mesh_adaptive import axes_from_config
from .common import ROOT, sha, code_hash
from .resolution import proper_steps

def load(path):
    c=json.loads(Path(path).read_text(encoding='utf-8'));validate(c);return c

def validate(c):
    for key in ('id','status','classification','cases','limits','code_sha256','input_hashes','dependencies','units','gates_sha256'):
        if key not in c:raise ValueError('missing preset '+key)
    if c['status']!='NOT_EXECUTED':raise ValueError('configuration must retain NOT_EXECUTED; execution state belongs to results')
    if re.fullmatch('[a-z0-9_]+',c['id']) is None:raise ValueError('invalid preset identifier')
    if len({x['case_id'] for x in c['cases']})!=len(c['cases']):raise ValueError('duplicate case id')
    for case in c['cases']:
        if '/' in case['case_id'] or '\\' in case['case_id'] or case['case_id'] in ('.','..'):raise ValueError('invalid case path')
        if case['mode'] in ('baseline_reanalysis','receiver_replay'):continue
        for key in ('case_id','grid','field','source','receivers','initial','observation','geometry','rotation','planes','comparison_group'):
            if key not in case:raise ValueError('missing case '+key)
        axes=axes_from_config(case['grid'])
        if any(len(a)<3 or np.any(np.diff(a)<=0) for a in axes):raise ValueError('invalid axes')
        if case['rotation'] not in (-1,0,1):raise ValueError('invalid rotation')
        if case['initial'] not in ('zero','standing_mode'):raise ValueError('unsupported initial data')
        if case['initial']=='standing_mode' and case['mode']!='numerical_reference':raise ValueError('analytic nonzero initial data are restricted to the reference control')
        s=case['source'];f=case['field'];o=case['observation'];r=case['receivers']
        if s.get('normalization_policy') not in ('continuum_L2','legacy_discrete'):raise ValueError('explicit source normalization required')
        if min(s['omega'],s['duration'],s['sigma_xy'],s['sigma_z'],f['dt'],f['t_end'],o['sample_dt'],o['diagnostic_dt'],o['volume_dt'])<=0:raise ValueError('nonpositive scales')
        if s['amplitude']<0 or f['mass']<0 or min(r['omega'],r['gamma'])<=0 or r['coupling']<0:raise ValueError('invalid field/receiver')
        if f['boundary'] not in ('dirichlet','neumann','sponge'):raise ValueError('invalid BC')
        if o['dtype'] not in ('float32','float64'):raise ValueError('invalid storage dtype')
        for name in ('sample_dt','diagnostic_dt','volume_dt'):
            if not np.isclose(f['t_end']/o[name],round(f['t_end']/o[name])):raise ValueError('observation must divide t_end')
        if o['sample_dt']*max(s['omega'],r['omega'])>=np.pi:raise ValueError('receiver aliasing')
        if o['diagnostic_dt']*s['omega']>=np.pi:raise ValueError('carrier aliasing')
        if any(p<=0 or p>min(-axes[2][0],axes[2][-1]) for p in case['planes']):raise ValueError('invalid symmetric flux planes')
        if any(w<=0 for w in f['sponge_width']):raise ValueError('invalid sponge width')
    return c

def estimate_case(case):
    if case['mode'] in ('baseline_reanalysis','receiver_replay'):
        return dict(case_id=case['case_id'],mode=case['mode'],nodes=0,frames=0,memory_bytes=(4 if case['mode']=='baseline_reanalysis' else 2)*1024**3,disk_bytes=1024**3,
                    matvec_operations=0,status='NO_PDE_REANALYSIS_INPUT_REQUIRED',cpu_seconds=None,analysis_cost='input-dependent streaming FFT/replay; second admission after source metadata inspection')
    axes=axes_from_config(case['grid']);shape=[len(a) for a in axes];n=int(np.prod(shape));t=case['field']['t_end'];o=case['observation']
    frames=int(round(t/o['volume_dt']))+1;diagnostics=int(round(t/o['diagnostic_dt']))+1
    intervals=[Fraction(str(o[k])).limit_denominator(10**6) for k in ('sample_dt','diagnostic_dt','volume_dt')];den=lcm(*[q.denominator for q in intervals]);tick=gcd(*[q.numerator*(den//q.denominator) for q in intervals])/den
    planned_dt=tick/ceil(tick/case['field']['dt']);steps=int(np.ceil(t/planned_dt))
    # No assumed compression ratio. Budget includes coordinates, metric, FEM and sparse assembly.
    memory=n*8500+512*1024**2
    slices=(shape[0]*shape[2]+shape[1]*shape[2]+len(case['phase_z'])*shape[0]*shape[1])
    disk=int(frames*n*2*np.dtype(o['dtype']).itemsize+diagnostics*(slices+len(case['phase_z'])*5*64)*4+diagnostics*1044*6*8+120*n+64*1024**2)
    dx=[float(np.diff(a).max()) for a in axes];s=case['source'];mass=case['field']['mass'];wave=2*np.pi/np.sqrt(s['omega']**2-mass**2) if s['omega']>mass else None
    # Four envelope sidebands are a conservative planning proxy, not a hard spectral cutoff.
    omega_proxy=s['omega']+4*np.pi/s['duration'];wave_proxy=2*np.pi/np.sqrt(omega_proxy**2-mass**2) if omega_proxy>mass else None
    proper_dx=proper_steps(case,dx)
    adequate=s['sigma_xy']>=3*max(dx[:2]) and s['sigma_z']>=3*dx[2] and wave_proxy is not None and wave_proxy>=12*max(proper_dx)
    angular_ok=wave_proxy is not None and 2*np.pi/wave_proxy*max(case['phase_radii'])<=.8*(64/2)
    adequate=adequate and angular_ok
    geometry_min_sigma=case.get('geometry_min_sigma')
    if geometry_min_sigma is not None:adequate=adequate and geometry_min_sigma>=3*max(dx[:2])
    return dict(case_id=case['case_id'],mode=case['mode'],nodes=n,tetrahedra=int(6*np.prod(np.array(shape)-1)),shape=shape,
                frames=frames,diagnostic_records=diagnostics,memory_bytes=int(memory),disk_bytes=disk,matvec_operations=steps*n*240,planned_dt_before_assembled_CFL=planned_dt,
                cpu_seconds=None,cpu_time_status='NO_CALIBRATED_THROUGHPUT; operation count is not wall time',
                max_dx=dx,conservative_proper_axis_step=proper_dx.tolist(),wavelength_carrier=wave,wavelength_envelope_proxy=wave_proxy,angular_sampling_proxy_adequate=bool(angular_ok),planning_resolution_adequate=bool(adequate),
                flowline_sampling_adequate=bool(o['volume_dt']<=.5*min(dx)),
                losses_from_recording='no discarded integration steps; phase uses diagnostic_dt; flowlines limited by volume_dt; broadband beyond measured Nyquist is flagged',status='PLANNED_NOT_EXECUTED')

def frozen_checks(c):
    missing=[];changed=[]
    if c['code_sha256']!=code_hash():changed.append('code_sha256')
    if c['gates_sha256']!=sha(ROOT/'config/gates.json'):changed.append('gates_sha256')
    for name,expected in c['input_hashes'].items():
        p=ROOT/name
        if not p.is_file():missing.append(name)
        elif sha(p)!=expected:changed.append(name)
    canonical=ROOT/'config'/f'{c["id"]}.json'
    if not canonical.is_file():missing.append(str(canonical.relative_to(ROOT)))
    elif c!=json.loads(canonical.read_text(encoding='utf-8')):changed.append('config_argument_differs_from_frozen_preset')
    manifest=ROOT/'hashes_antes_da_execucao.txt'
    if not manifest.is_file():missing.append('hashes_antes_da_execucao.txt')
    else:
        frozen_names=set()
        for line in manifest.read_text(encoding='utf-8').splitlines():
            if not line or line.startswith('#'):continue
            expected,name=line.split('  ',1);path=(ROOT/name).resolve()
            frozen_names.add(name)
            if not path.is_relative_to(ROOT):raise ValueError('unsafe frozen manifest path')
            if not path.is_file():missing.append(name)
            elif sha(path)!=expected:changed.append(name)
        if str(canonical.relative_to(ROOT)) not in frozen_names:missing.append('preset_not_listed_in_frozen_manifest')
    return dict(missing=missing,changed=changed)

def readiness(c):
    # Missing mandatory current documents must not be silently replaced by older versions.
    missing=[d['name'] for d in c['dependencies'] if d.get('required_for_execution') and d.get('status')!='VERIFIED']
    return dict(status='BLOCKED_MISSING_HISTORICAL_DATA' if missing else 'READY_FOR_EXPLICIT_AUTHORIZATION',missing=missing)

def plan(c,output,case_id=None,actual_limits=True):
    selected=[x for x in c['cases'] if case_id is None or x['case_id']==case_id]
    if not selected:raise ValueError('case not found')
    plans=[estimate_case(x) for x in selected];reasons=[];limits=c['limits'];total=sum(p['disk_bytes'] for p in plans)
    for p in plans:
        if p['memory_bytes']>limits['memory_bytes']:reasons.append(p['case_id']+': memory bound exceeded')
        if p['matvec_operations']>limits['max_matvec_operations']:reasons.append(p['case_id']+': CPU operation bound exceeded')
    if total>limits['disk_bytes']:reasons.append('aggregate disk bound exceeded; select --case or preregister a new budget')
    probe=Path(output).resolve()
    while not probe.exists():probe=probe.parent
    free=shutil.disk_usage(probe).free
    if actual_limits and total+limits['reserve_disk_bytes']>free:reasons.append('insufficient actual free disk including reserve')
    available=None
    try:
        mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());available=int(mem['MemAvailable'].strip().split()[0])*1024
        cp=Path('/sys/fs/cgroup/memory.max')
        if cp.exists() and cp.read_text().strip()!='max':available=min(available,int(cp.read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text()))
    except (OSError,ValueError,KeyError):pass
    if actual_limits and available is not None and max(p['memory_bytes'] for p in plans)>available:reasons.append('insufficient actual available memory')
    checks=frozen_checks(c)
    return dict(preset=c['id'],status='BLOCKED_RESOURCES' if reasons else 'PLANNED_NOT_EXECUTED',resource_reasons=reasons,cases=plans,
                aggregate_disk_bytes=total,peak_memory_bytes=max(p['memory_bytes'] for p in plans),actual_free_disk=free,actual_available_memory=available,
                frozen_checks=checks,dependencies=readiness(c),limits=limits,new_scientific_simulations_executed=False)
