"""Reuse P1/RK4 solver. This module has no automatic integration entry point."""
import json,time,sys,platform,os,importlib.metadata
from pathlib import Path
from fractions import Fraction
from math import lcm,gcd,ceil
import numpy as np
from hrf_integral.mesh_adaptive import RectilinearMesh,axes_from_config
from hrf_integral.spiral_receivers import catalog
from hrf_integral.history import load as historical
from .geometry import build_geometry,metric_audit
from .system import VerticalSystem,forcing
from .observer import EnergyObserver
from .energy import ledger_rk4,balance,hemisphere_powers
from .transport import vertical_observables,parity_error,orientation_nematic,ring_currents,peak_catalog
from .storage import ChunkStore,finalize,verify_completion
from .common import ROOT,save_json,save_npz,fingerprint,code_hash,sha,cumulative

def run_case(c,out,admission=None):
    if admission is None or admission.get('explicit_execute') is not True or admission.get('status')!='PLANNED_NOT_EXECUTED' or admission.get('dependencies',{}).get('missing'):
        raise PermissionError('Use the explicit CLI run --execute after frozen-input, dependency and resource admission')
    if admission.get('frozen_checks',{}).get('changed') or admission.get('frozen_checks',{}).get('missing'):
        raise PermissionError('Changed or missing preregistered inputs')
    folder=Path(out)/c['case_id'];folder.mkdir(parents=True,exist_ok=True)
    run_id=fingerprint(dict(config=c,code_sha256=code_hash(),gates=sha(ROOT/'config/gates.json')))
    if verify_completion(folder):
        result=json.loads((folder/'case.json').read_text())
        if result['run_id']!=run_id:raise ValueError('finished output belongs to a different frozen run')
        ChunkStore(folder/'chunks',run_id);return result
    if (folder/'run.json').exists() and json.loads((folder/'run.json').read_text())['run_id']!=run_id:raise ValueError('use a fresh output folder after configuration/code changes')
    beg=time.monotonic();mesh=RectilinearMesh(axes_from_config(c['grid']));metric,H=build_geometry(c);rec=catalog(c,mesh.bounds);active=rec['active'];indices=np.flatnonzero(active);r=c['receivers']
    reciprocal=(indices<468) if r['historical_mode']=='reciprocal' else np.zeros(len(indices),bool)
    system=VerticalSystem(mesh,metric,c['field']['mass'],points=rec['xyz'][active],reciprocal_mask=reciprocal,omega=r['omega'],coupling=r['coupling'],gamma_r=r['gamma'],boundary=c['field']['boundary'],sponge=c['field']['sponge'],sponge_width=c['field']['sponge_width'])
    observer=EnergyObserver(system);force,dipole=forcing(system,c)
    intervals=[Fraction(str(c['observation'][k])).limit_denominator(10**6) for k in ('sample_dt','diagnostic_dt','volume_dt')]
    den=lcm(*[a.denominator for a in intervals]);tick=gcd(*[a.numerator*(den//a.denominator) for a in intervals])/den
    dt=tick/ceil(tick/min(c['field']['dt'],system.dt_bound));nt=int(round(c['field']['t_end']/dt));strides=[int(round(float(a)/dt)) for a in intervals]
    if nt*mesh.n*240>admission['limits']['max_matvec_operations']:raise RuntimeError('BLOCKED_RESOURCES: assembled CFL increases CPU estimate above frozen bound')
    theta=np.arange(64)*2*np.pi/64;rz=np.asarray(c['phase_z']);radii=np.asarray(c['phase_radii'])
    probes=np.array([[rr*np.cos(a),rr*np.sin(a),zz] for zz in rz for rr in radii for a in theta]);inside=np.all((probes>=mesh.bounds[:,0])&(probes<=mesh.bounds[:,1]),axis=1);C=mesh.interpolation(probes[inside])
    zi=np.array([np.argmin(abs(mesh.axes[2]-z)) for z in rz])
    save_npz(folder/'grid.npz',x=mesh.axes[0],y=mesh.axes[1],z=mesh.axes[2],H=H(mesh.xyz).reshape(mesh.shape).astype('f4'),node_volume=observer.node_volume.reshape(mesh.shape),receiver_xyz=rec['xyz'],receiver_active=active,receiver_labels=rec['labels'],receiver_kind=rec['kind'],probe_z=rz,probe_r=radii,probe_theta=theta,slice_actual_z=mesh.axes[2][zi])
    run=dict(status='RUNNING',run_id=run_id,case_id=c['case_id'],config=c,dt=dt,steps=nt,active_historical=int(active[:468].sum()),active_receivers=int(active.sum()),code_sha256=code_hash(),metric=metric_audit(metric,mesh.xyz[::max(1,mesh.n//1000)]),new_bench='VVR-01',scientific_execution_requires_explicit_command=True)
    run['environment']=dict(python=sys.version,platform=platform.platform(),dependencies={name:importlib.metadata.version(name) for name in ('numpy','scipy','matplotlib','pillow')},BLAS_threads={k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')})
    save_json(folder/'run.json',run);store=ChunkStore(folder/'chunks',run_id);cp=folder/'checkpoint.npz';state=np.zeros(2*mesh.n+2*system.h);ledger=np.zeros(3);start=0;initial=0.
    if c['initial']=='standing_mode':
        q=np.prod([np.sin(np.pi*(mesh.xyz[:,k]-mesh.bounds[k,0])/np.ptp(mesh.bounds[k])) for k in range(3)],axis=0)
        q[mesh.boundary]=0.;state[:mesh.n]=q;initial=system.energy(state)
    if cp.exists():
        with np.load(cp,allow_pickle=False) as d:
            if str(d['run_id'])!=run_id:raise ValueError('checkpoint identity mismatch')
            state=d['state'];ledger=d['ledger'];start=int(d['step']);initial=float(d['H_initial'])
        store.rollback(start)
    try:
        for i in range(start,nt+1):
            t=i*dt;sample=cuts=volume=None
            if i%strides[0]==0:
                b=balance(system.energy(state),initial,ledger);sample=dict(X=state[2*mesh.n:2*mesh.n+system.h],P=state[2*mesh.n+system.h:],field=system.C@state[:mesh.n],ledger=ledger,H=b['H'],balance_relative_error=b['balance_relative_error'],hemisphere_powers=hemisphere_powers(system,state,t,force))
            if i%strides[1]==0:
                observed=observer.evaluate(state);shape=mesh.shape;phi=state[:mesh.n].reshape(shape);E=observed['energy_density'].reshape(shape);J=observed['flux'].reshape(*shape,3)
                stats=vertical_observables(mesh.axes,E,J,observer.node_volume,gamma=system.gam,planes=c['planes']);parity=parity_error(phi,E,J,mesh.axes);slices=[];nematic=[]
                stats['ring_currents']=ring_currents(mesh.axes,J,rz,radii,gamma=system.gam)
                stats['orbital_Lz']=observed['orbital_Lz_operational']
                for k in zi:slices.append(peak_catalog(phi[:,:,k],*mesh.axes[:2]));nematic.append(orientation_nematic(phi[:,:,k],*mesh.axes[:2]))
                ring=np.full(len(probes),np.nan);ring[inside]=C@phi.ravel()
                cuts=dict(xy=phi[:,:,zi].transpose(2,0,1).astype('f4'),xz=phi[:,np.argmin(abs(mesh.axes[1])),:].astype('f4'),yz=phi[np.argmin(abs(mesh.axes[0])),:,:].astype('f4'),ring=ring.reshape(len(rz),len(radii),len(theta)).astype('f4'),stats_json=json.dumps(stats,default=lambda v:v.tolist() if isinstance(v,np.ndarray) else v),parity_json=json.dumps(parity),peaks_json=json.dumps(slices),nematic_json=json.dumps(nematic),orbital_Lz_operational=observed['orbital_Lz_operational'],kinetic_quadrature_correction=observed['old_kinetic_quadrature_deficit'])
            if i%strides[2]==0:
                dtype=c['observation']['dtype'];volume=dict(phi=state[:mesh.n].reshape(mesh.shape).astype(dtype),momentum=state[mesh.n:2*mesh.n].reshape(mesh.shape).astype(dtype))
            if any(x is not None for x in (sample,cuts,volume)):
                store.write(i,t,sample,cuts,volume)
                save_npz(cp,run_id=run_id,step=i,state=state,ledger=ledger,H_initial=initial)
            if i==nt:break
            state,ledger=ledger_rk4(system,state,ledger,t,dt,force)
            if not np.isfinite(state).all() or np.max(abs(state))>1e25:raise FloatingPointError('nonfinite/divergent state')
        samples=[]
        for row in store.catalog['records']:
            if row.get('sample'):
                with np.load(folder/'chunks'/row['sample'],allow_pickle=False) as d:samples.append({k:d[k].copy() for k in d.files})
        times=np.array([d['t'] for d in samples]);X=np.array([d['X'] for d in samples]);P=np.array([d['P'] for d in samples]);incident=np.array([d['field'] for d in samples])
        rl=historical('b39_rele');R=rl.leitura(times,X,P,np.full(system.h,r['omega']))
        thresholds=json.loads((ROOT/'inputs/historical_thresholds.json').read_text());key=r['historical_threshold_case'];key=key.replace('_s+1','_s-1') if c['rotation']==-1 else key;threshold=thresholds[key]
        lock=rl.rele(times,R,threshold['theta_lock'],'trava');release=rl.rele(times,R,threshold['theta_release'],'solta')
        regional=np.array([d['hemisphere_powers'] for d in samples])
        save_npz(folder/'observations.npz',ts=times,X=X,P=P,field=incident,readout=R,relay_lock=lock,relay_release=release,active_catalog_indices=indices,energy=np.array([d['H'] for d in samples]),ledger=np.array([d['ledger'] for d in samples]),balance_relative_error=np.array([d['balance_relative_error'] for d in samples]),hemisphere_powers=regional,hemisphere_work_sampled=cumulative(times,regional))
        result=dict(run,thresholds=threshold,relay_fired_historical=int(np.any(lock[:,indices<468]>0,axis=0).sum()),relay_fired_all=int(np.any(lock>0,axis=0).sum()),seconds=time.monotonic()-beg,frames=sum(bool(r.get('volume')) for r in store.catalog['records']),max_balance_error=max(float(d['balance_relative_error']) for d in samples),scientific_verdict='INCONCLUSIVE_PENDING_CONTROLS',HRF_holography='BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY')
        finalize(folder,result);cp.unlink(missing_ok=True);return dict(result,status='COMPLETED')
    except BaseException as exc:
        save_json(folder/'run.json',dict(run,status='INTERRUPTED_OR_FAILED',error=type(exc).__name__+': '+str(exc)));raise
