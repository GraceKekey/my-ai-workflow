"""Energy-current integral curves, headless orientation and falsifiable candidates.

These are operational curves of J/e, not material worldlines or particle paths.
No phase ridge is used to choose the seeds or the transport trajectory.
"""
import numpy as np
from scipy.interpolate import RegularGridInterpolator

def energy_velocity(energy,current,lapse=None,gamma=None,floor=1e-20):
    e=np.asarray(energy,float);j=np.asarray(current,float);N=1. if lapse is None else np.asarray(lapse)
    v=np.divide(j,e[...,None],out=np.zeros_like(j),where=e[...,None]>floor)*np.asarray(N)[...,None] if np.ndim(N) else np.divide(j,e[...,None],out=np.zeros_like(j),where=e[...,None]>floor)*N
    speed2=np.sum(v*v,axis=-1) if gamma is None else np.einsum('...i,...ij,...j->...',v,gamma,v)
    valid=(e>floor)&np.isfinite(v).all(axis=-1)&(speed2<=np.asarray(N)**2*(1+1e-5))
    return np.where(valid[...,None],v,np.nan),valid

def seed_plane(axes,current,height,max_seeds=256,gamma=None):
    from .transport import interpolate_plane,integrate_xy
    x,y,z=axes;sign=1 if height>0 else -1;sqrtg=1. if gamma is None else np.sqrt(np.linalg.det(gamma));j=sign*interpolate_plane(sqrtg*current[...,2],z,height)
    stride=max(1,int(np.ceil(np.sqrt(len(x)*len(y)/max_seeds))))
    ii=np.unique(np.r_[np.arange(0,len(x),stride),len(x)-1]);jj=np.unique(np.r_[np.arange(0,len(y),stride),len(y)-1])
    xx=x[ii];yy=y[jj];coarse=np.maximum(j[np.ix_(ii,jj)],0.)
    def weights(a):
        w=np.empty(len(a));w[0]=(a[1]-a[0])/2;w[-1]=(a[-1]-a[-2])/2;w[1:-1]=(a[2:]-a[:-2])/2;return w
    w=coarse*weights(xx)[:,None]*weights(yy)[None,:];X,Y=np.meshgrid(xx,yy,indexing='ij');points=np.c_[X.ravel(),Y.ravel(),np.full(X.size,height)]
    fine=float(integrate_xy(np.maximum(j,0),x,y));sampled=float(w.sum());valid=w.ravel()>max(w.max(initial=0)*1e-6,1e-28)
    return points[valid],w.ravel()[valid],abs(sampled-fine)/max(fine,1e-30)

def track_curves(axes,frames,start_index,height,max_seeds=256,sponge_width=(10.,10.,10.),gamma=None):
    """frames is a re-iterable generator factory yielding (t,e,J). Only two fields in memory."""
    paths=[];valids=[];times=[];weights=None;seed_error=None;prev=None;positions=None;live=None
    bounds=np.array([[a[0],a[-1]] for a in axes]);mindx=min(np.min(np.diff(a)) for a in axes)
    for index,(t,e,j) in enumerate(frames()):
        if index<start_index:continue
        v,good=energy_velocity(e,j,gamma=gamma)
        if positions is None:
            positions,weights,seed_error=seed_plane(axes,j,height,max_seeds,gamma);live=np.ones(len(positions),bool)
            prev=(t,v);paths.append(positions.copy());valids.append(live.copy());times.append(t);continue
        dt=t-prev[0]
        if dt<=0 or dt>.5*mindx:raise ValueError('flowline temporal resolution insufficient for frozen displacement bound')
        old=RegularGridInterpolator(axes,prev[1],bounds_error=False,fill_value=np.nan)
        new=RegularGridInterpolator(axes,v,bounds_error=False,fill_value=np.nan)
        active=np.flatnonzero(live)
        if len(active):
            pos=positions[active];v0=old(pos);mid=pos+.5*dt*v0;vm=.5*(old(mid)+new(mid));proposal=pos+dt*vm
            ok=np.isfinite(proposal).all(axis=1)&np.all((proposal>bounds[:,0]+sponge_width)&(proposal<bounds[:,1]-sponge_width),axis=1)
            live[active[~ok]]=False;positions[active[ok]]=proposal[ok];positions[active[~ok]]=np.nan
        paths.append(positions.copy());valids.append(live.copy());times.append(t);prev=(t,v)
    if positions is None:return dict(status='NO_SEED_FRAME')
    return dict(status='OPERATIONAL_ENERGY_CURRENT_CURVES',t=np.asarray(times),xyz=np.asarray(paths),valid=np.asarray(valids),seed_weight=weights,
                seed_quadrature_relative_error=seed_error,notice='integral curves of the Eulerian energy velocity, not material or photon trajectories')

def curve_candidate(t,xyz,valid,cell,omega,gates):
    idx=np.flatnonzero(valid)
    if len(idx)<gates['curve_min_frames']:return dict(candidate=False,reason='too few valid frames')
    # First contiguous segment only; never reconnect after loss or topology change.
    idx=idx[:next((i for i in range(1,len(idx)) if idx[i]!=idx[i-1]+1),len(idx))]
    p=np.asarray(xyz)[idx];tt=np.asarray(t)[idx];r=np.hypot(p[:,0],p[:,1]);angle=np.unwrap(np.arctan2(p[:,1],p[:,0]));dz=float(p[-1,2]-p[0,2])
    if len(p)<3:return dict(candidate=False,reason='disconnected data')
    A=np.c_[p[:,2],np.ones(len(p))];fit=np.linalg.lstsq(A,angle,rcond=None)[0];span=float(np.ptp(angle));res=float(np.sqrt(np.mean((A@fit-angle)**2))/max(span,1e-30))
    cv=float(np.std(r)/max(np.mean(r),1e-30));direction=np.sign(p[0,2]);outward=np.mean(direction*np.diff(p[:,2])>0)
    candidate=(span>=gates['curve_angle_min'] and abs(dz)>=max(gates['curve_dz_min'],4*cell) and np.min(r)>=2*cell and cv<=gates['curve_radius_cv_max'] and res<=gates['curve_fit_residual_max'] and outward>=gates['curve_outward_fraction_min'] and tt[-1]-tt[0]>=2*np.pi/omega)
    return dict(candidate=bool(candidate),angle_span=span,z_displacement=dz,radius_cv=cv,fit_relative_residual=res,outward_fraction=float(outward),dtheta_dz=float(fit[0]),duration=float(tt[-1]-tt[0]))

def transport_gate(curves,cell,omega,gates,controls,return_fraction):
    required=('PASS_NUMERICAL_REFERENCE','PASS_ENERGY_BALANCE','PASS_VERTICAL_SYMMETRY_CONTROL','SPATIAL_CONVERGENCE','TEMPORAL_CONVERGENCE','BOUNDARY_ROBUSTNESS','FLOWLINE_REFINEMENT')
    ready=all(controls.get(k) is True for k in required)
    if curves.get('status')!='OPERATIONAL_ENERGY_CURRENT_CURVES' or len(curves['seed_weight'])==0:return dict(status='INCONCLUSIVE',reason='no resolved seed flux')
    measured=[curve_candidate(curves['t'],curves['xyz'][:,i],curves['valid'][:,i],cell,omega,gates) for i in range(len(curves['seed_weight']))]
    weights=np.asarray(curves['seed_weight']);fraction=float(sum(w for w,m in zip(weights,measured) if m['candidate'])/weights.sum())
    enough=len(weights)>=gates['curve_min_seeds'] and curves['seed_quadrature_relative_error']<=gates['seed_quadrature_error_max'] and return_fraction<=gates['return_fraction_max']
    candidate=ready and enough and fraction>=gates['candidate_weight_fraction_min']
    status='HELICAL_ENERGY_TRANSPORT_CANDIDATE' if candidate else ('NO_RESOLVED_HELICAL_TRANSPORT' if ready and enough else 'INCONCLUSIVE')
    return dict(status=status,operational_curve_candidates=measured,sampled_flux_weight_fraction=fraction,controls=controls,controls_complete=ready,sampling_adequate=bool(enough),
                interpretation='frozen candidate for sampled energy-current curves; does not identify a unique material helix')
