"""Inspect .npy headers in ZIP streams before loading historical numeric arrays."""
from pathlib import Path
import json,zipfile,shutil
import numpy as np
from hrf_integral.mesh_adaptive import axes_from_config

def uncompressed_npz(path):
    with zipfile.ZipFile(path) as z:return sum(x.file_size for x in z.infolist())

def analysis_admission(folder,output,gates,flowlines=False):
    folder=Path(folder);out=Path(output);meta=json.loads((folder/'case.json').read_text());c=meta['config'];axes=axes_from_config(c['grid']);n=int(np.prod([len(a) for a in axes]));old=(folder/'frames/frames.json').exists()
    cat=json.loads((folder/('frames/frames.json' if old else 'chunks/catalog.json')).read_text());records=cat['frames' if old else 'records']
    frames=len(records);nz=len(c['diagnostics']['z_planes']) if old else len(c['phase_z']);nr=len(c['diagnostics']['radii']) if old else len(c['phase_radii']);theta=c['diagnostics']['angular_samples'] if old else 64
    rings=frames*nz*nr*theta;inputs=uncompressed_npz(folder/'observations.npz')+uncompressed_npz(folder/'grid.npz')
    memory=inputs+int(rings*130+n*200+512*1024**2)+(n*8500 if flowlines and not old else 0)
    disk=int(rings*100+inputs+128*1024**2)
    probe=out.resolve()
    while not probe.exists():probe=probe.parent
    reasons=[]
    if memory>gates['analysis_memory_bytes']:reasons.append('analysis memory estimate exceeds frozen budget')
    if disk>gates['analysis_disk_bytes']:reasons.append('analysis disk estimate exceeds frozen budget')
    if disk+2*1024**3>shutil.disk_usage(probe).free:reasons.append('actual free disk inadequate')
    available=None
    try:
        mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines());available=int(mem['MemAvailable'].strip().split()[0])*1024
        cp=Path('/sys/fs/cgroup/memory.max')
        if cp.exists() and cp.read_text().strip()!='max':available=min(available,int(cp.read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text()))
        if memory>available:reasons.append('actual available memory inadequate')
    except (OSError,ValueError,KeyError):pass
    return dict(status='BLOCKED_RESOURCES' if reasons else 'ADMITTED_REANALYSIS',memory_bytes=memory,disk_bytes=disk,reasons=reasons,actual_available_memory=available,new_PDE_integrations=0)
