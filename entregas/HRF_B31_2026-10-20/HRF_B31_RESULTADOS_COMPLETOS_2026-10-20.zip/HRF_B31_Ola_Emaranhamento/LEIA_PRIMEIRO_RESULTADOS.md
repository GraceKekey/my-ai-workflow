# B31 — resultados completos

Leia RELATORIO_CIENTIFICO_B31.md e resultados/avaliacao_B31.json.

Há código, protocolo, ZIP original, dados, logs, tabelas, figuras, verificações de integridade e auditoria suplementar. Os arquivos de fumaca/ não participam da avaliação completa.
