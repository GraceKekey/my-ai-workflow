# -*- coding: utf-8 -*-
"""HRF B31d — a ola de emaranhamento: um quantum atravessando um disco de GMFs.

Estado |psi> = a^dagger(f)|0>, f = pacote gaussiano em k (helicidade circular com dois campos de polarização).
Nada aqui usa o complemento explicitamente: para um estado puro gaussiano e L = L_A + L_Abar linear,
    |psi> = O_A |Omega> + |chi>,   O_A = sum_k [ p_k/(n_k+1) b_k^dagger - (q_k/n_k) b_k ],
onde b_k são os modos de Williamson de A (ocupação n_k = nu_k - 1/2), L_A = sum_k (p_k b_k^dagger + q_k b_k), e |chi>
é a parte do pacote em modos de Abar não emaranhados com A. Então
    rho_A = O rho0 O^dagger + c rho0,   c = <L_Abar^dagger L_Abar> - sum_k (|p|^2 n^2/(n+1) + |q|^2 (n+1)^2/n),
e a entropia de Rényi-2 sai fechada (teorema de Wick no estado térmico com 2 eps):
    Tr rho_A^2 / Tr rho0^2 = [a12^2 + 4|sum u v s|^2 + b^2 + 2 c b + c^2] / Z^2,
    s = 1/(2 sinh eps), b = sum (|u|^2+|v|^2) s, a12 = sum |u|^2 (m2+1) + |v|^2 m2, m2 = 1/(e^{2eps}-1),
    Z = sum |u|^2 (n+1) + |v|^2 n + c  (= 1: teste de validade).
Modos com n < tau são tratados como puros (sem parceiro); a validade exige insensibilidade a tau.
"""
import numpy as np
from scipy.linalg import eigh

import b31_rede as rd


def williamson_modos(XA, PA):
    ex, U = eigh(XA)
    Xh = (U * np.sqrt(ex)) @ U.T
    Xmh = (U / np.sqrt(ex)) @ U.T
    C2 = Xh @ PA @ Xh
    nu2, W = eigh(0.5 * (C2 + C2.T))
    nu = np.sqrt(np.maximum(nu2, 0.25))
    # phi_A = Xh W D^{-1/2} Q ;  P_A = Xmh W D^{1/2} Pi ;  b = (Q + i Pi)/sqrt(2)
    Gphi = Xh @ W / np.sqrt(nu)[None, :]
    Gpi = Xmh @ W * np.sqrt(nu)[None, :]
    return nu, Gphi, Gpi


def coef_modos(alpha_A, beta_A, Gphi, Gpi):
    a = alpha_A @ Gphi
    c = beta_A @ Gpi
    p = (a + 1j * c) / np.sqrt(2.0)
    q = (a - 1j * c) / np.sqrt(2.0)
    return p, q


def renyi2(p_list, q_list, n, tau, c_total):
    """p_list, q_list: listas (uma por campo de polarização) de coeficientes; n: ocupações (iguais nos campos)."""
    puro = n < tau
    nn = np.where(puro, 1.0, n)
    eps = np.where(puro, np.inf, np.log1p(1.0 / nn))
    s = np.where(puro, 0.0, 0.5 / np.sinh(np.where(puro, 1.0, eps)))
    m2 = np.where(puro, 0.0, 1.0 / np.expm1(2 * np.where(puro, 1.0, eps)))
    a1 = a12 = b = 0.0
    uvs = 0.0 + 0.0j
    resto = 0.0
    for p, q in zip(p_list, q_list):
        u = p / (n + 1.0)
        v = np.where(puro, 0.0, -q / nn)
        # termos do parceiro e o resto não emaranhado
        resto += float(np.sum(np.where(puro, 0.0, np.abs(p) ** 2 * nn ** 2 / (nn + 1) + np.abs(q) ** 2 * (nn + 1) ** 2 / nn)))
        a1 += float(np.sum(np.abs(u) ** 2 * (n + 1) + np.abs(v) ** 2 * n))
        a12 += float(np.sum(np.abs(u) ** 2 * (m2 + 1) + np.abs(v) ** 2 * m2))
        b += float(np.sum((np.abs(u) ** 2 + np.abs(v) ** 2) * s))
        uvs += complex(np.sum(u * v * s))
    c = c_total - resto
    Z = a1 + c
    razao = (a12 ** 2 + 4 * abs(uvs) ** 2 + b ** 2 + 2 * c * b + c * c) / (Z * Z)
    return float(-np.log(razao)), float(Z), float(c), float(np.max(np.abs(q_list[0][puro])) if np.any(puro) else 0.0)


def norma_complemento(alpha_A, beta_A, XA, PA):
    """<L_Abar^dagger L_Abar> = 1 - 2 Re[L_A^dagger, L_A] + <L_A^dagger L_A>, com [L_A^dagger, L_A] = -2 sum Im(conj(alpha) beta)."""
    comut = -2.0 * np.sum(np.imag(np.conj(alpha_A) * beta_A))
    LL = np.real(np.conj(alpha_A) @ XA @ alpha_A + np.conj(beta_A) @ PA @ beta_A) - np.sum(np.imag(np.conj(alpha_A) * beta_A))
    return float(1.0 - 2.0 * comut + LL)


def serie(R, Lt, k0, dk, x_ini, tempos, taus=(1e-10, 1e-12), m=0.0):
    """trajetória do pacote ao longo de +x, atravessando um disco de raio R centrado na origem."""
    idx = rd.disco(R)
    Xg, Pg = rd.correladores(Lt, m)
    XA = rd.bloco(Xg, idx, Lt)
    PA = rd.bloco(Pg, idx, Lt)
    nu, Gphi, Gpi = williamson_modos(XA, PA)
    n = nu - 0.5
    sel = (idx[:, 0] % Lt, idx[:, 1] % Lt)
    linhas = []
    for t in tempos:
        al, be, f, w = rd.pacote(Lt, m, k0, dk, (x_ini, 0.0), t)
        aA, bA = al[sel], be[sel]
        e = rd.densidade_energia(al, be, m)
        pE = float(e[sel].sum() / e.sum())
        cnorm = norma_complemento(aA, bA, XA, PA)
        p, q = coef_modos(aA, bA, Gphi, Gpi)
        lin = {"t": float(t), "p_E": pE, "E_total": float(e.sum()), "E_esperada": float(np.sum(np.abs(f) ** 2 * w))}
        for tau in taus:
            d_lin, Z, c, qmax = renyi2([p], [q], n, tau, cnorm)
            r2 = 1.0 / np.sqrt(2.0)
            d_cp, Zp, _, _ = renyi2([p * r2, 1j * p * r2], [q * r2, 1j * q * r2], n, tau, cnorm)
            d_cm, Zm, _, _ = renyi2([p * r2, -1j * p * r2], [q * r2, -1j * q * r2], n, tau, cnorm)
            lin[f"tau={tau:g}"] = {"dS2_linear": d_lin, "dS2_circ_mais": d_cp, "dS2_circ_menos": d_cm,
                                   "Z_linear": Z, "Z_circ_mais": Zp, "Z_circ_menos": Zm, "c": c, "q_max_modos_puros": qmax}
        qp = -np.log(pE ** 2 + (1 - pE) ** 2)
        lin["dS2_quasiparticula"] = float(qp)
        lin["dS2_coerente"] = 0.0  # estado coerente = vácuo deslocado: covariância idêntica (operações locais)
        linhas.append(lin)
    return {"R": R, "Lt": Lt, "n_sitios": int(len(idx)), "nu_min": float(nu.min()), "k0": list(k0), "dk": dk,
            "x_ini": x_ini, "serie": linhas}
