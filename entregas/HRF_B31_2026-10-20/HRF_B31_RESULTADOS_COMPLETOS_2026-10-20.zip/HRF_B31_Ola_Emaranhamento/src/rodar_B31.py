# -*- coding: utf-8 -*-
"""Orquestrador da B31. Uso:
    python -I src/rodar_B31.py fumaca            (tamanhos pequenos, fora do conjunto de decisão)
    python -I src/rodar_B31.py completo [a|b|c|d|tudo]
Cada caso concluído é gravado de forma atômica em resultados/B31_checkpoint.json; relançar retoma sem refazer.
"""
import json
import os
import platform
import sys
import time
from pathlib import Path

os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import numpy as np  # noqa: E402
import scipy  # noqa: E402

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import b31_rede as rd  # noqa: E402
import b31a_modular as ma  # noqa: E402
import b31b_dualidade as bd  # noqa: E402
import b31d_ola as od  # noqa: E402

CONFIG = {
    "fumaca": {
        "B31a": {"R": [5, 6], "L_principal": 256, "L_controle": 128},
        "B31b": {"triangular_n": [8], "rsa": {"N": 60, "densidade": 0.9, "dmin": 0.8, "sementes": [20263101]}},
        "B31c": {"R": 5, "massas": [0.0, 0.2], "L": 256},
        "B31d": {"R": 6, "Lt": [256, 512], "k0": [0.8, 0.0], "dk": 0.8 / 6, "x_ini": -20.0,
                 "tempos": [0, 8, 16, 20, 24, 32, 40], "taus": [1e-10, 1e-12]},
    },
    "completo": {
        "B31a": {"R": [8, 12, 16], "L_principal": 1024, "L_controle": 512},
        "B31b": {"triangular_n": [24], "rsa": {"N": 600, "densidade": 0.9, "dmin": 0.8,
                                               "sementes": [20263101, 20263102, 20263103]}},
        "B31c": {"R": 12, "massas": [0.0, 0.1, 0.2, 0.4], "L": 1024},
        "B31d": {"R": 20, "Lt": [1024, 2048], "k0": [0.8, 0.0], "dk": 0.8 / 6, "x_ini": -35.0,
                 "tempos": list(range(0, 71, 2)), "taus": [1e-10, 1e-12]},
    },
}


class Caderno:
    def __init__(self, caminho):
        self.caminho = Path(caminho)
        self.dados = json.load(open(self.caminho)) if self.caminho.exists() else {"casos": {}}

    def tem(self, chave):
        return chave in self.dados["casos"]

    def grava(self, chave, valor):
        self.dados["casos"][chave] = valor
        tmp = self.caminho.with_suffix(".tmp")
        with open(tmp, "w") as fh:
            json.dump(self.dados, fh, indent=1)
        os.replace(tmp, self.caminho)
        print(f"[{time.strftime('%H:%M:%S')}] gravado {chave}", flush=True)


def bloco_a(cfg, cad):
    c = cfg["B31a"]
    fontes = {f"L{c['L_principal']}": rd.Fonte(c["L_principal"], 0.0), f"L{c['L_controle']}": rd.Fonte(c["L_controle"], 0.0)}
    for R in c["R"]:
        ch = f"B31a|R={R}"
        if cad.tem(ch):
            continue
        t = time.time()
        res = ma.caso(R, 0.0, fontes)
        res["segundos"] = round(time.time() - t, 1)
        cad.grava(ch, res)


def bloco_b(cfg, cad):
    c = cfg["B31b"]
    for n in c["triangular_n"]:
        ch = f"B31b|triangular_{n}"
        if not cad.tem(ch):
            pts, Lx, Ly = bd.triangular_periodico(n)
            cad.grava(ch, bd.caso(f"triangular_{n}", pts, Lx, Ly))
    r = c["rsa"]
    L = float(np.sqrt(r["N"] / r["densidade"]))
    for sem in r["sementes"]:
        ch = f"B31b|rsa_{r['N']}_semente={sem}"
        if cad.tem(ch):
            continue
        pts = bd.rsa_periodico(r["N"], L, L, r["dmin"], np.random.default_rng(sem))
        if len(pts) < r["N"]:
            raise RuntimeError("RSA não atingiu N")
        cad.grava(ch, bd.caso(f"rsa_{r['N']}_{sem}", pts, L, L))


def bloco_c(cfg, cad):
    c = cfg["B31c"]
    for m in c["massas"]:
        ch = f"B31c|R={c['R']}|m={m}"
        if cad.tem(ch):
            continue
        t = time.time()
        res = ma.caso(c["R"], m, {f"L{c['L']}": rd.Fonte(c["L"], m)}, qs=(13,))
        res["segundos"] = round(time.time() - t, 1)
        cad.grava(ch, res)


def bloco_d(cfg, cad):
    c = cfg["B31d"]
    for Lt in c["Lt"]:
        ch = f"B31d|R={c['R']}|Lt={Lt}"
        if cad.tem(ch):
            continue
        t = time.time()
        res = od.serie(c["R"], Lt, tuple(c["k0"]), c["dk"], c["x_ini"], np.array(c["tempos"], dtype=float), tuple(c["taus"]))
        res["segundos"] = round(time.time() - t, 1)
        cad.grava(ch, res)


def main():
    modo = sys.argv[1]
    qual = sys.argv[2] if len(sys.argv) > 2 else "tudo"
    cfg = CONFIG[modo]
    pasta = AQUI.parent / ("fumaca" if modo == "fumaca" else "resultados")
    pasta.mkdir(exist_ok=True)
    meta = {"modo": modo, "config": cfg, "python": platform.python_version(), "numpy": np.__version__,
            "scipy": scipy.__version__, "maquina": platform.platform(), "inicio": time.strftime("%Y-%m-%d %H:%M:%S")}
    with open(pasta / f"B31_config_{modo}.json", "w") as fh:
        json.dump(meta, fh, indent=1)
    cad = Caderno(pasta / "B31_checkpoint.json")
    for b, fn in [("a", bloco_a), ("b", bloco_b), ("c", bloco_c), ("d", bloco_d)]:
        if qual in ("tudo", b):
            fn(cfg, cad)
    print("fim", time.strftime("%H:%M:%S"))


if __name__ == "__main__":
    main()
