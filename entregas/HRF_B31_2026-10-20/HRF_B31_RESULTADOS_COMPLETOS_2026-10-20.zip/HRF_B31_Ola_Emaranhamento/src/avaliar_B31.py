# -*- coding: utf-8 -*-
"""Avaliador congelado da B31. Uso: python -I src/avaliar_B31.py <pasta com B31_checkpoint.json e B31_config_*.json>"""
import json
import math
import sys
from pathlib import Path

LOG2 = math.log(2.0)
D_B31 = {
    "a": {"tol_L": 1e-3, "tol_q": 0.01, "nu_min": 0.5 - 1e-9, "tol_chm": 0.05, "faixa": (0.8, 1.2),
          "loc_chm": 0.95, "loc_nao": 0.80, "q_dec": "13", "q_ctrl": "12"},
    "b": {"tol_dif": 1e-9, "tol_area": 1e-10},
    "c": {"fator": 2.0, "piso": 0.05, "q": "13"},
    "d": {"tol_Z": 1e-8, "tol_tau": 1e-6, "tol_E": 1e-8, "tol_Lt": 1e-3, "nu_min": 0.5 - 1e-9,
          "D1_pmin": 0.9, "D1_max": 0.5 * LOG2, "D2": (0.85, 1.15), "D2_p": (0.3, 0.7), "D3": 0.10, "D4": 0.02,
          "D6": 1e-10},
}


def _razoes(teste):
    return [teste["rho_M_mel"], teste["rho_N"]]


def avaliar_a(casos, cfg):
    d = D_B31["a"]
    c = cfg["B31a"]
    Lp, Lc = f"L{c['L_principal']}", f"L{c['L_controle']}"
    valid, falhas, por_R = True, [], {}
    for R in c["R"]:
        k = casos[f"B31a|R={R}"]
        P = k["por_correlador"][Lp]
        C = k["por_correlador"][Lc]
        tp = P["por_q"][d["q_dec"]]["testes"]
        tq = P["por_q"][d["q_ctrl"]]["testes"]
        tc = C["por_q"][d["q_dec"]]["testes"]
        dL = max(abs(a - b) for x, y in zip(tp, tc) for a, b in zip(_razoes(x), _razoes(y)))
        dq = max(abs(a - b) for x, y in zip(tp, tq) for a, b in zip(_razoes(x), _razoes(y)))
        numin = min(P["nu_min"], C["nu_min"])
        if dL > d["tol_L"]:
            valid = False
            falhas.append(f"R={R}: |Δρ| entre {Lp} e {Lc} = {dL:.2e}")
        if dq > d["tol_q"]:
            valid = False
            falhas.append(f"R={R}: |Δρ| entre cortes q=12 e 13 = {dq:.2e}")
        if numin < d["nu_min"]:
            valid = False
            falhas.append(f"R={R}: nu_min = {numin}")
        dev = max(abs(r - 1) for t in tp for r in _razoes(t))
        dev_can = max(abs(t["rho_M_can"] - 1) for t in tp)
        todas = [r for t in tp for r in _razoes(t)]
        por_R[R] = {"desvio_max": dev, "desvio_M_canonico": dev_can, "razoes_min_max": [min(todas), max(todas)],
                    "localidade_N_media": P["por_q"][d["q_dec"]]["localidade_N_media_min"][0],
                    "localidade_M_media": P["por_q"][d["q_dec"]]["localidade_M_media_min"][0],
                    "dif_L": dL, "dif_q": dq, "R_efetivo": k["R_efetivo"]}
    Rmax, Rmin = max(c["R"]), min(c["R"])
    g = por_R[Rmax]
    if not valid:
        dec = "INCONCLUSIVO"
    elif g["razoes_min_max"][0] < d["faixa"][0] or g["razoes_min_max"][1] > d["faixa"][1] or g["localidade_N_media"] < d["loc_nao"]:
        dec = "NAO_CHM"
    elif g["desvio_max"] <= d["tol_chm"] and g["desvio_max"] <= por_R[Rmin]["desvio_max"] and g["localidade_N_media"] >= d["loc_chm"]:
        dec = "LOCAL_CHM"
    else:
        dec = "LOCAL_DEFORMADO"
    return {"decisao": dec, "validade": valid, "falhas_validade": falhas, "por_R": por_R,
            "melhoria_aproxima_de_1": g["desvio_max"] < g["desvio_M_canonico"]}


def avaliar_b(casos, cfg):
    d = D_B31["b"]
    linhas, ok = [], True
    for ch, k in casos.items():
        if not ch.startswith("B31b|"):
            continue
        cond = (k["dif_espectral_relativa"] <= d["tol_dif"] and k["nulos_Z"] == 1
                and k["nulos_gauge"] == k["nulos_gauge_previstos"] and abs(k["soma_areas_sobre_area"] - 1) <= d["tol_area"]
                and k["peso_min"] > 0 and k["euler_V_menos_E_mais_F"] == 0)
        ok = ok and cond
        linhas.append({"malha": k["malha"], "passa": cond, "dif": k["dif_espectral_relativa"],
                       "nulos": [k["nulos_Z"], k["nulos_gauge"], k["nulos_gauge_previstos"]]})
    return {"decisao": "DUAL_EXATO" if ok and linhas else "FALHA", "malhas": linhas}


def avaliar_c(casos, cfg):
    d = D_B31["c"]
    c = cfg["B31c"]
    devs, S = [], []
    for m in c["massas"]:
        k = casos[f"B31c|R={c['R']}|m={m}"]
        P = list(k["por_correlador"].values())[0]
        tp = P["por_q"][d["q"]]["testes"]
        devs.append(max(abs(r - 1) for t in tp for r in _razoes(t)))
        S.append(P["S"])
    mono = all(b > a for a, b in zip(devs, devs[1:]))
    forte = devs[-1] >= max(d["fator"] * devs[0], d["piso"])
    return {"decisao": "GAP_QUEBRA_CHM" if (mono and forte) else "INDEFINIDO", "massas": c["massas"],
            "desvio_max_por_massa": devs, "S_por_massa": S, "S_decresce": all(b < a for a, b in zip(S, S[1:]))}


def avaliar_d(casos, cfg):
    d = D_B31["d"]
    c = cfg["B31d"]
    taus = [f"tau={t:g}" for t in c["taus"]]
    s1 = casos[f"B31d|R={c['R']}|Lt={c['Lt'][0]}"]
    s2 = casos[f"B31d|R={c['R']}|Lt={c['Lt'][1]}"]
    valid, falhas = True, []
    for s in (s1, s2):
        if s["nu_min"] < d["nu_min"]:
            valid = False
            falhas.append(f"Lt={s['Lt']}: nu_min = {s['nu_min']}")
        for l in s["serie"]:
            for tau in taus:
                for zk in ("Z_linear", "Z_circ_mais", "Z_circ_menos"):
                    if abs(l[tau][zk] - 1) > d["tol_Z"]:
                        valid = False
                        falhas.append(f"Lt={s['Lt']} t={l['t']}: {zk} = {l[tau][zk]}")
            dt = abs(l[taus[0]]["dS2_linear"] - l[taus[1]]["dS2_linear"])
            if dt > d["tol_tau"]:
                valid = False
                falhas.append(f"Lt={s['Lt']} t={l['t']}: |Δ tau| = {dt:.2e}")
            if abs(l["E_total"] / l["E_esperada"] - 1) > d["tol_E"]:
                valid = False
                falhas.append(f"Lt={s['Lt']} t={l['t']}: energia")
    dLt = max(abs(a[taus[0]]["dS2_linear"] - b[taus[0]]["dS2_linear"]) for a, b in zip(s1["serie"], s2["serie"]))
    if dLt > d["tol_Lt"]:
        valid = False
        falhas.append(f"|Δ Lt| = {dLt:.2e}")
    ser = s1["serie"]
    lin = [l[taus[0]]["dS2_linear"] for l in ser]
    qp = [l["dS2_quasiparticula"] for l in ser]
    pE = [l["p_E"] for l in ser]
    cp = [l[taus[0]]["dS2_circ_mais"] for l in ser]
    cm = [l[taus[0]]["dS2_circ_menos"] for l in ser]
    i_in = max(range(len(pE)), key=lambda i: pE[i])
    D1_aval = pE[i_in] >= d["D1_pmin"]
    D1 = D1_aval and lin[i_in] <= d["D1_max"]
    i_max = max(range(len(lin)), key=lambda i: lin[i])
    D2 = (d["D2"][0] * LOG2 <= lin[i_max] <= d["D2"][1] * LOG2) and (d["D2_p"][0] <= pE[i_max] <= d["D2_p"][1])
    D3v = max(abs(a - b) for a, b in zip(lin, qp))
    D4v = max(max(abs(a - b), abs(c2 - b)) for a, c2, b in zip(cp, cm, lin))
    D6v = max(abs(a - b) for a, b in zip(cp, cm))
    D3, D4, D6 = D3v <= d["D3"], D4v <= d["D4"], D6v <= d["D6"]
    if not valid:
        dec = "INCONCLUSIVO"
    elif not D2:
        dec = "NAO_CONFIRMADA"
    elif D1 and D3 and D4 and D6:
        dec = "CONFIRMADA"
    else:
        dec = "PARCIAL"
    return {"decisao": dec, "validade": valid, "falhas_validade": falhas[:20], "dif_Lt": dLt,
            "D1": {"avaliavel": D1_aval, "passa": D1, "p_E_max": pE[i_in], "dS2_no_p_E_max": lin[i_in]},
            "D2": {"passa": D2, "dS2_max": lin[i_max], "em_unidades_de_log2": lin[i_max] / LOG2, "p_E_no_max": pE[i_max]},
            "D3": {"passa": D3, "max_dif_quasiparticula": D3v},
            "D4": {"passa": D4, "max_dif_circular_linear": D4v},
            "D6": {"passa": D6, "max_dif_helicidades": D6v}}


def global_(a, b, d):
    if "INCONCLUSIVO" in (a["decisao"], d["decisao"]) or b["decisao"] == "FALHA":
        return "INCONCLUSIVA"
    if a["decisao"] == "NAO_CHM" or d["decisao"] == "NAO_CONFIRMADA":
        return "NAO_APOIADA"
    if a["decisao"] == "LOCAL_CHM" and d["decisao"] == "CONFIRMADA" and b["decisao"] == "DUAL_EXATO":
        return "APOIADA"
    return "PARCIAL"


def main():
    pasta = Path(sys.argv[1])
    casos = json.load(open(pasta / "B31_checkpoint.json"))["casos"]
    cfgf = sorted(pasta.glob("B31_config_*.json"))[-1]
    meta = json.load(open(cfgf))
    cfg = meta["config"]
    a, b, c, d = avaliar_a(casos, cfg), avaliar_b(casos, cfg), avaliar_c(casos, cfg), avaliar_d(casos, cfg)
    out = {"modo": meta["modo"], "B31a": a, "B31b": b, "B31c": c, "B31d": d, "global": global_(a, b, d),
           "regras": D_B31}
    with open(pasta / "avaliacao_B31.json", "w") as fh:
        json.dump(out, fh, indent=1, default=str)
    print(json.dumps({k: (v["decisao"] if isinstance(v, dict) and "decisao" in v else v) for k, v in out.items() if k != "regras"}, indent=1))


if __name__ == "__main__":
    main()
