# -*- coding: utf-8 -*-
"""HRF B31b — dualidade exata em 2D: a ola nos GMFs (Z) e um campo de gauge na espuma de Voronoi (bolha = laço).

Lado Z (GMFs = vértices da Delaunay):  H = sum P_i^2/(2 A_i) + 1/2 sum_e w_e (Z_i - Z_j)^2.
Lado gauge (paredes de Voronoi = ligações, bolhas = laços): H = sum_e E_e^2/(2 m_e) + sum_i B_i^2/(2 mu_i), B = d1 a,
com mu_i = A_i e 1/m_e = w_e. Previsão: espectros não nulos idênticos; modos nulos: 1 (Z) e F + 1 (gauge) no toro.
Malhas periódicas: rede triangular (tapete da E-65) e Delaunay de pontos com núcleo duro (RSA).
"""
import numpy as np
from scipy.spatial import Delaunay
from scipy.linalg import eigh


def rsa_periodico(N, Lx, Ly, dmin, rng, tent=200000):
    pts = []
    for _ in range(tent):
        p = rng.random(2) * [Lx, Ly]
        ok = True
        for q in pts:
            d = p - q
            d -= np.round(d / [Lx, Ly]) * [Lx, Ly]
            if d @ d < dmin * dmin:
                ok = False
                break
        if ok:
            pts.append(p)
            if len(pts) == N:
                break
    return np.array(pts)


def triangular_periodico(n):
    pts = np.array([[i + 0.5 * j, 0.5 * np.sqrt(3) * j] for j in range(n) for i in range(n)], dtype=float)
    # célula periódica: retângulo n x (n*sqrt3/2) exige n par
    pts[:, 0] = np.mod(pts[:, 0], n)
    return pts, float(n), float(n * np.sqrt(3) / 2)


def delaunay_periodica(pts, Lx, Ly):
    N = len(pts)
    rep, ids = [], []
    for a in (-1, 0, 1):
        for b in (-1, 0, 1):
            rep.append(pts + [a * Lx, b * Ly])
            ids.append(np.arange(N))
    P = np.vstack(rep)
    I = np.concatenate(ids)
    tri = Delaunay(P).simplices
    centro = P[tri].mean(axis=1)
    dentro = (centro[:, 0] >= 0) & (centro[:, 0] < Lx) & (centro[:, 1] >= 0) & (centro[:, 1] < Ly)
    tri = tri[dentro]
    pesos = {}
    area = np.zeros(N)
    for t in tri:
        X = P[t]
        for k in range(3):
            i, j, o = t[k], t[(k + 1) % 3], t[(k + 2) % 3]
            u = P[i] - P[o]
            v = P[j] - P[o]
            cot = (u @ v) / abs(u[0] * v[1] - u[1] * v[0])
            e = tuple(sorted((I[i], I[j])))
            pesos[e] = pesos.get(e, 0.0) + 0.5 * cot
    return tri, I, P, pesos


def montar(pts, Lx, Ly):
    tri, I, P, pesos = delaunay_periodica(pts, Lx, Ly)
    N = len(pts)
    E = sorted(pesos.keys())
    w = np.array([pesos[e] for e in E])
    comp2 = []
    for (i, j) in E:
        d = pts[i] - pts[j]
        d -= np.round(d / [Lx, Ly]) * [Lx, Ly]
        comp2.append(d @ d)
    comp2 = np.array(comp2)
    A = np.zeros(N)
    for (i, j), we, l2 in zip(E, w, comp2):
        A[i] += 0.25 * we * l2
        A[j] += 0.25 * we * l2
    d0 = np.zeros((len(E), N))
    for k, (i, j) in enumerate(E):
        d0[k, i] = 1.0
        d0[k, j] = -1.0
    return {"N": N, "E": len(E), "F": len(tri), "w": w, "A": A, "d0": d0, "area_total": float(Lx * Ly)}


def espectros(m):
    w, A, d0 = m["w"], m["A"], m["d0"]
    # lado Z: omega^2 = eig(A^-1/2 d0^T W d0 A^-1/2)
    Lz = d0.T @ (w[:, None] * d0)
    Kz = Lz / np.sqrt(A)[:, None] / np.sqrt(A)[None, :]
    wz = eigh(Kz, eigvals_only=True)
    # lado gauge: d1 (bolhas x paredes) = d0^T ; omega^2 = eig(m^-1/2 d1^T mu^-1 d1 m^-1/2), m_e = 1/w_e, mu = A
    d1 = d0.T
    Kg = np.sqrt(w)[:, None] * (d1.T @ (d1 / A[:, None])) * np.sqrt(w)[None, :]
    wg = eigh(Kg, eigvals_only=True)
    return wz, wg


def caso(nome, pts, Lx, Ly, tol_zero=1e-9):
    m = montar(pts, Lx, Ly)
    wz, wg = espectros(m)
    escala = max(wz.max(), wg.max())
    nz = int(np.sum(np.abs(wz) < tol_zero * escala))
    ng = int(np.sum(np.abs(wg) < tol_zero * escala))
    az = np.sort(wz[np.abs(wz) >= tol_zero * escala])
    ag = np.sort(wg[np.abs(wg) >= tol_zero * escala])
    mesmo_n = len(az) == len(ag)
    dif = float(np.max(np.abs(az - ag)) / escala) if mesmo_n else float("inf")
    e0z = 0.5 * float(np.sum(np.sqrt(np.maximum(az, 0))))
    e0g = 0.5 * float(np.sum(np.sqrt(np.maximum(ag, 0)))) if mesmo_n else float("nan")
    return {"malha": nome, "N_GMFs": m["N"], "paredes": m["E"], "triangulos": m["F"],
            "euler_V_menos_E_mais_F": m["N"] - m["E"] + m["F"],
            "soma_areas_sobre_area": float(m["A"].sum() / m["area_total"]),
            "peso_min": float(m["w"].min()),
            "nulos_Z": nz, "nulos_gauge": ng, "nulos_gauge_previstos": m["F"] + 1,
            "dif_espectral_relativa": dif, "E0_Z": e0z, "E0_gauge": e0g,
            "omega_min_Z": float(np.sqrt(az.min())), "omega_max_Z": float(np.sqrt(az.max()))}
