# -*- coding: utf-8 -*-
"""Exercita todos os ramos do avaliador congelado com dados sintéticos derivados da fumaça (não é resultado)."""
import copy
import json
import sys
from pathlib import Path

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))
import avaliar_B31 as av  # noqa: E402

pasta = AQUI.parent / "fumaca"
base = json.load(open(pasta / "B31_checkpoint.json"))["casos"]
cfg = json.load(open(pasta / "B31_config_fumaca.json"))["config"]
vistos = {"a": set(), "b": set(), "c": set(), "d": set(), "g": set()}


def mexe_a(casos, fun):
    for R in cfg["B31a"]["R"]:
        k = casos[f"B31a|R={R}"]
        for rot, P in k["por_correlador"].items():
            for q, Q in P["por_q"].items():
                for t in Q["testes"]:
                    fun(R, rot, q, t)


# B31a
for nome, fun in {
    "chm": lambda R, rot, q, t: None,
    "nao": lambda R, rot, q, t: t.update(rho_N=1.3) if R == max(cfg["B31a"]["R"]) else None,
    "deform": lambda R, rot, q, t: t.update(rho_N=1.07) if R == max(cfg["B31a"]["R"]) else None,
    "inconc": lambda R, rot, q, t: t.update(rho_N=t["rho_N"] + (0.05 if q == "12" else 0)),
}.items():
    c = copy.deepcopy(base)
    if nome == "chm":  # valida e com desvio pequeno decrescente
        mexe_a(c, lambda R, rot, q, t: t.update(rho_M_mel=1 + 0.01 / R, rho_N=1 + 0.01 / R))
    else:
        mexe_a(c, lambda R, rot, q, t: t.update(rho_M_mel=1 + 0.01 / R, rho_N=1 + 0.01 / R))
        mexe_a(c, fun)
    r = av.avaliar_a(c, cfg)
    vistos["a"].add(r["decisao"])
    print("B31a", nome, "->", r["decisao"])
# B31b
c = copy.deepcopy(base)
vistos["b"].add(av.avaliar_b(c, cfg)["decisao"])
for k in c:
    if k.startswith("B31b|"):
        c[k]["dif_espectral_relativa"] = 1e-6
vistos["b"].add(av.avaliar_b(c, cfg)["decisao"])
# B31c
c = copy.deepcopy(base)
vistos["c"].add(av.avaliar_c(c, cfg)["decisao"])
for k in c:
    if k.startswith("B31c|") and k.endswith("m=0.2"):
        for P in c[k]["por_correlador"].values():
            for t in P["por_q"]["13"]["testes"]:
                t.update(rho_N=1.0, rho_M_mel=1.0)
vistos["c"].add(av.avaliar_c(c, cfg)["decisao"])


# B31d
def caso_d(fun):
    c = copy.deepcopy(base)
    for k in c:
        if k.startswith("B31d|"):
            fun(c[k])
    return c


def dentro(s):  # p_E máximo alto e emaranhamento baixo nesse instante
    s["serie"][-1]["p_E"] = 0.95
    s["serie"][-1]["dS2_quasiparticula"] = 0.1
    for tau in ("tau=1e-10", "tau=1e-12"):
        s["serie"][-1][tau].update(dS2_linear=0.1, dS2_circ_mais=0.1, dS2_circ_menos=0.1)


def baixo(s):
    for l in s["serie"]:
        for tau in ("tau=1e-10", "tau=1e-12"):
            for kk in ("dS2_linear", "dS2_circ_mais", "dS2_circ_menos"):
                l[tau][kk] *= 0.4


def zruim(s):
    s["serie"][0]["tau=1e-10"]["Z_linear"] = 1.001


for nome, fun in {"confirmada": dentro, "parcial": lambda s: None, "nao": baixo, "inconc": zruim}.items():
    r = av.avaliar_d(caso_d(fun), cfg)
    vistos["d"].add(r["decisao"])
    print("B31d", nome, "->", r["decisao"])
# global
A = {"decisao": "LOCAL_CHM"}
for a, b, d in [("LOCAL_CHM", "DUAL_EXATO", "CONFIRMADA"), ("LOCAL_DEFORMADO", "DUAL_EXATO", "PARCIAL"),
                ("NAO_CHM", "DUAL_EXATO", "CONFIRMADA"), ("INCONCLUSIVO", "DUAL_EXATO", "CONFIRMADA"),
                ("LOCAL_CHM", "FALHA", "CONFIRMADA")]:
    vistos["g"].add(av.global_({"decisao": a}, {"decisao": b}, {"decisao": d}))
print(json.dumps({k: sorted(v) for k, v in vistos.items()}, ensure_ascii=False))
esperado = {"a": {"LOCAL_CHM", "NAO_CHM", "LOCAL_DEFORMADO", "INCONCLUSIVO"}, "b": {"DUAL_EXATO", "FALHA"},
            "c": {"GAP_QUEBRA_CHM", "INDEFINIDO"}, "d": {"CONFIRMADA", "PARCIAL", "NAO_CONFIRMADA", "INCONCLUSIVO"},
            "g": {"APOIADA", "PARCIAL", "NAO_APOIADA", "INCONCLUSIVA"}}
assert all(vistos[k] == esperado[k] for k in esperado), "ramo não alcançado"
print("todos os ramos alcançados")
