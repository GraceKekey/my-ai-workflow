"""Tabelas, figuras e relatório da entrega; não altera a bancada congelada."""
from pathlib import Path
import json,hashlib,csv,datetime,zipfile,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent.parent
load=lambda name:json.loads((R/name).read_text())
meta=load('resultados/B31_config_completo.json');cfg=meta['config'];data=load('resultados/B31_checkpoint.json')['casos'];ev=load('resultados/avaliacao_B31.json')
expected={f'B31a|R={x}' for x in cfg['B31a']['R']}|{f'B31b|triangular_{x}' for x in cfg['B31b']['triangular_n']}|{f"B31b|rsa_{cfg['B31b']['rsa']['N']}_semente={s}" for s in cfg['B31b']['rsa']['sementes']}|{f"B31c|R={cfg['B31c']['R']}|m={m}" for m in cfg['B31c']['massas']}|{f"B31d|R={cfg['B31d']['R']}|Lt={Lt}" for Lt in cfg['B31d']['Lt']}
checks={'modo_completo':meta['modo']=='completo','chaves_exatamente_previstas':set(data)==expected}
for Lt in cfg['B31d']['Lt']:
 case=data[f"B31d|R={cfg['B31d']['R']}|Lt={Lt}"]
 checks[f'tempos_Lt_{Lt}']=[v['t'] for v in case['serie']]==cfg['B31d']['tempos']
 checks[f'taus_Lt_{Lt}']=all(all(f'tau={t:g}' in v for t in cfg['B31d']['taus']) for v in case['serie'])
for line in (R/'hashes_antes_da_execucao.txt').read_text().splitlines():
 if not line or line.startswith('#'):continue
 h,f=line.split(maxsplit=1);checks['hash:'+f]=hashlib.sha256((R/f).read_bytes()).hexdigest()==h
assert all(checks.values()),checks
(R/'VERIFICACAO_COBERTURA.json').write_text(json.dumps(checks,indent=2,ensure_ascii=False))
(R/'tabelas').mkdir(exist_ok=True);(R/'figuras').mkdir(exist_ok=True)
def table(name,rows):
 with (R/'tabelas'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
rows=[]
for key,c in data.items():
 if key.startswith(('B31a|','B31c|')):
  for cor,p in c['por_correlador'].items():
   for q,values in p['por_q'].items():
    for t in values['testes']:rows.append({'caso':key,'R_nominal':c['R_nominal'],'R_efetivo':c['R_efetivo'],'m':c['m'],'correlador':cor,'q':q,**t,'S':p['S'],'S2':p['S2'],'nu_min':p['nu_min'],'localidade_N_media':values['localidade_N_media_min'][0],'localidade_M_media':values['localidade_M_media_min'][0]})
table('B31a_c_todos_testes.csv',rows)
table('B31b_malhas.csv',[c for k,c in data.items() if k.startswith('B31b|')])
rows=[]
for key,c in data.items():
 if key.startswith('B31d|'):
  for line in c['serie']:
   base={k:v for k,v in line.items() if not isinstance(v,dict)}
   for tau,vals in line.items():
    if isinstance(vals,dict):rows.append({'caso':key,'Lt':c['Lt'],'tau':tau,**base,**vals})
table('B31d_series_completas.csv',rows)
# Suplementos a partir dos dados já calculados: as três polarizações, sem nova decisão.
dcheck={}
pols=('dS2_linear','dS2_circ_mais','dS2_circ_menos');taus=[f'tau={t:g}' for t in cfg['B31d']['taus']]
series=[data[f"B31d|R={cfg['B31d']['R']}|Lt={Lt}"]['serie'] for Lt in cfg['B31d']['Lt']]
dcheck['max_diferenca_tau_todas_polarizacoes']=max(abs(l[taus[0]][pol]-l[taus[1]][pol]) for ser in series for l in ser for pol in pols)
dcheck['max_diferenca_Lt_todas_polarizacoes']=max(abs(a[taus[0]][pol]-b[taus[0]][pol]) for a,b in zip(*series) for pol in pols)
dcheck['max_erro_Z']=max(abs(v[z]-1) for ser in series for l in ser for t,v in l.items() if t.startswith('tau=') for z in ('Z_linear','Z_circ_mais','Z_circ_menos'))
dcheck['max_erro_energia']=max(abs(l['E_total']/l['E_esperada']-1) for ser in series for l in ser)
(R/'CONTROLES_D_TODAS_POLARIZACOES.json').write_text(json.dumps(dcheck,indent=2))
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.2})
fig,ax=plt.subplots(2,2,figsize=(12,8))
a=ev['B31a']['por_R'];rs=[int(v) for v in a]
ax[0,0].plot(rs,[a[str(v)]['desvio_max'] for v in rs],'o-',label='Melhorado e momento (máximo)')
ax[0,0].plot(rs,[a[str(v)]['desvio_M_canonico'] for v in rs],'s--',label='M canônico')
ax[0,0].axhline(.05,color='gray',ls=':',label='Limite 5%');ax[0,0].set(title='A · Desvio em relação a CHM',xlabel='Raio nominal R',ylabel='Máximo |ρ − 1|');ax[0,0].legend(fontsize=8)
b=[c for k,c in data.items() if k.startswith('B31b|')]
ax[0,1].bar(range(len(b)),[max(c['dif_espectral_relativa'],1e-18) for c in b]);ax[0,1].set_yscale('log');ax[0,1].axhline(1e-9,color='gray',ls=':');ax[0,1].set_xticks(range(len(b)),['Triangular']+[f'Delaunay {i}' for i in range(1,len(b))],rotation=15);ax[0,1].set(title='B · Dualidade espectral',ylabel='Diferença relativa')
c=ev['B31c'];ax[1,0].plot(c['massas'],c['desvio_max_por_massa'],'o-');ax[1,0].set(title='C · Efeito da massa',xlabel='Massa m',ylabel='Máximo |ρ − 1|')
ser=series[0];ts=[l['t'] for l in ser]
for pol,label in zip(pols,('Linear','Circular +','Circular −')):ax[1,1].plot(ts,[l[taus[0]][pol] for l in ser],label=label,lw=1.6)
ax[1,1].plot(ts,[l['dS2_quasiparticula'] for l in ser],'k--',label='Quasipartícula',lw=1)
ax[1,1].plot(ts,[l['dS2_coerente'] for l in ser],':',color='gray',label='Coerente (construção)')
ax[1,1].axhline(np.log(2),ls=':',color='gray');ax[1,1].set(title='D · Ola de emaranhamento (Lt=1024)',xlabel='Tempo t',ylabel='ΔS₂');ax[1,1].legend(fontsize=8)
fig.tight_layout();fig.savefig(R/'figuras/B31_resumo.png',dpi=160);plt.close(fig)
fig,ax=plt.subplots(figsize=(8,4));ax.plot(ts,[l['p_E'] for l in ser],'o-');ax.axhline(.9,ls=':',color='gray');ax.set(xlabel='Tempo t',ylabel='Fração de energia p_E',title='D · Passagem do pacote pelo disco R=20');fig.tight_layout();fig.savefig(R/'figuras/B31_fracao_energia.png',dpi=160);plt.close(fig)
now=datetime.datetime.now(datetime.timezone.utc).isoformat()
lines=['# HRF B31 — relatório da execução completa','',f'Concluído em {now}.','',f"**H-par no modelo livre: {ev['global']}.**",'']
lines+=['| Bloco | Decisão congelada |','|---|---|']+[f"| B31{k} | {ev['B31'+k]['decisao']} |" for k in 'abcd']
lines+=['','## Objetivo','','Testar a hipótese paralela de GMFs emaranhados no modelo livre: Hamiltoniano modular de um disco, dualidade espectral, efeito da massa e uma partícula atravessando a região.','','## Hipóteses','','A: forma local CHM e aproximação ao limite contínuo. B: igualdade dos espectros não nulos e contagens dos modos nulos. C: a massa aumenta o desvio de CHM e reduz a entropia. D: excesso de Rényi-2 próximo da previsão de quasipartícula, pico perto de ln 2, passagem da ola e independência das helicidades.','','## Parâmetros','','```json',json.dumps(cfg,ensure_ascii=False,indent=2),'```','','## Protocolo','','Executado src/rodar_B31.py completo, seguido de src/avaliar_B31.py resultados, ambos com Python isolado (-I) e uma thread BLAS. Não houve alteração no código científico ou nas regras congeladas. Não se usaram os resultados de fumaça na decisão. O ZIP de entrada e a fumaça recebida foram preservados. O teste sintético do avaliador alcançou todos os ramos; não é evidência física.','','Versões e máquina da execução:','','```json',json.dumps({k:v for k,v in meta.items() if k!='config'},indent=2,ensure_ascii=False),'```','','## Medidas e resultados','','### B31a — modular','','| R | Desvio máximo | Desvio canônico | Localidade N | ΔL | Δq |','|---|---:|---:|---:|---:|---:|']
for rr,v in a.items():lines.append(f"| {rr} | {v['desvio_max']:.9g} | {v['desvio_M_canonico']:.9g} | {v['localidade_N_media']:.9g} | {v['dif_L']:.9g} | {v['dif_q']:.9g} |")
lines+=['','### B31b — dualidade','','| Malha | Diferença espectral | Nulos Z / gauge / previstos |','|---|---:|---|']
for v in ev['B31b']['malhas']:lines.append(f"| {v['malha']} | {v['dif']:.9g} | {v['nulos']} |")
lines+=['','### B31c — massa','','| m | Desvio máximo | S |','|---|---:|---:|']
for m,d,S in zip(c['massas'],c['desvio_max_por_massa'],c['S_por_massa']):lines.append(f'| {m} | {d:.9g} | {S:.9g} |')
lines+=['','### B31d — passagem do quantum','','```json',json.dumps(ev['B31d'],ensure_ascii=False,indent=2),'```','','## Controles','','A cobertura exata dos 13 casos foi conferida: A=3, B=4, C=4, D=2. Cada caso D contém os 36 instantes e ambos os cortes. Os oito hashes do código e protocolo continuam iguais aos do pré-registro. A tabela de D preserva todas as polarizações e os controles.','','Avaliação completa:','','```json',json.dumps(ev,ensure_ascii=False,indent=2),'```','','Controles suplementares calculados das três polarizações (não alteram a decisão):','','```json',json.dumps(dcheck,indent=2),'```','','## Interpretação','']
for block in 'ad':
 fail=ev['B31'+block]['falhas_validade']
 if fail:lines.append(f"B31{block}: validade numérica não aprovada: {'; '.join(fail)}. A classificação inconclusiva não constitui refutação física.")
if ev['global']=='APOIADA':lines.append('Os critérios congelados apoiam H-par neste modelo de campo livre. Esta conclusão se limita à bancada e aos controles pré-registrados.')
else:lines.append('A conclusão segue os critérios congelados, sem ajustar limites ou selecionar casos após conhecer os resultados. A classificação global não pode ser extrapolada para uma teoria holográfica completa.')
lines+=['','### Auditoria adicional e limites','','Em B31d o código congela os autovalores de Williamson por ν² → max(ν², 1/4). Por isso, o nu_min gravado não é uma verificação independente do limite inferior antes desse ajuste. A auditoria suplementar recalculou os dois mínimos brutos, sem modificar a bancada, e confrontou a fórmula de Rényi-2 com matrizes de Fock de um modo em três ocupações térmicas. Resultados:','','```json',json.dumps(load('AUDITORIA_SUPLEMENTAR.json'),ensure_ascii=False,indent=2),'```','','A onda coerente tem ΔS₂=0 por construção; não é uma evolução independente calculada do estado coerente. As duas polarizações são cópias iguais do campo fora do plano, como definido no protocolo; não constituem uma simulação completa da polarização de gauge nas ligações. É um campo livre não compacto, sem vórtices; não demonstra reconstrução holográfica do bulk, regime de N grande ou acoplamento forte. B31d mede Rényi-2, e a precisão é dupla.','','## Reprodução e arquivos','','Código e protocolo completos em src/ e no protocolo original. Instale requirements_execucao.txt em Python compatível; execute com OPENBLAS_NUM_THREADS=1, OMP_NUM_THREADS=1 e MKL_NUM_THREADS=1. Para reprodução integral sem reutilizar checkpoints, copie src/ e o protocolo para outra pasta e rode os dois comandos do LEIAME_B31.md. Os resultados estão em resultados/, as tabelas em tabelas/ e as figuras em figuras/. MANIFEST_SHA256_ENTREGA.json permite conferir todos os arquivos incluídos.']
(R/'RELATORIO_CIENTIFICO_B31.md').write_text('\n'.join(lines)+'\n')
(R/'LEIA_PRIMEIRO_RESULTADOS.md').write_text('# B31 — resultados completos\n\nLeia RELATORIO_CIENTIFICO_B31.md e resultados/avaliacao_B31.json.\n\nHá código, protocolo, ZIP original, dados, logs, tabelas, figuras, verificações de integridade e auditoria suplementar. Os arquivos de fumaca/ não participam da avaliação completa.\n')
(R/'requirements_execucao.txt').write_text(f"numpy=={meta['numpy']}\nscipy=={meta['scipy']}\nmatplotlib=={matplotlib.__version__}\n")
(R/'PROVENIENCIA_CONCLUSAO.json').write_text(json.dumps({'utc':now,'python':meta['python'],'numpy':meta['numpy'],'scipy':meta['scipy'],'matplotlib':matplotlib.__version__,'resultado':ev['global'],'codigo_congelado_inalterado':True},ensure_ascii=False,indent=2))
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256_ENTREGA.json']
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(R/'MANIFEST_SHA256_ENTREGA.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
archive=R.parent.parent/'HRF_B31_RESULTADOS_COMPLETOS_2026-10-20.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[R/'MANIFEST_SHA256_ENTREGA.json']):z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(f'{R.name}/{name}')).hexdigest()==h
shutil.copy2(R/'RELATORIO_CIENTIFICO_B31.md',R.parent.parent/'HRF_B31_RELATORIO_2026-10-20.md')
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'resultado':ev['global'],'arquivos':len(files)+1},indent=2,ensure_ascii=False))
