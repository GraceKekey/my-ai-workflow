"""Conferências suplementares, sem alterar código, dados ou decisões congeladas."""
from pathlib import Path
import sys,json,numpy as np
from scipy.linalg import eigh
R=Path(__file__).resolve().parent.parent;sys.path.insert(0,str(R/'src'))
import b31_rede as rd
from b31d_ola import renyi2
out={'nota':'Suplemento; não altera a classificação do avaliador congelado.','nu_bruto_B31d':{},'um_modo':[]}
idx=rd.disco(20)
for Lt in (1024,2048):
 Xg,Pg=rd.correladores(Lt,0.0);X=rd.bloco(Xg,idx,Lt);P=rd.bloco(Pg,idx,Lt)
 ex,U=eigh(X);Xh=(U*np.sqrt(ex))@U.T;C=Xh@P@Xh
 w=eigh((C+C.T)*.5,eigvals_only=True)
 out['nu_bruto_B31d'][str(Lt)]={'nu_min_antes_do_clipping':float(np.sqrt(w.min())),'nu2_min':float(w.min()),'passa_limite_protocolo':bool(np.sqrt(w.min())>=.5-1e-9)}
for n in (.2,1.,3.):
 D=180;r=n/(n+1);rho0=np.diag((1-r)*r**np.arange(D));ann=np.diag(np.sqrt(np.arange(1,D)),1)
 u=.6+.2j;v=-.3+.1j;c=.25;p=u*(n+1);q=-v*n
 rest=abs(p)**2*n*n/(n+1)+abs(q)**2*(n+1)**2/n
 calc,Z,_,_=renyi2([np.array([p])],[np.array([q])],np.array([n]),1e-12,c+rest)
 O=u*ann.T+v*ann;rho=O@rho0@O.conj().T+c*rho0;rho/=np.trace(rho)
 exact=float(-np.log(np.trace(rho@rho).real/np.trace(rho0@rho0).real))
 out['um_modo'].append({'n':n,'fock_dim':D,'renyi2_formula':calc,'renyi2_fock':exact,'diferenca':abs(calc-exact)})
assert all(v['passa_limite_protocolo'] for v in out['nu_bruto_B31d'].values())
assert max(v['diferenca'] for v in out['um_modo'])<1e-12
(R/'AUDITORIA_SUPLEMENTAR.json').write_text(json.dumps(out,indent=2));print(json.dumps(out,indent=2))
