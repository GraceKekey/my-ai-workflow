# HRF B31 — A ola de emaranhamento na fronteira
## Hamiltoniano modular de um pedaço da fronteira, dualidade e um quantum que levanta a arquibancada
## Protocolo pré-registrado

**Data:** 19 de outubro de 2026, 23h45 (America/Sao_Paulo) — Claude (`-clau`) · fluxo ímpar
**Autoria:** Mario José do Canto Filho, MD · redação: Claude
**Autorização para registrar:** Mario, 23h27 ("registrar tudo do B31 com os blocos A, B, C e D").
**Execução:** só depois de "pode rodar". Protocolo, código e hashes ficam congelados antes da rodada completa.
**Antecedentes:** E-65 (primeiro teste da leitura (b): campo Z nos GMFs do tapete, vácuo quântico, Ryu–Takayanagi);
nota `HRF_Nota_Progresso_Dualidade_Relata_Primarios_PT_2026-10-19_2300-clau.md`; conversa de 19/10 (23h04–23h27).

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 1. Objetivo

Testar, num modelo de campo livre na fronteira, a **hipótese paralela de Mario (H-par)**:

> O sistema fundamental é o GMF (uma célula da fronteira) emaranhado com o resto da fronteira. O hamiltoniano "fecha"
> entre o pedaço e o resto. As excitações são como uma ola num estádio, e a "altura" de cada pessoa é a força do
> emaranhamento da sua célula com o resto.

| Bloco | Pergunta |
|---|---|
| **B31a** | O hamiltoniano que liga um disco de GMFs ao resto (hamiltoniano modular, ρ_A = e^(−K_A)) é local e tem a forma de Casini–Huerta–Myers (CHM)? |
| **B31b** | A ola nos GMFs é exatamente dual a um campo de gauge na espuma de Voronoi, com a bolha de cada GMF como laço? |
| **B31c** | Uma "mola própria" em cada GMF (massa m, o gap) destrói a forma CHM? |
| **B31d** | Um único quantum, em polarização circular, atravessando o disco levanta e abaixa o emaranhamento como uma ola, até ln 2? Uma onda clássica não levanta? |

## 2. Hipóteses e previsões (escritas antes)

**Modelo [M].** Tapete triangular intacto da E-65 (a = 1), campo Z nos GMFs:
H = Σ P_i²/(2A) + ½ Σ_e w (Z_i − Z_j)² + ½ Σ m² A Z_i², com w = 1/√3, A = √3/2, c = 1. Vácuo gaussiano no plano infinito.

**B31a [F na continuidade; M na rede].** Para um disco numa CFT, K = 2π ∫ β(r) T₀₀, β = (R² − r²)/(2R) (CHM 2011). O escalar
sem massa em 2+1D é conforme com o tensor melhorado (ξ = 1/8). Previsão: as formas quadráticas de K em campos de teste
suaves batem com CHM a ≤ 5% no maior disco; o núcleo de momento N é quase diagonal (local). Previsão secundária:
a versão melhorada fica mais perto de 1 que a canônica.

**B31b [F].** Os espectros não nulos dos dois lados coincidem exatamente em qualquer malha (identidade algébrica);
modos nulos: 1 do lado Z e F + 1 do lado gauge no toro (F = número de triângulos).

**B31c [F].** Com massa, o hamiltoniano modular deixa de ser o CHM: o desvio cresce com mR. A entropia do disco cai
com m.

**B31d [F, quadro de quasipartículas; M na rede].** Para |ψ⟩ = a†(f)|0⟩ com o pacote dividido entre dentro (fração p)
e fora do disco, ΔS₂ ≈ −log(p² + (1 − p)²): máximo ln 2 em p = ½, volta a ~0 quando o quantum está todo dentro ou todo
fora. Uma onda clássica (estado coerente) não muda o emaranhamento (operações locais). Polarização circular e linear
dão o mesmo ΔS₂ no quadro de quasipartículas; o sinal da helicidade não importa.

## 3. Parâmetros

**B31a.**
- Discos centrados num GMF, R ∈ {8, 12, 16} (931 GMFs no maior). Raio efetivo pela área: R_ef = √(N·A/π).
- Correladores de vácuo do plano infinito por FFT num toro Lt × Lt, com extrapolação de Richardson em 1/Lt:
  principal L = 1024 (1024/2048), controle L = 512 (512/1024).
- Hamiltoniano modular pela decomposição de Williamson: M = X^(−½) W diag(νε) Wᵀ X^(−½), N = X^(½) W diag(ε/ν) Wᵀ X^(½).
  Modos com ν − ½ < 10^(−q) são cortados (limite da precisão dupla): decisão com q = 13, controle q = 12.
- Campos de teste: gaussianas de largura σ = 0,3 R_ef, centradas em s·R_ef (s = 0; 0,15; 0,3), nas direções 0° e 90°,
  multiplicadas por uma janela que vai a zero entre 0,7 e 0,9 R_ef.
- Previsões CHM em rede: ⟨g, M g⟩ = 2π Σ_e β_e w (g_i − g_j)² + (π/R) Σ A g_i² (melhorado; sem o último termo:
  canônico); ⟨h, N h⟩ = 2π Σ β_i h_i²/A.

**B31b.** Toros: rede triangular 24 × 24 (576 GMFs) e Delaunay periódica de 600 pontos com núcleo duro d_min = 0,8,
densidade 0,9, sementes 20263101, 20263102, 20263103. Pesos cotangentes w_e; áreas de Voronoi A_i; lado gauge com
μ_i = A_i e 1/m_e = w_e.

**B31c.** R = 12, m ∈ {0; 0,1; 0,2; 0,4} (mR = 0 a 4,8), L = 1024, q = 13; previsão CHM com o termo de massa
2π Σ β_i m² A g_i².

**B31d.**
- Disco R = 20 (1 459 GMFs); toros Lt = 1024 (decisão) e 2048 (controle).
- Pacote gaussiano em k: k₀ = (0,8; 0), Δk = k₀/6 (largura ~3,75 a), centro inicial x = −35, t = 0, 2, …, 70.
- **Onda injetada em saca-rolha (regra do projeto):** dois campos de polarização iguais nos GMFs; quantum em
  polarização circular, a†_circ = (a†_y ± i a†_z)/√2, com as duas helicidades. Polarização linear como referência.
- Rényi-2 exata do estado de uma partícula (fórmula fechada, seção 4); corte de modos puros τ = 10⁻¹⁰ (decisão) e
  10⁻¹² (controle).
- Fração p_E(t) = energia em excesso dentro do disco / energia total do quantum.

## 4. Protocolo

1. `python -I src/rodar_B31.py completo` (checkpoint atômico por caso; relançar retoma).
2. `python -I src/avaliar_B31.py resultados` → `resultados/avaliacao_B31.json`.
3. Relatório na ordem Objetivo → Hipóteses → Parâmetros → Protocolo → Medidas → Resultados → Controles → Interpretação.

**Rényi-2 do estado de uma partícula (B31d).** Para estado puro gaussiano e L = L_A + L_Ā linear, sem usar o
complemento explicitamente: |ψ⟩ = O_A|Ω⟩ + |χ⟩, com O_A = Σ_k [p_k/(n_k+1) b_k† − (q_k/n_k) b_k] nos modos de
Williamson de A, e |χ⟩ a parte do pacote em modos de Ā não emaranhados com A. Então ρ_A = O ρ⁰ O† + c ρ⁰ e
Tr ρ_A²/Tr ρ⁰² = [a₁₂² + 4|Σ u v s|² + b² + 2cb + c²]/Z², com s = 1/(2 senh ε), b = Σ(|u|² + |v|²)s,
a₁₂ = Σ|u|²(m₂+1) + |v|²m₂, m₂ = 1/(e^(2ε) − 1), Z = Σ|u|²(n+1) + |v|²n + c. O código confere Z = 1 em cada instante
e a fórmula contra o caso exato de um modo.

## 5. Medidas

- **B31a:** razões ρ_M (melhorada e canônica) e ρ_N por campo de teste; localidade (fração do peso de cada linha de N e
  M no próprio GMF e nos 6 vizinhos, para r ≤ 0,6 R); perfil da diagonal de N contra β(r); entropias S e S₂ do disco;
  modos cortados.
- **B31b:** diferença espectral relativa, modos nulos, Euler, soma das áreas, energia de ponto zero dos dois lados.
- **B31c:** desvio máximo |ρ − 1| por massa; S(m).
- **B31d:** ΔS₂(t) linear, circular + e circular −; previsão de quasipartícula; p_E(t); Z(t); controle coerente
  (ΔS₂ = 0 por construção).

## 6. Regras de decisão (congeladas; `src/avaliar_B31.py`)

**B31a.** Validade: |Δρ| entre L = 1024 e 512 ≤ 10⁻³; |Δρ| entre q = 13 e 12 ≤ 0,01; ν_min ≥ ½ − 10⁻⁹.
Desvio = max |ρ − 1| sobre ρ_M melhorado e ρ_N, em todos os campos de teste.
- **INCONCLUSIVO** se a validade falha;
- **NÃO_CHM** se em R = 16 alguma razão sai de [0,8; 1,2] ou a localidade média de N < 0,80;
- **LOCAL_CHM** se em R = 16 o desvio ≤ 0,05, o desvio em R = 16 ≤ o de R = 8, e a localidade média de N ≥ 0,95;
- **LOCAL_DEFORMADO** nos outros casos.

**B31b.** **DUAL_EXATO** se, em todas as malhas: diferença espectral ≤ 10⁻⁹, 1 modo nulo do lado Z, F + 1 do lado gauge,
|ΣA/área − 1| ≤ 10⁻¹⁰, pesos > 0 e Euler = 0. Senão **FALHA** (indica erro de código).

**B31c.** **GAP_QUEBRA_CHM** se o desvio cresce estritamente com m e o desvio em m = 0,4 ≥ max(2 × desvio em m = 0; 0,05).
Senão **INDEFINIDO**. Relato: S decresce com m.

**B31d.** Validade: |Z − 1| ≤ 10⁻⁸ (todas as polarizações e τ); |ΔS₂(τ₁) − ΔS₂(τ₂)| ≤ 10⁻⁶; energia total = Σ|f|²ω a
10⁻⁸; |ΔS₂(Lt 1024) − ΔS₂(Lt 2048)| ≤ 10⁻³; ν_min ≥ ½ − 10⁻⁹.
- D1: no instante de p_E máximo (se ≥ 0,9), ΔS₂ ≤ ½ ln 2 (a ola passa; não fica alta);
- D2: max ΔS₂ ∈ [0,85; 1,15]·ln 2, com p_E ∈ [0,3; 0,7] nesse instante;
- D3: max |ΔS₂ − ΔS₂(quasipartícula)| ≤ 0,10;
- D4: max |ΔS₂(circular) − ΔS₂(linear)| ≤ 0,02;
- D6: |ΔS₂(+) − ΔS₂(−)| ≤ 10⁻¹⁰.
Decisões: **INCONCLUSIVO** se a validade falha; **NÃO_CONFIRMADA** se D2 falha; **CONFIRMADA** se D1 (avaliável),
D3, D4 e D6 passam; **PARCIAL** nos outros casos.

**Global (H-par no modelo livre):** **INCONCLUSIVA** se B31a ou B31d forem INCONCLUSIVO ou B31b = FALHA;
**NÃO APOIADA** se B31a = NÃO_CHM ou B31d = NÃO_CONFIRMADA; **APOIADA** se B31a = LOCAL_CHM, B31b = DUAL_EXATO e
B31d = CONFIRMADA; **PARCIAL** nos outros casos. A B31c é relatada à parte (variante com gap).

## 7. Fumaça (não vale como resultado)

`python -I src/rodar_B31.py fumaca` (23h43, 2 s), tamanhos fora do conjunto de decisão:
- B31a em R = 5 e 6 (L = 256/128): razões a ≤ 0,4% de 1 com o tensor melhorado (canônico ~12% acima); localidade de N
  0,998; cortes q = 12 e 13 diferem ≤ 4×10⁻⁴. Os toros pequenos da fumaça falham a validade de Lt (2–3×10⁻³);
  na escala de Lt a diferença cai ~8× por duplicação (5×10⁻⁵ entre 512 e 1024 em R = 5–6), dentro do limite.
- B31b: identidade exata (10⁻¹⁵) na rede triangular 8 × 8 e numa Delaunay de 60 pontos; modos nulos 1 e F + 1.
- B31c (R = 5, m = 0 e 0,2): desvio sobe de 0,004 para 0,26; S cai.
- B31d (R = 6, Lt 256/512): Z = 1 a 10⁻¹⁰; ΔS₂ máximo 0,691 (0,996 ln 2) em p_E = 0,53; diferença para a
  quasipartícula ≤ 0,013; circular − linear ≤ 5×10⁻⁴; D1 não avaliável (disco pequeno demais para o quantum caber).
- Fórmula de Rényi-2 conferida contra o caso exato de um modo (igual a 10⁻¹⁶).
- `src/teste_avaliador_sintetico_B31.py`: todos os ramos das regras alcançados.

Custo estimado da rodada completa: menos de 10 minutos.

## 8. Limites declarados

- Campo livre: não é uma fronteira holográfica de verdade (falta N grande e acoplamento forte; o halo da E-65). A B31
  testa o que um campo livre pode dizer sobre H-par, não a reconstrução do bulk.
- Uma polarização "fora do plano" e uma cópia dela fazem as vezes das duas polarizações; a polarização no plano, com a
  sua estrutura de gauge nas ligações (e os modos de borda de Casini–Huerta–Rosabal), fica para depois.
- Z não compacto: sem vórtices e sem o gap de Polyakov.
- O emaranhamento medido é Rényi-2 (B31d) e von Neumann/Rényi-2 do disco (B31a/c).
- Precisão dupla: modos quase puros (ν − ½ < 10⁻¹³) são cortados; as regras exigem insensibilidade ao corte.

## 9. Arquivos

`src/b31_rede.py`, `src/b31a_modular.py`, `src/b31b_dualidade.py`, `src/b31d_ola.py`, `src/rodar_B31.py`,
`src/avaliar_B31.py`, `src/teste_avaliador_sintetico_B31.py`, `fumaca/`, `hashes_antes_da_execucao.txt`.

## Referências

- H. Casini, M. Huerta, R. C. Myers, JHEP 05 (2011) 036 (CHM).
- J. J. Bisognano, E. H. Wichmann, J. Math. Phys. 16, 985 (1975).
- H. Casini, M. Huerta, J. Phys. A 42, 504007 (2009) (entropia em teorias livres; núcleos gaussianos).
- M. Nozaki, T. Numasawa, T. Takayanagi, Phys. Rev. Lett. 112, 111602 (2014).
- P. Calabrese, J. Cardy, J. Stat. Mech. (2005) P04010.
- O. A. Castro-Alvaredo, C. De Fazio, B. Doyon, I. M. Szécsényi, Phys. Rev. Lett. 121, 170602 (2018).
- T. Faulkner, M. Guica, T. Hartman, R. C. Myers, M. Van Raamsdonk, JHEP 03 (2014) 051.
- H. Casini, M. Huerta, J. A. Rosabal, Phys. Rev. D 89, 085012 (2014).
