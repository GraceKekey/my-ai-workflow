# HRF B31 — A ola de emaranhamento na fronteira (pré-registro)

**Estado:** pré-registrado em 19/10/2026, 23h45. **Não executado.** Rodar só depois de "pode rodar".

## O que é
Teste da hipótese paralela de Mario (H-par): o GMF é uma célula da fronteira emaranhada com o resto; o hamiltoniano
"fecha" entre o pedaço e o resto; as excitações são uma ola em que a "altura" é a força do emaranhamento.
Quatro blocos: (a) hamiltoniano modular de um disco contra a forma CHM; (b) dualidade exata ola ↔ gauge na espuma;
(c) efeito da "mola própria" (massa); (d) um quantum em saca-rolha atravessando o disco: ΔS₂ sobe até ln 2 e volta.

## Como rodar
```bash
cd HRF_B31_Ola_Emaranhamento
sed -n '4,20p' hashes_antes_da_execucao.txt | sha256sum -c -   # integridade
python -I src/rodar_B31.py completo > resultados_log.txt 2>&1
python -I src/avaliar_B31.py resultados
```
Custo estimado: menos de 10 minutos em 2 núcleos. Checkpoint atômico em `resultados/B31_checkpoint.json`.

## Arquivos
- `HRF_B31_PROTOCOLO_2026-10-19_2345-clau.md` — protocolo (objetivo, hipóteses, parâmetros, regras congeladas).
- `src/` — código; `fumaca/` — rodada de fumaça e avaliação (não valem como resultado).
- `FUMACA_B31.md` — resumo da fumaça.
- `hashes_antes_da_execucao.txt` — SHA-256 de código e protocolo antes da rodada.
