# HRF B31 — Fumaça (19/10/2026, 23h43; não vale como resultado)

Tamanhos fora do conjunto de decisão. Decisões do avaliador na fumaça (esperadas: B31a INCONCLUSIVO por toros pequenos; B31d PARCIAL porque D1 não é avaliável em R = 6):

- B31a: INCONCLUSIVO
- B31b: DUAL_EXATO
- B31c: GAP_QUEBRA_CHM
- B31d: PARCIAL

## B31a (R = 5, 6; L = 256/128)

- R = 5 (R_ef = 5.009): desvio máx (melhorado) = 0.0040; canônico = 0.1226; localidade N = 0.9987; |Δ L| = 2.1e-03; |Δ q| = 2.4e-04
- R = 6 (R_ef = 5.917): desvio máx (melhorado) = 0.0035; canônico = 0.1200; localidade N = 0.9982; |Δ L| = 3.3e-03; |Δ q| = 4.3e-04

Convergência em Lt (R = 5–6, fora da decisão): |Δρ| = 2–3×10⁻³ (128/256), 3–5×10⁻⁴ (256/512), 3–6×10⁻⁵ (512/1024).

## B31b

- triangular_8: dif = 1.2e-15; nulos Z / gauge / previstos = [1, 129, 129]
- rsa_60_20263101: dif = 1.2e-15; nulos Z / gauge / previstos = [1, 121, 121]

## B31c (R = 5)

- massas [0.0, 0.2]: desvio [0.004, 0.2567]; S [2.4591, 2.0259]

## B31d (R = 6; Lt 256/512)

- validade: True; |Δ Lt| = 6.8e-05
- D1 avaliável: False (p_E máx = 0.573)
- D2: ΔS₂ máx = 0.6905 = 0.9962 ln 2, em p_E = 0.526
- D3: max |ΔS₂ − quasipartícula| = 0.0125
- D4: max |circular − linear| = 4.5e-04
- D6: max |+ − −| = 0.0e+00

Conferência da fórmula de Rényi-2 contra o caso exato de um modo: igual a 10⁻¹⁶.
Teste sintético do avaliador: todos os ramos alcançados (`src/teste_avaliador_sintetico_B31.py`).
