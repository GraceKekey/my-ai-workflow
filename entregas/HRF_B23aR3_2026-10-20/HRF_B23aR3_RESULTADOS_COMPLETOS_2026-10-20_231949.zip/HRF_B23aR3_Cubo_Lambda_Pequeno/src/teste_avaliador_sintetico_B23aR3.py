"""Dados fabricados, não físicos. Exercita ramos e precedência das regras congeladas."""
from pathlib import Path
import sys,json,copy
sys.path.insert(0,str(Path(__file__).resolve().parent))
from rodar_B23aR3 import chave,especificacoes
from avaliar_B23aR3 import avaliar
ROOT=Path(__file__).resolve().parent.parent
ref=json.loads((ROOT/'referencias/B23R2_cubo.json').read_text())
def base():
 out={}
 for nome,S,l,m in especificacoes('completo'):
  j=1+(ref['casos']['0.05']['razao_dJ']-1)*(l/.05)**2
  k=1+(ref['casos']['0.05']['razao_anel_media']-1)*(l/.05)**2
  out[chave(nome,S,l,m)]={'razao_dJ':j,'razao_anel_media':k,'razao_anel_min':k-1e-5,'razao_anel_max':k+1e-5,'residuo_real':1e-14,'g_min_sobreposicao':.99,'gap_sobre_2V':.95,'faces':{str(i):{'frustrado':False,'movimentos':2} for i in range(6)}}
 return out
seen=set()
def test(label,cases,expected):
 out=avaliar(cases,ref);assert out['decisao']==expected,(label,out);seen.add(out['decisao']);print(label,'->',out['decisao']);return out
b=base();test('convergência quadrática válida',b,'A3_FECHADO')
x=copy.deepcopy(b);x[chave('cubo',1,.025,'lobpcg')]['residuo_real']=2e-10;test('V0 inclui segundo método',x,'INCONCLUSIVO')
x=copy.deepcopy(b);x[chave('cubo',1,.05)]['razao_dJ']+=1e-6;test('V1 recertificação',x,'INCONCLUSIVO')
x=copy.deepcopy(b);x[chave('cubo',1,.025,'lobpcg')]['razao_anel_media']+=1e-5;test('V2 precisão relativa ao desvio',x,'INCONCLUSIVO')
x=copy.deepcopy(b);x[chave('cubo',1,.07)]['faces']['5']['movimentos']=0;test('V3 todas as seis faces',x,'INCONCLUSIVO')
x=copy.deepcopy(b);x[chave('cubo',1,.07)]['razao_dJ']=1.3;test('razão grosseiramente fora',x,'NAO_EMERGE')
x=copy.deepcopy(b)
for k in x:
 if k.startswith('cubo|'):x[k]['razao_dJ']=ref['casos']['0.05']['razao_dJ']
test('A2 passa e ordem elétrica zero',x,'A3_FALHA')
x=copy.deepcopy(b);x[chave('cubo',1,.035)]['razao_anel_media']=.995;test('razão próxima mas A2 não passa',x,'PARCIAL')
x=copy.deepcopy(b);x.pop(chave('plaqueta',1,.07));test('checkpoint incompleto',x,'INCONCLUSIVO')
x=copy.deepcopy(b);x[chave('plaqueta',1,.07)]['razao_dJ']=100.;test('plaqueta não altera decisão do cubo',x,'A3_FECHADO')
x=copy.deepcopy(b)
for v in x.values():v['residuo_real']=1e-10;v['g_min_sobreposicao']=.5;v['gap_sobre_2V']=.5
test('limites V0 inclusivos',x,'A3_FECHADO')
x=copy.deepcopy(b);x[chave('cubo',1,.035)]['razao_dJ']=1.
test('log de zero não recebe epsilon',x,'A3_FALHA')
assert seen=={'INCONCLUSIVO','NAO_EMERGE','A3_FECHADO','A3_FALHA','PARCIAL'}
print('Todos os cinco ramos alcançados; testes sintéticos sem valor físico.')
