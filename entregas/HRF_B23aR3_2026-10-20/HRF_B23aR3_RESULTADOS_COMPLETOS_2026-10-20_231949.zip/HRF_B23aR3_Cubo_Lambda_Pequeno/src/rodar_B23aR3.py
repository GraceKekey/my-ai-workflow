"""B23a-R3: somente orquestra o código B23-R2 intacto. completo exige autorização humana prévia."""
from pathlib import Path
import os,sys,json,time,platform,hashlib,datetime
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
ROOT=Path(__file__).resolve().parent.parent
sys.path.insert(0,str(ROOT/'src'))
FONTES={'b23_modelo.py':'eaa1e7493fb0e142bea048c2fd164cf40c383941a8086ba84cbe11ae7a2d2cec','b23ar2_emergencia.py':'c5af7a5fa35cd7afa6c91391e373213398f44940128480ec1852e0b7cb661ce2'}
LAMBDAS=(.07,.05,.035,.025)
def chave(nome,S,lam,metodo='chebyshev'):return f'{nome}|S={S}|lambda={lam:g}|metodo={metodo}'
def especificacoes(modo):
 if modo=='fumaca':return [('cubo',1,.1,'chebyshev')]+[(n,1,l,'chebyshev') for n in ('plaqueta','faixa') for l in LAMBDAS]
 if modo=='completo':return [('cubo',1,l,'chebyshev') for l in LAMBDAS]+[('plaqueta',1,l,'chebyshev') for l in LAMBDAS]+[('cubo',1,.025,'lobpcg')]
 raise ValueError('modo deve ser fumaca ou completo')
def atomico(p,d):
 tmp=p.with_suffix(p.suffix+'.tmp')
 with tmp.open('w') as f:json.dump(d,f,ensure_ascii=False,indent=2,allow_nan=False);f.flush();os.fsync(f.fileno())
 os.replace(tmp,p)
def main():
 modo=sys.argv[1];spec=especificacoes(modo)
 for f,h in FONTES.items():
  if hashlib.sha256((ROOT/'src'/f).read_bytes()).hexdigest()!=h:raise RuntimeError('Fonte congelada alterada: '+f)
 import numpy as np
 import scipy
 import b23ar2_emergencia as A
 pasta=ROOT/('fumaca' if modo=='fumaca' else 'resultados');pasta.mkdir(exist_ok=True)
 parametros={'modo':modo,'V':1.,'casos':[{'nome':n,'S':s,'lambda':l,'metodo':m} for n,s,l,m in spec],'fontes_sha256':FONTES}
 path=pasta/'B23aR3_checkpoint.json'
 cad=json.loads(path.read_text()) if path.exists() else {'parametros':parametros,'casos':{}}
 if cad['parametros']!=parametros:raise RuntimeError('Checkpoint incompatível; não será alterado.')
 if set(cad['casos'])-{chave(*s) for s in spec}:raise RuntimeError('Checkpoint contém casos não previstos.')
 meta_path=pasta/f'B23aR3_config_{modo}.json'
 meta=json.loads(meta_path.read_text()) if meta_path.exists() else {'parametros':parametros,'tentativas':[]}
 if meta['parametros']!=parametros:raise RuntimeError('Configuração incompatível.')
 tentativa={'inicio_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inicio_local':time.strftime('%Y-%m-%d %H:%M:%S %z'),'python':platform.python_version(),'numpy':np.__version__,'scipy':scipy.__version__,'maquina':platform.platform(),'blas_threads':1}
 meta['tentativas'].append(tentativa);atomico(meta_path,meta);inicio=time.monotonic()
 print(f'B23a-R3 modo={modo}; casos={len(spec)}',flush=True)
 for nome,S,lam,metodo in spec:
  k=chave(nome,S,lam,metodo)
  if k not in cad['casos']:
   print('iniciando '+k,flush=True)
   cad['casos'][k]=A.caso(nome,S,lam,metodo=metodo,V=1.)
   atomico(path,cad)
  r=cad['casos'][k]
  print(f"gravado {k}: dJ={r['razao_dJ']:.16g} anel={r['razao_anel_media']:.16g} residuo={r['residuo_real']:.3g} segundos={r['segundos']}",flush=True)
 tentativa['fim_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat();tentativa['segundos_tentativa']=time.monotonic()-inicio;tentativa['concluido']=True;atomico(meta_path,meta)
 print('fim '+modo,flush=True)
if __name__=='__main__':main()
