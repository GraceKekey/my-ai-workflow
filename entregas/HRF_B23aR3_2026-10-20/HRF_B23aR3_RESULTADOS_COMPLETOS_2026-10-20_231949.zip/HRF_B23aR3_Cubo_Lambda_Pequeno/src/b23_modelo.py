# -*- coding: utf-8 -*-
"""
HRF B23 — Levin–Wen → conexão U(1) + energia de Wilson do HRF (rede regular)
Módulo comum: complexos (GMFs, ligações, laços), operadores de spin S nas ligações, Hamiltoniano microscópico
sem invariância de gauge, Hamiltoniano efetivo de des Cloizeaux e previsões de teoria de perturbação.

Convenção de Levin–Wen (eq. 7 de cond-mat/0407140): ligações orientadas do vértice par para o ímpar, de modo que
Q_I = (−1)^I Σ_pernas S^z vira a divergência assinada d0ᵀ S^z e o anel B_p = S⁺S⁻S⁺S⁻ vira e^{i(d1 a)_p}.
Dicionário com o HRF: S^z_e ↔ campo elétrico Π_e (momento conjugado da fase a_e); S⁺/√(S(S+1)) ↔ U_e = e^{ia_e}.
"""
from __future__ import annotations

import itertools
import math
from dataclasses import dataclass, field

import numpy as np
import scipy.linalg as sl
import scipy.sparse as sp
import scipy.sparse.linalg as spl


# ============================================================================ complexos
@dataclass
class Complexo:
    nome: str
    N: int                                   # vértices (GMFs)
    arestas: list                            # (cauda, cabeça)
    faces: list                              # lista de listas [(aresta, sinal ±1), ...] percorrendo o laço
    d0: np.ndarray = field(init=False)       # E × N: −1 na cauda, +1 na cabeça (convenção do HRF)
    d1: np.ndarray = field(init=False)       # F × E

    def __post_init__(self):
        E, F = len(self.arestas), len(self.faces)
        self.d0 = np.zeros((E, self.N), int)
        for k, (a, b) in enumerate(self.arestas):
            self.d0[k, a] -= 1
            self.d0[k, b] += 1
        self.d1 = np.zeros((F, E), int)
        for f, ciclo in enumerate(self.faces):
            for e, s in ciclo:
                self.d1[f, e] += s
        assert not np.any(self.d1 @ self.d0), "d1 d0 ≠ 0: laços inconsistentes"

    @property
    def E(self):
        return len(self.arestas)

    @property
    def F(self):
        return len(self.faces)


def _faces_de_ciclos(arestas, ciclos):
    """Converte ciclos de vértices em listas (aresta, sinal)."""
    mapa = {}
    for k, (a, b) in enumerate(arestas):
        mapa[(a, b)] = (k, +1)
        mapa[(b, a)] = (k, -1)
    faces = []
    for c in ciclos:
        faces.append([mapa[(c[i], c[(i + 1) % len(c)])] for i in range(len(c))])
    return faces


def _orienta_lw(pares, paridade):
    """Orientação de Levin–Wen: do vértice par para o ímpar (só para grafos bipartidos)."""
    out = []
    for a, b in pares:
        assert paridade[a] != paridade[b], "grafo não bipartido"
        out.append((a, b) if paridade[a] == 0 else (b, a))
    return out


def plaqueta():
    """Um laço quadrado (4 GMFs, 4 ligações, 1 laço)."""
    par = [0, 1, 0, 1]
    arestas = _orienta_lw([(0, 1), (1, 2), (2, 3), (3, 0)], par)
    return Complexo("plaqueta", 4, arestas, _faces_de_ciclos(arestas, [[0, 1, 2, 3]]))


def faixa():
    """Dois quadrados lado a lado (6 GMFs, 7 ligações, 2 laços)."""
    V = [(x, y) for x in range(3) for y in range(2)]
    idx = {v: i for i, v in enumerate(V)}
    pares = []
    for (x, y) in V:
        for dx, dy in ((1, 0), (0, 1)):
            w = (x + dx, y + dy)
            if w in idx:
                pares.append((idx[(x, y)], idx[w]))
    par = [(x + y) % 2 for (x, y) in V]
    arestas = _orienta_lw(pares, par)
    ciclos = [[idx[(0, 0)], idx[(1, 0)], idx[(1, 1)], idx[(0, 1)]],
              [idx[(1, 0)], idx[(2, 0)], idx[(2, 1)], idx[(1, 1)]]]
    return Complexo("faixa", 6, arestas, _faces_de_ciclos(arestas, ciclos))


def cubo():
    """Superfície de um cubo (8 GMFs, 12 ligações, 6 laços orientados para fora). Célula da rede cúbica."""
    V = [(x, y, z) for x in (0, 1) for y in (0, 1) for z in (0, 1)]
    idx = {v: i for i, v in enumerate(V)}
    pares = []
    for v in V:
        for d in range(3):
            if v[d] == 0:
                w = list(v); w[d] = 1
                pares.append((idx[v], idx[tuple(w)]))
    par = [sum(v) % 2 for v in V]
    arestas = _orienta_lw(pares, par)
    ciclos = []
    for d in range(3):                       # faces perpendiculares ao eixo d, em d = 0 e d = 1
        o1, o2 = [k for k in range(3) if k != d]
        for s in (0, 1):
            def p(u, w):
                c = [0, 0, 0]; c[d] = s; c[o1] = u; c[o2] = w
                return idx[tuple(c)]
            ciclo = [p(0, 0), p(1, 0), p(1, 1), p(0, 1)]
            # normal do ciclo (regra da mão direita) = +e_d se (o1, o2, d) é par; inverte para apontar para fora
            sinal_normal = 1 if (o1, o2, d) in ((0, 1, 2), (1, 2, 0), (2, 0, 1)) else -1
            para_fora = 1 if s == 1 else -1
            if sinal_normal != para_fora:
                ciclo = ciclo[::-1]
            ciclos.append(ciclo)
    return Complexo("cubo", 8, arestas, _faces_de_ciclos(arestas, ciclos))


COMPLEXOS = {"plaqueta": plaqueta, "faixa": faixa, "cubo": cubo}


# ============================================================================ previsões de perturbação
def soma_ordenacoes(n):
    """Σ sobre as n! ordens de virar as n ligações de um laço de Π 1/(custo intermediário/V)."""
    from fractions import Fraction
    tot = Fraction(0)
    for perm in itertools.permutations(range(n)):
        Q = [0] * n
        prod = Fraction(1)
        for k in perm[:-1]:
            Q[k] -= 1; Q[(k + 1) % n] += 1
            prod *= Fraction(1, sum(q * q for q in Q))
        tot += prod
    return tot


def coef_anel(n):
    """Elemento de anel efetivo = coef_anel(n) · Γⁿ/Vⁿ⁻¹ · Π √(S(S+1) − m(m±1)). Negativo para Γ > 0."""
    return -float(soma_ordenacoes(n)) / 2 ** n


def dJ_efetivo(Gam, V):
    """Termo elétrico emergente em 2ª ordem: δJ_ef = Γ²/(4V) por ligação, para qualquer S."""
    return Gam ** 2 / (4 * V)


# ============================================================================ espaço de spins nas ligações
def configuracoes(E, S):
    """Todas as configurações m ∈ {−S..S}^E (índice em base 2S+1, dígito e = ligação e)."""
    b = 2 * S + 1
    D = b ** E
    idx = np.arange(D, dtype=np.int64)
    pot = b ** np.arange(E, dtype=np.int64)
    m = ((idx[:, None] // pot[None, :]) % b).astype(np.int16) - S
    return m, pot


def ME(S, m, delta):
    """Elemento ⟨m+δ|S^δ|m⟩ (δ = ±1)."""
    return np.sqrt(np.maximum(S * (S + 1) - m * (m + delta), 0.0))


def h_micro(cx: Complexo, S, V, Gam, dJ0=0.0, incid=None):
    """H = V Σ_I Q_I² + δJ0 Σ_e (S^z_e)² − Γ Σ_e S^x_e. Sem nenhum termo invariante de gauge.
    incid (E × N): sinais da lei de conservação em cada GMF; padrão = d0 (fluxo orientado)."""
    incid = cx.d0 if incid is None else incid
    m, pot = configuracoes(cx.E, S)
    D = m.shape[0]
    Q = m.astype(np.int32) @ incid.astype(np.int32)
    diag = V * (Q.astype(float) ** 2).sum(1) + dJ0 * (m.astype(float) ** 2).sum(1)
    rows, cols, vals = [np.arange(D)], [np.arange(D)], [diag]
    for e in range(cx.E):
        ok = np.nonzero(m[:, e] < S)[0]
        rows.append(ok); cols.append(ok + pot[e])
        vals.append(-(Gam / 2) * ME(S, m[ok, e].astype(float), +1))
    H = sp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(D, D)).tocsr()
    H = H + sp.triu(H, 1).T
    Qtot = (Q.astype(float) ** 2).sum(1)
    return H.tocsr(), m, Qtot


def espaco_P(m, incid):
    """Índices do setor sem cargas (Q_I = 0 em todo GMF)."""
    Q = m.astype(np.int32) @ incid.astype(np.int32)
    return np.nonzero(~np.any(Q, axis=1))[0]


def limite_superior(H):
    """Cota de Gershgorin para o maior autovalor."""
    dg = H.diagonal()
    fora = abs(H - sp.diags(dg)).sum(1).A1
    return float(np.max(dg + fora))


def filtro_chebyshev(H, X, grau, a, b):
    """Amplifica a parte de X com autovalores abaixo de a; amortece [a, b]."""
    e, c = (b - a) / 2, (b + a) / 2
    Y = (H @ X - c * X) / e
    for _ in range(2, grau + 1):
        Yn = 2 * (H @ Y - c * Y) / e - X
        X, Y = Y, Yn
        nrm = np.abs(Y).max()
        if nrm > 1e100:                       # reescala para não estourar
            X, Y = X / nrm, Y / nrm
    return Y


def autoespaco_baixo(H, d, extra=4, seed=0, Pidx=None, corte=None, grau=40, tol=1e-12, max_iter=12):
    """Banda baixa de dimensão d (= dim P) e os 'extra' níveis seguintes.
    Denso se D ≤ 7000. Senão: iteração de subespaço com filtro de Chebyshev semeada nos vetores de P (robusta a
    degenerescências, ao contrário de Lanczos de vetor único) + Rayleigh–Ritz; os níveis acima da banda vêm de Lanczos
    no operador deflacionado H + σ·Y Yᵀ. Resíduo = max_col ‖HY − YΛ‖ / cota espectral."""
    D = H.shape[0]
    if D <= 7000:
        w, Y = sl.eigh(H.toarray())
        return w[: d + extra], Y[:, :d], 0.0
    b = limite_superior(H)
    if Pidx is None:                          # sem espaço modelo (controle V = 0): Lanczos simples
        rng = np.random.default_rng(seed)
        k = d + extra
        w, Y = spl.eigsh(H, k=k, which="SA", tol=1e-13, ncv=min(D - 1, max(2 * k + 20, 60)),
                         v0=rng.normal(size=D), maxiter=200000)
        o = np.argsort(w)
        w, Y = w[o], Y[:, o]
        Yb = Y[:, :d]
        res = float(np.max(np.linalg.norm(H @ Yb - Yb * w[:d], axis=0)) / b)
        return w, Yb, res
    a = corte if corte is not None else 1.0
    X = np.zeros((D, d))
    X[Pidx, np.arange(d)] = 1.0
    res = np.inf
    for it in range(max_iter):
        X = filtro_chebyshev(H, X, grau, a, b)
        Qm, _ = np.linalg.qr(X)
        Hs = Qm.T @ (H @ Qm)
        lam, V = np.linalg.eigh((Hs + Hs.T) / 2)
        X = Qm @ V
        res = float(np.max(np.linalg.norm(H @ X - X * lam, axis=0)) / b)
        if res <= tol:
            break
    Yb = X
    sigma = 10.0 * b
    op = spl.LinearOperator((D, D), matvec=lambda v: H @ v + sigma * (Yb @ (Yb.T @ v)), dtype=float)
    rng = np.random.default_rng(seed)
    wq = spl.eigsh(op, k=extra, which="SA", tol=1e-10, v0=rng.normal(size=D), return_eigenvectors=False,
                   ncv=min(D - 1, 40), maxiter=200000)
    w = np.concatenate([lam, np.sort(wq)])
    return w, Yb, res


def des_cloizeaux(H, Yb, Pidx):
    """Hamiltoniano efetivo hermitiano no espaço modelo P (des Cloizeaux): exato, sem teoria de perturbação."""
    X = Yb[Pidx, :]
    G = X @ X.T
    g, U = np.linalg.eigh(G)
    Gm = (U / np.sqrt(g)) @ U.T
    Hy = Yb.T @ (H @ Yb)
    Hy = (Hy + Hy.T) / 2
    Heff = Gm @ X @ Hy @ X.T @ Gm
    return (Heff + Heff.T) / 2, float(g.min())


def padroes_de_laco(cx: Complexo, incid):
    """Para cada laço, o padrão de viradas ±1 que preserva todas as cargas (se existir) dada a lei de conservação.
    Devolve lista de (face, vetor δ sobre as ligações) ou None se o laço é frustrado."""
    out = []
    for f, ciclo in enumerate(cx.faces):
        es = [e for e, _ in ciclo]
        # resolve: em cada GMF do laço, incid[e,I] δ_e + incid[e',I] δ_e' = 0
        delta = {es[0]: 1}
        ok = True
        n = len(es)
        for i in range(n):
            e, e2 = es[i], es[(i + 1) % n]
            comuns = set(np.nonzero(incid[e])[0]) & set(np.nonzero(incid[e2])[0])
            I = [I for I in comuns][0]
            val = -incid[e, I] * delta[e] / incid[e2, I]
            if e2 in delta:
                ok = ok and (delta[e2] == val)
            else:
                delta[e2] = int(val)
        if ok:
            v = np.zeros(cx.E, int)
            for e, s in delta.items():
                v[e] = s
            out.append((f, v))
        else:
            out.append((f, None))
    return out


def analisar_Heff(Heff, mP, cx, S, V, Gam, incid):
    """Compara Heff com as previsões: elétrico δJ_ef = Γ²/4V (diagonal) e anel coef_anel(n)Γⁿ/Vⁿ⁻¹Π√ (fora da diagonal)."""
    d = Heff.shape[0]
    # diagonal: ajuste c0 + δJ Σ m²
    s2 = (mP.astype(float) ** 2).sum(1)
    A = np.stack([np.ones(d), s2], 1)
    coef, *_ = np.linalg.lstsq(A, np.diag(Heff), rcond=None)
    dJ_med = float(coef[1]) if np.ptp(s2) > 0 else float("nan")
    # anéis
    pads = padroes_de_laco(cx, incid)
    chave = {tuple(r): i for i, r in enumerate(mP.tolist())}
    razoes, usados = [], np.zeros((d, d), bool)
    escala = 0.0
    por_face = {}
    for f, v in pads:
        if v is None:
            por_face[f] = {"frustrado": True, "movimentos": 0}
            continue
        n = int(np.count_nonzero(v))
        c = coef_anel(n) * Gam ** n / V ** (n - 1)
        rf = []
        for i in range(d):
            for sgn in (+1, -1):
                alvo = mP[i] + sgn * v
                if np.any(np.abs(alvo) > S):
                    continue
                j = chave.get(tuple(alvo.tolist()))
                if j is None:
                    continue
                es = np.nonzero(v)[0]
                pred = c * np.prod(ME(S, mP[i, es].astype(float), sgn * v[es]))
                escala = max(escala, abs(pred))
                rf.append(Heff[j, i] / pred)
                usados[i, j] = usados[j, i] = True
        razoes += rf
        por_face[f] = {"frustrado": False, "movimentos": len(rf),
                       "razao_media": float(np.mean(rf)) if rf else float("nan")}
    fora = Heff.copy()
    np.fill_diagonal(fora, 0.0)
    fora[usados] = 0.0
    resid = float(np.abs(fora).max() / escala) if escala > 0 else float("nan")
    razoes = np.array(razoes)
    return {
        "dJ_medido": dJ_med,
        "dJ_previsto": dJ_efetivo(Gam, V),
        "razao_dJ": dJ_med / dJ_efetivo(Gam, V) if np.isfinite(dJ_med) else float("nan"),
        "n_elementos_anel": int(razoes.size),
        "razao_anel_media": float(razoes.mean()) if razoes.size else float("nan"),
        "razao_anel_min": float(razoes.min()) if razoes.size else float("nan"),
        "razao_anel_max": float(razoes.max()) if razoes.size else float("nan"),
        "residuo_fora_de_aneis_sobre_escala": resid,
        "faces": por_face,
    }


# ============================================================================ base de fluxos do cubo (B23b)
def base_fluxos_cubo(cx: Complexo, B):
    """Estados sem carga no cubo como alturas de face n_f (n_0 = 0), com |E_e| ≤ B, E = d1ᵀ n.
    Na superfície fechada (esfera), todo fluxo sem divergência é borda de laços."""
    F = cx.F
    viz = [[] for _ in range(F)]
    for e in range(cx.E):
        fs = np.nonzero(cx.d1[:, e])[0]
        a, b = fs
        viz[a].append(b); viz[b].append(a)
    livres = list(range(1, F))
    # enumeração por camadas com poda: faces vizinhas de 0 primeiro
    ordem = sorted(livres, key=lambda f: 0 if 0 in viz[f] else 1)
    estados = np.zeros((1, F), np.int16)
    for f in ordem:
        novos = []
        for val in range(-2 * B, 2 * B + 1):
            X = estados.copy()
            X[:, f] = val
            ok = np.ones(len(X), bool)
            for g in viz[f]:
                if g == 0 or g in ordem[: ordem.index(f)]:
                    ok &= np.abs(X[:, f] - X[:, g]) <= B
            novos.append(X[ok])
        estados = np.concatenate(novos)
    Evals = estados.astype(np.int32) @ cx.d1.astype(np.int32)
    assert np.abs(Evals).max() <= B
    return estados, Evals


def h_fluxos(cx, estados, Evals, dJ, K, S=None):
    """H = δJ Σ E² − (K/2) Σ_f (T_f R_f + h.c.). S=None: rotor de Kogut–Susskind/Wilson (R = 1);
    S inteiro: ligação quântica de spin S, R = Π ρ, ρ = √(S(S+1) − m(m±1))/√(S(S+1)).
    Monta só o termo de subida T_f (n_f → n_f + 1) e soma o transposto."""
    D, F = estados.shape
    off = 4 * 2 * 64 + 1
    pesos = off ** np.arange(F, dtype=np.int64)
    chaves = (estados.astype(np.int64) + 256) @ pesos
    ordem = np.argsort(chaves)
    ch_ord = chaves[ordem]
    diag = sp.diags(dJ * (Evals.astype(float) ** 2).sum(1))
    rows, cols, vals = [], [], []
    for f in range(F):
        alvo = chaves + pesos[f]
        pos = np.minimum(np.searchsorted(ch_ord, alvo), D - 1)
        ok = ch_ord[pos] == alvo
        i = np.nonzero(ok)[0]
        j = ordem[pos[ok]]
        if S is None:
            amp = np.ones(len(i))
        else:
            es = np.nonzero(cx.d1[f])[0]
            m = Evals[i][:, es].astype(float)
            dlt = cx.d1[f, es][None, :].astype(float)
            amp = np.prod(np.sqrt(np.maximum(S * (S + 1) - m * (m + dlt), 0.0)) / math.sqrt(S * (S + 1)), axis=1)
        rows.append(j); cols.append(i); vals.append(-(K / 2) * amp)
    T = sp.coo_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(D, D)).tocsr()
    return (diag + T + T.T).tocsr()
