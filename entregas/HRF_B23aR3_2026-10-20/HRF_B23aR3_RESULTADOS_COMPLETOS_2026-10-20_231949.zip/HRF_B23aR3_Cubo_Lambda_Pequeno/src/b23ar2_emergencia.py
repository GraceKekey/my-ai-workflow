# -*- coding: utf-8 -*-
"""
HRF B23a-R2 — emergência do termo elétrico e do anel de Wilson nos aglomerados GRANDES que a B23 original não
completou: cubo S = 1 (531 441 estados), faixa S = 3 (823 543) e plaqueta S = 4 (6 561).
Modelo e análise: b23_modelo.py ORIGINAL (H = VΣQ² − ΓΣS^x; Hamiltoniano efetivo exato de des Cloizeaux).
Autossolver primário: o da B23 (denso até 7 000 estados; acima, iteração de subespaço com filtro de Chebyshev
semeada no setor sem cargas). Correção: o resíduo é MEDIDO também no caminho denso (o original gravava 0,0).
Segundo método (controle "dois métodos"): LOBPCG com pré-condicionador diagonal, em casos escolhidos antes.
Checkpoint atômico depois de cada caso.
"""
from __future__ import annotations

import json
import math
import os
import time

import numpy as np
import scipy.sparse.linalg as spl

import b23_modelo as M


def residuo_relativo(H, Y, w):
    cota = float(abs(H).sum(1).max())
    return float(np.max(np.linalg.norm(H @ Y - Y * w, axis=0)) / cota)


def banda_chebyshev(H, P, d, V):
    w, Y, _ = M.autoespaco_baixo(H, d, extra=4, Pidx=P, corte=V)
    return w, Y


def banda_lobpcg(H, P, d, extra=4, tol=1e-11, maxiter=600):
    D = H.shape[0]
    dg = H.diagonal()
    X = np.zeros((D, d)); X[P, np.arange(d)] = 1.0
    desl = dg.min() - 1.0
    Mpre = spl.LinearOperator((D, D), matvec=lambda v: v / (dg - desl),
                              matmat=lambda Vv: Vv / (dg - desl)[:, None], dtype=float)
    w, Y = spl.lobpcg(H, X, M=Mpre, largest=False, tol=tol, maxiter=maxiter)
    o = np.argsort(w)
    w, Y = w[o], Y[:, o]
    sigma = 10.0 * float(abs(H).sum(1).max())
    op = spl.LinearOperator((D, D), matvec=lambda v: H @ v + sigma * (Y @ (Y.T @ v)), dtype=float)
    wq = spl.eigsh(op, k=extra, which="SA", tol=1e-10, v0=np.random.default_rng(0).normal(size=D),
                   return_eigenvectors=False, ncv=min(D - 1, 40), maxiter=200000)
    return np.concatenate([w, np.sort(wq)]), Y


def caso(nome, S, lam, metodo="chebyshev", modo_sinal="assinado", semente_n3=None, V=1.0):
    t0 = time.time()
    cx = M.COMPLEXOS[nome]()
    Gam = lam * V / math.sqrt(S * (S + 1))
    incid = cx.d0.copy()
    extra_info = {}
    if modo_sinal == "sem_sinal":
        incid = np.abs(cx.d0)
    elif modo_sinal == "aleatorio":
        s = semente_n3
        while True:
            inc = cx.d0 * np.random.default_rng(s).choice([-1, 1], size=cx.d0.shape)
            pads = M.padroes_de_laco(cx, inc)
            fr = sum(v is None for _, v in pads)
            if 1 <= fr < cx.F:                 # pelo menos um laço frustrado E pelo menos um livre
                break
            s += 1
        incid = inc
        extra_info = {"semente_usada": s, "lacos_frustrados": int(fr)}
    H, m, Qtot = M.h_micro(cx, S, V, Gam, incid=incid)
    P = M.espaco_P(m, incid)
    d = len(P)
    if metodo == "lobpcg":
        w, Y = banda_lobpcg(H, P, d)
    else:
        w, Y = banda_chebyshev(H, P, d, V)
    res = residuo_relativo(H, Y, w[:d])
    Heff, gmin = M.des_cloizeaux(H, Y, P)
    a = M.analisar_Heff(Heff, m[P], cx, S, V, Gam, incid)
    return {"complexo": nome, "S": S, "lambda": lam, "Gamma": Gam, "metodo": metodo, "modo_sinal": modo_sinal,
            "dim_total": int(H.shape[0]), "dim_P": d, "residuo_real": res, "g_min_sobreposicao": gmin,
            "gap_sobre_2V": float((w[d] - w[d - 1]) / (2 * V)), "autovalores_banda": [float(x) for x in w[:d]],
            "nivel_acima": float(w[d]), **extra_info, **a, "segundos": round(time.time() - t0, 1)}


class Caderno:
    def __init__(self, caminho):
        self.caminho = caminho
        self.dados = json.load(open(caminho)) if os.path.exists(caminho) else {"casos": {}, "controles": {}}

    def grava(self, grupo, chave, valor):
        self.dados[grupo][chave] = valor
        tmp = self.caminho + ".tmp"
        json.dump(self.dados, open(tmp, "w"), ensure_ascii=False, indent=1)
        os.replace(tmp, self.caminho)


def _linha(r):
    return (f"dimP={r['dim_P']} res={r['residuo_real']:.1e} gmin={r['g_min_sobreposicao']:.4f} gap/2V={r['gap_sobre_2V']:.4f} "
            f"dJ={r['razao_dJ']:.6f} anel={r['razao_anel_media']:.6f} [{r['razao_anel_min']:.6f}, {r['razao_anel_max']:.6f}] "
            f"fora={r['residuo_fora_de_aneis_sobre_escala']:.1e} ({r['segundos']} s)")


def rodar(cfg, pasta):
    cad = Caderno(os.path.join(pasta, "B23aR2_checkpoint.json"))
    for nome, S in cfg["casos"]:
        for lam in cfg["lambdas"]:
            ch = f"{nome}|S={S}|lambda={lam}"
            if ch not in cad.dados["casos"]:
                cad.grava("casos", ch, caso(nome, S, lam))
            print(f"  B23a-R2 {nome} S={S} λ={lam}: " + _linha(cad.dados["casos"][ch]), flush=True)
    for nome, S, lam in cfg["dois_metodos"]:
        ch = f"dois_metodos|{nome}|S={S}|lambda={lam}"
        if ch not in cad.dados["controles"]:
            r = caso(nome, S, lam, metodo="lobpcg")
            p = cad.dados["casos"][f"{nome}|S={S}|lambda={lam}"]
            cad.grava("controles", ch, {"lobpcg": r,
                                        "dif_banda": float(np.max(np.abs(np.array(r["autovalores_banda"]) - np.array(p["autovalores_banda"])))),
                                        "dif_razoes": float(max(abs(r["razao_dJ"] - p["razao_dJ"]), abs(r["razao_anel_media"] - p["razao_anel_media"])))})
        c = cad.dados["controles"][ch]
        print(f"  B23a-R2 dois métodos {nome} S={S} λ={lam}: Δbanda={c['dif_banda']:.1e} Δrazões={c['dif_razoes']:.1e}", flush=True)
    n1 = cfg["N1"]
    ch = f"N1|{n1[0]}|S={n1[1]}|lambda={n1[2]}"
    if ch not in cad.dados["controles"]:
        r = caso(*n1, modo_sinal="sem_sinal")
        p = cad.dados["casos"][f"{n1[0]}|S={n1[1]}|lambda={n1[2]}"]
        cad.grava("controles", ch, {"sem_sinal": r, "dif_banda": float(np.max(np.abs(np.array(r["autovalores_banda"]) - np.array(p["autovalores_banda"]))))})
    print(f"  B23a-R2 N1 (sem sinal × assinado, {n1[0]} S={n1[1]}): Δbanda={cad.dados['controles'][ch]['dif_banda']:.1e}", flush=True)
    n3 = cfg["N3"]
    ch = f"N3|{n3[0]}|S={n3[1]}|lambda={n3[2]}"
    if ch not in cad.dados["controles"]:
        cad.grava("controles", ch, caso(*n3[:3], modo_sinal="aleatorio", semente_n3=n3[3]))
    r = cad.dados["controles"][ch]
    livres = [v["razao_media"] for v in r["faces"].values() if not v["frustrado"]]
    print(f"  B23a-R2 N3 (sinais aleatórios, {n3[0]} S={n3[1]}): frustrados={r['lacos_frustrados']} razões livres={np.round(livres, 4).tolist()}", flush=True)
    return cad.dados
