"""Regras B23a-R3. Não recalibra tolerâncias e não usa a plaqueta para decidir o cubo."""
from pathlib import Path
import sys,json,math,os
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
import numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parent))
from rodar_B23aR3 import chave,especificacoes
JANELA=(.05,.035,.025)
def ordem(lambdas,desvios):
 if any(d==0 or not math.isfinite(d) for d in desvios):return None
 return float(np.polyfit(np.log(lambdas),np.log(np.abs(desvios)),1)[0])
def avaliar(casos,referencias):
 esperadas={chave(*s) for s in especificacoes('completo')}
 if set(casos)!=esperadas:
  return {'decisao':'INCONCLUSIVO','dados_completos':False,'falhas':['Cobertura incompatível com os nove casos completos.'],'ausentes':sorted(esperadas-set(casos)),'extras':sorted(set(casos)-esperadas)}
 cubos={k:v for k,v in casos.items() if k.startswith('cubo|')}
 campos=('razao_dJ','razao_anel_media','razao_anel_min','razao_anel_max','residuo_real','g_min_sobreposicao','gap_sobre_2V')
 if any(any(not isinstance(v.get(f),(float,int)) or not math.isfinite(v[f]) for f in campos) for v in cubos.values()):
  return {'decisao':'INCONCLUSIVO','dados_completos':False,'falhas':['Medida do cubo ausente ou não finita; não há decisão válida.']}
 prim={l:casos[chave('cubo',1,l)] for l in (.07,.05,.035,.025)}
 alt=casos[chave('cubo',1,.025,'lobpcg')];ref=referencias['casos']['0.05']
 v0={k:v['residuo_real']<=1e-10 and v['g_min_sobreposicao']>=.5 and v['gap_sobre_2V']>=.5 for k,v in cubos.items()}
 d1={f:abs(prim[.05][f]-ref[f]) for f in ('razao_dJ','razao_anel_media')}
 v1=all(d<=1e-9 for d in d1.values())
 d2={f:{'diferenca':abs(alt[f]-prim[.025][f]),'limite':frac*abs(prim[.025][f]-1)} for f,frac in (('razao_dJ',.01),('razao_anel_media',.05))}
 v2=all(d['diferenca']<=d['limite'] for d in d2.values())
 def seis(v):
  faces=v.get('faces',{})
  return len(faces)==6 and set(str(k) for k in faces)==set(map(str,range(6))) and all(f.get('frustrado') is False and f.get('movimentos',0)>0 for f in faces.values())
 v3={k:seis(v) for k,v in cubos.items()}
 validade={'V0':all(v0.values()),'V1':v1,'V2':v2,'V3':all(v3.values())}
 por_l={str(l):{'desvio_dJ':prim[l]['razao_dJ']-1,'desvio_anel':prim[l]['razao_anel_media']-1,'espalhamento_anel':prim[l]['razao_anel_max']-prim[l]['razao_anel_min']} for l in JANELA}
 a2=all(abs(v['desvio_dJ'])<=.003 and abs(v['desvio_anel'])<=.003 and 0<=v['espalhamento_anel']<=.03 for v in por_l.values())
 pj=ordem(JANELA,[prim[l]['razao_dJ']-1 for l in JANELA]);pk=ordem(JANELA,[prim[l]['razao_anel_media']-1 for l in JANELA])
 a3=pj is not None and pk is not None and pj>=1.5 and pk>=1.5
 grosso=any(not .8<=v[f]<=1.2 for v in cubos.values() for f in ('razao_dJ','razao_anel_media'))
 if not all(validade.values()):dec='INCONCLUSIVO'
 elif grosso:dec='NAO_EMERGE'
 elif a2 and a3:dec='A3_FECHADO'
 elif a2:dec='A3_FALHA'
 else:dec='PARCIAL'
 # Série é descritiva. Recertificação .05 entra uma só vez, com a medida nova.
 ls=np.array([.4,.2,.1,.07,.05,.035,.025])
 ds=np.array([(referencias['casos'][str(l)] if l in (.4,.2,.1) else prim[l])['razao_dJ']-1 for l in ls])
 design=np.stack((ls**2,ls**4,ls**6),axis=1);coef=np.linalg.lstsq(design,ds,rcond=None)[0]
 roots=np.roots([coef[2],coef[1],coef[0]])
 zeros=sorted(math.sqrt(float(r.real)) for r in roots if r.real>0 and abs(r.imag)<=1e-10*max(1,abs(r.real)))
 return {'decisao':dec,'dados_completos':True,'validade':validade,'falhas':[k for k,v in validade.items() if not v],
         'V0_por_caso':v0,'V1_diferencas':d1,'V2_dois_metodos':d2,'V3_seis_faces_por_caso':v3,
         'A2_R3':a2,'A3_R3':a3,'janela':list(JANELA),'ordem_dJ':pj,'ordem_anel':pk,'por_lambda_janela':por_l,
         'alguma_razao_fora_0.8_1.2':grosso,'serie_descritiva':{'lambdas':ls.tolist(),'desvios_dJ':ds.tolist(),'coeficientes_a_b_c':coef.tolist(),'zeros_positivos_nao_triviais':zeros,'zero_mais_proximo':zeros[0] if zeros else None,'residuo_max_ajuste':float(np.max(np.abs(design@coef-ds)))},
         'leitura_combinada':{'E1_B23c':'EQUIVALENTE (antecedente reportado; não refeito)','E2_B23b_R2':'CONVERGE_6F (antecedente reportado; não refeito)','E3_B23a':'EMERGE (R2 + R3)' if dec=='A3_FECHADO' else 'PARCIAL (B23a-R2 mantida)','correspondencia':'CONFIRMADA (R2 + R3)' if dec=='A3_FECHADO' else 'PARCIAL (B23-R2 mantida)'},
         'nota':'Plaqueta: controle de precisão descritivo. Desvio zero torna a ordem indefinida (null) e A3 não demonstrado; não se acrescenta epsilon ao log.'}
def main():
 pasta=Path(sys.argv[1]);root=Path(__file__).resolve().parent.parent
 meta=json.loads((pasta/'B23aR3_config_completo.json').read_text())
 if meta['parametros']['modo']!='completo':raise ValueError('A fumaça não recebe decisão científica.')
 out=avaliar(json.loads((pasta/'B23aR3_checkpoint.json').read_text())['casos'],json.loads((root/'referencias/B23R2_cubo.json').read_text()))
 (pasta/'avaliacao_B23aR3.json').write_text(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False));print(json.dumps(out,ensure_ascii=False,indent=2,allow_nan=False))
if __name__=='__main__':main()
