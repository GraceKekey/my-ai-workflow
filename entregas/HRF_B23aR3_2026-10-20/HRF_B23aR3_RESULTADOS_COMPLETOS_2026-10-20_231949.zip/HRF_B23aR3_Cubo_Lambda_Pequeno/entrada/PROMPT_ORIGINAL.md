# PROMPT — HRF B23a-R3: o termo elétrico do cubo em λ pequeno (fechar o critério A3)

> Cole este texto inteiro no outro ambiente, junto com o anexo `HRF_B23R2_RETOMADA_2026-10-19_1958-clau.zip`
> (SHA-256 `741c362382dc9426ece44d2c55a5bc964f12312248020cbdae3cc233666074bf`).
> Preparado por Claude (`-clau`) em 20/10/2026, 16h45, para Mario José do Canto Filho, MD.

---

## 0. Papel e regras de trabalho

Você vai **pré-registrar, implementar e (só depois de autorização) executar** a bancada **B23a-R3** do HRF
(Holographic Reconstruction Framework), um programa independente de pesquisa em fundamentos da física. Autor: Mario José
do Canto Filho, MD. É uma bancada curta, que fecha um único critério deixado em aberto pela B23-R2.

Regras obrigatórias:
1. **Duas fases.** Fase 1: pré-registro (protocolo, código, fumaça, teste do avaliador, hashes) e **pare**. Fase 2: só
   depois de Mario escrever **"pode rodar"**.
2. **Não altere nada depois de ver resultados.** Regras, tolerâncias, valores de λ e código ficam congelados na Fase 1.
   Se algo falhar, relate; não corrija silenciosamente.
3. **Reuse o código congelado da B23-R2 sem modificar** (seção 2). O código novo só orquestra e avalia.
4. Python isolado (`python -I`), BLAS com 1 thread, checkpoint atômico por caso (relançar retoma sem refazer).
5. Português; marcas **[F]** estabelecido · **[M]** modelo/bancada · **[H]** hipótese HRF · **[?]** aberto · **[D]** decisão.
6. Esta bancada não injeta ondas.

## 1. Contexto (o que já se sabe)

Modelo de Levin–Wen nas relações: **H = V Σ_v Q_v² − Γ Σ_e S_e^x**, spin S em cada ligação (S^z = campo elétrico), Q_v =
divergência de S^z no vértice (carga de Gauss), V = 1. Parâmetro λ = Γ√(S(S+1))/V. No setor sem cargas, o Hamiltoniano
efetivo exato (des Cloizeaux) deve conter:
- **termo elétrico** por ligação: δJ = Γ²/(4V) (2ª ordem);
- **anel de Wilson** em cada face quadrada: −(5/32) Γ⁴/V³ · Π √(S(S+1) − m(m ± 1)) (4ª ordem).
As razões medido/previsto devem tender a 1 com correções O(λ²).

**B23-R2 (19–20/10/2026), cubo S = 1** (12 ligações, 531 441 estados, setor sem cargas com 69; as 6 faces com anel):

| λ | razão δJ | razão do anel (média) | resíduo real | g_min | gap/2V |
|---|---|---|---|---|---|
| 0,4 | 0,9973406576177153 | 0,982969762355549 | 6,7×10⁻¹⁴ | 0,765 | 0,519 |
| 0,2 | 1,0000530189836927 | 0,9964234686814853 | 7,0×10⁻¹⁵ | 0,941 | 0,753 |
| 0,1 | 1,000043263214373 | 0,9990928117023864 | 7,4×10⁻¹⁵ | 0,985 | 0,876 |
| 0,05 | 1,0000124832319144 | 0,9997715804633781 | 5,1×10⁻¹⁵ | 0,996 | 0,938 |

Veredito congelado da B23a-R2: **PARCIAL**, só pelo critério **A3** (ordem ≥ 1,5 na janela λ = 0,2; 0,1; 0,05) no termo
elétrico do cubo (ordem 1,04; o anel deu 1,98). Análise post hoc: (razão δJ − 1) = aλ² + bλ⁴ + cλ⁶ com a = 0,0052,
b = −0,084, c = −0,33; o termo dominante é λ², mas a correção troca de sinal em λ ≈ 0,227, logo acima da janela, e achata
o ponto λ = 0,2. A B23-R3 testa isso **longe do zero**.

## 2. Código congelado a reutilizar (não modificar)

Do anexo, confira os SHA-256:

| arquivo | SHA-256 |
|---|---|
| `HRF_B23R2/src/b23_modelo.py` | `eaa1e7493fb0e142bea048c2fd164cf40c383941a8086ba84cbe11ae7a2d2cec` |
| `HRF_B23R2/src/b23ar2_emergencia.py` | `c5af7a5fa35cd7afa6c91391e373213398f44940128480ec1852e0b7cb661ce2` |

Use `b23ar2_emergencia.caso(nome, S, lam, metodo="chebyshev" | "lobpcg")`. Ela devolve `razao_dJ`, `razao_anel_media`,
`razao_anel_min`, `razao_anel_max`, `residuo_real`, `g_min_sobreposicao`, `gap_sobre_2V`, `faces`,
`residuo_fora_de_aneis_sobre_escala`, `autovalores_banda`, entre outros.

## 3. Objetivo

Medir a ordem de convergência do termo elétrico e do anel no cubo S = 1 em λ pequeno, longe do zero da correção, e
fechar (ou não) o critério A3.

## 4. Hipóteses e previsões (escritas antes)

- [M] (razão δJ − 1) segue aλ² + bλ⁴ + cλ⁶ com a ≈ 0,0052. Previsões pela série da B23-R2 (escritas agora):
  λ = 0,07: +2,34×10⁻⁵; λ = 0,035: +6,24×10⁻⁶; λ = 0,025: +3,22×10⁻⁶. Sinal positivo em todo λ ≤ 0,1.
- [M] (razão do anel − 1) ≈ −0,09 λ²: λ = 0,035: ≈ −1,1×10⁻⁴; λ = 0,025: ≈ −5,7×10⁻⁵.
- Ordem log-log na janela nova ≈ 2 para os dois termos.

## 5. Parâmetros

- **Cubo S = 1**, V = 1, método Chebyshev (o primário da B23-R2): λ ∈ {0,07; 0,05; 0,035; 0,025}.
  λ = 0,05 é **recertificação** (tem de reproduzir a B23-R2).
- **Dois métodos:** cubo S = 1 em λ = 0,025 também com `metodo="lobpcg"`.
- **Controle de precisão barato:** plaqueta S = 1 (denso) nos mesmos quatro λ.
- **Custo (confira na fumaça):** na B23-R2 o cubo levou 7–14 min por λ (mais lento quanto menor λ); LOBPCG ~12 min.
  Estimativa total: 1–1,5 h.
- **Precisão:** em λ = 0,025 o anel vale ~6×10⁻⁸ e o desvio esperado ~5,7×10⁻⁵ relativo (~3×10⁻¹² absoluto); o resíduo
  real da B23-R2 foi ~10⁻¹⁴. O controle "dois métodos" verifica se a precisão basta. Não desça abaixo de λ = 0,025.

## 6. Medidas

Para cada caso: razões δJ e do anel (média, mín., máx.), desvios (razão − 1), resíduo real, g_min, gap/2V, resíduo fora
dos anéis, anel presente nas 6 faces, tempo. Ordens: inclinação de mínimos quadrados de ln|razão − 1| contra ln λ na
**janela λ ∈ {0,05; 0,035; 0,025}**. Série: ajuste de (razão δJ − 1) = aλ² + bλ⁴ + cλ⁶ em todos os λ (0,4; 0,2; 0,1 da
B23-R2 + os novos), relatando a, b, c e o zero da correção.

## 7. Regras de decisão (congelar no avaliador antes da Fase 2)

**Validade** (se qualquer uma falhar: **INCONCLUSIVO**):
- V0: resíduo real ≤ 10⁻¹⁰, g_min ≥ 0,5 e gap/2V ≥ 0,5 em todos os casos do cubo;
- V1 (recertificação, λ = 0,05): |Δ razão δJ| e |Δ razão do anel média| contra a B23-R2 ≤ 10⁻⁹;
- V2 (dois métodos, λ = 0,025): |Δ razão δJ| ≤ 1% de |razão δJ − 1| e |Δ razão do anel média| ≤ 5% de
  |razão do anel média − 1|;
- V3: anel presente nas 6 faces em todos os λ.

**Critérios:**
- A2-R3: em λ ∈ {0,05; 0,035; 0,025}, |razão − 1| ≤ 0,003 para δJ e anel médio, e espalhamento do anel (máx − mín) ≤ 0,03;
- A3-R3: ordem ≥ 1,5 para δJ **e** para o anel, na janela {0,05; 0,035; 0,025}.

**Decisão da B23a-R3:**
- **INCONCLUSIVO** se a validade falha;
- **NAO_EMERGE** se alguma razão sair de [0,8; 1,2];
- **A3_FECHADO** se A2-R3 e A3-R3 passam;
- **A3_FALHA** se A2-R3 passa e A3-R3 falha;
- **PARCIAL** nos outros casos.

**Leitura combinada (pré-registrada):** se A3_FECHADO, a B23a (R2 + R3) passa a **EMERGE**; com a B23b-R2 =
CONVERGE_6F, a correspondência Levin–Wen ↔ Capítulo 2 na rede regular fica **CONFIRMADA (R2 + R3)**. Em qualquer outro
desfecho, o veredito geral da B23-R2 (PARCIAL) continua valendo.

## 8. Fase 1 — pré-registro (e pare)

1. Confira os hashes da seção 2. Crie uma pasta nova `HRF_B23aR3_Cubo_Lambda_Pequeno/` com `src/` (cópias **idênticas**
   dos dois arquivos + `rodar_B23aR3.py`, `avaliar_B23aR3.py`, `teste_avaliador_sintetico_B23aR3.py`).
2. **Fumaça** fora do conjunto de decisão: plaqueta S = 1 e faixa S = 1 nos quatro λ, e o cubo S = 1 em λ = 0,1 (caso já
   conhecido: tem de dar as razões da tabela da seção 1). Meça os tempos.
3. **Teste sintético do avaliador:** dados fabricados que levem a todos os ramos (INCONCLUSIVO, NAO_EMERGE, A3_FECHADO,
   A3_FALHA, PARCIAL).
4. **Protocolo** `HRF_B23aR3_PROTOCOLO_<data-hora>.md` (Objetivo, Hipóteses, Parâmetros, Protocolo, Medidas, Regras de
   decisão, Fumaça, Limites, Arquivos), com as previsões numéricas da seção 4.
5. `LEIAME_B23aR3.md` com os comandos e `hashes_antes_da_execucao.txt` (protocolo + todo `src/`).
6. Zip `HRF_B23aR3_PREREGISTRO_<data-hora>.zip` e **pare**. Mostre a Mario o resumo e espere "pode rodar".

## 9. Fase 2 — execução (só depois de "pode rodar")

1. `sha256sum -c hashes_antes_da_execucao.txt` (guarde a saída).
2. `python -I src/rodar_B23aR3.py completo` → checkpoint por caso.
3. `python -I src/avaliar_B23aR3.py resultados` → `resultados/avaliacao_B23aR3.json`.
4. Figura (não muda decisões): |razão − 1| contra λ em log-log, δJ e anel, B23-R2 + B23a-R3, com a série ajustada e a
   reta de inclinação 2.
5. **Relatório** `HRF_B23aR3_RELATORIO_<data-hora>.md`, na ordem **Objetivo → Hipóteses → Parâmetros → Protocolo →
   Medidas → Resultados → Controles/convergência → Interpretação**, com as marcas [F]/[M]/[H]/[?]/[D]. Compare os desvios
   medidos com as previsões da seção 4 e diga o estado E1–E3 da correspondência (E1 B23c EQUIVALENTE; E2 B23b-R2
   CONVERGE_6F; E3 B23a).
6. **Entrega:** zip com a pasta inteira depois da rodada (código, protocolo, fumaça, resultados, logs, figura, saída dos
   hashes, versões e máquina) e o zip de entrada original. Mario devolve o zip a Claude para auditoria independente.

## 10. Limites a declarar

- Aglomerado finito (superfície fechada do cubo): testa coeficientes locais, não a fase de Coulomb termodinâmica.
- ħ entra nas relações de comutação; nada aqui deriva ħ.
- Precisão dupla: abaixo de λ ≈ 0,02 o desvio do anel se aproxima do ruído numérico.
