"""Entrega da Fase 2: relatórios e gráficos, sem modificar protocolo, código ou decisões congeladas."""
from pathlib import Path
from zoneinfo import ZoneInfo
import json,csv,hashlib,datetime,zipfile,shutil
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
R=Path(__file__).resolve().parent.parent
load=lambda p:json.loads((R/p).read_text())
cad=load('resultados/B23aR3_checkpoint.json');meta=load('resultados/B23aR3_config_completo.json');ev=load('resultados/avaliacao_B23aR3.json');refs=load('referencias/B23R2_cubo.json')['casos'];cs=cad['casos']
expected={f'cubo|S=1|lambda={l:g}|metodo=chebyshev' for l in (.07,.05,.035,.025)}|{f'plaqueta|S=1|lambda={l:g}|metodo=chebyshev' for l in (.07,.05,.035,.025)}|{'cubo|S=1|lambda=0.025|metodo=lobpcg'}
checks={'cobertura_exata_nove_casos':set(cs)==expected,'concluido_runner':meta['tentativas'][-1].get('concluido') is True,'parametros_completo':cad['parametros']==meta['parametros'],'modo_completo':cad['parametros']['modo']=='completo'}
for line in (R/'hashes_antes_da_execucao.txt').read_text().splitlines():
 h,f=line.split(maxsplit=1);checks['hash_congelado:'+f]=hashlib.sha256((R/f).read_bytes()).hexdigest()==h
old=load('MANIFEST_SHA256_ENTREGA.json')
for f,h in old.items():checks['arquivo_fase1_inalterado:'+f]=hashlib.sha256((R/f).read_bytes()).hexdigest()==h
assert all(checks.values()),checks
(R/'VERIFICACAO_COBERTURA_FASE2.json').write_text(json.dumps(checks,ensure_ascii=False,indent=2))
(R/'tabelas').mkdir(exist_ok=True);(R/'figuras').mkdir(exist_ok=True)
def table(name,rows):
 keys=list(dict.fromkeys(k for row in rows for k in row))
 with (R/'tabelas'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
rows=[];faces=[]
for key,c in cs.items():
 rows.append({'caso':key,**{k:v for k,v in c.items() if isinstance(v,(int,float,str,bool)) or v is None},'desvio_dJ':c['razao_dJ']-1,'desvio_anel':c['razao_anel_media']-1,'espalhamento_anel':c['razao_anel_max']-c['razao_anel_min']})
 for face,v in c['faces'].items():faces.append({'caso':key,'face':face,**v})
table('B23aR3_todos_casos.csv',rows);table('B23aR3_faces.csv',faces)
primary={c['lambda']:c for c in cs.values() if c['complexo']=='cubo' and c['metodo']=='chebyshev'}
predj={.07:2.34e-5,.035:6.24e-6,.025:3.22e-6};predk={.035:-1.1e-4,.025:-5.7e-5};predrows=[]
for l,c in primary.items():
 j=c['razao_dJ']-1;k=c['razao_anel_media']-1
 predrows.append({'lambda':l,'desvio_dJ_medido':j,'previsao_dJ_numerica_prompt':predj.get(l),'previsao_dJ_serie_R2_arredondada':.0052*l*l-.084*l**4-.33*l**6,'desvio_anel_medido':k,'previsao_anel_numerica_prompt':predk.get(l),'previsao_anel_modelo_menos0.09lambda2':-.09*l*l,'erro_rel_previsao_dJ':j/predj[l]-1 if l in predj else None,'erro_rel_previsao_anel':k/predk[l]-1 if l in predk else None})
table('B23aR3_previsoes_vs_medidas.csv',predrows)
# Figura solicitada: dados R2 + R3, série descritiva congelada para δJ e referência de inclinação 2.
plt.rcParams.update({'font.size':10,'axes.grid':True,'grid.alpha':.2})
fig,axs=plt.subplots(1,2,figsize=(12,4.8))
oldls=np.array([.4,.2,.1,.05]);newls=np.array([.07,.05,.035,.025]);grid=np.geomspace(.024,.42,500)
def positive(vals):
 a=np.abs(np.asarray(vals,float));return np.where(a>0,a,np.nan)
for ax,field,label in zip(axs,('razao_dJ','razao_anel_media'),('Termo elétrico δJ','Anel de Wilson (média)')):
 ax.loglog(oldls,positive([refs[str(l)][field]-1 for l in oldls]),'o',color='gray',label='B23-R2 (conhecidos)')
 ax.loglog(newls,positive([primary[l][field]-1 for l in newls]),'s-',label='B23a-R3 · Chebyshev')
 alt=cs['cubo|S=1|lambda=0.025|metodo=lobpcg'];ax.loglog([.025],positive([alt[field]-1]),'x',ms=10,mew=2,label='LOBPCG · controle')
 anchor=abs(primary[.05][field]-1);ax.loglog(grid,anchor*(grid/.05)**2,'--',color='black',lw=1,label='Inclinação 2 (referência)')
 ax.axvspan(.025,.05,alpha=.08,color='blue',label='Janela decisória A3')
 if field=='razao_dJ':
  a,b,c=ev['serie_descritiva']['coeficientes_a_b_c'];ax.loglog(grid,positive(a*grid**2+b*grid**4+c*grid**6),':',color='#e47720',label='Série ajustada (descritiva)')
 ax.set(title=label,xlabel='λ',ylabel='|razão − 1|');ax.legend(fontsize=7,loc='best')
fig.tight_layout();fig.savefig(R/'figuras/B23aR3_convergencia.png',dpi=180);fig.savefig(R/'figuras/B23aR3_convergencia.pdf');plt.close(fig)
now=datetime.datetime.now(ZoneInfo('America/Sao_Paulo'));stamp=now.strftime('%Y-%m-%d_%H%M%S')
name=f'HRF_B23aR3_RELATORIO_{stamp}.md'
lines=['# HRF B23a-R3 — termo elétrico do cubo em λ pequeno','',f'Concluído em {now.isoformat()} (America/Sao_Paulo).','','Marcas: [F] estabelecido · [M] modelo/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.','',f"**[D] B23a-R3: {ev['decisao']}.**",'','## Objetivo','','[M] Medir as ordens do termo elétrico e do anel no cubo S=1 em λ pequeno, longe do zero da correção, e testar o critério A3 deixado em aberto pela B23a-R2.','','## Hipóteses','','[M] Previsões pré-registradas: desvio δJ de +2,34×10⁻⁵ em λ=0,07, +6,24×10⁻⁶ em 0,035 e +3,22×10⁻⁶ em 0,025; sinal positivo em λ≤0,1. Anel: aproximadamente −0,09λ², com −1,1×10⁻⁴ em 0,035 e −5,7×10⁻⁵ em 0,025. Ordem esperada próxima de 2 para ambos. A série arredondada da R2, anterior a esta rodada, foi aλ²+bλ⁴+cλ⁶ com a=0,0052, b=−0,084 e c=−0,33.','','## Parâmetros','','[M] Cubo S=1, V=1; primário Chebyshev em λ=0,07,0,05,0,035,0,025. λ=0,05 é recertificação. LOBPCG no cubo em 0,025. Controle descritivo denso na plaqueta S=1 nos quatro λ. Janela decisória fixa 0,05,0,035,0,025. Não se desceu de 0,025. Nenhuma onda foi injetada.','','## Protocolo','','[D] A Fase 1 foi congelada e entregue antes da autorização. A mensagem de Mario “Pode rodar” autorizou esta Fase 2 (AUTORIZACAO_FASE2.json). Todos os hashes foram conferidos antes e após os cálculos. O orquestrador e o avaliador congelados foram executados com Python isolado (-I) e uma thread BLAS. As duas fontes científicas são cópias binárias idênticas às da B23-R2. A recertificação foi recalculada; não se copiou a medida antiga ou a fumaça para os resultados novos. O teste sintético de cinco desfechos foi realizado na Fase 1 e não é evidência física.','','[F] Os arquivos originais de toda a Fase 1, inclusive seu manifesto, foram preservados. FASE1_CONCLUIDA.json descreve historicamente o estado anterior à autorização, não o estado atual; o estado atual está nesta entrega e em PROVENIENCIA_CONCLUSAO_FASE2.json.','','Versões, máquina, tempos e tentativas:','','```json',json.dumps(meta,ensure_ascii=False,indent=2),'```','','## Medidas','','| Caso | δJ | Anel médio | Mín. anel | Máx. anel | Resíduo | g_min | gap/2V | Fora dos anéis | Tempo (s) |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
for key,c in cs.items():lines.append(f"| {key} | {c['razao_dJ']:.16g} | {c['razao_anel_media']:.16g} | {c['razao_anel_min']:.12g} | {c['razao_anel_max']:.12g} | {c['residuo_real']:.5g} | {c['g_min_sobreposicao']:.10g} | {c['gap_sobre_2V']:.10g} | {c['residuo_fora_de_aneis_sobre_escala']:.6g} | {c['segundos']} |")
lines+=['','## Resultados','',f"[D] Decisão congelada: **{ev['decisao']}**. A2-R3={ev['A2_R3']}; A3-R3={ev['A3_R3']}. Ordens na janela fixa: δJ={ev['ordem_dJ']}; anel={ev['ordem_anel']}.",'','### Previsões escritas antes × medidas novas','','| λ | Desvio δJ medido | Previsão δJ explícita | Desvio anel medido | Previsão anel explícita |','|---|---:|---:|---:|---:|']
for row in predrows:lines.append(f"| {row['lambda']} | {row['desvio_dJ_medido']:.12g} | {row['previsao_dJ_numerica_prompt']} | {row['desvio_anel_medido']:.12g} | {row['previsao_anel_numerica_prompt']} |")
lines+=['','Células sem previsão numérica explícita são None na tabela; o modelo −0,09λ² e a série arredondada da R2 estão na tabela CSV completa. Não foram ajustadas previsões depois dos dados.','','### Série descritiva','', '[M] OLS sem pesos com os sete λ distintos do pré-registro. A nova medida em 0,05 entra uma única vez. A série e seu zero não participam da decisão.','','```json',json.dumps(ev['serie_descritiva'],ensure_ascii=False,indent=2),'```','','## Controles/convergência','','[F] Nove casos presentes: quatro cubos primários, quatro plaquetas e o segundo método. Os hashes congelados e todos os arquivos da Fase 1 foram conferidos. Os dados completos, autovalores de banda, faces e resíduos estão em resultados/B23aR3_checkpoint.json; tabelas CSV complementam a leitura.','','Avaliação congelada integral, incluindo V0–V3 e suas tolerâncias:','','```json',json.dumps(ev,ensure_ascii=False,indent=2),'```','','## Interpretação','']
if ev['decisao']=='A3_FECHADO':
 lines+=['[D] A2-R3 e A3-R3 passaram com validade V0–V3. Pela leitura combinada pré-registrada, B23a (R2+R3) passa a EMERGE e a correspondência Levin–Wen ↔ Capítulo 2 na rede regular fica CONFIRMADA (R2+R3). A R2 isolada continua tendo seu resultado histórico PARCIAL; esta é uma conclusão combinada, não uma alteração retrospectiva daquela avaliação.']
else:
 lines+=[f"[D] Não se obteve A3_FECHADO: resultado {ev['decisao']}; falhas de validade {ev.get('falhas',[])}. O resultado geral PARCIAL da B23-R2 continua valendo, conforme a regra anterior aos dados. Não se alterou janela, método ou tolerância para buscar aprovação."]
lines+=['','### E1–E3 da correspondência','','| Etapa | Estado e origem |','|---|---|']+[f'| {k} | {v} |' for k,v in ev['leitura_combinada'].items()]
lines+=['','[F] E1 é antecedente reportado no prompt; B23c não foi reexecutada. E2 refere-se à B23b-R2 anterior, não reexecutada em R3; a avaliação e o checkpoint completos dessa execução anterior são preservados em antecedentes/. E3 é a conclusão definida pela regra combinada acima.','','### Limites','','[M] Aglomerado finito, superfície fechada do cubo: teste de coeficientes locais; não demonstra a fase de Coulomb termodinâmica. [F] ħ já entra nas relações de comutação; não é derivado aqui. [?] Precisão dupla: abaixo de λ≈0,02 o desvio do anel se aproxima do ruído, e esta rodada não explorou essa região. [H] A correspondência física mais ampla do HRF permanece além desta bancada.','','### Reprodução e arquivos','','Use o protocolo congelado e LEIAME_B23aR3.md. A pasta inclui fontes, protocolo, fumaça, dados, logs, figura PNG/PDF, tabelas, versões, máquina, autorização e os ZIPs de entrada e pré-registro. O manifesto da Fase 1 foi preservado; MANIFEST_SHA256_RESULTADOS.json cobre esta entrega completa. Para refazer todos os casos sem reutilizar checkpoints, use uma cópia da pasta e remova apenas a pasta resultados/ dessa cópia, preservando as fontes congeladas.']
(R/name).write_text('\n'.join(lines)+'\n')
(R/'LEIA_PRIMEIRO_FASE2.md').write_text(f"# B23a-R3 — Fase 2 concluída\n\n[D] Resultado: {ev['decisao']}.\n\nLeia {name} e resultados/avaliacao_B23aR3.json. A Fase 1 foi preservada sem alterações; seus arquivos que dizem aguardar autorização são registros históricos. A autorização e os resultados completos da Fase 2 estão incluídos. Os cinco casos do cubo são efetivamente calculados aqui; os antecedentes E1 e E2 não foram refeitos.\n")
(R/'PROVENIENCIA_CONCLUSAO_FASE2.json').write_text(json.dumps({'concluido_em':now.isoformat(),'fase':2,'autorizacao_recebida':True,'casos':len(cs),'resultado':ev['decisao'],'fontes_e_protocolo_inalterados':True,'versao_matplotlib':matplotlib.__version__,'relatorio':name,'leitura_combinada':ev['leitura_combinada']},ensure_ascii=False,indent=2))
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256_RESULTADOS.json' and not p.name.endswith('.tmp')]
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(R/'MANIFEST_SHA256_RESULTADOS.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
archive=R.parent.parent/f'HRF_B23aR3_RESULTADOS_COMPLETOS_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[R/'MANIFEST_SHA256_RESULTADOS.json']):z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,h in manifest.items():assert hashlib.sha256(z.read(f'{R.name}/{p}')).hexdigest()==h
out={'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'relatorio':str(R/name),'resultado':ev['decisao'],'arquivos':len(files)+1,'data_local':now.strftime('%Y-%m-%d'),'stamp':stamp}
print(json.dumps(out,ensure_ascii=False,indent=2))
