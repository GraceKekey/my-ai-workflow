"""Documenta a fumaça concluída, congela a Fase 1 e cria o pacote. Não executa a Fase 2."""
from pathlib import Path
from zoneinfo import ZoneInfo
import json,hashlib,datetime,zipfile,importlib.metadata,subprocess
R=Path(__file__).resolve().parent.parent
load=lambda p:json.loads((R/p).read_text())
meta=load('fumaca/B23aR3_config_fumaca.json');cad=load('fumaca/B23aR3_checkpoint.json');refs=load('referencias/B23R2_cubo.json')
assert meta['parametros']['modo']=='fumaca' and meta['tentativas'][-1]['concluido']
expected={'cubo|S=1|lambda=0.1|metodo=chebyshev'}|{f'{n}|S=1|lambda={l:g}|metodo=chebyshev' for n in ('plaqueta','faixa') for l in (.07,.05,.035,.025)}
assert set(cad['casos'])==expected
assert not (R/'resultados').exists(),'Fase 2 não pode ter começado.'
checks={}
for f,h in meta['parametros']['fontes_sha256'].items():checks[f]=hashlib.sha256((R/'src'/f).read_bytes()).hexdigest()==h
cubo=cad['casos']['cubo|S=1|lambda=0.1|metodo=chebyshev'];ref=refs['casos']['0.1']
diffs={f:abs(cubo[f]-ref[f]) for f in ('razao_dJ','razao_anel_media')}
checks['cubo_conhecido_reproduz_razoes_ate_1e-9']=all(x<=1e-9 for x in diffs.values())
checks['residuos_fumaca_ate_1e-10']=all(v['residuo_real']<=1e-10 for v in cad['casos'].values())
checks['g_min_fumaca_ao_menos_0.5']=all(v['g_min_sobreposicao']>=.5 for v in cad['casos'].values())
checks['gap_fumaca_ao_menos_0.5']=all(v['gap_sobre_2V']>=.5 for v in cad['casos'].values())
assert all(checks.values()),checks
assert 'Todos os cinco ramos alcançados' in (R/'logs/teste_avaliador_sintetico.txt').read_text()
now=datetime.datetime.now(ZoneInfo('America/Sao_Paulo'));stamp=now.strftime('%Y-%m-%d_%H%M%S')
smoke=['# Fumaça B23a-R3 — fora da decisão','',f'Concluída/documentada em {now.isoformat()}.','', 'Somente cubo S=1, λ=0,1 (conhecido), plaqueta S=1 e faixa S=1 nos quatro λ. Os cubos λ=0,07,0,05,0,035,0,025 e o LOBPCG em 0,025 NÃO foram executados nesta fase. Nos aglomerados pequenos o primário usa automaticamente o caminho denso congelado.','', '| Caso | δJ | Anel médio | Resíduo real | g_min | gap/2V | Tempo (s) |','|---|---:|---:|---:|---:|---:|---:|']
for k,v in cad['casos'].items():smoke.append(f"| {k} | {v['razao_dJ']:.16g} | {v['razao_anel_media']:.16g} | {v['residuo_real']:.4g} | {v['g_min_sobreposicao']:.8g} | {v['gap_sobre_2V']:.8g} | {v['segundos']} |")
smoke+=['','Diferenças para a B23-R2 no cubo λ=0,1:','','```json',json.dumps(diffs,indent=2),'```','','Verificações operacionais desta fumaça (não são critérios novos de decisão da Fase 2):','','```json',json.dumps(checks,ensure_ascii=False,indent=2),'```','','O teste sintético, sem significado físico, alcançou INCONCLUSIVO, NAO_EMERGE, A3_FECHADO, A3_FALHA e PARCIAL, verificando também V0–V3, os limites inclusivos de V0, a cobertura, a não interferência da plaqueta na decisão e o log de desvio zero. Log completo em logs/teste_avaliador_sintetico.txt.']
(R/'FUMACA_B23aR3.md').write_text('\n'.join(smoke)+'\n')
orig=(R/'entrada/PROMPT_ORIGINAL.md').read_text()
def sec(n):
 text=orig.split(f'## {n}. ',1)[1];text=text.split('\n## ',1)[0]
 return text.split('\n',1)[1].strip()
protocol_name=f'HRF_B23aR3_PROTOCOLO_{stamp}.md'
p=['# HRF B23a-R3 — termo elétrico do cubo em λ pequeno','## Protocolo pré-registrado — Fase 1','',f'Data: {now.isoformat()} (America/Sao_Paulo).','', 'Autoria científica: Mario José do Canto Filho, MD. Prompt original: Claude (-clau), 20/10/2026 16h45. Implementação e fumaça: Codex.','', '**[D] Fase 2 não iniciada. Este pré-registro deve ser aprovado por Mario com “pode rodar” antes dos casos completos.**','', 'Marcas: [F] estabelecido · [M] modelo/bancada · [H] hipótese HRF · [?] aberto · [D] decisão. Esta bancada não injeta ondas.','', '## Objetivo','',sec(3),'','## Contexto conhecido','',sec(1),'','## Hipóteses e previsões','',sec(4),'','## Parâmetros','',sec(5),'','## Protocolo','', 'Fase 1: copiar as duas fontes científicas sem alterações, implementar apenas orquestração e avaliação, executar a fumaça permitida, testar o avaliador, registrar esta documentação e os hashes e parar. Nenhum caso completo é copiado da fumaça.','', 'Fase 2, somente após “pode rodar”: conferir hashes; executar python -I src/rodar_B23aR3.py completo; executar python -I src/avaliar_B23aR3.py resultados; elaborar figura e relatório sem modificar a decisão.','', 'Todas as chamadas científicas usam b23ar2_emergencia.caso(nome,S,lambda,metodo=...,V=1), sem alterações. O runner fixa uma thread BLAS antes de importar NumPy/SciPy. Um checkpoint JSON é sincronizado e substituído atomicamente após cada caso; relançar retoma apenas casos ausentes, verificando parâmetros e fontes. Tentativas e versões são registradas.','', '## Medidas','',sec(6),'','## Regras de decisão','',sec(7),'','### Convenções operacionais congeladas','', '- V0 e V3 abrangem todos os cinco casos do cubo, incluindo LOBPCG. V1 compara o Chebyshev em 0,05 com as razões integrais do checkpoint B23-R2 recebido (referencias/B23R2_cubo.json).','- V2 usa como denominador o desvio absoluto do método primário em 0,025, sem piso numérico. Se esse desvio for exatamente zero, a tolerância correspondente é zero: só igualdade exata passa.','- A2-R3 e as ordens usam apenas os três cubos Chebyshev da janela 0,05;0,035;0,025. A recusa grosseira NAO_EMERGE considera δJ e o anel médio dos casos do cubo, incluindo o segundo método. Mínimo e máximo do anel entram no espalhamento. A plaqueta é um controle descritivo de precisão, sem mudar a decisão do cubo.','- As comparações nos limites são inclusivas, exatamente como no prompt. Cobertura incompleta ou dados não finitos impedem uma avaliação válida e são classificados INCONCLUSIVO, com diagnóstico.','- A ordem é a inclinação OLS de ln|razão−1| contra ln λ, sem pesos, na janela fixa. Se algum desvio for exatamente zero, a ordem é indefinida (null), A3 não é demonstrado e não se acrescenta epsilon ao log.','- A série descritiva é OLS sem pesos em λ=0,4;0,2;0,1 (R2) e 0,07;0,05;0,035;0,025 (R3). O novo 0,05 aparece uma só vez; o antigo só recertifica. Relatam-se a,b,c, resíduos e todas as raízes reais positivas não triviais de a+bλ²+cλ⁴; o zero principal é o positivo mais próximo da origem. O ajuste e seus zeros não participam da decisão.','- As seis faces devem ser exatamente 0–5, não frustradas e ter movimentos de anel positivos. Não há teste de sinal novo: as previsões de sinal são relatadas, sem virar critério posterior.','- A fumaça não recebe decisão científica da Fase 2. O avaliador sintético é identificado como não físico. E1 e E2 são antecedentes reportados, não são reexecutados nesta bancada.','', '## Fumaça e teste do avaliador','', '\n'.join(smoke[2:]),'', '## Limites','',sec(10),'', '## Arquivos','', '- src/b23_modelo.py e src/b23ar2_emergencia.py: cópias idênticas e hashes originais verificados.','- src/rodar_B23aR3.py: orquestração e checkpoint.','- src/avaliar_B23aR3.py: regras, ordens, série descritiva e leitura combinada.','- src/teste_avaliador_sintetico_B23aR3.py: dados artificiais e testes de regras.','- referencias/B23R2_cubo.json: valores conhecidos extraídos do ZIP original autenticado por SHA-256.','- entrada/: ZIP original e prompt recebido; fumaca/: dados e versões reais; logs/: logs.','- LEIAME_B23aR3.md, FUMACA_B23aR3.md, hashes_antes_da_execucao.txt e MANIFEST_SHA256_ENTREGA.json.','', 'O congelamento abrange este protocolo, todo src/ e os dados de referência. Nenhuma regra será ajustada após os casos completos. Em falha, registrar e relatar; não corrigir silenciosamente.']
(R/protocol_name).write_text('\n'.join(p)+'\n')
versions=meta['tentativas'][-1]
(R/'requirements_execucao.txt').write_text(f"numpy=={versions['numpy']}\nscipy=={versions['scipy']}\nmatplotlib=={importlib.metadata.version('matplotlib')}\n")
readme=f'''# B23a-R3 — pré-registro da Fase 1

[D] A Fase 2 ainda NÃO foi executada. Aguardando Mario escrever “pode rodar”, conforme o prompt original.

Leia {protocol_name} e FUMACA_B23aR3.md. A fumaça tem nove casos fora da decisão nova; o único cubo é λ=0,1, conhecido. Os testes sintéticos não são resultados físicos. Não há pasta resultados/ nesta entrega.

Ambiente da fumaça: Python {versions['python']}, NumPy {versions['numpy']}, SciPy {versions['scipy']}; uma thread BLAS. As duas fontes científicas são cópias binárias idênticas às do ZIP de entrada (SHA-256 741c362382dc9426ece44d2c55a5bc964f12312248020cbdae3cc233666074bf).

## Somente depois da autorização — Fase 2

Use Python >=3.10 e as bibliotecas de requirements_execucao.txt num ambiente virtual. Na pasta raiz deste pacote:

```bash
sha256sum -c hashes_antes_da_execucao.txt > logs/verificacao_hashes_fase2.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -I src/rodar_B23aR3.py completo > logs/rodada_completa.txt 2>&1
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -I src/avaliar_B23aR3.py resultados > logs/avaliacao_completa.txt 2>&1
```

Se a conferência de hashes falhar, pare antes da execução. Confira o código de saída de cada comando, inclusive o runner: não confunda erro com conclusão. Se houver interrupção operacional, relançar o mesmo runner retoma casos gravados; não apague nem edite checkpoints. Se houver falha científica/numérica, relate sem alterar fontes ou limites. O runner não substitui a autorização humana: o comando completo só deve ser acionado após aprovação.

A avaliação grava resultados/avaliacao_B23aR3.json. Complete a entrega com a figura log-log e relatório solicitados no prompt (E1–E3), preservando os arquivos congelados. Não use fumaça como dados decisórios. Entregue a pasta inteira, logs, versões, hashes e o ZIP original de entrada.

## Custo

Cubo conhecido λ=0,1 na fumaça: {cubo['segundos']} s. Casos menores e tempos estão em FUMACA_B23aR3.md. A estimativa prévia da Fase 2 é 1–1,5 h; o custo em λ menores e de LOBPCG não foi medido nesta fase. Não executar cubos novos para refinar a estimativa antes da autorização.

## Integridade e estrutura

hashes_antes_da_execucao.txt congela protocolo, todo src/, referências e documentos relevantes. MANIFEST_SHA256_ENTREGA.json cobre o pacote inteiro (exceto ele mesmo). entrada/ preserva o ZIP e prompt originais. Não é necessário acessar o repositório para usar este pacote.
'''
(R/'LEIAME_B23aR3.md').write_text(readme)
state={'fase':1,'fase1_concluida':True,'fase2_iniciada':False,'autorizacao_fase2_pendente':True,'congelado_em':now.isoformat(),'protocolo':protocol_name,'verificacoes_fumaca':checks,'diferencas_cubo_conhecido':diffs,'casos_fumaca':len(cad['casos']),'casos_completos_executados':0,'testes_sinteticos':'todos os cinco ramos alcançados'}
(R/'FASE1_CONCLUIDA.json').write_text(json.dumps(state,ensure_ascii=False,indent=2))
freeze=[R/protocol_name,*sorted((R/'src').glob('*.py')),R/'referencias/B23R2_cubo.json',R/'LEIAME_B23aR3.md',R/'FUMACA_B23aR3.md',R/'requirements_execucao.txt',R/'entrada/PROMPT_ORIGINAL.md']
(R/'hashes_antes_da_execucao.txt').write_text('\n'.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(R)}' for p in freeze)+'\n')
(R/'logs/verificacao_hashes_fase1.txt').write_bytes(subprocess.check_output(['sha256sum','-c','hashes_antes_da_execucao.txt'],cwd=R))
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256_ENTREGA.json']
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(R/'MANIFEST_SHA256_ENTREGA.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
archive=R.parent.parent/f'HRF_B23aR3_PREREGISTRO_{stamp}.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[R/'MANIFEST_SHA256_ENTREGA.json']):z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(archive) as z:
 assert z.testzip() is None
 for p,h in manifest.items():assert hashlib.sha256(z.read(f'{R.name}/{p}')).hexdigest()==h
print(json.dumps({'zip':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'protocolo':str(R/protocol_name),'fase':1,'fase2_iniciada':False,'arquivos':len(files)+1},ensure_ascii=False,indent=2))
