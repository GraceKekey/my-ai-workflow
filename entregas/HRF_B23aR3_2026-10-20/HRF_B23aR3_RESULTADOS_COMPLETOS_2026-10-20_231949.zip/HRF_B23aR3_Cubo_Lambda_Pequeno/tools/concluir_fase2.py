"""Aguarda o runner, aplica o avaliador congelado e publica a entrega verificada. Não altera as fontes."""
from pathlib import Path
import os,time,json,subprocess,tempfile,hashlib,urllib.request,zipfile,io,datetime
R=Path(__file__).resolve().parent.parent;P='/workspace/my-ai-workflow/.venv/bin/python3'
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLCONFIGDIR='/tmp/hrf-b23ar3-mpl',XDG_CACHE_HOME='/tmp/hrf-b23ar3-cache',TZ='America/Sao_Paulo')
def log(msg):print(datetime.datetime.now(datetime.timezone.utc).isoformat(),msg,flush=True)
log('Aguardando os nove casos da Fase 2; nenhuma alteração nos critérios.')
while True:
 text=(R/'logs/rodada_completa.txt').read_text()
 if 'Traceback (most recent call last)' in text:raise RuntimeError('Runner falhou; preservar e relatar logs, sem alterar código.')
 if 'fim completo' in text:break
 time.sleep(30)
log('Runner concluído. Conferindo hashes e executando avaliador congelado.')
with (R/'logs/verificacao_hashes_apos_rodada.txt').open('w') as f:subprocess.run(['sha256sum','-c','hashes_antes_da_execucao.txt'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
with (R/'logs/avaliacao_completa.txt').open('w') as f:subprocess.run([P,'-I','src/avaliar_B23aR3.py','resultados'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
res=subprocess.check_output([P,'-I','tools/preparar_resultados_fase2.py'],cwd=R,env=env).decode();meta=json.loads(res)
(R.parent.parent/'HRF_B23aR3_RESULTADOS_EMPACOTAMENTO.json').write_text(res)
log('Relatório e ZIP completos; publicando em branch independente.')
repo=Path('/workspace/my-ai-workflow');date=meta['data_local'].replace('-','');branch='resultados-hrf-b23ar3-'+date;folder='entregas/HRF_B23aR3_'+meta['data_local'];archive=Path(meta['zip']);report=Path(meta['relatorio'])
with tempfile.TemporaryDirectory(prefix='b23ar3-result-publish-') as td:
 ge=env.copy();ge.update(GIT_INDEX_FILE=td+'/index',GIT_AUTHOR_NAME='Codex',GIT_AUTHOR_EMAIL='codex@openai.com',GIT_COMMITTER_NAME='Codex',GIT_COMMITTER_EMAIL='codex@openai.com')
 def git(*args,input=None):return subprocess.check_output(['git','-C',str(repo),*args],input=input,env=ge).decode().strip()
 if git('ls-remote','origin','refs/heads/'+branch):raise RuntimeError('Branch existente; preservar e revisar antes de publicar.')
 git('fetch','--no-tags','origin','HEAD');git('read-tree',git('rev-parse','FETCH_HEAD'));parent=git('rev-parse','FETCH_HEAD')
 for p in (archive,report):
  blob=git('hash-object','-w','--stdin',input=p.read_bytes());git('update-index','--add','--cacheinfo',f'100644,{blob},{folder}/{p.name}')
 commit=git('commit-tree',git('write-tree'),'-p',parent,'-m','Disponibiliza execução completa HRF B23a-R3 com regras congeladas')
 git('push','origin',commit+':refs/heads/'+branch)
 url=f'https://raw.githubusercontent.com/GraceKekey/my-ai-workflow/{commit}/{folder}/{archive.name}'
 with urllib.request.urlopen(url,timeout=60) as response:payload=response.read();status=response.status
 assert status==200 and len(payload)==meta['bytes'] and hashlib.sha256(payload).hexdigest()==meta['sha256']
 with zipfile.ZipFile(io.BytesIO(payload)) as z:assert z.testzip() is None
 meta.update(commit=commit,branch=branch,download_url=url,http_status=status,download_verified=True)
 (R.parent.parent/'HRF_B23aR3_RESULTADOS_PUBLICACAO.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2));log(json.dumps(meta,ensure_ascii=False))
