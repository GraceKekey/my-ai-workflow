# B23a-R3 — pré-registro da Fase 1

[D] A Fase 2 ainda NÃO foi executada. Aguardando Mario escrever “pode rodar”, conforme o prompt original.

Leia HRF_B23aR3_PROTOCOLO_2026-10-20_181105.md e FUMACA_B23aR3.md. A fumaça tem nove casos fora da decisão nova; o único cubo é λ=0,1, conhecido. Os testes sintéticos não são resultados físicos. Não há pasta resultados/ nesta entrega.

Ambiente da fumaça: Python 3.12.14, NumPy 2.2.6, SciPy 1.15.3; uma thread BLAS. As duas fontes científicas são cópias binárias idênticas às do ZIP de entrada (SHA-256 741c362382dc9426ece44d2c55a5bc964f12312248020cbdae3cc233666074bf).

## Somente depois da autorização — Fase 2

Use Python >=3.10 e as bibliotecas de requirements_execucao.txt num ambiente virtual. Na pasta raiz deste pacote:

```bash
sha256sum -c hashes_antes_da_execucao.txt > logs/verificacao_hashes_fase2.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -I src/rodar_B23aR3.py completo > logs/rodada_completa.txt 2>&1
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 python -I src/avaliar_B23aR3.py resultados > logs/avaliacao_completa.txt 2>&1
```

Se a conferência de hashes falhar, pare antes da execução. Confira o código de saída de cada comando, inclusive o runner: não confunda erro com conclusão. Se houver interrupção operacional, relançar o mesmo runner retoma casos gravados; não apague nem edite checkpoints. Se houver falha científica/numérica, relate sem alterar fontes ou limites. O runner não substitui a autorização humana: o comando completo só deve ser acionado após aprovação.

A avaliação grava resultados/avaliacao_B23aR3.json. Complete a entrega com a figura log-log e relatório solicitados no prompt (E1–E3), preservando os arquivos congelados. Não use fumaça como dados decisórios. Entregue a pasta inteira, logs, versões, hashes e o ZIP original de entrada.

## Custo

Cubo conhecido λ=0,1 na fumaça: 486.4 s. Casos menores e tempos estão em FUMACA_B23aR3.md. A estimativa prévia da Fase 2 é 1–1,5 h; o custo em λ menores e de LOBPCG não foi medido nesta fase. Não executar cubos novos para refinar a estimativa antes da autorização.

## Integridade e estrutura

hashes_antes_da_execucao.txt congela protocolo, todo src/, referências e documentos relevantes. MANIFEST_SHA256_ENTREGA.json cobre o pacote inteiro (exceto ele mesmo). entrada/ preserva o ZIP e prompt originais. Não é necessário acessar o repositório para usar este pacote.
