# Fumaça B23a-R3 — fora da decisão

Concluída/documentada em 2026-10-20T18:11:05.982225-03:00.

Somente cubo S=1, λ=0,1 (conhecido), plaqueta S=1 e faixa S=1 nos quatro λ. Os cubos λ=0,07,0,05,0,035,0,025 e o LOBPCG em 0,025 NÃO foram executados nesta fase. Nos aglomerados pequenos o primário usa automaticamente o caminho denso congelado.

| Caso | δJ | Anel médio | Resíduo real | g_min | gap/2V | Tempo (s) |
|---|---:|---:|---:|---:|---:|---:|
| cubo|S=1|lambda=0.1|metodo=chebyshev | 1.000043263214373 | 0.9990928117025215 | 7.41e-15 | 0.98506091 | 0.87642304 | 486.4 |
| plaqueta|S=1|lambda=0.07|metodo=chebyshev | 0.9992076725055774 | 0.9970632932659729 | 2.195e-16 | 0.99755287 | 0.95128746 | 0.0 |
| plaqueta|S=1|lambda=0.05|metodo=chebyshev | 0.9995960483224864 | 0.9985008582481536 | 2.117e-16 | 0.99875075 | 0.96503861 | 0.0 |
| plaqueta|S=1|lambda=0.035|metodo=chebyshev | 0.9998021403336833 | 0.9992652061934786 | 4.176e-16 | 0.99938768 | 0.9754419 | 0.0 |
| plaqueta|S=1|lambda=0.025|metodo=chebyshev | 0.9998990695127266 | 0.9996250536889424 | 2.593e-16 | 0.99968755 | 0.98241878 | 0.0 |
| faixa|S=1|lambda=0.07|metodo=chebyshev | 0.9994795472743772 | 0.9982814859477438 | 9.456e-16 | 0.99571857 | 0.93376505 | 2.3 |
| faixa|S=1|lambda=0.05|metodo=chebyshev | 0.999734847808277 | 0.9991232421762255 | 5.819e-16 | 0.99781409 | 0.95260754 | 2.3 |
| faixa|S=1|lambda=0.035|metodo=chebyshev | 0.9998701745553428 | 0.9995703950212935 | 5.929e-16 | 0.99892851 | 0.96678737 | 2.3 |
| faixa|S=1|lambda=0.025|metodo=chebyshev | 0.9999337861976317 | 0.9997808149733076 | 6.204e-16 | 0.99945323 | 0.97626028 | 3.9 |

Diferenças para a B23-R2 no cubo λ=0,1:

```json
{
  "razao_dJ": 4.440892098500626e-16,
  "razao_anel_media": 1.3511414209688155e-13
}
```

Verificações operacionais desta fumaça (não são critérios novos de decisão da Fase 2):

```json
{
  "b23_modelo.py": true,
  "b23ar2_emergencia.py": true,
  "cubo_conhecido_reproduz_razoes_ate_1e-9": true,
  "residuos_fumaca_ate_1e-10": true,
  "g_min_fumaca_ao_menos_0.5": true,
  "gap_fumaca_ao_menos_0.5": true
}
```

O teste sintético, sem significado físico, alcançou INCONCLUSIVO, NAO_EMERGE, A3_FECHADO, A3_FALHA e PARCIAL, verificando também V0–V3, os limites inclusivos de V0, a cobertura, a não interferência da plaqueta na decisão e o log de desvio zero. Log completo em logs/teste_avaliador_sintetico.txt.
