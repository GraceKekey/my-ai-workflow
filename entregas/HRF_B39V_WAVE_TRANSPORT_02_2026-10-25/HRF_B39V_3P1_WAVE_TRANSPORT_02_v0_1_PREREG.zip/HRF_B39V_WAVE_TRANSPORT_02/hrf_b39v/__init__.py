"""[M] HRF classical scalar wave transport; no computation on import."""
__version__ = '0.1.0'
BENCHMARK = 'HRF-B39V-3P1-WAVE-TRANSPORT-02'
