"""[M] Horizontal planes and metric-aware energy/current exports from real frames."""
from pathlib import Path
import csv
import numpy as np
import matplotlib.pyplot as plt
from hrf_vertical.common import save_npz, save_json
from hrf_vertical.transport import cylindrical_current


def additional_figures(ds, output, time, phi, vmax):
    from hrf_vertical.figures import finish
    out = Path(output)
    x, y, z = ds.axes
    selected = np.unique(np.argmin(abs(z[:, None] - ds.grid['slice_actual_z'][None, :]), axis=0))
    # The saved z coordinates are actual mesh planes, never requested-but-unavailable heights.
    if len(selected) > 7:
        selected = selected[np.unique(np.linspace(0, len(selected)-1, 7).astype(int))]
    fig, axes = plt.subplots(1, len(selected), figsize=(4*len(selected), 4), squeeze=False)
    for ax, k in zip(axes.flat, selected):
        ax.imshow(phi[:, :, k].T, origin='lower', extent=[x[0],x[-1],y[0],y[-1]],
                  vmin=-vmax, vmax=vmax, cmap='RdBu_r', aspect='equal')
        ax.set(xlabel='x', ylabel='y', title=f'z={z[k]:g}')
        with (out / f'xy_zindex_{k:04d}.csv').open('w', newline='', encoding='utf-8') as file:
            w=csv.writer(file); w.writerow(['x','y','z','phi'])
            w.writerows((xx,yy,z[k],phi[i,j,k]) for i,xx in enumerate(x) for j,yy in enumerate(y))
    finish(fig, out/'FigureC_horizontal_planes.png', f'C — cortes xy em alturas reais, t={time:g}; escala comum')
    # Streaming: reconstruct at most one observer and inspect one volume at a time.
    match = None
    for t, energy, current in ds.flow_frames():
        if abs(t-time) < 1e-10:
            match = energy, current
            break
    if match is None:
        raise ValueError('selected energy frame missing')
    energy, current = match
    gamma = ds.metric_grid()
    xyz = np.stack(np.meshgrid(x,y,z,indexing='ij'),axis=-1)
    components = cylindrical_current(xyz,current,gamma)
    k=int(np.argmin(abs(z))); midy=int(np.argmin(abs(y)))
    fig, axes=plt.subplots(2,2,figsize=(12,9))
    axes[0,0].imshow(energy[:,:,k].T,origin='lower',extent=[x[0],x[-1],y[0],y[-1]],cmap='magma',aspect='auto')
    axes[0,0].set(title=f'energia por volume próprio; z={z[k]:g}',xlabel='x',ylabel='y')
    for ax,key,title in zip((axes[0,1],axes[1,0],axes[1,1]),('radial','azimuthal','vertical'),('J_r','J_theta','J_z normal ao plano')):
        values=components[key][:,midy,:]
        scale=max(float(abs(values).max()),1e-30)
        ax.imshow(values.T,origin='lower',extent=[x[0],x[-1],z[0],z[-1]],vmin=-scale,vmax=scale,cmap='RdBu_r',aspect='auto')
        ax.set(title=title+'; observador Euleriano ortonormal',xlabel='x',ylabel='z')
    finish(fig,out/'FigureDF_energy_current_maps.png',f'D/F — energia e correntes físicas locais, t={time:g}')
    save_npz(out/'field_snapshot.npz',t=time,x=x,y=y,z=z,phi=phi,H=ds.grid['H'],energy_density=energy,
             current_coordinate_contravariant=current,Jr=components['radial'],Jtheta=components['azimuthal'],
             Jz_normal=components['vertical'],receiver_xyz=ds.grid['receiver_xyz'])
    save_json(out/'data_export.json',dict(source_case=str(ds.folder),source_time=time,
              data='field_snapshot.npz and xy_zindex_*.csv; no smoothing/downsampling of numerical diagnostic values',
              horizontal_planes=z[selected],visualization_only=True,new_PDE_runs=0))
