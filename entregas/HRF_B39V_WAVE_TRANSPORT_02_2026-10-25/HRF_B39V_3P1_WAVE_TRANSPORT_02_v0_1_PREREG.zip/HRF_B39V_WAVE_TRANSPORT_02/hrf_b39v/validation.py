"""Static validation and SHA-256 auditing; never construct or evolve a PDE mesh."""
import json
from pathlib import Path
from hrf_vertical.common import ROOT, sha
from hrf_vertical.config import load, frozen_checks, estimate_case, readiness


def validate_all():
    rows = []
    for path in sorted((ROOT / 'configs').glob('*.json')):
        if path.name == 'gates.json':
            continue
        try:
            c = load(path)
            checks = frozen_checks(c)
            rows.append(dict(preset=c['id'], checks=checks, dependencies=readiness(c),
                             cases=len(c['cases']),
                             resolution=[dict(case_id=x['case_id'], adequate=estimate_case(x).get('planning_resolution_adequate')) for x in c['cases']],
                             valid=not checks['missing'] and not checks['changed']))
        except (ValueError, KeyError, OSError) as error:
            rows.append(dict(preset=path.stem, valid=False, error=str(error)))
    status = json.loads((ROOT / 'PREREG_STATUS.json').read_text(encoding='utf-8'))
    return dict(status='PASS_SOFTWARE' if rows and all(x['valid'] for x in rows) else 'FAIL_SOFTWARE',
                scope='static structure, configurations and frozen file integrity; no physical experiment',
                presets=rows, preregistration_state=status['state'], new_scientific_runs=0)
