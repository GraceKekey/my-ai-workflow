"""Public WT-02 names, preserving the detailed inherited evidence and its scope."""
def from_analysis(summary):
    old = summary['gates']
    information = summary['information']['spatial_resolution_adequate']
    return {
        'PASS_ZSCAN_PIPELINE': summary['diagnostic_records'] >= 3,
        'PASS_ENERGY_BALANCE': old['energy'] == 'PASS_ENERGY_BALANCE',
        'PASS_ANGULAR_DECOMPOSITION': old['phase'] == 'PASS_PHASE_DIAGNOSTIC',
        'PASS_RECEIVER_SPECTRAL_PIPELINE': old['receiver'] == 'PASS_RECEIVER_SPECTRAL_DIAGNOSTIC',
        'PASS_PARITY_CONTROL': old['vertical_symmetry'] == 'PASS_VERTICAL_SYMMETRY_CONTROL',
        'ANGULAR_STRUCTURE_DETECTED': information and summary['evidence']['ANGULAR_PHASE_STRUCTURE'],
        'VERTICAL_TRANSPORT_DETECTED': information and summary['evidence']['VERTICAL_ENERGY_TRANSPORT'],
        'AZIMUTHAL_CIRCULATION_DETECTED': information and summary['evidence']['AZIMUTHAL_ENERGY_CIRCULATION'],
        'HELICAL_PHASE_CANDIDATE': information and summary['evidence']['phase_candidate'] == 'HELICAL_PHASE_CANDIDATE',
        'transport_interpretation': summary['structure']['status'],
        'domain': 'W; classical scalar, prescribed static geometry. Pipeline PASS is software/diagnostic only.',
        'historical_replication': 'BLOCKED_HISTORICAL_REPLICATION',
        'holography': 'BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY',
    }
