"""Explicit CLI. Installation/import/validate/plan never evolve a field."""
import argparse
import contextlib
import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from datetime import datetime, timezone

# Limit numerical libraries before their first import.
for _key in ('OPENBLAS_NUM_THREADS', 'OMP_NUM_THREADS', 'MKL_NUM_THREADS'):
    os.environ[_key] = '1'
os.environ.setdefault('MPLCONFIGDIR', str(Path(tempfile.gettempdir()) / 'hrf-wt02-mpl'))
os.environ.setdefault('XDG_CACHE_HOME', str(Path(tempfile.gettempdir()) / 'hrf-wt02-cache'))


def technical_tests(output):
    from hrf_vertical.common import ROOT, save_json, code_hash, sha
    from . import BENCHMARK
    out = Path(output)
    out.mkdir(parents=True, exist_ok=False)
    stream = io.StringIO()
    gate_hash_before=sha(ROOT/'configs/gates.json')
    previous = os.environ.get('HRF_WT02_TECHNICAL_OUTPUT')
    os.environ['HRF_WT02_TECHNICAL_OUTPUT'] = str(out)
    try:
        with contextlib.redirect_stdout(stream), contextlib.redirect_stderr(stream):
            suite = unittest.defaultTestLoader.discover(str(ROOT / 'tests'), pattern='test_*.py')
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    finally:
        if previous is None:
            os.environ.pop('HRF_WT02_TECHNICAL_OUTPUT', None)
        else:
            os.environ['HRF_WT02_TECHNICAL_OUTPUT'] = previous
    (out / 'test.log').write_text(stream.getvalue(), encoding='utf-8')
    report = dict(benchmark=BENCHMARK, status='PASS_SOFTWARE' if result.wasSuccessful() else 'FAIL_SOFTWARE',
                  tests_run=result.testsRun, failures=len(result.failures), errors=len(result.errors), skipped=len(result.skipped),
                  scope='algebra, synthetic controls and bounded analytical reference integrations only',
                  scientific_scenarios_executed=0, code_sha256=code_hash(),
                  UTC=datetime.now(timezone.utc).isoformat(), python=sys.version,
                  gates_unchanged_during_test_run=gate_hash_before==sha(ROOT/'configs/gates.json'),
                  gates_sha256=gate_hash_before,
                  preregistration_manifest_present=(ROOT/'hashes_antes_da_execucao.txt').exists(),
                  reference_gate='PASS_REFERENCE_TESTS' if result.wasSuccessful() else 'FAIL_NUMERICAL')
    save_json(out / 'summary.json', report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    if not result.wasSuccessful():
        print(stream.getvalue())
    return 0 if result.wasSuccessful() else 1


def main(argv=None):
    from hrf_vertical.common import ROOT
    args = list(sys.argv[1:] if argv is None else argv)
    if not args:
        print('Commands: validate, plan, test, run --execute, analyze, visualize; see documentation/HOW_TO_RUN.md')
        return 0
    command = args[0]
    if command == 'validate':
        p = argparse.ArgumentParser(); p.add_argument('--output')
        a = p.parse_args(args[1:])
        from .validation import validate_all
        from hrf_vertical.common import save_json
        report = validate_all()
        if a.output:
            save_json(a.output, report)
        print(json.dumps(report, ensure_ascii=False, indent=2))
        return 0 if report['status'] == 'PASS_SOFTWARE' else 1
    if command == 'test':
        p = argparse.ArgumentParser(); p.add_argument('--output')
        a = p.parse_args(args[1:])
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d_%H%M%S_%f')
        return technical_tests(a.output or ROOT.parent / ('HRF_WT02_TECHNICAL_TESTS_' + stamp))
    if command in ('plan', 'run'):
        if '--config' not in args:
            raise SystemExit('--config is required')
        index = args.index('--config') + 1
        if not Path(args[index]).is_file() and (ROOT / args[index]).is_file():
            args[index] = str(ROOT / args[index])
        if '--output' not in args:
            args += ['--output', str(ROOT / 'results' / Path(args[index]).stem)]
    elif command == 'analyze':
        if '--input' in args and '--output' not in args:
            source = Path(args[args.index('--input') + 1])
            args += ['--output', str(ROOT / 'analysis' / source.name)]
    elif command == 'visualize':
        args[0] = 'figures'
        if '--input' not in args:
            raise SystemExit('--input is required')
        source = Path(args[args.index('--input') + 1])
        if '--analysis' not in args:
            args += ['--analysis', str(ROOT / 'analysis')]
        if '--output' not in args:
            args += ['--output', str(ROOT / 'figures' / source.name)]
    from hrf_vertical.cli import main as inherited_main
    return inherited_main(args)


if __name__ == '__main__':
    raise SystemExit(main())
