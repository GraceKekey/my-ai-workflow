"""Data-derived numerical evidence; a plan or an input Boolean cannot certify physics."""
from pathlib import Path
import json
import numpy as np
from scipy.interpolate import RegularGridInterpolator
from .dataset import Dataset
from .common import relative,sha,save_json

def differences(a,b,prefix=''):
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        for key in sorted(set(a)|set(b)):
            if key in ('case_id','comparison_group','classification','resources_predicted','code_sha256','status','initial_expected_frequency'):continue
            if key not in a or key not in b:out.append(prefix+key)
            else:out.extend(differences(a[key],b[key],prefix+key+'.'))
        return out
    return [] if a==b else [prefix.rstrip('.')]

def standing_solution(axes,t,mass):
    xyz=np.stack(np.meshgrid(*axes,indexing='ij'),axis=-1)
    k=np.array([np.pi/np.ptp(a) for a in axes]);q0=np.prod(np.sin((xyz-np.array([a[0] for a in axes]))*k),axis=-1)
    omega=np.sqrt(np.sum(k*k)+mass*mass)
    return q0*np.cos(omega*t),omega

def reference_error(folder):
    ds=Dataset(folder)
    if ds.config.get('initial')!='standing_mode':raise ValueError('not an analytical reference case')
    measured=[]
    for t,d in ds.volumes():
        exact,omega=standing_solution(ds.axes,t,ds.config['field']['mass']);w=ds.grid['node_volume']
        scale=max(float(np.sum(w)),1e-30)
        measured.append(float(np.sqrt(np.sum(w*(d['phi']-exact)**2)/scale)))
    return dict(case=ds.folder.name,max_absolute_RMS=float(max(measured)),field_amplitude_normalization=1.,mode_omega=float(omega),sha256=sha(ds.folder/'case.json'))

def compare_cases(first,second,expected_change,roi=None):
    a=Dataset(first);b=Dataset(second);changes=differences(a.config,b.config)
    def allowed(path):return any(path==p or path.startswith(p+'.') for p in expected_change)
    if any(not allowed(p) for p in changes):raise ValueError('confounded comparison: '+', '.join(changes))
    if not changes:raise ValueError('no independently changed parameter')
    t1=np.array([r['t'] for r in a.catalog if a.old or r.get('volume')]);t2=np.array([r['t'] for r in b.catalog if b.old or r.get('volume')])
    if len(t1)!=len(t2) or not np.allclose(t1,t2):raise ValueError('comparison requires identical recorded physical times')
    axes=a.axes
    bounds=np.array([[max(x[0],y[0]),min(x[-1],y[-1])] for x,y in zip(a.axes,b.axes)]) if roi is None else np.asarray(roi)
    masks=[(v>=bb[0])&(v<=bb[1]) for v,bb in zip(axes,bounds)];points=np.stack(np.meshgrid(*[v[m] for v,m in zip(axes,masks)],indexing='ij'),axis=-1)
    numerator=denominator=0.;energy_diffs=[]
    for (t,fa),(tb,fb) in zip(a.volumes(),b.volumes()):
        field=fa['phi'][np.ix_(*masks)];other=RegularGridInterpolator(b.axes,fb['phi'],bounds_error=True)(points)
        numerator+=float(np.sum((field-other)**2));denominator+=float(np.sum(field**2))
    ea=a.observations()['energy'];eb=b.observations()['energy'];energy_error=relative(ea,eb) if ea.shape==eb.shape else None
    return dict(first=str(a.folder),second=str(b.folder),first_sha256=sha(a.folder/'case.json'),second_sha256=sha(b.folder/'case.json'),changed=changes,
                spacetime_field_relative_L2=float(np.sqrt(numerator/max(denominator,1e-30))),global_energy_relative_L2=energy_error,ROI=bounds.tolist(),
                interpretation='field norm at common coordinates and recorded times; observational convergence is tested separately')

def compare_observables(first_analysis,second_analysis):
    a=Path(first_analysis);b=Path(second_analysis)
    summaries=[json.loads((p/'summary.json').read_text()) for p in (a,b)]
    with np.load(a/'vertical.npz',allow_pickle=False) as va,np.load(b/'vertical.npz',allow_pickle=False) as vb:
        if not np.array_equal(va['times'],vb['times']):raise ValueError('observable comparison requires identical physical sample times')
        keys=[k for k in va.files if k in vb.files and k.startswith('flux__') and 'cumulative_' in k]
        flux_error=max((relative(va[k],vb[k]) for k in keys),default=np.inf)
        asym_error=relative(va['asymmetry'],vb['asymmetry'])
    with np.load(a/'receiver_spectra.npz',allow_pickle=False) as ra,np.load(b/'receiver_spectra.npz',allow_pickle=False) as rb:
        arrival_a=ra['threshold_arrival'];arrival_b=rb['threshold_arrival'];valid=np.isfinite(arrival_a)&np.isfinite(arrival_b)
        arrival_error=relative(arrival_a[valid],arrival_b[valid]) if valid.any() else np.inf
        response_error=relative(ra['response_max'],rb['response_max'])
        peak_a=ra['received_max'];peak_b=rb['received_max'];ratio=np.divide(peak_b,peak_a,out=np.full_like(peak_a,np.nan),where=peak_a>1e-14)
    preserved=summaries[0]['evidence']==summaries[1]['evidence'] and summaries[0]['structure']['status']==summaries[1]['structure']['status']
    return dict(arrival_relative_change=arrival_error,flux_relative_change=flux_error,receiver_response_relative_change=response_error,
                asymmetry_relative_change=asym_error,gate_classification_preserved=preserved,incident_peak_ratio_per_receiver=ratio,
                ratio_interpretation='continuous enhancement/suppression at the same receiver; no recalibrated relay threshold')

def reference_evidence(spatial,temporal,gates):
    if len(spatial)!=3 or len(temporal)!=3:raise ValueError('three spatial and three temporal references required')
    errors=[reference_error(p) for p in spatial];datasets=[Dataset(p) for p in spatial]
    h=np.array([max(np.diff(a).max() for a in d.axes) for d in datasets]);err=np.array([e['max_absolute_RMS'] for e in errors])
    order_space=float(np.polyfit(np.log(h),np.log(err),1)[0]) if np.all(err>0) else None
    tdata=[Dataset(p) for p in temporal];dt=np.array([d.meta['dt'] for d in tdata]);dif=[]
    for i in (0,1):dif.append(compare_cases(temporal[i],temporal[i+1],['field.dt'])['spacetime_field_relative_L2'])
    order_time=observed_order(*dif,ratio=dt[0]/dt[1]) if np.isclose(dt[0]/dt[1],dt[1]/dt[2]) else None
    measures=dict(max_mode_RMS=float(max(err)),spatial_order=order_space,temporal_order=order_time)
    valid=order_space is not None and order_time is not None and max(err)<=gates['reference_mode_RMS_max'] and order_space>=gates['spatial_order_min'] and order_time>=gates['temporal_order_min']
    return dict(status='PASS_NUMERICAL_REFERENCE' if valid else 'FAIL_NUMERICAL',measurements=measures,spatial=errors,effective_dt=dt,
                source_files=[dict(path=str(Path(p)/'case.json'),sha256=sha(Path(p)/'case.json')) for p in spatial+temporal])

def pair_evidence(first,second,first_analysis,second_analysis,allowed,gate_name,gates):
    field=compare_cases(first,second,allowed);obs=compare_observables(first_analysis,second_analysis)
    measures=dict(field_relative_change=field['spacetime_field_relative_L2'],**obs)
    # Independent receiver convergence also has to hold; a low field error is insufficient.
    measures['gate_classification_preserved']=measures['gate_classification_preserved'] and obs['receiver_response_relative_change']<=gates['receiver_response_relative_max']
    files=[Path(first)/'case.json',Path(second)/'case.json',Path(first_analysis)/'summary.json',Path(second_analysis)/'summary.json']
    return {gate_name:dict(measurements=measures,source_files=[dict(path=str(p),sha256=sha(p)) for p in files])}

def basic_evidence(folder,analysis,gates):
    ds=Dataset(folder);analysis=Path(analysis);obs=ds.observations();p=json.loads((analysis/'nematic_and_parity.json').read_text());parity=[r for r in p['parity'] if r['status']=='MEASURED']
    source=[dict(path=str(analysis/'nematic_and_parity.json'),sha256=sha(analysis/'nematic_and_parity.json')),dict(path=str(ds.folder/'observations.npz'),sha256=sha(ds.folder/'observations.npz'))]
    result={}
    if 'balance_relative_error' in obs:result['PASS_ENERGY_BALANCE']=dict(measurements=dict(relative_error=float(np.max(obs['balance_relative_error']))),source_files=source)
    if parity:result['PASS_VERTICAL_SYMMETRY_CONTROL']=dict(measurements={k:max(r[k] for r in parity) for k in ('phi','energy','current')},source_files=source)
    return result

def flowline_evidence(first_analysis,second_analysis,gates):
    a=Path(first_analysis);b=Path(second_analysis);changes=[];preserved=True;files=[]
    for sign in (-1,1):
        pa=a/f'flow_gate_{sign:+d}.json';pb=b/f'flow_gate_{sign:+d}.json'
        if not pa.exists() or not pb.exists():continue
        ra=json.loads(pa.read_text());rb=json.loads(pb.read_text())
        if 'sampled_flux_weight_fraction' not in ra or 'sampled_flux_weight_fraction' not in rb:continue
        fa=ra['sampled_flux_weight_fraction'];fb=rb['sampled_flux_weight_fraction'];changes.append(abs(fa-fb));preserved=preserved and ((fa>=gates['candidate_weight_fraction_min'])==(fb>=gates['candidate_weight_fraction_min']))
        files.extend([pa,pb])
    if len(changes)!=2:return {}
    return {'FLOWLINE_REFINEMENT':dict(measurements=dict(fraction_absolute_change=max(changes),candidate_classification_preserved=preserved),source_files=[dict(path=str(p),sha256=sha(p)) for p in files])}

def observed_order(d01,d12,ratio=2.):
    if d01<=0 or d12<=0 or ratio<=1:return None
    return float(np.log(d01/d12)/np.log(ratio))

def certify(evidence,gates):
    # Evidence must consist of calculated measurements with source-file checksums.
    out={k:False for k in ('PASS_NUMERICAL_REFERENCE','PASS_ENERGY_BALANCE','PASS_VERTICAL_SYMMETRY_CONTROL','SPATIAL_CONVERGENCE','TEMPORAL_CONVERGENCE','BOUNDARY_ROBUSTNESS','FLOWLINE_REFINEMENT')}
    for name,item in evidence.items():
        if name not in out:continue
        required=item.get('source_files',[])
        if not required or any(not Path(x['path']).is_file() or sha(x['path'])!=x['sha256'] for x in required):continue
        measurements=item.get('measurements',{})
        def number(key,default=np.inf):
            value=measurements.get(key)
            return float(value) if isinstance(value,(float,int)) and np.isfinite(value) else default
        if name=='PASS_NUMERICAL_REFERENCE':out[name]=number('max_mode_RMS')<=gates['reference_mode_RMS_max'] and number('spatial_order',-np.inf)>=gates['spatial_order_min'] and number('temporal_order',-np.inf)>=gates['temporal_order_min']
        elif name=='PASS_ENERGY_BALANCE':out[name]=number('relative_error')<=gates['energy_relative_max']
        elif name=='PASS_VERTICAL_SYMMETRY_CONTROL':out[name]=all(number(key)<=gates['vertical_'+key+'_relative_max'] for key in ('phi','energy','current'))
        elif name in ('SPATIAL_CONVERGENCE','TEMPORAL_CONVERGENCE','BOUNDARY_ROBUSTNESS'):
            out[name]=number('field_relative_change')<=gates['field_control_relative_max'] and number('arrival_relative_change')<=gates['arrival_relative_max'] and number('flux_relative_change')<=gates['flux_control_relative_max'] and measurements.get('gate_classification_preserved') is True
        elif name=='FLOWLINE_REFINEMENT':out[name]=number('fraction_absolute_change')<=gates['curve_fraction_change_max'] and measurements.get('candidate_classification_preserved') is True
    return out
