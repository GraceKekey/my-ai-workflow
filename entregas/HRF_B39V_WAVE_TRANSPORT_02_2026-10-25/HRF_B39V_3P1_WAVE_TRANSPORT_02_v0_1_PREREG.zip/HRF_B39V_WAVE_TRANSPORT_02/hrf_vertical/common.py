"""Small, deterministic, strict and portable IO utilities."""
from pathlib import Path
import hashlib, json, os, tempfile
import numpy as np

ROOT = Path(__file__).resolve().parents[1]

def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''): h.update(chunk)
    return h.hexdigest()

def clean(x):
    if isinstance(x, dict): return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)): return [clean(v) for v in x]
    if isinstance(x, np.ndarray): return clean(x.tolist())
    if isinstance(x, np.generic): return clean(x.item())
    if isinstance(x, float) and not np.isfinite(x): return None
    if isinstance(x, Path): return str(x)
    return x

def save_json(path, obj):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name+'.', dir=path.parent)
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(clean(obj), f, indent=2, ensure_ascii=False, allow_nan=False)
            f.write('\n'); f.flush(); os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def save_npz(path, **arrays):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix=path.name+'.', suffix='.npz', dir=path.parent)
    try:
        with os.fdopen(fd, 'wb') as f:
            np.savez_compressed(f, **arrays); f.flush(); os.fsync(f.fileno())
        os.replace(temp, path)
    finally:
        if os.path.exists(temp): os.unlink(temp)

def code_hash():
    h = hashlib.sha256()
    files = [p for folder in ('hrf_b39v','hrf_vertical','hrf_integral','historico/B39V/src','scripts') for p in (ROOT/folder).glob('*.py')]
    for p in sorted(files,key=lambda p:p.relative_to(ROOT).as_posix()):
        h.update(p.relative_to(ROOT).as_posix().encode()); h.update(p.read_bytes())
    return h.hexdigest()

def fingerprint(obj):
    return hashlib.sha256(json.dumps(clean(obj), sort_keys=True, allow_nan=False).encode()).hexdigest()

def cumulative(t, values):
    t=np.asarray(t); v=np.asarray(values)
    shape=(len(t)-1,)+(1,)*(v.ndim-1)
    return np.concatenate([np.zeros_like(v[:1]), np.cumsum((v[1:]+v[:-1])*.5*np.diff(t).reshape(shape),axis=0)])

def relative(a,b,floor=1e-30):
    return float(np.linalg.norm(np.asarray(a)-np.asarray(b))/max(np.linalg.norm(a),np.linalg.norm(b),floor))

def available_memory_bytes():
    """Available OS memory constrained by cgroup; Windows uses its native API."""
    if os.name=='nt':
        import ctypes
        class MemoryStatus(ctypes.Structure):
            _fields_=[('length',ctypes.c_ulong),('load',ctypes.c_ulong)]+[(name,ctypes.c_ulonglong) for name in ('total_phys','avail_phys','total_page','avail_page','total_virtual','avail_virtual','extended')]
        status=MemoryStatus();status.length=ctypes.sizeof(status)
        return int(status.avail_phys) if ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(status)) else None
    try:
        mem=dict(line.split(':',1) for line in Path('/proc/meminfo').read_text().splitlines())
        available=int(mem['MemAvailable'].strip().split()[0])*1024
        cp=Path('/sys/fs/cgroup/memory.max')
        if cp.exists() and cp.read_text().strip()!='max':
            available=min(available,max(0,int(cp.read_text())-int(Path('/sys/fs/cgroup/memory.current').read_text())))
        return available
    except (OSError,ValueError,KeyError):
        try:return int(os.sysconf('SC_AVPHYS_PAGES')*os.sysconf('SC_PAGE_SIZE'))
        except (ValueError,OSError,AttributeError):return None
