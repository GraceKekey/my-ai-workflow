"""Eulerian energy/current and Killing flux for static beta=0 geometries.

J^i=-pi_n gamma^{ij} d_j phi. A z-surface has dA=sqrt(gamma)*sqrt(gamma^zz) dxdy.
The outward physical normal contraction is +/-J^z/sqrt(gamma^zz).
Killing-energy flux per coordinate time is +/-N^2 sqrt(gamma) J^z dxdy.
"""
import numpy as np
from .common import cumulative

def integrate_xy(a,x,y):
    return np.trapezoid(np.trapezoid(a, x=y,axis=1),x=x,axis=0)

def interpolate_plane(array,z,height):
    if height < z[0] or height > z[-1]: raise ValueError('plane outside domain')
    k=min(max(np.searchsorted(z,height)-1,0),len(z)-2); u=(height-z[k])/(z[k+1]-z[k])
    return (1-u)*array[:,:,k]+u*array[:,:,k+1]

def cylindrical_current(xyz, current, gamma=None):
    xyz=np.asarray(xyz); current=np.asarray(current,float)
    g=np.broadcast_to(np.eye(3),(*xyz.shape[:-1],3,3)) if gamma is None else np.asarray(gamma)
    r=np.hypot(xyz[...,0],xyz[...,1]); valid=r>1e-12
    er=np.zeros_like(current); er[...,0]=np.divide(xyz[...,0],r,out=np.zeros_like(r),where=valid); er[...,1]=np.divide(xyz[...,1],r,out=np.zeros_like(r),where=valid)
    et=np.stack([-er[...,1],er[...,0],np.zeros_like(r)],axis=-1)
    inverse=np.linalg.inv(g);ez=inverse[..., :,2]/np.sqrt(inverse[...,2,2])[...,None]
    def normalize(v):
        norm=np.sqrt(np.einsum('...i,...ij,...j->...',v,g,v))
        return np.divide(v,norm[...,None],out=np.zeros_like(v),where=norm[...,None]>0)
    er=normalize(er);projection=np.einsum('...i,...ij,...j->...',et,g,er);et=normalize(et-projection[...,None]*er)
    def component(v):return np.einsum('...i,...ij,...j->...',current,g,v)
    return dict(radial=component(er),azimuthal=component(et),vertical=component(ez),axis_valid=valid,
                convention='Eulerian orthonormal frame: z normal to constant-z surface, r tangent radial, theta Gram-Schmidt tangent; axis r=0 has no angular direction')

def ring_currents(axes,current,zplanes,radii,gamma=None,angular_samples=64):
    """Integral J_i dx^i around actual coordinate circles; metric-aware physical projections."""
    from scipy.interpolate import RegularGridInterpolator
    theta=np.arange(angular_samples)*2*np.pi/angular_samples
    points=np.array([[r*np.cos(a),r*np.sin(a),z] for z in zplanes for r in radii for a in theta])
    j=RegularGridInterpolator(axes,current,bounds_error=False,fill_value=np.nan)(points)
    if gamma is None:g=np.broadcast_to(np.eye(3),(len(points),3,3))
    else:g=RegularGridInterpolator(axes,np.asarray(gamma).reshape(*current.shape[:-1],3,3),bounds_error=False,fill_value=np.nan)(points)
    components=cylindrical_current(points,j,g);tangent=np.c_[-points[:,1],points[:,0],np.zeros(len(points))]
    dot=np.einsum('ni,nij,nj->n',j,g,tangent);shape=(len(zplanes),len(radii),angular_samples)
    circulation=dot.reshape(shape).sum(axis=-1)*2*np.pi/angular_samples
    normal_z=components['vertical'];jt=components['azimuthal'].reshape(shape);jz=normal_z.reshape(shape)
    jz*=np.sign(np.asarray(zplanes))[:,None,None]
    alignment=np.divide(np.mean(jt*jz,axis=-1),np.sqrt(np.mean(jt*jt,axis=-1)*np.mean(jz*jz,axis=-1)),out=np.full(shape[:-1],np.nan),where=(np.mean(jt*jt,axis=-1)*np.mean(jz*jz,axis=-1))>1e-40)
    return dict(circulation=circulation,mean_Jtheta=np.mean(jt,axis=-1),mean_Jz_outward=np.mean(jz,axis=-1),angular_vertical_alignment=alignment)

def vertical_observables(axes, energy, current, node_volume, N=None, gamma=None, planes=(10.,20.)):
    x,y,z=[np.asarray(a) for a in axes]; shape=(len(x),len(y),len(z))
    energy=np.asarray(energy).reshape(shape); current=np.asarray(current).reshape(*shape,3); vol=np.asarray(node_volume).reshape(shape)
    if not np.isfinite(energy).all() or not np.isfinite(current).all() or not np.isfinite(vol).all() or np.any(energy<0) or np.any(vol<=0):raise FloatingPointError('FAIL_NUMERICAL: invalid energy, current or physical volume')
    lapse=np.ones(shape) if N is None else np.asarray(N).reshape(shape)
    g=np.broadcast_to(np.eye(3),(*shape,3,3)) if gamma is None else np.asarray(gamma).reshape(*shape,3,3)
    sqrtg=np.sqrt(np.linalg.det(g)); density=energy*vol; total=float(density.sum())
    # Split dual nodal volume at z=0: half of the central node belongs to each side.
    upper=(z>0).astype(float)+.5*(z==0); lower=(z<0).astype(float)+.5*(z==0)
    eplus=float(np.sum(density*upper)); eminus=float(np.sum(density*lower))
    flux=[]
    for height in planes:
        if height<=0:raise ValueError('use positive plane magnitudes')
        row={'height':float(height)}
        for label,sign in [('plus',1),('minus',-1)]:
            power=sign*interpolate_plane(lapse*lapse*sqrtg*current[...,2],z,sign*height)
            row[label+'_out']=float(integrate_xy(np.maximum(power,0),x,y))
            row[label+'_return']=float(integrate_xy(np.maximum(-power,0),x,y))
            row[label+'_net']=row[label+'_out']-row[label+'_return']
            row[label+'_gross']=row[label+'_out']+row[label+'_return']
        row['signed_coordinate_z_net']=row['plus_net']-row['minus_net']
        row['both_hemispheres_outward']=row['plus_net']+row['minus_net'];flux.append(row)
    xyz=np.stack(np.meshgrid(x,y,z,indexing='ij'),axis=-1)
    cyl=cylindrical_current(xyz,current,g)
    # Signed local volume-current moments, not power through a closed cylinder.
    currents={key:float(np.sum(cyl[key]*vol)) for key in ('radial','azimuthal','vertical')}
    currents['azimuthal_absolute']=float(np.sum(np.abs(cyl['azimuthal'])*vol))
    currents['azimuthal_coherence']=abs(currents['azimuthal'])/max(currents['azimuthal_absolute'],1e-30)
    weights=density.sum(axis=(0,1));cx=np.divide((density*xyz[...,0]).sum(axis=(0,1)),weights,out=np.full(len(z),np.nan),where=weights>1e-30)
    cy=np.divide((density*xyz[...,1]).sum(axis=(0,1)),weights,out=np.full(len(z),np.nan),where=weights>1e-30)
    return dict(E_plus=eplus,E_minus=eminus,E_total_Eulerian=total,E_total_Killing_projected=float(np.sum(lapse*density)),
                up_down_asymmetry=(eplus-eminus)/max(total,1e-30),planes=flux,currents=currents,
                centroid_x=cx,centroid_y=cy,slab_energy=weights,
                scope='field perturbation only; global Hamiltonian ledger also includes reciprocal oscillators and interaction')

def parity_error(phi,energy,current,axes):
    z=np.asarray(axes[2])
    if not np.allclose(z,-z[::-1],atol=1e-12):return dict(status='NOT_APPLICABLE_ASYMMETRIC_DOMAIN')
    def err(a,b):return float(np.linalg.norm(a-b)/max(np.linalg.norm(a),np.linalg.norm(b),1e-30))
    j=np.asarray(current); mirror=j[:,:,::-1].copy();mirror[...,2]*=-1
    return dict(status='MEASURED',phi=err(phi,phi[:,:,::-1]),energy=err(energy,energy[:,:,::-1]),current=err(j,mirror))

def orientation_nematic(phi,x,y):
    """Headless dipole orientation from |phi|^2. No arbitrary choice of one lobe."""
    X,Y=np.meshgrid(x,y,indexing='ij');w=np.abs(phi)**2; den=float(w.sum())
    if den<1e-28:return dict(angle_mod_pi=None,resultant=0.,status='UNDEFINED_ZERO_FIELD')
    theta=np.arctan2(Y,X);w=np.where(X*X+Y*Y>1e-24,w,0.);den=float(w.sum())
    if den<1e-28:return dict(angle_mod_pi=None,resultant=0.,status='UNDEFINED_AXIS_ONLY')
    q=np.sum(w*np.exp(2j*theta))/den
    return dict(angle_mod_pi=float((np.angle(q)/2)%np.pi) if abs(q)>.05 else None,resultant=float(abs(q)),status='HEADLESS_ORIENTATION')

def peak_catalog(phi,x,y,tie_relative=.001,max_saved=8):
    from hrf_integral.ridge_tracking import local_peaks
    result=local_peaks(phi,x,y,tie_relative,max_count=None);points=result['points'];count=len(points)
    result['total_local_maxima']=count;result['saved_maxima_cap']=max_saved;result['truncated']=count>max_saved
    result['global_tie_count']=sum(p[2]>=points[0][2]*(1-tie_relative) for p in points) if count else 0
    result['points']=points[:max_saved]
    if result['truncated']:result['primary']=None;result['ambiguous']=True
    return result

def flux_history(records,t):
    if not records:return {}
    result={}
    for j,plane in enumerate(records[0]['planes']):
        result[str(plane['height'])]={}
        for key in ('plus_out','minus_out','plus_return','minus_return','plus_net','minus_net'):
            v=np.array([r['planes'][j][key] for r in records]);result[str(plane['height'])][key]=v
            result[str(plane['height'])]['cumulative_'+key]=cumulative(t,v)
    return result
