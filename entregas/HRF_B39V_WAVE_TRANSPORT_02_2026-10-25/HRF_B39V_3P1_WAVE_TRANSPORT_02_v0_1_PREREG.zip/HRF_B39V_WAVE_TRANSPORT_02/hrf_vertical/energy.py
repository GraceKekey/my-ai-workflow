"""Exact semidiscrete global ledger for the reused static Hamiltonian.

H=.5 p M^-1 p+.5 q K q + sum_recip(.5 v^2+.5 Omega^2 x^2+g x Cq).
The passive oscillator energy is deliberately excluded. No integration is run on import.
"""
import numpy as np

def power_terms(system,state,t,force):
    if system.dynamic or np.any(system.beta): raise ValueError('VVR ledger requires static beta=0 metric')
    n=system.mesh.n;p=state[n:2*n];v=state[2*n+system.h:];vel=p/system.mm
    load=np.zeros(n) if force is None else force(t)
    return np.array([vel@load, np.sum(system.damp*p*vel), np.sum(np.asarray(system.gamma_r)*v*v*system.reciprocal_mask)])

def hemisphere_powers(system,state,t,force):
    n=system.mesh.n;p=state[n:2*n];velocity=p/system.mm;z=system.mesh.xyz[:,2]
    upper=(z>0).astype(float)+.5*(z==0);lower=1-upper;load=np.zeros(n) if force is None else force(t)
    source=velocity*load;sponge=system.damp*p*velocity;v=state[2*n+system.h:]
    zr=system.receiver_xyz[:,2];ur=(zr>0).astype(float)+.5*(zr==0);loss=np.asarray(system.gamma_r)*v*v*system.reciprocal_mask
    return np.array([source@upper,source@lower,sponge@upper,sponge@lower,loss@ur,loss@(1-ur)])

def augmented_rhs(system,y,t,force):
    size=2*system.mesh.n+2*system.h
    return np.r_[system.rhs(t,y[:size],force),power_terms(system,y[:size],t,force)]

def ledger_rk4(system,state,ledger,t,dt,force):
    """Physical RK4 step plus stage-consistent work/loss quadrature. Explicit caller only."""
    y=np.r_[state,ledger]
    a=augmented_rhs(system,y,t,force);b=augmented_rhs(system,y+dt*a/2,t+dt/2,force)
    c=augmented_rhs(system,y+dt*b/2,t+dt/2,force);d=augmented_rhs(system,y+dt*c,t+dt,force)
    ans=y+dt*(a+2*b+2*c+d)/6
    return ans[:-3],ans[-3:]

def balance(energy,initial,ledger,absolute_floor=1e-20):
    work,sponge,receiver=np.asarray(ledger);residual=float(energy-initial-work+sponge+receiver)
    scale=max(abs(energy),abs(initial),abs(work)+abs(sponge)+abs(receiver),absolute_floor)
    return dict(H=float(energy),H_initial=float(initial),source_work=float(work),sponge_loss=float(sponge),
                reciprocal_receiver_loss=float(receiver),balance_residual=residual,balance_relative_error=abs(residual)/scale,
                outer_boundary_power='zero imposed by homogeneous Dirichlet or Neumann; sponge loss listed separately')
