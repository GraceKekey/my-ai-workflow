"""Derived P1 observer: retain lumped mean(pi^2), rather than mean(pi)^2.

For N=1, beta=0 and boundary-compatible states, integral e dV matches the
field part of the discrete Hamiltonian. Old outputs are not overwritten.
"""
import numpy as np
from hrf_integral.volume_observables import VolumeObserver

class EnergyObserver(VolumeObserver):
    def evaluate(self,state):
        result=super().evaluate(state);m=self.m;s=self.s
        if not np.allclose(s.N,1.) or np.any(s.beta):raise ValueError('VVR conservative observer restricted to N=1,beta=0')
        pi=state[m.n:2*m.n]/s.mm;corr=np.zeros(m.n)
        for lo in range(0,len(m.tets),self.block):
            hi=min(lo+self.block,len(m.tets));tet=m.tets[lo:hi]
            variance=np.maximum((pi[tet]**2).mean(axis=1)-pi[tet].mean(axis=1)**2,0.)
            corr+=np.bincount(tet.ravel(),weights=np.repeat(self.weight[lo:hi]*variance/8,4),minlength=m.n)
        result['energy_density']+=corr/self.node_volume;result['total_Eulerian_energy']+=float(corr.sum())
        result['old_kinetic_quadrature_deficit']=float(corr.sum())
        return result
