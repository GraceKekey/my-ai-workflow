"""VVR-01. Importing this package never starts an integration."""
__version__ = '0.1.1'
