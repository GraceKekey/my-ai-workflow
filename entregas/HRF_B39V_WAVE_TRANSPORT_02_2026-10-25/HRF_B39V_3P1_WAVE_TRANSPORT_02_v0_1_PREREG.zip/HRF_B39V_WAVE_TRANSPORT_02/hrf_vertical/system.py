"""Existing coupled solver with explicit physical sponge width and passive replay mode."""
import numpy as np
from hrf_integral.spiral_system import SpiralSystem
from hrf_integral.spiral_source import envelope

class VerticalSystem(SpiralSystem):
    def __init__(self,*args,sponge_width=(10.,10.,10.),sponge_profile='fixed_physical',**kwargs):
        super().__init__(*args,**kwargs)
        self.receiver_xyz=np.asarray(kwargs.get('points',args[3] if len(args)>3 else ()),float).reshape(-1,3)
        width=np.asarray(sponge_width,float)
        if width.shape!=(3,) or np.any(width<=0):raise ValueError('three positive physical sponge widths required')
        distance=np.minimum(self.mesh.xyz-self.mesh.bounds[:,0],self.mesh.bounds[:,1]-self.mesh.xyz)
        if sponge_profile not in ('fixed_physical','legacy_min_extent'):raise ValueError('unknown sponge profile')
        if self.bc=='sponge' and sponge_profile=='fixed_physical':self.damp=kwargs.get('sponge',.5)*np.max(np.maximum(1-distance/width,0)**2,axis=1)
        if self.dynamic or np.any(self.beta) or not np.allclose(self.N,1.):raise ValueError('VVR supports static unit lapse and zero shift')
        # Conservative explicit stability guard for damping and receiver coupling.
        self.dt_bound=min(self.dt_bound,.25/max(np.max(self.damp,initial=0),float(np.max(np.asarray(self.gamma_r))),1e-12))

def forcing(system,c):
    s=c['source'];policy=s.get('normalization_policy','legacy_discrete')
    kind=s.get('kind','dipole_rotating')
    if kind=='null' or s['amplitude']==0:
        zero=np.zeros(system.mesh.n)
        return lambda t:zero.copy(),np.zeros((system.mesh.n,2))
    if kind=='monopole':
        r=system.mesh.xyz-np.asarray(s.get('center',(0.,0.,0.)))
        a=np.exp(-.5*(r[:,:2]**2).sum(axis=1)/s['sigma_xy']**2-.5*(r[:,2]/s['sigma_z'])**2)
        profile=a*system.mm*system.N**2
        if system.bc!='neumann':profile[system.mesh.boundary]=0.
        if policy=='continuum_L2':norm=np.pi**.75*s['sigma_xy']*np.sqrt(s['sigma_z'])
        elif policy=='legacy_discrete':norm=np.sqrt(np.sum(profile**2/system.mm))
        else:raise ValueError('unknown source normalization')
        if norm<=1e-30:raise ValueError('unresolved monopole')
        basis=np.c_[profile/norm,np.zeros_like(profile)]
        return lambda t:s['amplitude']*envelope(t,s)*basis[:,0]*np.cos(s['omega']*t),basis
    if kind not in ('dipole_rotating','dipole_fixed'):raise ValueError('unknown spatial source kind')
    if policy=='legacy_discrete':dipole=system.source(s['sigma_xy'],s['sigma_z'],s.get('center',(0.,0.,0.)))
    elif policy=='continuum_L2':
        # Fix the continuum J profile across metric, domain and grid changes.
        # Integral (P_x^2+P_y^2) d^3x = pi^(3/2)*sigma_z for the derivative-Gaussian pair.
        r=system.mesh.xyz-np.asarray(s.get('center',(0.,0.,0.)));a=np.exp(-.5*(r[:,:2]**2).sum(axis=1)/s['sigma_xy']**2-.5*(r[:,2]/s['sigma_z'])**2)
        dipole=r[:,:2]/s['sigma_xy']**2*a[:,None]*system.mm[:,None]*system.N[:,None]**2/(np.pi**.75*np.sqrt(s['sigma_z']))
        if system.bc!='neumann':dipole[system.mesh.boundary]=0.
    else:raise ValueError('unknown frozen source normalization policy')
    rotation=c['rotation'] if kind=='dipole_rotating' else 0
    def load(t):return s['amplitude']*envelope(t,s)*(dipole[:,0]*np.cos(s['omega']*t)+rotation*dipole[:,1]*np.sin(s['omega']*t))
    return load,dipole
