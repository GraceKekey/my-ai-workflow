"""Streaming adapter for actual old SPIRAL frames and new VVR chunks."""
from pathlib import Path
import json
import numpy as np
from .common import sha

class Dataset:
    def __init__(self,folder):
        self.folder=Path(folder);p=self.folder/'case.json'
        if not p.is_file():raise FileNotFoundError('BLOCKED_MISSING_HISTORICAL_DATA: '+str(p))
        self.meta=json.loads(p.read_text());self.config=self.meta['config'];self.old=(self.folder/'frames/frames.json').exists()
        if self.meta.get('status')!='COMPLETED':raise ValueError('incomplete case: no completed scientific dataset')
        if not self.old:
            from .storage import verify_completion
            if not verify_completion(self.folder):raise ValueError('new dataset lacks a valid completion seal')
        with np.load(self.folder/'grid.npz',allow_pickle=False) as d:self.grid={k:d[k].copy() for k in d.files}
        self.axes=[self.grid[k] for k in ('x','y','z')]
        from hrf_integral.mesh_adaptive import axes_from_config
        if any(not np.array_equal(a,b) for a,b in zip(self.axes,axes_from_config(self.config['grid']))):raise ValueError('grid coordinates differ from recorded configuration')
        if self.old:self.catalog=json.loads((self.folder/'frames/frames.json').read_text())['frames']
        else:self.catalog=json.loads((self.folder/'chunks/catalog.json').read_text())['records']
        self._observer=None
    def read_item(self,row,kind):
        if self.old:
            name=row['file' if kind=='volume' else 'cuts_file'];expected=row['sha256' if kind=='volume' else 'cuts_sha256'];path=self.folder/'frames'/name
        else:
            if not row.get(kind):return None
            path=self.folder/'chunks'/row[kind];expected=row[kind+'_sha256']
        if sha(path)!=expected:raise ValueError('corrupt source '+str(path))
        with np.load(path,allow_pickle=False) as d:return {k:d[k].copy() for k in d.files}
    def cuts(self):
        for row in self.catalog:
            d=self.read_item(row,'cuts')
            if d is not None:yield row['t'],d
    def volumes(self):
        for row in self.catalog:
            d=self.read_item(row,'volume')
            if d is None:continue
            yield row['t'],d
    def flow_frames(self):
        for t,d in self.volumes():
            if 'energy_density' in d and 'flux' in d:yield t,d['energy_density'],d['flux'];continue
            if self._observer is None:
                from hrf_integral.mesh_adaptive import RectilinearMesh
                from .geometry import build_geometry
                from .system import VerticalSystem
                from .observer import EnergyObserver
                mesh=RectilinearMesh(self.axes);metric,_=build_geometry(self.config)
                system=VerticalSystem(mesh,metric,self.config['field']['mass'],points=(),boundary=self.config['field']['boundary'],sponge_width=self.config['field']['sponge_width'])
                self._observer=EnergyObserver(system)
            n=self._observer.m.n;state=np.r_[d['phi'].ravel(),d['momentum'].ravel()]
            out=self._observer.evaluate(state);yield t,out['energy_density'].reshape(d['phi'].shape),out['flux'].reshape(*d['phi'].shape,3)
    def observations(self):
        with np.load(self.folder/'observations.npz',allow_pickle=False) as d:return {k:d[k].copy() for k in d.files}
    def metric_grid(self):
        if self.config.get('geometry',{}).get('kind','flat')=='flat':return None
        from .geometry import build_geometry
        metric,_=build_geometry(self.config);xyz=np.stack(np.meshgrid(*self.axes,indexing='ij'),axis=-1)
        _,_,g=metric.fields(xyz.reshape(-1,3));return g.reshape(*xyz.shape[:-1],3,3)
