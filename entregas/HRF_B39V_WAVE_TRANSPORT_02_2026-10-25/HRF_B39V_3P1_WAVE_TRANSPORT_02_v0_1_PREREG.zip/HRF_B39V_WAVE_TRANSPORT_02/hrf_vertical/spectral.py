"""Measured incident spectra and fixed-threshold receiver diagnostics.

Omega sweeps replay a specified incident field without changing its PDE.
This is a passive counterfactual, not a reciprocal self-consistent new run.
"""
import numpy as np
from scipy.signal import welch
from scipy.linalg import expm
from hrf_integral.history import load

def spectrum(t,signal):
    t=np.asarray(t,float);a=np.asarray(signal,float)
    if len(t)<16 or not np.allclose(np.diff(t),t[1]-t[0],rtol=1e-7,atol=1e-10):raise ValueError('at least 16 uniform samples required for spectra')
    nperseg=min(512,len(t));freq,power=welch(a,fs=1/(t[1]-t[0]),nperseg=nperseg,noverlap=nperseg//2,axis=0,detrend='constant',scaling='density')
    omega=2*np.pi*freq;density=power/(2*np.pi);total=np.trapezoid(density,x=omega,axis=0)
    cumulative=np.cumsum(density,axis=0);den=cumulative[-1]
    fractions=np.divide(cumulative,den,out=np.zeros_like(cumulative),where=den>0)
    bandwidth95=omega[np.argmax(fractions>=.95,axis=0)];peak=omega[np.argmax(density,axis=0)]
    nonzero=total>1e-28;peak=np.where(nonzero,peak,np.nan);bandwidth95=np.where(nonzero,bandwidth95,np.nan)
    # Finite sampled spectrum cannot exclude power already aliased before recording.
    edge=np.sum(density[-max(1,len(omega)//10):],axis=0)/np.maximum(np.sum(density,axis=0),1e-300)
    return dict(omega=omega,PSD_per_angular_frequency=density,variance_integral=total,peak_omega=peak,
                bandwidth95=bandwidth95,nyquist_edge_power_fraction=edge,nperseg=nperseg,frequency_resolution=2*np.pi/(nperseg*(t[1]-t[0])))

def transfer(omega,omega0,gamma,coupling):
    if omega0<=0 or gamma<=0 or coupling<0:raise ValueError('invalid oscillator')
    return -coupling/(omega0**2-np.asarray(omega)**2+1j*gamma*np.asarray(omega))

def threshold_arrivals(t,values,fraction=.1,absolute_floor=1e-14):
    """Interpolated first fractional |signal| crossing; never called a causal front."""
    t=np.asarray(t);a=abs(np.asarray(values));peak=a.max(axis=0);result=np.full(a.shape[1],np.nan)
    for i in range(a.shape[1]):
        if peak[i]<=absolute_floor:continue
        threshold=fraction*peak[i];hits=np.flatnonzero(a[:,i]>=threshold)
        if not len(hits):continue
        j=hits[0]
        result[i]=float(t[0]) if j==0 else float(t[j-1]+(t[j]-t[j-1])*(threshold-a[j-1,i])/max(a[j,i]-a[j-1,i],1e-300))
    return result

def foh_matrix(dt,omega0,gamma,coupling):
    """Exact matrix exponential for piecewise-linear incident forcing, no time-step ODE approximation."""
    A=np.array([[0.,1.,0.,0.],[-omega0**2,-gamma,-coupling,0.],[0.,0.,0.,1.],[0.,0.,0.,0.]])
    return expm(A*dt)

def oscillator_band(omega0,gamma):
    """Exact -3dB displacement-response band, including absence of a nonzero resonance."""
    upeak=max(omega0**2-gamma**2/2,0.);dmin=(omega0**2-upeak)**2+gamma**2*upeak
    roots=np.roots([1.,gamma**2-2*omega0**2,omega0**4-2*dmin]);real=sorted(float(v.real) for v in roots if abs(v.imag)<1e-10)
    lo=np.sqrt(max(real[0],0.));hi=np.sqrt(max(real[-1],0.))
    return dict(peak_omega=float(np.sqrt(upeak)),half_power_low=float(lo),half_power_high=float(hi),half_power_width=float(hi-lo),
                status='NONZERO_RESONANCE' if upeak>0 else 'NO_NONZERO_RESONANT_PEAK')

def passive_replay(t,incident,omega0,gamma,coupling):
    t=np.asarray(t,float);a=np.asarray(incident,float)
    if a.ndim==1:a=a[:,None]
    if len(t)<2 or not np.allclose(np.diff(t),t[1]-t[0],rtol=1e-8,atol=1e-12):raise ValueError('uniform replay samples required')
    dt=t[1]-t[0];E=foh_matrix(dt,omega0,gamma,coupling);x=np.zeros_like(a);p=np.zeros_like(a)
    for i in range(len(t)-1):
        state=np.stack([x[i],p[i],a[i],(a[i+1]-a[i])/dt]);ans=E@state;x[i+1]=ans[0];p[i+1]=ans[1]
    return x,p

def diagnose(t,incident,X,P,omega0,gamma,coupling,threshold,source=None,threshold_valid=None):
    a=np.asarray(incident);x=np.asarray(X);p=np.asarray(P)
    if a.shape!=x.shape or p.shape!=x.shape:raise ValueError('receiver channel shape mismatch')
    ps=spectrum(t,a);h=transfer(ps['omega'][:,None],omega0,gamma,coupling)
    predicted=abs(h)**2*ps['PSD_per_angular_frequency'];output=spectrum(t,x)
    relay=load('b39_rele');R=relay.leitura(np.asarray(t),x,p,np.full(x.shape[1],omega0))
    calibrated=np.ones(x.shape[1],bool) if threshold_valid is None else np.asarray(threshold_valid,bool)
    if calibrated.shape!=(x.shape[1],):raise ValueError('threshold identity mask mismatch')
    firing=np.zeros_like(R);firing[:,calibrated]=relay.rele(t,R[:,calibrated],threshold,'trava')
    energy=.5*(p*p+omega0*omega0*x*x)
    received=np.max(abs(a),axis=0);readout=np.max(R,axis=0)
    peak=ps['peak_omega'];coherent=np.exp(-1j*np.asarray(t)[:,None]*np.nan_to_num(peak)[None,:])
    amplitude=2*np.mean(x*coherent,axis=0)
    out=dict(incident_spectrum=ps,response_spectrum=output,transfer=h,stationary_predicted_response_PSD=predicted,
             response_in_phase=amplitude.real,response_quadrature=amplitude.imag,oscillator_energy=energy,readout=R,
             received_max=received,response_max=np.max(abs(x),axis=0),readout_max=readout,threshold_ratio=np.where(calibrated,readout/threshold,np.nan),
             relay_fired=np.any(firing>0,axis=0),relay_rule_valid=calibrated,coupling_nonzero=bool(coupling!=0),historical_threshold=threshold,
             omega0=omega0,gamma=gamma,exact_transfer_band=oscillator_band(omega0,gamma),threshold_arrival=threshold_arrivals(t,a),incident_peak_time=np.asarray(t)[np.argmax(abs(a),axis=0)],
             stationary_transfer_warning='PSD transfer is steady-state prediction; pulse transients and reciprocal modification are not omitted from measured channels',
             detuning_cause='NOT_ESTABLISHED_BY_FREQUENCY_DIFFERENCE_ALONE')
    if source is not None:out['source_spectrum']=spectrum(t,source)
    return out
