"""Atomic chunks and final completion seal. Old SPIRAL outputs remain read-only."""
from pathlib import Path
import json
import numpy as np
from .common import save_json,save_npz,sha

class ChunkStore:
    def __init__(self,folder,run_id):
        self.folder=Path(folder);self.folder.mkdir(parents=True,exist_ok=True);self.path=self.folder/'catalog.json';self.run_id=run_id
        self.catalog=json.loads(self.path.read_text()) if self.path.exists() else dict(run_id=run_id,records=[])
        if self.catalog['run_id']!=run_id:raise ValueError('chunk configuration/code mismatch')
        if not self.path.exists():save_json(self.path,self.catalog)
        self.verify()
    def verify(self):
        for row in self.catalog['records']:
            for kind in ('sample','cuts','volume'):
                if row.get(kind) and sha(self.folder/row[kind])!=row[kind+'_sha256']:raise ValueError('corrupt '+row[kind])
    def write(self,step,t,sample=None,cuts=None,volume=None):
        row=dict(step=int(step),t=float(t))
        for kind,values in [('sample',sample),('cuts',cuts),('volume',volume)]:
            if values is None:continue
            name=f'{kind}_{step:09d}.npz';save_npz(self.folder/name,t=t,**values);row[kind]=name;row[kind+'_sha256']=sha(self.folder/name)
        self.catalog['records']=[r for r in self.catalog['records'] if r['step']<step]+[row]
        save_json(self.path,self.catalog)
    def rollback(self,step):
        # Chunks beyond the last atomic checkpoint are ignored, then overwritten on replay.
        self.catalog['records']=[r for r in self.catalog['records'] if r['step']<=step];save_json(self.path,self.catalog)

def finalize(folder,result):
    folder=Path(folder);obj=dict(result,status='COMPLETED')
    save_json(folder/'case.json',obj);save_json(folder/'run.json',obj)
    seal=dict(status='COMPLETED_COMMITTED',run_id=obj['run_id'],case_sha256=sha(folder/'case.json'),run_sha256=sha(folder/'run.json'),
              observations_sha256=sha(folder/'observations.npz'),catalog_sha256=sha(folder/'chunks/catalog.json'),grid_sha256=sha(folder/'grid.npz'))
    save_json(folder/'COMPLETION.json',seal)

def verify_completion(folder):
    folder=Path(folder);p=folder/'COMPLETION.json'
    if not p.exists():return False
    seal=json.loads(p.read_text())
    for file,key in [('case.json','case_sha256'),('run.json','run_sha256'),('observations.npz','observations_sha256'),('chunks/catalog.json','catalog_sha256'),('grid.npz','grid_sha256')]:
        if sha(folder/file)!=seal[key]:raise ValueError('completion seal mismatch '+file)
    return seal['status']=='COMPLETED_COMMITTED'

def audit_old_metadata(folder):
    folder=Path(folder);case=json.loads((folder/'case.json').read_text());run=json.loads((folder/'run.json').read_text()) if (folder/'run.json').exists() else {}
    mismatch=run.get('status')!=case.get('status')
    return dict(case_id=case.get('case_id'),case_status=case.get('status'),run_status=run.get('status'),mismatch=mismatch,
                interpretation='old runner writes RUNNING once and never finalizes run.json; raw integrity must be checked separately' if mismatch else 'consistent metadata',
                original_case_sha256=sha(folder/'case.json'),original_run_sha256=sha(folder/'run.json') if run else None,
                original_files_modified=False)
