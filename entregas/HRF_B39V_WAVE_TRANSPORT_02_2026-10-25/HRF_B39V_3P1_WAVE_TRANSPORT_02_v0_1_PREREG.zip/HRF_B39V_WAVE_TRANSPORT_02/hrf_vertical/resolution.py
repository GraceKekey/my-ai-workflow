"""Coordinate versus conservative proper-axis resolution in prescribed graph metrics."""
import json
import numpy as np
from .common import ROOT

def proper_steps(config,coordinate_dx):
    g=config.get('geometry',{'kind':'flat'});dx=np.asarray(coordinate_dx,float)
    if g['kind']=='flat':return dx
    thickness=g.get('thickness',15.)
    if g['kind'] in ('historical_graph','historical_one_valley','historical_two_valleys'):
        table=json.loads((ROOT/'inputs/geometry_resolution_bounds.json').read_text());b=table[g['historical_case']]
        bounds=[b['max_abs_hx'],b['max_abs_hy'],b['max_abs_h']/(thickness*np.sqrt(np.e))]
    elif g['kind'] in ('analytic_graph','synthetic_valley'):
        gradient=sum(abs(v[2])/(v[3]*np.sqrt(np.e)) for v in g['valleys']);height=sum(abs(v[2]) for v in g['valleys']);bounds=[gradient,gradient,height/(thickness*np.sqrt(np.e))]
    else:raise ValueError('unrecognized geometry resolution bound')
    return dx*np.sqrt(1+np.asarray(bounds)**2)
