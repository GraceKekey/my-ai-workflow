# Módulos e estado real

**CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] v0.1 · 24/10/2026 · W apenas; G/D separados.

- `common.py` — IO atômico, SHA-256, representação JSON sem números não finitos e identificação do código.
- `config.py / admission.py / resolution.py` — Validação, estimativa antes de alocar FEM, recursos efetivos, manifesto congelado e limites de passo próprio; headers ZIP antes de ler arrays grandes.
- `geometry.py` — Alturas originais P/h/T, perfil3D herdado e auditoria de assinatura/paridade. Três paisagens históricas recuperadas; outras não são inventadas.
- `system.py / observer.py / energy.py` — Sistema recíproco/passivo derivado do solver real, fonte comJ fixo, sponge física, energia concentrada conservativa e ledger RK4.
- `storage.py / dataset.py / runner.py` — Chunks/checkpoints, integridade de volume/cortes/receptores, conclusão selada, leitura antiga e nova e integração futura explícita.
- `transport.py` — Hemisférios, fora/retorno/bruto/líquido, tríade física, circulação em anéis, centros, paridade e eixo nemático.
- `helical.py` — VelocidadeJ/e, sementes ponderadas, curvas temporais, controles de causalidade/resolução e candidatos falsificáveis.
- `spectral.py` — PSD, banda própria, transferência complexa, fase/quadratura, chegada de limiar, propagador matricial e replay passivo futuro.
- `analysis.py` — Reanálise semPDE, todos os ajustes de fase, janelas, limiares e canais históricos, flags e separação dos hemisférios.
- `controls.py` — Comparação de campos/observáveis, referências analíticas futuras, ordens, evidências rastreáveis e certificação condicionada.
- `figures.py` — Figuras1–8, correntes/degenerescências, curvasJ/e, escala comum, GIF/MP4 volumétricos com câmera fixa, sem campos fictícios.
- `cli.py / scripts/` — Planejamento por padrão, execução explícita, evidências, figuras e launchers Windows/Linux; sem execução em importações/instalação.

[D] Implementação real, sem classes vazias ou funções de demonstração usadas como solver. Foram feitas verificações estáticas e75 testes de álgebra/integridade. Integração temporal nova, convergência física e replays científicos continuam NÃO EXECUTADOS. Portanto não se anuncia certificação end-to-end das futuras simulações.

[?] Bloqueados: adoção das duas versões documentais atuais, auditoria dos brutos do Colab e geração de figuras científicas desses dados; estados físicosG/D. Não implementados no móduloVVR: Einstein dinâmico, eletromagnetismo, quantização, AMR dinâmico, lapso/shift novos ou reconstrução holográfica física. São limites explícitos, não funções que retornam falsamentePASS.
