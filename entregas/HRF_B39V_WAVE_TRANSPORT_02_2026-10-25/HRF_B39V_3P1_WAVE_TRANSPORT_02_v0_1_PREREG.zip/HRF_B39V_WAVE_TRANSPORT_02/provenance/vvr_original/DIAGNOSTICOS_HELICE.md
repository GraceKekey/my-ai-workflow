# Diagnósticos de fase, circulação e transporte

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[M/D] Fase: lock-in Hann de2φ exp(+iωt), convenção φ~cos(mθ+kz z−ωt). Comparar1,5/2/2,5 ciclos; descartar bordas. Pisos de amplitude absoluto1e−14 e relativo1e−6; mínimo16 registros. Harmônicos m−4…4 são normalizados pela potência angular TOTAL, incluindo a que está fora dessa lista. Primário m=s (m1 no controle sem giro); pureza≥0,6. Zero de amplitude não recebe fase.

[D] Torção: ao menos quatro alturas conectadas; sem preencher lacunas; incrementos de fase>0,8π são suspeitos de alias. Ajuste ponderado com span≥0,5rad e RMS relativo≤0,25. Candidato precisa persistir nas três janelas com variação de kz≤20% do maior|kz| e satisfazer resolução espacial. Todos os ajustes, inclusive rejeitados, são registrados com m,kz,resíduo, span e erro-padrão descritivo da inclinação. Esse erro de ajuste não é intervalo estatístico de confiança: amostras correlacionadas exigem controles de malha, janela e fronteira.

[M] Quiralidade operacional reutiliza Σm Pm/(max|m| ΣPm). Inverter seu sinal ao inverter s não demonstra corrente vertical. Nem m≠0 implica kz≠0. O passo−2πm/kz é passo da crista de fase, não percurso material.

[D] Máximos de|φ| são contados com empates de0,1%; até8 posições são gravadas por plano junto com contagem total, número de empates e flag de truncamento. Truncamento invalida a crista principal; os volumes brutos permitem reanálise completa. não escolher um lobo antipodal. O eixo nemático ponderado por|φ|² usa exp(2iθ), ângulo móduloπ e resultante mínima0,05. Centros de energia independem da crista. Configuração com mudança de topologia ou rastreio perdido permanece indefinida.

[M/D] Transporte: curvas integrais da velocidade Euleriana v_E=J/e, sem sementes escolhidas pela fase ou pela crista. Integração de pós-processamento por ponto médio, entre campos gravados; velocidade com norma física>1+1e−5 é invalidada. Sementes de quadratura cobrem os dois lobos e os dois hemisférios, pesadas pelo fluxo positivo no plano. Erro de quadratura≤5%, pelo menos16 sementes, plano≥3σz e início após desligar a fonte. Passo entre volumes≤0,5 célula mínima; sair da região anterior à sponge ou perder amplitude encerra o segmento, sem reconectar lacunas.

[D] Candidato por curva: ≥16 frames; raio≥2 passos espaciais; span angular≥π; deslocamento vertical≥max(20,4Δ); CV do raio≤0,25; resíduo relativoθ(z)≤0,20; ≥90% dos incrementos z para fora; duração≥um período da fonte. A família exige≥20% do PESO AMOSTRADO do fluxo nessas curvas e refluxo≤10%. Não se identifica esse peso com toda a energia emitida. Medidas são separadas em+z/−z; uma soma líquida nula não veta dois transportes opostos.

[D] O rótulo HELICAL_ENERGY_TRANSPORT_CANDIDATE exige também referência numérica, energia, paridade, convergência espacial/temporal, robustez de contorno e estabilidade do próprio rastreamento. Variação de fração no refinamento≤0,05 e classificação preservada. Sem esses controles→INCONCLUSIVE. Com ambos os hemisférios resolvidos e controles válidos, ausência de candidatos→NO_RESOLVED_HELICAL_TRANSPORT. O domínio antigo±25 não tem plano elegível≥30 para σz10; não se força uma conclusão a partir dele.

[?] Curvas do fluxo de um campo clássico não são trajetórias materiais únicas, fótons ou linhas de transporte de identidade. Reflexões, fase giratória radial, circulação sem z, máximos degenerados e fluxo vertical retilíneo são controles adversariais explícitos.
