# Protocolo pré-registrado

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


## Objetivo

[D] Discriminar propagação volumétrica simétrica, rotação de fase, circulação, efeitos geométricos, seletividade dos receptores e artefatos numéricos, sem exigir uma espiral. W é o mapa investigado. Não inferir G ou D.

## Hipóteses anteriores à execução

[H] H0-z: fonte, dados iniciais, receptores, contornos e métrica pares em z preservam a reflexão vetorial apropriada. Energia pode sair nos dois hemisférios com fluxo assinado líquido nulo. H0-helix: m≠0 não obriga kz≠0 nem curvas helicoidais de energia. H-vales: perfis históricos podem alterar chegada, intensidade e circulação sem selecionar +z. H-receptores: banda incidente, amortecimento, acoplamento e filtro histórico podem explicar parte do não disparo; a causa dominante está aberta. H-numérica: candidatos instáveis com resolução/fronteira são inconclusivos.

## Parâmetros

[D] Nove presets separados. Não se usam contagens textuais como configuração: a lista exata de casos está nos JSONs e em `PRESETS_E_RECURSOS.md`. Famílias principais: fonte ω0,13, m0,05, F0,02, σxy12, σz10, pulso160, t520, dt0,1; grade xy105², z33/79/129 para±25/60/100. Comparação de vales: todos os quatro cenários usam a mesma grade161²×105 e o mesmo domínio±130,±130,±60. O maior refinamento completo209²×161 excede24GiB e deve ser bloqueado nessa cota.

[D] Mudança explícita de controle: a nova fonte usa normalização contínua fixa sqrt(π^(3/2)σz), mantendo J(x,t) igual ao mudar métrica, domínio e malha. A fonte antiga normalizava cada carga discreta. Assim, não se anuncia recertificação numérica da rodada antiga; a reanálise mantém sua fonte original. A esponja nova tem largura física fixa10 por eixo; o domínio não a engrossa automaticamente.

## Protocolo

1. Verificar manifestos e dependências. Aguardar autorização posterior; esta entrega não a presume.
2. Reanalisar dados antigos disponibilizados, com hashes e saídas em pasta separada.
3. Após novo congelamento documental e autorização, executar referências analíticas e controles nulos/paridade; medir ordens efetivas e energia antes de interpretar os cenários longos.
4. Executar famílias pareadas mantendo as outras variáveis. Cada caso tem checkpoint atômico, chunks, identidade por configuração+código+gates e selo final.
5. Medir espectros recebidos; repetir análises temporais com1,5/2/2,5 ciclos; realizar comparações de malha, dt, domínio e esponja. Replays de receptores são passivos e separados da PDE recíproca.
6. Somente com controles quantitativos válidos examinar candidatos de transporte. Falhas e nulos permanecem registrados, sem alterar critérios para obter disparos ou hélices.

## Medidas

[F/M] Energia/corrente Eulerianas do escalar, energia Hamiltoniana conjunta com casas recíprocas, perdas de esponja/receptores, trabalho da fonte, hemisférios, fluxos por planos, refluxo e integrais temporais. Componentes físicas cilíndricas em tríade ortonormal, circulação de linha, momento orbital operacional e sua derivada. Fase/harmônicos, ajustes rejeitados e aceitos, centros, máximos degenerados e eixo nemático. Espectros, resposta, fase/quadratura, limiar e relé separados.

## Decisões

[D] Os valores exatos estão em `config/gates.json`, com definições em `HIPOTESES_E_GATES.md`. PASS_SOFTWARE é o único PASS desta entrega. PASS_NUMERICAL_REFERENCE e todos os gates científicos novos permanecem NOT_EXECUTED. A ausência de controles não se torna resultado nulo físico. Falta de referência histórica necessária→BLOCKED_MISSING_HISTORICAL_DATA; falta de recursos→BLOCKED_RESOURCES; erro certificado→FAIL_NUMERICAL; falta de informação→INCONCLUSIVE.

## Limites e arquivos

[?] Campo clássico escalar sobre geometria prescrita, interpolação P1 por partes, massa concentrada, RK4 e sponge não perfeita. Gaussianas não têm suporte compacto; chegada de10% não é frente causal. Curvas J/e não são partículas. Os módulos gerais de lapso/shift herdados ficam preservados, mas o módulo VVR restringe-se a N=1, β=0 e geometria estática. Nenhuma solução de Einstein ou derivação de ħ é reivindicada.
