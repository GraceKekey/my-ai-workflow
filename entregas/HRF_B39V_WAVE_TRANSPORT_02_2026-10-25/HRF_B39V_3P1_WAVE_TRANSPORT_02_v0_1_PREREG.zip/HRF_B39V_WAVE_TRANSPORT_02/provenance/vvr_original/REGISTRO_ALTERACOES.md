# Registro de desenvolvimento

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[D] Novo diretório; fontes antigas nunca editadas. Implementados observador conservativo derivado, ledger por estágios, metadados selados, arquivos de chunks, reader streaming, fases com lacunas explícitas, circulação própria, curvas J/e, espectro/transferência/replays passivos, adaptador de altura com conectividade original, presets, recursos, evidências, figuras/filmes e CLI com autorização explícita.

[D] Decisões de modelagem anteriores a qualquer integração nova: normalização contínua fixa da fonte; largura física fixa da sponge; tríade ortonormal para componentes; limites de passo próprio conservadores; sementes fora de3σz e após desligamento; todas as regras quantitativas do gate. Esses pontos são alterações declaradas em relação à exploração anterior.

[D] Correções de software pré-freeze e logs de falhas constam da errata. A primeira estimativa estática com Delaunay produziu NaN por simplexes degenerados e foi preservada como FALHA DE DESENVOLVIMENTO, não resultado científico. O limite final usa a triangulação original, sem NaN. Não se usaram campos novos para ajustar decisões.
