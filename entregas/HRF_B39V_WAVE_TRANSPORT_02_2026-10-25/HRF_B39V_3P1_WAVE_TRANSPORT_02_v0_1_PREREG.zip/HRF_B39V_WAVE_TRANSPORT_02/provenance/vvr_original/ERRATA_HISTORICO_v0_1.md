# Errata versionada e mudanças antes do congelamento

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[D] Nenhum ZIP/código/relatório/resultado anterior foi reescrito. Esta errata documenta problemas de código e decisões da NOVA bancada; não reclassifica automaticamente a rodada grande do Colab.

1. **Metadados finais.** O runner SPIRAL escreve `run.json` como RUNNING e finaliza somente `case.json`. Confirmado nos dois smokes locais. O runner VVR atualiza ambos e grava selo COMPLETION com hashes; ausência/inconsistência do selo não é sucesso silencioso. O significado nos arquivos grandes precisa de conferência dos brutos.
2. **Quadratura cinética.** O observador antigo usa a média deπ por tetraedro ao quadrado. Em massa concentrada, mean(π²) preserva a energia cinética discreta; a diferença é a variância. O novo EnergyObserver corrige sua própria saída e expõe a diferença. Ledger H e energia de campo são distinguidos. Impacto nos números antigos não calculado.
3. **NaN no ajuste axial.** O helper herdado usa max(amplitude), sensível aNaN. Uma altura inválida pode invalidar todo o trecho. O wrapper novo mantém a máscara, usa zero somente no teste de amplitude e preserva os trechos conectados; não preenche fases. Testes de uma borda ausente e de uma lacuna central verificam a distinção. Não se afirma que isso explique os zero candidatos da rodada anterior sem os dados.
4. **Conectividade histórica.** O adaptador integral/SPIRAL retriangulava P por Delaunay. A auditoria estática desse P encontrou16 simplexes numericamente degenerados, área≤9,6e−14, com transformadas não finitas; isso contaminou uma primeira estimativa de limite de gradiente. O NOVO adaptador preserva T original da B39V e h gravado, sem retriangulação ou nova solução de altura. O primeiro recibo inválido e a fonte de desenvolvimento foram preservados em `reports/revisao_geometria_prefreeze/`. Não há demonstração de que as execuções antigas tenham amostrado um desses simplexes.
5. **Fonte controlada e sponge.** A normalização contínua fixa de J e a largura física fixa da sponge são decisões novas, declaradas, para impedir mudanças implícitas quando se troca domínio/métrica. Não se apresentam como recertificação bit a bit do baseline.
6. **Falha de software encontrada antes do freeze.** Primeira bateria:60 testes, um erro na finalização de catálogo vazio. A rotina passou a persistir também o catálogo inicial. Logs v1/v2 e a fonte anterior foram mantidos. Casos sintéticos adicionais foram acrescentados; nenhum resultado físico novo orientou a correção ou os critérios.
