# Emenda pré-execução 1 — proteção da varredura científica de receptores

[D] 24/10/2026. A revisão estática após o primeiro congelamento identificou que a CLI bloqueava as novas PDEs por dependências documentais, mas encaminhava o replay de osciladores antes desse bloqueio. Replays também são varreduras científicas e não devem ignorar os documentos obrigatórios.

[D] Foi acrescentada a verificação de dependências antes do encaminhamento do replay. A reanálise somente de arquivos antigos continua disponível sem solver. Um teste de regressão usa mock que falharia se o replay fosse chamado; não executa osciladores ou campos. Nenhuma regra física, limiar, fonte, malha ou resultado foi alterado. Versão interna0.1.1; nome externo do pacotev0.1 preservado conforme solicitado.

[D] Congelamento anterior:209 arquivos, SHA2566aed1d5da505918b1bdabb0197ea06d7255ba55a38d7f12c28a957ce65be251d. Fonte anterior da CLI, manifesto e recibo do primeiro ZIP foram preservados em reports/pre_emenda1/. O ZIP anterior foi preservado separadamente no ambiente de trabalho, sem sobrescrita. O novo manifesto é o vigente; não se reutiliza o anterior para autorizar ciência.

**Novas integrações3+1:0. Varreduras científicas de receptores:0. Estudos físicos de convergência:0.** Esta emenda é anterior a qualquer execução científica nova e à entrega final ao usuário.
