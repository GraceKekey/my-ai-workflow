"""All solver entry points require the explicit 'run --execute' command."""
import argparse,json,sys
from pathlib import Path
from .common import ROOT,save_json
from .config import load,plan

def _main(argv=None):
    parser=argparse.ArgumentParser(description='VVR-01: default is plan only. No scientific integration during installation/import/tests.')
    sub=parser.add_subparsers(dest='command',required=True)
    for name in ('plan','run'):
        p=sub.add_parser(name);p.add_argument('--config',required=True);p.add_argument('--output',required=True);p.add_argument('--case');p.add_argument('--execute',action='store_true');p.add_argument('--input')
    p=sub.add_parser('reanalyze');p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('analyze');p.add_argument('--input',required=True);p.add_argument('--output',required=True);p.add_argument('--flowlines',action='store_true');p.add_argument('--evidence')
    p=sub.add_parser('figures');p.add_argument('--input',nargs='+',required=True);p.add_argument('--analysis',required=True);p.add_argument('--output',required=True);p.add_argument('--comparisons');p.add_argument('--max-frames',type=int,default=16)
    p=sub.add_parser('compare');p.add_argument('--first',required=True);p.add_argument('--second',required=True);p.add_argument('--allow',nargs='+',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('reference-check');p.add_argument('--input',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('certify');p.add_argument('--evidence',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('basic-evidence');p.add_argument('--input',required=True);p.add_argument('--analysis',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('reference-evidence');p.add_argument('--spatial',nargs=3,required=True);p.add_argument('--temporal',nargs=3,required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('control-evidence');p.add_argument('--first',required=True);p.add_argument('--second',required=True);p.add_argument('--analysis-first',required=True);p.add_argument('--analysis-second',required=True);p.add_argument('--allow',nargs='+',required=True);p.add_argument('--gate',choices=['SPATIAL_CONVERGENCE','TEMPORAL_CONVERGENCE','BOUNDARY_ROBUSTNESS'],required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('flow-evidence');p.add_argument('--first-analysis',required=True);p.add_argument('--second-analysis',required=True);p.add_argument('--output',required=True)
    p=sub.add_parser('merge-evidence');p.add_argument('--input',nargs='+',required=True);p.add_argument('--output',required=True)
    args=parser.parse_args(argv);gates=json.loads((ROOT/'config/gates.json').read_text())
    if args.command in ('plan','run'):
        c=load(args.config);result=plan(c,args.output,args.case);out=Path(args.output);out.mkdir(parents=True,exist_ok=True);save_json(out/'plan.json',result)
        print(json.dumps({k:result[k] for k in ('preset','status','aggregate_disk_bytes','peak_memory_bytes','dependencies','frozen_checks')},indent=2))
        if args.command=='plan' or not args.execute:return 0
        if result['frozen_checks']['missing'] or result['frozen_checks']['changed']:print('BLOCKED_CHANGED_PREREGISTRATION');return 4
        if result['status']=='BLOCKED_RESOURCES':return 2
        selected=[x for x in c['cases'] if args.case is None or x['case_id']==args.case]
        if all(x['mode'] in ('baseline_reanalysis','receiver_replay') for x in selected):
            from .analysis import baseline,receiver_sweep
            for case in selected:
                source=args.input or ROOT/case['input_directory']
                if case['mode']=='baseline_reanalysis':baseline(source,out/case['case_id'],gates)
                else:receiver_sweep(source,out/case['case_id'],case['parameters'],gates)
            return 0
        if result['dependencies']['missing']:print('BLOCKED_MISSING_HISTORICAL_DATA: mandatory current documents not adopted in this freeze');return 3
        from .runner import run_case
        summaries=[]
        for case in selected:
            per_case=plan(c,args.output,case['case_id'])
            if per_case['status']=='BLOCKED_RESOURCES':save_json(out/'blocked_case.json',per_case);return 2
            record=run_case(case,out,dict(per_case,explicit_execute=True));summaries.append(record);print(case['case_id'],record['status'],flush=True)
        save_json(out/'execution.json',dict(status='SCIENTIFIC_EXECUTION_EXPLICITLY_REQUESTED',cases=[dict(case_id=r['case_id'],status=r['status']) for r in summaries]))
    elif args.command=='reanalyze':
        from .analysis import baseline
        result=baseline(args.input,args.output,gates);print(result['status'])
    elif args.command=='analyze':
        from .analysis import analyze_case
        from .controls import certify
        controls=certify(json.loads(Path(args.evidence).read_text()),gates) if args.evidence else None
        result=analyze_case(args.input,args.output,gates,args.flowlines,controls);print(result.get('structure',{}).get('status',result.get('status')))
    elif args.command=='compare':
        from .controls import compare_cases
        save_json(args.output,compare_cases(args.first,args.second,args.allow))
    elif args.command=='reference-check':
        from .controls import reference_error
        save_json(args.output,reference_error(args.input))
    elif args.command=='certify':
        from .controls import certify
        save_json(args.output,certify(json.loads(Path(args.evidence).read_text()),gates))
    elif args.command=='basic-evidence':
        from .controls import basic_evidence
        save_json(args.output,basic_evidence(args.input,args.analysis,gates))
    elif args.command=='reference-evidence':
        from .controls import reference_evidence
        result=reference_evidence(args.spatial,args.temporal,gates);save_json(args.output,{'PASS_NUMERICAL_REFERENCE':result})
    elif args.command=='control-evidence':
        from .controls import pair_evidence
        save_json(args.output,pair_evidence(args.first,args.second,args.analysis_first,args.analysis_second,args.allow,args.gate,gates))
    elif args.command=='flow-evidence':
        from .controls import flowline_evidence
        save_json(args.output,flowline_evidence(args.first_analysis,args.second_analysis,gates))
    elif args.command=='merge-evidence':
        evidence={}
        for p in args.input:
            obj=json.loads(Path(p).read_text());overlap=set(evidence)&set(obj)
            if overlap:raise ValueError('duplicate gates: select independently matched evidence: '+str(overlap))
            evidence.update(obj)
        save_json(args.output,evidence)
    elif args.command=='figures':
        from .figures import render_case,matched_comparison,convergence_figure,pair_statistics
        from .dataset import Dataset
        vmax=0.
        for folder in args.input:
            for _,d in Dataset(folder).volumes():vmax=max(vmax,float(abs(d['phi']).max()))
        vmax=max(vmax,1e-30);out=Path(args.output);out.mkdir(parents=True,exist_ok=True);analyses=Path(args.analysis)
        for folder in args.input:render_case(folder,analyses/Path(folder).name,out/Path(folder).name,vmax,args.max_frames)
        if len(args.input)>1:
            datasets=[Dataset(p) for p in args.input]
            if len(datasets)==2 and {d.config['rotation'] for d in datasets}=={-1,1}:
                plus=next(d for d in datasets if d.config['rotation']==1);minus=next(d for d in datasets if d.config['rotation']==-1)
                matched_comparison([plus.folder,minus.folder],out,vmax,7);save_json(out/'rotation_pair.json',pair_statistics(plus.folder,minus.folder,analyses/plus.folder.name,analyses/minus.folder.name))
            else:matched_comparison(args.input,out,vmax,5)
        if args.comparisons:convergence_figure(args.comparisons,out)
    return 0

def main(argv=None):
    arguments=sys.argv[1:] if argv is None else list(argv)
    try:return _main(arguments)
    except (FileNotFoundError,MemoryError,FloatingPointError) as error:
        status='BLOCKED_MISSING_HISTORICAL_DATA' if isinstance(error,FileNotFoundError) else ('BLOCKED_RESOURCES' if isinstance(error,MemoryError) else 'FAIL_NUMERICAL')
        report=dict(status=status,error=type(error).__name__+': '+str(error),scientific_success_claimed=False)
        if '--output' in arguments:
            target=Path(arguments[arguments.index('--output')+1]);path=target.with_suffix('.error.json') if target.suffix=='.json' else target/'failure.json';save_json(path,report)
        print(json.dumps(report,indent=2));return 2

if __name__=='__main__':raise SystemExit(main())
