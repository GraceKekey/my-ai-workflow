"""Reuse archived B39V height; never replace Poisson heights with lookalike Gaussians."""
import numpy as np
from scipy.spatial import Delaunay
from hrf_integral.history import Height
from hrf_integral.geometry import ADM
from hrf_integral.spiral_geometry import GaussianHeight
from .common import ROOT

class ArchivedHeight(Height):
    def __init__(self,name):
        path=ROOT/'inputs/archived_geometry'/f'{name}.npz'
        if not path.is_file():raise FileNotFoundError('BLOCKED_MISSING_HISTORICAL_DATA: '+str(path))
        with np.load(path,allow_pickle=False) as data:self.P=data['P'];self.h=data['h']
        self.minimum=float(self.h.min());self.tri=Delaunay(self.P)

def build_geometry(config):
    g=config['geometry'];kind=g['kind']
    if kind=='flat':return ADM(),lambda xyz:np.zeros(len(xyz))
    if kind=='historical_graph':height=ArchivedHeight(g['historical_case'])
    elif kind=='analytic_graph':height=GaussianHeight(g['valleys'])
    else:raise ValueError('unsupported VVR geometry')
    thickness=float(g.get('thickness',15.))
    if thickness<=0:raise ValueError('positive extrusion thickness required')
    metric=ADM('graph',height_map=height,thickness=thickness,lapse_depth=0.)
    def H(xyz):
        a=np.atleast_2d(xyz);return height(a[:,:2])[0]*np.exp(-.5*(a[:,2]/thickness)**2)
    return metric,H

def metric_audit(metric,points):
    points=np.asarray(points,float);N,b,g=metric.fields(points)
    eig=np.linalg.eigvalsh(g);mir=points.copy();mir[:,2]*=-1;_,_,gm=metric.fields(mir)
    R=np.diag([1.,1.,-1.]);expected=np.einsum('ij,njk,kl->nil',R,g,R)
    return dict(lapse_min=float(N.min()),spatial_eigenvalue_min=float(eig.min()),lorentzian=bool(np.all(N>0)&np.all(eig>0)),
                parity_covariance_error=float(np.max(abs(gm-expected))),shift_max=float(abs(b).max()),
                Einstein_solution='NOT_CLAIMED; prescribed piecewise geometry')
