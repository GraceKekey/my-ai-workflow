# Proveniência e inventário

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[D] Inventário legível por máquina: `reports/inventario_lido.json`. Herança conferida byte a byte: `reports/heranca_verificada.json` (143 arquivos originais copiados idênticos). Esses143 registros identificam COPIADO+HASH, o que não deve ser confundido com afirmação de leitura científica integral de todos os documentos. O inventário distingue consultas efetivas de fontes, dados extraídos e materiais inacessíveis.

[D] Base: entrega SPIRAL v0.1 de23/10, SHA256 do ZIP ec7ae013f20d5927c72fd0c08cb32110d318729c227bdecbac69b8e8514cf7fb; núcleo integral e fonte histórica B39V preservados. Foram consultados run, System, SpiralSystem, FEM, mesh, VolumeObserver, geometria, história, receptor/relé, config, fonte, fase, helicity, crista, armazenamento, visualização e protocolo/gates anteriores. O mapa integral e seu protocolo científico também foram lidos. Fontes históricas de altura foram abertas para extrair P/h/T e seus hashes constam do recibo de geometria.

[D] Livros locais disponíveis: Cap0_1v0.1(08/10) e Cap03v0.2(22/10), apenas referências históricas. Livros EXIGIDOS: Cap0_1v0.2(09/10) e Cap03v0.5(24/10), ausentes. A busca por nomes foi feita no workspace/anexos e os links foram tentados por HTTP normal, preservando proxy e verificação TLS. Não houve conector Drive autenticado nem uso de credenciais inventadas. `reports/acesso_a_fontes.json` registra as limitações.

[D] Os números científicos anteriores desta solicitação estão em `reports/baseline_informado.json`, origem TEXTO_DO_USUARIO e status RAW_NOT_VERIFIED. O único baseline bruto acessível localmente era o smoke técnico antigo, que não substitui a execução grande. Seus metadados foram somente auditados e seus arquivos não foram modificados.

[D] Os novos hrf_vertical/*.py são derivados novos; hrf_integral/ e historico/ continuam idênticos aos copiados. O código SHA é distinto do SHA do ZIP. `hashes_antes_da_execucao.txt` congela protocolo, regras, presets, código e entradas. `MANIFESTO_SHA256.txt` abrange a entrega completa, incluindo os logs de software. O manifesto não lista a si próprio. As saídas futuras têm identificadores e hashes próprios; não são anexados retroativamente ao pré-registro.
