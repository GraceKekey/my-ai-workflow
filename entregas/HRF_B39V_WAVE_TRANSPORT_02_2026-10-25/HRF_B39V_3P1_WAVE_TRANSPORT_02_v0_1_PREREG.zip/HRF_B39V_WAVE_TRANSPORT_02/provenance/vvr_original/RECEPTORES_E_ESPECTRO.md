# Receptores, espectro e não disparo

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[M] Os468 históricos têm posições exatas em z0 e acoplamento recíproco por padrão; extras são sondas passivas com rótulos independentes, inclusive coincidências. Casas fora de um domínio compacto de referência continuam catalogadas e inativas, sem clamping. As referências compactas não certificam a transferência de todas as468.

[F/M] Xddot+γXdot+Ω²X=−g φ_inc, χ(ω)=−g/(Ω²−ω²+iγω), para a convenção temporal exp(+iωt). O programa calcula PSD Welch em frequência ANGULAR, resolução de bins, banda95%, potência perto de Nyquist, χ complexa, banda exata de meia potência, resposta em fase/quadratura e energia(Xdot²+Ω²X²)/2. Em forte amortecimento pode não existir pico ressonante não nulo; não usar γ como largura exata em todos os casos.

[D] São separados: campo incidente acima do piso, g não nulo, resposta do oscilador, cruzamento do limiar e evento do relé. A rotina histórica `b39_rele.py` é idêntica; inclui normalização√Ω, demodulação na frequência própria, filtro T_R20, trava, histerese0,5 e lâmpada. A reprodução confere o canal integral, inclusive a rede estacionária se ela foi registrada. A razão espectral estacionária é diagnóstico; transientes não são apagados.

[D] Varredura UM fator por vez: Ω={0,10;0,13;0,20;0,50;1,85}, γ={0,05;0,10;0,20} emΩ1,85, g={0,025;0,05;0,10} emΩ1,85. São nove replays independentes com o mesmo campo incidente. O propagador do oscilador usa exponencial matricial exata para interpolação linear entre amostras; a aproximação do sinal exige refinamento temporal. Não são novas PDEs, mas constituem varredura científica e NÃO foram executados nesta entrega.

[D] Todos os limiares originais permanecem fixos. Eventos de replays são `counterfactual_shadow_relays`, não eventos reais das casas recíprocas históricas. Mudar Ω/g em um modelo recíproco altera o campo e exige outra simulação explícita; não se confunde essa intervenção com o replay passivo. O preset de controle passivo versus recíproco mantémΩ/γ/g e muda só a realimentação.

[?] Ausência de disparo não implica ausência de perturbação, de resposta ou de uma organização HRF; disparo tampouco demonstra DIO/GMFt. A hipótese de dessintonia só será avaliada contra o espectro recebido e as intervenções controladas, não pela diferença nominal0,13 versus1,85.

[D] Nos pares geométricos novos usa-se a MESMA referência plana G_P de limiar para isolar a alteração de geometria. Os valores próprios dos outros casos históricos continuam arquivados, sem reestimar nada. A reanálise antiga usa a referência que foi efetivamente registrada em cada caso, inclusive a orientação do giro. Isso não é uma calibração volumétrica nem certifica a transferência histórica integral.
