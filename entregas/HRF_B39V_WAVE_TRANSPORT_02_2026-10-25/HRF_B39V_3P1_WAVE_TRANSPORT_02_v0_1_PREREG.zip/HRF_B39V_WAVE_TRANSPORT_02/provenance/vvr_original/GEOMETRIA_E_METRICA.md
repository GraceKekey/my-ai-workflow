# Geometria recuperada e métrica prescrita

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[F/M] A B39V histórica resolve Δh=ρ no disco R155, h=0 na borda, com ρ=Σ2πα Nσ. α é intensidade de carga da equação, NÃO profundidade h mínima. Um vale: (x,y,α,σ)=(0,0,12,8). V2n acrescenta(0,55,6,5); V2o acrescenta(−45,0,8,6). Os dois últimos são assimetrias históricas em xy, não assimetrias em z. Foram lidos os h efetivamente gravados nos NPZ antigos; não foi resolvida novamente a equação de altura.

[M/D] `inputs/archived_geometry/` preserva P,h,T originais; P/T vêm da função histórica idêntica disco(155,0.75). Cada campo tem154.987 nós. A interpolação usa a conectividade triangular ORIGINAL, sem suavização e sem substituir o perfil por gaussiana parecida. A opção gaussiana analítica existe apenas em `valleys_exploratory.json`, explicitamente marcada. Profundidades recuperadas~−34,8641/−41,1199/−44,8920 constam do recibo estático; não são resultados de novas integrações.

[M] Extensão herdada, explicitamente candidata: H(x,y,z)=h(x,y) exp[−z²/(2ℓ²)], ℓ15. γij=δij+∂iH∂jH; ds²=−dt²+γij dxi dxj, N1, β0. ∂xH=hx e, ∂yH=hy e, ∂zH=−hz e/ℓ². γ é positiva definida e detg4<0; código audita assinatura e covariância de paridade. Não é solução de Einstein demonstrada.

[F/M] H é par em z, mas γxz e γyz são ímpares. O teste correto é γ(x,y,−z)=R γ(x,y,z) R, R=diag(1,1,−1), não igualdade ingênua de todos os componentes. Na fatia z0 o bloco xy reproduz a métrica da superfície linear por partes; z é a terceira coordenada do bulk, não h.

[?] h é contínuo por partes, seu gradiente salta entre triângulos. Fora da triangulação histórica usa-se h=0, com junção não globalmente C1. Não inferir curvatura pontual suave nessas interfaces. A largura de extensão é um parâmetro novo de3D, comparado separadamente15 versus30 no preset exploratório.

[D] A resolução usa também limites conservadores de passo próprio: Δℓi≤Δxi sqrt(1+sup|∂iH|²). Os limites de derivada vieram dos triângulos históricos arquivados, sem evolução, em `inputs/geometry_resolution_bounds.json`. A informação do espectro medido ainda precisa satisfazer12 células por comprimento próprio; boa aparência geométrica não concede PASS histórico.
