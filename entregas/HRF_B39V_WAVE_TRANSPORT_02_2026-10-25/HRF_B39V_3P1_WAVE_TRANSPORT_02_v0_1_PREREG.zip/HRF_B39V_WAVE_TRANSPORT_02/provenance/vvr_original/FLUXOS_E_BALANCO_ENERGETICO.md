# Fluxos físicos e balanço

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[F] Para assinatura−+++, Tμν=∂μφ∂νφ−gμν[(∂φ)²+m²φ²]/2. Para observadores Eulerianos com N1, β0: πn=p/M, e=[πn²+γij_inv ∂iφ∂jφ+m²φ²]/2 e J^i=−πn γij_inv∂jφ. p é momento integrado por nó. O programa não identifica J coordenado com uma medida física sem o referencial.

[M] O observador novo preserva mean(πn²) na quadratura concentrada. A integral nodal de e coincide com a parte de campo do Hamiltoniano para estados compatíveis com a borda. O observador antigo usava mean(πn)²; o déficit por variância é registrado separadamente na errata e nunca removido dos arquivos antigos.

[F/M] No plano z=±a, dA=√γ sqrt(γzz_inv) dxdy e s_i=±δiz/sqrt(γzz_inv). Fluxo de Killing por tempo coordenado: ±N²√γ Jz dxdy. Cada plano guarda integral positiva para fora, integral negativa em módulo para retorno, líquido=fora−retorno e bruto=fora+retorno. A soma dos fluxos orientados dos dois hemisférios é distinta da diferença assinada em coordenada z. A interpolação de superfície e trapézios precisam de refinamento.

[M] E± incluem metade do volume dual dos nós z0, conservando E++E−=Etotal. Fontes gaussianas também atuam fora de qualquer esfera finita; não chamar tempos de cruzamento de frentes causais. Há gráficos de chegada de amplitude, com resolução temporal explicitada.

[M] H=1/2 pM^-1p+1/2φKφ+Σrec[1/2v²+1/2Ω²X²+gX Cφ]. Sondas passivas são excluídas. dH/dt=φdot·F−Σdamp p φdot−Σrec γv². A quadratura do trabalho e das perdas usa os quatro estágios do mesmo RK4; resíduo relativo máximo amostrado deve ser≤1e−6. Borda exterior homogênea Dirichlet ou Neumann tem trabalho nulo no modelo discreto; sponge é contabilizada como dissipação e não como PML perfeita.

[M/D] Potências por hemisfério da fonte, sponge e receptores também são guardadas. Suas integrais são trapézios nos registros, rotuladas `hemisphere_work_sampled`; somente o ledger GLOBAL usa quadratura dos estágios. Energia Euleriana de cada hemisfério não inclui automaticamente interação com casas e não deve ser usada para exigir fechamento local exato com fluxos contínuos aproximados. As diferenças locais são observáveis de convergência, não energia inventada.

[D] Componentes Jr,Jtheta,Jz usam uma tríade ortonormal: normal físico à superfície z constante, radial tangente normalizado, azimutal obtido por Gram–Schmidt. Circulação é ∮Ji dxi em círculos coordenados; não confundir essa integral de linha com o momento de volume de Jtheta ou com potência. Lz=−∫πn(x∂yφ−y∂xφ)dV é operacional; dLz/dt é torque operacional. Malha, fonte, casas e sponge podem quebrar a conservação; nenhuma carga de Noether axial é presumida em paisagens sem simetria axial.
