"""Only algebraic tests. No PDE integration or scientific sweep."""
import sys,unittest,os,tempfile
from pathlib import Path
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'hrf-vvr-mpl'))
os.environ.setdefault('XDG_CACHE_HOME',str(Path(tempfile.gettempdir())/'hrf-vvr-cache'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
if __name__=='__main__':
    result=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.discover(str(Path(__file__).resolve().parents[1]/'tests'),pattern='test_algebra*.py'))
    raise SystemExit(not result.wasSuccessful())
