@echo off
setlocal
cd /d "%~dp0.."
set OPENBLAS_NUM_THREADS=1
set OMP_NUM_THREADS=1
set MKL_NUM_THREADS=1
python -X utf8 -I scripts\vvr.py %*
exit /b %ERRORLEVEL%
