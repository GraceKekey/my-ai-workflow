"""Isolated-Python launcher; nothing runs when imported."""
import os,sys,tempfile
from pathlib import Path
for key in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[key]='1'
os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'hrf-vvr-mpl'))
os.environ.setdefault('XDG_CACHE_HOME',str(Path(tempfile.gettempdir())/'hrf-vvr-cache'))
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
if __name__=='__main__':
    from hrf_vertical.cli import main
    raise SystemExit(main())
