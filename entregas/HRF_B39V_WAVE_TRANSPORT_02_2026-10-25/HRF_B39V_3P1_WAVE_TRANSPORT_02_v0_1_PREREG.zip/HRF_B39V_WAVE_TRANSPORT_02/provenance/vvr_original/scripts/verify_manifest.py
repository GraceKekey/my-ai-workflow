"""Portable SHA-256 verification, including spaces and Unicode paths."""
from pathlib import Path
import hashlib,sys
root=Path(__file__).resolve().parents[1]
def main():
    manifest=root/(sys.argv[1] if len(sys.argv)>1 else 'MANIFESTO_SHA256.txt');count=0
    for line in manifest.read_text(encoding='utf-8').splitlines():
        if not line or line.startswith('#'):continue
        expected,name=line.split('  ',1);p=(root/name).resolve()
        if not p.is_relative_to(root):raise ValueError('unsafe manifest path')
        h=hashlib.sha256()
        with p.open('rb') as f:
            for chunk in iter(lambda:f.read(1024**2),b''):h.update(chunk)
        if h.hexdigest()!=expected:raise ValueError('SHA-256 mismatch: '+name)
        count+=1
    print(f'OK: {count} files verified');return 0
if __name__=='__main__':raise SystemExit(main())
