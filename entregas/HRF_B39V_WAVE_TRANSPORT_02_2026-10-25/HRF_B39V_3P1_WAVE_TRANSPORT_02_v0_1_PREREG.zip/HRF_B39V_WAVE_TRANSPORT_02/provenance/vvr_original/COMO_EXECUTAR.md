# Instalação, dry-run e execução posterior

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[D] Descompacte o ZIP: a raiz interna curta é `HRF_B39V_VVR_v0_1`, para facilitar Windows/Colab. Use Python3.12; a instalação não executa nada.

```bash
cd HRF_B39V_VVR_v0_1
python3 -I scripts/verify_manifest.py
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
OPENBLAS_NUM_THREADS=1 OMP_NUM_THREADS=1 MKL_NUM_THREADS=1 .venv/bin/python -I scripts/test_algebra.py
.venv/bin/python -I scripts/vvr.py plan --config config/vertical_symmetric.json --output planejamento
```

No Windows: `py -3 -m venv .venv`, depois `.venv\Scripts\python.exe -m pip install -r requirements.txt`. Use `python -X utf8 -I` para os launchers, ou `scripts\run_windows.bat plan --config config\vertical_symmetric.json --output planejamento`. Linux tem `bash scripts/run_linux.sh ...`. Nenhum launcher omite a exigência explícita de execução.

## Reanálise antiga, sem solver

```bash
.venv/bin/python -I scripts/vvr.py reanalyze --input /caminho/real/spiral_standard --output reanalise_antiga
.venv/bin/python -I scripts/vvr.py run --config config/receivers_frequency_sweep.json --input /caminho/real/spiral_standard/splus --output replays --execute
```

[D] O primeiro comando reprocessa dados arquivados, preservando o veredito original; o segundo lança uma VARREDURA DE OSCILADORES, que requer autorização posterior nesta tarefa e não foi rodado. A pasta de entrada precisa ter case.json, grid.npz, observations.npz, frames e seus catálogos/hashes. Um link do Drive não é um caminho local; no Colab monte sua conta com `drive.mount('/content/drive')` e indique a pasta real. Não é necessário baixar um ZIP volumétrico pelo navegador.

## Integração futura, somente após desbloqueio documental e autorização

```bash
python3 -I scripts/verify_manifest.py hashes_antes_da_execucao.txt
.venv/bin/python -I scripts/vvr.py run --config config/vertical_symmetric.json --case flat_z100 --output resultados/vertical_symmetric --execute
.venv/bin/python -I scripts/vvr.py analyze --input resultados/vertical_symmetric/flat_z100 --output analises/flat_z100
```

[D] Nesta edição, o segundo comando será bloqueado pelas duas referências documentais obrigatórias ausentes. Não edite somente o status da dependência: isso viola o manifesto. Será necessário ler os documentos, revisar a consistência, emitir uma revisão versionada do pré-registro e obter autorização para as novas integrações. Não há execução automática na instalação/importação/teste. Sem `--execute`, `run` também faz somente planejamento. Repetir um comando autorizado retoma chunks/checkpoint compatíveis, sem mudar parâmetros.

## Evidências e figuras futuras

```bash
.venv/bin/python -I scripts/vvr.py reference-evidence --spatial resultados/refinement_study/reference_space_9 resultados/refinement_study/reference_space_17 resultados/refinement_study/reference_space_33 --temporal resultados/refinement_study/reference_time_0.05 resultados/refinement_study/reference_time_0.025 resultados/refinement_study/reference_time_0.0125 --output evidencias_referencia.json
.venv/bin/python -I scripts/vvr.py basic-evidence --input resultados/vertical_symmetric/flat_z100 --analysis analises/flat_z100 --output evidencias_basicas.json
.venv/bin/python -I scripts/vvr.py control-evidence --first resultados/controle/A --second resultados/controle/B --analysis-first analises/A --analysis-second analises/B --allow grid --gate SPATIAL_CONVERGENCE --output evidencias_malha.json
.venv/bin/python -I scripts/vvr.py merge-evidence --input evidencias_referencia.json evidencias_basicas.json evidencias_malha.json --output evidencias.json
.venv/bin/python -I scripts/vvr.py certify --evidence evidencias.json --output controles_certificados.json
.venv/bin/python -I scripts/vvr.py analyze --input resultados/vertical_symmetric/flat_z100 --output analises/flat_z100 --flowlines --evidence evidencias.json
.venv/bin/python -I scripts/vvr.py figures --input resultados/chirality_pair/splus resultados/chirality_pair/sminus --analysis analises --output figuras --max-frames 16
```

[D] A/B são caminhos EXEMPLO para casos realmente comparáveis, não dados incluídos. Faltam ainda evidências independentes de dt, fronteira e rastreamento; sem elas a estrutura continua INCONCLUSIVE. `flow-evidence --first-analysis ... --second-analysis ...` mede estabilidade das curvas; `control-evidence` usa TEMPORAL_CONVERGENCE ou BOUNDARY_ROBUSTNESS para os outros controles. Comparações não admitem outras mudanças silenciosas. `--comparisons arquivo.json` em `figures` gera a Figura8 de comparações reais; família de vales na mesma malha gera a Figura5 e um par s± gera a Figura7. GIF usa Pillow; MP4 requer ffmpeg e, se ausente, seu bloqueio é registrado sem falsificar um vídeo.
