# Limites científicos e numéricos

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[?] Duas versões documentais obrigatórias e os dados científicos do Colab não foram acessados. A entrega é um pré-registro técnico fundamentado no código e nas fontes locais, com adoção documental e auditoria completa do baseline bloqueadas. Não se declara a bancada liberada para execução nem homologada pelas versões ausentes.

[M/?] Campo escalar clássico, geometria prescrita estática N1/β0, discretização P1 por partes, massa concentrada, amostragem trilinear dos detectores e RK4. Não é eletromagnetismo vetorial/polarização; não demonstra fótons, spin/helicidade intrínseca, partículas quânticas, DIO, GMFt físico, gravidade emergente, dimensão derivada ou dualidade holográfica.

[D] W é propagação no modelo. G, reconstrução geométrica física, e D, dicionário boundary–bulk, permanecem independentes e bloqueados. `BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY` é mantido mesmo se todos os testes de W passarem no futuro.

[?] A altura histórica é linear por partes e sua extensão3D é uma escolha nova. Malha graduada herdada é estática, sem células penduradas; não é AMR dinâmico. Os novos presets fornecidos são uniformes para facilitar comparações. Fora do disco e nos contornos há interfaces a controlar.

[?] Sponge não é PML; Gaussianas têm caudas e pulsos não são monocromáticos. Aliasing prévio à gravação não é excluído por PSD discretizada sem potência perto de Nyquist. A banda95% não prova ausência de componentes fracas relevantes; exigem-se refinamentos. Gravação mais espaçada pode impossibilitar curvas J/e, fase ou resposta; esses observáveis ficam inconclusivos, sem interpolação para fingir resolução.

[D] Campos/momentos dos volumes são float32 nos presets principais; checkpoints e ledger são float64. NPZ é compressão sem perda DOS VALORES GRAVADOS, não garantia de que float32 seja igual ao estado interno. A quantização é explícita e deve ser controlada; limiar de paridadeφ2e−6 é maior que a escala relativa de arredondamento float32.

[?] Estimativas8500bytes/nó+512MiB são conservadoras de planejamento, não RSS medido em rodadas novas. CPU é proxy240×N×passos, sem conversão não calibrada em horas. Espaço livre e memória efetiva são checados antes do lançamento. Cota insuficiente bloqueia, sem reduzir silenciosamente malha ou frequência de gravação. Resultados antigos não são apagados para abrir espaço.
