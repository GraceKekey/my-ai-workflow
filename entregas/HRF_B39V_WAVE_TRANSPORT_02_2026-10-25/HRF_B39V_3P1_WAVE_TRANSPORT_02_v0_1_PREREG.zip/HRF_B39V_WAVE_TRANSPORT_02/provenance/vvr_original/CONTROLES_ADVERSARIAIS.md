# Controles adversariais e referências

**Estado: CÓDIGO NOVO — PRÉ-REGISTRADO — SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] VVR-01, v0.1, 24/10/2026. [F] física estabelecida; [M] modelo; [H] hipótese; [?] aberto; [D] decisão.


[D] Executados nesta fase apenas testes de álgebra, matrizes, transformadas e IO temporário, todos identificados como sintéticos. Nenhuma evolução temporal de campo, nenhuma varredura científica de receptor e nenhum estudo físico de convergência foi realizado.

[F/M, testes de software] Estado nulo→RHS exatamente nulo; identidades Hamiltonianas com fonte, amortecimento, detector recíproco e passivo; projeção de energia; quadratura; interpolação linear; assinatura/paridade da métrica; medidas próprias de fluxo; hemisférios; circulação conhecida; resposta analítica e exponencial matricial de oscilador; PSD de sinal sintético com mais de uma banda; modos m± e kz conhecido; m≠0,kz0; corrente azimutal sem z; curvas verticais retas simétricas; corrente radial; retorno; dipolo antipodal; centros/nemático; hashes, corrupção, retomada de chunks e metadados finais. Curvas helicoidais positivas são ARRAYS FABRICADOS exclusivamente para testar a regra; não são solução da bancada.

[D] Referências futuras: modo analítico φ=Π sin[π(xi−ai)/Li] cos(ωt), ω²=m²+Σ(π/Li)², caixa±10, Dirichlet, fonte e g nulos, m0,2. Malhas9³/17³/33³ e dt0,05/0,025/0,0125 (temporal na mesma malha33³) estão pré-registrados. O código mede dt efetivo; não força ordem4 quando o ajuste de estabilidade deixa razões diferentes. Erro RMS absoluto normalizado por amplitude1≤0,02; ordens espacial≥1,5 e temporal≥3,5. Esses gates permanecem NOT_EXECUTED.

[D] Controles grandes: planoz25/60/100 com resolução mantida; contornos Dirichlet/Neumann/sponge; largura10/15; intensidade0,5/0,25; domínio xy130/150 mantendoΔxy; domínio z assimétrico identificado; par s±; fonte nula; fonte sem giro; acoplamento passivo/recíproco; malhas completas53²×41/105²×81/209²×161. O último caso ultrapassa a cota de memória e não pode ser executado nessa cota.

[?] Uma referência compacta ou um teste de álgebra não valida convergência da estrutura helicoidal na caixa completa. Comparações exigem tempos físicos iguais, ROI comum e registro de toda mudança independente. `controls.differences` rejeita pares confundidos. Chegada, fluxo, resposta e classificação precisam permanecer estáveis; arquivo de evidência precisa apontar fontes com SHA-256, não somente dizer PASS.
