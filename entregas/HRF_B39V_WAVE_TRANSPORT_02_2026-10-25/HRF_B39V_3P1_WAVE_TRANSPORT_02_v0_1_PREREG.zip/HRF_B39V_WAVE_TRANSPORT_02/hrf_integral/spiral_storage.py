from pathlib import Path
import json
import numpy as np
from .io import atomic_json,atomic_npz,digest

class FrameStore:
    def __init__(self,path,run_id):
        self.path=Path(path);self.path.mkdir(parents=True,exist_ok=True);self.catalog_file=self.path/'frames.json';self.run_id=run_id
        if self.catalog_file.exists():
            self.catalog=json.loads(self.catalog_file.read_text())
            if self.catalog['run_id']!=run_id:raise ValueError('frame store belongs to different configuration/code')
            for frame in self.catalog['frames']:
                if digest(self.path/frame['file'])!=frame['sha256']:raise ValueError('corrupt frame '+frame['file'])
        else:self.catalog={'run_id':run_id,'frames':[]}
    def write(self,index,step,t,arrays,cuts):
        name=f'frame_{index:06d}.npz';cutname=f'cuts_{index:06d}.npz';atomic_npz(self.path/name,**arrays);atomic_npz(self.path/cutname,**cuts)
        rec=dict(index=index,step=step,t=t,file=name,sha256=digest(self.path/name),cuts_file=cutname,cuts_sha256=digest(self.path/cutname))
        # Idempotent replacement after a crash between data and checkpoint writes.
        existing=[f for f in self.catalog['frames'] if f['step']<step];self.catalog['frames']=existing+[rec];atomic_json(self.catalog_file,self.catalog);return rec
    def read(self,rec,verify=True,cuts=False):
        name=rec['cuts_file' if cuts else 'file'];sha=rec['cuts_sha256' if cuts else 'sha256']
        if verify and digest(self.path/name)!=sha:raise ValueError('corrupt frame '+name)
        return np.load(self.path/name,allow_pickle=False)
