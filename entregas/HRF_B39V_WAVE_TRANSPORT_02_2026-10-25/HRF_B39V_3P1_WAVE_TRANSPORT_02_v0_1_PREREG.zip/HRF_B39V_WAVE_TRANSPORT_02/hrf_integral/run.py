"""New spiral CLI. Default plans only; --execute required to launch a supplied preset."""
import argparse,json,os,sys,time,platform,shutil
from fractions import Fraction
from math import gcd,lcm,ceil
from pathlib import Path
import numpy as np
from .spiral_config import ROOT,load_config,cases,estimate,code_digest
from .mesh_adaptive import RectilinearMesh,axes_from_config
from .spiral_receivers import catalog
from .spiral_geometry import build_metric
from .spiral_source import build_forcing
from .spiral_storage import FrameStore
from .dynamics import rk4
from .spiral_system import SpiralSystem
from .volume_observables import VolumeObserver
from .io import atomic_json,atomic_npz,fingerprint,digest
from .history import load

def observation_operator(mesh,c):
    z=np.asarray(c['diagnostics']['z_planes']);r=np.asarray(c['diagnostics']['radii']);theta=np.arange(c['diagnostics']['angular_samples'])*2*np.pi/c['diagnostics']['angular_samples']
    coords=np.array([[radius*np.cos(a),radius*np.sin(a),zz] for zz in z for radius in r for a in theta]);inside=np.all((coords>=mesh.bounds[:,0])&(coords<=mesh.bounds[:,1]),axis=1)
    # Keep all requested probes, explicitly mask out-of-domain entries instead of clamping.
    C=mesh.interpolation(coords[inside]);xy_indices=[int(np.argmin(abs(mesh.axes[2]-zz))) for zz in z]
    return dict(C=C,points=coords,inside=inside,z=z,r=r,theta=theta,xy_indices=xy_indices,actual_z=mesh.axes[2][xy_indices])

def run_case(c,out,stop_steps=None):
    folder=Path(out)/c['case_id'];folder.mkdir(parents=True,exist_ok=True);plan=estimate(c);run_id=fingerprint(dict(config=c,code=code_digest()))
    done=folder/'case.json'
    if done.exists():
        old=json.loads(done.read_text())
        if old['run_id']!=run_id:raise ValueError('configuration/code changed; use a fresh output directory')
        if old['status']=='COMPLETED':
            FrameStore(folder/'frames',run_id)
            if digest(folder/'observations.npz')!=old['observations_sha256']:raise ValueError('corrupt observation traces')
            return old
    if plan['status']=='BLOCKED_RESOURCE_LIMIT':
        result=dict(status='BLOCKED_RESOURCE_LIMIT',run_id=run_id,case_id=c['case_id'],resources=plan);atomic_json(done,result);return result
    beg=time.monotonic();mesh=RectilinearMesh(axes_from_config(c['grid']));metric,H=build_metric(c);rec=catalog(c,mesh.bounds);active=rec['active'];points=rec['xyz'][active];spec=c['receivers']
    reciprocal_mask=(np.flatnonzero(active)<468) if spec.get('extra_mode','passive')=='passive' else np.ones(len(points),bool)
    system=SpiralSystem(mesh,metric,c['field']['mass'],reciprocal_mask=reciprocal_mask,points=points,omega=spec['omega'],coupling=spec['coupling'],gamma_r=spec['gamma'],boundary=c['field']['boundary'],sponge=c['field']['sponge'])
    force,dipole=build_forcing(system,c);obs=VolumeObserver(system);probes=observation_operator(mesh,c)
    # Integrate on a rational common observation lattice: the final frame remains uniformly sampled.
    intervals=[Fraction(str(c['observation'][key])).limit_denominator(10**6) for key in ('sample_dt','frame_dt')]
    den=lcm(*[q.denominator for q in intervals]);numer=[q.numerator*(den//q.denominator) for q in intervals];tick=gcd(*numer)/den
    dt=tick/ceil(tick/min(c['field']['dt'],system.dt_bound));nt=int(round(c['field']['t_end']/dt));sample_stride=int(round(c['observation']['sample_dt']/dt));frame_stride=int(round(c['observation']['frame_dt']/dt))
    run=dict(status='RUNNING',run_id=run_id,case_id=c['case_id'],config=c,resources=plan,dt=dt,sample_stride=sample_stride,frame_stride=frame_stride,frame_frequency_bound=.55/system.dt_bound,full_field_frame_nyquist_resolved=bool(c['observation']['frame_dt']*.55/system.dt_bound<np.pi),active_receivers=int(active.sum()),active_historical=int(active[:468].sum()),catalog_receivers=len(active),historical_catalog_count=468,extra_receivers_mode=spec.get('extra_mode','passive'),energy_scope='field plus reciprocal detectors; passive-probe energy excluded',phase_convention='negative temporal frequency: demodulate 2 phi exp(+i omega t); primary angular m=rotation',notice='TECHNICAL_SMOKE_ONLY' if plan['technical_smoke'] else 'exploratory 3D prescribed geometry; no physical holographic dictionary')
    atomic_json(folder/'run.json',run)
    atomic_npz(folder/'grid.npz',x=mesh.axes[0],y=mesh.axes[1],z=mesh.axes[2],H=H(mesh.xyz).reshape(mesh.shape).astype('f4'),node_volume=obs.node_volume.reshape(mesh.shape),receiver_xyz=rec['xyz'],receiver_active=active,receiver_kind=rec['kind'],receiver_labels=rec['labels'],probe_xyz=probes['points'],probe_inside=probes['inside'],probe_z=probes['z'],probe_r=probes['r'],probe_theta=probes['theta'],slice_actual_z=probes['actual_z'])
    store=FrameStore(folder/'frames',run_id);state=np.zeros(2*mesh.n+2*system.h);start=0;ts=[];xs=[];ps=[];fields=[];energies=[];cp=folder/'checkpoint.npz'
    if cp.exists():
        with np.load(cp,allow_pickle=False) as data:
            if str(data['run_id'])!=run_id:raise ValueError('checkpoint configuration mismatch')
            state=data['state'].copy();start=int(data['step']);ts=list(data['ts']);xs=list(data['X']);ps=list(data['P']);fields=list(data['field']);energies=list(data['energy'])
    network=None;rho=0.
    if spec['stationary_network']:
        netload=system.mm*system.N**2
        if system.bc!='neumann':netload[mesh.boundary]=0
        rho=500*c['source']['amplitude']*np.linalg.norm(dipole)/np.linalg.norm(netload);network=system.network(netload,1.)
    interrupted=False
    for i in range(start,nt+1):
        t=i*dt
        if (i%sample_stride==0 or i==nt) and not (ts and abs(ts[-1]-t)<dt/2):
            ts.append(t);xs.append(state[2*mesh.n:2*mesh.n+system.h].copy());ps.append(state[2*mesh.n+system.h:].copy());fields.append(system.C@state[:mesh.n]);energies.append(system.energy(state,t))
        if i%frame_stride==0 or i==nt:
            observed=obs.evaluate(state);dtype=c['observation']['dtype'];phi=state[:mesh.n].reshape(mesh.shape);p=state[mesh.n:2*mesh.n].reshape(mesh.shape)
            ring=np.full(len(probes['points']),np.nan);ring[probes['inside']]=probes['C']@state[:mesh.n]
            cuts=dict(t=t,xy=phi[:,:,probes['xy_indices']].transpose(2,0,1).astype(dtype),xz=phi[:,np.argmin(abs(mesh.axes[1])),:].astype(dtype),yz=phi[np.argmin(abs(mesh.axes[0])),:,:].astype(dtype),ring=ring.reshape(len(probes['z']),len(probes['r']),len(probes['theta'])).astype(dtype))
            arrays=dict(t=t,phi=phi.astype(dtype),momentum=p.astype(dtype),energy_density=observed['energy_density'].reshape(mesh.shape).astype(dtype),flux=observed['flux'].reshape(*mesh.shape,3).astype(dtype),orbital_Lz_operational=observed['orbital_Lz_operational'],total_Eulerian_energy=observed['total_Eulerian_energy'])
            frame_index=int(i//frame_stride) if i%frame_stride==0 else int(np.ceil(i/frame_stride));store.write(frame_index,i,t,arrays,cuts)
            atomic_npz(cp,run_id=run_id,step=i,state=state,ts=ts,X=xs,P=ps,field=fields,energy=energies)
        if i==nt:break
        if stop_steps is not None and i-start>=stop_steps:interrupted=True;break
        state=rk4(system,state,t,dt,force)
        if not np.isfinite(state).all() or np.max(abs(state))>1e30:raise FloatingPointError('nonfinite/divergent evolution')
    if interrupted:
        result=dict(run,status='INTERRUPTED_FOR_TEST',last_step=i);atomic_json(done,result);return result
    ts=np.asarray(ts);xs=np.asarray(xs);ps=np.asarray(ps);rl=load('b39_rele');R=rl.leitura(ts,xs,ps,np.full(system.h,spec['omega']),Xr=network,A=rho,Om_r=1.)
    thresholds=json.loads((ROOT/'inputs/historical_thresholds.json').read_text());key=spec['historical_threshold_case']
    paired_key=key.replace('_s+1','_s-1') if c['rotation']==-1 else key
    if paired_key in thresholds:key=paired_key
    if key not in thresholds:raise ValueError('MISSING_SOURCE historical thresholds '+key)
    theta=thresholds[key];lock=rl.rele(ts,R,theta['theta_lock'],'trava');release=rl.rele(ts,R,theta['theta_release'],'solta')
    atomic_npz(folder/'observations.npz',ts=ts,X=xs,P=ps,field=fields,readout=R,relay_lock=lock,relay_release=release,brightness=rl.lampada(ts,release),energy=energies,active_catalog_indices=np.flatnonzero(active),network=np.asarray(network) if network is not None else np.zeros(system.h,dtype=complex),network_scale=rho)
    result=dict(run,status='COMPLETED',seconds=time.monotonic()-beg,frames=len(store.catalog['frames']),observations_sha256=digest(folder/'observations.npz'),threshold_policy='unchanged historical values; no new calibration; exploratory readout not certified',thresholds=theta,stationary_network=bool(spec['stationary_network']),relay_fired=int(np.any(lock>0,axis=0).sum()),ended_after_source=c['field']['t_end']>(c['source']['duration']+(c['source'].get('count',1)-1)*c['source'].get('period',0) if c['source']['mode']=='pulse_train' else c['source']['duration']),scientific_verdict='INCONCLUSIVE_SPIRAL_STRUCTURE')
    atomic_json(done,result);cp.unlink(missing_ok=True);return result

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--config',required=True);ap.add_argument('--output',required=True);ap.add_argument('--execute',action='store_true');ap.add_argument('--case',default=None);ap.add_argument('--stop-steps',type=int,default=None,help=argparse.SUPPRESS);a=ap.parse_args();c=load_config(a.config);out=Path(a.output);out.mkdir(parents=True,exist_ok=True)
    case_list=list(cases(c));case_list=[x for x in case_list if a.case is None or x['case_id']==a.case]
    if not case_list:raise ValueError('no matching cases')
    plans=[dict(case_id=x['case_id'],**estimate(x)) for x in case_list];total=sum(p['estimated_uncompressed_output_bytes'] for p in plans)
    plan=dict(status='PLANNED_NOT_EXECUTED',config=c,cases=plans,total_uncompressed_disk_bytes=total,code_sha256=code_digest(),execution_authorized_by_this_command=bool(a.execute),environment=dict(python=sys.version,numpy=np.__version__,platform=platform.platform(),BLAS_threads={k:os.environ.get(k) for k in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS')}))
    if total>c['limits']['disk_bytes']:plan['status']='BLOCKED_RESOURCE_LIMIT';plan['reason']='aggregate sweep disk estimate exceeds bound'
    atomic_json(out/'plan.json',plan);print(json.dumps(plan),flush=True)
    if not a.execute:return 0
    if plan['status']=='BLOCKED_RESOURCE_LIMIT':return 2
    results=[]
    for case in case_list:
        result=run_case(case,out,a.stop_steps);results.append(result);print(json.dumps({k:result[k] for k in ('case_id','status','frames','seconds') if k in result}),flush=True)
    atomic_json(out/'execution.json',dict(status='TECHNICAL_SMOKE_ONLY' if c['classification']=='TECHNICAL_SMOKE_ONLY' else 'EXECUTED_EXPLORATORY',cases=[dict(case_id=x['case_id'],status=x['status']) for x in results],HRF_holography='BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY'))
    return 0
if __name__=='__main__':raise SystemExit(main())
