"""Retain ambiguous lobes. Deterministic tie-breaking is not evidence of a helix."""
import numpy as np
from scipy.ndimage import maximum_filter

def local_peaks(slice_phi,x,y,tie_relative=.001,max_count=8):
    amp=np.abs(slice_phi);peak=float(amp.max(initial=0))
    if peak<=1e-14:return dict(points=[],ambiguous=True,primary=None)
    local=(amp==maximum_filter(amp,size=3,mode='constant'))&(amp>=.05*peak)
    ii,jj=np.nonzero(local);order=np.argsort(-amp[ii,jj],kind='stable')[:max_count]
    points=[[float(x[ii[k]]),float(y[jj[k]]),float(amp[ii[k],jj[k]])] for k in order]
    ambiguous=sum(p[2]>=peak*(1-tie_relative) for p in points)>1
    return dict(points=points,ambiguous=ambiguous,primary=None if ambiguous or not points else points[0][:2])

def classify_line(z,xy,dx,dy,d):
    z=np.asarray(z);xy=np.asarray(xy,float);valid=np.isfinite(xy).all(axis=1)
    if valid.sum()<d['min_valid_z']:return dict(label='INDEFINITE_AMBIGUOUS_OR_MISSING_RIDGE')
    z=z[valid];xy=xy[valid];radius=np.linalg.norm(xy,axis=1);spatial=max(dx,dy)
    line=np.column_stack([np.polyval(np.polyfit(z,xy[:,k],1),z) for k in (0,1)]);line_error=float(np.sqrt(np.mean(np.sum((xy-line)**2,axis=1))))
    if np.median(radius)<2*spatial:return dict(label='AXIAL_LINE_NO_RESOLVED_TWIST',line_rmse=line_error)
    theta=np.unwrap(np.arctan2(xy[:,1],xy[:,0]));ang_span=float(np.ptp(theta));rad_cv=float(radius.std()/max(radius.mean(),1e-30));fit=np.polyfit(z,theta,1);pred=np.c_[np.cos(np.polyval(fit,z)),np.sin(np.polyval(fit,z))]*radius.mean();helix_error=float(np.sqrt(np.mean(np.sum((xy-pred)**2,axis=1)))/radius.mean())
    if line_error<=spatial and ang_span<np.pi/4:label='LINE_LIKE'
    elif ang_span>=d['helix_angle_span_min'] and rad_cv<=d['ridge_radius_cv_max'] and helix_error<=d['ridge_relative_rmse_max']:label='HELIX_GEOMETRY_CANDIDATE'
    elif ang_span>=d['weak_helix_span_min'] and rad_cv<=d['ridge_radius_cv_max'] and helix_error<=d['ridge_relative_rmse_max']:label='WEAK_HELIX_GEOMETRY_CANDIDATE'
    elif ang_span<np.pi/4 and np.ptp(radius)>2*spatial:label='RADIAL_EXPANSION_CANDIDATE'
    else:label='INDEFINITE'
    return dict(label=label,line_rmse=line_error,angle_span=ang_span,radius_cv=rad_cv,helix_relative_rmse=helix_error,dtheta_dz=float(fit[0]),pitch_z_per_2pi=float(2*np.pi/fit[0]) if abs(fit[0])>1e-12 else None)
