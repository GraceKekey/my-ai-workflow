"""Finite-window complex lock-in. Phase is a narrow-band observable, never arg(real phi)."""
import numpy as np
from scipy.signal import fftconvolve

def demodulate(values,t,omega,cycles=2.):
    values=np.asarray(values,float);t=np.asarray(t,float)
    if len(t)<3 or omega<=0:return np.zeros(values.shape,dtype=complex),np.zeros(len(t),bool),{'status':'INSUFFICIENT_TEMPORAL_WINDOW'}
    dt=np.diff(t)
    if not np.allclose(dt,dt[0],rtol=1e-5,atol=1e-9):raise ValueError('phase analysis requires uniform frame times')
    if omega*dt[0]>=np.pi:raise ValueError('temporal aliasing')
    width=max(3,int(round(cycles*2*np.pi/omega/dt[0])));width+=1-width%2
    if width>len(t):return np.zeros(values.shape,dtype=complex),np.zeros(len(t),bool),{'status':'INSUFFICIENT_TEMPORAL_WINDOW','required_frames':width,'available_frames':len(t)}
    window=np.hanning(width);window/=window.sum();shape=(len(t),)+(1,)*(values.ndim-1)
    # For cos(m theta+kz z-omega t), lock-in phase = m theta+kz z.
    signal=2*np.nan_to_num(values)*np.exp(1j*omega*t).reshape(shape)
    kernel=window.reshape((width,)+(1,)*(values.ndim-1));z=fftconvolve(signal,kernel,mode='same',axes=0)
    valid=np.zeros(len(t),bool);half=width//2;valid[half:len(t)-half]=True
    return z,valid,{'status':'COMPUTED_WINDOWED_LOCK_IN','window_frames':width,'window_cycles':cycles,'edge_frames_discarded_each_side':half,'phase_convention':'negative temporal frequency; multiply real phi by +i omega t'}

def azimuthal(phasor,theta,m_values,relative_floor=1e-6,absolute_floor=1e-14,resultant_min=.05):
    z=np.asarray(phasor,dtype=complex);theta=np.asarray(theta);m=np.asarray(m_values);amp=np.abs(z);floor=max(absolute_floor,float(np.nanmax(amp,initial=0))*relative_floor)
    point_valid=np.isfinite(z)&(amp>floor);safe=np.where(np.isfinite(z),z,0)
    coeff=np.einsum('...a,ma->...m',safe,np.exp(-1j*m[:,None]*theta[None,:]))/len(theta)
    power=np.abs(coeff)**2;total=np.mean(np.abs(safe)**2,axis=-1);fraction=np.divide(power,total[...,None],out=np.zeros_like(power),where=total[...,None]>0)
    resultant=np.divide(np.sum(safe,axis=-1),np.sum(amp,axis=-1),out=np.zeros(z.shape[:-1],complex),where=np.sum(amp,axis=-1)>floor)
    ring_phase=np.where(np.abs(resultant)>=resultant_min,np.angle(resultant),np.nan)
    winding=np.sum(np.angle(np.roll(safe,-1,axis=-1)*np.conj(safe)),axis=-1)/(2*np.pi)
    winding=np.where(np.all(point_valid,axis=-1),winding,np.nan)
    return dict(amplitude=amp,phase=np.where(point_valid,np.angle(z),np.nan),coefficients=coeff,power_fraction=fraction,circular_mean_phase=ring_phase,circular_resultant=np.abs(resultant),winding=winding,point_valid=point_valid,amplitude_floor=floor)

def longest_contiguous(indices):
    indices=np.asarray(indices,int)
    if not len(indices):return indices
    groups=np.split(indices,np.flatnonzero(np.diff(indices)>1)+1);return max(groups,key=len)

def axial_phase_fit(z,coeff,minimum=4,residual_max=.25,phase_span_min=.5):
    z=np.asarray(z);c=np.asarray(coeff);amp=abs(c);valid=np.isfinite(c)&(amp>max(np.max(amp,initial=0)*1e-6,1e-14));idx=longest_contiguous(np.flatnonzero(valid))
    if len(idx)<minimum:return dict(status='INSUFFICIENT_CONNECTED_Z',kz=None,phase_span=None,relative_residual=None)
    phase=np.unwrap(np.angle(c[idx]));raw_step=np.abs(np.angle(c[idx][1:]*np.conj(c[idx][:-1])))
    if np.any(raw_step>.8*np.pi):return dict(status='POSSIBLE_AXIAL_ALIASING',kz=None,phase_span=None,relative_residual=None)
    fit=np.polyfit(z[idx],phase,1,w=amp[idx]);pred=np.polyval(fit,z[idx]);span=float(np.ptp(phase));res=float(np.sqrt(np.average((phase-pred)**2,weights=amp[idx]**2))/max(span,.1))
    return dict(status='PHASE_TWIST_CANDIDATE' if span>=phase_span_min and res<=residual_max else 'NO_RESOLVED_LINEAR_TWIST',kz=float(fit[0]),phase_span=span,relative_residual=res,valid_z=int(len(idx)),z_min=float(z[idx[0]]),z_max=float(z[idx[-1]]))
