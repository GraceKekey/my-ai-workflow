"""Strict inputs and preflight: no solver allocation in planning mode."""
from pathlib import Path
from copy import deepcopy
from itertools import product
import hashlib,json
import numpy as np
from .mesh_adaptive import axes_from_config
from .io import fingerprint,digest
ROOT=Path(__file__).resolve().parents[1]

def load_config(path):
    c=json.loads(Path(path).read_text());validate(c);return c

def validate(c):
    for key in ('id','classification','grid','source','field','receivers','observation','limits','diagnostics'):
        if key not in c:raise ValueError('missing '+key)
    src=c['source'];fld=c['field'];obs=c['observation'];limits=c['limits']
    axes=axes_from_config(c['grid'])
    if len(axes)!=3 or any(len(a)<3 or not np.isfinite(a).all() or np.any(np.diff(a)<=0) for a in axes):raise ValueError('invalid grid axes')
    if any(src[k]<=0 for k in ('duration','sigma_xy','sigma_z','omega')) or src['amplitude']<0:raise ValueError('invalid source')
    if fld['mass']<0 or fld['dt']<=0 or fld['t_end']<=0:raise ValueError('invalid field parameters')
    if fld['boundary'] not in ('dirichlet','neumann','sponge'):raise ValueError('unknown boundary')
    if obs['sample_dt']<=0 or obs['frame_dt']<=0 or obs['frame_dt']<fld['dt']:raise ValueError('invalid observation interval')
    if src['mode'] not in ('pulsed','quasi_harmonic','pulse_train'):raise ValueError('unknown source mode')
    if src['mode']=='pulse_train' and (src.get('count',0)<1 or src.get('period',0)<src['duration']):raise ValueError('overlapping/invalid pulse train')
    if src['mode']=='quasi_harmonic' and not 0<src.get('ramp',0)<src['duration']/2:raise ValueError('invalid harmonic ramp')
    if c['classification'] not in ('TECHNICAL_SMOKE_ONLY','EXPLORATORY_NOT_HISTORICAL_MATCH','CLOSEST_HISTORICAL_PARAMETERS_NOT_CERTIFIED'):raise ValueError('unlabelled exploratory preset')
    if any(s not in (-1,1) for s in c.get('rotations',[1])):raise ValueError('rotation must be +/-1')
    if not np.isclose(fld['t_end']/obs['frame_dt'],round(fld['t_end']/obs['frame_dt'])):raise ValueError('t_end must be an integer multiple of frame_dt for phase analysis')
    if obs['sample_dt']*max(src['omega'],c['receivers']['omega'])>=np.pi:raise ValueError('receiver temporal aliasing')
    if obs['frame_dt']*src['omega']>=np.pi:raise ValueError('field frame temporal aliasing')
    d=c['diagnostics']
    if d['angular_samples']<2*max(abs(m) for m in d['m_values'])+3:raise ValueError('angular aliasing')
    if len(d['z_planes'])<3 or len(set(d['z_planes']))!=len(d['z_planes']):raise ValueError('insufficient/duplicate z planes')
    if min(limits['memory_bytes'],limits['disk_bytes'],limits['analysis_memory_bytes'])<=0:raise ValueError('invalid resources')
    if c['receivers'].get('extra_mode','passive') not in ('passive','reciprocal'):raise ValueError('unknown extra receiver mode')
    if 't_end' in c.get('sweep',{}):raise ValueError('t_end sweep not supported; use separate presets')
    return c

def cases(c):
    dimensions=[('rotation',c.get('rotations',[1]))]+[(k,v) for k,v in c.get('sweep',{}).items()]
    for values in product(*[v for _,v in dimensions]):
        case=deepcopy(c);tags=[]
        for (name,_),value in zip(dimensions,values):
            if name=='rotation':case['rotation']=value;tags.append('splus' if value==1 else 'sminus')
            else:
                group,key=name.split('.',1)
                if group not in ('source','field'):raise ValueError('unsupported sweep '+name)
                case[group][key]=value;tags.append(name.replace('.','_')+'_'+str(value).replace('.','p'))
        case['case_id']='_'.join(tags);validate(case);yield case

def code_digest():
    files=sorted((ROOT/'hrf_integral').glob('*.py'));h=hashlib.sha256()
    for p in files:h.update(p.name.encode());h.update(p.read_bytes())
    return h.hexdigest()

def estimate(c):
    axes=axes_from_config(c['grid']);n=int(np.prod([len(a) for a in axes]));frames=int(np.ceil(c['field']['t_end']/c['observation']['frame_dt']))+1
    step=int(np.ceil(c['field']['t_end']/c['field']['dt']));slab=max(len(axes[0])*len(axes[1]),1)*frames
    memory=n*7500+slab*64;disk=n*6*4*frames+frames*len(c['diagnostics']['z_planes'])*len(axes[0])*len(axes[1])*8+40_000_000
    local=[];center=c['source'].get('center',[0,0,0])
    for k,a in enumerate(axes):
        sigma=c['source']['sigma_z' if k==2 else 'sigma_xy'];mid=(a[1:]+a[:-1])/2;mask=np.abs(mid-center[k])<=2*sigma
        local.append(float(np.max(np.diff(a)[mask])) if np.any(mask) else float(np.max(np.diff(a))))
    wavelength=2*np.pi/np.sqrt(c['source']['omega']**2-c['field']['mass']**2) if c['source']['omega']>c['field']['mass'] else None
    resolved=(c['source']['sigma_xy']>=3*max(local[:2]) and c['source']['sigma_z']>=3*local[2] and wavelength is not None and wavelength>=12*max(np.diff(a).max() for a in axes))
    reasons=[]
    if memory>c['limits']['memory_bytes']:reasons.append('estimated peak memory exceeds configured bound')
    if disk>c['limits']['disk_bytes']:reasons.append('uncompressed volume output estimate exceeds configured bound')
    if slab*64>c['limits']['analysis_memory_bytes']:reasons.append('phase slab exceeds analysis memory bound')
    return dict(status='BLOCKED_RESOURCE_LIMIT' if reasons else 'ADMITTED',reasons=reasons,nodes=n,frames=frames,estimated_peak_bytes=int(memory),estimated_uncompressed_output_bytes=int(disk),estimated_matvec_operations=int(step*n*240),time_estimate_status='NO_CALIBRATED_THROUGHPUT_OPERATION_COUNT_ONLY',source_resolution_adequate=bool(resolved),wavelength=wavelength,source_local_max_dx=local,shape=[len(a) for a in axes],technical_smoke=c['classification']=='TECHNICAL_SMOKE_ONLY')
