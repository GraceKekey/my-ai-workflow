"""Numpy marching tetrahedra; no mandatory scikit-image/VTK dependency."""
from itertools import permutations
import numpy as np

def display_grid(field,axes,max_axis=34):
    idx=[np.unique(np.rint(np.linspace(0,len(a)-1,min(len(a),max_axis))).astype(int)) for a in axes]
    return np.asarray(field)[np.ix_(*idx)],[a[i] for a,i in zip(axes,idx)]

def isosurface(field,axes,level,max_axis=34,max_triangles=12000):
    field,axes=display_grid(field,axes,max_axis);shape=field.shape
    if not np.isfinite(field).all() or not float(field.min())<level<float(field.max()):return np.empty((0,3,3)),{'status':'NO_LEVEL_CROSSING','level':float(level)}
    xyz=np.stack(np.meshgrid(*axes,indexing='ij'),axis=-1).reshape(-1,3);ijk=np.stack(np.meshgrid(*[np.arange(n-1) for n in shape],indexing='ij'),axis=-1).reshape(-1,3);all_t=[]
    for perm in permutations(range(3)):
        vertices=[ijk.copy()];cur=ijk.copy()
        for axis in perm:cur=cur.copy();cur[:,axis]+=1;vertices.append(cur)
        all_t.append(np.stack([np.ravel_multi_index(v.T,shape) for v in vertices],axis=1))
    tetra=np.concatenate(all_t);f=field.ravel()[tetra];pos=f>level;active=(pos.any(axis=1)&(~pos).any(axis=1));tetra=tetra[active];f=f[active];pos=pos[active];triangles=[]
    def cross(v,fa,fb,a,b):
        t=(level-fa)/(fb-fa);return v[a]+t*(v[b]-v[a])
    # Active tetrahedra only, with deterministic ordering and no invented surfaces at zero field.
    for ids,values,signs in zip(tetra,f,pos):
        v=xyz[ids];p=np.flatnonzero(signs);n=np.flatnonzero(~signs)
        if len(p) in (1,3):
            anchor=p[0] if len(p)==1 else n[0];others=n if len(p)==1 else p
            triangles.append([cross(v,values[anchor],values[j],anchor,j) for j in others])
        else:
            q=[cross(v,values[a],values[b],a,b) for a,b in ((p[0],n[0]),(p[0],n[1]),(p[1],n[0]),(p[1],n[1]))];triangles.extend([[q[0],q[1],q[2]],[q[1],q[3],q[2]]])
    triangles=np.asarray(triangles);before=len(triangles)
    if before>max_triangles:triangles=triangles[np.linspace(0,before-1,max_triangles).astype(int)]
    return triangles,dict(status='COMPUTED_DISPLAY_MESH',level=float(level),triangles_before_display_cap=before,triangles=len(triangles),display_shape=shape,notice='visual resampling/cap only; diagnostics use original numeric data')

def point_cloud(field,axes,threshold,max_points=6000):
    ids=np.argwhere(np.abs(field)>threshold)
    if len(ids)>max_points:ids=ids[np.linspace(0,len(ids)-1,max_points).astype(int)]
    points=np.column_stack([a[ids[:,k]] for k,a in enumerate(axes)]) if len(ids) else np.empty((0,3))
    values=field[tuple(ids.T)] if len(ids) else np.empty(0)
    return points,values

def overlays(ax,grid,center,bounds):
    x,y,z=(grid[k] for k in ('x','y','z'));X,Y=np.meshgrid(x,y,indexing='ij');iz=int(np.argmin(abs(z)));H=grid['H'][:,:,iz]
    from matplotlib import cm,colors
    norm=colors.Normalize(vmin=float(H.min()),vmax=float(H.max())+1e-30);colors_H=cm.Greys(norm(H));colors_H[...,3]=.12
    ax.plot_surface(X,Y,np.full_like(X,z[iz]),facecolors=colors_H,rstride=max(1,len(x)//25),cstride=max(1,len(y)//25),shade=False)
    inside=grid['receiver_active'];hist=np.arange(len(inside))<468;points=grid['receiver_xyz']
    for mask,color,label in ((inside&hist,'black','receptores históricos visíveis'),(inside&~hist,'goldenrod','receptores extras')):
        p=points[mask]
        if len(p)>400:p=p[np.linspace(0,len(p)-1,400).astype(int)]
        if len(p):ax.scatter(*p.T,s=3,c=color,alpha=.35,label=label)
    ax.scatter(*np.asarray(center),c='green',marker='*',s=80,label='fonte')
    ax.set(xlim=bounds[0],ylim=bounds[1],zlim=bounds[2],xlabel='x',ylabel='y',zlabel='z');ax.set_box_aspect([np.ptp(a) for a in (x,y,z)])
