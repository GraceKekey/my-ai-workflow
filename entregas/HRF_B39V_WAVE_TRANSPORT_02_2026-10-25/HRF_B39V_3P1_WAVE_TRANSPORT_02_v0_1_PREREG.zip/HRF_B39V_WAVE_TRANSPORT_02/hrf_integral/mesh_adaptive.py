"""Rectilinear graded P1 grid. Local central refinement without hanging nodes/AMR."""
from itertools import permutations
import numpy as np
from scipy.sparse import coo_matrix
from .fem import Mesh

class RectilinearMesh(Mesh):
    def __init__(self, axes):
        self.axes=[np.asarray(a,float) for a in axes]
        if len(self.axes)!=3 or any(len(a)<3 or np.any(np.diff(a)<=0) or not np.isfinite(a).all() for a in self.axes):
            raise ValueError('three finite strictly increasing axes required')
        self.shape=tuple(len(a) for a in self.axes);self.bounds=np.array([[a[0],a[-1]] for a in self.axes]);self.dx=np.array([np.diff(a).min() for a in self.axes])
        self.xyz=np.stack(np.meshgrid(*self.axes,indexing='ij'),axis=-1).reshape(-1,3);self.n=len(self.xyz)
        ijk=np.stack(np.meshgrid(*[np.arange(n-1) for n in self.shape],indexing='ij'),axis=-1).reshape(-1,3);tets=[]
        for perm in permutations(range(3)):
            vertices=[ijk.copy()];cur=ijk.copy()
            for axis in perm:
                cur=cur.copy();cur[:,axis]+=1;vertices.append(cur)
            tets.append(np.stack([np.ravel_multi_index(v.T,self.shape) for v in vertices],axis=1))
        self.tets=np.concatenate(tets);v=self.xyz[self.tets];A=v[:,1:]-v[:,:1];self.volume=np.abs(np.linalg.det(A))/6
        other=np.linalg.inv(A).transpose(0,2,1);self.grad=np.concatenate((-other.sum(axis=1)[:,None,:],other),axis=1);self.centers=v.mean(axis=1)
        self.boundary=np.any(np.isclose(self.xyz,self.bounds[:,0])|np.isclose(self.xyz,self.bounds[:,1]),axis=1);self.free=np.flatnonzero(~self.boundary)
    def interpolation(self,points):
        points=np.asarray(points,float).reshape(-1,3)
        if np.any(points<self.bounds[:,0]) or np.any(points>self.bounds[:,1]):raise ValueError('receiver outside grid')
        inds=np.array([np.clip(np.searchsorted(a,points[:,k],side='right')-1,0,len(a)-2) for k,a in enumerate(self.axes)]).T
        u=np.array([(points[:,k]-a[inds[:,k]])/(a[inds[:,k]+1]-a[inds[:,k]]) for k,a in enumerate(self.axes)]).T
        rows=[];cols=[];vals=[]
        for a in (0,1):
            for b in (0,1):
                for c in (0,1):
                    d=np.array([a,b,c]);rows.extend(range(len(points)));cols.extend(np.ravel_multi_index((inds+d).T,self.shape));vals.extend(np.prod(np.where(d,u,1-u),axis=1))
        return coo_matrix((vals,(rows,cols)),shape=(len(points),self.n)).tocsr()

def axes_from_config(grid):
    if grid.get('kind','uniform')=='uniform':return [np.linspace(*b,n) for b,n in zip(grid['bounds'],grid['shape'])]
    if grid['kind']!='graded_center':raise ValueError('unsupported grid')
    axes=[]
    for spec in grid['axes']:
        breaks=spec['breaks'];cells=spec['cells']
        if len(breaks)!=len(cells)+1 or any(n<1 for n in cells):raise ValueError('invalid graded breaks/cells')
        axes.append(np.concatenate([np.linspace(a,b,n+1)[:-1] for a,b,n in zip(breaks[:-1],breaks[1:],cells)]+[np.array([breaks[-1]])]))
    return axes
