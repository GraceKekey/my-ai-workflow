"""Controlled mathematical angular basis on known AdS4. No HRF dictionary supplied."""
import numpy as np
from scipy.special import jv,gamma

def angular_projection(values,theta,m_values):
    return np.einsum('...a,ma->...m',values,np.exp(-1j*np.asarray(m_values)[:,None]*np.asarray(theta)))/len(theta)

def ads_cylindrical_mode(t,r,theta,z,m=1,radial_k=.4,q=.7,m2=0.):
    if m2<-2.25 or q<=0 or radial_k<0 or np.any(np.asarray(z)<=0):raise ValueError('invalid free AdS4 mode')
    nu=np.sqrt(2.25+m2);omega=np.sqrt(radial_k**2+q**2);angular=jv(m,radial_k*np.asarray(r))*np.exp(1j*(m*np.asarray(theta)-omega*np.asarray(t)))
    boundary=(q/2)**nu/gamma(nu+1)*angular;bulk=np.asarray(z)**1.5*jv(nu,q*np.asarray(z))*angular
    return dict(bulk=bulk,boundary_normalizable_coefficient=boundary,omega=omega,delta=1.5+nu,m=m,scope='specified free normalizable mode on given AdS4; scalar kinematics, not HRF reconstruction',HRF_gate='BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY')
