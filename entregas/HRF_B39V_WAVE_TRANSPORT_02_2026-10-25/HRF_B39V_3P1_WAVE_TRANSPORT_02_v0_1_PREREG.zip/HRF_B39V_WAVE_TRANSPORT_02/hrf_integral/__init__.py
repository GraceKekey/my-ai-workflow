"""SPIRAL observation layer derived from immutable integral v1.0.0."""
__version__ = "0.1.0"
BASE_INTEGRAL_VERSION = "1.0.0"
