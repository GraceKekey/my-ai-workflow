from pathlib import Path
import argparse,json,csv
from .plot3d import case_folders
from .spiral_diagnostics import analyze_case
from .io import atomic_json

def make_report(input_path,output):
    folders=case_folders(input_path);output=Path(output);output.mkdir(parents=True,exist_ok=True)
    summaries=[analyze_case(f) for f in folders]
    if not summaries:raise ValueError('no completed cases; no scientific result can be reported')
    technical=all(s['classification']=='TECHNICAL_SMOKE_ONLY' for s in summaries)
    headline='PRÉ-REGISTRADO — GRANDES SIMULAÇÕES NÃO EXECUTADAS; APENAS SMOKE TÉCNICO' if technical else 'EXECUÇÃO EXPLORATÓRIA — NÃO É CERTIFICAÇÃO FÍSICA'
    atomic_json(output/'summary.json',{'state':headline,'cases':summaries,'HRF_holography':'BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY'})
    (output/'RESUMO_EXECUTIVO.md').write_text('# Resumo executivo\n\n[D] '+headline+'.\n\n[M] '+str(len(summaries))+' casos com volumes, cortes, energia/fluxo, receptores e diagnósticos processados. PASS do pipeline significa gerar e interpretar arquivos nos limites especificados, sem provar uma espiral.\n\n'+('\n\n'.join(f"- Caso {s['case_id']}: {s['frames']} frames; informação={s['gates']['information']}; zscan={s['gates']['zscan']}; helicidade={s['gates']['helicity']}; estrutura={s['gates']['structure']}." for s in summaries))+'\n\n[?] Nenhuma imagem isolada demonstra transporte helicoidal ascendente, DIO, GMFt ou gravidade emergente.\n')
    lines=['# Relatório SPIRAL diagnostics','', '[D] '+headline+'.','', '## Objetivo','', '[D] Observar campo 3D e discriminar propagação radial, rotação angular, torção de fase e transporte em z. Não inserir fator exp(i k_z z) nem um deslocamento azimutal forçado na fonte.', '', '## Parâmetros','', '[D] Cada caso guarda run.json/case.json, a configuração completa, os passos efetivos, a malha, o catálogo dos 468 históricos e os extras. Os receptores fora do domínio técnico permanecem catalogados e explicitamente inativos. Limiar histórico preservado por caso; não foi recalibrado.', '', '## Medidas e método','', '[M] Campo completo phi e momento por frame; energia Euleriana e corrente local por projeção de gradientes FEM P1; carga orbital operacional em z; centros de energia; máximos locais com preservação de degenerescências. A energia dos frames descreve a perturbação, não a rede estacionária adicionada ao readout.', '', '[M] Fase de lock-in: média Hann finita de 2 phi exp(+i omega t), compatível com cos(m theta+kz z-omega t). A fase exige janela e amplitude suficientes; bordas da janela são descartadas. A média circular de um vórtice m≠0 pode ser indefinida; reporta-se a fase do coeficiente harmônico, não uma média linear de ângulos. Potência é normalizada pela potência total do anel, sem esconder conteúdo fora do conjunto de m.', '', '[M] Torção de fase é ajustada em trechos z conectados, nos dois hemisférios e globalmente. Requer pureza do modo primário ≥limiar congelado e controle de aliasing. Crista de |phi| com lobos empatados não recebe uma linha artificial escolhida por desempate.', '', '## Resultados e gates','', '```json',json.dumps(summaries,indent=2,ensure_ascii=False),'```','', '## Interpretação','', '[H] Um ajuste m≠0 e kz≠0 pode representar uma hélice de fase. Isso não implica trajetória helicoidal de energia. [M] Geometria de crista, fluxo, centro de energia e assimetria superior/inferior são saídas distintas. [F] Uma fonte par em z sobre fundo par admite radiação simétrica para cima e para baixo, sem preferência ascendente. Rotação de fonte não insere direção privilegiada em z.', '', '[?] Estruturas candidatas exigem controles de grade, fronteira, janela de fase, massa/frequência e comparação pareada s±. Gates de visualização/diagnóstico não certificam a estrutura física. A interface HRF continua BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY.']
    (output/'RELATORIO_SPIRAL_DIAGNOSTICS.md').write_text('\n'.join(lines)+'\n')
    limits=Path(__file__).resolve().parents[1]/'LIMITES_DA_INTERPRETACAO.md'
    if limits.exists():(output/limits.name).write_bytes(limits.read_bytes())
    return summaries

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True);a=ap.parse_args();summaries=make_report(a.input,a.output);print(json.dumps({'reported_cases':len(summaries),'scientific_structure':'INCONCLUSIVE_SPIRAL_STRUCTURE'}))
if __name__=='__main__':main()
