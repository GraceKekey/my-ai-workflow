import numpy as np

def arrival_time(t,signal,fraction=.1,absolute_floor=1e-14):
    t=np.asarray(t);a=np.asarray(signal);peak=float(np.max(a,initial=0))
    if not np.isfinite(peak) or peak<=absolute_floor:return None
    threshold=peak*fraction;hit=np.flatnonzero(a>=threshold)
    if not len(hit):return None
    i=int(hit[0])
    if i==0:return float(t[0])
    return float(t[i-1]+(threshold-a[i-1])/(a[i]-a[i-1])*(t[i]-t[i-1]))

def slice_centers(energy_density,node_volume,x,y,z):
    w=np.asarray(energy_density)*node_volume;energy=w.sum(axis=(0,1));X,Y=np.meshgrid(x,y,indexing='ij');cx=np.divide(np.sum(w*X[:,:,None],axis=(0,1)),energy,out=np.full(len(z),np.nan),where=energy>1e-30);cy=np.divide(np.sum(w*Y[:,:,None],axis=(0,1)),energy,out=np.full(len(z),np.nan),where=energy>1e-30)
    total=energy.sum();center=np.array([np.sum(w*X[:,:,None]),np.sum(w*Y[:,:,None]),np.sum(energy*z)])/total if total>1e-30 else np.full(3,np.nan)
    return energy,np.c_[cx,cy],center

def radial_time(energy_density,node_volume,x,y,r_edges):
    X,Y=np.meshgrid(x,y,indexing='ij');radius=np.sqrt(X*X+Y*Y).ravel();ids=np.digitize(radius,r_edges)-1
    w=np.asarray(energy_density)*node_volume
    return np.array([np.sum(w.reshape(-1,w.shape[-1])[ids==i],axis=0) for i in range(len(r_edges)-1)])
