"""Historical reciprocal detectors plus passive extra probes, with explicit energy scope."""
import numpy as np
from scipy.sparse import bmat,diags
from scipy.sparse.linalg import spsolve
from .dynamics import System

class SpiralSystem(System):
    def __init__(self,*args,reciprocal_mask=None,**kwargs):
        super().__init__(*args,**kwargs)
        mask=np.ones(self.h,bool) if reciprocal_mask is None else np.asarray(reciprocal_mask,bool)
        if mask.shape!=(self.h,):raise ValueError('reciprocal mask length mismatch')
        self.reciprocal_mask=mask;self.drive=np.full(self.h,self.g);self.back=np.where(mask,self.g,0.)
    def rhs(self,t,state,forcing=None):
        n=self.mesh.n;q=state[:n];p=state[n:2*n];x=state[2*n:2*n+self.h];v=state[2*n+self.h:];mm,K,B=self.operators(t)
        qd=p/mm+B@q;pd=-K@q-B.T@p-self.damp*p-self.C.T@(self.back*x)
        if forcing is not None:pd+=forcing(t)
        vd=-self.omega**2*x-self.gamma_r*v-self.drive*(self.C@q)
        if self.bc!='neumann':qd[self.mesh.boundary]=0;pd[self.mesh.boundary]=0
        return np.r_[qd,pd,v,vd]
    def energy(self,state,t=0.):
        n=self.mesh.n;q=state[:n];p=state[n:2*n];x=state[2*n:2*n+self.h];v=state[2*n+self.h:];mm,K,B=self.operators(t);mask=self.reciprocal_mask
        return float(.5*np.sum(p*p/mm)+.5*q@(K@q)+p@(B@q)+.5*np.sum((v*v+self.omega**2*x*x)[mask])+(self.back*x)@(self.C@q))
    def network(self,forcing,omega):
        if self.dynamic or np.any(self.beta):raise ValueError('stationary network needs static zero shift')
        A=self.K-diags(self.mm*omega**2)+diags(1j*omega*self.mm*self.damp);D=diags(self.omega**2-omega**2+1j*omega*self.gamma_r)
        sol=spsolve(bmat([[A,self.C.T@diags(self.back)],[diags(self.drive)@self.C,D]],format='csc'),np.r_[forcing,np.zeros(self.h)])
        return sol[self.mesh.n:]
