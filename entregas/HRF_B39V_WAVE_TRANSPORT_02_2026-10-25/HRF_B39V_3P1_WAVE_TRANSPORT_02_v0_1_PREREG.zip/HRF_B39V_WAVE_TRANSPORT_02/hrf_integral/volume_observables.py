"""Eulerian scalar energy/current, P1 gradients and conservative nodal projection."""
import numpy as np

class VolumeObserver:
    def __init__(self,system,block_size=50000):
        self.s=system;self.m=system.mesh;self.block=block_size
        N,b,g=system.metric.fields(self.m.centers);self.sqrtg=np.sqrt(np.linalg.det(g));self.inv=np.linalg.inv(g)
        self.weight=self.m.volume*self.sqrtg
        self.node_volume=np.bincount(self.m.tets.ravel(),weights=np.repeat(self.weight/4,4),minlength=self.m.n)
    def evaluate(self,state):
        m=self.m;s=self.s;n=m.n;phi=state[:n];normal=state[n:2*n]/s.mm/s.N
        en=np.zeros(n);angular=np.zeros(n);flux=np.zeros((n,3))
        for lo in range(0,len(m.tets),self.block):
            hi=min(lo+self.block,len(m.tets));tet=m.tets[lo:hi];grad=np.einsum('ta,tai->ti',phi[tet],m.grad[lo:hi]);pi=normal[tet].mean(axis=1)
            phi2=(phi[tet]**2).mean(axis=1) # Lumped potential consistent with field mass quadrature.
            contr=np.einsum('tij,tj->ti',self.inv[lo:hi],grad)
            energy=.5*(pi*pi+np.einsum('ti,ti->t',grad,contr)+s.mass**2*phi2)
            current=-pi[:,None]*contr
            # Operational orbital angular density about z. Conserved Noether charge only with axial symmetry and closed boundaries.
            center=m.centers[lo:hi];lz=-pi*(center[:,0]*grad[:,1]-center[:,1]*grad[:,0]);w=self.weight[lo:hi]/4
            ids=tet.ravel();en+=np.bincount(ids,weights=np.repeat(w*energy,4),minlength=n);angular+=np.bincount(ids,weights=np.repeat(w*lz,4),minlength=n)
            for axis in range(3):flux[:,axis]+=np.bincount(ids,weights=np.repeat(w*current[:,axis],4),minlength=n)
        return dict(energy_density=en/self.node_volume,flux=flux/self.node_volume[:,None],orbital_density=angular/self.node_volume,total_Eulerian_energy=float(en.sum()),orbital_Lz_operational=float(angular.sum()))
