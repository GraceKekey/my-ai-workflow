"""On-demand full per-frame CSV/JSON/NPZ export; default data remains compressed NPZ."""
import argparse,json,csv,shutil
from pathlib import Path
import numpy as np
from .spiral_diagnostics import sanitize
from .spiral_storage import FrameStore

def export_frame(case,output,index=0,kind='volume',format='csv',max_bytes=256*1024**2,slice_index=0):
    case=Path(case);output=Path(output);output.parent.mkdir(parents=True,exist_ok=True);run=json.loads((case/'case.json').read_text());store=FrameStore(case/'frames',run['run_id']);frames=store.catalog['frames']
    if not 0<=index<len(frames):raise ValueError('frame index out of range')
    if kind=='volume':
        with store.read(frames[index]) as d:arrays={k:d[k].copy() for k in ('phi','energy_density','flux')}
        with np.load(case/'grid.npz',allow_pickle=False) as g:axes=[g[k] for k in ('x','y','z')]
        estimated=arrays['phi'].size*180
    elif kind=='phase':
        source=case/'analysis'/f'phase_xy_{slice_index:02d}.npz'
        with np.load(source,allow_pickle=False) as d:arrays={'amplitude':d['amplitude'][index],'phase':d['phase'][index],'valid':d['phase_valid'][index],'actual_z':d['actual_z']}
        with np.load(case/'grid.npz',allow_pickle=False) as g:axes=[g[k] for k in ('x','y')]
        estimated=arrays['amplitude'].size*100
    elif kind=='diagnostics':
        p=case/'analysis/diagnostics.npz'
        if not p.exists():raise ValueError('run diagnostics/report first')
        with np.load(p,allow_pickle=False) as d:arrays={k:d[k].copy() for k in d.files}
        axes=[];estimated=sum(v.size for v in arrays.values())*40
    else:raise ValueError('unsupported export kind')
    if estimated>max_bytes:raise ValueError('BLOCKED_RESOURCE_LIMIT estimated text export exceeds max-bytes')
    if format=='npz':np.savez_compressed(output,**arrays);return
    if format=='json':
        payload=dict(frame=index,t=frames[index]['t'],kind=kind,axes=axes,arrays=arrays)
        output.write_text(json.dumps(sanitize(payload),ensure_ascii=False,allow_nan=False));return
    with output.open('w',newline='') as f:
        writer=csv.writer(f)
        if kind=='volume':
            writer.writerow(['t','x','y','z','phi','Eulerian_energy_density','flux_x','flux_y','flux_z'])
            for ix,x in enumerate(axes[0]):
                for iy,y in enumerate(axes[1]):
                    for iz,z in enumerate(axes[2]):writer.writerow([frames[index]['t'],x,y,z,arrays['phi'][ix,iy,iz],arrays['energy_density'][ix,iy,iz],*arrays['flux'][ix,iy,iz]])
        elif kind=='phase':
            writer.writerow(['t','x','y','z_actual','amplitude','phase','phase_valid'])
            for ix,x in enumerate(axes[0]):
                for iy,y in enumerate(axes[1]):writer.writerow([frames[index]['t'],x,y,float(arrays['actual_z']),arrays['amplitude'][ix,iy],arrays['phase'][ix,iy],int(arrays['valid'][ix,iy])])
        else:
            writer.writerow(['array','indices','value'])
            for name,values in arrays.items():
                for idx in np.ndindex(values.shape):writer.writerow([name,','.join(map(str,idx)),values[idx]])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',required=True);ap.add_argument('--output',required=True);ap.add_argument('--frame',type=int,default=0);ap.add_argument('--kind',choices=['volume','diagnostics','phase'],default='volume');ap.add_argument('--format',choices=['csv','json','npz'],default='csv');ap.add_argument('--max-bytes',type=int,default=256*1024**2);ap.add_argument('--slice-index',type=int,default=0);a=ap.parse_args();export_frame(a.input,a.output,a.frame,a.kind,a.format,a.max_bytes,a.slice_index)
if __name__=='__main__':main()
