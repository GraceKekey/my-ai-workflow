from pathlib import Path
import shutil,subprocess,json
from PIL import Image
from .io import atomic_json

def export_frames(paths,output,fps=5,gif=True,mp4=True):
    paths=[Path(p) for p in paths];output=Path(output);output.mkdir(parents=True,exist_ok=True);status={'frames':len(paths),'fps':fps}
    if not paths:return dict(status='NO_FRAMES')
    if gif:
        images=[Image.open(p).convert('RGB') for p in paths]
        images[0].save(output/'slices.gif',save_all=True,append_images=images[1:],duration=int(1000/fps),loop=0)
        for img in images:img.close()
        status['gif']='EXPORTED'
    if mp4:
        ffmpeg=shutil.which('ffmpeg')
        if ffmpeg is None:status['mp4']='BLOCKED_OPTIONAL_FFMPEG_MISSING'
        else:
            # The plotting pipeline names files consecutively and uses constant dimensions.
            result=subprocess.run([ffmpeg,'-y','-loglevel','error','-framerate',str(fps),'-i',str(paths[0].parent/'frame_%05d.png'),'-vf','pad=ceil(iw/2)*2:ceil(ih/2)*2','-c:v','libx264','-pix_fmt','yuv420p',str(output/'slices.mp4')],capture_output=True,text=True)
            status['mp4']='EXPORTED' if result.returncode==0 else 'BLOCKED_OPTIONAL_CODEC';status['ffmpeg_message']=result.stderr[-2000:]
    atomic_json(output/'animation.json',status);return status
