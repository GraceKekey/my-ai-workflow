"""Operational angular/axial diagnostics for a scalar; no intrinsic spin/helicity claim."""
import numpy as np
from .phase_analysis import axial_phase_fit

def chirality(power,m):
    power=np.asarray(power,float);m=np.asarray(m);den=power.sum(axis=-1)*max(np.max(abs(m)),1)
    return np.divide(np.einsum('...m,m->...',power,m),den,out=np.zeros(den.shape),where=den>0)

def twist_profiles(z,coefficients,m_values,primary_m,valid_time,d):
    idx=list(m_values).index(primary_m);results=[]
    for it in np.flatnonzero(valid_time):
        for ir in range(coefficients.shape[2]):
            for side,mask in [('all',np.ones(len(z),bool)),('upper',np.asarray(z)>0),('lower',np.asarray(z)<0)]:
                c=coefficients[it,mask,ir,idx];fit=axial_phase_fit(np.asarray(z)[mask],c,minimum=d['min_valid_z'],residual_max=d['linear_phase_residual_max'],phase_span_min=d['twist_phase_span_min'])
                kz=fit.get('kz');fit.update(time_index=int(it),radius_index=ir,side=side,m=int(primary_m),phase_crest_dtheta_dz=-kz/primary_m if kz is not None and primary_m else None,pitch_z_per_2pi=-2*np.pi*primary_m/kz if kz is not None and abs(kz)>1e-12 and primary_m else None)
                results.append(fit)
    return results

def axial_transport(z,energy,flux):
    z=np.asarray(z);energy=np.asarray(energy,float);flux=np.asarray(flux,float);upper=z>0;lower=z<0
    Eup=energy[:,upper].sum(axis=1);Edown=energy[:,lower].sum(axis=1);den=Eup+Edown
    asym=np.divide(Eup-Edown,den,out=np.full_like(den,np.nan),where=den>0)
    denflux=np.sum(np.abs(flux),axis=1);net=np.divide(flux.sum(axis=1),denflux,out=np.full_like(denflux,np.nan),where=denflux>0)
    outward=np.divide(np.sum(flux*np.sign(z),axis=1),denflux,out=np.full_like(denflux,np.nan),where=denflux>0)
    return dict(energy_upper_lower_asymmetry=asym,net_z_flux_fraction=net,outward_z_flux_fraction=outward,interpretation='symmetric upward/downward radial radiation can have positive outward flux and zero net upward transport')

def paired_angular_statistics(a,b,m_values):
    """Compare measured rotations without assuming source sign forces axial transport."""
    ma=np.asarray(a['usable_phase_ring'],bool);mb=np.asarray(b['usable_phase_ring'],bool)
    ca=np.asarray(a['mode_real'])+1j*np.asarray(a['mode_imag']);cb=np.asarray(b['mode_real'])+1j*np.asarray(b['mode_imag'])
    if ca.shape!=cb.shape or ma.shape!=mb.shape:raise ValueError('incompatible paired phase grids')
    valid=ma&mb;result={'status':'COMPUTED_PAIRED_DIAGNOSTIC' if valid.any() else 'INCONCLUSIVE_INSUFFICIENT_PHASE','matched_phase_rings':int(valid.sum()),'mean_chirality_plus':None,'mean_chirality_minus':None,'angular_power_reflection_relative_error':None}
    if valid.any():
        result['mean_chirality_plus']=float(np.mean(np.asarray(a['chirality_operational'])[valid]));result['mean_chirality_minus']=float(np.mean(np.asarray(b['chirality_operational'])[valid]));power_a=np.sum(abs(ca[valid])**2,axis=0);power_b=np.sum(abs(cb[valid])**2,axis=0);reverse=[list(m_values).index(-m) for m in m_values];den=np.linalg.norm(power_a)
        result['angular_power_reflection_relative_error']=float(np.linalg.norm(power_a-power_b[reverse])/den) if den>0 else None
    La=np.asarray(a['orbital_Lz'],float);Lb=np.asarray(b['orbital_Lz'],float);den=np.linalg.norm(La)+np.linalg.norm(Lb)
    result['orbital_sign_flip_relative_error']=float(np.linalg.norm(La+Lb)/den) if den>0 else None
    result['notice']='comparison of operational angular data; no holography, particle helicity or upward-transport conclusion'
    return result
