import numpy as np
from scipy.optimize import minimize
from .geometry import ADM
from .history import Height,load

class GaussianHeight:
    def __init__(self,valleys):
        self.valleys=valleys
        starts=[(v[0],v[1]) for v in valleys] or [(0,0)]
        self.minimum=min(float(minimize(lambda xy:self([xy])[0][0],xy,method='BFGS').fun) for xy in starts) if valleys else 0.
    def __call__(self,xy):
        xy=np.atleast_2d(xy);h=np.zeros(len(xy));gx=h.copy();gy=h.copy()
        for x,y,depth,sigma in self.valleys:
            dx=xy[:,0]-x;dy=xy[:,1]-y;term=-depth*np.exp(-(dx*dx+dy*dy)/(2*sigma*sigma));h+=term;gx-=term*dx/sigma**2;gy-=term*dy/sigma**2
        return h,gx,gy

def build_metric(c):
    g=c.get('geometry',{'kind':'flat'});kind=g['kind']
    if kind=='flat':return ADM(),lambda xyz:np.zeros(len(xyz))
    if kind=='historical_graph':
        config=load('b39v_config');rod=next(r for r in config.rodadas('completo') if r['nome']==g['historical_case']);height=Height(rod)
    elif kind=='analytic_graph':height=GaussianHeight(g['valleys'])
    else:raise ValueError('unsupported spiral geometry')
    thickness=g.get('thickness',15.);metric=ADM('graph',height_map=height,thickness=thickness,lapse_depth=g.get('lapse_depth',0.))
    def H(xyz):
        xyz=np.atleast_2d(xyz);return height(xyz[:,:2])[0]*np.exp(-.5*(xyz[:,2]/thickness)**2)
    return metric,H
