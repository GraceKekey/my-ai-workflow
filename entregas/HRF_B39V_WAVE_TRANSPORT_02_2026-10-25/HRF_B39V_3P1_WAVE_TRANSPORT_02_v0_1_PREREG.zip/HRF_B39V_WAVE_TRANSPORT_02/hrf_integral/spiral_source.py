"""Scalar rotating dipole; no imposed axial phase or directed z forcing."""
import numpy as np

def envelope(t,s):
    duration=s['duration'];mode=s['mode']
    if mode=='pulsed':return np.sin(np.pi*t/duration)**2 if 0<t<duration else 0.
    if mode=='pulse_train':
        index=int(np.floor(t/s['period']))
        if index<0 or index>=s['count']:return 0.
        u=t-index*s['period'];return np.sin(np.pi*u/duration)**2 if 0<u<duration else 0.
    if mode=='quasi_harmonic':
        if not 0<t<duration:return 0.
        ramp=s['ramp'];return min(1.,np.sin(.5*np.pi*min(t,duration-t)/ramp)**2) if min(t,duration-t)<ramp else 1.
    raise ValueError('unknown envelope')

def build_forcing(system,c):
    s=c['source'];dipole=system.source(s['sigma_xy'],s['sigma_z'],s.get('center',(0.,0.,0.)))
    # Same relative source phase as B39V. Both basis columns may differ by an overall sign convention.
    def force(t):return s['amplitude']*envelope(t,s)*(dipole[:,0]*np.cos(s['omega']*t)+c['rotation']*dipole[:,1]*np.sin(s['omega']*t))
    return force,dipole
