from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]

def catalog(c,bounds):
    historical=np.loadtxt(ROOT/'inputs/historical_receivers.csv',delimiter=',',skiprows=1)[:,1:]
    if historical.shape!=(468,3):raise ValueError('MISSING_SOURCE exact historical receiver catalog')
    xyz=list(historical);kind=['historical']*468;labels=[f'H{i:03d}' for i in range(468)]
    spec=c['receivers'];angles=np.arange(spec.get('azimuth_count',24))*2*np.pi/spec.get('azimuth_count',24)
    for z in (-20.,-10.,-5.,5.,10.,20.):
        for radius in spec.get('radii',[20.,60.,100.]):
            for k,a in enumerate(angles):xyz.append([radius*np.cos(a),radius*np.sin(a),z]);kind.append('horizontal_ring');labels.append(f'z{z:g}_r{radius:g}_a{k}')
    for radius in spec.get('vertical_radii',[5.,10.,20.]):
        for plane in ('xz','yz'):
            for k,a in enumerate(angles):
                q=[radius*np.cos(a),0.,radius*np.sin(a)] if plane=='xz' else [0.,radius*np.cos(a),radius*np.sin(a)]
                xyz.append(q);kind.append('vertical_ring');labels.append(f'{plane}_r{radius:g}_a{k}')
    # Deliberately keep coincident independent detectors, with explicit labels and reciprocal coupling.
    xyz=np.asarray(xyz);bounds=np.asarray(bounds);inside=np.all((xyz>=bounds[:,0])&(xyz<=bounds[:,1]),axis=1)
    return dict(xyz=xyz,kind=np.asarray(kind),labels=np.asarray(labels),active=inside,historical_count=468)
