"""Portable strict manifest verification; no execution of simulations."""
from pathlib import Path
import hashlib
import sys
ROOT = Path(__file__).resolve().parents[1]
manifest = ROOT / (sys.argv[1] if len(sys.argv) > 1 else 'MANIFESTO_SHA256.txt')
count = 0
for line in manifest.read_text(encoding='utf-8').splitlines():
    if not line or line.startswith('#'):
        continue
    expected, name = line.split('  ', 1)
    p = (ROOT / name).resolve()
    if not p.is_relative_to(ROOT) or not p.is_file():
        raise SystemExit('Missing or unsafe manifest path: ' + name)
    h = hashlib.sha256()
    with p.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    if h.hexdigest() != expected:
        raise SystemExit('SHA-256 mismatch: ' + name)
    count += 1
print(f'OK: {count} files; SHA-256 manifest verified')
