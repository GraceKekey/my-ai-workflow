@echo off
set OPENBLAS_NUM_THREADS=1
set OMP_NUM_THREADS=1
set MKL_NUM_THREADS=1
python -I "%~dp0wt02.py" %*
exit /b %ERRORLEVEL%
