"""Isolated launcher: python -I scripts/wt02.py COMMAND ..."""
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from hrf_b39v.cli import main
if __name__ == '__main__':
    raise SystemExit(main())
