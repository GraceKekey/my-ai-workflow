"""[F/M] Bounded mathematical/software references, never the scientific presets.

Hard caps: each mesh <=4913 nodes, elapsed model time <=1 and <=1000 steps.
Outputs under reports/technical_tests are labelled references, never B39V findings.
"""
import contextlib
from copy import deepcopy
import io
import json
import os
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch
import numpy as np
from scipy.sparse import diags
from scipy.sparse.linalg import eigsh
from hrf_integral.geometry import ADM
from hrf_integral.mesh_adaptive import RectilinearMesh
from hrf_integral.spiral_source import envelope
from hrf_vertical.common import ROOT, save_json, save_npz, relative
from hrf_vertical.config import load, readiness, validate
from hrf_vertical.system import VerticalSystem, forcing
from hrf_vertical.energy import ledger_rk4, balance
from hrf_vertical.controls import standing_solution, observed_order
from hrf_vertical.runner import run_case
from hrf_vertical.storage import verify_completion


def evolve(system, initial, end, dt, force=None):
    assert system.mesh.n <= 4913 and 0 < end <= 1
    steps = round(end / dt)
    assert steps <= 1000 and dt <= system.dt_bound and np.isclose(steps * dt, end)
    y = initial.copy(); ledger = np.zeros(3)
    for i in range(steps):
        y, ledger = ledger_rk4(system, y, ledger, i * dt, dt, force)
    return y, ledger


def small_system(n=7, boundary='dirichlet', reciprocal=False, curved=False):
    from hrf_vertical.geometry import GaussianHeight
    mesh = RectilinearMesh([np.linspace(-1, 1, n)] * 3)
    metric = ADM('graph', height_map=GaussianHeight([[0., 0., .1, .7]]), thickness=.8) if curved else ADM()
    return VerticalSystem(mesh, metric, .2, points=[[.1, .2, .1]], reciprocal_mask=[reciprocal],
                          coupling=.05, gamma_r=.1, omega=1.3, boundary=boundary,
                          sponge=.4, sponge_width=[.4] * 3)


def record(name, measures):
    target = os.environ.get('HRF_WT02_TECHNICAL_OUTPUT')
    if target:
        save_json(Path(target) / (name + '.json'), dict(scope='TECHNICAL_MATHEMATICAL_REFERENCE_ONLY', **measures))


class MathematicalReferences(unittest.TestCase):
    def test_null_solution_stays_bitwise_zero(self):
        s = small_system(); y = np.zeros(2*s.mesh.n+2*s.h)
        z, ledger = evolve(s, y, .2, .01)
        self.assertTrue(np.array_equal(z, y)); self.assertTrue(np.array_equal(ledger, np.zeros(3)))

    def test_analytical_standing_wave_spatial_reference(self):
        errors = []
        for n in (9, 17):
            s = small_system(n); s.drive[:] = 0; s.back[:] = 0
            q, _ = standing_solution(s.mesh.axes, 0, s.mass)
            y = np.r_[q.ravel(), np.zeros(s.mesh.n+2*s.h)]
            z, _ = evolve(s, y, .5, .005)
            exact, _ = standing_solution(s.mesh.axes, .5, s.mass)
            err = float(np.sqrt(np.sum(s.mm*(z[:s.mesh.n]-exact.ravel())**2)/s.mm.sum()))
            errors.append(err)
        order = observed_order(errors[0], errors[1])
        record('analytical_standing_mode', dict(nodes=[729,4913], time=.5, errors=errors, order=order, threshold_order=1.5))
        self.assertLess(max(errors), .02); self.assertGreaterEqual(order, 1.5)

    def test_temporal_RK4_against_exact_discrete_eigenmode(self):
        s = small_system(7); s.drive[:] = 0; s.back[:] = 0
        ids = s.mesh.free; w = s.mm[ids]
        A = diags(1/np.sqrt(w)) @ s.K[ids][:,ids] @ diags(1/np.sqrt(w))
        vals, vecs = eigsh(A, k=1, which='SM', v0=np.ones(len(ids)), tol=1e-12)
        q = np.zeros(s.mesh.n); q[ids] = vecs[:,0]/np.sqrt(w); q /= max(abs(q))
        y = np.r_[q, np.zeros(s.mesh.n+2*s.h)]; frequency = np.sqrt(vals[0])
        errors = []
        for dt in (.04,.02,.01):
            z, _ = evolve(s, y, .4, dt)
            errors.append(relative(z[:s.mesh.n], q*np.cos(frequency*.4)))
        orders = [observed_order(errors[i],errors[i+1]) for i in (0,1)]
        record('RK4_temporal_reference', dict(nodes=343, time=.4, dt=[.04,.02,.01], errors=errors, orders=orders))
        self.assertGreaterEqual(min(orders),3.5)

    def test_energy_balance_sponge_and_reciprocal_receiver(self):
        for reciprocal in (False,True):
            with self.subTest(reciprocal=reciprocal):
                s=small_system(boundary='sponge',reciprocal=reciprocal,curved=True)
                q,_=standing_solution(s.mesh.axes,0,s.mass)
                y=np.r_[q.ravel()*.01,np.zeros(s.mesh.n+2*s.h)]
                source=lambda t:s.mm*q.ravel()*.003*np.cos(t)
                z,ledger=evolve(s,y,.4,.005,source)
                b=balance(s.energy(z),s.energy(y),ledger)
                record('energy_'+str(reciprocal),dict(nodes=343,time=.4,reciprocal=reciprocal,**b))
                self.assertLessEqual(b['balance_relative_error'],1e-6)
                self.assertGreater(ledger[1],0)
                if reciprocal:self.assertGreater(ledger[2],0)
                else:self.assertEqual(ledger[2],0)

    def test_vertical_and_rotation_reflections_in_flat_reference(self):
        s=small_system(9);s.drive[:]=0;s.back[:]=0
        c=deepcopy(load(ROOT/'configs/vertical_medium.json')['cases'][0])
        c['source'].update(sigma_xy=.35,sigma_z=.4,omega=4.,duration=.5)
        results=[]
        for rotation in (1,-1):
            c['rotation']=rotation;force,_=forcing(s,c)
            z,_=evolve(s,np.zeros(2*s.mesh.n+2*s.h),.4,.005,force)
            results.append(z[:s.mesh.n].reshape(s.mesh.shape))
        vertical=relative(results[0],results[0][:,:,::-1])
        angular=relative(results[0],results[1][:,::-1,:])
        record('flat_parity_rotation',dict(nodes=729,time=.4,vertical_relative_L2=vertical,rotation_relative_L2=angular,tolerance=1e-10))
        self.assertLess(vertical,1e-10);self.assertLess(angular,1e-10)

    def test_passive_receivers_do_not_change_the_field(self):
        s=small_system();q,_=standing_solution(s.mesh.axes,0,s.mass)
        y=np.r_[q.ravel()*.01,np.zeros(s.mesh.n+2*s.h)]
        with_drive,_=evolve(s,y,.3,.005)
        s.drive[:]=0
        without_drive,_=evolve(s,y,.3,.005)
        self.assertTrue(np.array_equal(with_drive[:2*s.mesh.n],without_drive[:2*s.mesh.n]))
        self.assertGreater(abs(with_drive[-2]),0)
        self.assertEqual(without_drive[-2],0)


class SourceAndScope(unittest.TestCase):
    def test_all_source_types_are_real_and_z_even(self):
        s=small_system(7)
        c=deepcopy(load(ROOT/'configs/vertical_medium.json')['cases'][0])
        c['source'].update(sigma_xy=.4,sigma_z=.4,duration=1.)
        for kind in ('null','monopole','dipole_fixed','dipole_rotating'):
            c['source']['kind']=kind;force,_=forcing(s,c);a=force(.3)/s.mm
            a=a.reshape(s.mesh.shape)
            self.assertTrue(np.isfinite(a).all());self.assertTrue(np.allclose(a,a[:,:,::-1]))
            if kind=='null':self.assertEqual(abs(a).max(),0)
            else:self.assertGreater(abs(a).max(),0)

    def test_single_pulse_and_train_are_distinct(self):
        s=dict(mode='pulsed',duration=1.,count=3,period=2.,ramp=.2)
        self.assertAlmostEqual(envelope(2.5,s),0)
        s['mode']='pulse_train'
        self.assertAlmostEqual(envelope(2.5,s),1)
        self.assertAlmostEqual(envelope(6.5,s),0)
        s['mode']='quasi_harmonic'
        self.assertGreater(envelope(.05,s),0);self.assertLess(envelope(.05,s),1)

    def test_autonomous_cases_have_no_document_dependency(self):
        c=load(ROOT/'configs/vertical_medium.json')
        self.assertEqual(readiness(c)['missing'],[])

    def test_reanalysis_uses_provided_raw_directory_without_editing_config(self):
        c=load(ROOT/'configs/receiver_frequency_sweep.json')
        self.assertTrue(readiness(c)['missing'])
        with tempfile.TemporaryDirectory() as td:
            (Path(td)/'case.json').write_text('{}')
            self.assertEqual(readiness(c,td)['missing'],[])

    def test_fixed_dipole_inconsistent_rotation_is_rejected(self):
        c=deepcopy(load(ROOT/'configs/vertical_medium.json'));c['cases'][0]['source']['kind']='dipole_fixed'
        with self.assertRaises(ValueError):validate(c)

    def test_public_gate_names_do_not_promote_underresolved_data(self):
        from hrf_b39v.gates import from_analysis
        summary=dict(gates=dict(energy='PASS_ENERGY_BALANCE',phase='PASS_PHASE_DIAGNOSTIC',receiver='INCONCLUSIVE',vertical_symmetry='INCONCLUSIVE'),
                     information=dict(spatial_resolution_adequate=False),diagnostic_records=100,
                     evidence=dict(ANGULAR_PHASE_STRUCTURE=True,VERTICAL_ENERGY_TRANSPORT=True,AZIMUTHAL_ENERGY_CIRCULATION=True,phase_candidate='HELICAL_PHASE_CANDIDATE'),
                     structure=dict(status='INCONCLUSIVE'))
        gates=from_analysis(summary)
        self.assertTrue(gates['PASS_ANGULAR_DECOMPOSITION'])
        self.assertFalse(gates['HELICAL_PHASE_CANDIDATE']);self.assertFalse(gates['ANGULAR_STRUCTURE_DETECTED'])


class SmallTransactionalReference(unittest.TestCase):
    def test_restart_complete_and_readonly_analysis(self):
        # A single tiny, bounded analytical-mode reference. Not a scientific preset.
        c=deepcopy(load(ROOT/'configs/vertical_short.json')['cases'][0])
        c.update(case_id='TECHNICAL_REFERENCE_ONLY',classification='TECHNICAL_REFERENCE_ONLY',mode='numerical_reference',initial='standing_mode',
                 grid=dict(kind='uniform',bounds=[[-20.,20.]]*3,shape=[7]*3),phase_z=[-10.,-5.,0.,5.,10.],phase_radii=[5.,10.],planes=[10.])
        c['source'].update(amplitude=0.,kind='null',duration=.2,sigma_xy=6.,sigma_z=6.,omega=1.)
        c['field'].update(t_end=.32,dt=.02,mass=.2,boundary='dirichlet',sponge_width=[5.]*3)
        c['observation'].update(sample_dt=.02,diagnostic_dt=.02,volume_dt=.02,dtype='float64')
        c['receivers'].update(historical_mode='passive',coupling=0.,radii=[5.],vertical_radii=[5.],azimuth_count=4)
        admission=dict(explicit_execute=True,status='PLANNED_NOT_EXECUTED',dependencies=dict(missing=[]),frozen_checks=dict(changed=[],missing=[]),limits=dict(max_matvec_operations=1e8))
        with tempfile.TemporaryDirectory() as td:
            root=Path(td);native=ledger_rk4;calls=[]
            def interrupt(system,y,ledger,t,dt,force):
                calls.append(t)
                if len(calls)==3:raise KeyboardInterrupt('controlled checkpoint test')
                return native(system,y,ledger,t,dt,force)
            with patch('hrf_vertical.runner.ledger_rk4',side_effect=interrupt):
                with self.assertRaises(KeyboardInterrupt):run_case(c,root/'resumed',admission)
            folder=root/'resumed'/c['case_id']
            self.assertEqual(json.loads((folder/'run.json').read_text())['status'],'INTERRUPTED')
            result=run_case(c,root/'resumed',admission)
            complete=run_case(c,root/'fresh',admission)
            self.assertEqual(result['frames'],17);self.assertTrue(verify_completion(folder))
            self.assertEqual(result['status'],'COMPLETED')
            for p in ('run.json','case.json'):self.assertEqual(json.loads((folder/p).read_text())['status'],'COMPLETED')
            with np.load(folder/'observations.npz') as a,np.load(root/'fresh'/c['case_id']/'observations.npz') as b:
                self.assertTrue(np.array_equal(a['energy'],b['energy']))
                extras=~a['receiver_threshold_valid']
                self.assertTrue(extras.any());self.assertTrue(np.isnan(a['relay_lock'][:,extras]).all())
            from hrf_vertical.analysis import analyze_case
            gates=json.loads((ROOT/'configs/gates.json').read_text())
            analysis=analyze_case(folder,root/'analysis'/c['case_id'],gates)
            self.assertEqual(analysis['structure']['status'],'INCONCLUSIVE')
            self.assertEqual(analysis['information']['spatial_resolution_adequate'],False)
            record('transactional_pipeline',dict(nodes=343,time=.32,frames=17,checkpoint_resume_bitwise_equal=True,
                                               status='PASS_REFERENCE_TESTS',interpretation='no scientific spiral verdict'))
            target=os.environ.get('HRF_WT02_TECHNICAL_OUTPUT')
            if target:
                import shutil
                shutil.copytree(folder,Path(target)/'reference_run'/c['case_id'])
                shutil.copytree(root/'analysis'/c['case_id'],Path(target)/'reference_analysis'/c['case_id'])
