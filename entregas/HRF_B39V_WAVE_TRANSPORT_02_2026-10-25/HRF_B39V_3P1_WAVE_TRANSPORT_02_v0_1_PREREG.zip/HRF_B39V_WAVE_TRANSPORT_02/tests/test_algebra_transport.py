"""Synthetic arrays for software tests only. No time integration or scientific output."""
import unittest,json
import numpy as np
from hrf_vertical.common import ROOT
from hrf_vertical.transport import vertical_observables,parity_error,orientation_nematic,cylindrical_current,ring_currents,peak_catalog
from hrf_vertical.helical import energy_velocity,curve_candidate,transport_gate,seed_plane
from hrf_vertical.analysis import phase_diagnostic,masked_axial_fit
from hrf_integral.ridge_tracking import local_peaks

G=json.loads((ROOT/'configs/gates.json').read_text())

class TransportAlgebra(unittest.TestCase):
    def setUp(self):
        self.axes=[np.linspace(-1,1,5)]*3;self.shape=(5,5,5);self.e=np.ones(self.shape);self.v=np.ones(self.shape)/125
        self.xyz=np.stack(np.meshgrid(*self.axes,indexing='ij'),axis=-1);self.j=np.zeros((*self.shape,3));self.j[...,2]=self.xyz[...,2]
    def stats(self,**kwargs):return vertical_observables(self.axes,self.e,self.j,self.v,planes=[1.],**kwargs)
    def test_symmetric_outflow_is_not_zero_transport(self):
        r=self.stats();p=r['planes'][0];self.assertAlmostEqual(p['signed_coordinate_z_net'],0);self.assertAlmostEqual(p['both_hemispheres_outward'],8)
    def test_hemisphere_partition_includes_central_dual_volume(self):
        r=self.stats();self.assertAlmostEqual(r['E_plus']+r['E_minus'],r['E_total_Eulerian']);self.assertAlmostEqual(r['E_plus'],r['E_minus'])
    def test_reflux_is_separate(self):
        self.j*=-1;p=self.stats()['planes'][0];self.assertAlmostEqual(p['plus_return'],4);self.assertAlmostEqual(p['plus_out'],0)
    def test_metric_surface_measure(self):
        g=np.broadcast_to(np.diag([4.,9.,16.]),(*self.shape,3,3));self.assertAlmostEqual(self.stats(gamma=g)['planes'][0]['plus_out'],96)
    def test_lapse_squared_killing_flux(self):self.assertAlmostEqual(self.stats(N=np.full(self.shape,2.))['planes'][0]['plus_out'],16)
    def test_mirror_covariant_vector(self):
        r=parity_error(self.e,self.e,self.j,self.axes);self.assertEqual(max(r['phi'],r['energy'],r['current']),0)
    def test_mirror_detects_corruption(self):
        self.e[0,0,0]+=1;r=parity_error(self.e,self.e,self.j,self.axes);self.assertGreater(r['phi'],0)
    def test_asymmetric_domain_not_pass(self):
        a=self.axes[:2]+[np.linspace(0,2,5)];self.assertEqual(parity_error(self.e,self.e,self.j,a)['status'],'NOT_APPLICABLE_ASYMMETRIC_DOMAIN')
    def test_coordinate_azimuthal_sign(self):
        c=cylindrical_current([[2.,0.,0.]],[[0.,3.,1.]]);self.assertAlmostEqual(c['azimuthal'][0],3);self.assertAlmostEqual(c['vertical'][0],1)
    def test_axis_azimuth_is_undefined(self):self.assertFalse(cylindrical_current([[0.,0.,0.]],[[1.,0.,0.]])['axis_valid'][0])
    def test_superluminal_current_invalidated(self):
        v,ok=energy_velocity(np.ones(2),np.array([[.3,0.,0.],[2.,0.,0.]]));self.assertTrue(ok[0]);self.assertFalse(ok[1]);self.assertTrue(np.isnan(v[1]).all())
    def test_metric_speed_not_euclidean_speed(self):
        v,ok=energy_velocity(np.ones(1),np.array([[.6,0.,0.]]),gamma=np.array([np.diag([4.,1.,1.])]))
        self.assertFalse(ok[0])
    def test_zero_energy_has_no_curve(self):self.assertFalse(energy_velocity(np.zeros(1),np.zeros((1,3)))[1][0])
    def test_seed_weight_uses_actual_outward_flux(self):
        p,w,err=seed_plane(self.axes,self.j,1.,256);self.assertAlmostEqual(w.sum(),4);self.assertAlmostEqual(err,0)
    def test_integrated_circulation_of_known_rotation(self):
        j=np.zeros_like(self.j);j[...,0]=-self.xyz[...,1];j[...,1]=self.xyz[...,0]
        r=ring_currents(self.axes,j,[0.],[.5]);self.assertAlmostEqual(r['circulation'][0,0],2*np.pi*.5**2,delta=1e-12)
    def test_out_of_domain_rings_are_not_clamped(self):
        r=ring_currents(self.axes,self.j,[0.],[5.]);self.assertTrue(np.isnan(r['circulation'][0,0]))
    def test_cylindrical_components_are_orthonormal_in_graph_metric(self):
        g=np.array([[[2.,.3,.4],[.3,1.5,.2],[.4,.2,1.8]]]);j=np.array([[.2,.3,.4]]);c=cylindrical_current([[2.,1.,1.]],j,g)
        self.assertAlmostEqual(sum(float(c[k][0]**2) for k in ('radial','azimuthal','vertical')),float(j[0]@g[0]@j[0]),delta=1e-12)
    def test_nonfinite_flux_is_not_a_diagnostic_pass(self):
        self.j[0,0,0,0]=np.nan
        with self.assertRaises(FloatingPointError):self.stats()
    def test_maxima_truncation_preserves_topology_count_and_ambiguity(self):
        r=peak_catalog(np.ones((5,5)),np.arange(5.),np.arange(5.));self.assertEqual(r['total_local_maxima'],25);self.assertTrue(r['truncated']);self.assertIsNone(r['primary'])

class HelixNegativeControls(unittest.TestCase):
    def setUp(self):self.t=np.linspace(0,100,101);self.theta=np.linspace(0,2*np.pi,101);self.valid=np.ones(101,bool)
    def candidate(self,theta,z,r=None):
        if r is None:r=np.full(101,10.)
        xyz=np.c_[r*np.cos(theta),r*np.sin(theta),z]
        return curve_candidate(self.t,xyz,self.valid,1.,1.,G),xyz
    def test_synthetic_helix_positive(self):self.assertTrue(self.candidate(self.theta,np.linspace(20,80,101))[0]['candidate'])
    def test_radial_energy_with_rotating_phase_does_not_pass(self):self.assertFalse(self.candidate(np.zeros(101),np.linspace(20,80,101),np.linspace(10,30,101))[0]['candidate'])
    def test_circulation_without_vertical_transport_does_not_pass(self):self.assertFalse(self.candidate(self.theta,np.full(101,20.))[0]['candidate'])
    def test_straight_symmetric_vertical_transport_does_not_pass(self):
        for s in (-1,1):self.assertFalse(self.candidate(np.zeros(101),s*np.linspace(20,80,101))[0]['candidate'])
    def test_returning_z_does_not_pass(self):self.assertFalse(self.candidate(self.theta,20+10*np.sin(self.theta))[0]['candidate'])
    def test_plan_cannot_certify_a_helix(self):
        _,xyz=self.candidate(self.theta,np.linspace(20,80,101));curves=dict(status='OPERATIONAL_ENERGY_CURRENT_CURVES',t=self.t,xyz=np.repeat(xyz[:,None,:],16,axis=1),valid=np.ones((101,16),bool),seed_weight=np.ones(16),seed_quadrature_relative_error=0.)
        self.assertEqual(transport_gate(curves,1.,1.,G,{},0.)['status'],'INCONCLUSIVE')
    def test_all_controls_plus_helix_yields_candidate(self):
        _,xyz=self.candidate(self.theta,np.linspace(20,80,101));curves=dict(status='OPERATIONAL_ENERGY_CURRENT_CURVES',t=self.t,xyz=np.repeat(xyz[:,None,:],16,axis=1),valid=np.ones((101,16),bool),seed_weight=np.ones(16),seed_quadrature_relative_error=0.)
        controls={k:True for k in ('PASS_NUMERICAL_REFERENCE','PASS_ENERGY_BALANCE','PASS_VERTICAL_SYMMETRY_CONTROL','SPATIAL_CONVERGENCE','TEMPORAL_CONVERGENCE','BOUNDARY_ROBUSTNESS','FLOWLINE_REFINEMENT')}
        self.assertEqual(transport_gate(curves,1.,1.,G,controls,0.)['status'],'HELICAL_ENERGY_TRANSPORT_CANDIDATE')
        self.assertEqual(transport_gate(curves,1.,1.,G,controls,.5)['status'],'INCONCLUSIVE')
    def test_antipodal_peaks_preserved(self):
        x=np.linspace(-10,10,41);X,Y=np.meshgrid(x,x,indexing='ij');phi=np.exp(-((X-5)**2+Y*Y))-np.exp(-((X+5)**2+Y*Y))
        peaks=local_peaks(phi,x,x);self.assertTrue(peaks['ambiguous']);self.assertIsNone(peaks['primary']);self.assertGreaterEqual(len(peaks['points']),2)
    def test_nematic_is_headless(self):
        x=np.linspace(-10,10,41);X,Y=np.meshgrid(x,x,indexing='ij');phi=np.exp(-((X-5)**2+Y*Y))-np.exp(-((X+5)**2+Y*Y))
        a=orientation_nematic(phi,x,x);b=orientation_nematic(-phi,x,x);self.assertEqual(a,b);self.assertGreater(a['resultant'],.8)
    def test_lost_trajectories_cannot_support_a_negative_finding(self):
        _,xyz=self.candidate(self.theta,np.linspace(20,80,101))
        valid=np.ones((101,16),bool);valid[4:]=False
        curves=dict(status='OPERATIONAL_ENERGY_CURRENT_CURVES',t=self.t,xyz=np.repeat(xyz[:,None,:],16,axis=1),valid=valid,seed_weight=np.ones(16),seed_quadrature_relative_error=0.)
        controls={k:True for k in ('PASS_NUMERICAL_REFERENCE','PASS_ENERGY_BALANCE','PASS_VERTICAL_SYMMETRY_CONTROL','SPATIAL_CONVERGENCE','TEMPORAL_CONVERGENCE','BOUNDARY_ROBUSTNESS','FLOWLINE_REFINEMENT')}
        self.assertEqual(transport_gate(curves,1.,1.,G,controls,0.)['status'],'INCONCLUSIVE')
    def test_zero_orientation_undefined(self):self.assertIsNone(orientation_nematic(np.zeros((3,3)),[-1,0,1],[-1,0,1])['angle_mod_pi'])

class PhaseControls(unittest.TestCase):
    def signal(self,kz,m=1):
        t=np.arange(0,35,.5);z=np.linspace(-20,20,9);theta=np.arange(32)*2*np.pi/32
        values=np.cos(m*theta[None,None,None,:]+kz*z[None,:,None,None]-t[:,None,None,None])
        return phase_diagnostic(t,values,z,theta,1.,m,G)
    def test_known_nonzero_kz(self):
        r=self.signal(.08);self.assertTrue(r['robust_candidates']);self.assertAlmostEqual(r['robust_candidates'][0]['kz'],.08,delta=.002)
    def test_nonzero_m_is_not_nonzero_kz(self):self.assertFalse(self.signal(0.)['robust_candidates'])
    def test_rotation_changes_angular_sign(self):
        a=self.signal(0.,1);b=self.signal(0.,-1);self.assertGreater(a['mean_chirality_by_window'][1],0);self.assertLess(b['mean_chirality_by_window'][1],0)
    def test_short_window_inconclusive(self):
        r=phase_diagnostic(np.arange(4.),np.zeros((4,3,1,32)),[-1,0,1],np.arange(32)*2*np.pi/32,1.,1,G);self.assertEqual(r['status'],'INCONCLUSIVE')
    def test_missing_edge_does_not_poison_valid_axial_segment(self):
        z=np.arange(8.);c=np.exp(1j*.2*z);c[0]=np.nan+1j*np.nan;r=masked_axial_fit(z,c,G);self.assertEqual(r['status'],'PHASE_TWIST_CANDIDATE');self.assertAlmostEqual(r['kz'],.2)
    def test_missing_height_is_not_interpolated_to_create_twist(self):
        z=np.arange(7.);c=np.exp(1j*.2*z);c[3]=np.nan+1j*np.nan;self.assertEqual(masked_axial_fit(z,c,G)['status'],'INSUFFICIENT_CONNECTED_Z')
