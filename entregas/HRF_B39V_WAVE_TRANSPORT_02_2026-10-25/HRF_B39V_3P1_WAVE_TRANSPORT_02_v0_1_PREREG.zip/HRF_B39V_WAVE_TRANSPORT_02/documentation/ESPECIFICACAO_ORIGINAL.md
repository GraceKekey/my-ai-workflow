# PROMPT MESTRE AUTOSSUFICIENTE PARA CODEX
## HRF — Próxima bancada B39V: propagação tridimensional, transporte helicoidal, geometria e receptores

**Identificador:** HRF-B39V-3P1-WAVE-TRANSPORT-02  
**Versão:** v0.1 — especificação de desenvolvimento  
**Idioma:** português brasileiro  
**Entrega desejada:** código completo, documentação incorporada e pacote ZIP executável  
**Estado científico exigido:** PRÉ-REGISTRADO — NOVAS SIMULAÇÕES NÃO EXECUTADAS

---

# 1. INSTRUÇÃO FUNDAMENTAL

Você, Codex, deve desenvolver a próxima bancada numérica do **Holographic Reconstruction Framework (HRF)** utilizando todas as informações fornecidas neste prompt.

**Este prompt contém o contexto necessário.**

Você NÃO deve depender de:

- Google Drive;
- arquivos de outros chats;
- acesso a projetos do ChatGPT;
- documentos científicos adicionais do HRF;
- repositórios externos específicos;
- links de documentação fornecidos em conversas anteriores.

Se houver arquivos ZIP anexados diretamente à sua sessão ou disponíveis no diretório de trabalho, utilize-os como material adicional e como fonte primária de código e dados históricos.

Entretanto, **nenhum arquivo externo é condição obrigatória para implementar a bancada autônoma descrita aqui**.

Se os códigos originais estiverem disponíveis, reaproveite-os e preserve suas interfaces. Se não estiverem disponíveis, implemente uma nova versão funcional, claramente identificada como implementação independente.

**Nunca afirme que reproduziu exatamente um experimento histórico cujo código e dados originais não foram disponibilizados.**

Não interrompa o desenvolvimento apenas porque alguma documentação histórica está inacessível. Separe o que pode ser implementado autonomamente daquilo que permanece bloqueado por falta de proveniência.

Não produza apenas um projeto, pseudocódigo ou orientações genéricas. Escreva os módulos reais.

---

# 2. CONTEXTO CIENTÍFICO DO HRF

O HRF é um programa independente de pesquisa em fundamentos da física, propagação de campos, organização informacional, geometria e reconstrução holográfica.

A estratégia científica é chamada **Reconstrução Unificadora Progressiva (RUP)**.

Ela opera em duas etapas:

**B — Integração da física estabelecida**

Partir de equações e modelos conhecidos, preservando os seus limites de validade. Implementar setores físicos separadamente e testar suas interfaces.

**A — Investigação de possível fundamento comum**

Somente depois, investigar se diferentes descrições podem emergir de uma estrutura física mais geral.

Não presumir que essa fundamentação comum existe ou já foi demonstrada.

## 2.1 Classificação científica obrigatória

Adote estas etiquetas em relatórios e código:

- **[F]** Resultado estabelecido da física ou matemática, dentro de seu domínio de validade.
- **[M]** Modelo, cálculo ou simulação.
- **[H]** Hipótese ainda não demonstrada.
- **[?]** Lacuna ou questão aberta.
- **[D]** Decisão metodológica.

Uma simulação bem-sucedida não é comprovação experimental.

## 2.2 Terminologia

**Bulk 3+1:** três dimensões espaciais e uma temporal.

**Boundary 2+1:** duas dimensões espaciais e uma temporal, quando pertinente à investigação holográfica.

**DIO:** organização informacional distribuída, proposta hipotética do HRF.

**GMFt:** manifestação local/contextual candidata de uma organização informacional, em propostas específicas do HRF.

DIO e GMFt são conceitos distintos, não demonstrados e não devem ser identificados automaticamente com uma onda clássica, um oscilador ou um receptor.

**GMF:** possui usos históricos especializados e não deve ser identificado automaticamente com GMFt.

Não introduzir entidades fundamentais adicionais como fatos estabelecidos.

## 2.3 Três problemas científicos separados

**W — Propagação e dinâmica:** evolução de ondas, energia, fase, circulação e transporte.

**G — Geometria/reconstrução:** origem ou reconstrução da geometria física.

**D — Dicionário boundary–bulk:** correspondência entre estados, operadores e observáveis de uma teoria de boundary e do bulk.

Esta bancada investiga principalmente **W**.

Pode usar uma geometria prescrita para estudar propagação, mas isso não demonstra que a geometria foi reconstruída holograficamente.

Manter explicitamente:

`BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY`

Nenhum resultado desta bancada deve ser promovido automaticamente a demonstração de DIO, GMFt, fóton quântico ou gravidade emergente.

---

# 3. HISTÓRICO CIENTÍFICO — B39V

A bancada B39V original investigou propagação ondulatória, geometria, efeitos de vales, focalização, sombras, atrasos e receptores.

Uma etapa posterior estendeu a investigação para uma implementação volumétrica 3+1, utilizando um campo escalar clássico e osciladores receptores.

Foi criada também uma bancada exploratória de diagnóstico de estrutura espiralada, comparando os dois sentidos de rotação de uma fonte dipolar.

Essa última execução é a referência imediata para a próxima investigação.

## 3.1 Configuração da última execução

Os parâmetros registrados foram:

| Parâmetro | Valor |
|---|---|
| Dimensões | 3 espaciais + tempo |
| Campo | Escalar real clássico |
| Geometria | Plana |
| Domínio x | −130 a +130 |
| Domínio y | −130 a +130 |
| Domínio z | −25 a +25 |
| Malha | 67 × 67 × 33 |
| Massa do campo | 0,05 |
| Frequência angular da fonte | 0,13 |
| Amplitude da fonte | 0,02 |
| Largura xy da fonte | 12 |
| Largura z da fonte | 10 |
| Duração nominal do pulso | 160 |
| Ramp | 20 |
| Quantidade configurada de pulsos | 3 |
| Período configurado | 200 |
| Passo temporal | 0,1 |
| Tempo final | 520 |
| Intervalo entre observações | 0,5 |
| Contorno | Sponge |
| Intensidade da sponge | 0,5 |
| Frequência própria dos receptores | 1,85 |
| Amortecimento dos receptores | 0,1 |
| Acoplamento | 0,05 |
| Receptores históricos | 468 |
| Receptores extras | 576 |
| Total de receptores | 1.044 |

Os experimentos foram:

- `splus`: rotação +1;
- `sminus`: rotação −1.

Cada caso produziu **1.041 frames**.

A classificação era:

`EXPLORATORY_NOT_HISTORICAL_MATCH`

Esses valores são referência da execução anterior. Não representam parâmetros universais do HRF.

## 3.2 Resultados anteriores

Os registros da última bancada apontaram:

| Observável | splus | sminus |
|---|---:|---:|
| Frames | 1.041 | 1.041 |
| Quiralidade angular média | +0,107966586 | −0,107966586 |
| Candidatos aceitos de torção de fase | 0 | 0 |
| Cristas classificadas como indefinidas ou ambíguas | 1.041 | 1.041 |
| Fração máxima absoluta de fluxo líquido em z | 5,184×10⁻¹² | 9,756×10⁻¹² |
| Assimetria energética máxima entre hemisférios | 1,828×10⁻¹² | 1,524×10⁻¹² |
| Disparos de receptores | 0 | 0 |

Também foi registrado erro relativo de reflexão da potência angular próximo de:

\[
3,8\times10^{-16}.
\]

Os diagnósticos de fase angular e varredura vertical foram executados.

O resultado científico estrutural permaneceu:

`INCONCLUSIVE_SPIRAL_STRUCTURE`

**Interpretação:**

[M] A estrutura angular responde ao sentido de rotação da fonte.

[M] A onda se propaga pelo volume tridimensional.

[?] Não foi demonstrado que o centro da energia percorre uma trajetória ascendente em espiral.

[?] Não foi identificada uma crista única suficiente para definir uma trajetória helicoidal.

[M] Os resultados são compatíveis com transporte aproximadamente simétrico entre os hemisférios superior e inferior, dentro da precisão registrada.

Um fluxo líquido próximo de zero NÃO significa necessariamente ausência de fluxo vertical. Os fluxos para +z e −z podem se cancelar.

## 3.3 Torção de fase observada como ajuste exploratório

Um diagnóstico anterior reportou inclinações locais da ordem de:

\[
|k_z|\approx0,01177.
\]

O passo espacial formal correspondente seria aproximadamente:

\[
P=\frac{2\pi}{|k_z|}\approx533.
\]

O domínio vertical tinha apenas 50 unidades.

Esses ajustes não preencheram os critérios de aceitação de estrutura helicoidal.

Portanto, não existe resultado positivo certificado de hélice de fase nem de transporte helicoidal.

## 3.4 Resultado dos receptores

Houve zero disparos.

Uma reanálise anterior estimou leitura seletiva máxima da ordem de:

\[
2,46\times10^{-11}.
\]

O limiar histórico correspondente era aproximadamente:

\[
1,10\times10^{-8}.
\]

Esses valores são pontos de referência da auditoria anterior; se os dados brutos não estiverem disponíveis, não devem ser apresentados como medidas independentemente reproduzidas.

Há uma diferença importante entre:

\[
\omega_{\mathrm{fonte}}=0,13
\]

e

\[
\Omega_{\mathrm{receptor}}=1,85.
\]

A possível dessintonia espectral é uma hipótese investigável, não uma causa já demonstrada.

O espectro real de uma fonte pulsada não se reduz necessariamente a uma única frequência.

## 3.5 Problemas conhecidos

A última bancada apresentou cinco limitações centrais:

1. Geometria plana, sem os vales históricos.
2. Domínio vertical relativamente curto.
3. Transporte helicoidal não resolvido.
4. Ausência de certificação específica de convergência e fronteiras para a hipótese da hélice.
5. Receptores com campo incidente, mas sem disparos.

Também há uma inconsistência documental: alguns `run.json` anteriores indicavam `RUNNING`, enquanto os respectivos registros consolidados indicavam `COMPLETED`.

A nova implementação deverá evitar essa inconsistência.

---

# 4. A PERGUNTA CIENTÍFICA PRINCIPAL

**Uma fonte dipolar girante emite uma perturbação cuja energia se propaga em espiral tridimensional, ou produz apenas uma estrutura angular rotativa sobre uma propagação predominantemente radial e simétrica?**

Distinguir rigorosamente:

1. Rotação da fonte.
2. Rotação temporal da fase.
3. Estrutura azimutal espacial.
4. Hélice geométrica de fase.
5. Circulação azimutal de energia.
6. Transporte vertical.
7. Trajetória helicoidal efetiva do transporte de energia.
8. Movimento do centroide de energia.

Esses oito fenômenos não são equivalentes.

Uma fonte que gira em um plano não seleciona automaticamente uma direção privilegiada de propagação em z.

**Não inclua artificialmente um termo de fase proporcional a z para criar uma hélice no experimento principal.**

Um campo com hélice imposta poderá aparecer somente como teste unitário sintético, claramente identificado como tal.

---

# 5. MODELO MATEMÁTICO AUTÔNOMO

Se o código original estiver disponível, preservar inicialmente a equação, normalizações e discretização existentes.

Se não estiver disponível, implementar o seguinte modelo de referência independente, documentando a diferença em relação à bancada histórica.

## 5.1 Campo escalar real

Usar unidades naturais com \(c=1\), salvo justificativa explícita.

A equação plana de referência é:

\[
\partial_t^2\phi
-\nabla^2\phi
+\mu^2\phi=S(x,y,z,t).
\]

Onde:

- \(\phi\): campo escalar real;
- \(\mu\): parâmetro de massa;
- \(S\): fonte externa;
- \(t\): tempo;
- \(x,y,z\): coordenadas espaciais.

Em geometria curva prescrita, usar uma implementação matematicamente consistente da equação de Klein–Gordon covariante:

\[
(\Box_g-\mu^2)\phi=S_g,
\]

com convenção de assinatura, sinal da fonte, ação e normalizações explicitamente documentadas.

Não reutilizar ingenuamente as fórmulas de energia plana quando a métrica for curva.

## 5.2 Energia e corrente no caso plano

Definir:

\[
\pi=\partial_t\phi.
\]

A densidade energética de referência é:

\[
\rho_E=
\frac12
\left(
\pi^2+|\nabla\phi|^2+\mu^2\phi^2
\right).
\]

E o fluxo energético:

\[
\mathbf J_E=-\pi\nabla\phi.
\]

Na convenção da equação plana acima:

\[
\partial_t\rho_E+\nabla\cdot\mathbf J_E=S\pi.
\]

Esse balanço deve ser verificado numericamente, contabilizando fronteiras e dissipação.

Na geometria curva estática, utilizar a corrente conservada apropriada ao campo e à simetria temporal disponível. Se a geometria não possuir simetria temporal, não pressupor conservação da energia na forma anterior.

## 5.3 Fonte dipolar girante

Se não houver código histórico, usar como **modelo novo e explícito**, e não como reconstrução exata da fonte original, uma fonte da forma:

\[
S_s(x,y,z,t)=
A f(r,z)\,w(t)
\left[
\frac{x}{\sigma_{xy}}\cos(\omega t)
+s\frac{y}{\sigma_{xy}}\sin(\omega t)
\right],
\]

com:

\[
f(r,z)=
\exp\left(
-\frac{x^2+y^2}{2\sigma_{xy}^2}
-\frac{z^2}{2\sigma_z^2}
\right),
\]

onde \(s\in\{-1,+1\}\).

A envoltória \(w(t)\) deverá permitir pulsos, rampas e trens de pulsos.

Esta expressão representa uma fonte espacial dipolar rotativa na implementação autônoma. Não afirmar que corresponde exatamente à fonte histórica B39V sem comparação de código.

Implementar também fontes de controle:

- nula;
- monopolar;
- dipolar fixa;
- dipolar girante +1;
- dipolar girante −1.

As fontes devem ser simétricas em z nos experimentos de paridade vertical.

---

# 6. EXPERIMENTO A — PROPAGAÇÃO VERTICAL

Criar três configurações iniciais:

**A0 — Referência**

Domínio vertical:

\[
z\in[-25,25].
\]

**A1 — Extensão intermediária**

\[
z\in[-60,60].
\]

**A2 — Extensão longa**

\[
z\in[-100,100].
\]

Preservar a resolução efetiva necessária para representar fonte, comprimento de onda e gradientes.

Não aumentar \(\Delta z\) automaticamente apenas porque o domínio cresceu.

Planejar memória, CPU e disco antes de cada execução.

## 6.1 Novos observáveis

Calcular:

\[
E_+(t)=\int_{z>0}\rho_E\,dV
\]

e

\[
E_-(t)=\int_{z<0}\rho_E\,dV.
\]

Também calcular os fluxos através dos planos:

\[
z=\pm z_0.
\]

Separar fluxos orientados para fora, para dentro e fluxos assinados.

Registrar:

- energia em cada hemisfério;
- fluxo para +z;
- fluxo para −z;
- energia acumulada que atravessa cada plano;
- reflexão;
- dissipação sponge;
- contribuição da fonte;
- balanço energético;
- erro de conservação.

Definir de modo claro a normalização de qualquer razão utilizada.

A intensidade do fluxo líquido deve ser comparada com o transporte bruto, não apenas com um número arbitrário.

---

# 7. EXPERIMENTO B — ESTRUTURA ESPIRALADA

Implementar diagnósticos independentes.

## B1. Decomposição angular

Em coordenadas cilíndricas:

\[
(r,\theta,z).
\]

Estimar os coeficientes harmônicos:

\[
a_m(r,z,t)
=
\frac{1}{2\pi}
\int_0^{2\pi}
\phi(r,\theta,z,t)e^{-im\theta}\,d\theta.
\]

Para análise de fase temporal, utilizar uma extração complexa estreita em banda com janela explicitamente documentada, como lock-in com janela Hann.

Registrar potência por modo, pureza, fase e incerteza.

Distinguir o modo angular de uma trajetória física.

## B2. Circulação de energia

Em coordenadas cilíndricas:

\[
\mathbf J_E=
J_r\hat{\mathbf r}
+J_\theta\hat{\boldsymbol\theta}
+J_z\hat{\mathbf z}.
\]

Medir:

- \(J_r\): transporte radial;
- \(J_\theta\): circulação azimutal;
- \(J_z\): transporte vertical.

Calcular também o momento angular orbital operacional em torno de z, com definições, unidades, volumes e condições de validade explícitos.

Não chamar esse diagnóstico de spin ou helicidade intrínseca de um fóton.

## B3. Torção de fase em z

Investigar ajustes:

\[
\Phi_m(z)\approx k_z z+\Phi_0.
\]

Calcular o ajuste separadamente em:

- hemisfério superior;
- hemisfério inferior;
- domínio global.

Não atravessar regiões de amplitude insuficiente.

Não remover artificialmente descontinuidades de fase nem desambiguar \(2\pi\) sem algoritmo justificado.

## B4. Cristas e centros de energia

Rastrear:

- máximos de amplitude;
- máximos de energia;
- centros de energia;
- orientação de dois lobos antipodais;
- estruturas contínuas realmente identificáveis.

O detector precisa admitir múltiplas cristas e ambiguidade.

É proibido escolher um único lobo de um dipolo simétrico só para produzir uma trajetória com aparência de hélice.

## B5. Teste efetivo de transporte helicoidal

Uma candidatura de transporte helicoidal só poderá ser registrada se houver evidência quantitativa simultânea de:

- circulação azimutal;
- transporte vertical;
- coerência espaço-temporal;
- robustez sob controles;
- ausência de interpretação puramente visual;
- estabilidade sob refinamento e variações admissíveis de fronteira.

Se houver fase giratória, mas fluxo energético predominantemente radial, o diagnóstico deve registrar isso explicitamente.

Se os dois hemisférios apresentarem transporte simétrico, não descrever o fenômeno como subida preferencial.

---

# 8. EXPERIMENTO C — EFEITOS DOS VALES GEOMÉTRICOS

Criar uma interface de geometria com pelo menos dois modos obrigatórios:

- `flat`;
- `synthetic_valley`.

Se existirem arquivos históricos locais com a definição dos vales B39V, acrescentar:

- `historical_one_valley`;
- `historical_two_valleys`.

**Atenção:** os modos históricos somente poderão ser ativados com os parâmetros e funções efetivamente recuperados do material original.

Não inventar profundidades, larguras ou posições históricas.

Na ausência dessas fontes, registrar:

`BLOCKED_MISSING_HISTORICAL_GEOMETRY`

A geometria sintética deve ser rotulada como um controle matemático novo e separado da B39V histórica.

## 8.1 Geometria sintética de controle

Implementar uma perturbação espacial suave e prescrita, com parâmetros explícitos, garantindo que a métrica permaneça não degenerada e com assinatura física adequada.

É aceitável utilizar uma função auxiliar de perfil gaussiano para testar o código de geometria.

Entretanto, uma função de altura \(H(x,y,z)\) não constitui, isoladamente, uma métrica do espaço-tempo.

É obrigatório derivar ou especificar claramente o tensor métrico utilizado, o operador diferencial e os elementos de volume.

Não afirmar solução dinâmica das equações de Einstein sem demonstração correspondente.

## 8.2 Comparações

Comparar os cenários:

- plano;
- vale sintético;
- vale histórico, se disponível;
- dois vales históricos, se disponíveis.

Medir:

- atraso de propagação;
- intensidade;
- focalização;
- sombras;
- dispersão;
- fase angular;
- circulação;
- fluxo vertical;
- resposta dos receptores.

Todas as comparações devem usar condições iniciais e parâmetros compatíveis, modificando uma variável principal por vez.

---

# 9. EXPERIMENTO D — RESPOSTA DOS RECEPTORES

Implementar uma camada independente de diagnóstico dos osciladores receptores.

Se houver código histórico, recuperar suas equações e regras originais.

Na ausência desse código, utilizar como modelo de referência explicitamente independente um oscilador amortecido forçado:

\[
\ddot q_i+
2\gamma_i\dot q_i+
\Omega_i^2q_i
=
g_i\,\phi(\mathbf x_i,t).
\]

Não apresentar esta equação como a implementação histórica B39V sem confirmação.

Os receptores passivos não podem retroagir sobre o campo. Se for implementado acoplamento recíproco, ele deve ser um modo dinâmico separado.

## 9.1 Canais de diagnóstico

Registrar para cada receptor:

1. Campo incidente.
2. Espectro temporal incidente.
3. Resposta do oscilador.
4. Fase e amplitude da resposta.
5. Energia do oscilador, se aplicável.
6. Comparação com o limiar.
7. Evento de disparo, quando existir regra válida.

Receptores históricos e receptores sintéticos novos não devem compartilhar indevidamente limiares ou identidades.

## 9.2 Varredura de frequência

Implementar uma varredura exploratória para:

\[
\Omega\in
\{0,10;\,0,13;\,0,20;\,0,50;\,1,85\}.
\]

Preservar 1,85 como referência da última execução.

Separar a frequência própria da resposta à frequência dominante do sinal realmente incidente.

Também preparar varreduras controladas de amortecimento e acoplamento.

**Não reduzir os limiares para fabricar disparos.**

Se forem utilizados os limiares históricos, preservar os valores por caso e os metadados originais. Se não estiverem disponíveis, não fabricar calibração histórica.

---

# 10. CONTROLES FALSIFICÁVEIS

Implementar testes que possam retornar resultados negativos.

São obrigatórios:

- Fonte nula.
- Fonte fixa, sem rotação.
- Inversão \(s=+1\leftrightarrow s=-1\).
- Simetria vertical \(z\leftrightarrow-z\).
- Geometria plana.
- Geometria perturbada conhecida.
- Domínio vertical aumentado.
- Diferentes condições de contorno.
- Refinamento espacial.
- Refinamento temporal.
- Fluxo radial sem circulação.
- Circulação azimutal sem transporte vertical preferencial.
- Campo sintético com hélice de fase conhecida.
- Dipolo com máximos antipodais degenerados.
- Oscilador amortecido com resposta analítica conhecida.

Os casos sintéticos servem para validar software e diagnósticos.

Não devem ser misturados aos resultados físicos exploratórios.

Congelar os critérios antes de executar os experimentos correspondentes.

Evitar adotar tolerâncias a posteriori para transformar um FAIL em PASS.

---

# 11. GATES E RESULTADOS CIENTÍFICOS

Implementar os seguintes estados:

### Gates de software

- `PASS_SOFTWARE`
- `PASS_REFERENCE_TESTS`
- `FAIL_SOFTWARE`
- `FAIL_NUMERICAL`
- `BLOCKED_RESOURCES`

### Gates de diagnóstico

- `PASS_ZSCAN_PIPELINE`
- `PASS_ENERGY_BALANCE`
- `PASS_ANGULAR_DECOMPOSITION`
- `PASS_RECEIVER_SPECTRAL_PIPELINE`
- `PASS_PARITY_CONTROL`

### Resultados interpretativos

- `ANGULAR_STRUCTURE_DETECTED`
- `VERTICAL_TRANSPORT_DETECTED`
- `AZIMUTHAL_CIRCULATION_DETECTED`
- `HELICAL_PHASE_CANDIDATE`
- `HELICAL_ENERGY_TRANSPORT_CANDIDATE`
- `NO_RESOLVED_HELICAL_TRANSPORT`
- `INCONCLUSIVE`

### Bloqueios de proveniência

- `BLOCKED_MISSING_HISTORICAL_GEOMETRY`
- `BLOCKED_MISSING_HISTORICAL_SOURCE`
- `BLOCKED_HISTORICAL_REPLICATION`
- `BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY`

A classificação deverá especificar claramente o domínio de validade de cada PASS.

Um teste de visualização aprovado não demonstra um fenômeno físico.

O resultado nulo ou inconclusivo é cientificamente aceitável.

---

# 12. REQUISITOS COMPUTACIONAIS

Utilizar preferencialmente:

- Python;
- NumPy;
- SciPy;
- Matplotlib;
- bibliotecas de visualização 3D adequadas;
- JSON;
- CSV;
- NPZ;
- pytest.

Não depender de serviços externos durante a execução.

Documentar versões e dependências em `pyproject.toml` ou equivalente.

## 12.1 Solver

Implementar um solver numérico real e verificável.

Para a versão autônoma plana, é aceitável utilizar diferenças finitas de ordem documentada e integrador temporal estável.

Se o código original estiver disponível, priorizar seu método já testado, preservando compatibilidade e proveniência.

Para geometria curva, utilizar discretização adequada ao operador métrico, mantendo a consistência entre campo, fluxos e energia.

Não substituir um solver físico por geração de gráficos artificiais.

## 12.2 Controle de recursos

O programa deve estimar:

- número de nós;
- memória de trabalho;
- memória do integrador;
- custo computacional aproximado;
- tamanho dos resultados;
- espaço necessário para checkpoints.

Implementar modo de planejamento que não execute a simulação.

Criar escrita incremental e leitura em blocos para evitar carregar todos os frames tridimensionais na memória.

Os dados diagnósticos devem conservar precisão apropriada; reduções de resolução usadas apenas na visualização devem ser documentadas.

## 12.3 Reprodutibilidade

Registrar:

- ID de cada cenário;
- hash SHA-256;
- versão do código;
- parâmetros;
- unidades;
- sistema operacional;
- versões das bibliotecas;
- sementes aleatórias;
- data e hora;
- comandos executados;
- status de execução;
- falhas;
- incertezas.

Implementar conclusão atômica de execução: evitar que um `run.json` permaneça em `RUNNING` depois de uma conclusão confirmada em outro registro.

Se um processo falhar, preservar estado `FAILED` ou `INTERRUPTED`, sem fingir conclusão.

---

# 13. VISUALIZAÇÕES EXIGIDAS

O projeto deve gerar rotinas para:

**A — Campo volumétrico 3D:** isosuperfícies positivas e negativas, fonte, eixos e receptores.

**B — Cortes verticais:** planos xz e yz para acompanhar a expansão da onda.

**C — Propagação horizontal:** planos xy em múltiplas alturas.

**D — Energia:** mapas de densidade e gráficos de fluxos +z/−z.

**E — Fase angular:** modos, intensidade, coerência e dependência em z.

**F — Circulação:** componentes radial, azimutal e vertical do fluxo.

**G — Cristas e centros de energia:** apresentar trajetórias apenas quando identificáveis, com ambiguidades visíveis.

**H — Receptores:** campo incidente, resposta espectral, limiares e disparos.

**I — Comparação geométrica:** campo plano versus campo com vales.

**J — Rotação s+ versus s−:** imagens sincronizadas e escalas idênticas.

Implementar exportação:

- PNG;
- GIF;
- MP4, quando o ambiente tiver codificador disponível;
- dados CSV/NPZ para reprodução das figuras.

As animações devem permitir observar temporalmente a onda completa, sem utilizar uma hélice gráfica pré-desenhada que possa ser confundida com um resultado.

---

# 14. ESTRUTURA SUGERIDA DE SOFTWARE

Organize uma implementação independente como:

```text
HRF_B39V_NEXT/
  README.md
  pyproject.toml

  hrf_b39v/
    __init__.py
    config.py
    grid.py
    geometry.py
    source.py
    scalar_solver.py
    boundary.py
    energy.py
    cylindrical_flux.py
    angular_modes.py
    phase_twist.py
    ridge_tracking.py
    receivers.py
    spectral_analysis.py
    experiments.py
    diagnostics.py
    visualization_3d.py
    animation.py
    resources.py
    provenance.py
    cli.py

  configs/
    baseline.json
    vertical_short.json
    vertical_medium.json
    vertical_long.json
    flat_rotation_pair.json
    synthetic_valley.json
    historical_valleys.json
    receiver_frequency_sweep.json
    boundary_controls.json
    refinement.json

  tests/
    test_scalar_solver.py
    test_energy_balance.py
    test_parity.py
    test_angular_modes.py
    test_phase_twist.py
    test_flux.py
    test_receivers.py
    test_geometry.py
    test_provenance.py

  documentation/
    SCIENTIFIC_CONTEXT.md
    HISTORICAL_BASELINE.md
    EQUATIONS.md
    PROTOCOL_PREREG.md
    OBSERVABLES_AND_GATES.md
    LIMITATIONS.md
    HOW_TO_RUN.md

  results/
  figures/
  manifests/
```

Os nomes podem ser adaptados à arquitetura existente, se ela for tecnicamente superior.

A documentação deve reproduzir o contexto necessário deste prompt, para que o pacote final seja autossuficiente.

Não deixar módulos com apenas `pass`, `TODO` ou placeholders, salvo dependências históricas genuinamente bloqueadas e claramente identificadas.

---

# 15. COMANDOS E MODOS DE EXECUÇÃO

Implementar comandos reais para:

```bash
python -m hrf_b39v.cli validate
python -m hrf_b39v.cli plan --config configs/vertical_medium.json
python -m hrf_b39v.cli test
python -m hrf_b39v.cli run --config configs/vertical_medium.json
python -m hrf_b39v.cli analyze --input results/CASO
python -m hrf_b39v.cli visualize --input results/CASO
```

Esses são contratos desejados de interface. Ajuste a sintaxe se necessário, documentando a interface final.

O comando `plan` não pode iniciar a PDE.

O comando `test` deve rodar apenas testes técnicos e referências controladas, sem acionar por engano uma rodada científica extensa.

O comando `run` deve ser explícito e separado do comando de instalação.

---

# 16. ETAPAS DO TRABALHO

## ETAPA 1 — Preparação

Crie a estrutura do projeto e documente o contexto histórico fornecido neste prompt.

Se houver ZIPs locais, audite seu inventário e seus hashes.

Se não houver, prossiga com a implementação independente.

## ETAPA 2 — Núcleo físico

Implemente o solver plano, as fontes, as fronteiras e a energia.

Valide primeiro problemas matemáticos de referência de pequeno custo.

## ETAPA 3 — Diagnósticos

Implemente fluxos verticais separados, modos angulares, corrente azimutal, fase e rastreamento de cristas.

Inclua casos artificiais conhecidos para verificar se os detectores distinguem uma hélice verdadeira de uma rotação sem transporte helicoidal.

## ETAPA 4 — Geometria

Implemente o controle sintético em geometria prescrita.

Adicione a geometria histórica somente se as fontes originais estiverem localmente disponíveis.

## ETAPA 5 — Receptores

Implemente osciladores, espectros, modos passivos e os controles de ressonância.

Preserve a distinção entre resposta contínua e disparo histórico.

## ETAPA 6 — Relatórios e visualizações

Implemente gráficos, exportações, animações, relatórios e manifesto de proveniência.

## ETAPA 7 — Pré-registro

Congele:

- hipóteses;
- variáveis independentes;
- controles;
- tolerâncias justificadas;
- gates;
- parâmetros;
- versões de software;
- limites computacionais.

Não altere critérios após observar resultados científicos.

---

# 17. RESTRIÇÃO DE EXECUÇÃO

**Nesta solicitação, a tarefa principal é ESCREVER OS CÓDIGOS, não executar a nova investigação científica.**

Você está autorizado a:

- desenvolver módulos;
- fazer análises estáticas;
- executar testes unitários;
- testar problemas analíticos mínimos;
- verificar sintaxe;
- conferir importações;
- executar pequenos testes técnicos indispensáveis para demonstrar que o software funciona.

Não está autorizado a:

- executar a bateria científica completa;
- executar varreduras de parâmetros;
- executar rodadas físicas de alta resolução;
- produzir um novo veredicto sobre a existência de espiral;
- sobrescrever dados históricos;
- preencher relatórios científicos com resultados inventados.

As novas rodadas devem permanecer:

`NOT_EXECUTED`

Os testes técnicos realmente executados devem possuir registro separado.

---

# 18. ENTREGA FINAL OBRIGATÓRIA

Entregue um único ZIP principal:

`HRF_B39V_3P1_WAVE_TRANSPORT_02_v0_1_PREREG.zip`

Ele deve conter:

1. Todo o código-fonte.
2. Configurações completas.
3. Testes automatizados.
4. Equações e convenções.
5. Descrição dos resultados anteriores.
6. Plano das novas experiências.
7. Critérios de aceitação e falha.
8. Rotinas de figuras e animações.
9. Manual de execução.
10. Manifesto SHA-256.
11. Lista de materiais históricos disponíveis e indisponíveis.
12. Relatório de testes técnicos executados.
13. Declaração explícita de que as novas rodadas científicas não foram executadas.

Se algum recurso importante não puder ser implementado, registre-o como bloqueio real e explique a consequência para a interpretação.

Verifique a integridade do ZIP antes de disponibilizá-lo.

---

# 19. INSTRUÇÃO FINAL

A última bancada mostrou rotação angular associada ao sentido de giro da fonte, mas não conseguiu demonstrar uma trajetória energética helicoidal ascendente.

A nova bancada precisa responder, progressivamente:

**Pergunta 1:** A energia se propaga para cima e para baixo de maneira simétrica?

**Pergunta 2:** Existe fluxo azimutal físico, além da rotação da fase?

**Pergunta 3:** O fluxo azimutal e o vertical possuem correlação suficiente para caracterizar transporte helicoidal?

**Pergunta 4:** Os vales geométricos modificam esse transporte?

**Pergunta 5:** Por que os receptores respondem sem disparar?

**Pergunta 6:** Os efeitos persistem sob controles de simetria, domínio, fronteiras e refinamento?

Não procure confirmar antecipadamente uma espiral.

Não imponha resultados por construção.

**Implemente uma bancada numérica completa, independente, reproduzível e capaz de refutar as hipóteses propostas.**

Ao terminar, entregue o ZIP, os comandos para executar as futuras simulações e um resumo preciso do que foi implementado, testado, bloqueado e ainda não executado.

**ESTADO FINAL: CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**
