# Limites físicos e computacionais

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[M/?] Campo escalar clássico e geometrias prescritas, sem teoria quântica de fótons, polarização eletromagnética real ou Einstein dinâmico. Não derivamos ħ, dimensão espacial de uma boundary, helicidade intrínseca, partículas, DIO, GMFt, gravidade emergente ou holografia física. BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY.

[?] Não há dados científicos SPIRAL brutos. A síntese do histórico depende das medidas informadas; reprodução histórica permanece bloqueada. As fontes/alturas locais foram aproveitadas e incluídas; isso não é a rodada experimental antiga nem uma certificação de equivalência 2,5D→3+1.

[?] Curvas de J/e são um indicador operacional local em energia não nula. Não são trajetórias materiais únicas. Exigência de uma volta completa não foi introduzida: o critério de candidatura usa meia volta≥π com outros controles. Fontes com dois lobos podem continuar sem crista única. Fase linear no intervalo vertical não prova uma hélice global.

[M/?] O balanço global semidiscreto é testável, mas correntes e integrais de planos são projeções e quadraturas espaciais próprias, sujeitas a erro de refinamento. O histórico usa energia quadrada da média de π; a nova projeção usa média de π². Geometria histórica é afim por partes com borda/extrusão prescrita. Simetria tensorial contínua não garante simetria exata da triangulação volumétrica.

[?] O plano histórico mais grosso não satisfaz o proxy conservador de banda/espaço; a análise não poderá transformar isso em evidência robusta de transporte. A maior malha física de refinamento tem estimativa de56.17GiB e excede o teto de24GiB: bloqueio real. Não foi substituída por uma malha grosseira rotulada como convergida.

[D] A pré-análise de custos é conservadora, não medição de pico RSS nem duração calibrada. Se a RAM/disco livre forem menores, a CLI bloqueia. Arquivos por chunk não carregam todos os volumes na memória; cortes/anéis/receptores compactos podem ser agregados após admissão. O plano não é um certificado de convergência nem de custo exato.

[D] Dependências Python são instaladas uma vez; execução local não acessa Drive/repositório/serviço externo. MP4 requer ffmpeg com libx264; ausência do codificador é bloqueio opcional, declarado, não sucesso falso. PNG/GIF continuam disponíveis. A animação tem câmera/escala fixas e tempos rotulados; decimação visual não é resolução temporal dos diagnósticos.
