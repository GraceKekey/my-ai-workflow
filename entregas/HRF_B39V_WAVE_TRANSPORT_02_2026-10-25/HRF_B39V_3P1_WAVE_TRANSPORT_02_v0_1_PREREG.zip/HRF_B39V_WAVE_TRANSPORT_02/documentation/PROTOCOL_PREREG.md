# Protocolo pré-registrado

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] Congelamento anterior a qualquer resultado científico WT-02: código, critérios, parâmetros, entradas e este protocolo constam de `hashes_antes_da_execucao.txt`. Mudança requer nova versão, motivação e novo manifesto. As referências técnicas são registradas separadamente. Não foram usados resultados físicos novos para ajustar limiares.

[H1] Na geometria/fonte/contornos pares, a propagação vertical pode ser bidirecional e o fluxo líquido pequeno pode ocultar transporte bruto. [H2] Um modo angular e circulação não implicam transporte helicoidal. [H3] Vales prescritos podem alterar chegada, sombra/foco, dispersão e corrente. [H4] Espectro e função de transferência podem explicar parte da resposta sem disparo; diferença entre frequências nominais é insuficiente. [H5] O efeito observado pode ser artefato de malha/domínio/fronteira. As cinco hipóteses admitem resultados negativos/inconclusivos.

[D] Plano A: casos planos z ±25/±60/±100, resolução mantida. Plano B: pares s+ e s−, modos e correntes separados, curvas J/e nos dois hemisférios, nenhuma crista arbitrariamente escolhida. Plano C: flat, vale sintético e alturas históricas recuperadas, mesma fonte/malha nas famílias comparáveis. Plano D: nove replays passivos com sinal incidente fixo, uma mudança por contraste.

[D] Fonte principal: dipolo original, normalização continuum_L2, A=.02, ω=.13, μ=.05, σxy=12, σz=10, pulso sin² de duração160; count3/period200 são inativos no modo pulsed. dt solicitado .1, t_final520. Receptores históricos Ω1.85/γhist.1/g.05 recíprocos; extras passivos; rede estacionária desligada. Modos passivos e ausência de giro são controles distintos.

[D] Todos os JSONs têm status NOT_EXECUTED, unidades c=1, IDs, entradas/hash, malha, fonte, contorno, tolerâncias/recursos e dependências. Os estados efetivos vão apenas em resultados. `baseline.json` documenta uma configuração antiga, não recertifica dados indisponíveis. `baseline_reanalysis` não usa solver e exige dados reais fornecidos depois.

[D] Cadência principal sample/diagnostic/volume=.5; família de refinamento volume=.25 em todas as três malhas físicas. Registros incrementais φ e p, cortes, anéis angulares e ledger. Precisão float64 na evolução, float32 nos volumes científicos planejados; referências numéricas matemáticas float64. Não refinar, reduzir dados ou alterar amplitude automaticamente para caber nos recursos.

[D] Critérios exatos: `OBSERVABLES_AND_GATES.md` e `configs/gates.json`. A novidade metodológica WT-02 exige ao menos 80% do peso de fluxo em curvas com tempo/radio/amostragem resolvidos para permitir inclusive um resultado negativo de transporte. Perda de curvas não é evidência de ausência de hélice. Limite da sponge no rastreador vem da configuração do caso.

[D] Ordem futura: validate → plan por caso → verificar manifesto → comando run explícito → análise sem solver → referências/controles e certificação por evidências calculadas → figuras → relatório. A ausência de dados/recursos produz bloqueio; a ausência de controles produz INCONCLUSIVE. Nenhum PASS de software certifica existência de espiral.

[?] Os critérios de helicidade são operacionais e metodológicos, não limites fundamentais nem erros experimentais. O teste investiga W; G/D continuam separados e bloqueados.
