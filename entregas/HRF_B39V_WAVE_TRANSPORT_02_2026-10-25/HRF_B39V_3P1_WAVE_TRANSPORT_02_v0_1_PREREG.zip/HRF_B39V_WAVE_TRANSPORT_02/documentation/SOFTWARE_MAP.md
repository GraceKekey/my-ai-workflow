# Módulos reais e responsabilidades

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] Arquitetura em três camadas, preservando o trabalho disponível em vez de reiniciar um solver simplificado.

| Camada | Implementação |
|---|---|
| hrf_integral | malha P1 tetraédrica, ADM, sistema KG/osc, integração base, interpolação, observação, fase/cristas, isosuperfícies e codec; código herdado preservado |
| hrf_vertical/config, admission, resolution | validação, cadências, recursos antes da alocação, hashes, banda/passo próprio e limites efetivos |
| hrf_vertical/system, runner, energy, observer | carga/normalização/fonte, execução explícita, RK4 com ledger, quadratura energética corrigida |
| hrf_vertical/geometry | alturas originais ou sintéticas e métrica prescrita, sem nova solução histórica |
| hrf_vertical/transport, helical, controls | hemisférios/superfícies próprias, correntes, nemático, curvas J/e, candidatos e evidências de controle |
| hrf_vertical/storage, dataset | chunks atômicos, hashes, checkpoint/retomada, selo final, streaming compatível com SPIRAL |
| hrf_vertical/spectral, analysis | espectros incidentes, transferências, FOH, readout histórico, fases e síntese sem nova PDE |
| hrf_vertical/figures + hrf_b39v/visual_exports | figuras 3D, cortes xz/yz/xy, energia/fluxos, receptores, pares com escala comum e CSV/NPZ/GIF/MP4 |
| hrf_b39v/cli, validation, gates | interface pública autônoma, testes técnicos separados, validação de congelamento e vocabulário WT-02 |
| scripts/wt02.py, run_linux.sh, run_windows.bat | entrada isolada e BLAS1; sem execução automática |

[M] Não há solver substituído por desenho, classes vazias ou funções de demonstração usadas como ciência. As únicas gerações sintéticas pertencem a testes explicitamente rotulados. O algoritmo de cristas pode retornar múltiplos máximos, ambiguidades e falta de informação; isso é comportamento científico previsto.

[?] Permanecem dependentes de execução científica futura: convergência da malha grande, influência das fronteiras, resposta real dos receptores, efeito quantitativo dos vales e qualquer candidatura de helicidade. Reanálise histórica e replay precisam de seus dados reais. Isso não é um módulo sem implementação; é ausência de entrada/resultado autorizado.
