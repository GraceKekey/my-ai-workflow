# Receptores, espectro e não disparo

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[M] As 468 identidades e posições originais vêm de inputs/historical_receivers.csv. Identidades H000...H467 nunca são atribuídas a sondas extras. Histórico ativo significa posição dentro do domínio; reporta-se quantos dos 468 foram efetivamente incluídos. Extras de anéis horizontais/verticais conservam rótulos próprios, inclusive coincidências geométricas, e são passivos por padrão. Na saída nova, receiver_threshold_valid é falso para extras e seus canais de relé/razão por limiar ficam NaN (não calibrados), não recebem um limiar histórico por conveniência.

[D] `b39_rele.py` e limiares por caso são preservados. No cenário novo de comparação geométrica, usa-se a referência congelada G_P para todas as geometrias, explicitamente, isolando a variável geometria. Isso não reproduz uma calibração histórica específica de cada geometria. Nos arquivos antigos, a reanálise usa o limiar realmente registrado por caso. A inversão de giro usa a entrada s− respectiva.

[M] O pipeline mede sinal incidente, PSD Welch por frequência angular, pico/banda95/resolução espectral, amplitude/fase/quadratura do oscilador, energia ½(P²+Ω²X²), leitura seletiva, razões contínuas por limiar, cruzamento de limiar e relé histórico. A PSD divide a densidade por 2π ao converter Hz→ω. Resposta estacionária usa H(ω)=−g/(Ω²−ω²+iγhistω), banda de −3dB exata incluindo ausência de ressonância não nula no caso sobreamortecido. PSD teórica não substitui resposta transitória medida.

[D] A família passiva tem nove entradas: Ω=.10,.13,.20,.50,1.85 a γhist=.1,g=.05; γhist=.05,.20 a Ω1.85,g.05; g=.025,.10 a Ω1.85,γhist.1. Um parâmetro principal muda por contraste. Replay usa exponencial matricial exata para interpolação linear por partes do sinal gravado (FOH). Isso não resolve novamente o campo nem descreve a auto-consistência de uma mudança recíproca de Ω. O mesmo limiar continua congelado; eventos do replay são contrafactuais, nunca disparos históricos reais.

[?] Os dados brutos incidentes da rodada do celular estão ausentes. O replay está implementado e bloqueia quando o input não existe; pode operar sobre uma futura rodada WT-02 real ou sobre os dados antigos fornecidos depois, sem editar critérios. Não foi executada varredura científica nesta entrega.

[D] Cinco níveis distintos: perturbação incidente → acoplamento não nulo → resposta do oscilador → cruzamento de limiar → relé. Nenhum nível demonstra DIO/GMFt. Não se reduz o limiar para obter um disparo. Ausência de disparo não implica ausência de campo.
