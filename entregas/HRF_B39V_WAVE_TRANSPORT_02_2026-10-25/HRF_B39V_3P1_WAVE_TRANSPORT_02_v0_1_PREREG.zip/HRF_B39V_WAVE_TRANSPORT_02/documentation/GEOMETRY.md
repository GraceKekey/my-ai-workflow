# Geometria prescrita: sintética e histórica recuperada

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[M] Interfaces: `flat`, `synthetic_valley`, `historical_one_valley`, `historical_two_valleys`; nomes internos anteriores `analytic_graph`/`historical_graph` continuam aceitos. Todas são estáticas, N=1, β=0. A função de altura é apenas entrada para a métrica especificada abaixo.

\[
H(x,y,z)=h(x,y)e^{-z^2/(2\ell_z^2)},\quad \gamma_{ij}=\delta_{ij}+\partial_iH\partial_jH,\quad ds^2=-dt^2+\gamma_{ij}dx^idx^j.
\]

[F] detγ=1+|∇H|²>0 e os autovalores espaciais são 1,1,1+|∇H|². A métrica 4D é lorentziana. O operador usado é Δγφ=(1/√γ)∂i(√γ γij∂jφ). Volume próprio √γ d³x; nenhum resultado das equações de Einstein é reivindicado.

[D] No sintético h=−Σ a exp(−((x−x0)²+(y−y0)²)/(2σ²)), suave e prescrito. Os parâmetros estão no JSON. É um controle novo, não aproximação visual de um vale histórico.

[M] Os arquivos P,h,T foram efetivamente recuperados da B39V 2,5D, sem nova solução de Poisson. O adaptador usa a triangulação original T, interpolação baricêntrica e derivadas afins por triângulo. Cada arquivo tem 154987 nós.

| arquivo incluído | fontes históricas (x,y,α,σ) | min h arquivado |
|---|---|---:|
| G_V1a12_s+1.npz | (0,0,12,8) | −34.864140527346414 |
| G_V2n_s+1.npz | anterior e (0,55,6,5) | −41.11992962824829 |
| G_V2o_s+1.npz | anterior central e (−45,0,8,6) | −44.891989081441324 |

[D] α é intensidade da fonte da construção histórica, não a profundidade de h. O perfil arquivado não foi substituído por gaussianas. Extrusão ℓz=15 nos casos históricos é uma extensão volumétrica prescrita explícita, não prova da equivalência quantitativa 2,5D→3+1. Os hashes e limites de gradiente estão em inputs/.

[?] h é afim por partes, derivadas descontínuas nas arestas; fora do disco histórico R=155 o adaptador usa zero. A métrica é regular por elementos e positiva, sem reivindicar suavidade C1 global. Usar refinamento e observar a borda da extensão. Isso é uma limitação real, não um bloqueio de importação do código.

[F/M] H é par em z; γxz e γyz são ímpares. O teste tensorial correto é γ(x,y,−z)=R γ(x,y,z) R, R=diag(1,1,−1). Não exigir igualdade elemento a elemento sem transformar índices. Esta geometria não escolhe +z espontaneamente.

[D] Os modos históricos recusam arquivo ausente. Não há geração automática de vale substituto. `BLOCKED_MISSING_HISTORICAL_GEOMETRY` deve ser reportado quando a respectiva entrada não existir/for corrompida.
