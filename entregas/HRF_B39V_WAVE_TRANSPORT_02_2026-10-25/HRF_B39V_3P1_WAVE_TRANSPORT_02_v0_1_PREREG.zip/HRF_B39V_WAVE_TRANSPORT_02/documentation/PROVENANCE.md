# Materiais disponíveis, proveniência e alterações

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] A especificação atual está incluída integralmente. O manifesto de origem VVR com210 arquivos foi conferido antes das alterações. O inventário JSON (`reports/inventory.json`) distingue inspeção de texto, leitura de arrays e simples verificação byte a byte; não confunde hash com leitura científica.

[M] Nesta derivação, 149 arquivos herdados continuam idênticos (incluindo o solver integral e as rotinas históricas); os arquivos alterados estão listados nominalmente no inventário. Mudanças concentram-se na camada hrf_vertical e na nova CLI/validação/exportação hrf_b39v. As interfaces internas históricas são preservadas. Não foram executadas CLIs antigas extensas.

[D] Novos recursos: fontes nula/monopolar/dipolo fixo; perfil de sponge histórico explícito na referência; dependências exclusivamente locais/autônomas; 12presets, validação/teste/planejamento/execução separada; gates públicos WT-02; exportação horizontal e mapas de energia/corrente com CSV/NPZ; referências analíticas técnicas, retomada e teste contra falso negativo por perda de curvas.

[D] Alturas originais P/h/T, catálogo468, limiares históricos por caso e todos os códigos usados estão no ZIP. A extensão 3+1 das alturas é declarada em GEOMETRY.md. Dados científicos grandes SPIRAL não estão no pacote e não foram inventados. Os relatórios e hashes VVR anteriores em provenance/vvr_original/ são arquivos históricos, não configuração ativa da nova versão.

[D] Alterações antes do congelamento: correção de rótulos e admissão; passagem da largura de sponge ao rastreador; NO_RESOLVED exige cobertura de curvas resolvidas≥80%; correção da nomenclatura de frames para compatibilidade com ffmpeg (`frame_%05d.png`). O primeiro ensaio de exportação encontrou nomes com4dígitos; o registro foi preservado em build_02, e a exportação será revalidada com5dígitos. Não foi erro de codificador ausente nem resultado físico. Também foram separados máximos de amplitude/energia e desativados limiares/relés para sondas extras; as referências futuras usam float64, e o hash do código usa caminhos POSIX para portabilidade. Nenhuma dessas correções usou resultados científicos novos.

[?] BLOCKED_HISTORICAL_REPLICATION continua. Os capítulos externos que bloqueavam a versão anterior não são dependência desta solicitação autossuficiente. Não se afirma ter lido suas versões mais recentes nem se exige seu envio para operar os novos controles matemáticos. A investigação não certifica G/D.
