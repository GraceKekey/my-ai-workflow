# Observáveis, incertezas e gates quantitativos

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[D] Valores congelados em configs/gates.json. As tolerâncias são metas metodológicas anteriores à ciência, motivadas pela ordem de discretização, controles analíticos/sintéticos e necessidade de rejeitar interpretações ambíguas. Não são barras de erro já medidas em cenários grandes.

| Gate/observável | Regra pré-registrada | Controle/falha possível |
|---|---|---|
| PASS_SOFTWARE | zero falhas nos testes/validação; hash íntegro | matriz incorreta, IO corrompido, manifesto alterado |
| PASS_REFERENCE_TESTS | referências técnicas limitadas aprovadas | solução nula, modo analítico, oscilador e checkpoint; não certifica a malha científica |
| FAIL_SOFTWARE / FAIL_NUMERICAL | entrada/código inválido / não finito, divergência ou referência física numérica falha | logs preservados, sem converter a PASS |
| BLOCKED_RESOURCES | RAM, disco real/computado ou operações acima do teto | limites de 1 byte em testes adversariais |
| PASS_ZSCAN_PIPELINE | pelo menos 3 registros lidos e cálculo de hemisférios/planos concluído | não significa transporte detectado |
| PASS_ENERGY_BALANCE | max erro relativo do ledger global ≤1e−6 | fonte nula, fronteira fechada, sponge e modo recíproco/passivo |
| PASS_PARITY_CONTROL | φ≤2e−6, energia≤1e−3, J transformada≤5e−3 em L2 relativo | domínio assimétrico é não aplicável; espelhar componentes vetoriais |
| PASS_ANGULAR_DECOMPOSITION | ≥16 frames, janela Hann completa e algum anel válido | janela curta retorna INCONCLUSIVE; dados sintéticos m conhecidos |
| PASS_RECEIVER_SPECTRAL_PIPELINE | canal histórico reproduzido em erro relativo ≤1e−10 e potência nos 10% superiores do Nyquist ≤.001 | sinal conhecido e oscilador analítico; PSD amostrada não exclui alias anterior |
| ANGULAR_STRUCTURE_DETECTED | fração de potência m≠0≥.5 em anel válido, informação espacial adequada | m≠0 com kz=0 |
| AZIMUTHAL_CIRCULATION_DETECTED | |∫Jtheta dV| > .05 ∫|Jtheta|dV, informação adequada | fluxo radial e circulação com Jz=0 |
| VERTICAL_TRANSPORT_DETECTED | máximo por par de planos da energia total orientada para fora >.01 Etotal,max, informação adequada | fluxos ±z separados; não somar energia repetida por planos distintos |

[M] E± usa volume próprio e metade do volume dual no plano z=0. Fluxos em ±z0: potência local orientada ±√γ Jz (N=1); integrais separadas de parte positiva/negativa produzem out/return; net=out−return, gross=out+return. São superfícies de coordenadas, com normal físico e medida explicitados. Fluxo líquido coordenado +z é plus_net−minus_net; transporte para fora é a soma. Os canais individuais e energias acumuladas são gravados; o centroide é ponderado por e dV, por plano.

[M] J é projetada em base Euleriana ortonormal: z normal ao plano constante-z; r tangente radial; theta tangente de Gram–Schmidt. Circulação é ∮Ji dxi; integrais de volume de Jtheta são momentos operacionais distintos. Lz=−∫π(x∂yφ−y∂xφ)dV; dLz/dt é diagnóstico de torque operacional. Conservação de Noether exige simetria axial real e contorno adequado; não é spin intrínseco.

[D] Fase: lock-in complexo Hann com 1.5,2,2.5 ciclos e bordas descartadas, m=−4..4 e 64 ângulos. Piso max(1e−14,1e−6 amplitude máxima). Modo primário m=s (ou m=1 no controle s=0), pureza ≥.6. Ajuste axial no maior segmento conectado com ≥4 alturas válidas, passo de fase ≤.8π, extensão de fase≥.5rad e RMS ponderado/ extensão≤.25. Reportar todas as tentativas, inclusive rejeitadas. Candidato exige estabilidade de kz entre janelas≤.2. Ajustes global/+z/−z separados, sem interpolar lacunas; erro padrão do ajuste é descritivo, não intervalo de confiança com amostras independentes. Fonte sem eixo axial imposto; m=1,kz=0 deve rejeitar torção.

[D] HELICAL_ENERGY_TRANSPORT_CANDIDATE: curvas de J/e, não trajetórias materiais. Semear por fluxo positivo em plano ≥3σz e somente depois do desligamento da fonte e do cruzamento de 10% do fluxo acumulado. Pelo menos16 sementes, erro de quadratura do plano≤.05, refluxo≤.1. Cada curva candidata exige ≥16 frames conectados, duração≥1 período, r≥2 células, variação angular≥π, |Δz|≥max(20,4 células), CV do raio≤.25, resíduo theta(z) relativo≤.2 e ≥90% dos passos para fora. Peso de candidatos≥.2 e peso com resolução temporal/radial válida≥.8. Velocidade física superluminal além de 1+1e−5 invalida; dt dos volumes≤.5 célula; interromper ao entrar na sponge ou perder amplitude/continuidade.

[D] Candidatura e NO_RESOLVED_HELICAL_TRANSPORT exigem referências científicas de malha (RMS≤.02, ordem espacial≥1.5, temporal≥3.5), balanço, paridade, refinamentos e controles de contorno efetivos. Em contrastes: campo/chegada≤5%, fluxos/resposta receptora≤10%, classificações preservadas; variação da fração de curvas≤.05 absoluta. Evidências incluem arquivos e SHA e medidas calculadas; um Booleano fornecido pelo usuário não certifica um gate. NO_RESOLVED é restrito à amostragem/intervalo testados, nunca prova geral de inexistência.

[D] Sem informação espacial, janela, cobertura de curvas ou controles: INCONCLUSIVE. Certificar cada hemisfério separadamente; candidato em um lado não significa subida preferencial. Os máximos antipodais mantêm empates: tolerância relativa .001, até8 posições salvas, truncamento invalida máximo único. Orientação nemática exp(2iθ), sem seta; resultante≤.05 torna orientação indefinida.

[D] Resolução: fonte ≥3 células/σ e comprimento de onda≥12 passos próprios conservadores. Planejamento usa banda-proxy ω+4π/duração, não corte rígido; depois mede ω95 apenas em canais relevantes acima de max(Pmax·1e−12,1e−28). Condição angular rmax k95≤.8 Ntheta/2. Downsampling visual nunca melhora o gate físico.

[?] Proveniência: BLOCKED_HISTORICAL_REPLICATION para resultados antigos sem dados brutos; BLOCKED_MISSING_HISTORICAL_GEOMETRY ou BLOCKED_MISSING_HISTORICAL_SOURCE quando arquivos locais necessários estiverem ausentes. A presente entrega contém fontes e alturas, mas não resultados científicos SPIRAL do celular. BLOCKED_NO_VALIDATED_HOLOGRAPHIC_DICTIONARY permanece incondicional nesta bancada.
