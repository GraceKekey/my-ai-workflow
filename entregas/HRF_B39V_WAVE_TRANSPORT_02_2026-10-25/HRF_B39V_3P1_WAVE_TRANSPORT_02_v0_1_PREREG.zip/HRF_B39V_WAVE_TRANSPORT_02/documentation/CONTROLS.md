# Controles adversariais e separação técnica/científica

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[M] Controles algébricos/sintéticos executados: solução nula/RHS; identidades Hamiltonianas recíproco/passivo; volume, gradiente/interpolação P1; assinatura/paridade tensorial; coordenadas e superfícies com medida própria; fluxo radial sem giro, circulação sem Jz, transporte ±z sem espiral; modo angular conhecido e hélice sintética kz=.08; m≠0,kz=0; fases com lacunas e alias; máximos antipodais/nemático; transferência/FOH analítico/sobreamortecimento; hashes, corrupção de chunks, finalização e admission antes da malha.

[M] Referências matemáticas pequenas autorizadas pela solicitação atual: fonte nula; modo estacionário em duas malhas de 729/4913 nós até t=.5; modo discreto de 343 nós até t=.4 para RK4; fonte/curva de energia em 343 nós até t=.4 com/sem receptores recíprocos e sponge; reflexões em 729 nós até t=.4; uma integração de IO de343 nós até t=.32 com interrupção/reinício e17 frames. Não são os presets científicos. Limites estão codificados no helper de testes: ≤4913 nós, ≤1000 passos e tempo≤1.

[D] Resultados/figuras dessas referências ficam exclusivamente em reports/technical_tests/. Testes não executam configs/ nem varreduras científicas. Os presets de null/fonte fixa/paridade/contorno/refinamento físicos grandes continuam NOT_EXECUTED, mesmo quando existe um teste pequeno homônimo.

[D] Para candidatos de transporte são obrigatórios controles feitos na família científica real, com seus dados/contornos/resoluções. Não utilizar o PASS da referência pequena como certificação da malha volumétrica grande. O pipeline de certificação exige arquivos-fonte com hashes e medidas derivadas.

[D] A cobertura de trajetórias foi reforçada antes do congelamento WT-02: curvas interrompidas não sustentam nem candidato nem um resultado negativo resolvido. Um teste injeta perda precoce de todas as curvas e exige INCONCLUSIVE.
