# Equações, ação, convenções e discretização

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[F/M] Assinatura −+++, c=1, geometria estática com N=1 e β=0. Escrevemos

\[
\mathcal A=\int\sqrt{-g}\,[-\tfrac12 g^{ab}\partial_a\phi\partial_b\phi-\tfrac12\mu^2\phi^2+S\phi]d^4x.
\]

A variação dá (□g−μ²)φ=−S. Portanto Sg=−S na convenção covariante da especificação. No plano: φtt−∇²φ+μ²φ=S. Fonte é externa, não um estado de boundary reconstruído.

[F] π=φt; e=½(π²+γij∂iφ∂jφ+μ²φ²), Ji=−πγij∂jφ. Na geometria estática de lapse unitário, ∂t(√γ e)+∂i(√γ Ji)=√γ Sπ, antes de sponge/receptores. No plano, isso reduz ao balanço solicitado.

[M] Matrizes P1: M concentrada por quadratura de vértices de √γ; K gradiente com γ inversa nos centroides e potencial concentrado. Variáveis semidiscretas q=φ e p=M qdot, distintas de π. A carga aplicada é M S nos casos N=1. RK4 usa limite conservador de Gershgorin/CFL e resolve uma malha temporal racional comum às cadências de registro. dt efetivo é registrado, sem alteração posterior de parâmetros físicos.

[D] O código da fonte original tem bases derivadas de gaussianas: x/σxy² e y/σxy². No modo `legacy_discrete`, o par é normalizado por sqrt(Σ(fx²+fy²)/M). No principal WT-02, `continuum_L2` divide por π^(3/4)√σz, mantendo S coordenado igual ao mudar a métrica/domínio/malha. Essa é uma escolha explícita herdada de VVR, não a expressão de fallback x/σxy da especificação; o original está disponível, portanto suas bases foram reaproveitadas. Monopolo usa Gaussiana normalizada por π^(3/4)σxy√σz. Não há fator exp(ikz z).

[M] Receptores recuperados: Xdd+γhist Xdot+Ω²X=−g Cφ. O termo γhist é o coeficiente integral de atrito; não é o γamplitude da equação alternativa 2γamplitude da especificação. Aqui γamplitude=γhist/2. O sinal −g vem do Hamiltoniano H_int=+g X Cφ. No modo recíproco, pdot inclui −CᵀgX; no passivo esse termo é zero e o oscilador não altera o campo. Não usar a fórmula +g/(...+2iγω) para o canal histórico.

[F/M] Hglobal=½pᵀM⁻¹p+½qᵀKq+Σrecip[½v²+½Ω²X²+gXCq]. Energia de sondas passivas é apenas diagnóstica e fica fora desse balanço. Hdot=velᵀf−Σ damp p vel−Σrecip γhist v². Fonte, perdas e H são integrados nos mesmos estágios RK4, evitando erro de quadratura de uma soma posterior.

[M] Densidade local usa média de π² por tetraedro, corrigindo o déficit da média(π)² do observador antigo. Sua integral reproduz a parte de campo de H; interação/receptores pertencem ao ledger global separado. Campos antigos com energia gravada conservam a quadratura antiga, identificada no relatório.

[D] Dirichlet e Neumann homogêneas têm potência externa nula ideal; sponge é amortecimento local quadrático antes da parede Dirichlet. Não é uma fronteira perfeitamente transparente. Largura física fixa de 10 por eixo nos principais; referência baseline usa o perfil anterior 20% do menor comprimento. Reflexões/refluxo e estudos de contorno continuam necessários.
