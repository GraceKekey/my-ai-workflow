# Baseline anterior: informação fornecida e limites da auditoria

**HRF-B39V-3P1-WAVE-TRANSPORT-02 · v0.1 · 25/10/2026 (Brasil)**

**CÓDIGO PREPARADO — PRÉ-REGISTRO — NOVAS SIMULAÇÕES CIENTÍFICAS NÃO EXECUTADAS.**

[M/?] **USER_REPORTED_NOT_INDEPENDENTLY_REPRODUCED.** A execução científica anterior não foi lida dos dados brutos nesta entrega. A tabela abaixo é transcrição da especificação recebida. A existência de código histórico local não substitui os dados científicos da rodada do celular.

Parâmetros reportados: flat, escalar real, x/y ±130, z ±25, 67×67×33, μ=.05, ω=.13, A=.02, σxy=12, σz=10, duração=160, ramp=20, count=3, period=200; dt=.1, t_final=520, observações=.5; sponge=.5; Ωreceptor=1.85, γhist=.1, g=.05; 468 históricos e 576 extras. Classificação `EXPLORATORY_NOT_HISTORICAL_MATCH`.

| Medida informada | splus | sminus |
|---|---:|---:|
| frames | 1041 | 1041 |
| quiralidade média operacional | +.107966586 | −.107966586 |
| torções de fase aceitas | 0 | 0 |
| cristas ambíguas/indefinidas | 1041 | 1041 |
| máximo da fração absoluta de fluxo z líquido | 5.184e−12 | 9.756e−12 |
| assimetria energética máxima | 1.828e−12 | 1.524e−12 |
| disparos | 0 | 0 |

[M/?] Reflexão da potência angular reportada ~3.8e−16. Estado estrutural anterior: `INCONCLUSIVE_SPIRAL_STRUCTURE`. Isso não demonstra transporte helicoidal. Fluxos +z e −z podem cancelar no valor líquido.

[M/?] Ajuste exploratório |kz|~.01177 implica passo formal 2π/|kz|~533, muito maior que a extensão vertical anterior de 50. Não passou o critério de aceitação. Leitura seletiva ~2.46e−11 e limiar ~1.10e−8 são referências fornecidas, não medidas reproduzidas aqui. O catálogo incluído preserva os limiares originais por caso; o valor de G_P é 1.1031300280569998e−8.

[D] Inspeção direta do código confirma: `mode=pulsed` utiliza sin²(πt/duração) somente entre 0 e duração. `count` e `period` só atuam em `pulse_train`; `ramp` atua em `quasi_harmonic`. Assim, três pulsos configurados não significam três pulsos efetivamente emitidos no modo pulsed. `baseline.json` preserva a normalização discreta e a sponge histórica; não é uma recertificação dos resultados indisponíveis.

[?] Não foi certificada a hipótese de dessintonia como causa principal do não disparo. O campo pulsado deve ser medido espectralmente. A geometria plana, domínio vertical curto, cristas degeneradas e ausência de controles de refinamento/fronteira limitam a leitura anterior.

[D] A inconsistência de finalização RUNNING/COMPLETED é preservada em errata da versão anterior. Nesta versão, `run.json` e `case.json` recebem COMPLETED, seguidos de selo `COMPLETION.json`; falhas/interrupções não recebem selo válido. Nenhum histórico foi sobrescrito.
