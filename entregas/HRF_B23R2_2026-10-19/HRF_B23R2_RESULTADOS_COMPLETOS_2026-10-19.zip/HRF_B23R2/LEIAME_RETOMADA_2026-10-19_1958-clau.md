# HRF B23-R2 — estado da rodada e instruções para retomar

**Data:** 19 de outubro de 2026, 19h58 — Claude (`-clau`)

## O que aconteceu

A rodada pré-registrada começou às 17h53 nesta sessão de nuvem (2 núcleos, 7 GB), em dois processos paralelos.
Às 19h53 os dois foram interrompidos pelo limite de 2 h que esta sessão impõe a processos em segundo plano. A
ferramenta não permite relançar processos que já usaram o limite máximo, por isso a rodada precisa ser concluída em
outro ambiente (por exemplo, o que rodou a B25, com 4 CPUs e 32 GB).

**Nada se perdeu:** cada caso concluído está gravado em `resultados/B23aR2_checkpoint.json` e
`resultados/B23bR2_checkpoint.json`. Os casos que estavam em andamento (faixa S = 3, λ = 0,1; β = 2, S = 3) recomeçam
do zero.

## Integridade

Código e protocolo não foram alterados depois dos hashes de 17h53:14. Confira com:
```bash
sed -n '4,10p' hashes_antes_da_execucao.txt | sha256sum -c -
```
`src/figuras_B23R2.py` foi escrito depois do congelamento. Só gera figuras e não entra na decisão.

## Concluído até 19h53

**B23a-R2 (6 de 12 casos principais):**
- cubo S = 1: os 4 λ;
- faixa S = 3: λ = 0,4 e 0,2.

**B23b-R2 (21 casos + referências):**
- β = 0,5: completo, S = 1–12;
- β = 1: completo, S = 1–12;
- β = 2: referência de rotor, S = 1 e S = 2.

## Falta

**B23a-R2:**
- faixa S = 3: λ = 0,1 e 0,05;
- plaqueta S = 4: os 4 λ;
- dois métodos: plaqueta S = 4, faixa S = 3 e cubo S = 1, em λ = 0,1;
- N1 e N3 no cubo.

**B23b-R2:**
- β = 2: S = 3–12;
- β = 3: referência |E| ≤ 10 e S = 1–12;
- truncamento: 8 → 10 em β = 2; 10 → 12 em β = 3;
- âncora.

Tempo estimado num ambiente de 4 CPUs, com os dois blocos em paralelo: 2,5–3 h. Os casos mais caros são S = 12
(~35–40 min por β nas duas representações) e faixa S = 3 (~25–40 min por λ).

## Como retomar (sem alterar nada)

```bash
cd HRF_B23R2
python -I src/rodar_B23R2.py completo b > resultados/log_b_retomada.txt 2>&1 &   # retoma do checkpoint
python -I src/rodar_B23R2.py completo a > resultados/log_a_retomada.txt 2>&1 &
wait
python -I src/avaliar_B23R2.py resultados           # regras congeladas → resultados/avaliacao_B23R2.json
python -I src/figuras_B23R2.py resultados           # opcional, depois da avaliação
```
O orquestrador já fixa 1 thread de BLAS por processo. Não apague nem edite os checkpoints. Registre no relatório a
troca de máquina e as versões de Python, NumPy e SciPy (é um desvio operacional, não de método).

## Resultados parciais (descritivos; NÃO são veredito)

**Cubo S = 1, λ = 0,05:**
- razão δJ = 1,000012; razão do anel = 0,99977 [0,99933; 1,00016];
- gap/2V = 0,938; resíduo 5×10⁻¹⁵;
- anel presente nas 6 faces.

**B23b-R2:**
- discordância entre as duas representações ≤ 4×10⁻¹³ em todos os casos.

| β | D(S) para S = 6, 8, 10, 12 | p(6–12) | D monótono de 2 a 12 |
|---|---|---|---|
| 0,5 | 0,00120 · 0,000704 · 0,000463 · 0,000327 | 1,87 | sim |
| 1 | 0,0147 · 0,00873 · 0,00575 · 0,00407 | 1,85 | sim |

Os 12 valores antigos (S = 1–8) desses dois β reproduzem os da B23R.
