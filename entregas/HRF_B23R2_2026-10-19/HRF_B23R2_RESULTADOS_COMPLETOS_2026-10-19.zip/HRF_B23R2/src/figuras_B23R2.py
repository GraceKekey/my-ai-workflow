# -*- coding: utf-8 -*-
"""Figuras da B23-R2 (feitas DEPOIS da avaliação; não entram na decisão). Uso: python -I figuras_B23R2.py [pasta]"""
import json
import sys
from pathlib import Path

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402

pasta = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "resultados"
cfg = json.load(open(pasta / "B23R2_config.json"))["config"]
B = json.load(open(pasta / "B23bR2_checkpoint.json"))
A = json.load(open(pasta / "B23aR2_checkpoint.json"))

SUP, TXT, TXT2, GRADE = "#fcfcfb", "#0b0b0b", "#52514e", "#e4e3df"
SERIES = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
MARC = ["o", "s", "^", "D"]
plt.rcParams.update({"font.size": 10, "axes.edgecolor": TXT2, "axes.labelcolor": TXT, "xtick.color": TXT2,
                     "ytick.color": TXT2, "axes.titlecolor": TXT, "figure.facecolor": SUP, "axes.facecolor": SUP})

fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 4.8))
# (a) D(S) da B23b-R2
cb = cfg["B23bR2"]
for i, beta in enumerate(cb["betas"]):
    ref = np.array(B["casos"][f"beta={beta}|rotor|Emax={cb['Emax_ref'][str(beta)]}"]["niveis_E"])
    span = ref[-1] - ref[0]
    Ss = np.array(cb["S"])
    D = [np.max(np.abs(np.array(B["casos"][f"beta={beta}|S={S}"]["niveis_E"]) - ref)) / span for S in Ss]
    ax1.loglog(Ss, D, marker=MARC[i], color=SERIES[i], lw=2, ms=7, mec=SUP, mew=1.5, label=f"β = {beta:g}")
x = np.array([6, 12.0])
ax1.loglog(x, 0.5 * (x / 6) ** -2, ls="--", color=TXT2, lw=1)
ax1.text(9.2, 0.5 * (9.2 / 6) ** -2 * 1.25, "inclinação −2", color=TXT2, fontsize=9)
ax1.axvspan(5.6, 12.8, color=GRADE, alpha=0.5, lw=0)
ax1.text(6.0, ax1.get_ylim()[0] * 1.4 if ax1.get_ylim()[0] > 0 else 1e-4, "janela de decisão (S = 6–12)", color=TXT2, fontsize=9)
ax1.set_xlabel("spin S da ligação")
ax1.set_ylabel("desvio espectral D(S) contra o rotor")
ax1.set_title("(a) B23b-R2: ligação quântica → rotor de Wilson (6 faces)", fontsize=11, loc="left")
ax1.set_xticks(cb["S"]); ax1.set_xticklabels([str(s) for s in cb["S"]])
ax1.grid(True, which="major", color=GRADE, lw=0.8); ax1.legend(frameon=False, labelcolor=TXT)
for s in ("top", "right"):
    ax1.spines[s].set_visible(False)
# (b) B23a-R2: desvio da razão do anel
ca = cfg["B23aR2"]
lams = np.array(ca["lambdas"])
for i, (nome, S) in enumerate(ca["casos"]):
    dev = [abs(A["casos"][f"{nome}|S={S}|lambda={l}"]["razao_anel_media"] - 1) for l in lams]
    ax2.loglog(lams, dev, marker=MARC[i], color=SERIES[i], lw=2, ms=7, mec=SUP, mew=1.5, label=f"{nome} S = {S}")
ax2.loglog(lams, 0.6 * lams ** 2, ls="--", color=TXT2, lw=1)
ax2.text(0.11, 0.6 * 0.11 ** 2 * 0.55, "∝ λ²", color=TXT2, fontsize=9)
ax2.set_xlabel("λ = Γ√(S(S+1))/V")
ax2.set_ylabel("|razão do anel − 1| (medido / previsto)")
ax2.set_title("(b) B23a-R2: anel de Wilson emergente", fontsize=11, loc="left")
ax2.grid(True, which="major", color=GRADE, lw=0.8); ax2.legend(frameon=False, labelcolor=TXT)
for s in ("top", "right"):
    ax2.spines[s].set_visible(False)
fig.tight_layout()
fig.savefig(pasta / "B23R2_figuras.png", dpi=150)
print("figura gravada")
