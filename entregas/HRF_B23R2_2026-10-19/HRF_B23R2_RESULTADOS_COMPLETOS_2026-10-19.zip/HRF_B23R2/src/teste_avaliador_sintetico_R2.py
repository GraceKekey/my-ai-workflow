# -*- coding: utf-8 -*-
"""Teste do avaliador da B23-R2 com dados SINTÉTICOS (inventados): só verifica que as regras rodam e que os ramos
de decisão são alcançáveis. Uso: python -I teste_avaliador_sintetico_R2.py"""
import sys
from pathlib import Path
import numpy as np
sys.path.insert(0, str(Path(__file__).resolve().parent))
import avaliar_B23R2 as AV  # noqa: E402

CA = {"casos": [["cubo", 1], ["faixa", 3], ["plaqueta", 4]], "lambdas": [0.4, 0.2, 0.1, 0.05],
      "dois_metodos": [["cubo", 1, 0.1]], "N1": ["cubo", 1, 0.1], "N3": ["cubo", 1, 0.1, 1]}
CB = {"betas": [0.5, 1.0, 2.0, 3.0], "S": [1, 2, 3, 4, 6, 8, 10, 12], "Emax_ref": {"0.5": 8, "1.0": 8, "2.0": 8, "3.0": 10}}


def fake_a(r5=0.999, dm=1e-12):
    casos = {}
    for nome, S in CA["casos"]:
        for lam in CA["lambdas"]:
            r = 1 - (1 - r5) * (lam / 0.05) ** 2
            casos[f"{nome}|S={S}|lambda={lam}"] = {"residuo_real": 1e-15, "g_min_sobreposicao": 0.99, "gap_sobre_2V": 0.9,
                                                   "razao_dJ": r, "razao_anel_media": r, "razao_anel_min": r - 1e-4,
                                                   "razao_anel_max": r + 1e-4, "residuo_fora_de_aneis_sobre_escala": 0.01,
                                                   "faces": {str(f): {"frustrado": False, "movimentos": 4} for f in range(6)}}
    ctl = {"dois_metodos|cubo|S=1|lambda=0.1": {"dif_banda": dm, "dif_razoes": dm},
           "N1|cubo|S=1|lambda=0.1": {"dif_banda": 0.0},
           "N3|cubo|S=1|lambda=0.1": {"lacos_frustrados": 2, "faces": {"0": {"frustrado": True}, "1": {"frustrado": False, "razao_media": 0.99}}}}
    return {"casos": casos, "controles": ctl}


def fake_b(p=2.0, disc=0.0):
    casos, ctl = {}, {}
    for beta in CB["betas"]:
        ref = np.linspace(-5, 5, 10)
        casos[f"beta={beta}|rotor|Emax={CB['Emax_ref'][str(beta)]}"] = {"niveis_E": ref.tolist(), "niveis_H": ref.tolist(),
            "discordancia_E_H": disc, "residuo_E": 1e-13, "residuo_H": 1e-13, "transicoes_por_face_E": [5] * 6, "transicoes_por_face_H": [5] * 6}
        for S in CB["S"]:
            niv = ref + 10 * 0.1 * beta / S ** p
            casos[f"beta={beta}|S={S}"] = {"niveis_E": niv.tolist(), "niveis_H": niv.tolist(), "discordancia_E_H": disc,
                                           "residuo_E": 1e-13, "residuo_H": 1e-13, "transicoes_por_face_E": [5] * 6, "transicoes_por_face_H": [5] * 6}
    ctl["truncamento|x"] = {"dif_relativa": 1e-12}; ctl["ancora|x"] = {"pior_diferenca": 0.0}
    return {"casos": casos, "controles": ctl}


print("a:", AV.avaliar_a(fake_a(), CA)["decisao"], "|", AV.avaliar_a(fake_a(r5=0.7), CA)["decisao"], "|",
      AV.avaliar_a(fake_a(dm=1e-6), CA)["decisao"], "|", AV.avaliar_a(fake_a(r5=0.95), CA)["decisao"])
print("b:", AV.avaliar_b(fake_b(), CB)["decisao"], "|", AV.avaliar_b(fake_b(p=1.0), CB)["decisao"], "|",
      AV.avaliar_b(fake_b(p=-0.2), CB)["decisao"], "|", AV.avaliar_b(fake_b(disc=1e-6), CB)["decisao"])
