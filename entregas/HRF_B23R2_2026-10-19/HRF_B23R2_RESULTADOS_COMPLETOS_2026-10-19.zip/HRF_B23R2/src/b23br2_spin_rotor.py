# -*- coding: utf-8 -*-
"""
HRF B23b-R2 — cubo fechado com as SEIS plaquetas: ligação quântica de spin S → rotor de Wilson.

Duas representações independentes do mesmo Hamiltoniano (têm de coincidir):
  rep E  : estados = fluxos E nas 12 ligações (setor sem cargas); o anel da face f leva E → E + d1[f]; o alvo é
           procurado pela chave E. Nenhuma face é especial.
  rep H  : estados = alturas de face n (n_âncora = 0, E = d1ᵀn); face f ≠ âncora: n_f → n_f + 1; face âncora:
           n_g → n_g − 1 para todo g ≠ âncora (porque Σ_f d1[f] = 0 na superfície fechada).
H = δJ Σ E² − (K/2) Σ_f (T_f R_f + h.c.); rotor: R = 1; spin S: R = Π √(S(S+1) − m(m±1))/√(S(S+1)), |E| ≤ S.
Autossolver congelado: denso se dim ≤ 5000; senão Lanczos (eigsh) com 24 autovalores, subespaço de 96, tol 1e-12;
semente 20262325 na rep E e 20262326 na rep H; resíduo de Ritz explícito dos 10 níveis.
"""
from __future__ import annotations

import json
import math
import os
import time

import numpy as np
import scipy.linalg as sl
import scipy.sparse as sp
import scipy.sparse.linalg as spl

import b23_modelo as M

N_NIVEIS = 10
DENSO_ATE = 5000


def cubo_ancorado(ancora):
    cx = M.cubo()
    ordem = [ancora] + [f for f in range(cx.F) if f != ancora]
    cx.d1 = cx.d1[ordem, :].copy()
    cx.faces = [cx.faces[f] for f in ordem]
    assert not np.any(cx.d1 @ cx.d0) and not np.any(cx.d1.sum(0))
    return cx


def _fator(S, Em, sinais):
    if S is None:
        return np.ones(len(Em))
    return np.prod(np.sqrt(np.maximum(S * (S + 1) - Em * (Em + sinais), 0.0)) / math.sqrt(S * (S + 1)), axis=1)


def _monta(D, diag, blocos):
    rows = np.concatenate([b[0] for b in blocos]); cols = np.concatenate([b[1] for b in blocos])
    vals = np.concatenate([b[2] for b in blocos])
    T = sp.coo_matrix((vals, (rows, cols)), shape=(D, D)).tocsr()
    return (sp.diags(diag) + T + T.T).tocsr()


def h_rep_E(cx, Ev, dJ, K, S):
    D = len(Ev)
    Ev = Ev.astype(np.int64)
    Bm = int(np.abs(Ev).max())
    base = 2 * Bm + 3                         # cabe E + d1 ∈ [−B−1, B+1] sem aliasing; base^12 < 2^63 para B ≤ 12
    assert float(base) ** cx.E < 2.0 ** 62
    pesos = base ** np.arange(cx.E, dtype=np.int64)
    ch = (Ev + Bm + 1) @ pesos
    ordem = np.argsort(ch); cho = ch[ordem]
    blocos, cont = [], []
    for f in range(cx.F):
        dl = cx.d1[f].astype(np.int64)
        alvo = (Ev + dl + Bm + 1) @ pesos
        pos = np.minimum(np.searchsorted(cho, alvo), D - 1)
        ok = cho[pos] == alvo
        i = np.nonzero(ok)[0]; j = ordem[pos[ok]]
        es = np.nonzero(dl)[0]
        amp = _fator(S, Ev[i][:, es].astype(float), dl[es].astype(float)[None, :])
        blocos.append((j, i, -(K / 2) * amp)); cont.append(int(len(i)))
    return _monta(D, dJ * (Ev.astype(float) ** 2).sum(1), blocos), cont


def h_rep_H(cx, n, Ev, dJ, K, S):
    D, F = n.shape
    n = n.astype(np.int64)
    pesos = (8 * 64 + 1) ** np.arange(F, dtype=np.int64)
    ch = (n + 256) @ pesos
    ordem = np.argsort(ch); cho = ch[ordem]
    blocos, cont = [], []
    for f in range(F):
        desl = np.zeros(F, np.int64)
        if f == 0:
            desl[1:] = -1                      # face âncora
        else:
            desl[f] = 1
        alvo = (n + desl + 256) @ pesos
        pos = np.minimum(np.searchsorted(cho, alvo), D - 1)
        ok = cho[pos] == alvo
        i = np.nonzero(ok)[0]; j = ordem[pos[ok]]
        dl = cx.d1[f].astype(np.int64)
        es = np.nonzero(dl)[0]
        assert np.array_equal(Ev[j] - Ev[i], np.broadcast_to(dl, (len(i), cx.E))), "anel não soma d1[f]"
        amp = _fator(S, Ev[i][:, es].astype(float), dl[es].astype(float)[None, :])
        blocos.append((j, i, -(K / 2) * amp)); cont.append(int(len(i)))
    return _monta(D, dJ * (Ev.astype(float) ** 2).sum(1), blocos), cont


def niveis(H, semente):
    D = H.shape[0]
    if D <= DENSO_ATE:
        w, V = sl.eigh(H.toarray())
    else:
        w, V = spl.eigsh(H, k=24, which="SA", tol=1e-12, ncv=96, v0=np.random.default_rng(semente).normal(size=D))
        o = np.argsort(w); w, V = w[o], V[:, o]
    w, V = w[:N_NIVEIS], V[:, :N_NIVEIS]
    res = float(np.max(np.linalg.norm(H @ V - V * w, axis=0)))
    return w, res


class Caderno:
    """Checkpoint atômico depois de cada caso."""

    def __init__(self, caminho):
        self.caminho = caminho
        self.dados = json.load(open(caminho)) if os.path.exists(caminho) else {"casos": {}, "controles": {}}

    def tem(self, chave, grupo="casos"):
        return chave in self.dados[grupo]

    def grava(self, chave, valor, grupo="casos"):
        self.dados[grupo][chave] = valor
        tmp = self.caminho + ".tmp"
        json.dump(self.dados, open(tmp, "w"), ensure_ascii=False, indent=1)
        os.replace(tmp, self.caminho)


def caso_duplo(cx, B, dJ, K, S):
    """Mesmo Hamiltoniano nas duas representações; devolve níveis, resíduos, contagens e a discordância."""
    t0 = time.time()
    n, Ev = M.base_fluxos_cubo(cx, B)
    HE, cE = h_rep_E(cx, Ev, dJ, K, S)
    wE, rE = niveis(HE, 20262325)
    del HE
    HH, cH = h_rep_H(cx, n, Ev, dJ, K, S)
    wH, rH = niveis(HH, 20262326)
    del HH
    return {"dim": int(len(n)), "niveis_E": wE.tolist(), "niveis_H": wH.tolist(),
            "discordancia_E_H": float(np.max(np.abs(wE - wH))), "residuo_E": rE, "residuo_H": rH,
            "transicoes_por_face_E": cE, "transicoes_por_face_H": cH, "segundos": round(time.time() - t0, 1)}


def rodar(cfg, pasta):
    cad = Caderno(os.path.join(pasta, "B23bR2_checkpoint.json"))
    cx = cubo_ancorado(0)
    dJ = 1.0
    for beta in cfg["betas"]:
        K = 2 * beta ** 2 * dJ
        Eref = cfg["Emax_ref"][str(beta)]
        ch = f"beta={beta}|rotor|Emax={Eref}"
        if not cad.tem(ch):
            cad.grava(ch, {"beta": beta, "S": None, "Emax": Eref, **caso_duplo(cx, Eref, dJ, K, None)})
        print(f"  B23b-R2 β={beta} rotor |E|≤{Eref}: dim={cad.dados['casos'][ch]['dim']} "
              f"disc={cad.dados['casos'][ch]['discordancia_E_H']:.1e} ({cad.dados['casos'][ch]['segundos']} s)", flush=True)
        for S in cfg["S"]:
            ch = f"beta={beta}|S={S}"
            if not cad.tem(ch):
                cad.grava(ch, {"beta": beta, "S": S, **caso_duplo(cx, S, dJ, K, S)})
            c = cad.dados["casos"][ch]
            print(f"  B23b-R2 β={beta} S={S}: dim={c['dim']} disc={c['discordancia_E_H']:.1e} "
                  f"res={max(c['residuo_E'], c['residuo_H']):.1e} ({c['segundos']} s)", flush=True)
    # controles de truncamento (só rep E)
    for beta, Ea, Eb in cfg["truncamento"]:
        ch = f"truncamento|beta={beta}|{Ea}->{Eb}"
        if not cad.tem(ch, "controles"):
            K = 2 * beta ** 2 * dJ
            n, Ev = M.base_fluxos_cubo(cx, Eb)
            w, r = niveis(h_rep_E(cx, Ev, dJ, K, None)[0], 20262327)
            ref = np.array(cad.dados["casos"][f"beta={beta}|rotor|Emax={Ea}"]["niveis_E"])
            cad.grava(ch, {"beta": beta, "Emax_a": Ea, "Emax_b": Eb, "dim_b": int(len(n)), "residuo": r,
                           "dif_relativa": float(np.max(np.abs(w - ref)) / (ref[-1] - ref[0]))}, "controles")
        print(f"  B23b-R2 truncamento β={beta} {Ea}→{Eb}: {cad.dados['controles'][ch]['dif_relativa']:.1e}", flush=True)
    # controle de âncora (rep H com as 6 âncoras)
    for S in cfg["ancora_S"]:
        ch = f"ancora|S={S}|beta={cfg['ancora_beta']}"
        if not cad.tem(ch, "controles"):
            K = 2 * cfg["ancora_beta"] ** 2 * dJ
            ws = []
            for a in range(6):
                c2 = cubo_ancorado(a)
                n, Ev = M.base_fluxos_cubo(c2, S)
                ws.append(niveis(h_rep_H(c2, n, Ev, dJ, K, S)[0], 20262326)[0])
            cad.grava(ch, {"pior_diferenca": float(max(np.max(np.abs(w - ws[0])) for w in ws))}, "controles")
        print(f"  B23b-R2 âncora S={S}: {cad.dados['controles'][ch]['pior_diferenca']:.1e}", flush=True)
    return cad.dados
