# -*- coding: utf-8 -*-
"""
HRF B23-R2 — orquestrador.  Uso:  python -I rodar_B23R2.py fumaca|completo  a|b|config  [pasta]
  a: B23a-R2 (emergência nos aglomerados grandes)   b: B23b-R2 (spin → rotor, seis faces)   config: só grava a config
Os dois blocos rodam em processos separados (um por núcleo), com checkpoint por caso.
"""
from __future__ import annotations

import json
import os
import platform
import sys
import time
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

AQUI = Path(__file__).resolve().parent
sys.path.insert(0, str(AQUI))

import numpy as np   # noqa: E402
import scipy         # noqa: E402

CONFIG = {
    "completo": {
        "B23aR2": {"casos": [["cubo", 1], ["faixa", 3], ["plaqueta", 4]], "lambdas": [0.4, 0.2, 0.1, 0.05],
                   "dois_metodos": [["plaqueta", 4, 0.1], ["faixa", 3, 0.1], ["cubo", 1, 0.1]],
                   "N1": ["cubo", 1, 0.1], "N3": ["cubo", 1, 0.1, 20262327]},
        "B23bR2": {"betas": [0.5, 1.0, 2.0, 3.0], "S": [1, 2, 3, 4, 6, 8, 10, 12],
                   "Emax_ref": {"0.5": 8, "1.0": 8, "2.0": 8, "3.0": 10},
                   "truncamento": [[2.0, 8, 10], [3.0, 10, 12]], "ancora_S": [1, 2], "ancora_beta": 1.0},
    },
    "fumaca": {
        "B23aR2": {"casos": [["plaqueta", 1], ["faixa", 1]], "lambdas": [0.4, 0.2, 0.1, 0.05],
                   "dois_metodos": [["plaqueta", 1, 0.1], ["faixa", 1, 0.1]],
                   "N1": ["plaqueta", 1, 0.1], "N3": ["faixa", 1, 0.1, 20262327]},
        "B23bR2": {"betas": [1.0], "S": [1, 2, 3], "Emax_ref": {"1.0": 3}, "truncamento": [[1.0, 3, 4]],
                   "ancora_S": [1], "ancora_beta": 1.0},
    },
}


def main():
    modo, bloco = sys.argv[1], sys.argv[2]
    pasta = Path(sys.argv[3]) if len(sys.argv) > 3 else AQUI.parent / ("fumaca" if modo == "fumaca" else "resultados")
    pasta.mkdir(parents=True, exist_ok=True)
    cfg = CONFIG[modo]
    if bloco == "config":
        meta = {"modo": modo, "gravado": time.strftime("%Y-%m-%d %H:%M:%S"), "python": platform.python_version(),
                "numpy": np.__version__, "scipy": scipy.__version__, "maquina": platform.platform(), "nucleos": os.cpu_count()}
        json.dump({"meta": meta, "config": cfg}, open(pasta / "B23R2_config.json", "w"), ensure_ascii=False, indent=1)
        return
    t0 = time.time()
    print(f"HRF B23-R2 — modo {modo} — bloco {bloco} — {time.strftime('%Y-%m-%d %H:%M:%S')}", flush=True)
    if bloco == "a":
        import b23ar2_emergencia as A
        A.rodar(cfg["B23aR2"], str(pasta))
    elif bloco == "b":
        import b23br2_spin_rotor as B
        B.rodar(cfg["B23bR2"], str(pasta))
    print(f"fim bloco {bloco} — {round(time.time() - t0, 1)} s — {time.strftime('%Y-%m-%d %H:%M:%S')}", flush=True)


if __name__ == "__main__":
    main()
