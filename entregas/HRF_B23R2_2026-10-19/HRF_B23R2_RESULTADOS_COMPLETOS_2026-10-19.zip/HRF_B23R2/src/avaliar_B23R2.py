# -*- coding: utf-8 -*-
"""
HRF B23-R2 — avaliador com as regras PRÉ-REGISTRADAS (escrito antes da rodada completa).
Uso: python -I avaliar_B23R2.py [pasta]  →  avaliacao_B23R2.json
"""
from __future__ import annotations

import json
import sys
from pathlib import Path

import numpy as np

# D(S) de referência da B23R (oficial para β = 1 e 2; auditoria espectral para β = 0,5) — recertificação, não decisão
D_B23R = {"0.5": {"1": 0.020076372918666794, "2": 0.0076649327592556, "3": 0.004029454748982513, "4": 0.002471856587021018,
                  "6": 0.0011987881290539486, "8": 0.0007042923589676645},
          "1.0": {"1": 0.1775462460421482, "2": 0.08486451791552387, "3": 0.04732165782033851, "4": 0.0297635838993894,
                  "6": 0.014732876792729482, "8": 0.008724936926987678},
          "2.0": {"1": 0.7338197706415933, "2": 0.44076996546956937, "3": 0.27964240078129476, "4": 0.1962494118992079,
                  "6": 0.10460495102104418, "8": 0.06321644274197014}}


def inclinacao(xs, ys):
    return float(np.polyfit(np.log(np.asarray(xs, float)), np.log(np.abs(np.asarray(ys, float))), 1)[0])


# ----------------------------------------------------------------------------- B23b-R2
def avaliar_b(dados, cfg):
    casos, ctl = dados["casos"], dados["controles"]
    V_disc = max(c["discordancia_E_H"] for c in casos.values())
    V_res = max(max(c["residuo_E"], c["residuo_H"]) for c in casos.values())
    V_faces = all(min(c["transicoes_por_face_E"]) > 0 and len(set(c["transicoes_por_face_E"])) == 1 and
                  c["transicoes_por_face_E"] == c["transicoes_por_face_H"] for c in casos.values())
    V_trunc = max(v["dif_relativa"] for k, v in ctl.items() if k.startswith("truncamento"))
    V_anc = max(v["pior_diferenca"] for k, v in ctl.items() if k.startswith("ancora"))
    valido = V_disc <= 1e-9 and V_res <= 1e-9 and V_faces and V_trunc <= 1e-8 and V_anc <= 1e-9
    por_beta, recert = {}, {}
    mono_ok = ordem_ok = True
    grosso = False
    for beta in cfg["betas"]:
        ref = np.array(casos[f"beta={beta}|rotor|Emax={cfg['Emax_ref'][str(beta)]}"]["niveis_E"])
        span = ref[-1] - ref[0]
        D = {S: float(np.max(np.abs(np.array(casos[f"beta={beta}|S={S}"]["niveis_E"]) - ref)) / span) for S in cfg["S"]}
        Ss = [2, 3, 4, 6, 8, 10, 12]
        mono = all(D[Ss[i]] > D[Ss[i + 1]] for i in range(len(Ss) - 1))
        p = -inclinacao([6, 8, 10, 12], [D[s] for s in (6, 8, 10, 12)])
        p_antigo = -inclinacao([3, 4, 6, 8], [D[s] for s in (3, 4, 6, 8)])
        if D[12] >= D[6]:
            grosso = True
        mono_ok &= mono
        ordem_ok &= p >= 1.5
        por_beta[str(beta)] = {"D": {str(k): v for k, v in D.items()}, "monotono_2_a_12": mono, "p_6_a_12": p,
                               "p_3_a_8": p_antigo}
        b = f"{float(beta)}"
        if b in D_B23R:
            recert[b] = max(abs(D[int(s)] - v) for s, v in D_B23R[b].items())
    if not valido:
        dec = "INCONCLUSIVO"
    elif grosso:
        dec = "NÃO CONVERGE"
    elif mono_ok and ordem_ok:
        dec = "CONVERGE_6F"
    else:
        dec = "PARCIAL"
    return {"decisao": dec, "validade": {"discordancia_E_H_max": V_disc, "residuo_max": V_res, "seis_faces_iguais": V_faces,
                                         "truncamento_max": V_trunc, "ancora_max": V_anc, "valido": valido},
            "por_beta": por_beta, "recertificacao_B23R_max_dif": recert,
            "recertificado": all(v <= 1e-8 for v in recert.values())}


# ----------------------------------------------------------------------------- B23a-R2
def avaliar_a(dados, cfg):
    casos, ctl = dados["casos"], dados["controles"]
    por, A0 = {}, True
    A1 = A2 = A3 = A4 = F6 = True
    grosso = False
    for nome, S in cfg["casos"]:
        cs = {lam: casos[f"{nome}|S={S}|lambda={lam}"] for lam in cfg["lambdas"]}
        a0 = all(c["residuo_real"] <= 1e-8 and c["g_min_sobreposicao"] >= 0.5 for l, c in cs.items() if l <= 0.2)
        a1 = all(c["gap_sobre_2V"] >= 0.5 for l, c in cs.items() if l <= 0.2)
        c5 = cs[0.05]
        a2 = (abs(c5["razao_dJ"] - 1) <= 0.03 and abs(c5["razao_anel_media"] - 1) <= 0.03 and
              (c5["razao_anel_max"] - c5["razao_anel_min"]) <= 0.03)
        ls = [0.2, 0.1, 0.05]
        dK = [abs(cs[l]["razao_anel_media"] - 1) for l in ls]
        dJ = [abs(cs[l]["razao_dJ"] - 1) for l in ls]
        pK = inclinacao(ls, dK) if max(dK) >= 1e-7 else float("inf")
        pJ = inclinacao(ls, dJ) if max(dJ) >= 1e-7 else float("inf")
        a3 = pK >= 1.5 and pJ >= 1.5
        a4 = c5["residuo_fora_de_aneis_sobre_escala"] <= 0.05
        f6 = all((not v["frustrado"]) and v["movimentos"] > 0 for v in c5["faces"].values())
        if not (0.8 <= c5["razao_anel_media"] <= 1.2 and 0.8 <= c5["razao_dJ"] <= 1.2):
            grosso = True
        A0 &= a0; A1 &= a1; A2 &= a2; A3 &= a3; A4 &= a4; F6 &= f6
        por[f"{nome} S={S}"] = {"A0": a0, "A1": a1, "A2": a2, "A3": a3, "A4": a4, "todos_os_lacos_com_anel": f6,
                                "razao_dJ_0.05": c5["razao_dJ"], "razao_anel_0.05": c5["razao_anel_media"],
                                "ordem_anel": pK, "ordem_dJ": pJ, "residuo_fora_0.05": c5["residuo_fora_de_aneis_sobre_escala"]}
    dm = [v for k, v in ctl.items() if k.startswith("dois_metodos")]
    DM = all(v["dif_banda"] <= 1e-9 and v["dif_razoes"] <= 1e-9 for v in dm) and len(dm) == len(cfg["dois_metodos"])
    n1 = [v for k, v in ctl.items() if k.startswith("N1")][0]
    N1 = n1["dif_banda"] <= 1e-9
    n3 = [v for k, v in ctl.items() if k.startswith("N3")][0]
    livres = [v["razao_media"] for v in n3["faces"].values() if not v["frustrado"]]
    N3 = n3["lacos_frustrados"] >= 1 and len(livres) >= 1 and all(0.9 <= x <= 1.1 for x in livres)
    if not (A0 and DM):
        dec = "INCONCLUSIVO"
    elif grosso:
        dec = "NÃO EMERGE"
    elif A1 and A2 and A3 and A4 and F6 and N1 and N3:
        dec = "EMERGE"
    else:
        dec = "PARCIAL"
    return {"decisao": dec, "A0": A0, "A1": A1, "A2": A2, "A3": A3, "A4": A4, "todos_os_lacos": F6,
            "dois_metodos": DM, "N1": N1, "N3": N3, "N3_razoes_livres": livres, "por_caso": por}


def main():
    pasta = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(__file__).resolve().parent.parent / "resultados"
    cfg = json.load(open(pasta / "B23R2_config.json"))["config"]
    a = avaliar_a(json.load(open(pasta / "B23aR2_checkpoint.json")), cfg["B23aR2"])
    b = avaliar_b(json.load(open(pasta / "B23bR2_checkpoint.json")), cfg["B23bR2"])
    if "INCONCLUSIVO" in (a["decisao"], b["decisao"]):
        geral = "INCONCLUSIVA"
    elif a["decisao"] == "NÃO EMERGE" or b["decisao"] == "NÃO CONVERGE":
        geral = "REFUTADA"
    elif a["decisao"] == "EMERGE" and b["decisao"] == "CONVERGE_6F":
        geral = "CORRESPONDÊNCIA CONFIRMADA NA REDE REGULAR"
    else:
        geral = "PARCIAL"
    out = {"B23_R2": geral, "B23aR2": a, "B23bR2": b,
           "nota": "B23c (dinâmica clássica) não é refeita aqui: EQUIVALENTE na execução externa do código congelado."}
    json.dump(out, open(pasta / "avaliacao_B23R2.json", "w"), ensure_ascii=False, indent=1, default=str)
    print(json.dumps({"B23-R2": geral, "B23a-R2": a["decisao"], "B23b-R2": b["decisao"]}, ensure_ascii=False))


if __name__ == "__main__":
    main()
