# Resultados B23-R2

Leia RELATORIO_CIENTIFICO_B23R2.md e resultados/avaliacao_B23R2.json.

Para retomar/reproduzir use o protocolo original, uma thread BLAS por processo e os scripts congelados. O ZIP original e os checkpoints recebidos estão preservados; os resultados finais combinam a execução anterior e esta retomada. Remova os checkpoints somente em uma cópia separada se desejar refazer todos os casos.
