# HRF B23-R2 — Levin–Wen → Wilson na rede regular: cubo completo e convergência spin → rotor com seis faces
## Protocolo pré-registrado

**Data:** 19 de outubro de 2026, 17h53 (America/Sao_Paulo) — Claude (`-clau`) · fluxo ímpar
**Autorização:** Mario, 17h28: "Pode rodar a B23 nova". Protocolo, código e hashes são congelados **antes** da rodada
completa, que começa logo depois do congelamento.
**Antecedentes:** B23 (pré-registro 11h05); execução parcial externa e auditoria (face f0); B23R externa (B23a-R reduzida,
B23b-R com seis faces); a minha auditoria independente (`HRF_B23_Auditoria_Independente_Pacotes_Externos_PT_2026-10-19_1715-clau.md`).

Marcas: [F] estabelecido · [M] toy model/bancada · [H] hipótese HRF · [?] aberto · [D] decisão.

---

## 1. Objetivo

Fechar as duas lacunas quânticas da B23:

| Bloco | O que falta | O que esta bancada faz |
|---|---|---|
| **B23a-R2** | espectro exato dos aglomerados grandes (nunca completado) | cubo S = 1, faixa S = 3, plaqueta S = 4, com os critérios da B23a; inclui o primeiro espectro exato do cubo com as 6 faces |
| **B23b-R2** | convergência spin → rotor com as 6 faces, com autossolver robusto congelado | refaz os 18 pares (recertificação, não cega) e acrescenta casos **nunca calculados**: S = 10, 12 e β = 3 (parte cega) |

A B23c (dinâmica clássica) não é refeita: deu EQUIVALENTE na execução externa do código congelado.

## 2. Hipóteses e previsões (escritas antes)

**B23a-R2.**
- Em λ = 0,05, as razões δJ e anel ficam a ≤ 0,3% de 1 também no cubo e na faixa S = 3, como nos aglomerados
  pequenos. No cubo, as **seis** faces têm o anel previsto (−5/32 Γ⁴/V³ · Π√(…)).
- As correções caem como λ².

**B23b-R2.**
- D(S) decresce de S = 2 a 12 nos quatro β.
- O expoente na janela nova S = 6–12 é ≥ 1,5 em todos os β e se aproxima de 2. β = 3 é o mais lento (pré-assintótico).
- Estimativa para orientar, não critério: D(12) em β = 2 ≈ 0,03.

## 3. Parâmetros

**B23a-R2.**
- Casos: cubo S = 1 (12 ligações, 531 441 estados, setor sem cargas com 69), faixa S = 3 (823 543; 37) e plaqueta S = 4
  (6 561; 9), com λ ∈ {0,4; 0,2; 0,1; 0,05}, V = 1, δJ₀ = 0.
- Dois métodos (LOBPCG × Chebyshev): plaqueta S = 4, faixa S = 3 e cubo S = 1, sempre em λ = 0,1.
- N1 (sem sinal × assinado): cubo S = 1, λ = 0,1.
- N3 (sinais aleatórios, ≥ 1 laço frustrado e ≥ 1 livre): cubo S = 1, λ = 0,1, primeira semente ≥ 20262327.

**B23b-R2.**
- β ∈ {0,5; 1; 2; 3}, δJ = 1, K = 2β²; S ∈ {1, 2, 3, 4, 6, 8, 10, 12}.
- Rotor de referência: |E| ≤ 8 para β ≤ 2 e |E| ≤ 10 para β = 3.
- Controles de truncamento: 8 → 10 em β = 2; 10 → 12 em β = 3.
- Controle de âncora: as 6 âncoras, S = 1 e 2, β = 1.

## 4. Protocolo

1. `python -I src/rodar_B23R2.py completo config`, depois `… completo b` e `… completo a` em **dois processos
   paralelos** (um por núcleo; BLAS com 1 thread). Checkpoint atômico depois de cada caso. Se um processo for
   interrompido, relança-se o mesmo comando, que retoma do checkpoint sem refazer casos.
2. `python -I src/avaliar_B23R2.py resultados` → `resultados/avaliacao_B23R2.json`.
3. Relatório na ordem Objetivo → Hipóteses → Parâmetros → Protocolo → Medidas → Resultados → Controles →
   Interpretação.

**B23a-R2.** Modelo e análise do `b23_modelo.py` original (cópia idêntica, SHA-256 `eaa1e749…`): H = VΣQ² − ΓΣS^x,
banda baixa e Hamiltoniano efetivo exato de des Cloizeaux.
- Autossolver primário: o da B23 (denso até 7 000 estados; acima, Chebyshev semeado no setor sem cargas).
- **Correção:** o resíduo é medido também no caminho denso.
- Segundo método: LOBPCG com pré-condicionador diagonal; o nível acima da banda vem de Lanczos com deflação.

**B23b-R2.** Duas representações independentes do mesmo Hamiltoniano:
- **rep E:** fluxos nas 12 ligações; o anel leva E → E + d₁[f]; nenhuma face é especial;
- **rep H:** alturas de face com âncora; a face âncora desloca as outras 5 alturas em −1.

Autossolver congelado:
- denso se dim ≤ 5 000;
- senão Lanczos com 24 autovalores, subespaço de 96, tol 10⁻¹², sementes 20262325 (rep E) e 20262326 (rep H);
- resíduo de Ritz explícito dos 10 níveis.

D(S) = max_i |E_i(S) − E_i(rotor)| / (E₉ − E₀)(rotor), calculado com a rep E.

## 5. Medidas

- **B23a-R2:** razão δJ, razão do anel (média, mín., máx.), resíduo fora dos anéis, gap/2V, g_min, resíduo real,
  anel presente em cada face, diferenças entre os dois métodos (banda e razões).
- **B23b-R2:** níveis nas duas representações e sua discordância, resíduos, transições por face, D(S), monotonia,
  expoente p na janela 6–12 (decisão) e 3–8 (relato), truncamento, âncora, recertificação contra a B23R.

## 6. Regras de decisão (congeladas; `src/avaliar_B23R2.py`)

**B23a-R2.**
- A0: resíduo real ≤ 10⁻⁸ e g_min ≥ 0,5 para λ ≤ 0,2.
- A1: gap/2V ≥ 0,5 para λ ≤ 0,2.
- A2 (λ = 0,05): |razão − 1| ≤ 0,03 para δJ e anel; espalhamento do anel ≤ 0,03.
- A3: ordem ≥ 1,5 para δJ e anel em λ ∈ {0,2; 0,1; 0,05}.
- A4 (λ = 0,05): resíduo fora dos anéis ≤ 0,05.
- F6: todos os laços (6 no cubo) com elementos de anel.
- DM: os dois métodos concordam a ≤ 10⁻⁹ (banda e razões).
- N1: |Δbanda| ≤ 10⁻⁹.
- N3: ≥ 1 laço frustrado, ≥ 1 livre, razões dos livres em [0,9; 1,1].

Decisões:
- **INCONCLUSIVO** se A0 ou DM falham;
- **NÃO EMERGE** se alguma razão em λ = 0,05 cair fora de [0,8; 1,2];
- **EMERGE** se A1–A4, F6, N1 e N3 passam;
- **PARCIAL** nos outros casos.

**B23b-R2.** Validade (se falhar: **INCONCLUSIVO**):
- discordância E × H ≤ 10⁻⁹;
- resíduos ≤ 10⁻⁹;
- transições por face > 0, iguais nas 6 faces e nas duas representações;
- truncamento ≤ 10⁻⁸;
- âncora ≤ 10⁻⁹.

Decisões:
- **CONVERGE_6F** se, em todos os β, D decresce estritamente em S = 2, 3, 4, 6, 8, 10, 12 e p(6–12) ≥ 1,5;
- **NÃO CONVERGE** se D(12) ≥ D(6) em algum β;
- **PARCIAL** nos outros casos.

Recertificação (relato, não decisão): os 18 D da B23R (auditados em β = 0,5; oficiais em β = 1, 2) reproduzidos a ≤ 10⁻⁸.

**Geral:**
- **CORRESPONDÊNCIA CONFIRMADA NA REDE REGULAR** se B23a-R2 = EMERGE e B23b-R2 = CONVERGE_6F;
- **REFUTADA** se NÃO EMERGE ou NÃO CONVERGE;
- **INCONCLUSIVA** se houver INCONCLUSIVO;
- **PARCIAL** nos outros casos.

## 7. Fumaça (não vale como resultado)

`rodar_B23R2.py fumaca` (17h50–17h52):
- B23b-R2 em β = 1 com S = 1–3 e rotor |E| ≤ 3: discordância E × H = 0; resíduos ~10⁻¹³; truncamento e âncora rodaram.
- B23a-R2 em plaqueta S = 1 e faixa S = 1, nos 4 λ: as razões reproduzem a B23a-R; resíduos reais ~10⁻¹⁶; os dois
  métodos concordam a ~10⁻¹²; N1 e N3 rodaram.
- Avaliador com dados sintéticos: todos os ramos alcançados.

Cronometragem prévia (números de tempo; casos fora do conjunto decisivo ou iguais aos já publicados):
- eigsh rep E em S = 10, β = 3: 85 s;
- LOBPCG no cubo S = 1, λ = 0,1: 12 min;
- faixa S = 3, λ = 0,4 (execução externa): 13 min.

**Custo estimado:** B23b-R2 ≈ 1–1,5 h; B23a-R2 ≈ 2,5–3 h. Em paralelo, ≈ 3 h.

**Nota de código:** o script da minha auditoria (`verif_f0.py`) usava uma chave de hash que podia transbordar int64 (a
coincidência exata com a B23R mostra que não houve colisão). Aqui a chave da rep E usa base 2B + 3, com verificação
explícita contra transbordamento.

## 8. Limites declarados

- Aglomerados finitos: testa coeficientes locais e a convergência spin → rotor, não a fase de Coulomb termodinâmica.
- O cubo é uma superfície fechada (6 laços); não é a rede cúbica periódica.
- ħ entra nas relações de comutação; nada aqui deriva ħ.
- A parte não cega (18 pares da B23b-R) só recertifica valores já conhecidos.

## 9. Arquivos

`src/b23_modelo.py` (cópia idêntica do original), `src/b23ar2_emergencia.py`, `src/b23br2_spin_rotor.py`,
`src/rodar_B23R2.py`, `src/avaliar_B23R2.py`, `src/teste_avaliador_sintetico_R2.py`, `fumaca/`,
`hashes_antes_da_execucao.txt`.
