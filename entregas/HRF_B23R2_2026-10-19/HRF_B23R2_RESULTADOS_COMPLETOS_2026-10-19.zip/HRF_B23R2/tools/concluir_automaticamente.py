"""Conclui avaliação e entrega somente após ambos os blocos terminarem."""
from pathlib import Path
import time,subprocess,os,json,hashlib,tempfile,urllib.request,zipfile,io,datetime
R=Path(__file__).resolve().parent.parent
P='/workspace/my-ai-workflow/.venv/bin/python'
env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',MKL_NUM_THREADS='1',MPLCONFIGDIR='/tmp/hrf-b23r2-mpl',TZ='America/Sao_Paulo')
def log(msg):print(datetime.datetime.now(datetime.timezone.utc).isoformat(),msg,flush=True)
def run(script,logfile):
 with (R/'resultados'/logfile).open('w') as f:
  subprocess.run([P,'-I',str(R/'src'/script),'resultados'],cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
log('Aguardando conclusão dos blocos a e b; nenhum resultado provisório será avaliado como completo.')
while True:
 texts={b:(R/f'resultados/log_{b}_retomada.txt').read_text() for b in ('a','b')}
 if any('Traceback (most recent call last)' in t for t in texts.values()):raise RuntimeError('Erro no cálculo; verificar logs originais.')
 if all(f'fim bloco {b} —' in t for b,t in texts.items()):break
 time.sleep(30)
log('Blocos concluídos. Avaliando com regras congeladas.')
run('avaliar_B23R2.py','log_avaliacao_retomada.txt')
run('figuras_B23R2.py','log_figuras_retomada.txt')
res=subprocess.check_output([P,str(R/'tools/preparar_entrega.py')],env=env,cwd=R).decode()
(R/'resultados/empacotamento.json').write_text(res)
# O registro externo é posterior ao ZIP; não modifica o arquivo validado.
meta=json.loads(res); archive=Path(meta['zip']); report=R/'RELATORIO_CIENTIFICO_B23R2.md'
repo=Path('/workspace/my-ai-workflow'); branch='resultados-hrf-b23r2-20261019'; folder='entregas/HRF_B23R2_2026-10-19'
with tempfile.TemporaryDirectory(prefix='b23r2-publish-') as td:
 ge=env.copy();ge.update(GIT_INDEX_FILE=td+'/index',GIT_AUTHOR_NAME='Codex',GIT_AUTHOR_EMAIL='codex@openai.com',GIT_COMMITTER_NAME='Codex',GIT_COMMITTER_EMAIL='codex@openai.com')
 def git(*args,input=None):return subprocess.check_output(['git','-C',str(repo),*args],input=input,env=ge).decode().strip()
 git('fetch','--no-tags','origin','HEAD')
 parent=git('rev-parse','FETCH_HEAD')
 existing=git('ls-remote','origin','refs/heads/'+branch)
 if existing:raise RuntimeError('Branch de entrega já existe; preservar e revisar antes de publicar.')
 git('read-tree',parent)
 for name,path in {archive.name:archive,'HRF_B23R2_RELATORIO_2026-10-19.md':report}.items():
  blob=git('hash-object','-w','--stdin',input=path.read_bytes());git('update-index','--add','--cacheinfo',f'100644,{blob},{folder}/{name}')
 commit=git('commit-tree',git('write-tree'),'-p',parent,'-m','Disponibiliza resultados completos HRF B23-R2 para download')
 git('push','origin',commit+':refs/heads/'+branch)
 url=f'https://raw.githubusercontent.com/GraceKekey/my-ai-workflow/{commit}/{folder}/{archive.name}'
 with urllib.request.urlopen(url,timeout=60) as r:data=r.read();status=r.status
 assert status==200 and hashlib.sha256(data).hexdigest()==meta['sha256']
 with zipfile.ZipFile(io.BytesIO(data)) as z:assert z.testzip() is None
 meta.update(commit=commit,branch=branch,download_url=url,http_status=status,download_verified=True)
 (R.parent.parent/'HRF_B23R2_PUBLICACAO.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2))
 log(json.dumps(meta,ensure_ascii=False))
