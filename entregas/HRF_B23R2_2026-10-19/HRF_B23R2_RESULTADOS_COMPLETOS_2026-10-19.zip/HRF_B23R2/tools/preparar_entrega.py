"""Pós-processamento da entrega; não altera código nem decisões congeladas."""
from pathlib import Path
import json,hashlib,datetime,csv,zipfile,shutil
R=Path(__file__).resolve().parent.parent
read=lambda p:json.loads((R/p).read_text())
cfg=read('resultados/B23R2_config.json')['config']; a=read('resultados/B23aR2_checkpoint.json'); b=read('resultados/B23bR2_checkpoint.json'); ev=read('resultados/avaliacao_B23R2.json')
ca=cfg['B23aR2']; cb=cfg['B23bR2']
expected_a={f'{n}|S={s}|lambda={l}' for n,s in ca['casos'] for l in ca['lambdas']}
expected_ac={f'dois_metodos|{n}|S={s}|lambda={l}' for n,s,l in ca['dois_metodos']}
expected_ac|={f"N1|{ca['N1'][0]}|S={ca['N1'][1]}|lambda={ca['N1'][2]}",f"N3|{ca['N3'][0]}|S={ca['N3'][1]}|lambda={ca['N3'][2]}"}
expected_b={f'beta={beta}|S={s}' for beta in cb['betas'] for s in cb['S']}|{f"beta={beta}|rotor|Emax={cb['Emax_ref'][str(beta)]}" for beta in cb['betas']}
expected_bc={f'truncamento|beta={beta}|{ea}->{eb}' for beta,ea,eb in cb['truncamento']}|{f"ancora|S={s}|beta={cb['ancora_beta']}" for s in cb['ancora_S']}
coverage={'a_casos':set(a['casos'])==expected_a,'a_controles':set(a['controles'])==expected_ac,'b_casos':set(b['casos'])==expected_b,'b_controles':set(b['controles'])==expected_bc}
for block,data in [('a',a),('b',b)]:
 old=read(f'estado_recebido/B23{block}R2_checkpoint.json')
 coverage[f'{block}_casos_recebidos_preservados']=all(data['casos'][k]==v for k,v in old['casos'].items())
 coverage[f'{block}_controles_recebidos_preservados']=all(data['controles'][k]==v for k,v in old['controles'].items())
for line in (R/'hashes_antes_da_execucao.txt').read_text().splitlines()[3:]:
 h,f=line.split(maxsplit=1);coverage['hash:'+f]=hashlib.sha256((R/f).read_bytes()).hexdigest()==h
assert all(coverage.values()),coverage
(R/'VERIFICACAO_COBERTURA.json').write_text(json.dumps(coverage,indent=2,ensure_ascii=False))
(R/'tabelas').mkdir(exist_ok=True)
def table(name,rows):
 with (R/'tabelas'/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
table('B23a_casos.csv',[{'chave':k,**{f:v for f,v in c.items() if isinstance(v,(str,int,float,bool)) or v is None}} for k,c in a['casos'].items()])
table('B23b_casos.csv',[{'chave':k,'beta':c['beta'],'S':c['S'],'dim':c['dim'],'discordancia_E_H':c['discordancia_E_H'],'residuo_E':c['residuo_E'],'residuo_H':c['residuo_H'],'segundos':c['segundos']} for k,c in b['casos'].items()])
table('B23b_convergencia.csv',[{'beta':beta,'S':s,'D':d,'p_6_a_12':v['p_6_a_12'],'monotono_2_a_12':v['monotono_2_a_12']} for beta,v in ev['B23bR2']['por_beta'].items() for s,d in v['D'].items()])
meta=read('PROVENIENCIA_RETOMADA.json');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
lines=['# Relatório HRF B23-R2 — retomada completa','',f'Entrega preparada em {now}.','',f"**Resultado geral do avaliador congelado: {ev['B23_R2']}.**",'',f"B23a-R2: **{ev['B23aR2']['decisao']}**. B23b-R2: **{ev['B23bR2']['decisao']}**.",'', '## Objetivo','', 'Concluir a emergência quântica nos aglomerados finitos e a convergência spin → rotor com as seis faces do cubo fechado, retomando a rodada recebida.','', '## Hipóteses','', 'Razões elétricas e de anel próximas de 1 quando λ diminui, correções com ordem ≥ 1,5; D(S) estritamente decrescente em S=2–12 e ordem ≥ 1,5 na janela S=6–12. Regras completas no protocolo original incluído.','', '## Parâmetros','', 'B23a: cubo S=1, faixa S=3, plaqueta S=4; λ=0,4,0,2,0,1,0,05. Controles: dois métodos em λ=0,1 para os três aglomerados, N1 e N3 no cubo. B23b: β=0,5,1,2,3; S=1,2,3,4,6,8,10,12; quatro rotores de referência, dois truncamentos e duas verificações de âncora.','', '## Protocolo e proveniência','', 'Foram mantidos os casos calculados na máquina anterior e retomados somente os ausentes, com os arquivos científicos e regras de decisão intactos. O estado recebido, o ZIP original e os logs de ambas as fases estão preservados. Dois processos paralelos, com uma thread BLAS cada; limite de 4 CPUs e 32 GiB. A configuração original foi preservada; a proveniência da retomada está em PROVENIENCIA_RETOMADA.json.','', f"Versões da retomada: {json.dumps(meta['versoes'],ensure_ascii=False)}. A troca de máquina e de bibliotecas é um desvio operacional documentado; não há alegação de reprodução bit a bit. Casos já recebidos não foram recalculados nesta execução.",'', '## Medidas e resultados','', '### B23a-R2','', '| Caso | δJ (λ=0,05) | Anel (λ=0,05) | Ordem δJ | Ordem anel |','|---|---:|---:|---:|---:|']
for name,c in ev['B23aR2']['por_caso'].items():lines.append(f"| {name} | {c['razao_dJ_0.05']:.10g} | {c['razao_anel_0.05']:.10g} | {c['ordem_dJ']:.6g} | {c['ordem_anel']:.6g} |")
lines+=['','### B23b-R2','','| β | D(6) | D(12) | Ordem 6–12 | Monótono |','|---|---:|---:|---:|---|']
for beta,c in ev['B23bR2']['por_beta'].items():lines.append(f"| {beta} | {c['D']['6']:.10g} | {c['D']['12']:.10g} | {c['p_6_a_12']:.6g} | {c['monotono_2_a_12']} |")
lines+=['','## Controles e validade','','Todos os 12 casos principais e 5 controles da B23a, e os 36 casos (32 spins + 4 rotores) e 4 controles da B23b estão presentes. A cobertura exata, preservação dos valores recebidos e sete hashes congelados foram verificados.','','B23a:','', '```json',json.dumps({k:v for k,v in ev['B23aR2'].items() if k!='por_caso'},indent=2,ensure_ascii=False),'```','','B23b:','','```json',json.dumps({k:v for k,v in ev['B23bR2'].items() if k!='por_beta'},indent=2,ensure_ascii=False),'```','','Resultados detalhados de cada regra por caso estão em resultados/avaliacao_B23R2.json. O teste sintético exercitou todos os ramos do avaliador, sem contar como evidência física. Figuras foram geradas somente após a avaliação.','','## Interpretação e limites','','A interpretação deve seguir as regras congeladas, inclusive possíveis resultados parciais ou inconclusivos. Esta é uma bancada em aglomerados finitos: não demonstra a fase de Coulomb no limite termodinâmico. O cubo é uma superfície fechada de seis faces, não uma rede cúbica periódica. ħ já entra nas relações de comutação; o experimento não deriva ħ. Os 18 pares conhecidos da B23R são recertificação, e não teste cego. B23c não foi reexecutada.','','O ZIP inclui código, protocolo, entrada original, estado recebido, resultados, logs, figuras, tabelas e hashes. Não é necessário acessar o repositório para ler ou reproduzir o pacote.']
failed_a=[k for k in ('A0','A1','A2','A3','A4','todos_os_lacos','dois_metodos','N1','N3') if not ev['B23aR2'][k]]
interpretation=(f"Na B23a-R2, critérios que não passaram: {', '.join(failed_a)}." if failed_a else 'Na B23a-R2, todos os critérios A0–A4, laços, dois métodos, N1 e N3 passaram.')
for name,c in ev['B23aR2']['por_caso'].items():
 if not c['A3']:
  interpretation+=f" Em {name}, A3 não passou: ordem elétrica {c['ordem_dJ']:.8g} e ordem do anel {c['ordem_anel']:.8g}; a regra exige ambas ≥ 1,5 na janela λ=0,2,0,1,0,05."
if ev['B23aR2']['decisao']=='INCONCLUSIVO':
 interpretation+=' A regra congelada classifica a falha de A0 ou da comparação entre métodos como inconclusiva; isso não equivale a uma refutação física.'
if ev['B23bR2']['decisao']=='CONVERGE_6F':
 interpretation+=' Na B23b-R2, a validade numérica passou, D(S) decresceu estritamente para os quatro β e todas as ordens da janela de decisão superaram 1,5.'
pos=lines.index('## Interpretação e limites')+2
lines[pos:pos]=[interpretation,'']
(R/'RELATORIO_CIENTIFICO_B23R2.md').write_text('\n'.join(lines)+'\n')
(R/'requirements_execucao.txt').write_text('\n'.join(f'{k}=={v}' for k,v in meta['versoes'].items() if k!='python')+'\n')
(R/'LEIA_PRIMEIRO_RESULTADOS.md').write_text('# Resultados B23-R2\n\nLeia RELATORIO_CIENTIFICO_B23R2.md e resultados/avaliacao_B23R2.json.\n\nPara retomar/reproduzir use o protocolo original, uma thread BLAS por processo e os scripts congelados. O ZIP original e os checkpoints recebidos estão preservados; os resultados finais combinam a execução anterior e esta retomada. Remova os checkpoints somente em uma cópia separada se desejar refazer todos os casos.\n')
(R/'PROVENIENCIA_CONCLUSAO.json').write_text(json.dumps({'utc':now,'cobertura_completa':True,'hashes_congelados_inalterados':True,'avaliacao':ev['B23_R2']},indent=2,ensure_ascii=False))
files=[p for p in R.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='MANIFEST_SHA256_ENTREGA.json']
manifest={str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(R/'MANIFEST_SHA256_ENTREGA.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False))
output=R.parent.parent/'HRF_B23R2_RESULTADOS_COMPLETOS_2026-10-19.zip'
with zipfile.ZipFile(output,'w',zipfile.ZIP_DEFLATED) as z:
 for p in sorted(files+[R/'MANIFEST_SHA256_ENTREGA.json']):z.write(p,str(Path(R.name)/p.relative_to(R)))
with zipfile.ZipFile(output) as z:
 assert z.testzip() is None
 for name,h in manifest.items():assert hashlib.sha256(z.read(f'{R.name}/{name}')).hexdigest()==h
shutil.copy2(R/'RELATORIO_CIENTIFICO_B23R2.md',R.parent.parent/'HRF_B23R2_RELATORIO_2026-10-19.md')
print(json.dumps({'zip':str(output),'bytes':output.stat().st_size,'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'resultado':ev['B23_R2']},indent=2,ensure_ascii=False))
