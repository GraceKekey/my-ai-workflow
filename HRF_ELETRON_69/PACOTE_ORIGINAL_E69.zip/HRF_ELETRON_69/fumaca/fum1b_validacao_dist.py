"""Fumaça 1b — validação de dois quanta distinguíveis |1_f1, 1_f2> contra diagonalização direta."""
import sys, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sla
sys.path.insert(0, "/home/claude/E69/src")
from e69_fock import dS2_dist
N, nmax = 4, 10; d = nmax + 1
K = np.diag([2.3, 2.1, 2.2, 2.4]) - 1.0 * (np.eye(N, k=1) + np.eye(N, k=-1)); K[0, 3] = K[3, 0] = -0.4
a1 = sp.diags(np.sqrt(np.arange(1, d)), 1); x1 = (a1 + a1.T) / np.sqrt(2); p1 = (a1 - a1.T) / (1j * np.sqrt(2)); I = sp.identity(d)
def op(o, i):
    m = [I] * N; m[i] = o; r = m[0]
    for q in m[1:]: r = sp.kron(r, q, format="csr")
    return r
X = [op(x1, i) for i in range(N)]; P = [op(p1, i) for i in range(N)]
H = sum(0.5 * P[i] @ P[i] for i in range(N)) + sum(0.5 * K[i, j] * X[i] @ X[j] for i in range(N) for j in range(N))
g0 = sla.eigsh(H.tocsc(), k=1, which="SA")[1][:, 0].astype(complex)
lam, V = np.linalg.eigh(K); s = np.sqrt(lam); Xc = 0.5 * (V / s) @ V.T; Pc = 0.5 * (V * s) @ V.T
f1 = np.array([0.6, -0.5, 0.45, 0.2]); f2 = np.array([0.1, 0.7, 0.3, -0.5])
c1 = V.T @ f1; c1 /= np.linalg.norm(c1); c2 = V.T @ f2; c2 -= (c1 @ c2) * c1; c2 /= np.linalg.norm(c2)
def adag(c):
    g = V @ (lam ** 0.25 * c); h = V @ (lam ** -0.25 * c)
    return sum((g[i] * X[i] - 1j * h[i] * P[i]) / np.sqrt(2) for i in range(N)), g, h
A1, g1, h1 = adag(c1); A2, g2, h2 = adag(c2)
psi = A2 @ (A1 @ g0); psi /= np.linalg.norm(psi)
A = [0, 1]; dA = d ** 2
pur = lambda v: float(np.real(np.trace((lambda M: M @ M.conj().T)(v.reshape(dA, -1)) @ (lambda M: M @ M.conj().T)(v.reshape(dA, -1)))))
XA, PA = Xc[np.ix_(A, A)], Pc[np.ix_(A, A)]
Hm = np.stack([h1[A], h2[A]], 1); Gm = np.stack([g1[A], g2[A]], 1)
Ca = Hm.T @ np.linalg.solve(2 * XA, Hm); Cb = Gm.T @ np.linalg.solve(2 * PA, Gm)
print("dS2 num", -np.log(pur(psi) / pur(g0)), " fórmula", dS2_dist(Ca, Cb))
