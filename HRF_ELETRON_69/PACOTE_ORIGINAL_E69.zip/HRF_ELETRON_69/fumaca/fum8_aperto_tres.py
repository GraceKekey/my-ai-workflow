"""Fumaça 8 — o aperto da E-67 (r = 0,25, w = 4, caixa 40x46) nas três leituras (aperto_tres) e em von Neumann."""
import sys, numpy as np
sys.path.insert(0, "/home/claude/E69/src")
from e65_holo import rede, disco, entropia_gauge
from e67_particula import modo_chapeu, aperta
from e69_fock import modos, vacuo_de_modos, aperto_tres
X, L, pr = rede(40, 46); c = L / 2 + np.array([0.25, 0.1])
lam, V = modos(len(X), pr); Xt, Pt = vacuo_de_modos(lam, V)
f = modo_chapeu(X, L, c, 4.0); Xs, Ps = aperta(Xt, Pt, f, 0.25)
R = []
for r in np.arange(1.0, 16.01, 0.5):
    idx = disco(X, L, c, r)
    R.append((r, *aperto_tres(Xt, Pt, Xs, Ps, idx), entropia_gauge(Xs, Ps, idx)[0] - entropia_gauge(Xt, Pt, idx)[0]))
R = np.array(R)
for i, n in enumerate(("cond", "compl", "fator", "vN (cond)")):
    v = R[:, i + 1]
    print(f"{n:10s} min {v.min():+.4f} em rho {R[v.argmin(), 0]:4.1f}   max {v.max():+.4f} em rho {R[v.argmax(), 0]:4.1f}")
