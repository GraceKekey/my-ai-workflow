"""Fumaça 5 — o centro da álgebra (P_A): as três leituras (condicional, completa, fator) no perfil centrado.
Caixa 40x46 (rápida) e 64x74 (a da rodada), w = 4 (e 5–7 na caixa grande). Domínio físico: s2 + gam^2/2 <= 1."""
import sys, time, numpy as np
sys.path.insert(0, "/home/claude/E69/src")
from e65_holo import rede, disco, minimg
from e67_particula import modo_chapeu
from e69_fock import (modos, vacuo_de_modos, gh, regiao, regiao2, gamma_centro, dS2_tres, dS2_dist_tres, ortogonaliza,
                      energia_fock)
tam = tuple(int(x) for x in sys.argv[1].split("x")) if len(sys.argv) > 1 else (40, 46)
ws = tuple(float(x) for x in sys.argv[2].split(",")) if len(sys.argv) > 2 else (4.0,)
t0 = time.time()
X, L, pr = rede(*tam); c = L / 2 + np.array([0.25, 0.1])
lam, V = modos(len(X), pr); Xt, Pt = vacuo_de_modos(lam, V); print("caixa", tam, "vácuo", round(time.time() - t0, 1), "s", flush=True)
for w in ws:
    f = modo_chapeu(X, L, c, w); g, h, fn = gh(lam, V, f)
    dxy = minimg(X - c, L); f2 = dxy[:, 0] * np.exp(-(dxy ** 2).sum(1) / (2 * w * w)); f2 = ortogonaliza(lam, V, f, f2)
    g2, h2, _ = gh(lam, V, f2); G = np.stack([g, g2], 1); H = np.stack([h, h2], 1)
    print(f"\n== w = {w}   E1 = {energia_fock(lam, V, f)[0]:.4f}")
    print("  rho   pNW   s1    s2    gam  s2+g²/2 | n=1 cond  compl  fator | n=2 cond  n=4 cond | dist cond  compl  fator")
    rhos = np.arange(0.5, 4 * w + 0.01, 0.5)
    for r in rhos:
        idx = disco(X, L, c, r)
        if len(idx) < 2: continue
        Ca, Cb, _ = regiao2(Xt, Pt, idx, G, H); s1, s2 = Ca[0, 0], Cb[0, 0]
        gm = gamma_centro(Pt, idx, g); gm2 = gamma_centro(Pt, idx, g2)
        a1 = dS2_tres(1, s1, s2, gm); a2 = dS2_tres(2, s1, s2, gm); a4 = dS2_tres(4, s1, s2, gm)
        dd = dS2_dist_tres(Ca, Cb, (gm, gm2))
        print(f"{r:5.1f} {(fn[idx]**2).sum():.3f} {s1:.3f} {s2:.3f} {gm:+.3f} {s2+gm*gm/2:.3f} | {a1[0]:+.4f} {a1[1]:+.4f} {a1[2]:+.4f} |"
              f" {a2[0]:+.4f} {a4[0]:+.4f} | {dd[0]:+.4f} {dd[1]:+.4f} {dd[2]:+.4f}", flush=True)
print("tempo total", round(time.time() - t0, 1), "s")
