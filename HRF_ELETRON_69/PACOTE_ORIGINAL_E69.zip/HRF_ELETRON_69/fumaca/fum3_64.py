"""Fumaça 3 — caixa 64x74, w = 4..7: perfis centrados, escala com n, dois quanta distinguíveis, energia, mapa fora do centro."""
import sys, time, numpy as np
sys.path.insert(0, "/home/claude/E69/src")
from e65_holo import rede, disco, minimg
from e67_particula import modo_chapeu, aperta, raio_metade
from e69_fock import modos, vacuo_de_modos, gh, regiao, dS2, energia_fock, regiao2, dS2_dist, ortogonaliza
t0 = time.time()
X, L, pr = rede(64, 74); N = len(X); c = L / 2 + np.array([0.25, 0.1])
lam, V = modos(N, pr); Xt, Pt = vacuo_de_modos(lam, V); print("vácuo", round(time.time() - t0), "s", flush=True)
rhos = np.arange(0.5, 24.01, 0.25)
for w in (4.0, 5.0, 6.0, 7.0):
    t1 = time.time()
    f = modo_chapeu(X, L, c, w); g, h, _ = gh(lam, V, f)
    dxy = minimg(X - c, L); f2 = dxy[:, 0] * np.exp(-(dxy ** 2).sum(1) / (2 * w * w)); f2 = ortogonaliza(lam, V, f, f2)
    g2, h2, _ = gh(lam, V, f2)
    E1, e = energia_fock(lam, V, f); E2, _ = energia_fock(lam, V, f2); r50 = raio_metade(X, L, c, e)
    prof = []
    for r in rhos:
        idx = disco(X, L, c, r)
        if len(idx) < 2: prof.append((r, 0, 0, 0, 0, 0)); continue
        Ca, Cb, S2 = regiao2(Xt, Pt, idx, np.stack([g, g2], 1), np.stack([h, h2], 1))
        s1, s2 = Ca[0, 0], Cb[0, 0]
        prof.append((r, dS2(1, s1, s2), dS2(2, s1, s2), dS2(4, s1, s2), dS2_dist(Ca, Cb), 0.5 * (s1 + s2)))
    P = np.array(prof); r = P[:, 0]; d1 = P[:, 1]
    k = np.argmax(d1); pe = P[:, 5]; jh = np.argmin(np.abs(pe - 0.5))
    print(f"w={w}: E1={E1:.4f} E1*w={E1*w:.3f} r50={r50:.2f} | pico n1 {d1[k]:.4f} em rho={r[k]} ({r[k]/w:.3f}w); p_eff=1/2 em {r[jh]} | "
          f"n2/n1={P[k,2]/d1[k]:.3f} n4/n1={P[k,3]/d1[k]:.3f} | dist máx {P[:,4].max():.4f} em {r[np.argmax(P[:,4])]} | min n1 {d1.min():+.5f} | fecho4w {np.abs(d1[r>=4*w]).max()/d1[k] if (r>=4*w).any() else float('nan'):.4f} | {time.time()-t1:.0f}s", flush=True)
    # mapa fora do centro (n = 1): raio de resposta máxima e profundidade equivalente
    out = []
    for dd in np.array([0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0]) * w:
        x0 = c + np.array([dd, 0.0]); rr = np.arange(max(0.5, dd - 1.5 * w), dd + 3.0 * w + 1e-9, 0.25); v = []
        for q in rr:
            idx = disco(X, L, x0, q)
            if len(idx) < 2: v.append(0.0); continue
            s1, s2, _ = regiao(Xt, Pt, idx, g, h); v.append(dS2(1, s1, s2))
        v = np.array(v); j = int(np.argmax(v)); rs = rr[j]
        if 0 < j < len(v) - 1:
            den = v[j - 1] - 2 * v[j] + v[j + 1]; rs = rr[j] + 0.25 * 0.5 * (v[j - 1] - v[j + 1]) / den if den != 0 else rr[j]
        out.append((dd / w, rs, v[j], np.sqrt(max(rs * rs - dd * dd, 0))))
    print("   mapa (d/w, rho*, pico, z*=sqrt(rho*^2-d^2)):", [(a, round(b, 2), round(cc, 3), round(z, 2)) for a, b, cc, z in out], f"| {time.time()-t1:.0f}s", flush=True)
print("total", round(time.time() - t0), "s")
