"""Fumaça 4 — caixa 64x74: controle 'gato' (separação 30, w = 4) e expoente de discos pequenos do Fock (w = 5)."""
import sys, numpy as np
sys.path.insert(0, "/home/claude/E69/src")
from e65_holo import rede, disco
from e67_particula import modo_chapeu
from e69_fock import modos, vacuo_de_modos, gh, regiao, dS2
X, L, pr = rede(64, 74); N = len(X); c = L / 2 + np.array([0.25, 0.1])
lam, V = modos(N, pr); Xt, Pt = vacuo_de_modos(lam, V)
fg = modo_chapeu(X, L, c, 4.0) + modo_chapeu(X, L, c + np.array([30.0, 0.0]), 4.0); fg /= np.linalg.norm(fg)
g, h, _ = gh(lam, V, fg)
for r in (8.0, 10.0, 12.0):
    s1, s2, _ = regiao(Xt, Pt, disco(X, L, c, r), g, h); print(f"gato rho={r}: n1 {dS2(1,s1,s2):.5f} (ln2 0.69315)  n2 {dS2(2,s1,s2):.5f} (0.98083)")
w = 5.0; f = modo_chapeu(X, L, c, w); g, h, _ = gh(lam, V, f); rp = np.array([1.0, 1.5, 2.0, 2.5, 3.0])
for fr in (0.5, 1.0, 1.5):
    x0 = c + np.array([fr * w, 0.0]); v = []
    for r in rp:
        s1, s2, _ = regiao(Xt, Pt, disco(X, L, x0, r), g, h); v.append(dS2(1, s1, s2))
    v = np.array(v); print(f"Fock w=5 d={fr}w: dS2 = {np.round(v,5).tolist()}  expoente {np.polyfit(np.log(rp), np.log(v), 1)[0]:.2f}")
