"""Fumaça 7 — caixa 64x74: mapa fora do centro (n = 1) nas três leituras, gato e discos pequenos. Uso: fum7 <w>"""
import sys, time, json, numpy as np
sys.path.insert(0, "/home/claude/E69/src")
from e65_holo import rede, disco
from e67_particula import modo_chapeu
from e69_fock import modos, vacuo_de_modos, gh, regiao, gamma_centro, dS2_tres
from avaliar_e69 import pico
w = float(sys.argv[1]); t0 = time.time()
X, L, pr = rede(64, 74); c = L / 2 + np.array([0.25, 0.1])
lam, V = modos(len(X), pr); Xt, Pt = vacuo_de_modos(lam, V)
f = modo_chapeu(X, L, c, w); g, h, _ = gh(lam, V, f)
out = {}
print(f"w={w}: z*(d) = sqrt(rho*^2 - d^2) por leitura (cond | compl | fator); pico do mapa", flush=True)
for dm in (0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0):
    dd = dm * w; x0 = c + np.array([dd, 0.0]); rr = np.arange(max(0.5, dd - 1.5 * w), dd + 3.0 * w + 1e-9, 0.25)
    v = np.zeros((len(rr), 3))
    for i, q in enumerate(rr):
        idx = disco(X, L, x0, q)
        if len(idx) < 2: continue
        s1, s2, _ = regiao(Xt, Pt, idx, g, h); v[i] = dS2_tres(1, s1, s2, gamma_centro(Pt, idx, g))
    zs = []; pk = []
    for j in range(3):
        rs, vv = pico(rr, v[:, j]); zs.append(float(np.sqrt(max(rs * rs - dd * dd, 0)))); pk.append(vv)
    out[dm] = dict(z=zs, pico=pk, minimo=v.min(0).tolist())
    print(f"  d={dm:.1f}w  z* {zs[0]:6.2f} {zs[1]:6.2f} {zs[2]:6.2f} | pico {pk[0]:.4f} {pk[1]:.4f} {pk[2]:.4f} | min {v[:,0].min():+.4f} ({time.time()-t0:.0f}s)", flush=True)
for j, nome in enumerate(("cond", "compl", "fator")):
    longe = [out[k]["z"][j] for k in out if k >= 2.0]
    print(f"  {nome}: razão mediana(z*, d>=2w)/z*(0) = {np.median(longe) / out[0.0]['z'][j]:.3f}")
if w == 4.0:
    c2 = c + np.array([30.0, 0.0]); fg = modo_chapeu(X, L, c, 4.0) + modo_chapeu(X, L, c2, 4.0); fg /= np.linalg.norm(fg)
    gg, hg, _ = gh(lam, V, fg)
    for r in (8.0, 10.0, 12.0):
        idx = disco(X, L, c, r); s1, s2, _ = regiao(Xt, Pt, idx, gg, hg); gm = gamma_centro(Pt, idx, gg)
        print(f"  gato rho={r}: gam={gm:+.4f}  n=1 {np.round(dS2_tres(1, s1, s2, gm), 4)}  n=2 {np.round(dS2_tres(2, s1, s2, gm), 4)}")
if w == 5.0:
    for fr in (0.5, 1.0, 1.5):
        x0 = c + np.array([fr * w, 0.0]); vals = []
        for r in (1.0, 1.5, 2.0, 2.5, 3.0):
            idx = disco(X, L, x0, r); s1, s2, _ = regiao(Xt, Pt, idx, g, h); vals.append(dS2_tres(1, s1, s2, gamma_centro(Pt, idx, g)))
        vals = np.array(vals); rp = np.array([1.0, 1.5, 2.0, 2.5, 3.0])
        print(f"  discos pequenos d={fr}w: expoentes", [round(float(np.polyfit(np.log(rp), np.log(np.abs(vals[:, j])), 1)[0]), 2) for j in range(3)])
print("tempo", round(time.time() - t0), "s")
