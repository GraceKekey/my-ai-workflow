# Fumaça da E-69 (antes do registro) · 8/10/2026 21h20–22h40 · -clau

Máquina nova: entropia de Rényi-2 **exata** de estados de Fock por função característica (χ_n = χ_0 · L_n(|c|²)),
na álgebra invariante de gauge da E-65/E-67 (`src/e69_fock.py`); vácuo, rede e modo "chapéu mexicano" iguais aos da E-67.
As fumaças 1–4 usaram só a leitura **"fator"** (ver item 5); as fumaças 5–7 refazem tudo nas três leituras do centro.

## Primeira rodada de fumaça (21h20–21h45; leitura "fator")

1. `fum1_validacao.py` e `fum1b_validacao_dist.py` (cadeia de 4 osciladores, espaço de Fock truncado): a fórmula
   reproduz a diagonalização direta — n = 1: 0,59708347 × 0,59708347; n = 2: 0,43877986 × 0,43877986; n = 3:
   0,35935235 × 0,35935233 (truncamento 12). Dois quanta distinguíveis com truncamento 10: 1,20336921 × 1,20336950
   (diferença 3 × 10⁻⁷, do truncamento); na validação VQ (`src/validar_formula.py`, truncamento 12): 1,20336949 ×
   1,20336950. **Erro máximo da VQ: 2 × 10⁻⁸.** *(Correção: a versão anterior desta nota dava "1,2033695 × 1,2033695"
   para o caso de truncamento 10.)*
2. `fum2_perfis.py` (caixa 40 × 46, w = 4): referência de gauge irrelevante (10 casas); perfil do Fock n = 1 é uma
   lomba positiva única, pico 0,6925 ≈ ln 2 em ρ = 5,5, onde p_eff = (σ₁² + σ₂²)/2 = ½; a probabilidade "de
   Newton–Wigner" Σ_A f² já é 0,86 ali. n = 2 e 4: 0,9804 e 1,2963 (lei dos bits: 0,9808 e 1,2966). O aperto
   r = 0,25, no mesmo modo, em Rényi-2 e em von Neumann: **dois lobos** (− e depois +), como na E-67. Controle "gato"
   (dois chapéus separados por 18): 0,6929 em ρ = 10 (ln 2 = 0,6931: **3 casas**; a versão anterior dizia 4).
3. `fum3_64.py` (caixa 64 × 74, w = 4–7, leitura "fator", picos sem interpolação):

   | w | E1 | E1·w | pico n=1 | ρ do pico | ρ/w | n2/n1 | n4/n1 | fecho 4w |
   |---|---|---|---|---|---|---|---|---|
   | 4 | 0,4126 | 1,650 | 0,6926 | 5,5 | 1,375 | 1,416 | 1,872 | 0,0025 |
   | 5 | 0,3309 | 1,654 | 0,6913 | 7,0 | 1,400 | 1,417 | 1,874 | 0,0024 |
   | 6 | 0,2761 | 1,657 | 0,6916 | 8,25 | 1,375 | 1,417 | 1,874 | 0,0021 |
   | 7 | 0,2368 | 1,658 | 0,6911 | 9,5 | 1,357 | 1,417 | 1,875 | não medível |

   Lei dos bits (metade dentro): n2/n1 = 1,4150; n4/n1 = 1,8707. Lei "área ∝ energia": 2 e 4.
   Mapa fora do centro (n = 1, w = 5): z* = 6,93; 6,21; 4,92; 4,07; 3,71; 3,90; 4,19 para d = 0 a 3w; razão
   longe/centro 0,53–0,59 nas quatro larguras. *(A coluna "distinguíveis/(2 × pico)" = 0,92 que estava aqui foi
   retirada: comparava os dois quanta com duas vezes o chapéu, mas o dipolo sozinho tem pico menor — ver item 7.)*
4. `fum4_gato_sondas.py` (64 × 74): gato com separação 30 e w = 4: ρ = 8; 10; 12 → 0,6805; 0,6927; 0,6931 (n = 1).
   Discos pequenos do Fock (w = 5) em d = 0,5w; w; 1,5w: expoente 3,78; 3,67; 4,10.

## O centro da álgebra (revisão, 21h50–22h25)

5. **O problema (achado da revisão).** Na álgebra invariante de gauge da região, o momento total P_A = Σ_A p é o
   **centro**: comuta com tudo o que a região mede. No vácuo gaussiano o fator {ΔZ, p − αP_A} é independente de P_A, e
   a entropia "destilável" da E-65/E-67 (α tirado do próprio estado) é a entropia de qualquer setor. No estado de Fock
   isso **não vale**: o quantum mexe na distribuição de P_A com o acoplamento γ = Σ_A g / √Var(P_A), e parte da
   informação "de que lado está o quantum" fica no centro, como informação **clássica**. A fórmula das fumaças 1–4
   ("fator", com o α do vácuo) ignora isso e, além disso, depende da escolha de α. Três leituras, iguais no vácuo:
   - **condicional (destilável):** ΔS₂ = −∫P(q) ln[Tr ρ_q² / Tr ρ_q,vácuo²] dq — a média, por setor do centro, da
     Rényi-2 extra. É a generalização direta da convenção da E-65/E-67. Não depende de α.
   - **completa:** a álgebra inteira, com o termo clássico do centro: R₂ = E[L_n(|c|²)²] com σ₂² → σ₂² + γ²/2. Não
     depende de α.
   - **fator:** só {ΔZ, p − αP_A} com o α do vácuo (fumaças 1–4). Depende de α.
6. **Validação por força bruta** (`src/validar_centro.py`, nova validação VC): anel de 5 GMFs, região de 2, função de
   onda tabulada numa grade 4D, transformada de Fourier na coordenada conjugada ao centro, setores traçados um a um —
   sem função característica e sem Laguerre. Três modos (γ = 1,31; 0,95; 0,11), n = 1 e 2, e dois quanta
   distinguíveis: as três leituras batem com as fórmulas com **erro máximo 4 × 10⁻¹³**. A pureza por setor do vácuo é
   a mesma em todos os setores (variação 5 × 10⁻¹³), e o sinal do deslocamento do fator foi fixado por isso. Na
   primeira tentativa a condicional diferia em 10⁻³ para γ = 1,31: resolução dos setores (passo em q grosso perto dos
   zeros de P(q)); com zeros acrescentados à transformada (8×) o erro caiu para 10⁻¹³. O amostrador gaussiano passou a
   aceitar covariâncias de posto incompleto (`_raiz` no lugar de Cholesky; mesma resposta nos casos de posto cheio).
   Domínio físico: σ₁² ≤ 1 e σ₂² + γ²/2 ≤ 1 (é a fração do modo dentro da região); nos pontos de teste fora desse
   domínio (por exemplo σ₁² = σ₂² = 1 com γ = 0,5) apareciam valores negativos — não ocorrem na rede (máximo 0,9998).
7. `fum5_centro.py` (40 × 46, w = 4) e `fum6_centro_64.py` (64 × 74, w = 4–7, passo 0,25, picos com interpolação
   parabólica) — perfis centrados nas três leituras:

   | w | E1 | **cond:** pico (÷ ln 2) | ρ/w | E1·z0 | n2/n1 | n4/n1 | β₂₄ | compl: pico | β₂₄ | fator: pico | β₂₄ | cond ÷ fator | γ no pico |
   |---|---|---|---|---|---|---|---|---|---|---|---|---|---|
   | 4 | 0,4126 | 0,1817 (0,262) | 1,087 | 1,795 | 1,735 | 2,493 | 0,523 | 0,5548 | 0,478 | 0,6951 | 0,402 | 0,261 | 1,00 |
   | 5 | 0,3309 | 0,1910 (0,275) | 1,094 | 1,809 | 1,712 | 2,437 | 0,510 | 0,5589 | 0,475 | 0,6919 | 0,403 | 0,276 | 0,97 |
   | 6 | 0,2761 | 0,1983 (0,286) | 1,076 | 1,782 | 1,698 | 2,399 | 0,499 | 0,5623 | 0,473 | 0,6918 | 0,403 | 0,287 | 0,95 |
   | 7 | 0,2368 | 0,2059 (0,297) | 1,100 | 1,823 | 1,681 | 2,360 | 0,489 | 0,5654 | 0,471 | 0,6912 | 0,403 | 0,298 | 0,94 |

   β₂₄ = log₂[pico(n=4)/pico(n=2)]: 1 se a imagem cresce como a energia; 0,403 na lei dos bits. Em todas as leituras a
   lomba é **positiva e única** (mínimo da condicional −2 × 10⁻¹⁶). Na leitura condicional, **só 26–30% do bit é
   destilável**; o resto mora no centro. A fração cresce devagar com w (γ no pico cai de 1,00 para 0,94, como se
   espera de γ² ~ 1/ln w: Var(P_A) tem um log ultravioleta). O pico condicional fica em ρ ≈ 1,09w (o do fator, em
   1,37–1,40w). O pico "fator" interpolado passa ln 2 em até 0,3% (0,6951): artefato da parábola; o limite exato de
   ΔS₂ para n = 1 é ln 2.
   **Dois quanta distinguíveis:** com discos centrados, o chapéu (par) e o dipolo (ímpar) são independentes na região
   (γ do dipolo ≤ 0,04; covariâncias cruzadas ~0) e somam **exatamente** (razão 1,000 nas três leituras) — por
   simetria, não por física. O dipolo sozinho tem pico 0,59–0,60. A hipótese "H69-D" virou controle (VD).
8. `fum7_mapa_centro.py` (64 × 74; mapa fora do centro, n = 1). Profundidade equivalente z* (d = 0; 0,5; 1; 1,5; 2;
   2,5; 3 × w):

   | w | leitura | z* | razão longe/centro |
   |---|---|---|---|
   | 4 | cond | 4,35; 4,31; 3,09; 2,80; 2,94; 3,08; 2,82 | 0,675 |
   | 4 | compl | 4,36; 4,23; 3,43; 2,97; 3,18; 3,32; 3,30 | 0,758 |
   | 4 | fator | 5,61; 5,08; 3,91; 3,11; 3,19; 3,33; 3,29 | 0,587 |
   | 5 | cond | 5,47; 4,77; 4,13; 3,31; 3,57; 3,81; 3,16 | 0,652 |
   | 5 | compl | 5,47; 4,92; 4,35; 3,89; 3,68; 3,89; 4,18 | 0,712 |
   | 5 | fator | 6,93; 6,21; 4,92; 4,07; 3,71; 3,90; 4,19 | 0,563 |

   (w = 7 foi interrompido em d = 2w por tempo; até ali: 7,70; 7,04; 5,93; 4,89; 4,61 na condicional.) Longe do
   centro o corte do disco passa quase reto pelo meio do modo, γ → 0 e as três leituras se juntam (picos 0,63–0,64).
   Gato (w = 4, separação 30), ρ = 8; 10; 12 — cond 0,6180; **0,6884**; 0,6928 · compl 0,6877; 0,6928; 0,6931 ·
   fator 0,6805; 0,6927; 0,6931 (γ = 0,29; 0,07; −0,02). Discos pequenos (w = 5; d = 0,5w; w; 1,5w), expoentes
   cond 3,72; 3,67; 4,10 · compl 2,78; 3,29; 3,75 · fator 3,78; 3,67; 4,10.
   Tempo (3 processos em 2 núcleos): mapa de w = 4 em 4,5 min, de w = 5 em 8 min. Os raios do mapa passaram a ter teto
   de 30 (abaixo de meia caixa), para não dar a volta no toro; isso não toca nenhum pico medido.

## Segunda revisão (22h25–22h40)

9. Um revisor independente apontou, e foi conferido:
   - **Estados gaussianos:** as três leituras são iguais só no **vácuo**. Num gaussiano qualquer, ρ_q é o mesmo em
     todos os setores (a condicional = a entropia da E-65/E-67), mas a completa ganha ½ ln[Var(P_A)/Var_vácuo(P_A)] e a
     fator muda com o α. `fum8_aperto_tres.py` (40 × 46, w = 4, aperto r = 0,25): condicional −0,0037 / +0,0098;
     completa −0,1163 / +0,0086; fator −0,0006 / +0,0267 (mínimo / máximo); von Neumann (condicional) −0,0111 / +0,0238.
     **O aperto é ondulação na condicional e na completa, não na fator.** O contraste com a E-67 é da leitura
     condicional. O aperto entrou na VC (força bruta, erro 4 × 10⁻¹²) e é gravado nas três leituras.
   - **Teorema:** para n = 1, nas leituras completa e fator, R₂ = 1 − (a + b) + (3a² + 2ab + 3b²)/4 ≤ 1 com a, b ∈
     [0, 1], logo ΔS₂ ≥ 0 sempre: H69-B só é teste na condicional. Foi acrescentado o critério de **lomba única**
     (proeminência ≥ 5% do pico): nos perfis da fumaça 6, 1 lomba em todas as larguras e leituras.
   - **H69-C vale para o modo chapéu e discos concêntricos:** o dipolo (γ ≈ 0) tem φ ≈ 1,000 e os picos do mapa com
     d ≥ 1,5w têm φ = 0,96–0,99 (w = 4: 0,963; 0,983; 0,991; 0,995). γ² no pico cai de 0,99 (w = 4) para 0,88 (w = 7):
     mais devagar que 1/ln w (ajuste ≈ c/(ln w + 2,9)).
   - **Faixa da razão longe/centro:** a condicional e a completa só têm mapa em w = 4 e 5 (0,65–0,68 e 0,71–0,76); a
     fator, nas quatro larguras, 0,53–0,59. A frase anterior "0,56–0,76" misturava as duas coisas.
   - **Ruído de z\*:** perfis em degraus e o fator ρ\*/z\* ≈ 3–5 tornam z\*(d ≥ 2w) ruidoso (w = 5, d = 3w: 3,16 na
     condicional × 4,18 nas outras, com picos iguais a 0,5%). Acrescentado um z\* descritivo por ajuste quadrático no
     topo (pontos ≥ 0,9 × pico).
   - Nome do veredito: "SIM — massa **no sentido fraco**" (objeto com conteúdo e E·z0 fixo); E·z0 é identidade de
     escala, e N = LINEAR não é esperado num campo livre.

## O que já se viu antes do registro (declarado)

Nas três leituras: **conteúdo** (lomba positiva única; teste de verdade só na condicional), **crescimento sublinear com
n** (β₂₄ = 0,40–0,52, longe de 1), **imagem estendida em profundidade** (razão longe/centro: condicional 0,65–0,68,
completa 0,71–0,76, em w = 4 e 5; fator 0,53–0,59 nas quatro larguras), **profundidade ∝ tamanho** e **E1·z0
constante** (CV ≈ 1%). Na leitura principal (condicional), com o modo chapéu e discos concêntricos, só **26–30% do bit
é destilável** — o resto mora no centro. O aperto da E-67 é ondulação na condicional. Os limiares do protocolo foram
escritos **depois** disto. O resultado esperado é **"SIM — massa no sentido fraco SEM gravidade"**, H69-C = "NO CENTRO"
e H69-R = "ROBUSTA". A rodada confirma com a grade completa, os mapas nas quatro larguras, o gato, a ponte com a E-67 e
as validações.

Teste do encadeamento: só em modo `teste` (caixa 24 × 28, w = 2 e 3), na pasta `teste_saida/`, apagada depois; nesse
modo VG e VA falham por causa da caixa pequena (esperado, sem sentido físico). `dados/` e `resultados/` estão vazios.
