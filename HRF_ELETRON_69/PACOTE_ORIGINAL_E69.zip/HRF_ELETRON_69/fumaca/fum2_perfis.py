"""Fumaça 2 — caixa 40x46: perfis centrados (Fock n = 1, 2, 4 × aperto r = 0,25, Rényi-2), referência de gauge, controle 'gato'."""
import sys, time, numpy as np
sys.path.insert(0, "/home/claude/E69/src")
from e65_holo import rede, disco, minimg, entropia_gauge
from e67_particula import modo_chapeu, aperta
from e69_fock import modos, vacuo_de_modos, gh, regiao, dS2, energia_fock
t0 = time.time()
X, L, pr = rede(40, 46); N = len(X); c = L / 2 + np.array([0.25, 0.1])
lam, V = modos(N, pr); Xt, Pt = vacuo_de_modos(lam, V); print("vácuo", round(time.time() - t0, 1), "s", flush=True)
w = 4.0; f = modo_chapeu(X, L, c, w); g, h, _ = gh(lam, V, f)
E1, e = energia_fock(lam, V, f); print("E1 =", round(E1, 4), " min densidade local", round(e.min(), 5), " soma", round(e.sum(), 4))
idx = disco(X, L, c, 6.0)
print("VK sig:", [tuple(np.round(regiao(Xt, Pt, idx, g, h, j0)[:2], 10)) for j0 in (0, 7, len(idx) - 1)])
Xs, Ps = aperta(Xt, Pt, f, 0.25)
rhos = np.arange(0.5, 16.01, 0.5); pnw = []
print(" rho   pNW   sig1   sig2  | dS2 n1   n2    n4  | aperto dS2   dS(vN)")
for r in rhos:
    idx = disco(X, L, c, r)
    if len(idx) < 2: continue
    s1, s2, S2 = regiao(Xt, Pt, idx, g, h)
    _, _, S2s = regiao(Xs, Ps, idx, g, h)
    dv = entropia_gauge(Xs, Ps, idx)[0] - entropia_gauge(Xt, Pt, idx)[0]
    p = float((f[idx] ** 2).sum())
    print(f"{r:5.1f} {p:.3f} {s1:.3f} {s2:.3f} | {dS2(1,s1,s2):+.4f} {dS2(2,s1,s2):+.4f} {dS2(4,s1,s2):+.4f} | {S2s-S2:+.5f} {dv:+.5f}", flush=True)
# controle 'gato': uma partícula em dois lugares (dois chapéus distantes); disco que contém um deles -> ln 2
c2 = c + np.array([18.0, 0.0])
fg = modo_chapeu(X, L, c, w) + modo_chapeu(X, L, c2, w); fg /= np.linalg.norm(fg)
gg, hg, _ = gh(lam, V, fg)
for r in (8.0, 10.0, 12.0):
    s1, s2, _ = regiao(Xt, Pt, disco(X, L, c, r), gg, hg); print(f"gato: rho={r}: dS2(n=1) = {dS2(1, s1, s2):.4f}  (ln2 = {np.log(2):.4f}); n=2 {dS2(2,s1,s2):.4f} (binomial {-np.log(6/16):.4f})")
print("tempo total", round(time.time() - t0, 1), "s")
