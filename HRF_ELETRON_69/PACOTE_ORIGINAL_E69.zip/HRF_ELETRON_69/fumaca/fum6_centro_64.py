"""Fumaça 6 — caixa 64x74, w = 4–7: perfis nas três leituras (passo 0,25), picos, razões n2/n1, n4/n1, aditividade
(dois quanta distinguíveis × soma dos dois quanta isolados), profundidade e E1·z0 por leitura."""
import sys, time, json, numpy as np
sys.path.insert(0, "/home/claude/E69/src")
from e65_holo import rede, disco, minimg
from e67_particula import modo_chapeu, raio_metade
from e69_fock import (modos, vacuo_de_modos, gh, regiao2, gamma_centro, dS2_tres, dS2_dist_tres, ortogonaliza, energia_fock)
from avaliar_e69 import pico
t0 = time.time()
X, L, pr = rede(64, 74); c = L / 2 + np.array([0.25, 0.1])
lam, V = modos(len(X), pr); Xt, Pt = vacuo_de_modos(lam, V); print("vácuo", round(time.time() - t0, 1), "s", flush=True)
LEI = ("cond", "compl", "fator"); res = {}
for w in (4.0, 5.0, 6.0, 7.0):
    t1 = time.time()
    f = modo_chapeu(X, L, c, w); g, h, fn = gh(lam, V, f)
    dxy = minimg(X - c, L); f2 = dxy[:, 0] * np.exp(-(dxy ** 2).sum(1) / (2 * w * w)); f2 = ortogonaliza(lam, V, f, f2)
    g2, h2, _ = gh(lam, V, f2); G = np.stack([g, g2], 1); H = np.stack([h, h2], 1)
    E1, e1 = energia_fock(lam, V, f)
    rh = np.arange(0.5, 4 * w + 0.01, 0.25); P = {k: [] for k in ("gam", "gam2", "s2g")}
    for l in LEI:
        for k in ("n1", "n2", "n4", "dip", "dist"): P[f"{k}_{l}"] = []
    for r in rh:
        idx = disco(X, L, c, r)
        Ca, Cb, _ = regiao2(Xt, Pt, idx, G, H); s1, s2 = Ca[0, 0], Cb[0, 0]
        gm = gamma_centro(Pt, idx, g); gm2 = gamma_centro(Pt, idx, g2)
        P["gam"].append(gm); P["gam2"].append(gm2); P["s2g"].append(s2 + gm * gm / 2)
        for n in (1, 2, 4):
            for l, v in zip(LEI, dS2_tres(n, s1, s2, gm)): P[f"n{n}_{l}"].append(v)
        for l, v in zip(LEI, dS2_tres(1, Ca[1, 1], Cb[1, 1], gm2)): P[f"dip_{l}"].append(v)
        for l, v in zip(LEI, dS2_dist_tres(Ca, Cb, (gm, gm2))): P[f"dist_{l}"].append(v)
    res[w] = dict(rh=rh.tolist(), E1=E1, r50=raio_metade(X, L, c, e1), **{k: list(map(float, v)) for k, v in P.items()})
    print(f"\n== w={w} E1={E1:.4f} r50={res[w]['r50']:.3f}  max(s2+g²/2)={max(P['s2g']):.3f}  max|gam2|={np.abs(P['gam2']).max():.2e}  ({time.time()-t1:.0f}s)")
    for l in LEI:
        r1, p1 = pico(rh, P[f"n1_{l}"]); p2 = pico(rh, P[f"n2_{l}"])[1]; p4 = pico(rh, P[f"n4_{l}"])[1]
        pd = pico(rh, P[f"dip_{l}"])[1]; soma = np.array(P[f"n1_{l}"]) + np.array(P[f"dip_{l}"]); js = int(np.argmax(soma))
        ad = P[f"dist_{l}"][js] / soma[js]; mn = min(P[f"n1_{l}"])
        print(f"  {l:5s} pico n1 {p1:.4f} (={p1/np.log(2):.3f} ln2) em rho {r1:.2f} (rho/w {r1/w:.3f}; E1·rho {E1*r1:.3f}) min {mn:+.4f}"
              f" | n2/n1 {p2/p1:.3f} n4/n1 {p4/p1:.3f} | dipolo {pd:.4f} | dist/(n1+dip) no pico da soma {ad:.3f}", flush=True)
json.dump({str(k): v for k, v in res.items()}, open("/home/claude/E69/fumaca/f6_centro_64.json", "w"))
print("tempo total", round(time.time() - t0, 1), "s")
