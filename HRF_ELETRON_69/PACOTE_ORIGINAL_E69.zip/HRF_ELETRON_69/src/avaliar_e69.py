"""HRF — ELETRON-69 — aplica as regras pré-registradas (protocolo §5–§6). Uso: python3 src/avaliar_e69.py [teste]
Leitura principal: 'cond' (condicional / destilável). As mesmas regras são aplicadas às leituras 'compl' e 'fator'
(robustez, H69-R). Classe de uma hipótese por largura -> classe final = a de pelo menos 3 das 4 larguras (no modo teste,
as 2); senão DIVIDIDA."""
import os, sys, json
from math import comb
import numpy as np
from scipy.signal import find_peaks

TESTE = len(sys.argv) > 1 and sys.argv[1] == "teste"
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(RAIZ, "teste_saida") if TESTE else RAIZ
D = os.path.join(BASE, "dados"); RES = os.path.join(BASE, "resultados")
WS = (2.0, 3.0) if TESTE else (4.0, 5.0, 6.0, 7.0)
LEI = ("cond", "compl", "fator"); PRINCIPAL = "cond"
LN2 = np.log(2.0)
BIN = {n: float(-np.log(comb(2 * n, n) / 4 ** n)) for n in (1, 2, 4)}   # lei dos bits (metade dentro): ln 2; 0,9808; 1,2966
BETA24_BITS = float(np.log2(BIN[4] / BIN[2]))                          # 0,403
J = lambda n: json.load(open(os.path.join(D, n + ".json")))


def pico(r, v):
    """posição e valor do máximo com interpolação parabólica."""
    v = np.asarray(v); k = int(np.argmax(v))
    if 0 < k < len(v) - 1:
        den = v[k - 1] - 2 * v[k] + v[k + 1]
        if den != 0:
            dx = 0.5 * (v[k - 1] - v[k + 1]) / den; h = r[1] - r[0]
            return float(r[k] + dx * h), float(v[k] - 0.25 * (v[k - 1] - v[k + 1]) * dx)
    return float(r[k]), float(v[k])


def expoente(rp, v):
    v = np.abs(np.asarray(v)); rp = np.asarray(rp); m = v > 1e-12
    return float(np.polyfit(np.log(rp[m]), np.log(v[m]), 1)[0]) if m.sum() >= 3 else float("nan")


def lombas(v, frac=0.05):
    """número de lombas (máximos locais com proeminência >= frac × máximo); o perfil é cercado por zeros."""
    v = np.asarray(v, float); top = float(v.max())
    if top <= 0:
        return 0
    return int(len(find_peaks(np.r_[0.0, v, 0.0], prominence=frac * top)[0]))


def classe_forma(v):
    """regra H69-B aplicada a um perfil: CONTEÚDO / ONDULAÇÃO / MISTO (devolve também mínimo, máximo e nº de lombas)."""
    v = np.asarray(v, float); mx = float(v.max()); mn = float(v.min()); nl = lombas(v)
    if mn >= -0.01 * mx and mx >= 0.05 and nl == 1:
        c = "CONTEÚDO"
    elif mn <= -0.2 * max(mx, 0.0) and mn < 0:
        c = "ONDULAÇÃO"
    else:
        c = "MISTO"
    return c, mn, mx, nl


def topo(r, v, frac=0.9):
    """posição do máximo por ajuste quadrático (mínimos quadrados) nos pontos >= frac × máximo (descritivo, H69-P)."""
    r = np.asarray(r, float); v = np.asarray(v, float); m = v >= frac * v.max()
    if m.sum() < 5:
        k = int(np.argmax(v)); m = np.zeros(len(v), bool); m[max(0, k - 2):k + 3] = True
    a2, a1, _ = np.polyfit(r[m], v[m], 2)
    return float(-a1 / (2 * a2)) if a2 < 0 else float(r[np.argmax(v)])


def maioria(cls):
    """classe de pelo menos 3 das 4 larguras (todas, se forem menos de 3); senão DIVIDIDA."""
    req = len(cls) - 1 if len(cls) >= 3 else len(cls)
    for c in sorted(set(cls)):
        if cls.count(c) >= req:
            return c
    return "DIVIDIDA"


def cv(x):
    x = np.asarray(x, float); return float(np.std(x) / np.mean(x))


def por_largura(a, l):
    """métricas e classes de uma largura numa leitura."""
    P = a["perfil"]; r = np.array(a["rhos"]); w = a["w"]
    d1 = np.array(P[f"n1_{l}"]); rp1, P1 = pico(r, d1); mn = float(d1.min())
    B, _, _, nl = classe_forma(d1)
    P2 = pico(r, P[f"n2_{l}"])[1]; P4 = pico(r, P[f"n4_{l}"])[1]
    b24 = float(np.log2(P4 / P2)); b12 = float(np.log2(P2 / P1))
    N = "LINEAR" if b24 >= 0.85 else ("SUBLINEAR" if b24 <= 0.65 else "INTERMEDIÁRIO")
    zs = {}; zt = {}; pm = {}
    for dm, m in a["mapa"].items():
        rs, vm = pico(np.array(m["r"]), m[l]); dd = float(dm) * w; zs[dm] = float(np.sqrt(max(rs * rs - dd * dd, 0.0)))
        rt = topo(m["r"], m[l]); zt[dm] = float(np.sqrt(max(rt * rt - dd * dd, 0.0))); pm[dm] = vm
    longe = [zs[k] for k in zs if float(k) >= 2.0] or [zs[max(zs, key=float)]]
    rz = float(np.median(longe) / zs["0.0"])
    longe_t = [zt[k] for k in zt if float(k) >= 2.0] or [zt[max(zt, key=float)]]
    rzt = float(np.median(longe_t) / zt["0.0"]) if zt["0.0"] > 0 else float("nan")
    Pc = "PONTUAL" if rz >= 0.85 else ("GRUDADO" if rz <= 0.35 else "ESTENDIDO EM PROFUNDIDADE")
    fe = d1[r >= 4 * w]; fecho = float(np.abs(fe).max() / P1) if len(fe) else float("nan")
    soma = d1 + np.array(P[f"dip_{l}"]); js = int(np.argmax(soma)); adit = float(P[f"dist_{l}"][js] / soma[js])
    son = {fr: expoente(a["rp"], s[f"fock_{l}"]) for fr, s in a["sondas"].items()}
    cap, apmn, apmx, apnl = classe_forma(P[f"ap_{l}"])
    return dict(pico_n1=P1, pico_sobre_ln2=P1 / LN2, rho_pico=rp1, z0_sobre_w=rp1 / w, min_n1=mn, lombas_n1=nl, classe_B=B,
                aperto=dict(classe=cap, minimo=apmn, maximo=apmx, lombas=apnl), picos_mapa=pm,
                z_estrela_topo=zt, razao_longe_centro_topo=rzt,
                pico_n2=P2, pico_n4=P4, n2_sobre_n1=P2 / P1, n4_sobre_n1=P4 / P1, beta12=b12, beta24=b24, classe_N=N,
                z_estrela=zs, razao_longe_centro=rz, classe_P=Pc, E1_vezes_z0=a["E1"] * rp1, fecho_4w=fecho,
                gam_no_pico=float(np.interp(rp1, r, P["gam"])), aditividade=adit, pico_dipolo=pico(r, P[f"dip_{l}"])[1],
                expoentes_discos_pequenos=son)


def main():
    out = {"leitura_principal": PRINCIPAL, "referencias": dict(bits_n1=BIN[1], bits_n2=BIN[2], bits_n4=BIN[4],
           beta24_bits=BETA24_BITS, beta24_linear=1.0), "por_leitura": {}, "validacoes": {}, "decisoes": {}}
    A = {w: J(f"fock_{w:g}") for w in WS}
    cls = {}
    for l in LEI:
        pw = {f"w{w:g}": por_largura(A[w], l) for w in WS}
        v = list(pw.values())
        z0w = [x["z0_sobre_w"] for x in v]; Ez = [x["E1_vezes_z0"] for x in v]
        cz, ce = cv(z0w), cv(Ez)
        Z = "PROPORCIONAL" if cz <= 0.05 else ("NÃO PROPORCIONAL" if cz >= 0.15 else "PARCIAL")
        M = "INVARIANTE" if ce <= 0.05 else ("NÃO INVARIANTE" if ce >= 0.15 else "PARCIAL")
        cls[l] = dict(B=maioria([x["classe_B"] for x in v]), N=maioria([x["classe_N"] for x in v]),
                      P=maioria([x["classe_P"] for x in v]), Z=Z, M=M)
        out["por_leitura"][l] = dict(por_largura=pw, CV_z0_sobre_w=cz, CV_E1_z0=ce, classes=cls[l])
    # H69-C: que fração do pico mora fora do centro (destilável)?
    fr = {f"w{w:g}": out["por_leitura"]["cond"]["por_largura"][f"w{w:g}"]["pico_n1"] /
          out["por_leitura"]["fator"]["por_largura"][f"w{w:g}"]["pico_n1"] for w in WS}
    frc = {f"w{w:g}": out["por_leitura"]["compl"]["por_largura"][f"w{w:g}"]["pico_n1"] /
           out["por_leitura"]["fator"]["por_largura"][f"w{w:g}"]["pico_n1"] for w in WS}
    cC = maioria(["DESTILÁVEL" if x >= 0.9 else ("NO CENTRO" if x <= 0.5 else "DIVIDIDO") for x in fr.values()])
    incl = float(np.polyfit(np.log(np.array(WS)), np.array(list(fr.values())), 1)[0]) if len(WS) >= 2 else float("nan")
    pl_ = lambda l, w: out["por_leitura"][l]["por_largura"][f"w{w:g}"]
    frd = {f"w{w:g}": pl_("cond", w)["pico_dipolo"] / pl_("fator", w)["pico_dipolo"] for w in WS}
    frm = {f"w{w:g}": {dm: pl_("cond", w)["picos_mapa"][dm] / pl_("fator", w)["picos_mapa"][dm]
                       for dm in pl_("cond", w)["picos_mapa"]} for w in WS}
    gp = {f"w{w:g}": pl_("cond", w)["gam_no_pico"] for w in WS}
    out["H69C"] = dict(fracao_destilavel=fr, fracao_completa=frc, inclinacao_vs_ln_w=incl, classe=cC,
                       gam_no_pico_cond=gp, fracao_dipolo=frd, fracao_mapa_fora_do_centro=frm)
    # validações
    val = out["validacoes"]; a0 = A[WS[0]]; r0 = np.array(a0["rhos"]); S2 = np.array(a0["perfil"]["S2vac"])
    m = (r0 >= 3) & (r0 <= (6 if TESTE else 20)); pf = np.polyfit(r0[m], S2[m], 1); res = S2[m] - np.polyval(pf, r0[m])
    R2v = 1 - (res ** 2).sum() / ((S2[m] - S2[m].mean()) ** 2).sum(); val["V0_lei_de_area_S2"] = dict(R2=float(R2v), ok=bool(R2v >= 0.99))
    vk = np.array(a0["VK"]); esp = float(np.abs(vk - vk[0]).max()); val["VK"] = dict(espalhamento=esp, ok=bool(esp <= 1e-8))
    dom = max(max(A[w]["perfil"]["s2g"]) for w in WS); s1m = max(max(A[w]["perfil"]["s1"]) for w in WS)
    val["VP_dominio"] = dict(max_s2_mais_gam2_meio=float(dom), max_s1=float(s1m), ok=bool(dom <= 1 + 1e-6 and s1m <= 1 + 1e-6))
    gt = J("gato"); dg = float(abs(gt[f"n1_{PRINCIPAL}"][1] - LN2))
    val["VG_gato"] = dict(dS2={l: gt[f"n1_{l}"] for l in LEI}, gam=gt["gam"], desvio_ln2=dg, ok=bool(dg <= 0.01))
    for cod, arq in (("VQ_formula_exata", "VQ.json"), ("VC_centro_forca_bruta", "VC.json")):
        p = os.path.join(RES, arq)
        vq = json.load(open(p)) if os.path.exists(p) else {"max": float("nan"), "ok": False}
        val[cod] = dict(erro_max=vq["max"], ok=bool(vq["ok"]))
    pl = out["por_leitura"][PRINCIPAL]["por_largura"].values()
    apr = []; apv = {}
    for w in WS:
        Pp = A[w]["perfil"]; ap = np.array(Pp["ap_cond"]); vn = np.array(Pp["Svnap"]) - np.array(Pp["Svn0"])
        apr.append(bool((ap.min() < -0.1 * ap.max()) and (vn.min() < -0.1 * vn.max())))
        apv[f"w{w:g}"] = dict(S2_min=float(ap.min()), S2_max=float(ap.max()), vN_min=float(vn.min()), vN_max=float(vn.max()),
                              classe_por_leitura={l: out["por_leitura"][l]["por_largura"][f"w{w:g}"]["aperto"]["classe"] for l in LEI},
                              expoentes_discos_pequenos={fr: expoente(A[w]["rp"], s_["aperto"]) for fr, s_ in A[w]["sondas"].items()})
    val["VA_ponte_aperto_dois_lobos"] = dict(por_largura=apr, valores=apv, ok=bool(all(apr)))
    fes = [x["fecho_4w"] for x in pl]
    val["VF_fecho_fock"] = dict(valores=fes, ok=bool(all((x <= 0.01) or np.isnan(x) for x in fes)))
    ads = [x["aditividade"] for x in pl]
    val["VD_aditividade_simetrica"] = dict(valores=ads, ok=bool(all(0.98 <= x <= 1.02 for x in ads)))
    bt = [out["por_leitura"]["fator"]["por_largura"][f"w{w:g}"]["pico_sobre_ln2"] for w in WS]
    val["VB_um_bit_no_fator"] = dict(valores=bt, ok=bool(all(0.95 <= x <= 1.05 for x in bt)))
    base_ok = all(val[k]["ok"] for k in ("V0_lei_de_area_S2", "VK", "VP_dominio", "VG_gato", "VQ_formula_exata",
                                          "VC_centro_forca_bruta"))
    c = cls[PRINCIPAL]
    if not base_ok:
        geral = "INCONCLUSIVO"
    elif c["B"] == "ONDULAÇÃO":
        geral = "NÃO — sem conteúdo (ondulação, como o aperto da E-67)"
    elif c["B"] == "CONTEÚDO" and c["M"] == "INVARIANTE":
        geral = ("SIM — massa no sentido fraco (objeto do bulk com conteúdo e E·z0 fixo) COM resposta de área "
                 "(a imagem cresce como a energia)" if c["N"] == "LINEAR" else
                 "SIM — massa no sentido fraco (objeto do bulk com conteúdo e E·z0 fixo) SEM gravidade "
                 "(a imagem cresce como informação, não como energia)" if c["N"] == "SUBLINEAR" else
                 "SIM — massa no sentido fraco (objeto do bulk com conteúdo e E·z0 fixo), gravidade indefinida")
    else:
        geral = "PARCIAL"
    dif = [f"{h}: " + " / ".join(f"{l}={cls[l][h]}" for l in LEI) for h in ("B", "M", "N", "P")
           if len({cls[l][h] for l in LEI}) > 1]
    rob = "ROBUSTA (as três leituras dão as mesmas classes em B, M, N e P)" if not dif else "DEPENDE DA LEITURA — " + "; ".join(dif)
    out["decisoes"] = {"H69 (massa na leitura b; leitura principal: condicional)": geral,
                       "H69-B (conteúdo × ondulação)": c["B"], "H69-C (onde mora o bit: destilável × centro)": cC,
                       "H69-N (cresce com n como energia ou como informação)": c["N"], "H69-P (ponto no bulk)": c["P"],
                       "H69-Z (profundidade ∝ tamanho)": c["Z"], "H69-M (massa invariante E·z0)": c["M"],
                       "H69-R (robustez entre as três leituras)": rob}
    os.makedirs(RES, exist_ok=True)
    json.dump(out, open(os.path.join(RES, "E69_resumo.json"), "w"), indent=1, ensure_ascii=False, default=float)
    print(json.dumps(out["decisoes"], indent=1, ensure_ascii=False))
    print(json.dumps({k: v["ok"] for k, v in val.items()}, indent=1, ensure_ascii=False))


if __name__ == "__main__":
    main()
