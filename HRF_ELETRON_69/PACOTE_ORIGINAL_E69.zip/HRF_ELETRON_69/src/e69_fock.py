"""
HRF — ELETRON-69 — estado de Fock (n quanta num modo suave) na fronteira e sua imagem no bulk (leitura de Ryu–Takayanagi).
Máquina exata para a entropia de Rényi-2 de |n_f> = (a_f^dagger)^n |0> / sqrt(n!):
  função característica  chi_n(xi) = chi_0(xi) * L_n(|c(xi)|^2),   c(xi) = -i [G(xi), a_f]   (L_n = Laguerre)
  pureza relativa         R2 = Tr rho_n^2 / Tr rho_0^2 = E_mu[ L_n(|c|^2)^2 ],  mu ~ |chi_0|^2 (gaussiana)
  delta S2 = -ln R2  (exato; sem truncamento).
Na álgebra invariante de gauge da região (diferenças de Z e momentos condicionados ao centro, como na E-65/E-67):
  |c|^2 = (s1^2 + s2^2)/2,  s1 ~ N(0, sig1^2), s2 ~ N(0, sig2^2) independentes,
  sig1^2 = dh^T (2 XY)^{-1} dh,  sig2^2 = g'^T (2 PC)^{-1} g'.
Autoria: Mario José do Canto Filho, MD · código: Claude (-clau)
"""
import numpy as np
from math import comb, factorial
from scipy.linalg import eigh, cho_factor, cho_solve
from e65_holo import W_E, M_N


def modos(N, pr, kap=None):
    """K~ = K/M e seus autopares sem o modo constante (gauge)."""
    if kap is None:
        kap = np.ones(len(pr))
    K = np.zeros((N, N)); a, b = pr[:, 0], pr[:, 1]; w = kap * W_E
    np.add.at(K, (a, a), w); np.add.at(K, (b, b), w); np.add.at(K, (a, b), -w); np.add.at(K, (b, a), -w)
    lam, V = eigh(K / M_N)
    return lam[1:], V[:, 1:]


def vacuo_de_modos(lam, V):
    s = np.sqrt(lam)
    return 0.5 * (V / s) @ V.T, 0.5 * (V * s) @ V.T


def gh(lam, V, f):
    """a_f = (g.x~ + i h.p~)/sqrt2 com g = K~^{1/4} f, h = K~^{-1/4} f (f sem componente constante, norma 1)."""
    fc = V.T @ f
    fc = fc / np.linalg.norm(fc)
    return V @ (lam ** 0.25 * fc), V @ (lam ** -0.25 * fc), V @ fc


def regiao(Xt, Pt, idx, g, h, j0=0):
    """devolve sig1^2, sig2^2, S2 do vácuo e S (von Neumann) do vácuo na álgebra invariante de gauge de idx."""
    idx = np.asarray(idx)
    idx = np.r_[idx[j0], np.delete(idx, j0)]
    XA = Xt[np.ix_(idx, idx)]; PA = Pt[np.ix_(idx, idx)]
    XY = XA[1:, 1:] - XA[1:, :1] - XA[:1, 1:] + XA[0, 0]
    cc = PA[1:, :].sum(1); v = PA.sum(); al = cc / v
    PC = PA[1:, 1:] - np.outer(cc, cc) / v
    dh = h[idx[1:]] - h[idx[0]]
    gp = g[idx[1:]] - al * g[idx].sum()
    cx = cho_factor(2 * XY); cp = cho_factor(2 * PC)
    s1 = float(dh @ cho_solve(cx, dh)); s2 = float(gp @ cho_solve(cp, gp))
    S2 = float(np.log(np.diag(cx[0])).sum() + np.log(np.diag(cp[0])).sum())   # (1/2) ln det(2XY) + (1/2) ln det(2PC)
    return s1, s2, S2


def laguerre_coef(n):
    """coeficientes de L_n(t) = sum_k (-1)^k C(n,k) t^k / k!"""
    return np.array([(-1) ** k * comb(n, k) / factorial(k) for k in range(n + 1)])


def momentos_t(s1, s2, mmax):
    """E[t^m], t = (X + Y)/2, X = s1 chi2_1, Y = s2 chi2_1 independentes."""
    df = lambda j: float(np.prod(np.arange(2 * j - 1, 0, -2))) if j > 0 else 1.0
    EX = [s1 ** j * df(j) for j in range(mmax + 1)]; EY = [s2 ** j * df(j) for j in range(mmax + 1)]
    return np.array([sum(comb(m, j) * EX[j] * EY[m - j] for j in range(m + 1)) / 2 ** m for m in range(mmax + 1)])


def R2(n, s1, s2):
    c = laguerre_coef(n); c2 = np.convolve(c, c)
    return float(c2 @ momentos_t(s1, s2, 2 * n))


def dS2(n, s1, s2):
    return -np.log(R2(n, s1, s2))


def energia_fock(lam, V, f, Kt=None):
    """energia de 1 quantum e densidade local (primeira ordem em n): de<x x> = u u^T, de<p p> = v v^T."""
    fc = V.T @ f; fc = fc / np.linalg.norm(fc)
    u = V @ (lam ** -0.25 * fc); v = V @ (lam ** 0.25 * fc)
    Ku = V @ (lam * (V.T @ u))
    e = 0.5 * (v * v + Ku * u)
    return float((lam ** 0.5 * fc ** 2).sum()), e


# ---------- dois quanta distinguíveis (modos ortogonais f1, f2) ----------
_GH = np.polynomial.hermite_e.hermegauss(6)          # nós/pesos de Gauss–Hermite (probabilista): exato até grau 11


def _raiz(C):
    """L com L L^T = C (C simétrica semidefinida; aceita posto incompleto, ao contrário de Cholesky)."""
    e, U = np.linalg.eigh(0.5 * (C + C.T))
    return U * np.sqrt(np.clip(e, 0.0, None))


def _gauss2(C):
    """pontos e pesos para (s1, s2) ~ N(0, C) 2x2 (exato para polinômios de grau <= 11)."""
    x, wt = _GH; wt = wt / wt.sum()
    Lc = _raiz(C)
    Z = np.stack(np.meshgrid(x, x, indexing="ij"), -1).reshape(-1, 2)
    W = np.outer(wt, wt).ravel()
    return Z @ Lc.T, W


def regiao2(Xt, Pt, idx, G, H, j0=0):
    """como regiao(), para vários modos: devolve Ca (cov de dh_i.xi_x), Cb (cov de g'_i.xi_p) e S2 do vácuo."""
    idx = np.asarray(idx); idx = np.r_[idx[j0], np.delete(idx, j0)]
    XA = Xt[np.ix_(idx, idx)]; PA = Pt[np.ix_(idx, idx)]
    XY = XA[1:, 1:] - XA[1:, :1] - XA[:1, 1:] + XA[0, 0]
    cc = PA[1:, :].sum(1); v = PA.sum(); al = cc / v; PC = PA[1:, 1:] - np.outer(cc, cc) / v
    DH = H[idx[1:]] - H[idx[0]]; GP = G[idx[1:]] - np.outer(al, G[idx].sum(0))
    cx = cho_factor(2 * XY); cp = cho_factor(2 * PC)
    Ca = DH.T @ cho_solve(cx, DH); Cb = GP.T @ cho_solve(cp, GP)
    S2 = float(np.log(np.diag(cx[0])).sum() + np.log(np.diag(cp[0])).sum())
    return Ca, Cb, S2


def dS2_dist(Ca, Cb):
    """|1_f1, 1_f2>: R2 = E[(1-q1)^2 (1-q2)^2], q_j = (sa_j^2 + sb_j^2)/2; Gauss–Hermite exato."""
    Sa, Wa = _gauss2(Ca); Sb, Wb = _gauss2(Cb)
    q1 = 0.5 * (Sa[:, None, 0] ** 2 + Sb[None, :, 0] ** 2); q2 = 0.5 * (Sa[:, None, 1] ** 2 + Sb[None, :, 1] ** 2)
    return float(-np.log((np.outer(Wa, Wb) * ((1 - q1) * (1 - q2)) ** 2).sum()))


def ortogonaliza(lam, V, f1, f2):
    """devolve f2 ortogonal a f1 no espaço dos modos (produto que define [a1, a2^dagger])."""
    c1 = V.T @ f1; c1 /= np.linalg.norm(c1); c2 = V.T @ f2; c2 = c2 - (c1 @ c2) * c1; c2 /= np.linalg.norm(c2)
    return V @ c2


# ---------- o centro da álgebra (fluxo total da região, P_A) ----------
# Na álgebra invariante de gauge, P_A = soma dos momentos da região comuta com tudo (é o centro). No vácuo gaussiano o
# fator F~ = {dZ, p - alfa P_A} é independente do centro; no estado de Fock não é: o quantum mexe na distribuição de P_A.
# Três leituras da entropia (iguais no vácuo; num estado gaussiano qualquer, só a condicional fica igual à da E-65/E-67):
#   'condicional' (destilável, como E-65/E-67):  dS2 = -int P(q) ln[ Tr rho_q^2 / Tr rho0_q^2 ] dq   (média por setor)
#   'completa'   (álgebra inteira, com o termo clássico do centro):  R2 = E[L_n(...)^2] com s2^2 -> s2^2 + gam^2/2
#   'fator'      (só o fator F~ com o alfa do vácuo; ignora o centro): R2 = E[L_n(|c|^2)^2]  (fórmula de regiao)
_QG = np.linspace(-16.0, 16.0, 3201); _DQ = _QG[1] - _QG[0]
_PHI = np.exp(-_QG ** 2 / 2) / np.sqrt(2 * np.pi)
_HE = np.stack([np.polynomial.hermite_e.hermeval(_QG, np.eye(17)[k]) for k in range(17)], 1)   # He_k(q), k <= 16


def gamma_centro(Pt, idx, g):
    """gam = (soma_A g) / sqrt(Var P_A): acoplamento do quantum ao centro da região."""
    idx = np.asarray(idx); v = Pt[np.ix_(idx, idx)].sum()
    return float(g[idx].sum() / np.sqrt(v))


def _gh_nodes(dim, deg):
    m = deg // 2 + 1
    x, wt = np.polynomial.hermite_e.hermegauss(m); wt = wt / wt.sum()
    grids = np.meshgrid(*([x] * dim), indexing="ij"); Z = np.stack([gg.ravel() for gg in grids], 1)
    ws = np.meshgrid(*([wt] * dim), indexing="ij"); W = np.prod(np.stack([q.ravel() for q in ws], 1), 1)
    return Z, W


def _poly_u_laguerre(n, sa, sb, gam):
    """coeficientes em u (ordem crescente) de L_n( (sa^2 + (sb + gam u)^2)/2 ) para cada nó."""
    c = laguerre_coef(n)
    x0 = 0.5 * (sa ** 2 + sb ** 2); x1 = sb * gam; x2 = 0.5 * gam ** 2 * np.ones_like(sa)
    out = np.zeros((len(sa), 2 * n + 1)); pw = np.zeros((len(sa), 2 * n + 1)); pw[:, 0] = 1.0
    for k in range(n + 1):
        out += c[k] * pw
        new = np.zeros_like(pw)
        new[:, :] += pw * x0[:, None]
        new[:, 1:] += pw[:, :-1] * x1[:, None]
        new[:, 2:] += pw[:, :-2] * x2[:, None]
        pw = new
    return out


def _bloco(coef):
    """F(q) = phi(q) sum_k a_k (-i)^k He_k(q) para cada nó (linhas)."""
    K = coef.shape[1]; ph = (-1j) ** np.arange(K)
    return _PHI[None, :] * ((coef * ph[None, :]) @ _HE[:, :K].T)


def dS2_tres(n, s1, s2, gam):
    """devolve (condicional, completa, fator) para |n_f>."""
    fator = dS2(n, s1, s2); completa = dS2(n, s1, s2 + 0.5 * gam ** 2)
    Z, W = _gh_nodes(2, 4 * n)
    sa = np.sqrt(s1) * Z[:, 0]; sb = np.sqrt(s2) * Z[:, 1]
    F = _bloco(_poly_u_laguerre(n, sa, sb, gam)); EF2 = (W[:, None] * np.abs(F) ** 2).sum(0)
    P = _bloco(_poly_u_laguerre(n, np.zeros(1), np.zeros(1), gam))[0].real
    m = P > 1e-300
    cond = float(-(P[m] * np.log(EF2[m] / P[m] ** 2)).sum() * _DQ)
    return cond, completa, fator


def checa_completa(n, s1, s2, gam):
    """consistência da máquina dos setores: pureza completa por setores × fórmula fechada."""
    Z, W = _gh_nodes(2, 4 * n)
    F = _bloco(_poly_u_laguerre(n, np.sqrt(s1) * Z[:, 0], np.sqrt(s2) * Z[:, 1], gam))
    R_set = float((W[:, None] * np.abs(F) ** 2).sum(0).sum() * _DQ * 2 * np.sqrt(np.pi))
    return R_set, R2(n, s1, s2 + 0.5 * gam ** 2)


def dS2_dist_tres(Ca, Cb, gams):
    """dois quanta distinguíveis |1_f1, 1_f2>: (condicional, completa, fator)."""
    fator = dS2_dist(Ca, Cb)
    g1, g2 = gams
    Cb_c = Cb + 0.5 * np.outer(gams, gams)
    completa = dS2_dist(Ca, Cb_c)
    Z, W = _gh_nodes(4, 8)
    La = _raiz(Ca); Lb = _raiz(Cb)
    SA = Z[:, :2] @ La.T; SB = Z[:, 2:] @ Lb.T
    p1 = _poly_u_laguerre(1, SA[:, 0], SB[:, 0], g1); p2 = _poly_u_laguerre(1, SA[:, 1], SB[:, 1], g2)
    coef = np.stack([np.convolve(a, b) for a, b in zip(p1, p2)])
    F = _bloco(coef); EF2 = (W[:, None] * np.abs(F) ** 2).sum(0)
    q1 = _poly_u_laguerre(1, np.zeros(1), np.zeros(1), g1)[0]; q2 = _poly_u_laguerre(1, np.zeros(1), np.zeros(1), g2)[0]
    P = _bloco(np.convolve(q1, q2)[None, :])[0].real; m = P > 1e-300
    cond = float(-(P[m] * np.log(EF2[m] / P[m] ** 2)).sum() * _DQ)
    return cond, completa, fator


def aperto_tres(Xt, Pt, Xs, Ps, idx):
    """estado gaussiano (Xs, Ps) sem correlação x-p (ex.: o aperto da E-67): Delta S2 nas três leituras, relativo ao vácuo.
    cond  = (1/2) ln det(2XY) + (1/2) ln det(2PC) com o alfa do próprio estado (= regiao(); convenção da E-65/E-67);
    compl = cond + (1/2) ln[Var_s(P_A)/Var_0(P_A)]  (o centro gaussiano: -ln int P^2 = (1/2) ln(4 pi Var));
    fator = (1/2) ln det(2XY) + (1/2) ln det(2 PC_alfa0), com PC_alfa0 = cov(p - alfa_vácuo P_A)."""
    idx = np.asarray(idx)

    def partes(Xa, Pa, al0):
        XA = Xa[np.ix_(idx, idx)]; PA = Pa[np.ix_(idx, idx)]
        XY = XA[1:, 1:] - XA[1:, :1] - XA[:1, 1:] + XA[0, 0]; cc = PA[1:, :].sum(1); v = PA.sum()
        PCs = PA[1:, 1:] - np.outer(cc, cc) / v
        PCf = PA[1:, 1:] - np.outer(al0, cc) - np.outer(cc, al0) + v * np.outer(al0, al0)
        lx = 0.5 * np.linalg.slogdet(2 * XY)[1]
        c_ = lx + 0.5 * np.linalg.slogdet(2 * PCs)[1]
        return np.array([c_, c_ + 0.5 * np.log(v), lx + 0.5 * np.linalg.slogdet(2 * PCf)[1]])

    PA0 = Pt[np.ix_(idx, idx)]; al0 = PA0[1:, :].sum(1) / PA0.sum()
    return tuple(float(x) for x in partes(Xs, Ps, al0) - partes(Xt, Pt, al0))
