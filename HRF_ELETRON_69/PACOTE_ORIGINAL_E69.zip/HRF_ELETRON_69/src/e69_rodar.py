"""HRF — ELETRON-69 — rodada (só executar depois do 'pode rodar'). Uso: python3 src/e69_rodar.py [teste]
Grava dados/fock_<w>.json e dados/gato.json; log em resultados/log_execucao.txt.
Cada entropia do estado de Fock é gravada nas três leituras do centro da álgebra (protocolo §2):
  _cond  = condicional / destilável (leitura principal, a mesma convenção da E-65/E-67)
  _compl = álgebra completa (inclui o termo clássico do centro)
  _fator = só o fator, com o alfa do vácuo (ignora o centro; é a leitura da fumaça 1–4)"""
import os, sys, json, time
import numpy as np
from multiprocessing import Pool
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from e65_holo import rede, disco, minimg, entropia_gauge
from e67_particula import modo_chapeu, aperta, raio_metade
from e69_fock import (modos, vacuo_de_modos, gh, regiao, regiao2, energia_fock, ortogonaliza, gamma_centro,
                      dS2_tres, dS2_dist_tres, aperto_tres)

TESTE = len(sys.argv) > 1 and sys.argv[1] == "teste"
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(RAIZ, "teste_saida") if TESTE else RAIZ
D = os.path.join(BASE, "dados"); RES = os.path.join(BASE, "resultados")
os.makedirs(D, exist_ok=True); os.makedirs(RES, exist_ok=True)
TAM = (24, 28) if TESTE else (64, 74)
WS = (2.0, 3.0) if TESTE else (4.0, 5.0, 6.0, 7.0)
NS = (1, 2, 4)                                        # número de quanta no mesmo modo
LEI = ("cond", "compl", "fator")
RHOS = np.arange(0.5, (8.0 if TESTE else 24.0) + 1e-9, 0.25)
RP = np.array([1.0, 1.5, 2.0, 2.5, 3.0]); FR = (0.5, 1.0, 1.5)        # discos pequenos (como na E-67)
DMAP = (0.0, 1.0, 2.0) if TESTE else (0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0)   # mapa: d = DMAP × w
RMAX = 11.0 if TESTE else 30.0                        # teto dos raios do mapa (abaixo de meia caixa: sem dar a volta no toro)
R_SQ = 0.25                                           # ponte com a E-67 (aperto no mesmo modo)
SEP_GATO, W_GATO, RHO_GATO = (8.0, 2.0, (3.0, 4.0, 5.0)) if TESTE else (30.0, 4.0, (8.0, 10.0, 12.0))


def log(*a):
    with open(os.path.join(RES, "log_execucao.txt"), "a") as fh:
        fh.write(time.strftime("%H:%M:%S ") + " ".join(str(x) for x in a) + "\n")


def base():
    X, L, pr = rede(*TAM); c = L / 2 + np.array([0.25, 0.1])
    lam, V = modos(len(X), pr); Xt, Pt = vacuo_de_modos(lam, V)
    return X, L, pr, c, lam, V, Xt, Pt


def tres(n, Xt, Pt, idx, g, h):
    s1, s2, _ = regiao(Xt, Pt, idx, g, h)
    return dS2_tres(n, s1, s2, gamma_centro(Pt, idx, g))


def job(spec):
    tipo, w = spec; t0 = time.time()
    X, L, pr, c, lam, V, Xt, Pt = base()
    if tipo == "gato":
        c2 = c + np.array([SEP_GATO, 0.0])
        fg = modo_chapeu(X, L, c, W_GATO) + modo_chapeu(X, L, c2, W_GATO); fg /= np.linalg.norm(fg)
        g, h, _ = gh(lam, V, fg); out = dict(tipo="gato", sep=SEP_GATO, w=W_GATO, rhos=list(RHO_GATO), gam=[])
        for k in ("n1", "n2"):
            for l in LEI:
                out[f"{k}_{l}"] = []
        for r in RHO_GATO:
            idx = disco(X, L, c, r); s1, s2, _ = regiao(Xt, Pt, idx, g, h); gm = gamma_centro(Pt, idx, g)
            out["gam"].append(gm)
            for n in (1, 2):
                for l, v in zip(LEI, dS2_tres(n, s1, s2, gm)):
                    out[f"n{n}_{l}"].append(v)
        json.dump(out, open(os.path.join(D, "gato.json"), "w")); log("ok gato", f"{time.time() - t0:.0f}s"); return "gato"
    f = modo_chapeu(X, L, c, w); g, h, fn = gh(lam, V, f)
    dxy = minimg(X - c, L); f2 = dxy[:, 0] * np.exp(-(dxy ** 2).sum(1) / (2 * w * w)); f2 = ortogonaliza(lam, V, f, f2)
    g2, h2, _ = gh(lam, V, f2)
    E1, e1 = energia_fock(lam, V, f); E2, _ = energia_fock(lam, V, f2)
    G = np.stack([g, g2], 1); H = np.stack([h, h2], 1)
    Xs, Ps = aperta(Xt, Pt, f, R_SQ)
    out = dict(tipo="fock", w=w, rhos=RHOS.tolist(), ns=list(NS), leituras=list(LEI), E1=E1, E_dipolo=E2,
               r50=raio_metade(X, L, c, e1), rp=RP.tolist(), fr=list(FR), dmap=list(DMAP), rmax_mapa=RMAX)
    chaves = ["s1", "s2", "gam", "gam2", "s2g", "Ca12", "Cb12", "Ca22", "Cb22", "S2vac", "pNW", "Svn0", "Svnap"]
    chaves += [f"{k}_{l}" for k in [f"n{n}" for n in NS] + ["dip", "dist", "ap"] for l in LEI]
    P = {k: [] for k in chaves}
    for r in RHOS:
        idx = disco(X, L, c, r)
        if len(idx) < 2:
            for k in P: P[k].append(0.0)
            continue
        Ca, Cb, S2 = regiao2(Xt, Pt, idx, G, H)
        s1, s2 = float(Ca[0, 0]), float(Cb[0, 0]); gm = gamma_centro(Pt, idx, g); gm2 = gamma_centro(Pt, idx, g2)
        P["s1"].append(s1); P["s2"].append(s2); P["gam"].append(gm); P["gam2"].append(gm2); P["s2g"].append(s2 + 0.5 * gm * gm)
        P["Ca12"].append(float(Ca[0, 1])); P["Cb12"].append(float(Cb[0, 1]))
        P["Ca22"].append(float(Ca[1, 1])); P["Cb22"].append(float(Cb[1, 1])); P["S2vac"].append(S2)
        P["pNW"].append(float((fn[idx] ** 2).sum()))
        for n in NS:
            for l, v in zip(LEI, dS2_tres(n, s1, s2, gm)):
                P[f"n{n}_{l}"].append(v)
        for l, v in zip(LEI, dS2_tres(1, float(Ca[1, 1]), float(Cb[1, 1]), gm2)):
            P[f"dip_{l}"].append(v)
        for l, v in zip(LEI, dS2_dist_tres(Ca, Cb, (gm, gm2))):
            P[f"dist_{l}"].append(v)
        for l, v in zip(LEI, aperto_tres(Xt, Pt, Xs, Ps, idx)):          # ponte com a E-67 (aperto gaussiano)
            P[f"ap_{l}"].append(v)
        P["Svn0"].append(entropia_gauge(Xt, Pt, idx)[0]); P["Svnap"].append(entropia_gauge(Xs, Ps, idx)[0])
    out["perfil"] = P
    log("perfil", f"fock_{w:g}", f"{time.time() - t0:.0f}s")
    son = {}
    for fr in FR:
        x0 = c + np.array([fr * w, 0.0]); v1 = {l: [] for l in LEI}; va = []
        for r in RP:
            idx = disco(X, L, x0, r); s1, s2, S2 = regiao(Xt, Pt, idx, g, h)
            for l, v in zip(LEI, dS2_tres(1, s1, s2, gamma_centro(Pt, idx, g))):
                v1[l].append(v)
            va.append(regiao(Xs, Ps, idx, g, h)[2] - S2)
        son[str(fr)] = dict(aperto=va, **{f"fock_{l}": v1[l] for l in LEI})
    out["sondas"] = son
    mapa = {}
    for dm in DMAP:
        dd = dm * w; x0 = c + np.array([dd, 0.0])
        rr = np.arange(max(0.5, dd - 1.5 * w), min(dd + 3.0 * w, RMAX) + 1e-9, 0.25); v = {l: [] for l in LEI}
        for q in rr:
            idx = disco(X, L, x0, q)
            if len(idx) < 2:
                for l in LEI: v[l].append(0.0)
                continue
            for l, x in zip(LEI, tres(1, Xt, Pt, idx, g, h)):
                v[l].append(x)
        mapa[str(dm)] = dict(r=rr.tolist(), **v)
        log("mapa", f"fock_{w:g}", f"d={dm}w", f"{time.time() - t0:.0f}s")
    out["mapa"] = mapa
    if w == WS[0]:
        idx = disco(X, L, c, 6.0 if not TESTE else 3.0)
        out["VK"] = [list(regiao(Xt, Pt, idx, g, h, j0)[:2]) for j0 in (0, len(idx) // 2, len(idx) - 1)]
    json.dump(out, open(os.path.join(D, f"fock_{w:g}.json"), "w"))
    log("ok", f"fock_{w:g}", f"{time.time() - t0:.0f}s")
    return f"fock_{w:g}"


def main():
    log("== início", "TESTE" if TESTE else "")
    specs = [("fock", w) for w in sorted(WS, reverse=True)] + [("gato", 0.0)]
    with Pool(int(os.environ.get("E69_PROCESSOS", "2"))) as pool:   # nº de processos não muda o resultado
        for _ in pool.imap_unordered(job, specs):
            pass
    log("== fim")


if __name__ == "__main__":
    main()
