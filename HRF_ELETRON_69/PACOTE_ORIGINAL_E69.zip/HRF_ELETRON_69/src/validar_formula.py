"""HRF — ELETRON-69 — VQ: confere a fórmula exata da Rényi-2 de |n_f> e de |1_f1, 1_f2> contra diagonalização direta
numa cadeia de 4 osciladores (espaço de Fock truncado). Uso: python3 src/validar_formula.py [teste]  (escreve resultados/VQ.json)"""
import os, sys, json, numpy as np, scipy.sparse as sp, scipy.sparse.linalg as sla
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from e69_fock import R2, dS2_dist
from math import factorial
np.set_printoptions(precision=6)
N, nmax = 4, 12
K = np.diag([2.3, 2.1, 2.2, 2.4]) - 1.0 * (np.eye(N, k=1) + np.eye(N, k=-1)); K[0, 3] = K[3, 0] = -0.4
d = nmax + 1
a1 = sp.diags(np.sqrt(np.arange(1, d)), 1)
x1 = (a1 + a1.T) / np.sqrt(2); p1 = (a1 - a1.T) / (1j * np.sqrt(2))
I = sp.identity(d)
def op(o, i):
    m = [I] * N; m[i] = o; r = m[0]
    for q in m[1:]: r = sp.kron(r, q, format="csr")
    return r
X = [op(x1, i) for i in range(N)]; P = [op(p1, i) for i in range(N)]
H = sum(0.5 * P[i] @ P[i] for i in range(N)) + sum(0.5 * K[i, j] * X[i] @ X[j] for i in range(N) for j in range(N))
ev, evec = sla.eigsh(H.tocsc(), k=1, which="SA"); g0 = evec[:, 0]
lam, V = np.linalg.eigh(K); s = np.sqrt(lam)
Xc = 0.5 * (V / s) @ V.T; Pc = 0.5 * (V * s) @ V.T
Xn = np.array([[np.vdot(g0, X[i] @ (X[j] @ g0)).real for j in range(N)] for i in range(N)])
print("E0 num/exato", ev[0], 0.5 * s.sum(), " erro cov X", np.abs(Xn - Xc).max())
f = np.array([0.6, -0.5, 0.45, 0.2]); f /= np.linalg.norm(f); fc = V.T @ f
g = V @ (lam ** 0.25 * fc); h = V @ (lam ** -0.25 * fc)
adag = sum((g[i] * X[i] - 1j * h[i] * P[i]) / np.sqrt(2) for i in range(N))
A = [0, 1]; dA = d ** len(A)
def pureza(psi):
    M = psi.reshape(dA, -1); rho = M @ M.conj().T; return float(np.real(np.trace(rho @ rho)))
XA, PA = Xc[np.ix_(A, A)], Pc[np.ix_(A, A)]
s1 = h[A] @ np.linalg.solve(2 * XA, h[A]); s2 = g[A] @ np.linalg.solve(2 * PA, g[A])
pv = pureza(g0.astype(complex)); print("pureza vácuo num/gauss", pv, 1 / np.sqrt(np.linalg.det(2 * XA) * np.linalg.det(2 * PA)))
psi = g0.astype(complex)
for n in (1, 2, 3):
    psi = adag @ psi; ps = psi / np.linalg.norm(psi)
    print(f"n={n}: norma^2/n! = {np.linalg.norm(psi)**2/factorial(n):.8f} | R2 num {pureza(ps)/pv:.8f}  fórmula {R2(n, s1, s2):.8f}")
print("sig1^2, sig2^2 =", s1, s2)
erros = []
psi = g0.astype(complex)
for n in (1, 2, 3):
    psi = adag @ psi; ps = psi / np.linalg.norm(psi); erros.append(abs(pureza(ps) / pv - R2(n, s1, s2)))
# dois quanta distinguíveis
f2 = np.array([0.1, 0.7, 0.3, -0.5]); c2 = V.T @ f2; c2 -= (fc / np.linalg.norm(fc) @ c2) * fc / np.linalg.norm(fc); c2 /= np.linalg.norm(c2)
c1 = fc / np.linalg.norm(fc)
g2 = V @ (lam ** 0.25 * c2); h2 = V @ (lam ** -0.25 * c2)
adag2 = sum((g2[i] * X[i] - 1j * h2[i] * P[i]) / np.sqrt(2) for i in range(N))
psi2 = adag2 @ (adag @ g0.astype(complex)); psi2 /= np.linalg.norm(psi2)
Hm = np.stack([h[A], h2[A]], 1); Gm = np.stack([g[A], g2[A]], 1)
Ca = Hm.T @ np.linalg.solve(2 * XA, Hm); Cb = Gm.T @ np.linalg.solve(2 * PA, Gm)
num_d = -np.log(pureza(psi2) / pv); form_d = dS2_dist(Ca, Cb); print("distinguíveis: num", num_d, "fórmula", form_d)
erros.append(abs(num_d - form_d))
RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(RAIZ, "teste_saida") if (len(sys.argv) > 1 and sys.argv[1] == "teste") else RAIZ
os.makedirs(os.path.join(BASE, "resultados"), exist_ok=True)
json.dump({"erros": erros, "max": max(erros), "ok": bool(max(erros) <= 1e-5)},
          open(os.path.join(BASE, "resultados", "VQ.json"), "w"), indent=1)
print("VQ erro máximo", max(erros))
