"""HRF — ELETRON-69 — validação VC: as três leituras do centro (condicional, completa, fator) contra a força bruta.
Anel de 5 GMFs (sem o modo constante = 4 coordenadas relativas y_j = Z_j - Z_0), região A = {0, 1}.
Álgebra da região: y1 (= dZ), p1, P_A = p0 + p1 (centro). Faz-se a troca canônica (y2, y3, y4) = B z com B[:,0] = 1,
de modo que o momento conjugado de z_c é pi2 + pi3 + pi4 = -P_A. A função de onda do estado de Fock é tabulada numa
grade 4D (y1, z_c, z_r1, z_r2); a transformada de Fourier em z_c dá os setores do centro; o resto (z_r) é traçado.
Nada aqui usa a função característica nem os polinômios de Laguerre: só a função de onda e álgebra de matrizes.
Inclui o aperto gaussiano r = 0,25 (ponte com a E-67) nas três leituras.
Uso: python3 src/validar_centro.py [teste]  ->  resultados/VC.json   (tolerância 1e-6)
Autoria: Mario José do Canto Filho, MD · código: Claude (-clau)"""
import os, sys, json
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from e69_fock import (modos, vacuo_de_modos, gh, regiao, regiao2, gamma_centro, dS2_tres, dS2_dist_tres, ortogonaliza,
                      aperto_tres)
from e67_particula import aperta

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BASE = os.path.join(RAIZ, "teste_saida") if (len(sys.argv) > 1 and sys.argv[1] == "teste") else RAIZ
N = 5; PR = np.array([[i, (i + 1) % N] for i in range(N)]); IDX = np.array([0, 1])
B = np.array([[1.0, 1.0, 0.0], [1.0, -1.0, 1.0], [1.0, 0.0, -1.0]])
NG = 44; NK = 8 * NG


def preparar():
    lam, V = modos(N, PR); Xt, Pt = vacuo_de_modos(lam, V)
    A = (V * np.sqrt(lam)) @ V.T                       # psi0 ∝ exp(-x A x / 2), <x x> = A^{-1}/2 = Xt
    T = np.zeros((4, 4)); T[0, 0] = 1.0; T[1:, 1:] = B   # y = T u, u = (y1, z_c, z_r1, z_r2)
    Q = T.T @ A[1:, 1:] @ T
    cov = 0.5 * np.linalg.inv(Q); L = 7.0 * np.sqrt(2.0 * np.diag(cov))
    ax = [np.linspace(-Lk, Lk, NG) for Lk in L]
    U = np.stack(np.meshgrid(*ax, indexing="ij"), -1)
    psi0 = np.exp(-0.5 * np.einsum("...i,ij,...j->...", U, Q, U))
    Y = U @ T.T                                          # (y1, y2, y3, y4) em cada ponto
    return lam, V, Xt, Pt, ax, psi0, Y


def leituras(psi, ax, alfa):
    """(condicional, completa, fator) em Rényi-2 a partir da função de onda; alfa: P_A = -pi_c."""
    d = [a[1] - a[0] for a in ax]
    ph = np.fft.fftshift(np.fft.fft(psi, n=NK, axis=1), axes=1) * d[1]      # zeros acrescentados: setores finos
    k = np.fft.fftshift(np.fft.fftfreq(NK, d[1])) * 2 * np.pi; dk = k[1] - k[0]
    M = ph.reshape(NG, NK, -1)                            # (y1, k, z_r)
    rho = np.einsum("akr,bkr->kab", M, M.conj()) * d[2] * d[3]
    P = np.einsum("kaa->k", rho).real * d[0]; Z = P.sum() * dk
    rho = rho / Z; P = P / Z
    tr2 = np.einsum("kab,kba->k", rho, rho).real * d[0] ** 2       # Tr (P rho_q)^2 por setor
    pur = tr2 / P ** 2
    y1 = ax[0]
    fases = np.exp(1j * alfa * k[:, None, None] * (y1[None, :, None] - y1[None, None, :]))   # p1 -> p1 - alfa P_A
    rF = (rho * fases).sum(0) * dk
    trF = float(np.einsum("ab,ba->", rF, rF).real * d[0] ** 2)
    return P, pur, float((tr2 * dk).sum()), trF, k, dk


def main():
    lam, V, Xt, Pt, ax, psi0, Y = preparar()
    cc = Pt[np.ix_(IDX, IDX)][1:, :].sum(1); v = Pt[np.ix_(IDX, IDX)].sum(); alfa = float(cc[0] / v)
    P0, pur0, c0, f0, k, dk = leituras(psi0, ax, alfa)
    out = {"alfa": alfa, "variacao_pureza_setores_vacuo": float(np.ptp(pur0[P0 > 1e-6 * P0.max()]) / pur0.max()),
           "fator_vacuo_igual_setor": float(abs(f0 - pur0[np.argmax(P0)]))}   # convenção de sinal do deslocamento
    fs = {"A": np.array([1.0, 0.6, -0.2, -0.7, -0.4]), "B": np.array([0.3, 1.0, 0.4, -0.9, -0.5]),
          "C": np.array([1.0, -0.8, 0.5, 0.1, -0.6])}
    casos = []
    for nome, f in fs.items():
        f = f - f.mean(); g, h, _ = gh(lam, V, f)
        s1, s2, _ = regiao(Xt, Pt, IDX, g, h); gam = gamma_centro(Pt, IDX, g)
        gx = Y @ g[1:]                                    # g.x = sum_{j>=1} g_j y_j (g sem componente constante)
        for n, psi in ((1, gx * psi0), (2, (2 * gx ** 2 - 1.0) * psi0)):
            P, pur, cn, fn, _, _ = leituras(psi, ax, alfa)
            m = P0 > 1e-12
            bruta = (float(-(P[m] * np.log(pur[m] / pur0[m])).sum() * dk), float(-np.log(cn / c0)), float(-np.log(fn / f0)))
            formula = dS2_tres(n, s1, s2, gam)
            casos.append(dict(modo=nome, n=n, s1=s1, s2=s2, gamma=gam, bruta=bruta, formula=list(formula),
                              erro=float(np.max(np.abs(np.array(bruta) - np.array(formula))))))
    f1 = fs["A"] - fs["A"].mean(); f2 = ortogonaliza(lam, V, f1, fs["C"] - fs["C"].mean())
    g1, h1, _ = gh(lam, V, f1); g2, h2, _ = gh(lam, V, f2)
    Ca, Cb, _ = regiao2(Xt, Pt, IDX, np.stack([g1, g2], 1), np.stack([h1, h2], 1))
    gams = (gamma_centro(Pt, IDX, g1), gamma_centro(Pt, IDX, g2))
    psi = (Y @ g1[1:]) * (Y @ g2[1:]) * psi0
    P, pur, cn, fn, _, _ = leituras(psi, ax, alfa); m = P0 > 1e-12
    bruta = (float(-(P[m] * np.log(pur[m] / pur0[m])).sum() * dk), float(-np.log(cn / c0)), float(-np.log(fn / f0)))
    formula = dS2_dist_tres(Ca, Cb, gams)
    casos.append(dict(modo="A+C distinguíveis", n=11, gamma=list(gams), bruta=bruta, formula=list(formula),
                      erro=float(np.max(np.abs(np.array(bruta) - np.array(formula))))))
    # aperto gaussiano (ponte com a E-67): função de onda gaussiana com a covariância apertada
    fa = fs["A"] - fs["A"].mean(); fa /= np.linalg.norm(fa)
    Xs, Ps = aperta(Xt, Pt, fa, 0.25)
    Dm = np.zeros((N - 1, N)); Dm[:, 0] = -1.0; Dm[np.arange(N - 1), np.arange(1, N)] = 1.0
    As = 0.5 * np.linalg.inv(Dm @ Xs @ Dm.T)
    T = np.zeros((4, 4)); T[0, 0] = 1.0; T[1:, 1:] = B
    U = np.stack(np.meshgrid(*ax, indexing="ij"), -1)
    psi_s = np.exp(-0.5 * np.einsum("...i,ij,...j->...", U, T.T @ As @ T, U))
    P, pur, cn, fn, _, _ = leituras(psi_s, ax, alfa); m = P0 > 1e-12
    bruta = (float(-(P[m] * np.log(pur[m] / pur0[m])).sum() * dk), float(-np.log(cn / c0)), float(-np.log(fn / f0)))
    formula = aperto_tres(Xt, Pt, Xs, Ps, IDX)
    casos.append(dict(modo="aperto r=0,25 (gaussiano)", n=0, gamma=0.0, bruta=bruta, formula=list(formula),
                      erro=float(np.max(np.abs(np.array(bruta) - np.array(formula))))))
    out["casos"] = casos; out["max"] = max(c["erro"] for c in casos)
    out["ok"] = bool(out["max"] <= 1e-6 and out["variacao_pureza_setores_vacuo"] <= 1e-8 and out["fator_vacuo_igual_setor"] <= 1e-8)
    for c in casos:
        print(c["modo"], c["n"], "gam", np.round(c["gamma"], 4), "bruta", np.round(c["bruta"], 8), "fórmula", np.round(c["formula"], 8))
    print("vácuo: variação da pureza entre setores", out["variacao_pureza_setores_vacuo"], "| erro máx", out["max"], "| ok", out["ok"])
    os.makedirs(os.path.join(BASE, "resultados"), exist_ok=True)
    json.dump(out, open(os.path.join(BASE, "resultados", "VC.json"), "w"), indent=1, ensure_ascii=False)


if __name__ == "__main__":
    main()
