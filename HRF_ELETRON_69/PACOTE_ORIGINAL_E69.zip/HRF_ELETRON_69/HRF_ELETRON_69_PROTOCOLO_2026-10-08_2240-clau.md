# HRF — ELETRON-69 — Um quantum na fronteira: o estado de Fock dá massa ao objeto do bulk?
## Protocolo pré-registrado (fronteira 2D, leitura por Ryu–Takayanagi) — NÃO EXECUTADO

**Data:** 8 de outubro de 2026, 22h40 (America/Sao_Paulo)
**Autoria:** Mario José do Canto Filho, MD · desenho, código e fumaça numérica: Claude (`-clau`)
**Origem:** pedido do pesquisador (21h19): "você tem como fazer o prompt para a gente testar com o estado de Fock para ver
se conseguimos massa?". A rodada só acontece depois de "pode rodar" — aqui ou no repositório do pesquisador (pacote
portátil, como na E-67).
**Base:** `HRF_ELETRON_67_RELATORIO_2026-10-08_1940-clau.md` — o aperto do estado vira um objeto do bulk com tamanho,
mas sem conteúdo ("pseudomassa": energia só de segunda ordem, imagem em dois lobos); candidato indicado lá: o estado de
um quantum. Leitura (b) [D, 8/10 14h27].
**Revisão antes do registro:** um rascunho das 21h50 (nunca entregue nem executado) usava só a leitura "fator" da
entropia. A revisão mostrou que o centro da álgebra da região guarda parte da informação do quantum; o desenho abaixo
mede as três leituras e escolhe uma como principal (§2). Fumaça refeita: `fumaca/FUMACA_E69.md`, itens 5–9.
**Marcas:** [F] estabelecido · [M] toy model · [H] hipótese HRF · [?] aberto · [D] decisão. **Nada aqui é elétron.**

---

## 1. Pergunta

Na E-67, o aperto (uma excitação unitária) não carrega energia de primeira ordem e sua imagem no bulk é uma ondulação.
Um **estado de Fock** — n quanta inteiros num modo suave f — carrega energia de primeira ordem (n vezes a energia de um
quantum): é um "pacote" indivisível, o análogo mais simples de uma partícula. Perguntas:

1. **Conteúdo:** a imagem do quantum no bulk é uma lomba positiva única (objeto com conteúdo) ou uma ondulação?
2. **Massa:** ela se comporta como um objeto de massa fixa visto a profundidades diferentes — profundidade ∝ tamanho e
   energia × profundidade constante (o "desvio para o vermelho" holográfico: E ∝ 1/z)?
3. **Forma:** a imagem é pontual (um ponto a uma profundidade) ou estendida?
4. **Gravidade:** com mais quanta (mais energia), a imagem cresce **como a energia** (área ∝ massa, como a gravidade
   exigiria) ou só **como a informação** (cresce devagar, como log n)?
5. **Onde mora o bit:** para o modo "chapéu" e discos concêntricos a ele, a informação "de que lado da borda está o
   quantum" é destilável (emaranhamento de verdade) ou fica no **centro** da álgebra — o fluxo total de momento da
   região, uma variável clássica?

## 2. Modelo e escolhas

- **Fronteira e campo [M]:** iguais aos da E-65/E-67 (`src/e65_holo.py` sem mudança): rede triangular a = 1, periódica,
  64 × 74 = 4 736 GMFs; polarização Z; vácuo gaussiano sem o modo constante; álgebra invariante de gauge da região
  (diferenças de Z e momentos).
- **Excitação [D]:** |n_f⟩ = (a_f†)ⁿ|0⟩/√n!, com a_f = Σ f_k b_k (b = aniquiladores do vácuo; f = "chapéu mexicano"
  de largura w, **o mesmo modo da E-67**, sem componente constante). É o pacote de um quantum no sentido de
  Newton–Wigner. n ∈ {1; 2; 4}. **Dois quanta distinguíveis:** |1_f, 1_f'⟩ com f' = x·e^(−r²/2w²) (dipolo no mesmo
  lugar e do mesmo tamanho), ortogonalizado a f; mede-se também o dipolo sozinho, |1_f'⟩.
- **Medida [D]: entropia de Rényi-2**, S₂ = −ln Tr ρ², **exata**: pela função característica,
  χ_n(ξ) = χ_0(ξ)·L_n(|c(ξ)|²) (L_n = polinômio de Laguerre; c linear em ξ), de modo que Tr ρ_n²/Tr ρ_0² = E[L_n(|c|²)²]
  numa gaussiana. Com g = K̃^(1/4) f e h = K̃^(−1/4) f: σ₁² = Δh·(2XY)⁻¹·Δh (lado das diferenças de Z) e
  σ₂² = g'·(2PC)⁻¹·g' (lado dos momentos, fator). Validada contra diagonalização direta (VQ, erro 2 × 10⁻⁸).
  **A entropia de von Neumann do Fock não é calculada.** Ponte com a E-67: o aperto r = 0,25 no mesmo modo, em
  Rényi-2 (nas três leituras abaixo) **e** em von Neumann (leitura condicional, a da E-67).
- **O centro da álgebra [F/D]:** P_A = Σ_A p (fluxo total de momento da região) comuta com tudo o que a região mede: é o
  centro. A álgebra é uma soma de setores, um por valor q de P_A: ρ = ⊕ P(q) ρ_q. No vácuo, ρ_q é o mesmo em todos os
  setores; no estado de Fock, não: o quantum se acopla ao centro com **γ = Σ_A g / √Var(P_A)**. Três leituras, iguais
  **no vácuo** (num estado gaussiano qualquer — por exemplo, o aperto da E-67 — ρ_q ainda é o mesmo em todos os
  setores, e a condicional é exatamente a entropia da E-65/E-67; mas a completa ganha ½ ln[Var(P_A)/Var_vácuo(P_A)] e
  a fator muda se o α do estado se afasta do α do vácuo):
  - **condicional (destilável) — LEITURA PRINCIPAL [D]:** ΔS₂ = −∫P(q) ln[Tr ρ_q² / Tr ρ_q,vácuo²] dq (média por setor).
    Motivo: é a convenção da E-65/E-67 (α tirado do próprio estado, que nos estados gaussianos é exatamente a entropia
    de um setor) e deixa de fora a incerteza clássica do fluxo — é a análoga, em Rényi-2 e setor a setor, da entropia
    destilável (que, a rigor, se define para von Neumann).
  - **completa:** a álgebra inteira, com o termo clássico do centro: σ₂² → σ₂² + γ²/2 na fórmula. Descritiva e usada
    em H69-R.
  - **fator:** só {ΔZ, p − αP_A} com o α do vácuo (a leitura do rascunho das 21h50). Depende da escolha de α.
    Descritiva e usada em H69-R.

  Cálculo exato da condicional: F(q; s) = φ(q) Σ_k a_k (−i)^k He_k(q), onde a_k são os coeficientes, na variável do
  centro, de L_n(½(s_a² + (s_b + γu)²)) (He = Hermite, φ = gaussiana); P(q) = F(q; 0). Validada por **força bruta**
  (VC: função de onda numa grade, setores por transformada de Fourier; Fock n = 1 e 2, dois distinguíveis e o aperto;
  erro 4 × 10⁻¹²). Domínio físico: σ₁² ≤ 1 e σ₂² + γ²/2 ≤ 1 (teoremas: são frações do modo dentro da região; VP).
  **Para n = 1, nas leituras completa e fator, ΔS₂ ≥ 0 é um teorema** (R₂ = 1 − (a + b) + (3a² + 2ab + 3b²)/4 ≤ 1
  para a, b ∈ [0, 1]); **só a condicional pode dar ondulação** — por isso só nela H69-B é um teste.
- **Regra holográfica [D]:** a mesma da E-65/E-67 (disco ρ ↔ semiesfera de raio ρ; topo na profundidade ρ).
- **O que se espera [F]:** num campo sem centro, um quantum dá à região a entropia de um "bit": ΔS₂ = −ln(p² + (1 − p)²),
  máximo ln 2 em p = ½ (Castro-Alvaredo et al., 2018); com n quanta no mesmo modo, ΔS₂(p = ½) = −ln[C(2n, n)/4ⁿ]
  (≈ ½ ln πn): cresce como log n. Aqui a fórmula exata (leitura fator) é ΔS₂ = −ln[p² + (1 − p)² + ¼(σ₁² − σ₂²)²], com
  p = (σ₁² + σ₂²)/2. Com centro, parte desse bit vira informação clássica do fluxo P_A — como os "modos de borda" das
  teorias de gauge, cuja entropia de Shannon não é destilável (Casini–Huerta–Rosabal 2014; Donnelly–Wall 2015;
  Soni–Trivedi 2016). **Num campo livre não há gravidade:** a entropia conta quanta, não energia. Na holografia,
  S = A/4G + S_bulk (Faulkner–Lewkowycz–Maldacena 2013); o "bit" é o termo S_bulk, e a parte de área (∝ energia) só
  existe num regime holográfico.
- **Definições [D]** (em cada leitura): z0 = raio do pico do perfil centrado; E1 = f·K̃^(1/2)·f (energia de um
  quantum); "massa invariante" = E1·z0 constante entre larguras; **β₂₄ = log₂[pico(n=4)/pico(n=2)]** (1 se a imagem
  cresce como a energia; 0,403 na lei dos bits); ponto no bulk: z*(d) = √(ρ*(d)² − d²), onde ρ*(d) é o raio de
  resposta máxima de discos com centro a uma distância d — um ponto a uma profundidade z0 dá z* constante. Picos com
  interpolação parabólica; "lomba" = máximo local com proeminência ≥ 5% do pico (perfil cercado por zeros).

## 3. Parâmetros

| Item | Valores |
|---|---|
| Larguras do modo | w ∈ {4; 5; 6; 7} |
| Quanta | n ∈ {1; 2; 4} (mesmo modo); dipolo sozinho; dois distinguíveis (chapéu + dipolo) |
| Leituras | condicional (principal), completa, fator |
| Centro do modo | c = centro da caixa + (0,25; 0,1) |
| Discos centrados | ρ = 0,5 a 24, passo 0,25 |
| Mapa fora do centro (n = 1) | d = {0; 0,5; 1; 1,5; 2; 2,5; 3} × w; raios de max(0,5; d − 1,5w) a min(d + 3w; 30), passo 0,25 |
| Discos pequenos | ρ ∈ {1; 1,5; 2; 2,5; 3} em d = 0,5w; w; 1,5w (Fock n = 1 nas três leituras e aperto; descritivo) |
| Ponte com a E-67 | aperto r = 0,25 no mesmo modo: Rényi-2 e von Neumann |
| Controle "gato" | um quantum dividido entre dois chapéus (w = 4) separados por 30; discos de raio 8; 10; 12 em volta de um |

## 4. Medidas

Para cada w e cada leitura: perfis ΔS₂(ρ) para n = 1, 2, 4, para o dipolo e para os distinguíveis; σ₁², σ₂², γ, γ do
dipolo, σ₂² + γ²/2 e a probabilidade de Newton–Wigner Σ_A f²; picos (valor e raio); E1, energia do dipolo, r50 da
densidade de energia de um quantum; fecho = max |ΔS₂(ρ ≥ 4w)| / pico (w = 4, 5, 6); mapa ρ*(d) e z*(d); expoentes nos
discos pequenos (Fock e aperto); ponte do aperto (mínimo, máximo, nº de lombas e classe de forma de ΔS₂ nas três
leituras; mínimo e máximo de ΔS de von Neumann); gato nas três leituras. Descritivos de H69-C: fração destilável do
dipolo sozinho, dos picos do mapa fora do centro e γ no pico. Descritivo de H69-P: z* também por ajuste quadrático no
topo (pontos ≥ 0,9 × pico), para medir o ruído da interpolação.

## 5. Regras de decisão

Todas as regras se aplicam à **leitura condicional** (principal) e, para H69-R, também às outras duas. Para as classes
dadas **por largura** (B, C, N, P): a classe final é a de **pelo menos 3 das 4 larguras**; senão, **DIVIDIDA**.

| Código | Regra |
|---|---|
| **H69-B** (conteúdo) | Por largura: **CONTEÚDO** se min ΔS₂(n=1) ≥ −0,01 × pico, pico ≥ 0,05 e **uma só lomba**; **ONDULAÇÃO** se min < 0 e min ≤ −0,2 × pico; senão MISTO. *Só é teste na condicional (nas outras duas, ΔS₂ ≥ 0 por teorema)* |
| **H69-C** (onde mora o bit; modo chapéu, discos concêntricos) | Por largura, fração destilável φ = pico(condicional)/pico(fator) do perfil centrado: **DESTILÁVEL** se φ ≥ 0,9; **NO CENTRO** se φ ≤ 0,5; senão DIVIDIDO. Descritivos: inclinação de φ contra ln w; γ no pico; φ do dipolo e dos picos do mapa fora do centro |
| **H69-N** (gravidade: energia ou informação?) | Por largura: **LINEAR** (área ∝ energia) se β₂₄ ≥ 0,85; **SUBLINEAR** (como informação) se β₂₄ ≤ 0,65; senão INTERMEDIÁRIO. Registram-se n2/n1, n4/n1 e β₁₂ (descritivos) |
| **H69-P** (ponto no bulk) | Por largura, razão = mediana de z*(d ≥ 2w) / z*(0): ≥ 0,85 **PONTUAL**; ≤ 0,35 **GRUDADO**; senão **ESTENDIDO EM PROFUNDIDADE** |
| **H69-Z** (profundidade ∝ tamanho) | CV de z0/w entre as 4 larguras: ≤ 0,05 **PROPORCIONAL**; ≥ 0,15 NÃO PROPORCIONAL; senão PARCIAL. *Esperado pela invariância de escala; é verificação* |
| **H69-M** (massa invariante) | CV de E1·z0: ≤ 0,05 **INVARIANTE**; ≥ 0,15 NÃO INVARIANTE; senão PARCIAL. *Como E1 ∝ 1/w, equivale a H69-Z; também é verificação* |
| **H69-R** (robustez) | **ROBUSTA** se as três leituras dão as mesmas classes em B, M, N e P; senão **DEPENDE DA LEITURA**, com a lista das diferenças. *(Em B a concordância é forçada nas leituras completa e fator; o que pesa é N e P)* |
| **H69** (geral, leitura condicional) | **INCONCLUSIVO** se VQ, VC, V0, VK, VP ou VG falharem; **NÃO — sem conteúdo** se H69-B = ONDULAÇÃO; **SIM — massa no sentido fraco SEM gravidade** se H69-B = CONTEÚDO, H69-M = INVARIANTE e H69-N = SUBLINEAR; **SIM — massa no sentido fraco COM resposta de área** se as duas primeiras e H69-N = LINEAR; **SIM — massa no sentido fraco, gravidade indefinida** se as duas primeiras e H69-N = INTERMEDIÁRIO ou DIVIDIDA; senão **PARCIAL** |

**"Massa no sentido fraco"** quer dizer só isto: um objeto do bulk **com conteúdo** (uma lomba positiva na leitura
condicional) cuja profundidade e energia seguem a regra E·z constante. Como H69-M é uma identidade de escala e H69-N
não deve dar LINEAR num campo livre, o "SIM" se decide, na prática, em H69-B (condicional). Não é a massa de nenhuma
partícula conhecida, nem gravidade.

## 6. Controles e validações

| Código | Exigência | Se falhar |
|---|---|---|
| VQ fórmula exata | `src/validar_formula.py`: erro ≤ 10⁻⁵ contra diagonalização direta (n = 1, 2, 3 e dois distinguíveis; sem centro) | INCONCLUSIVO |
| VC centro | `src/validar_centro.py`: as três leituras contra a força bruta (função de onda, setores por Fourier; Fock n = 1 e 2, distinguíveis, aperto), erro ≤ 10⁻⁶; pureza do vácuo igual em todos os setores (≤ 10⁻⁸); fator do vácuo igual à pureza de um setor (≤ 10⁻⁸; fixa o sinal do deslocamento) | INCONCLUSIVO |
| V0 lei de área | S₂ do vácuo linear em 3 ≤ ρ ≤ 20, R² ≥ 0,99 | INCONCLUSIVO |
| VK gauge | σ₁², σ₂² independentes do GMF de referência ≤ 10⁻⁸ (w = 4, ρ = 6) | INCONCLUSIVO |
| VP domínio | σ₁² ≤ 1 e σ₂² + γ²/2 ≤ 1 (+10⁻⁶) em todos os discos centrados | INCONCLUSIVO |
| VG gato | \|ΔS₂(n=1, ρ = 10) − ln 2\| ≤ 0,01 na leitura condicional | INCONCLUSIVO |
| VA ponte com a E-67 | na leitura condicional (a da E-67), o aperto tem dois lobos em Rényi-2 **e** em von Neumann (mínimo < −0,1 × máximo) em todas as larguras; a classe de forma do aperto nas três leituras fica registrada | registrado |
| VF fecho do Fock | fecho ≤ 0,01 (w = 4, 5, 6; leitura condicional) | registrado |
| VD aditividade por simetria | distinguíveis ÷ (chapéu + dipolo), no pico da soma, entre 0,98 e 1,02 em todas as larguras (chapéu par e dipolo ímpar são independentes num disco centrado) | registrado |
| VB um bit no fator | pico(fator)/ln 2 entre 0,95 e 1,05 em todas as larguras (o "bit" de Castro-Alvaredo et al.) | registrado |

## 7. Fumaça

Ver `fumaca/FUMACA_E69.md`. **Declarado:** a fumaça já mostrou, nas três leituras, lomba positiva única, β₂₄ = 0,40–0,52
(sublinear), imagem estendida em profundidade (razão longe/centro: condicional 0,65–0,68 e completa 0,71–0,76, só em
w = 4 e 5; fator 0,53–0,59 nas quatro larguras), z0/w e E1·z0 constantes (CV ≈ 1%); na leitura condicional, com o
modo chapéu e discos concêntricos, só 26–30% do bit é destilável (φ = 0,26–0,30, subindo devagar com w), enquanto o
dipolo e os discos com centro a d ≥ 1,5w ficam com φ ≈ 0,96–1; gato = 0,6884 em ρ = 10 na condicional (0,6927 no fator);
dois quanta distinguíveis somam exatamente (por simetria); o aperto da E-67 é ondulação na condicional e na completa,
mas não na fator (quase só positivo). Os limiares foram escritos **depois**. O resultado esperado é **"SIM — massa no
sentido fraco SEM gravidade"**, H69-C = **NO CENTRO**, H69-R = **ROBUSTA**.

## 8. Ressalvas registradas antes

- **Campo livre:** Ryu–Takayanagi é a regra escolhida [D]; o campo livre não tem o termo de área que, na holografia,
  responde à energia. A pergunta H69-N mede justamente essa falta.
- **Qual entropia:** a leitura principal (condicional) é uma decisão [D]; as três são publicadas. A diferença entre elas
  não é erro numérico: é física do centro (a mesma questão dos modos de borda das teorias de gauge). A leitura "fator"
  depende da escolha de α e não deve ser usada sozinha. **O contraste "aperto = ondulação × Fock = conteúdo" vale na
  leitura condicional** (a da E-67); na fator, o aperto também sai quase só positivo.
- **H69-C é sobre o modo chapéu e discos concêntricos.** O que se acopla ao centro é o fluxo Σ_A g; ele é grande quando
  o disco contém o miolo positivo de g e deixa de fora o anel negativo. O dipolo (γ ≈ 0) e os discos que cortam o modo
  quase em linha reta (γ → 0 por simetria) ficam com φ ≈ 1.
- **A fração destilável deriva com w** (0,26 → 0,30 entre w = 4 e 7): γ² no pico cai de 0,99 para 0,88. O argumento de
  escala (Σ_A g ~ w^½; Var(P_A) ~ ρ ln ρ, um log ultravioleta) dá γ² ~ 1/ln(w/a₀); os dados pedem a₀ ≪ 1 (ajuste
  γ² ≈ c/(ln w + 2,9)). Se γ → 0, a condicional tende à fator e φ → 1: [H] no contínuo o bit volta a ser destilável,
  mas só logaritmicamente — esta caixa não chega lá; o limite é [?].
- **Profundidade fora do centro é ruidosa:** um erro em ρ* vira um erro 3–5 vezes maior em z*, e os perfis andam em
  degraus (camadas de GMFs entrando no disco). Exemplo da fumaça: z*(3w) em w = 5 é 3,16 na condicional e 4,18 nas
  outras, com picos iguais a 0,5%. Os limiares de H69-P (0,35 e 0,85) deixam margem; o ajuste no topo é registrado
  para medir esse ruído.
- **Rényi-2, não von Neumann**, para o Fock. No regime de "bit" (leitura fator) as duas coincidem no pico (ln 2); para
  n quanta, a de von Neumann também cresce como log n (n = 2: 1,04; n = 4: 1,41 contra 0,98 e 1,30 em Rényi-2).
- **Qual quantum:** a_f† cria o quantum com o modo f nos osciladores normais do vácuo (pacote de Newton–Wigner); por isso
  ele se espalha mais que f². Outra escolha (por exemplo, o campo suavizado φ(f)|0⟩) muda a forma, não a lógica.
- **Massa invariante** e **profundidade ∝ tamanho** saem da autossemelhança do campo sem massa (E1 ∝ 1/w); são
  verificação da rede, não descoberta. O que é medida de verdade aqui: conteúdo (B), forma (P), crescimento com n (N) e
  onde mora o bit (C).
- **Dois quanta distinguíveis** somam por simetria nos discos centrados; por isso viraram controle (VD), não hipótese.
- O pico interpolado pode passar ln 2 em ~0,3% na leitura fator (artefato da parábola; o limite exato é ln 2).
- **Instante t = 0**; só a polarização Z; uma só caixa e uma só rede. "Gravidade" aqui quer dizer só "entropia ∝
  energia", não dinâmica nem atração medida.
- Nada aqui é elétron: sem carga, spin ou a massa do elétron.

## 9. Pedido de decisão [D] — exceção à D-E1

Como na E-67 (exceção aprovada só para ela): **não há onda injetada**; a excitação é um estado quântico de n quanta; um
saca-rolha clássico teria imagem nula no campo livre; o saca-rolha quântico exige a polarização no plano, ainda não
implementada. **Proposta:** a mesma exceção para a E-69. **Sem aprovação, a bancada não roda.**

## 10. Tempo e arquivos

Estimativa: 15 a 40 min em 2 processos (até ~2 GB por processo), dominados pelos mapas; validações ~1 min.
Arquivos: `src/e65_holo.py` e `src/e67_particula.py` (cópias sem mudança da E-67, mesmo SHA-256), `src/e69_fock.py`,
`src/e69_rodar.py`, `src/validar_formula.py`, `src/validar_centro.py`, `src/avaliar_e69.py`, `fumaca/`,
`hashes_antes_da_execucao.txt`. Comandos (só depois de "pode rodar"), nesta ordem: `python3 src/e69_rodar.py`,
`python3 src/validar_formula.py`, `python3 src/validar_centro.py` e `python3 src/avaliar_e69.py`.

## 11. Referências externas [F]

- Castro-Alvaredo, O. A.; De Fazio, C.; Doyon, B.; Szécsényi, I. M. (2018). Entanglement content of quasiparticle
  excitations. *Phys. Rev. Lett.* 121, 170602; e *Entanglement content of quantum particle excitations I. Free field
  theory*, *JHEP* 10 (2018) 039.
- Casini, H.; Huerta, M.; Rosabal, J. A. (2014). Remarks on entanglement entropy for gauge fields. *Phys. Rev. D* 89,
  085012.
- Donnelly, W.; Wall, A. C. (2015). Entanglement entropy of electromagnetic edge modes. *Phys. Rev. Lett.* 114, 111603.
- Soni, R. M.; Trivedi, S. P. (2016). Aspects of entanglement entropy for gauge theories. *JHEP* 01 (2016) 136.
- Faulkner, T.; Lewkowycz, A.; Maldacena, J. (2013). Quantum corrections to holographic entanglement entropy. *JHEP* 11
  (2013) 074.
