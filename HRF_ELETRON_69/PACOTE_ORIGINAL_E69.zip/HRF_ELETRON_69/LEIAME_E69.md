# LEIAME — HRF ELETRON-69 — pacote para execução externa

**Data:** 8 de outubro de 2026, 22h40 · **Autoria:** Mario José do Canto Filho, MD · código: Claude (`-clau`)
**Estado:** pré-registrado, **não executado**. A rodada só começa depois de "pode rodar" e da decisão sobre a exceção à
D-E1 (protocolo §9).
**Protocolo:** `HRF_ELETRON_69_PROTOCOLO_2026-10-08_2240-clau.md`. Nada aqui é elétron.

## O que a bancada mede, em uma frase

Um quantum (estado de Fock, n = 1, 2, 4) num modo "chapéu mexicano" da fronteira: sua imagem no bulk, lida por
Ryu–Takayanagi com a entropia de Rényi-2 exata, tem conteúdo (lomba positiva), escala como um objeto de massa fixa
(E·z0 constante), e cresce com n como a energia ou como a informação? E quanto do "bit" do quantum é destilável e quanto
mora no centro da álgebra (o fluxo total de momento da região)? Três leituras do centro: **condicional** (principal),
completa e fator.

## Requisitos

- Python ≥ 3.10 com `numpy` e `scipy` (`pip install -r requirements.txt`). Testado com Python 3.13.16, numpy 2.5.3 e
  scipy 1.18.1.
- Memória: até ~2 GB por processo (matrizes de 4 736 × 4 736). Com 2 processos, reserve ~4–5 GB de RAM.
- Tempo: 15 a 40 min com 2 processos numa máquina de 2 núcleos (dominado pelos mapas fora do centro); as duas
  validações levam ~1 min juntas. Varia com a máquina.

## Passos

```bash
# 0. conferir que nada mudou desde o registro (a linha de comentário gera só um aviso)
sha256sum -c hashes_antes_da_execucao.txt

# 1. (opcional) teste do encadeamento numa caixa minúscula — ~2 min; o resultado NÃO tem sentido físico
#    (nesse modo VG e VA falham por causa da caixa pequena — esperado)
python3 src/e69_rodar.py teste && python3 src/validar_formula.py teste && python3 src/validar_centro.py teste \
  && python3 src/avaliar_e69.py teste
rm -rf teste_saida

# 2. rodada da E-69 (nesta ordem)
python3 src/e69_rodar.py
python3 src/validar_formula.py | tee resultados/saida_validar_formula.txt
python3 src/validar_centro.py  | tee resultados/saida_validar_centro.txt
python3 src/avaliar_e69.py     | tee resultados/saida_avaliacao.txt
```

Para usar mais processos (se houver memória): `E69_PROCESSOS=4 python3 src/e69_rodar.py`. Cada tarefa é independente e
determinística; o número de processos não muda o resultado.

## O que trazer de volta para o relatório

- `dados/` — 5 arquivos: `fock_4.json`, `fock_5.json`, `fock_6.json`, `fock_7.json`, `gato.json`;
- `resultados/` — `E69_resumo.json`, `VQ.json`, `VC.json`, `log_execucao.txt`, `saida_validar_formula.txt`,
  `saida_validar_centro.txt` e `saida_avaliacao.txt`;
- versões de Python, numpy e scipy e o tipo de máquina
  (`python3 -c "import sys,numpy,scipy;print(sys.version,numpy.__version__,scipy.__version__)"`).

Com isso, o relatório (Objetivo → Hipóteses → Parâmetros → Protocolo → Medidas → Resultados → Controles/convergência →
Interpretação) e as figuras são feitos sem rodar de novo.

## Regras de registro

- Os scripts em `fumaca/` são o registro da fumaça (com os caminhos da máquina original); não fazem parte da rodada.
- Não editar nenhum arquivo listado em `hashes_antes_da_execucao.txt` antes de rodar. Se algo precisar mudar, a mudança
  entra no relatório como **desvio do protocolo**, com o motivo.
- A leitura principal é a **condicional** (protocolo §2); as outras duas são publicadas e entram em H69-R.
- O protocolo (§9) pede uma decisão [D] do pesquisador: **exceção à D-E1** para esta bancada (não há onda injetada; um
  saca-rolha clássico teria imagem nula no campo livre; o saca-rolha quântico exige a polarização no plano, ainda não
  implementada). Sem aprovação, a bancada não roda.
