# C5B-QO-QW03 — Earth Constraint Battery

STATUS: EXECUÇÃO CONCLUÍDA (bateria numérica exploratória). Não é validação física da hipótese.

## 1. Objetivo
Confrontar [H] C5B com observáveis terrestres e tornar limitações, exclusões e previsões explícitas. [M] 79 combinações, 73 perfis executados; 6 critérios de pressão rejeitados analiticamente. Não há ajuste a dados observacionais.

## 2. Modelo usado
[F] Métrica ds²=-A c²dt²+dr²/F+r²dΩ². [M] alpha=2, r0=2GM_V/c², F_virtual=1-r0/r; A_open=r/(r+r0), A_closed=F_virtual. Renormalização QW02: n=(1-f)/(1-m0(rc)/M); rho=n rho_PREM e m=n(m0(r)-m0(rc)) fora da cavidade. Dentro dela, não há matéria terrestre prescrita.

[M] Reconstrução declarada do QW02 a partir do QW01: F_total=F_virtual-2Gm/(c²r), phi=phi_matter+0.5 log A_virtual. phi_matter vem da TOV para a matéria prescrita com a mesma cavidade. Esta composição exige um tensor adicional anisotrópico. Não é a solução TOV de um único fluido terrestre autocoerente.

[F] A aceleração própria estática é g=c² sqrt(F) dphi/dr. A conservação de um fluido isotrópico estático dá P'=-(rho c²+P) phi'. Inserir g próprio diretamente em dP/dr omitiria o fator entre distância própria e raio areal. Não integrar até o horizonte fechado.

## 3. Parâmetros
Ver `parameters.json`, incluindo constantes, dez f de 1e-12 a 1e-3, controle zero, critérios 10%, 1%, 0.1%, e três pontos refinados no limiar de casca fina. Todo caso conserva o mesmo theta=(f,alpha,rc) em A–I. Os critérios de pressão são diagnósticos escolhidos pelo pedido, não limites experimentais.

## 4. Dados observacionais
[F] PREM reutilizado exatamente, SHA256 637d641a905960f4c789e0f6327e5a6b0a407c5dde1a4943e8675ef16678c1f1. Os coeficientes são um perfil de densidade simplificado previamente usado e normalizado pela massa gravitacional; não são medição independente de massa material. Não substituímos os coeficientes por outro PREM.

[?] Os documentos C5B04, bifurcação e notebooks não foram fornecidos/encontrados. O relatório QW02 foi fornecido; seus CSVs/código não. Metadados/textos de 3 referências públicas foram obtidos no GitHub Actions; ver `data/source_access_cloud.json`. Isso não fornece os dados brutos ou covariâncias necessários para uma likelihood observacional.

Canais identificados na referência primária de neutrinos (sem transformar informações bibliográficas em um limite independente de modelo):

{"identified_observables": ["Earth mass", "Moment of inertia", "Core mass", "Complementarity with seismology"], "raw_likelihood_available": false, "numerical_precision_adopted": null} Nenhuma incerteza observacional numérica foi inventada nem extraída desses acessos falhos. Referências bibliográficas conhecidas ao final são identificadas; não há likelihood de neutrinos, dados de frequências, covariância de I ou tempos PKIKP observados no pacote.

[F] Na GR, massa de energia integrada em raio areal, massa ADM, massa de repouso/bariônica em volume próprio e massa inferida por nucleons são diferentes. A convenção QW02 usa integral areal. Qualquer confronto real por neutrinos deve converter volumes/caminhos e tratar composição, interação, energia de ligação e calibração. Para f muito pequeno essas correções convencionais não podem ser ignoradas.

## 5. Testes de regressão QW02
[M] 18/18 valores do relatório reproduzidos; maior erro relativo 0.000347581, compatível com os valores arredondados. As sete pressões microscópicas concordam a melhor que 3.4e-8. Esta é regressão dos números publicados no relatório, não comparação com CSVs ausentes. Referências, tolerâncias e erros completos em `tables/regression_QW02.csv`.

## 6. Massa material × gravidade
[M] M_areal_material=(1-f)M; déficit definido fM. As sensibilidades para 1 e 5 sigma estão em `tables/01_mass_vs_matter.csv`; são precisões futuras requeridas. [?] Não há limite robusto de neutrinos estabelecido nesta bateria. Não usar PREM normalizado por M como confirmação independente. Todos os f não nulos ficam NÃO RESOLVIDOS neste canal.

## 7. Perfil gravitacional central
[M] Perfis estáticos GR e diagnóstico Newton separados. O controle zero recupera a referência TOV/PREM, cuja diferença Newtoniana é de ordem da compactação terrestre. Gravidade superficial quase não distingue f porque a massa total foi fixada. No campo fraco, um núcleo aproximadamente homogêneo dá Δg/g~fM/m0(r) e raios de influência proporcional a f^(1/3), mas remoção e renormalização da cavidade modificam essa regra. Todos os cruzamentos numéricos 0.01%, 0.1%, 1%, 10%, 100% e a igualdade aproximada das contribuições aparecem em `tables/02_gravity_crossings.csv`; raios dentro da cavidade são marcados como fora do domínio material, não extrapolados.

## 8. Cavidade
[M] Para excesso de pressão 1%, f=1e-6 requer rc=1432.5 m; f=1e-3 requer rc=1.15369e+06 m. A cavidade pode ser macroscópica.

[M] No diagnóstico Newtoniano, ΔP/P_matter >=2f/(1-f): o peso dm/r^4 favorece massa material pequena no interior e a média ponderada do m encerrado é <= metade da massa material da casca. A igualdade só aparece no limite de casca infinitamente fina. Portanto o critério de excesso <0.1% é inacessível para f >=0.001/2.001 ≈0.000499750125 nesta família prescrita. Este é limite de um critério do modelo, não uma exclusão observacional geral C5B. A regressão valida a aproximação fraca dos raios terrestres; correções GR foram checadas.

[F/M] Uma cavidade literalmente vazia que remove todo o núcleo interno (rc>=1221.5 km) contradiz o modelo de núcleo interno sólido. Casos assim são excluídos nessa interpretação. Abaixo disso, ausência de dados e kernels impede limites sísmicos rígidos: classificação C, atualmente não resolvido, com escalas de comprimento de onda registradas. Não transformamos λ=v/frequência em uma resolução experimental universal.

## 9. Massa + momento de inércia
[M] I0=8.01889229e+37 kg m²; I0/(MR²)=0.330799487. Para a componente central não rotante, I_virtual=0. O mesmo perfil dá ΔI/I=n(1-I_removed/I0)-1. Para cavidade pequena, ΔI/I≈-f; para cavidades grandes, a renormalização externa pode aumentar I e inverter o sinal. Não corrigimos a densidade para zerar I.

| f | rc mínimo 1% (m) | ΔI/I | fração de volume do núcleo interno removida | stress radial extra aberto (Pa) |
|---:|---:|---:|---:|---:|
| 1e-12 | 0.00143315 | -9.99978e-13 | 1.61509e-27 | -1.7962e+26 |
| 1e-11 | 0.0143315 | -1e-11 | 1.61509e-24 | -1.7962e+24 |
| 1e-10 | 0.143315 | -1e-10 | 1.61509e-21 | -1.7962e+22 |
| 1e-09 | 1.43315 | -1e-09 | 1.61509e-18 | -1.79621e+20 |
| 1e-08 | 14.3315 | -1e-08 | 1.61507e-15 | -1.79624e+18 |
| 1e-07 | 143.309 | -1e-07 | 1.61487e-12 | -1.79653e+16 |
| 1e-06 | 1432.5 | -9.99973e-07 | 1.61288e-09 | -1.79952e+14 |
| 1e-05 | 14266.9 | -9.97335e-06 | 1.59335e-06 | -1.8326e+12 |
| 0.0001 | 137567 | -7.61243e-05 | 0.00142844 | -2.47836e+10 |
| 0.001 | 1.15369e+06 | 0.0125316 | 0.842523 | -3.42045e+09 |

[?] Não há covariância observacional independente para comparar esses desvios com I observado. Limites 3 sigma para precisões hipotéticas estão explicitamente em `tables/04_inertia_conditional.csv`; não são exclusões empíricas. **Limite quantitativo ainda não demonstrado.**

## 10. Modos normais
[M] Calculamos Δpotencial Newtoniano, energia de ligação e uma aproximação radial homóloga de fluido: omega²=(3Gamma-4)|W|/(1.5 I), Gamma=5/3 fixo. A energia inclui autoatração e atração central. [?] Sem tensor elástico e kernels de modos, isso não é omega_0S0 nem qualquer modo terrestre identificado. As precisões espectrais na tabela são sensibilidade desse proxy. O trabalho da borda interna sob pressão não nula e a rigidez do suporte geométrico também não são modelados; a fórmula não é um autovalor da cavidade em equilíbrio. Status MODELO INSUFICIENTE para frequências observacionais.

## 11. Slichter
[M] Benchmark não rotante homogêneo, empuxo e massa adicionada: omega²=(4πG/3)rho_oc(rho_ic-rho_oc)/(rho_ic+rho_oc/2). Densidades média PREM interna e externa na ICB dão T_benchmark=4.83458 h. Não é solução elástica/rotante PREM exata nem período observado.

[M] Calculamos dois cenários distintos: apenas escala de densidades n, com ΔT/T=n^-1/2-1; e núcleo homogeneizado com massa retirada, que pode perder o sinal restaurador nesse toy model. Para uma fonte fixa dentro de uma cavidade de uma casca rígida transladada, o teorema da casca dá força linear direta zero enquanto o deslocamento é menor que rc. Substituir o campo central divergente na fórmula de Slichter inventaria acoplamento. Fonte presa ao núcleo, fonte fixa e cavidade com borda presa não são equivalentes. Cruzamentos de 0.1%, 1%, 10% são registrados apenas para o proxy e podem estar ausentes na grade. Nenhuma detecção atual ou estabilidade dinâmica foi assumida.

## 12. PKIKP
[M] Aproximação 1D para diâmetro central, com extensão explícita de polinômios de vP PREM e sem alteração de densidade original. 2∫0^rc dr/vP dá a escala do trecho removido. 1 ms, 10 ms, 0.1 s e 1 s correspondem aproximadamente a 5.63 m, 56.3 m, 563 m e 5.63 km. Não são previsões de um sinal que atravessa vácuo.

[F] Vácuo não transmite diretamente onda elástica PKIKP: não existe um Δt finito de chegada direta nesse cenário. Geometria sem matéria também não define um meio elástico. [M] Cenários rarefeitos com rho/rho_ext=0.01 e velocidades 0.1, 0.5, 1 e 2 vezes a velocidade central, além de interface ideal com velocidade casada, mostram atraso/avanço e coeficientes de transmissão de duas interfaces planas. Não incluem difração, trajetórias reais, atenuação, anisotropia ou reverberações. Status MODELO INSUFICIENTE para excluir por dados reais.

## 13. Equilíbrio hidrostático
[M] P obtida por conservação do fluido na métrica composta; o comparador possui exatamente a mesma cavidade e massa material. Aberto: pressão finita na garganta. Fechado: observador estático/pressão divergem ao se aproximar do horizonte; domínio de matéria começa em rc>r0.

[F/M] A geometria composta não tem o tensor de um único fluido PREM. Calculamos stress radial adicional p_extra=p_W+cross-ΔP, onde cross=-2(c⁴/8πG)(b_matter phi'_W+b_W phi'_matter)/r². Em alpha=2, o stress isolado fechado fora do horizonte é zero; isso NÃO elimina os stresses adicionais da composição com matéria. Aberto, p_W=-8(c⁴/8πG)mu²/[r³(r+2mu)] e a NEC radial isolada é negativa. O setor extra de energia local zero com p_extra<0 também viola NEC radial na decomposição adotada. Pequena sobrepressão material não implica pequena tensão geométrica. Em 9 casos, a NEC radial TOTAL também é negativa na borda da cavidade; os valores estão no CSV hidrostático e na grade completa. Para f=1e-6, critério 1%, estado aberto, o stress extra na borda é -1.79952e+14 Pa.

[M] Sem suporte para P(rc)>0, a cavidade vazia não satisfaz equilíbrio de interface. Registramos a escala |stress_superficial|~P rc/2 e o stress angular de Israel para o salto de derivada da métrica, como grandezas distintas. O suporte físico e seu acoplamento não foram fornecidos. Todos os f>0 falham no cenário de cavidade sem suporte; com setor extra, são MODELO INSUFICIENTE. Não há prova de estabilidade.

## 14. Ajuste/confronto conjunto
[M] Nenhum ajuste foi executado. Um único theta por caso atravessa os testes. Likelihood conceitual com GM,I,rho_neutrino,vP,vS,modos,Slichter requer covariâncias e leis materiais. PREM e gravidade não são canais estatisticamente independentes automaticamente. Ver `results/joint_likelihood.json`.

| Teste | Observável | Sensibilidade a f_V | Restrição obtida | Status |
|---|---|---|---|---|
| A/I | Independent material mass vs GM | Delta M/M=f | limite quantitativo ainda não demonstrado | NÃO RESOLVIDO |
| B | Deep static gravity | Central fractional signal approximately f*M/m_PREM(r) in weak field | limite quantitativo ainda não demonstrado | NÃO RESOLVIDO |
| C | Solid inner-core existence | Depends on rc and sampling; rc>=IC excluded for literal empty cavity | Literal cavity rc >= 1221.5 km incompatible with solid inner core | TENSÃO |
| D | Total mass and inertia | Delta I/I=n*(1-I_removed/I0)-1; microscopic -f | limite quantitativo ainda não demonstrado | NÃO RESOLVIDO |
| E | Elastic normal modes | Homologous fluid proxy only; mode kernels not specified | limite quantitativo ainda não demonstrado | MODELO INSUFICIENTE |
| F | Slichter | Density and anchoring dependent; hollow-shell direct force vanishes locally | limite quantitativo ainda não demonstrado | MODELO INSUFICIENTE |
| G | PKIKP | Delta t scenario-dependent; vacuum has no direct elastic transmission | limite quantitativo ainda não demonstrado | MODELO INSUFICIENTE |
| H | Hydrostatic/interface support | P(rc)>0 needs support; composed-metric extra stress required | limite quantitativo ainda não demonstrado | MODELO INSUFICIENTE |
| K | Open/closed dynamics | Einstein tensor requirements, no evolution law | limite quantitativo ainda não demonstrado | MODELO INSUFICIENTE |

Cada teste e a combinação têm f_max robusto nulo no sentido de **não calculável**, não f_max=0; o JSON usa `null`. **Limite quantitativo ainda não demonstrado.** No submodelo sem qualquer suporte de cavidade, nenhum f>0 demonstra equilíbrio; isso rejeita esse submodelo incompleto, não toda modificação C5B possível.

## 15. Região excluída
[M] Casos com o critério de pressão inacessível são excluídos desse critério; cavidades que eliminam todo o núcleo interno são excluídas da interpretação material terrestre literal. [F/M] Matéria estática até o horizonte fechado e interfaces materiais sem suporte com P(rc)>0 são inválidas. As demais falhas de observáveis ainda exigem dados/constitutivas; não foram ocultadas nem substituídas por ajuste.

## 16. Região ainda permitida
[?] Não foi demonstrada nenhuma faixa simultaneamente compatível com TODOS os observáveis gravitacionais, materiais e sísmicos. Valores pequenos podem gerar alterações pequenas em canais macroscópicos, mas permanecem não resolvidos e exigem suporte e dinâmica. 'Não excluído por esta bateria' não significa 'fisicamente permitido' ou confirmação.

## 17. Melhor observável futuro
[?] Para separar diretamente matéria e gravidade, a massa/número de nucleons inferida independentemente é o discriminador conceitual mais limpo. Na prática, observações sísmicas com travessias centrais e kernels de momento de inércia podem restringir cavidades macroscópicas antes; não existe ranking quantitativo de poder sem ruído/covariância. Slichter necessita primeiro de um modelo de acoplamento e uma medição confiável. Não alegamos que neutrinos já atingem as precisões necessárias.

## 18. Previsão falsificável C5B-Earth-01
[H/M] Previsão condicional fixada em `parameters.json` antes de usar dados-alvo: alpha=2, f∈[9e-7,1.1e-6], rc mínimo do critério de pressão 1% (1289.31–1575.68 m). Prevê déficit de massa material na convenção QW02 de [9e-7,1.1e-6] M, ou [5.37498e+18,6.56942e+18] kg. A precisão futura total requerida é <=1e-7 relativa.

Se dados FUTUROS independentes medirem massa material, devidamente convertida para a convenção areal/energia, com sigma/M<=1e-7, e não encontrarem esse déficit (resultado compatível com zero), esse intervalo será excluído a pelo menos 9 sigma sob ruído gaussiano e sistemáticas controladas. Não usamos o canal-alvo para ajustar f. A região é atualmente não resolvida, não demonstrada sobrevivente conjunta; o setor de suporte continua uma condição pendente. Uma previsão baseada só na definição de déficit é falsificável para essa parametrização, mas não constitui novo mecanismo causal derivado da C5B.

## 19. Teste exploratório aberto↔fechado
[M] Derivamos G_mu_nu para A(x0,r),F(x0,r), x0=ct, e conferimos por cálculo independente de Christoffel/Ricci. ∇mu G^mu_nu=0 foi verificada simbolicamente nas componentes temporal e radial. G_tr=-F_x0/(rF); fluxo ortonormal=-c⁴F_x0/(8πGr sqrt(AF)). Portanto variar F geralmente exige fluxo; mantendo F fixo não há fluxo radial obrigatório nessa ansatz diagonal, embora stresses anisotrópicos possam variar com o lapse.

[?] Não escolhemos interpolação temporal. Condições de extremidade A_inicial=A_open e A_final=F não são equação de evolução. Horizonte, junções, NEC e causalidade exigem chart regular e setor constitutivo. F=0 numa garganta aberta mínima não prova horizonte de eventos. Identidade de Bianchi não prova realizabilidade física, transição dinâmica nem propagação subluminal.

## 20. Limitações
Perfil de densidade prescrito, composição GR com stresses extras, cavidade/interface sem suporte especificado, velocidades sísmicas suplementares simplificadas, proxies de modos e Slichter, ausência de dados-alvo/covariâncias e ausência de dados observacionais brutos e covariâncias, mesmo com metadados bibliográficos acessíveis. Não há solução dinâmica, EOS terrestre completa, exclusão empírica global de f ou confirmação C5B. Mesmo o déficit material precisa de conversão relativística e composição nuclear para ser inferido por neutrinos.

[M] 17 testes automatizados aprovados; controles de massa, fonte, horizonte, limite f pequeno, GR fraca, pressão e unidades. Convergência radial, conservação e tensor simbólico em `results/validation.json`. Sucesso numérico não implica estabilidade física.

## 21. Próximos testes
Obter dados/covariâncias independentes e o código/CSVs QW02 originais; definir suporte conservado e constitutiva elástica sem ajustar observáveis; resolver modos com gravidade e elasticidade acopladas; definir ancoragem da fonte/cavidade para Slichter; propagar raios e ondas com interface real; testar o déficit previsto sem ajuste pós-dados; derivar uma evolução causal aberto↔fechado.

## Referências e procedência
- Relatório QW02 enviado nesta conversa: preservado em `data/`, fonte dos 18 valores de regressão.
- QW01 e PREM pré-existentes: SHA256 registrado; nunca alterados.
- Dziewonski, A. M.; Anderson, D. L. (1981). Preliminary reference Earth model. Physics of the Earth and Planetary Interiors 25, 297–356. DOI: 10.1016/0031-9201(81)90046-7. Referência bibliográfica dos polinômios; sem dados brutos externos novos no ajuste.
- Slichter, L. B. (1961). The fundamental free mode of the Earth's inner core. PNAS 47, 186–190. DOI: 10.1073/pnas.47.2.186. Referência do problema físico; benchmark aqui derivado sob aproximações declaradas.
- Neutrino tomography of Earth, arXiv:1803.05901: referência para futura obtenção de likelihood, não usada para um limite numérico. Metadados e excertos obtidos quando acessíveis; nenhuma precisão é usada como likelihood sem seus pressupostos e sistemáticas.
